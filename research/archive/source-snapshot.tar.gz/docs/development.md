# Development and testing

## Environment

Use the committed lockfile with Python 3.11:

```bash
uv sync --frozen --extra dev
make check
```

`PYTHON` can select an existing environment without modifying it:

```bash
make check PYTHON=.venv/bin/python
```

## Test boundaries

| Command | Scope | External data or live inference |
|---|---|---|
| `make test` / `make test-public` | Synthetic trace, provider, benchmark, and public-interface tests | Neither |
| `make verify` | Documentation, repository hygiene, selected frozen artifact integrity | Neither |
| `make check` | Both of the above | Neither |
| `make prepare-commit` | Public checks, review-only file inventory and local-history pattern scan | Neither |
| `make research-check` | Full archived score accounting, figure metadata, and authoring contracts | No live inference; uses repository archive files |
| `make test-all` | Every historical test file in an isolated process | Some files need local `data/` and `output/` |

The default suite is intentionally the public framework suite, not a claim that
all historical tests pass. Some historical modules mutate shared runner globals
at import time. Use `make test-all`, not a single-process `pytest -q`, for those
versions. The isolated runner records failures and timeouts under
`output/test-reports/`. Do not skip a failing assertion to produce a clean report.

Individual synthetic tests can run directly:

```bash
uv run python -m pytest -q tests/test_public_interface.py
```

Optional local commit hooks check documentation, hygiene and frozen artifact
integrity; they do not rewrite files. Archive-specific maintenance commands
live in `research/Makefile` and are documented through the research gateway.

The [validation status](release-status.md) distinguishes current public checks
from earlier private-input tests and their unresolved failures.

## Repository conventions

Use small, focused changes. Keep examples synthetic and use temporary directories
in tests. Stub provider calls rather than requiring credentials. Preserve frozen
protocol and artifact identities; version semantic changes separately.

Public documentation links are checked by `make docs-check`. The checker covers
the maintained public pages and the research gateway/current proposal, not every
historical notebook or network URL. Preserve a single research navigation entry
instead of adding iteration diaries to the user-facing introduction.

See [Contributing](../CONTRIBUTING.md) for review expectations and
[Publishing](../PUBLISHING.md) for wheel/source-distribution checks.

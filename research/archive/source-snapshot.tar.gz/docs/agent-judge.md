# Codex Agent Judge

Agent Judge is the default semantic-diagnosis direction for subsequent
AgentDebug experiments. Optimization is currently paused. The runtime default
remains the historical `luna-v12`, but it is not eligible for promotion under
the current no-prior-answer-routing boundary; do not use it for a new tuning
candidate. Historical protocols remain available by explicit protocol name so
their artifacts stay reproducible.

The two incumbent concepts are deliberately separate:

- **Historical routed result:** Luna v12 scored 13/30 Step Exact, but it reads
  the same-case Luna v3 answer and routes by its module/type. The current fixed
  boundary explicitly rejects that mechanism, so 13/30 is not a compliant
  incumbent or a completed goal.
- **Proposal-free control:** Luna v12 standalone produced 30/30 valid outputs
  but only 7/30 Step Exact. No current run simultaneously satisfies the
  no-prior-answer-routing boundary and the 12/30 target.
- **Historical target reference:** DeepSeek v58 at 12/30.  It is not the
  execution architecture and none of its prediction artifacts, caches,
  proposals, or batches are inputs to Luna.

The requirement-by-requirement audit is recorded in
[`docs/experiments/luna-v12-goal-completion-audit-2026-08-20.md`](experiments/luna-v12-goal-completion-audit-2026-08-20.md).

## Historical routed Luna v12 configuration

- model: `gpt-5.6-luna`
- reasoning effort: `medium`
- protocol: `agentdebug.codex-agent-judge.luna-v12`
- external LLM/API calls by the subagent: none
- input: complete gold-free prediction manifest plus matching cohort manifest
- output: one strict ten-field JSON record per case
- numerical confidence, score, probability, voting, and ranking: forbidden

The historical routed source of truth is
[`agentdebug/diagnostics/agent_judge_luna_v12.py`](../agentdebug/diagnostics/agent_judge_luna_v12.py).
It copies every audit-valid same-case Luna v3 prediction outside the exact
`planning/inefficient_plan` sink and mechanically rejects any out-of-scope
revision. Sink proposals must move to a different step and are attributed as a
single locally explicit failure after competition among Reflection assertions,
plan/action contracts, repetition maturity, and terminal System exhaustion.
Each session receives only its own one-row incumbent; no DeepSeek v58 artifact
or cross-case context is used. Historical v1-v2.4 and Luna v1-v11 sources are
not mutated.

## Evaluation boundary

The workflow is always split at a persisted artifact boundary:

```text
gold-free manifest + cohort
          ↓
prepare: preregistration + agent-task.md
          ↓
fresh Codex agent (gpt-5.6-luna/medium)
          ↓
predictions.json
          ↓
gold-free fail-closed validation
          ↓
prediction-audit.json
          ↓
only now: load labels and score
```

The subagent must use a fresh context and may read only the paths listed in its
generated task. It must never read labels, metrics, scored predictions, prior
predictions, case studies, model caches, or git history. A reported forbidden
read invalidates the entire run.

## Optimization policy

All future variants retain the Agent Judge architecture. Prompt and workflow
changes are developed and measured only on the complete frozen `tuning-v1`
cohort: 30 trajectories, ten from each environment. `smoke-v1` and the former
9-case slice are not active tuning inputs. A new version is compared against
the best full-`tuning-v1` result, not merely the immediately preceding run.

Use this simplified workflow:

1. Run the three lightweight synthetic test files in
   `LIGHTWEIGHT_ENGINEERING_TESTS`, then `py_compile` and `git diff --check`.
2. Run the candidate once on all 30 `tuning-v1` trajectories. Each trajectory
   gets one fresh Luna session; a bounded worker pool (four by default) only
   controls concurrency. Failed sessions retry only their own trajectory.
   All 30 results are mechanically restored to cohort order before validation
   and scoring.
3. Strictly validate all 30 records before loading any labels. Module/type
   distributions are reported as diagnostics and never block scoring.
4. Score the complete cohort. After every failed semantic attempt, write a
   case study identifying the
   error mode, causal ownership failure, and one falsifiable next change.
5. Promote only on the preregistered metric order: Step Exact, Step+Module,
   All Correct, then invalid-output count.

The historical routed runner is
[`scripts/run_agent_judge_luna_tuning.py`](../scripts/run_agent_judge_luna_tuning.py).
It rejects any cohort or prediction manifest that is not the exact frozen
full `tuning-v1` identity. The runner preregisters exactly 30 one-case sessions
at the logical input layer. The generic CLI still defaults to the ineligible
`luna-v12`; this is retained for historical reproduction and must be changed
before any new candidate run. With `--execute`, scoring runs automatically only
after the merged 30-case prediction array passes the full gold-free validator.

Each child may run the local validator for immediate feedback, but the parent
runner is authoritative: it revalidates that single prediction and writes the
preregistered audit itself. A missing or invalid prediction alone triggers a
fresh attempt directory; a child-side shell or audit-path mistake cannot spend
another Luna call when the prediction is already valid.

## Historical routed Luna v12 tuning-v1 result

The frozen full-cohort routed Luna v12 run is persisted under
`output/agenterrorbench-codex-gpt-5.6-luna-tuning-v1-agent-judge-luna-v12-case30/`.
It produced 30/30 valid predictions and passed the merged strict gold-free
audit before scoring.  Official metrics are Step Exact **13/30**, Step+Module
**6/30**, and All Correct **5/25**, with ALFWorld / GAIA / WebShop Step Exact
of **3/10 / 6/10 / 4/10**.  All 30 isolated sessions completed on attempt one.

This result is the outcome of protocol tuning on `tuning-v1`; it is not a
held-out or unknown-data generalization estimate. It is also not eligible under
the current boundary because the protocol uses same-case Luna v3 predictions
to select copy-versus-replace behavior. The proposal-free standalone control
is persisted under
`output/agenterrorbench-codex-gpt-5.6-luna-tuning-v1-agent-judge-luna-v12-standalone-v1-case30/`
and scored 7/30 Step Exact, 3/30 Step+Module, and 2/25 All Correct. The persisted
`final-experiment-report.md` and `promotion.json` in the run directory record
the historical protocol, session topology, hashes, audit boundary, artifact
inventory, and its then-recorded promotion from the 8/30 Luna v3 result; that
promotion record does not override the subsequently tightened experiment
boundary.

### Nested-sandbox limitation

The current container does not permit the nested `workspace-write` Linux
sandbox to create its loopback namespace (`bwrap ... RTM_NEWADDR`). Child
Codex sessions therefore use `danger-full-access` in the host workspace. The
allowlist/denylist, one-case input construction, retained JSONL
logs and validator still enforce the experiment protocol, but the filesystem
read boundary is contractual and auditable rather than kernel-enforced. A
future adversarial-grade deployment should place each child in a container
that mounts only its case manifest and output directory.

The frozen Experiment B artifacts remain under
`output/agenterrorbench-codex-gpt-5.6-terra-smoke-v1-experiment-b-v1/`.
They establish v1's historical baseline: 30/30 valid outputs, Step Exact 7/30,
Step+Module 3/30, and All Correct 2/27. These are retrospective smoke results,
not a new heldout claim.

## Historical Terra results

The first isolated v1 run on `tuning-v1` is persisted under
`output/agenterrorbench-codex-gpt-5.6-terra-tuning-v1-agent-judge-v1/`.
It produced 30/30 valid records, Step Exact 5/30, Step+Module 1/30, and
All Correct 0/25.  Its principal failure is a protocol-level action sink:
all 30 cases were assigned to `action`, and 26 used `parameter_error`.
The post-score case study is `tuning-failure-case-study.md` in that run.

Agent Judge v2 is a frozen challenger, not a replacement for v1 until it
passes promotion.  It keeps `gpt-5.6-terra/medium`, the ten-field output
contract, and the gold-free boundary, while changing the semantic order to:

```text
chronological causal breakpoint
              ↓
freeze predicted step
              ↓
same-step module ownership matrix
              ↓
action admission gate
              ↓
taxonomy type classification
```

The v2 Action Admission Gate requires an independently adequate same-step plan
and a concrete invocation that introduces a new defect.  A bad strategy that
the action faithfully executes remains planning ownership; a false memory or
reflection propagated downstream remains with its earliest mature owner; an
incorrect final answer is not automatically an action error; and
`parameter_error` is not a generic wrong-choice label.

The former 3x3 gate implementation and artifacts are retained for audit and
historical reproduction. They are not invoked by the active Luna tuning
runner and their distribution thresholds are not promotion criteria.

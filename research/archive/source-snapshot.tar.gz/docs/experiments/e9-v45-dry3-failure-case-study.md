# E9 v45 dry3 interrupted-selector failure case study

## Outcome

v45 did not produce a scorable dry3 result. The candidate stage completed
successfully, but the execution session ended while the Selector completion
was outstanding:

- candidate logical completion: reserved and completed;
- Selector logical completion: conservatively reserved before transport, but
  no response sidecar, raw response, or parsed record exists;
- logical-completion ledger: exactly 2/2 reservations, hard stop 541;
- unscored predictions: an empty file;
- predict-run metadata: absent;
- scoring and promotion: not run.

The immutable local evidence is:

- preregistration file SHA-256:
  `442e1c464232d91ebd7a246d7f55a77e6d4dfd33fc19254e97b40ce6db95b1db`;
- completion-ledger file SHA-256:
  `caefd523e4b7e4e2e67d2b5d81bb423d280a031cf9b55caa6be63d02d3f64b5c`;
- candidate parsed-record file SHA-256:
  `6a2d543a096943e89890dcf92a97842aadb664dbc54b4e2cb960671ace8ffa30`;
- candidate raw-wrapper file SHA-256:
  `236c2a70668ae32f747de286f566896c2a9f90bdb6b4d2e81c0d8241c134cb4a`;
- candidate response-sidecar file SHA-256:
  `f903f3d83ed3f891bf18099fb1875b80b6b8fa90a4eac892b73c10b0d918fc2e`;
- empty unscored-predictions file SHA-256:
  `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

v45 therefore cannot be reported as a diagnostic pass or failure and must
not advance directly to full30 or smoke.

## Case study

### Candidate stage completed normally

The candidate response is valid JSON, covers C01-C03 in frozen order, passes
the isolated parser, and has no per-case failure. Its provider telemetry is:

- one logical completion and one HTTP attempt;
- zero retries;
- 687,076 request input characters;
- 190,179 input tokens, 21,377 output tokens, and 211,556 total tokens;
- finish reason `stop`;
- 206.22 seconds of stage latency.

Its content also shows that the intended v45 Selector experiment remained
meaningful. C01 includes the released step-30 `system/step_limit` boundary,
C02 contains competing action and downstream-planning roots, and C03 contains
multiple planning/step-limit alternatives. The missing result is selection,
not candidate generation.

### Selector never became an auditable response

The ledger's second entry binds the exact Selector request SHA-256
`4fadfc5080530223bcc88f9077c64cd9ede5a353f3758f79c7b1a9c35b6ab989`.
No file for that request exists under any of the Selector sidecar, raw, or
parsed cache directories. The original process is no longer running.

The cache writes a response sidecar as the first operation after the provider
call returns. Its absence proves only that no response returned to application
code and reached that write. It does not prove whether the remote provider
received or billed the request. Treating the reservation as consumed is the
safe, conservative accounting choice.

An exact rerun correctly fails closed with `E8 logical-completion budget is
exhausted`: the existing ledger has already consumed both preregistered slots,
and there is no authoritative Selector sidecar from which to recover. The
rerun did not issue another provider request.

## Attribution

This failure is not evidence about v45 diagnostic accuracy, its categorical
boundary/action checks, DeepSeek output format, JSON parsing, or taxonomy
selection. There is no raw Selector judgment to evaluate.

The immediate cause is a pre-response execution interruption during a very
large, slow semantic request. The durable ledger deliberately records
authorization before transport, so it favors never exceeding a phase budget
over automatically replaying an ambiguous in-flight request. Response-sidecar
recovery covers interruptions after a response returns; it cannot recover an
interruption before any response is persisted.

The 190,179-token candidate input and 206-second latency make a long Selector
call vulnerable to loss of its controlling execution session. The session
loss is the observed operational failure; prompt length is a risk amplifier,
not a proven provider error. No API error response, retry, or invalid model
output was recorded.

No deterministic finding, semantic fallback, score, confidence, weight, vote,
or gold label participated.

## Recovery hypothesis

The next attempt must be a separately preregistered one-call Selector recovery,
not a mutation of the exhausted v45 ledger and not a new candidate call.
It will:

1. cryptographically bind this v45 preregistration, ledger, empty output, and
   exact successful candidate cache triplet;
2. reconstruct and verify the same v45 candidate and exact Selector request;
3. permit exactly one new logical completion for the missing Selector only,
   starting at cumulative count 541 and stopping at 542;
4. write its own durable ledger, response sidecar, raw record, predictions,
   run metadata, score, and promotion decision;
5. retain the v45 candidate prompt, v45 Selector prompt, raw-LLM ownership,
   frozen cases, and all dry gates unchanged.

This is an operational recovery protocol, not semantic tuning. The hypothesis
is falsified if any bound v45 byte has drifted, if the reconstructed request
hash is not the recorded Selector hash, if any provider call other than that
one selector is possible, or if the recovered result misses the unchanged
2/3 dry promotion gates. Any provider or benchmark failure again requires a
new completed case study before another LLM call.

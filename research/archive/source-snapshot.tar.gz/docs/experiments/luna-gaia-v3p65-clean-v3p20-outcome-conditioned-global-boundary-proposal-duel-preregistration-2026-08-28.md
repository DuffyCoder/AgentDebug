# Luna GAIA v3.65 预注册：outcome-conditioned global boundary proposal duel

日期：2026-08-28

## 冻结实验身份

- 版本：`agentdebug.codex-agent-judge.luna-gaia-v3.65-clean-v3.20-outcome-conditioned-global-boundary-proposal-duel`
- semantic parent：`agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- accepted incumbent：Luna v3.20，Step Exact `25/50`
- 原始冻结基线：Luna v3.4，Step Exact `21/50`
- 版本接受条件：完整、合法 GAIA-50 上 Step Exact `>25/50`
- Goal 完成条件：完整、合法 GAIA-50 上 Step Exact `>=30/50`
- 数据集：冻结 `gaia-paper-v1` 50 例
- 模型：`gpt-5.6-luna`
- reasoning effort：`medium`
- 运行拓扑：每例三个阶段，共 `150` 个成功 inference stages，允许失败重试但不允许缺例
- smoke gate：无；离线验证通过后直接运行完整 GAIA-50
- 选择指标：仅 Step Exact；Module/type/evidence 只作合法性约束

v3.65 是从 v3.20 协议语义干净重建的直接子版本。v3.39、v3.47、v3.49、
v3.50、v3.54、v3.56、v3.57、v3.59、v3.60、v3.61、v3.62 和 v3.64 的
prompt、候选、ledger、selector、validator 或预测均不作为 semantic parent，也不
累积进入本版本。它们只提供评分后机制证据。

## 先验事实与论文差异

v3.20 与 v3.39 都是 `25/50`，尚低于论文 AgentDebug 的 `29/50`。本地实验已
反复说明，论文式 Step×Module 局部画像可以把候选覆盖推过 30，但不能可靠地把
局部 positive 压缩成最终 critical Step：v3.54 的 local matrix 覆盖 `31/50`，
v3.56 覆盖 `36/50`，v3.57 fresh-anchor union oracle 为 `41/50`，最终结果却分别
只有 `18/50`、`22/50` 和 `20/50`。扩大候选池会形成候选洪泛，不能单独解释论文
29/50 的优势。

较小的 global-proposal 对照 v3.49 更有正信号：fresh anchor `21/50`，单 proposal
`16/50`，anchor-plus-proposal oracle `27/50`，duel 对 fresh anchor 产生 6 gain、
2 loss，最终 `25/50`。其瓶颈主要是 proposal recall。

v3.62 的完整 local matrix gold coverage 为 `29/50`、anchor union 为 `39/50`，
但 gold candidate 的 pairwise win 只有 2 例。评分后审计显示，它把
candidate-only repair 错误地解释为必须修好整个后续轨迹，形成过强的
whole-trajectory replaceability gate。

v3.64 的异构 panel 完整运行得到 Step Exact `18/50`，fresh anchor `21/50`，
specialist union 只覆盖 `15/50` gold，anchor-plus-any-specialist oracle 仅 `26/50`；
selector 相对 fresh anchor为 2 gain、5 loss。独立访问/写拓扑审计也失败，因此
v3.64 永久拒绝。即使忽略合法性，它的 oracle 也已证伪“只需硬化路径并重跑同一
panel”的方向。

## 唯一主要机制变化

相对 v3.20 只增加：

`one outcome-conditioned global boundary proposal duel`

1. 先运行完全不变的 v3.20 anchor，保留其 prediction、ledger 和 checkpoint。
2. 独立、anchor-blind 的 full-trajectory proposal 阶段最多输出一个全局 boundary，
   不生成局部候选投票或 per-Module reservoir。
3. proposal 必须同时从 ex-ante 和 ex-post 判断 probe：合理的初始探索不是永久 veto；
   只有 literal evidence 支持以下关系时才可把它提升为 material critical error：
   `task_contribution=zero`、`continuation_effect=failed_path`、
   `local_repair=redirects_owned_path`。
4. `local_repair` 只要求改写候选 Step 自己拥有的紧邻失败子路径，不要求单独修复
   全部后续错误或保证任务最终成功。
5. 如果 probe 产生了可复用线索，或实际引向 constructive new route，则它仍是
   normal/reasonable probe，不能被提升。
6. 最后一个 bounded duel 只能 exact-copy v3.20 anchor 或该唯一 proposal；证据
   不足时默认保留 anchor，不允许第三个 Step、不允许结果拼接。

这是一个统一的 critical-boundary maturity 变化，不包含 panel、多候选排序、
per-Module 投票、历史预测共识、case router 或任何 trajectory-specific 规则。

## Artifact contract 与可证伪关系

proposal validator 强制以下四字段同时出现：

```text
proposal_probe_status=(reasonable|material_error|not_applicable)
task_contribution=(zero|observed|not_applicable)
continuation_effect=(failed_path|constructive_new_route|not_applicable)
local_repair=(redirects_owned_path|does_not_redirect|not_applicable)
```

唯一允许的语义组合是：

- material proposal：`material_error / zero / failed_path / redirects_owned_path`
- reasonable probe：`reasonable / observed / constructive_new_route / does_not_redirect`
- no proposal：四项相应为 `not_applicable`

selector 必须绑定 anchor/proposal 的 Step、Module、type 和 literal witness，所选
prediction 必须与来源 artifact exact-copy 一致。最终 50 条 prediction、anchor、
ledger、checkpoint、proposal 和 duel 都必须覆盖同一冻结 cohort、顺序一致并通过
schema/taxonomy/evidence validator。

## 预期 gains、regressions 与反例

预期 gains 来自 v3.20 的 early capability false positive、被 initial/different
probe 类别性 veto 掩盖的成熟失败，以及 later symptom preference：真实 probe 在
看到 outcome 后显示零任务贡献，并使同一错误路径延续时，应能把 boundary 移回
该 owner Step。该假设不依赖 case ID、实体、网站或固定 Step。

主要回归风险是把正常工具失败、低概率但有信息价值的探索或尚未成功但提供了
可复用线索的 probe 误升为 critical error，使整体选择偏早。直接反例包括 v3.20
已正确但 ledger 中存在早期 negative outcome 的样本，以及 v3.44/v3.50 的候选
洪泛和 false override。强制四字段关系、max-one proposal、default keep 和
exact-copy duel 是对这些风险的控制。

以下任一结果均证伪本机制作为下一步接受版本：

- 完整 Step Exact `<=25/50`；
- anchor-plus-proposal oracle `<30/50`，说明候选覆盖仍不足以完成 Goal；
- proposal 对 fresh-anchor-wrong 的 gold recall 未优于 v3.49 的 6 例；
- duel 的 direct gains 不高于 direct losses；
- 出现成簇的 normal-probe early false override；
- 任何 gold-free、schema/taxonomy/evidence、顺序/hash、attempt-scope 或写拓扑失败。

## 冻结哈希

- protocol：`7831d6a7da6eee65d0fea2b3372491e14f81c77730a586fa0f51a2d5c2ff3f56`
- runner：`960c8dce96854b4f2c6f27cc77c54aae2eb0b0051340b4d732d85b9fce5823cb`
- registry：`fbce9c467d08ba19620dac8d3a427e4c6a831b3a6ca7ceb11d39dfaf43300e83`
- taxonomy：`d7e4b878059bbecec0a8fd3f078c0aeb5755bf9e65bb938c897dd83685f28c5c`
- tests：`025b9b50e2ea990d5d529dc1bf660df6b62fe84d4e5381f26b73d9ab1c094e11`
- independent access auditor：`7d8a663bd14c49038b9486962e0d4dd6a80227bfd4d7bf228e1421bdd073e70e`
- semantic-parent v3.20 protocol：`3e886325bf0a4b4d4a3e770071c0a36fe81dab2bebaf5015561ca828b6c2e4f9`
- cohort：`31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- prediction manifest：`77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`

哈希冻结后不得修改上述 source、validator 或 tests。若任何哈希变化，本预注册失效，
必须创建新版本而不是修补 v3.65。

## 执行与接受顺序

1. 在不读取 gold、旧预测、metrics、scored artifacts、错误报告或 git history 的
   环境中完成 150 个成功阶段，并冻结每例所有中间 artifact。
2. 先运行 aggregate validator、gold-free freeze audit 和独立 inference
   access/write audit；全部通过后才允许评分。
3. 评分后仅用 Step Exact 与 v3.20 做 both-correct、gain、loss、both-wrong 转移。
4. 若 Step Exact `26--29/50` 且全部合法，则成为新 accepted incumbent；若
   `>=30/50` 则完成 Goal；若 `<=25/50` 或任何合法性失败则永久拒绝 v3.65。
5. 拒绝时冻结当前结果，完成全部 Step 错误的 first-divergence 审计，再从当时
   accepted incumbent 创建新的单机制版本。

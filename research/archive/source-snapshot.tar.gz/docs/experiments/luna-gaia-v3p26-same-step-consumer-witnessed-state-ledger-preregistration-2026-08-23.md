# Luna GAIA v3.26 Same-Step Consumer-Witnessed State Ledger Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.26-same-step-consumer-witnessed-state-ledger`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia.v3.25-predecessor-feedback-aligned-state-ledger`
- Semantic anchor parent: `agentdebug.codex-agent-judge.luna-gaia.v3.20-packet-state-closure`
- Frozen incumbent: v3.20, Step Exact `25/50`
- Original v3.4 baseline: Step Exact `21/50`
- Version acceptance: `Step Exact > 25/50`
- Goal completion: `Step Exact >= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Frozen v3.25 predictions SHA-256: `84ce8248303896ad3948c6094227f337f55b1cfd4e6368cf0bc90b87fd3530f3`
- v3.25 Step-error audit SHA-256: `b3a95af80c4b737292dafaf6a93116b0ba0c1ef192dd9c4e2ae6694bd22ef953`
- v3.25 cluster audit SHA-256: `cd32ae200e113a6f566b933dfd91927e90419492a060fe38ee6547867df11487`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the only optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module/type/evidence remain legality constraints only.

## Post-score diagnosis motivating this version

v3.25 completed 50/50 at `18/50`, with 150/150 successful stages and no retry.
It emitted 625 mechanically aligned state rows but no earlier candidate and no
proposal. Five errors form a High-confidence `same_step_state_handoff_gap`
cluster.

For each target, the frozen gold state row is aligned to the predecessor result
but marked clear. The current contract allows a candidate only when
`downstream_consumer_step > state_step`. GAIA canonical Steps contain ordered
Memory/Reflection followed by Planning/Action in one assistant decision, so an
incorrect retained state can be consumed immediately by a later module without
the numeric Step changing. The validator has no consumer quote or module-order
check and structurally excludes that handoff.

## Single major change

Preserve the v3.20 anchor, v3.25 predecessor source binding, three closed state
pairs, chronological row coverage, earliest-candidate derivation, one-proposal
cap, bidirectional comparison, and default-keep arbiter. Change only the state
candidate's consumer contract.

Every row now has fields:

```text
step, state_quote, source_step, source_feedback_quote,
candidate_kind, candidate_relation, consumer_step, consumer_quote, verdict
```

Rules:

1. A clear row is exactly `none/not_applicable/null/null/clear` after its source
   fields.
2. A candidate must provide a literal `consumer_quote` from Planning or Action
   at `consumer_step` that observably depends on the defective state claim.
3. `consumer_step` may equal the state Step only when that Planning/Action span
   occurs after all Memory/Reflection spans in the same raw assistant output.
4. A numerically later consumer remains legal, now with the same literal
   Planning/Action witness requirement.
5. The three exact pairs remain `necessary_fact/omitted`,
   `entity_relation/unsupported`, and `outcome_claim/contradicted`.
6. The earliest candidate row still mechanically freezes the only candidate;
   proposal ownership remains Memory/Reflection and the arbiter still defaults
   to the anchor.

No case router, entity/site rule, historical prediction, gold information,
candidate pool, global selector, result splice, or module/type optimization is
added.

## Falsifiable prediction

- All state rows retain exact predecessor binding and gain a validated consumer
  field pair.
- At least one of the five audited same-Step handoffs becomes a candidate.
- At least one such candidate is earlier than its fresh anchor and reaches the
  arbiter.
- Literal Planning/Action ownership and ordering reject Memory/Reflection,
  absent, or pre-state consumer evidence.
- Candidate admission remains narrow rather than flooding the 625-row ledger.
- Accepted proposals yield positive net Step transitions against incumbent
  v3.20, and Step Exact exceeds `25/50`.

The hypothesis is falsified if the five target rows remain clear, same-Step
admission produces broad false candidates, the arbiter never accepts a valid
proposal, legality fails, or Step Exact is `<= 25/50`.

## Gain and regression analysis

Expected gains are five post-score errors sharing exactly this structural first
divergence: three omitted/over-compressed state handoffs, one unsupported
entity-relation handoff, and one contradicted outcome/progress handoff. Their
current prediction-minus-gold average is `+2.8`.

Primary risks are six incumbent-correct state-boundary cases where a benign
compression, provisional hypothesis, or locally false but harmless statement
could appear in the same Step as a later plan. A consumer quote alone does not
admit a candidate: exact predecessor evidence, one closed defect pair, semantic
dependence, later-module order, earliest derivation, direction-specific repair,
one proposal, and default keep all remain required. These controls also bound
candidate flooding and late-symptom preference.

The modification tends to make selection earlier only when a state defect and
its first literal consumption share a Step. It does not generally privilege
Planning, the first surface candidate, or later symptoms, and is uniform across
trajectory IDs, entities, sites, source models, and Step numbers.

## Execution and acceptance protocol

1. Implement the versioned prompt, consumer quote/order validator, runner, and
   negative tests.
2. Run offline tests, prepare-only 50-case validation, and source scans only;
   do not run a smoke gate.
3. Execute all 50 frozen cases with three fresh serial sessions per case and at
   most four cases concurrently.
4. Freeze predictions and every intermediate after 50/50 completion and full
   gold-free validation.
5. Only then read labels and score the immutable predictions.
6. Compute Step Exact transitions against v3.4, incumbent v3.20, and v3.25.
7. Accept only if Step Exact is `> 25/50`; complete the Goal only at `>= 30/50`
   with all legality and freeze checks passing.
8. Otherwise reject immutably, audit every Step error, and continue from one
   new uniform mechanism.

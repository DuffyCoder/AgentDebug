# E9 v32: independent candidate selector

## Motivation

The incomplete v31 full30 prefix produced 27 valid diagnoses. Its final
critical step matched gold in 9 cases, while the union of the final,
`earlier_candidate_step`, and `alternate_candidate_step` covered 13 cases.
Four cases therefore contained the gold step in the emitted candidate set but
the same LLM call selected a different final step. The v31 case study also
records a tenth full-phase request reserved in the durable ledger whose
response was not persisted after the process interruption.

## Frozen hypothesis

Separating hypothesis generation from final selection will reduce the
same-call commitment bias observed in v31. The Critic remains an untrusted
candidate generator. A new Selector sees the complete anonymous JudgeView,
the evidence-source catalog, and the Critic bundle, then emits the sole final
semantic tuple. The Selector may accept the proposal, choose either candidate
step, or diagnose a fresh root.

The validator only checks JSON shape, taxonomy validity, step/module evidence
ownership, hashes, cache lineage, and source-ID-to-verbatim-preview
projection. It never selects, scores, ranks, repairs, or falls back to a
semantic root. A failed Selector produces an invalid case even when the
Critic candidate is valid.

## Call topology

- `dry3`: one candidate call and one Selector call; cumulative 440 → 442.
- `full30`: reuse both dry calls, then 10 candidate/Selector pairs;
  cumulative 442 → 462.
- `smoke30`: fresh Scout, Arbiter, candidate, and Selector for 11 batches;
  cumulative 462 → 506.

There is no cumulative authorization ceiling. Each phase retains only its
exact topology-derived hard stop and durable request ledger. Transport retries
are recorded separately and are not logical completions.

## Promotion gates

- dry3: at least 2/3 Step Exact, 2/3 Step+Module Exact, and no invalid case.
- full30: at least 12/30 Step Exact, 3/30 Step+Module Exact, and at most one
  invalid case.
- smoke30: at least 12/30 Step Exact, 2/30 Step+Module Exact, at least 29
  successful cases, and one fresh held-out run only.

All tuning and smoke labels remain unavailable to prediction. Confidence,
score, weight, vote, probability, and deterministic semantic findings are not
inputs to either active LLM stage.

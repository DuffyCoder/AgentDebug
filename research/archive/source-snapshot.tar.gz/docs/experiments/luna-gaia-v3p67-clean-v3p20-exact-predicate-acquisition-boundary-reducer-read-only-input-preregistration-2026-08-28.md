# Luna GAIA v3.67 预注册：exact-predicate reducer + exact read-only input

状态：执行前冻结。

## 继承、目标和唯一机制

- semantic parent：accepted Luna v3.20，Step Exact `25/50`。
- 版本：`agentdebug.codex-agent-judge.luna-gaia.v3.67-clean-v3.20-exact-predicate-acquisition-boundary-reducer-read-only-input`。
- 数据集：冻结 `gaia-paper-v1` 50 例。
- 模型/effort：`gpt-5.6-luna` / `medium`。
- 原始基线：v3.4 Step Exact `21/50`。
- 接受条件：合法完整 GAIA-50 Step Exact `>25/50`。
- Goal 完成条件：合法完整 GAIA-50 Step Exact `>=30/50`。
- 无 smoke 门控；离线验证后直接完整运行。

唯一主要语义机制仍是 v3.66 预注册的 `exact-predicate acquisition boundary
reducer`。它从 v3.20 的 fresh anchor、稀疏 ledger 和 checkpoint 出发，最多提出一个
earlier probe-veto row 或一个 later mature boundary；只有 capability、实际 exact-predicate
outcome、贡献、later relation、candidate-only repair 和 recovery gate 全部闭合时，父进程
才 exact-copy 该候选，否则 exact-copy anchor。`partial_or_reusable` 不是类别性 veto，
但也不会单独触发 promotion。

v3.67 的 semantic parent 仍是 v3.20，不是 v3.66。代码只显式移植这一项尚未完成全量
检验的单一机制；不继承 v3.21--v3.65 的 proposal、panel、census、challenger、arbiter、
whole-trajectory gate 或 selector 改动，也不读取任何历史逐例预测。

## v3.66 runtime first divergence 与本次非语义修正

v3.66 已启动完整 50 例并保持原产物不变，但在合并/评分前以
`runtime_or_validation_failure` 结束：

- 50 个 case 目录均创建；19 例完成两个阶段，31 例失败；未读 gold、未评分；
- 23 例的完整 manifest prompt 超过 CLI `1,048,576` 字符上限，46 次 attempt 均在
  turn start 前失败；
- 另有 4 例 inactive `none` 字段、3 例 evidence ownership、1 例 identity binding
  验证失败；
- 成功运行的 stdout 没有 command execution，因为输入完全嵌入 prompt。

因此 v3.66 没有产生可用于接受/拒绝语义机制的 Step Exact。v3.67 只修复运行合同：

1. 父进程从同一完整 JudgeView 确定性生成 `inference-document.json`，保留所有 Step、
   assistant raw output、module span/owner source、相邻 feedback、task 与 execution facts，
   只去掉 cumulative wrapper 的重复前缀；
2. 初始 prompt 不再嵌入大 manifest；模型只能用 read-only shell 读取或搜索当前 attempt
   中这个精确文件，禁止目录枚举、其他路径、网络、validator 和写入；
3. 模型仍通过 JSON Schema 返回 response，父进程物化 artifacts；
4. trajectory identity/status 由父进程从冻结 case 绑定，不作为语义判断；
5. `candidate_status=none` 时父进程只规范化不活跃的 null/none/not_applicable/false 字段，
   不改变候选状态或 Step；
6. fresh retry 只接收 gold-free validator error code，evidence ownership 等结构错误可按
   原 v3.20 同会话 validator-repair 意图重新生成；
7. 评分前审计要求每个成功 stage 至少一次精确输入读取，禁止 directory inventory、
   labels/scored/docs/git/network/其他路径，验证 read-only contract、同 case 输入 hash 和
   全部写拓扑。

这些是运行与合法性修正，不增加第二个 Judge 机制。若任何访问/写入审计失败，版本在
评分前终止。

## 预期 gains、regressions 与判伪

预期 gain 簇与 v3.66 相同：earlier ledger probe 的实际结果仍无法取得 active subgoal
精确谓词，而 later anchor 只重复/传播同一缺口。主要风险也不变：把能取得必要 lead
的合理 discovery probe 误判为 final-answer incapable，或把普通 negative tool result
升级为 critical root。later 分支还可能造成晚症状偏置。

最大候选数保持 1，直接 state/constraint/capability/System root anchor 受保护。若 candidate
union oracle `<30/50`、相对 v3.20 gains 不大于 losses、final `<=25/50`，或任一 50/50、
hash、schema、taxonomy、evidence、gold-free、exact-read/write-topology 验证失败，本版本
拒绝。只有 final `>=30/50` 且全部合法才完成 Goal。

## 执行前冻结哈希与离线验证

- protocol：`ef3471821d63fc4f4f976df8ed4546aab4ecd40ac27574a311a18d3ae90c7bb3`
- runner：`81c001710ced9c2ac93be735d1cfb7a82b0236daa55f841668c7b0559ce590c8`
- registry：`08622591ef4e436027bfe529e8f40a0d5ca3a0eb75b797631640e7cd3d050254`
- taxonomy：`d7e4b878059bbecec0a8fd3f078c0aeb5755bf9e65bb938c897dd83685f28c5c`
- tests：`7faf402b9c13bf12c7afe2a552b8a3b0e9fd14a822cebaa033d2c116abefea59`
- access auditor：`c7137f35c8b02eaf1e9e1063a51bb110e609478664d0c62ef04840a4f46456be`
- semantic parent v3.20：`3e886325bf0a4b4d4a3e770071c0a36fe81dab2bebaf5015561ca828b6c2e4f9`
- prediction manifest：`77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- cohort：`31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`

离线验证：v3.67/v3.66/v3.20 相关测试 `19 passed`；Python compile、registry resolve、
50-case dry plan、`100` planned sessions、direct parent、模型/effort、两阶段 prompt 均低于
CLI initial-input limit。


# E9 v58 smoke-v1 Critic-cap preflight failure case study

## Closed attempt boundary

- Experiment: `e9_v58_fresh_v30_incumbent_copy_review_smoke_v1`.
- Original preregistration hash:
  `ad4dfaaebaf7987a29f7c56ea591e1a8b0eb422c306c39adb72787ce30c84ebf`.
- Frozen topology: 11 fresh Scout calls, 11 fresh Arbiter calls, 11 v30
  Critic calls, and 11 v58 Reviewer calls (44 total).
- Durable ledger at failure: 24/44 logical completions. All 22 fresh
  upstream calls and the first Critic/Reviewer pair completed. Two unscored
  rows were persisted. No gold labels were loaded and no score was computed.
- The exception happened while constructing the second Critic request, before
  its ledger reservation and before provider transport. There was therefore no
  25th logical call, retry, or untracked provider attempt.

## Observed failure

The frozen v30 helper rejected batch 2 locally:

```text
BatchedCriticWorkflowError: v14 Critic request exceeds the frozen character cap
```

The inherited Critic limit is 800,000 serialized message characters. An
offline reconstruction from the immutable smoke manifest, batch plan, fresh
predecessor manifest, and content-addressed caches measured every Critic
request:

| Batch | Characters | Overage above 800,000 |
| --- | ---: | ---: |
| 1 | 681,977 | 0 |
| 2 | 813,797 | 13,797 |
| 3 | 866,790 | 66,790 |
| 4 | 717,305 | 0 |
| 5 | 373,290 | 0 |
| 6 | 611,259 | 0 |
| 7 | 515,670 | 0 |
| 8 | 834,365 | 34,365 |
| 9 | 545,214 | 0 |
| 10 | 509,149 | 0 |
| 11 | 261,204 | 0 |

Thus a one-off bypass for batch 2 would merely move the same failure to batch
3 and later batch 8. All eleven batches must be preflighted together.

## Attribution

The excess does not come from the newly generated Scout or Arbiter response
text. The v30 Critic validates the predecessor binding but deliberately does
not expose predecessor suggestions to its six causal lanes. Its request body
contains the anonymous heldout timelines and evidence catalogs. Three
smoke-v1 trajectory batches are simply larger than the static cap inherited
from the tuning workflow.

The smoke freeze checked artifact hashes, cache freshness, call topology,
gold isolation, and the full repository test suite, but it did not construct
all heldout Critic messages locally. Consequently this deterministic capacity
mismatch was discovered only after the 22 fresh upstream calls had already
completed. The missing heldout-wide request-size preflight is the harness
defect.

This attempt does not falsify the v58 semantic hypothesis. No second-batch v30
diagnosis or v58 review exists, and no heldout labels or partial scores were
inspected. The first completed Reviewer pair is an incomplete prefix and must
not be interpreted as a result. The Reviewer still preserves incumbent
strengths through its unchanged KEEP/strictly-earlier-REPLACE contract.

## Recovery hypothesis and invariant

A recovery may run only after its code and contract are frozen and tested. It
will reuse the exact 24-call prefix and make at most the remaining 20 calls.
It will:

1. raise only the Critic message preflight ceiling from 800,000 to 900,000;
2. preconstruct all eleven Critic messages and prove the maximum is 866,790;
3. leave every message byte, prompt protocol, provider parameter, batch, case,
   dependency, and request hash unchanged;
4. prove the already-completed batch-1 Critic request hash remains
   `50b4dde1187cf9ccf4594f299072395524c9647a6508ae53afee6ca9e58e960e`;
5. retain the original content-addressed upstream, Critic, and Reviewer
   caches and the original 44-entry durable ledger; and
6. keep gold loading after complete raw-chain validation, with all invalid
   rows in the fixed denominator.

The 900,000 ceiling is an operational guard only. It does not truncate,
summarize, reorder, repair, or otherwise alter LLM semantics. If any remaining
provider call or recovery validation fails, another case study is required
before any further external call.

# Current GAIA-50 Goal experiment ledger: v3.81--v3.102

Date: 2026-08-30

Scope: the model-sweep and post-research experiments that established accepted
incumbent v3.83 and then attempted to exceed its frozen `26/50` Step Exact.
Only a complete 50-case run that passed every gold-free, schema, taxonomy,
evidence, ordering, access, and freeze gate is assigned a formal Step Exact.

| Version | Model / effort | Main test | Completion and legality | Step Exact | Decision |
|---|---|---|---|---:|---|
| v3.81 | GPT-5.6 Sol / medium | clean v3.20 model-only swap | Original run 49/50; case 37 was later rerun separately and passed, but the two runs were not a single preregistered frozen GAIA-50 artifact | Original valid subset 25/49; separate repaired case is exact, giving a descriptive 26/50 union only | Ineligible/rejected |
| v3.82 | GPT-5.6 Terra / medium | clean v3.20 model-only swap | 50/50, all legality passed | 22/50 | Rejected |
| v3.83 | GPT-5.5 / medium | clean v3.20 model-only swap | 50/50, all legality passed | **26/50** | **Accepted incumbent** |
| v3.84 | GPT-5.4 / medium | clean v3.83 model-only swap | 50/50, all legality passed | 23/50 | Rejected |
| v3.85 | GPT-5.5 / high | reasoning-effort-only change from v3.83 | 50/50, all legality passed | 23/50 | Rejected |
| v3.86 | GPT-5.5 / medium | bounded typed-boundary challenger | 50/50, all legality passed | 24/50 | Rejected |
| v3.87 | GPT-5.5 / medium | evidence-lifecycle challenger | 50/50, all legality passed | 18/50 | Rejected |
| v3.88 | GPT-5.5 / medium | sparse influence-graph challenger | 50/50, all legality passed | 22/50 | Rejected |
| v3.89 | GPT-5.5 + Sol challenger / medium | heterogeneous challenger | 50/50, all legality passed | 26/50 | Rejected: tied, did not exceed incumbent |
| v3.90 | GPT-5.5 / medium | outcome-conditioned predicate-handoff tournament | 49/50; case 17 exceeded the local Codex context limit | Not scored | Runtime-incomplete |
| v3.91 | GPT-5.5 / medium | same tournament, staged file inspection | 37/50; 13 singleton-ledger contract failures | Not scored | Runtime/validation-incomplete |
| v3.92 | GPT-5.5 / medium | singleton-safe file inspection | 50/50 semantic outputs, but all inspector reads failed under bwrap | Not scored | Access-invalid |
| v3.93 | GPT-5.5 / medium | audited no-bwrap transport | 50/50; 40 illegal commands in 35 stages and incomplete coverage | Not scored | Access-invalid |
| v3.94 | GPT-5.5 / medium | response-only transport contract | Stopped after the first four anchor stages deterministically failed prompt-marker construction | Not scored | Runtime-incomplete |
| v3.95 | GPT-5.5 / medium | dual-stage response-only contract | 12/50 final predictions; redundant wrapper and singleton access-contract mismatches | Not scored | Runtime-incomplete |
| v3.96 | GPT-5.5 / medium | normalized access audit | 50/50; unavailable `python`, wrapper-parser, and incomplete-command failures | Not scored | Access-invalid |
| v3.97 | GPT-5.5 / medium | Python-3 bounded access | 50/50; nine failed/incomplete reads and reducer audit overreach | Not scored | Access-invalid |
| v3.98 | GPT-5.5 / medium | stage-bounded access | 50/50; four fatal command/access events | Not scored | Access-invalid |
| v3.99 | GPT-5.5 / medium | CWD-robust attempt-bound inspection | 50/50; six reducers abbreviated the absolute inspector path | Not scored | Access-invalid |
| v3.100 | GPT-5.5 / medium | short attempt-bound inspector path | 50/50; two invalid owner commands and two task-only reducers | Not scored | Access-invalid |
| v3.101 | GPT-5.5 / medium | stage-local access validation and retry | 48/50; cases 15 and 25 exhausted the two-attempt cap | Not scored | Runtime-incomplete |
| v3.102 | GPT-5.5 / medium | same tournament with a third uniform fresh attempt | 50/50; all gold-free/access/schema/taxonomy/evidence/freeze gates passed | **21/50** | Rejected |

## Formal scored-run ranking

1. v3.83: `26/50` (accepted incumbent).
2. v3.89: `26/50` (tie, rejected by strict-improvement rule).
3. v3.86: `24/50`.
4. v3.84 and v3.85: `23/50` each.
5. v3.82 and v3.88: `22/50` each.
6. v3.102: `21/50`.
7. v3.87: `18/50`.

v3.81's `25/49` plus one exact separate repair is descriptive only and is not
ranked as a formal full-run result.

## v3.102 versus accepted v3.83

- Both correct: 13 cases.
- v3.83 wrong / v3.102 correct: 8 gains.
- v3.83 correct / v3.102 wrong: 13 regressions.
- Both wrong: 16 cases.
- Net Step change: `8 - 13 = -5`, hence `26/50 -> 21/50`.

The tournament therefore falsified the hypothesis that a global
outcome-conditioned predicate-handoff comparison over every native v3.83
ledger Step would improve Step Exact. The dominant practical problem was not
candidate reach alone: the selector did find eight new exact boundaries, but
its overrides destroyed thirteen incumbent-correct boundaries. v3.83 remains
the semantic parent for the next experiment, and none of v3.90--v3.102's
tournament selection semantics may accumulate into it.


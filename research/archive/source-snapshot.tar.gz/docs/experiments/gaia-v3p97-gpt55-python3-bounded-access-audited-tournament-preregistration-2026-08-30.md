# GAIA v3.97 GPT-5.5 Python-3 bounded-access tournament preregistration

Date: 2026-08-30

## Frozen identity

- Version: `agentdebug.codex-agent-judge.gaia-v3.97-gpt55-python3-bounded-access-audited-predicate-handoff-tournament`.
- Direct semantic parent: accepted v3.83, Step Exact `26/50`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Dataset manifest identity SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort identity SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Cohort manifest file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Frozen v3.83 protocol SHA-256: `a97908a78cec8df5fe9e4777d30aa9ecf498d1cdd1d692a42cc66976e9844531`.
- Frozen v3.83 predictions SHA-256: `f74161b06c456461ccacdcf7c708157154e8e9810cb5dffa8ef09352698fca3d`.
- Model/reasoning effort: `gpt-5.5` / `medium` for both stages.

## Single semantic mechanism

Relative to accepted v3.83, the only semantic change remains one
outcome-conditioned predicate-handoff tournament over every native Step in the
fresh v3.83 ledger, replacing the incumbent challenger/arbiter. Anchor semantics,
ledger admission, model, effort, evidence ownership, taxonomy legality, singleton
forced keep, and exact-copy final freeze remain the accepted-parent behavior plus
the contracts necessary to express this single tournament. No rejected prediction
or per-case routing information is available to inference.

The hypothesis remains: a complete global comparison of native prefixes by the
first observable unresolved exact-predicate handoff will recover incumbent-error
boundaries that the conservative challenger omitted without regressing more
incumbent-correct Steps than it gains.

## Runtime-only correction

v3.96 completed 50/50 but failed its pre-score access audit. Its prompt named a
nonexistent `python` executable; 159+ attempted leaves failed before models
repaired to the installed `python3`. Its parser then rejected successful
`python3`/`/usr/bin/python3` commands and transport-generated `-c` wrapper
variants. Two unbounded whole-Step reads over very large observations never
recorded completion.

v3.97 uniformly changes the advertised leaf to `python3`, removes whole-Step
inspection from the advertised and allowlisted interface, and retains bounded
task/timeline/owner/feedback reads. The audit strips at most two strictly parsed
transport wrappers from a fixed shell/option allowlist, then requires exactly
`python3` or `/usr/bin/python3`, `inspect_case.py`, and one allowlisted argument
form. Every failed/incomplete command, chain, mutation, redirect, general Python,
extra tool, missing coverage, or third wrapper remains fatal. Zero commands remain
legal only for a validator-proven singleton reducer with structural keep-anchor.
These corrections cannot rank or change a Step.

## Gains and regression risks

- Expected gains: incumbent errors whose gold boundary is already in the fresh
  native ledger but absent from the conservative challenger proposal.
- Expected regressions: early acquisition/probe promotion and global early bias.
- Candidate flood: no new Step is added; exactly one existing ledger Step wins.
- Direct counterexample: informative probe followed by independent effective
  repair must not be promoted merely because its immediate outcome was incomplete.
- No ID/entity/source/model-specific selection rule is present.

## Decision rules

- No smoke gate; full GAIA-50 follows offline validation.
- Freeze all 50 predictions and intermediate/access/legal audits before labels.
- Reject on any incomplete case, failed legality gate, or Step Exact `<=26/50`.
- Accept only if Step Exact `>26/50`; complete Goal only at `>=30/50`.
- Step Exact is the sole selection metric.

## Pre-inference source freeze

- Protocol SHA-256: `be41c23ff22702b2e77eebffee1b1fc2b5fba950ecf386972ab459c571da021b`.
- Runner SHA-256: `11334110bd73fa5f82524e3724c62b4929232c72c780f80a13c9cab5010b3657`.
- Inspector SHA-256: `556e8fe1e77186a55521f74734b05d35a33fe482a50d30b5bc21ce7ef02f7677`.
- Targeted test SHA-256: `647ddad2f646e02f4afc50f0c2f86bfe4cd1a2f6822f7c534dd8c4cd2b372ad5`.
- Registry SHA-256: `ab85b18ae8905648d44afc8196e056f8be58f47543437fd7dac6a34868a93e5c`.
- Offline validation: compilation passed; 38 targeted and inherited tests passed,
  including direct parent, threshold, both real task builders, Python-3 leaf,
  wrapper variants, whole-Step/chaining/mutation rejection, singleton scope,
  compatibility aliases, registry, and static gold/router scans.

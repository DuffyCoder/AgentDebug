# GAIA v3.98 GPT-5.5 stage-bounded access tournament runtime result

Date: 2026-08-30

## Decision

v3.98 completed all 50 cases and 100 semantic stages, but failed the mandatory
gold-free access audit before scoring. It is frozen, unscored, and rejected as a
runnable experiment. No label or gold artifact was read.

## Frozen facts

- Semantic parent: accepted v3.83 (`26/50`).
- Model/reasoning effort: `gpt-5.5` / `medium` in both stages.
- Completion: `50/50` cases, `100/100` successful stages, `101` attempts, zero failed cases.
- Successful commands: task `96`, timeline `236`, owner `614`, feedback `223`, feedback-chunk `30`.
- Invalid commands: `2`; failed/incomplete commands: `2`.
- Missing anchor or native-ledger candidate coverage: `0`.
- Runtime-contract failures: `0`.
- Structural zero-command singleton reducer keeps: cases 4, 21, 23, 37.

## First divergence

The first divergence remains `runtime_or_validation_failure`:

1. Reducer case 25 and anchor case 41 requested `feedback-chunk ... 0` although
   the inspector implemented only one-based chunks. Both later repaired to
   chunk 1, but the initial failed calls are correctly fatal.
2. Anchor case 46 emitted a 4,000-character raw chunk containing many JSON-
   escaped control bytes. Its encoded command output became much larger than
   the raw bound and never recorded completion.
3. Reducer case 47 began in the correct attempt directory, but a later inspector
   call executed from `/home/shujie.ge`; the relative `inspect_case.py` path
   therefore failed with exit code 2.

The v3.97 failures from reducer full-timeline overreach, valid final-page
clamping, and unchunked large feedback were fixed: required coverage was
complete and cases 3, 11, 28, 37, 43, and 46 all produced complete semantic
artifacts. v3.98 still cannot be scored because any access failure is fatal.

## Minimal next correction

Create v3.99 from accepted v3.83 with the same single tournament mechanism.
Bind each advertised inspector command to that attempt's absolute inspector
path and resolve the staged document relative to the inspector file, so process
CWD cannot redirect the read. Keep one-based chunks but accept `0` as a
deterministic alias for the first chunk. Bound chunks by JSON-encoded output
cost, not raw character count, and expose bounded exact printable runs so binary
feedback need not be exhaustively paged. These changes cannot rank a Step.

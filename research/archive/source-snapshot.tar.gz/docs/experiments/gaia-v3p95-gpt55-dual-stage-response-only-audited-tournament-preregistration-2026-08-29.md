# GAIA v3.95 GPT-5.5 dual-stage response-only audited tournament preregistration

Date: 2026-08-29

## Frozen identity

- Version: `agentdebug.codex-agent-judge.gaia-v3.95-gpt55-dual-stage-response-only-audited-predicate-handoff-tournament`.
- Direct semantic parent: accepted v3.83, Step Exact `26/50`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Dataset manifest identity SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort identity SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Cohort manifest file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Frozen v3.83 protocol SHA-256: `a97908a78cec8df5fe9e4777d30aa9ecf498d1cdd1d692a42cc66976e9844531`.
- Frozen v3.83 predictions SHA-256: `f74161b06c456461ccacdcf7c708157154e8e9810cb5dffa8ef09352698fca3d`.
- Model and reasoning effort: `gpt-5.5` / `medium` for both stages.

## Prior evidence and first divergence

v3.93 proved that no-bwrap transport restores actual JudgeView inspection but
failed the exact-command access gate because semantic “write/freeze” language
caused file I/O and some inspector calls were chained. v3.94 added the intended
literal response-only contract, but the injection function recognized only the
anchor prompt marker. The first four completed anchor stages then failed before
reducer inference with the same deterministic `response-only contract marker
changed unexpectedly` error. The run was stopped, preserved, and unscored.

The first divergence is `runtime_or_validation_failure`: anchor and reducer
tasks use different stable topology markers.

## One mechanism and one runtime correction

Relative to accepted v3.83, the only semantic mechanism remains one
outcome-conditioned predicate-handoff tournament over every native v3.83 ledger
Step, replacing the incumbent challenger/arbiter tail. Anchor semantics, native
ledger construction, model, effort, singleton forced-keep, same-Step legality,
and exact-copy freeze are unchanged.

The sole v3.95 correction is to inject the identical response-only/no-file-I/O,
one-command-at-a-time contract through the anchor's `THE ONLY DECISION ORDER`
marker and the reducer's `BOUNDED TOURNAMENT` marker. An offline test constructs
both real tasks and requires exactly one contract in each. This correction is
uniform and has no direct Step selection capacity.

The gold-free access gate remains unchanged: reject any extra/chained command,
file mutation, web/MCP call, nonzero or incomplete command event, missing task
inspection, incomplete timeline coverage, invalid runtime contract, case router,
or prior-prediction access.

## Impact analysis

The runtime fix should make the one tournament mechanism measurable. Once
measurable, expected gains remain limited to incumbent errors whose needed
boundary is present in the native prefix ledger. The main regression risk is a
systematic early shift from overpromoting reasonable acquisition probes; long
ledger candidate flooding and preview-only comparison are secondary risks.

Reject if Step Exact is `<=26/50`, if any case is incomplete, or if any legality
or access audit fails. Complete the Goal only at Step Exact `>=30/50` with all
50 cases and validations passing. Only Step Exact selects versions; no smoke
gate is used.

## Pre-inference freeze

- Protocol source SHA-256: `eef0739876161046a41c64cdbae0ccf656b8027374aa5b5e896dd302f28b02c5`.
- Runner source SHA-256: `36649791fec0fd32c636c7abc788ae3f4a92380ca0c06bd822d5006dcbc11ab1`.
- Inspector source SHA-256: `556e8fe1e77186a55521f74734b05d35a33fe482a50d30b5bc21ce7ef02f7677`.
- Negative/identity test source SHA-256: `06b63a8af7a7148b3a43290ef6949bca844ac8a76b0aac2e47a48400077f8094`.
- Offline validation: compilation passed; 32 targeted and inherited tests
  passed; both real task builders, single injection per stage, direct-parent
  identity, no-bwrap command, compatibility aliases, registry, and 50-case dry
  preparation passed.
- Static inference-source scan found no labels, metrics, scored artifacts,
  historical predictions, trajectory/entity router, or post-score audit reader.


# GAIA v3.93 runtime result

Date: 2026-08-29

v3.93 completed `50/50` cases and `100/100` semantic stages with two
validator retries. No-bwrap transport successfully restored real JudgeView
inspection, including the previously context-blocked longest case. The version
is nevertheless **runtime-invalid and unscored** because the preregistered
gold-free access gate failed before any label read.

The full event audit found 40 illegal commands in 35 stages: 31 real
ledger/checkpoint file-write commands and nine chained inspector commands.
Seven inspector events lacked a completed exit-zero record, and 27 stages did
not establish the required independent task plus complete timeline coverage.
There were no runtime-contract structure failures.

The first divergence is `runtime_or_validation_failure`. The prompt used
semantic process language such as “write the ledger” and “write the immutable
checkpoint.” With the bwrap sandbox disabled, GPT-5.5 sometimes interpreted
those phrases as real filesystem work; it also combined read-only inspector
calls with `&&` to reduce calls. Both violate the exact-command transport
contract even when the returned JSON passes semantic validators.

The minimal next correction is uniform and Step-invariant: define all
ledger/checkpoint “writing” as construction of fields in the one final response
JSON, explicitly prohibit file creation/modification, heredocs, redirects,
general Python and command chaining, and require each exact inspector command
to finish with exit code zero before the next call or final response. The Judge
selection mechanism remains unchanged.


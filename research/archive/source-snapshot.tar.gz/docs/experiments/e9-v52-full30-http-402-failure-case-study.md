# E9 v52 full30 HTTP 402 failure case study

## Attempt boundary

- Experiment: `e9_v52_module_census_deepseek_v4_flash_default_body`
- Pipeline: `e9-module-census-v52-deepseek-v4-flash-default`
- Full30 preregistration content hash:
  `6da603bbdd0caab45bcfa44801cee80922b173275b6f2515e5f5892627f9a007`
- Frozen code bundle content hash:
  `d1a0cc24d525f21f3d1b4481ce472c7517c22b80a01abc62b9f7f214aba618a4`
- Provider/model: DeepSeek OpenAI-compatible / `deepseek-v4-flash`
- Request mode: default body, temperature 0, one worker, 600-second timeout,
  8,192 maximum output tokens, five configured transport retries.
- The accepted dry3 batch was reused from cache. It had 3/3 valid rows and
  2/3 Step, Step+Module, and All Correct.

The full30 process completed batches 1 through 7 with 18 successful rows. In
batch 8 (`B264a53a2d3d40ffd4a50`), both the Critic and Selector endpoints
returned HTTP 402. All three rows in that batch were persisted as
`http_error`. The post-batch failure boundary then stopped the run before any
batch-9 LLM request.

## Durable usage and artifacts

- Full30 logical reservations used: 14/20.
- Full30 stages represented by those reservations: seven Critic requests and
  seven Selector requests for batches 2 through 8.
- Current cumulative logical count: 632 (616 before v52, two accepted-dry
  reservations, and fourteen full30 reservations).
- Full30 partial rows: 21 total; 18 `success`, 3 `http_error`.
- Across the complete v52 cache: 16 logical calls, 16 HTTP attempts, zero
  retries, 14 provider responses, and two HTTP failures.
- Successful v52 provider usage: 2,451,715 input tokens, 273,040 output
  tokens, 2,724,755 total tokens. HTTP 402 responses reported no provider token
  usage.
- Full30 ledger content hash:
  `b494e1ad270ebbd337a7984aecad5411e619f7235e0cd2b68c5352b9e4929171`.
- Full30 files at the failure boundary:
  - preregistration file SHA-256:
    `8f12f3b959239444cf9d3edc4013f1630deab9b62e59caac8824542fa92944e7`
  - ledger file SHA-256:
    `1e90257358f56f4cacf58b2f91e2127540419ddc911c883596dcc645955dfa78`
  - partial predictions file SHA-256:
    `cec338c1f339312137dc12d49ce78b42ca9c4fd118b2cabf27463184e5b367c5`
- v52 tuning cache state at the boundary: 48 files, combined state hash
  `4d72b1c03c6ed9acafe9b6e8c3e669b56d2735ee0e139d9041216022b9df7677`.
- No `predict-run.json`, scored predictions, metrics, or promotion decision was
  written for this incomplete full30 attempt.

## Failure localization

This is a provider-authorization/payment-class failure, not a semantic or JSON
failure:

1. The two failed raw records have `raw_response: null` and the exact failure
   message `The judge endpoint returned HTTP 402.` There is no LLM text to
   parse, repair, or semantically validate.
2. Critic request `bd955f02...` and Selector request `cbecfff3...` each made
   exactly one HTTP attempt and received no usage response. HTTP 402 is
   non-retryable under the frozen transport policy, so the configured retry
   loop correctly made zero retries.
3. The immediately preceding six paid full30 batches, plus the accepted dry
   batch, returned 14 valid `finish_reason=stop` responses with the same key,
   endpoint, model, request body mode, timeout, and parser.
4. The failing request sizes (611,339 Critic characters and 616,104 Selector
   characters) were below their frozen 800,000 and 900,000 local caps. No local
   preflight rejected either request.
5. Both different stages received the same HTTP status within one batch. This
   makes a stage-specific prompt or output-format defect implausible.

The sanitized client intentionally does not persist the provider response
body, so the exact provider-side billing state cannot be proven from local
artifacts alone. The defensible attribution is therefore: the provider
rejected authorization at the HTTP 402/payment-required class boundary,
consistent with exhausted account credit or an equivalent provider-side
billing restriction. It is not evidence against the v52 module-census
hypothesis.

## Why the workflow made two failed calls in one batch

The workflow isolates the two semantic stages. A Critic failure does not
deterministically choose a root or abort inside the batch: the raw Selector is
still allowed to make a fresh diagnosis from the complete trace plus the
remaining frozen LLM hypotheses. Therefore batch 8 reserved and attempted its
Selector after the Critic HTTP failure. The mandatory boundary is evaluated
after all rows for that batch are persisted; it then prevented batch 9. This
preserves the rule that final semantics can only come from the raw Selector,
while still stopping before another batch after a failure.

## Root cause and next falsifiable hypothesis

Root cause: external provider billing/authorization availability changed after
14 successful v52 responses. No prompt, parser, candidate, Selector, or
request-cap change is justified by this failure.

Next hypothesis: once the configured DeepSeek credential again accepts a
minimal default-body `deepseek-v4-flash` request, the exact frozen v52 semantic
pipeline can continue without semantic modification. Before any benchmark
recovery, perform one small provider-health probe. If it still returns HTTP
402, stop and request restored credit or a credential with capacity. If it
succeeds, create a hash-bound recovery phase that:

1. preserves all successful v52 raw responses and final semantic fields;
2. binds this incomplete attempt and its 14 reservations;
3. never treats the cached HTTP failures as semantic evidence;
4. grants only the exact remaining topology needed to re-execute batch 8 and
   finish batches 9 through 11; and
5. applies the original full30 promotion gate before any held-out smoke run.

## Provider-health probe result

After completing the attribution above, one minimal non-benchmark health probe
was sent to the same endpoint and model with the default request body:
`messages=[{"role":"user","content":"Reply OK."}]` and
`model="deepseek-v4-flash"`. Response content was discarded and credentials
were not printed or persisted in experiment artifacts. The endpoint returned
HTTP 402 immediately.

This falsifies immediate recovery with the current provider state and confirms
that even a tiny request is blocked independently of trajectory length or
prompt structure. No further provider or benchmark call is authorized by this
case study until the account regains capacity or a working credential is
supplied. Local construction and testing of the hash-bound recovery boundary
may continue without external calls.

## Recovery-preparation test failure and correction

The first local recovery test failed before any provider call for two
independent bookkeeping reasons:

1. the recovery script checked abbreviated ledger field names
   (`cumulative_before` and `maximum_new`) while the durable ledger schema uses
   `cumulative_logical_completions_before` and
   `maximum_new_logical_completions`; and
2. the cache-state hash originally transcribed above was incorrect. All 48
   cache files have modification times earlier than this case study, their
   stage/request identities and raw/sidecar/parsed consistency validate, and
   the directory-state function deterministically returns the corrected
   `4d72b1...` value. This was a case-study recording error, not a mutation by
   the recovery importer.

The next hypothesis is directly testable: use the schema-exact ledger fields,
bind the corrected immutable 48-file state, then rerun the cache-only recovery
tests. No LLM call is authorized by this correction.

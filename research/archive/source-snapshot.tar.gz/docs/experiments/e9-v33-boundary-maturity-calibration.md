# E9 v33: boundary and maturity calibration

## Scope

v33 preserves v32's Candidate then independent Selector architecture. The
Selector's raw response remains the sole source of the final step, taxonomy,
evidence source, and root-cause text. There are no deterministic findings,
semantic scores, confidence values, votes, weights, or fallback labels.

## Failure-driven change

The rejected v32 dry3 run scored 1/3. Its two errors exposed opposite forms of
premature localization:

- ALFWorld: the Selector replaced a valid terminal `system/step_limit` root
  even though the next cabinet was an admissible, previously unvisited state.
- WebShop: both stages treated the first list-page acquisition as an
  inefficient plan before repeated coverage and contemporaneous no-progress
  evidence made the strategy's failure observable.

v33 changes only semantic instructions in the Candidate and Selector prompts:

1. A novel admissible cabinet, page, location, or state remains meaningful
   coverage. Agent-authored pessimism and one alternate probe do not rebut a
   valid system boundary.
2. List pagination or acquisition is not erroneous merely because detail
   fields are absent. `planning/inefficient_plan` requires the first mature
   ineffective recommitment after repeated coverage, contemporaneous
   stagnation, and failure to change strategy.

These are qualitative LLM judgment criteria, not programmatic rules that
move, score, repair, or override a prediction.

## Frozen evaluation topology

- `dry3`: one frozen-v13 batch, Candidate + Selector, exactly 2 misses,
  cumulative 442 to 444.
- `full30`: eleven frozen-v13 batches, Candidate + Selector, exactly 20 new
  misses because dry's first two entries are reused, cumulative 444 to 464.
- `smoke30`: fresh Scout + Arbiter + Candidate + Selector over eleven batches,
  exactly 44 misses, cumulative 464 to 508.

Promotion remains gated by dry3, then tuning full30, then the one-shot held-out
smoke30. A failed phase requires a written case study before another LLM run.

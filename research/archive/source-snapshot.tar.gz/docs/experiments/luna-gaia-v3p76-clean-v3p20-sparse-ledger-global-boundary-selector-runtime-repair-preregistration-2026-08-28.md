# Luna GAIA v3.76 pre-registration

## Frozen identity

- Protocol: `agentdebug.codex-agent-judge.luna-gaia.v3.76-clean-v3.20-sparse-ledger-global-boundary-selector-runtime-repair`
- Semantic parent: accepted incumbent `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Incumbent Step Exact: `25/50`
- Original v3.4 baseline Step Exact: `21/50`
- Dataset: frozen `gaia-paper-v1`, 50 cases
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Acceptance: legal full-50 Step Exact `>25/50`
- Goal completion: legal full-50 Step Exact `>=30/50`
- Smoke gate: none

v3.75 completed 50/50 inference cases and 100/100 semantic stages, with no failed cases and a passing gold-free access/write audit, but failed before freeze and before scoring because its inherited freeze helper requested the obsolete `factorized_specialist_panel` validator key. It remains frozen and unscored. v3.76 does not continue or score those predictions.

## One semantic mechanism

The only Step-selection mechanism relative to v3.20 is the same cleanly migrated mechanism pre-registered for v3.75:

> Review every Step in the fresh v3.20 sparse ledger, optionally add at most one backward-traced later Step, and let one structured global selector freeze the earliest material critical boundary.

The prompt, candidate contract, selector fields, Step normalization constraints, model, and reasoning effort are byte-equivalent to v3.75 after version-name normalization. The only runtime repair is to build the pre-score freeze from `validation_audit.sparse_ledger_global_selector` instead of the unrelated v3.37 `factorized_specialist_panel` key. This is not an additional semantic mechanism.

The version is still a direct semantic child of v3.20. No rejected challenger, reducer, maturity gate, lane veto, multi-agent panel, or exact-predicate mechanism is inherited. Response-only owner-explicit input and same-Step payload materialization are legality scaffolding and cannot change the model-selected Step.

## Falsifiable hypothesis and risk

Post-score v3.74 evidence showed fresh v3.20 sparse-ledger gold coverage of `31/50`, while its final anchor+reducer oracle was only `21/50`; 11 fresh-anchor-wrong cases had the gold Step in the ledger, all earlier than the anchor. The hypothesis is that global comparative review can recover a useful subset of this existing recall without widening to an unbounded paper-style inventory.

Expected gains are fresh-anchor-wrong cases where a supplied earlier ledger Step is the first unrecovered path-changing defect, plus rare cases where one later slot represents the first mature boundary. The principal regression risk is a false prefix override of an incumbent-correct anchor, especially when an earlier ledger row is a reasonable probe, recovered defect, faithful propagation, or noncritical predecessor. The keep-anchor default, exact review of every supplied Step, one-later cap, and literal chronology/falsifier requirements are the uniform controls. The mechanism may still fail by keeping an incorrect anchor or by preferring a vivid later symptom.

All gains, regressions, acceptance, and rejection will be computed only against frozen v3.20. Step+Module, All Correct, module/type distributions, and v3.75's unscored outputs cannot affect selection.

## Frozen inputs and sources

- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort membership SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Semantic prediction-manifest SHA-256: `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`
- Protocol SHA-256: `3b32e4cd97dbb302aadabe0ca588c3cd72e34512fc4376407e1b08b244e926df`
- Runner SHA-256: `95b15a1f546da5e1c554ce6e18c7b656dc34a7f9a7e537b2756e985fff93127a`
- Access auditor SHA-256: `34eece1e093d4347d3a0e580cb185372294cbdc1878da4c77357235c7d257392`
- Registry SHA-256: `a0de5119abfd0bd3a8742f3a79736f75cef3f455e1e4df726e39cf2b3e2ceaa1`
- Targeted tests SHA-256: `cd3909dcea08d106bacaadfebd17fa2bdfdb790c72dbfac6d95310a062760f60`
- Prepared case inputs: exactly 50 under `output/gaia-paper-v3p76-case-inputs`

These inference sources are frozen at execution. Any subsequent source change invalidates v3.76 and requires a newly versioned direct-incumbent experiment.

## Execution and decision contract

1. Complete offline syntax, registry, protocol, negative-validator, access-auditor, and freeze-contract tests.
2. Do not run smoke or inspect gold.
3. Run all 50 cases from fresh v3.76 case directories; do not import any v3.75 prediction or intermediate artifact.
4. Require 50/50 completed cases, 100 successful semantic stages, schema/taxonomy/evidence validation, access/write audit, no routing, no prior predictions, and a complete gold-free freeze.
5. Score only after freeze. Compute exact Step transitions relative to v3.20.
6. Accept as the new incumbent only if Step Exact is greater than `25/50`; complete the Goal only at `>=30/50`.
7. If Step Exact is at most `25/50`, reject v3.76 unchanged, produce the full first-divergence audit, and branch the next semantic version from v3.20.

# E9 v58 smoke cap-recovery import-test failure case study

## Failure

The first targeted pytest collection failed with
`ModuleNotFoundError: run_e9_v56_incumbent_review`. No test body, API client, or
provider call ran, and the interrupted smoke artifacts remained unchanged.

## Attribution

The frozen smoke harness is a command-line script and imports its sibling
runner by a top-level module name. Importing the recovery through the
`scripts` namespace does not automatically place the physical `scripts/`
directory on `sys.path`, so importing the unchanged frozen harness failed.

## Correction

The recovery wrapper, not the frozen smoke harness, will add its own directory
to the module search path before importing both historical runners. This
preserves the frozen source bytes and makes direct execution and pytest import
resolve the same modules.

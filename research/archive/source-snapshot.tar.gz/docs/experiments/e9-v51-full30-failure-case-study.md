# E9 v51 full30 semantic failure case study

## Closed attempt

- Experiment: `e9_v51_whitespace_brace_deepseek_v4_flash_default_body`
- Preregistration content hash: `a362e2e51d5ce6dd4252880187dbe1a9f9bc50cd7cc7dfa477901da55977a433`
- Predict-run content hash: `cdbc27b38e33153c1024bdd62cddcd88da50617c18f31853bbc389008edc96ed`
- Promotion content hash: `ef85807f10eb7c0313e466a8117fd9559239ecb8d568b622f4ec5231299b93d5`
- Output validity: 30/30 raw Selector predictions succeeded; semantic mutation count zero.
- Provider use: 20 logical completions, 20 HTTP attempts, zero retries; 3,675,402 input, 504,571 output, and 4,179,973 total tokens.
- Result: Step Exact 7/30 (23.3%), Step+Module Exact 3/30, All Correct 3/25. Only the preregistered 12/30 Step Exact gate failed; every structural, budget, raw-final, gold-isolation, and other semantic minimum check passed.
- Cumulative logical completions after the attempt: 616.

This is a complete rejected full30 result. It must not be promoted to held-out
smoke. v51 successfully fixed both operational blockers: all 11 batches,
including the former 802,251-character batch 9, completed; all final Selector
responses parsed as strict JSON. The provider did not reproduce v50's missing
final brace in this run, so no syntax repair was applied to a final result.

One batch-3 Critic response ended with `finish_reason=length` and was stored as
`output_truncated`. The final Selector still returned three valid cases using
the frozen prior and Scout candidates, so this did not create invalid final
rows. It does, however, reinforce the need for a more concise candidate pass.

## Quantitative attribution

The dominant failure is candidate recall and temporal bias, not output format:

- Only 12/30 cases had any supplied hypothesis at the official step.
- Only 7/30 had a supplied hypothesis at the official step and module.
- Only 4/25 scorable cases had the exact official step/module/type tuple among
  supplied hypotheses.
- The Selector chose `fresh` in 12 cases, but only one of those fresh diagnoses
  had the official step.
- Among the 23 Step misses, 18 were later than the official step and only five
  were earlier. The mean signed error was +9.0 steps.
- By environment, Step Exact was ALFWorld 3/10, GAIA 4/10, and WebShop 0/10.
- All six official `planning/inefficient_plan` cases missed their step.

The current six Critic lanes are organized around competing global causal
theories (`terminal_guard`, `first_defect`, `branch_commitment`, summary loss,
cross-module consistency, and plan/action handoff). They often emit several
late planning/action candidates while emitting no candidate for a local
memory or reflection defect. The Selector then cannot reliably recover a
missing early module-level error from a very long trace.

The Selector compounds this recall problem with a stricter standard than the
original repository. It repeatedly requires a one-output counterfactual to
*independently prevent* the observed failure and treats an unknown redirected
search outcome as insufficient. The original AgentDebug Phase 2 asks whether
fixing the error would *likely* and fundamentally redirect the trajectory
toward success. The stronger v51 wording discounts early causal contributors
and favors a later conspicuous commitment. The +9-step mean bias and 18/23
late misses are the observed consequence.

## Representative cases

### Module ownership is absent even when the step is found

For `GPT-4o_043_alfworld_task_043`, the official root is step 6 reflection:
the reflection accepts a pot as equivalent to the required kettle. v51 finds
step 6 but assigns planning/constraint_ignorance. Its candidate set contains
step-6 planning and action hypotheses, but no reflection hypothesis at any
matching owner. The Selector cannot select the official module from the
supplied census and adopts the downstream plan.

For `Llama3.3-70B-Turbo_012_memory_b001_t00_e03-21a3a421`, the official root
is step 4 reflection/outcome_misinterpretation. The only step-4 candidate is
system/tool_execution_error, so the same environment response is attributed
to the system instead of to the agent's interpretation.

### Correct candidate is exposed but a later error wins

For `Llama3.3-70B-Turbo_007_memory_b000_t00_e08-f572f2ad`, candidate H01 is
the exact official step-1 action/parameter_error. The Selector rejects it and
chooses step 13 reflection/outcome_misinterpretation. This is the clearest
Selector-only failure: the correct raw LLM candidate exists, but the
guaranteed-prevention test prefers a later, more observable consequence.

### Repeated-search localization is systematically late

The official step for `GPT-4o_008_chat_b000_t00_e07-d50ae81f` is step 13
planning/inefficient_plan; v51 selects step 16 of the same module and type.
For `GPT-4o_011_chat_b000_t00_e10-69d80a84`, official step 21 becomes step 16.
Across WebShop, v51 obtains 0/10 Step Exact and frequently selects a late
pagination or query-repetition checkpoint. The mature-epoch policy is not
anchored to the first module output that makes a known-no-progress decision.

## Next falsifiable hypothesis: v52 module census

v52 will return to the original repository's two-phase logic without adding
deterministic findings, scores, confidence, weights, votes, or fallback:

1. Replace the six global-theory Critic lanes with six independent raw-LLM
   census lanes: `memory_local`, `reflection_local`, `planning_local`,
   `action_local`, `system_local`, and `global_critical`. Each module lane must
   emit the earliest clear local taxonomy error owned by that module, or null.
   Step 1 memory/reflection remains invalid. The global lane separately emits
   the earliest error that most likely caused the later failure cascade.
2. Make every lane concise (at most 320 characters of local basis). This keeps
   the same six-hypothesis ceiling while reducing the observed Critic
   truncation risk.
3. Change the Selector's global test from “correction independently guarantees
   prevention” to the original AgentDebug standard: correction would likely
   and fundamentally redirect the trajectory toward success. A clear earlier
   module error may own a causal cascade even when the unobserved alternative
   outcome cannot be proven successful. Early steps 1--3 remain normal unless
   the defect is explicit and fundamental.
4. For repeated search, select the first plan/reflection that reuses known
   failed coverage, contradicts retained state, or explicitly continues after
   recognized no progress. Do not wait for a later mature repetition merely
   because it is more conspicuous.

The raw Selector remains the sole source of final step/module/type and may
reject every candidate. Evidence validation remains strict and projects only
verbatim source-owned quotes. v52 starts at cumulative 616: dry3 uses two calls
to hard stop 618; an accepted dry may authorize full30 with twenty calls to
hard stop 638. Any failure again requires a completed case study before
another LLM call.

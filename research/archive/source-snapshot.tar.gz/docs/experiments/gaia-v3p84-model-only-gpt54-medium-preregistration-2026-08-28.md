# GAIA v3.84 model-only GPT-5.4/medium preregistration

Date: 2026-08-28

## Frozen identity

- Version: `agentdebug.codex-agent-judge.gaia-v3.84-model-only-gpt54-medium`.
- Direct semantic parent: accepted GPT-5.5 v3.83, Step Exact `26/50`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Cohort SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Prediction manifest SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Frozen v3.83 protocol source SHA-256: `a97908a78cec8df5fe9e4777d30aa9ecf498d1cdd1d692a42cc66976e9844531`.
- Frozen v3.83 runner source SHA-256: `a1613a04ad21b3306c61cd3082753ff5890ad09ab3d939f4c292c15e1dac483d`.
- Frozen v3.83 predictions SHA-256: `f74161b06c456461ccacdcf7c708157154e8e9810cb5dffa8ef09352698fca3d`.
- Model: `gpt-5.4`.
- Reasoning effort: `medium`.

## Single major change

Change only the executing model from `gpt-5.5` to `gpt-5.4`. The accepted
v3.83 packet-state anchor, earliest-causal challenger, default-keep arbiter,
prompts, artifact contracts, validators, three-session topology, case order,
concurrency, and retry bounds remain unchanged.

Rejected v3.81/v3.82 lineages contribute no prompt, validator, artifact, or
prediction. No incumbent prediction, label, metric, scored artifact, error
report, or gold rationale is visible during inference.

## Falsifiable hypothesis

GPT-5.4 will preserve v3.83's gains while reducing its six fresh-anchor losses.
Reject if the completed frozen run has Step Exact `<=26/50` or fails any
completeness, schema, taxonomy, evidence, ordering, hash, or gold-isolation
check.

## Acceptance and Goal completion

- Accept only if Step Exact is strictly greater than `26/50` and every legality
  check passes.
- Complete the Goal only if Step Exact is at least `30/50` and every legality
  check passes.
- Step+Module, All Correct, module/type distributions, token use, and latency
  are diagnostic only and do not affect acceptance.
- No smoke gate is used; after offline validation this version runs the full
  GAIA-50 directly.

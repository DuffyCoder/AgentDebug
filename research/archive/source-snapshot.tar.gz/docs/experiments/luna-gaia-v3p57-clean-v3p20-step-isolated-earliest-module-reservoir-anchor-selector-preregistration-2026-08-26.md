# Luna GAIA v3.57 preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.57-clean-v3.20-step-isolated-earliest-module-reservoir-anchor-selector`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: Luna v3.20, Step Exact `25/50`
- Original v3.4 baseline: Step Exact `21/50`
- Version acceptance: Step Exact `> 25/50`
- Goal completion: Step Exact `>= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the sole optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module/type/evidence remain legality constraints only.

## Clean-parent boundary

v3.57 is a direct semantic child of accepted v3.20. Its anchor task and
validator are the v3.20 packet-state-closure protocol with identity retagging.
No v3.21--v3.56 prompt, selector, challenger, ledger, prediction, score, or
runtime artifact is an inference input or semantic parent. v3.54 and v3.56 are
used only as post-score evidence for proposing the single mechanism below.

## Single major mechanism

Add one Step-isolated local taxonomy matrix, a deterministic bounded candidate
reservoir, and one anchor-aware final selection contract:

1. One fresh prefix-bounded session reviews each observable Step. It decides
   only whether each present Module owner contains a literal taxonomy-valid
   local error; it cannot see anchor, later Steps, scores, gold, or prior
   predictions.
2. Candidate admission is deterministic rather than semantic: for each of
   Memory, Reflection, Planning, Action, and System with any positive row,
   retain exactly its earliest positive row, in canonical Module order. The
   reservoir therefore contains at most five candidates.
3. The final selector must export every deterministic representative and
   cannot substitute a later row, omit a Module, invent a row, or drift
   Step/module/type/evidence.
4. The selector chooses exactly the fresh v3.20 anchor or one representative
   by the benchmark's first critical-error boundary: repair must materially
   redirect the failed path; fully recovered defects, faithful propagation,
   and downstream symptoms lose. Anchor is retained under tied or uncertain
   evidence.
5. A task-relevant initial probe with a concrete malformed parameter or wrong
   constraint remains eligible when the defect prevented informative progress.
   A valid indispensable System attempt with a literal external execution
   failure also remains eligible; external ownership alone is not a veto.

The deterministic earliest-per-Module reservoir is the unique mechanism.
v3.56's five causal boundary classes, maturity-before-admission gate,
contribution-witness rule, and two-sided relation prefixes are removed rather
than inherited.

## Post-score hypothesis and risks

v3.56 froze Step Exact `22/50` with a fresh anchor of `21/50`. Its complete
Step-local matrix contained gold Step in `36/50`, and fresh-anchor union local
coverage was `41/50`; the five-class maturity stage retained gold in only
`5/50`. The error audit locates 17 non-ambiguous cases where gold was a literal
taxonomy-valid local positive but never entered the representative set.

The preregistered reservoir is selected from a post-score candidate-coverage
analysis only; it is not a prediction or score composition. On the frozen v3.56
local matrix it covers `25/50` gold Steps, has fresh-anchor union oracle
`33/50`, and includes gold for 11 current errors. Those trajectory IDs and gold
facts remain only in post-score analysis artifacts and do not appear in any
inference source or manifest.

The main regression set is the 18 incumbent-correct cases that would see at
least one non-gold Module candidate in that post-score analysis. The principal
risks are earliest-positive bias, Planning salience, candidate flood up to five,
and promotion of a normal external failure or merely improvable probe. Exact
deterministic admission, candidate role assessment, one final exact-copy choice,
and default keep are the uniform controls. Candidate coverage does not accept
the version.

## Falsifiers

- any represented Module is omitted or a later positive row replaces its
  earliest positive;
- more than five representatives are exported;
- selected prediction is not an exact anchor/representative copy;
- local coverage is not exactly `717/717` or the full run is not 50/50;
- any inference reads labels, scores, old predictions, error audits, experiment
  documents, case routes, git history, or external resources;
- selector Step gains do not exceed selector Step regressions;
- final Step Exact is `<= 25/50`.

Only the last item controls version acceptance, and only Step Exact `>= 30/50`
can complete the Goal after all legality checks pass.

## Execution topology and pre-inference validation

- 50 fresh v3.20 anchors + 717 fresh Step-local sessions + 50 fresh selectors
  = exactly `817` planned successful model sessions.
- Fresh one-case sessions, maximum concurrency `4`, maximum two attempts per
  stage, and no smoke gate.
- Focused v3.57 tests: `10 passed`.
- Cross-version v3.20/v3.54/v3.56 tests: `23 passed` in isolated processes.
- Full-cohort dry-run: 50 cases, 717 legal Steps, 817 planned sessions.
- Static inference-source scan: no case ID/entity route, gold/score reader,
  rejected-version import, old prediction, or git-history input.

## Frozen post-run outcome

- Full GAIA-50 completed and froze `50/50` legal predictions.
- Step Exact: `20/50`; v3.57 is rejected and v3.20 remains the accepted
  incumbent at `25/50`.
- Relative to frozen v3.20: `19` both correct, `1` gain, `6` losses, `24`
  both wrong; net `-5`.
- Fresh v3.20 anchor: `19/50`. The selector changed eight Steps with `2`
  direct gains, `1` direct regression, and `5` wrong-to-wrong changes.
- Complete Step-local gold-Step coverage: `35/50`; fresh anchor plus any
  local-positive row oracle: `41/50`.
- Deterministic earliest-per-Module gold-Step coverage: `22/50`; fresh anchor
  plus reservoir oracle: `31/50`.
- Among the `30` final Step errors, the downstream bottlenecks are `9` cases
  where gold was already a reservoir representative but the selector rejected
  it, `9` where gold was a later same-Module local positive discarded by the
  earliest-only reservoir, `7` Step-local recall misses, `4` released-label
  ambiguities, and `1` false override of a correct fresh anchor.
- The independent inference-access audit passed: `817` planned stages each
  had a successful attempt, one selector required an authorized second attempt
  after an incomplete first attempt, there were no permanent failures, source
  hashes matched, no forbidden/gold/old-prediction read occurred, and all seven
  run-level aggregates contained exactly the same 50 trajectory IDs. Fifteen
  case indices had retained alternate-spelling side directories; none supplied
  a second frozen selector result or entered aggregation.

The hypothesis is therefore falsified. Earliest-per-Module compression retains
enough scoring-phase candidate coverage to make `30/50` reachable in principle,
but is not a criticality ordering rule. The multi-candidate selector preserves
only one net Step gain over its fresh anchor and systematically calls later
released boundaries `downstream_symptom`, `faithful_propagation`,
`noncritical_predecessor`, or `normal_tool_failure` while treating speculative
earlier anchors as `critical_root`. The next experiment must be a clean v3.20
child and may use these post-score facts only to test one isolated selection
mechanism; v3.57 artifacts and protocol changes remain rejected and immutable.

## Pre-inference source hashes

- Protocol SHA-256: `6563e16848f2b429f73c75709bf4ca9d510e71f8ad08285e2252a9f8cc8d224c`
- Runner SHA-256: `24272d097bb0d64cf87b65991fc15076fa02a58f9a93b30ff5b0bfeae35e89bd`
- Registry SHA-256: `03a46c9acd45746cf256216159132099a4e6e880805525a2e65727cc5154ec91`
- Focused-test SHA-256: `c415f8ea23e50c345be7cf47df373254e5e36e693b2c33d52b478ffb2afb721e`

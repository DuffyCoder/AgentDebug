# Luna GAIA v3.63 预注册：heterogeneous critical-boundary panel

日期：2026-08-28

## 冻结身份

- version：`agentdebug.codex-agent-judge.luna-gaia.v3.63-clean-v3.20-heterogeneous-critical-boundary-panel`
- semantic parent：`agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- accepted incumbent：Luna v3.20，Step Exact `25/50`
- original baseline：Luna v3.4，Step Exact `21/50`
- 数据集：冻结 `gaia-paper-v1` 50 例
- dataset content SHA-256：`fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- cohort content SHA-256：`193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- cohort manifest file SHA-256：`31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- prediction manifest file SHA-256：`77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- v3.20 parent source SHA-256：`3e886325bf0a4b4d4a3e770071c0a36fe81dab2bebaf5015561ca828b6c2e4f9`
- 模型：`gpt-5.6-luna`
- reasoning effort：`medium`
- 版本接受条件：完整、合法 GAIA-50 的 Step Exact `>25/50`
- Goal 完成条件：完整、合法 GAIA-50 的 Step Exact `>=30/50`
- smoke gate：无；离线验证后直接完整 GAIA-50

## 上一轮 first-divergence 证据

v3.62 完成固定 `817/817` stage，但 Step Exact 只有 `18/50`，且独立审计
发现 68 个意外目录和 20 个意外文件，因此已经冻结并拒绝。其 32 个 Step
错误中，28 个首先发生在 fresh anchor，四个为低置信度 annotation ambiguity。
可行动错误进一步分为：

- 19 个 gold Step 已是 Step-local positive，但 pair gate 返回 `anchor_wins`；
- 9 个 gold Step 未进入 Step-local positive；
- 四个 annotation ambiguity 不用于机制调参。

完整 local matrix 覆盖 `29/50` gold，fresh-anchor union oracle 是 `39/50`，
但 gold pair win 只有 `2/50`。这证伪了“继续扩大 local positive 后再要求
candidate-only repair 解决整条轨迹”的路径：候选中已有信号，但过强的
whole-trajectory replaceability 把 benchmark-local failure owner 全部压回 anchor。

同一 v3.20 语义在 30 次历史 fresh run 中的 anchor Step Exact 为 `17--23/50`。
评分后 3/5/7/9 路 plurality 的中位数只有约 `21--22/50`，最高 `27/50`，没有
任何组合达到 30；所以纯重复 anchor 共识也被离线否定。

另一方面，v3.39 的 typed proposal 对其 fresh anchor 有三次 direct gain、零次
direct loss；v3.49 的 global proposal duel 有六次 direct gain、两次 direct loss，
final 为 `25/50`。冻结 v3.20、v3.39 proposal 与 v3.49 proposal 的评分后 union
为 `31/50`，只用于提出“异质 complete-boundary hypothesis 可互补”的可证伪
假设，不进入推理、routing、manifest 或逐例拼接。v3.51 的三个同质 proposal
replica union 只有 `28/50`，是直接反例。

## 唯一主要机制变化

相对 v3.20 只增加一个 `heterogeneous complete-boundary panel`。每例固定五个
fresh、隔离 session：

1. 原样执行 v3.20 packet-state anchor；
2. `state_constraint` specialist：审查状态真值、Memory/Reflection handoff、任务
   约束和来源/目标对齐，只能输出一个完整 prediction 或 `none`；
3. `capability_action` specialist：审查能力承诺、不可行 acquisition、错误工具/
   Action、参数与执行前提，只能输出一个完整 prediction 或 `none`；
4. `feedback_terminal` specialist：审查工具反馈后的重承诺、outcome misread、恢复、
   faithful propagation、下游症状与终止/放弃边界，只能输出一个完整 prediction
   或 `none`；
5. 一个 anchor-preserving exact-copy selector，同时比较 anchor 与最多三个完整
   proposal，只能复制其中一个 prediction。

三个 specialist 都必须按时间顺序检查全部 Step 和全部可观察 owner，但只可为其
预注册 family 导出一个 benchmark-critical boundary。它们看不到 anchor、彼此输出、
历史预测、分数或 gold。family 是搜索责任，不是 vote、module/type metric 或优先级。

selector 禁止按多数、proposal 来源、Step 早晚、module/type、措辞强度或候选数量
排序。它必须定位每个候选最早成熟的 task-material failure owner，并执行 probe、
normal failure、recovery、mechanical predecessor、faithful propagation 和 downstream
symptom veto。关键统一变化是：candidate 的修复只需改变它所拥有的第一个
benchmark-relevant failed path；后续独立错误仍存在不能成为自动 `anchor_wins`。
只有 candidate 的 failure ownership 严格强于 anchor，且 anchor 有 literal
noncritical/recovered/predecessor/symptom 证据时才 override；不确定则 exact-copy
keep anchor。

## Gains 与 regressions 预估

预期 gains 来自三类互补边界：v3.20 的 state/capability early freeze、v3.39 能召回
的 later typed boundary，以及 v3.49 能产生的 anchor-blind global boundary。
每个 specialist 最多一个 proposal，把候选池固定为四个 prediction，避免论文公开
Phase-1 和 v3.62 的 local-positive 洪泛。

主要 regression 风险是：

- 正确 anchor 暴露于最多三个 non-gold complete proposals；
- specialist 把 reasonable probe、局部可改进、正常工具失败或晚期症状包装成完整
  critical prediction；
- selector 因更强措辞或后期持久性晚选；
- 为修复 v3.62 的过强 gate 而放宽 failure ownership，可能形成 false override。

直接反例包括 v3.44 的自由 selector、v3.49 的两次 direct loss、v3.51 的同质
replica ceiling，以及 v3.62 的非法写入。对应控制是常数候选上界、全轨迹 literal
owner 证据、origin-blind comparison、exact-copy、default keep 和严格 stage write
allowlist。

## 预注册 falsifiers

- fresh anchor 加三个 proposal 的评分后 candidate oracle `<30/50`；
- 三个 specialist 没有形成比 v3.51 同质 replica 更高的完整边界召回；
- selector 相对 fresh anchor 的 direct gains 不严格多于 direct losses；
- final Step Exact `<=25/50`；
- 任一完整性、write allowlist、hash、顺序、schema、taxonomy、literal evidence、
  exact-copy、case-routing 或 gold-free 审计失败。

Candidate oracle、family/module/type 分布仅用于评分后根因判断；版本接受、拒绝和
Goal 完成仍只由完整合法 GAIA-50 的 Step Exact 决定。

## 继承与隔离

- semantic parent 只有 v3.20；v3.21--v3.62 均不是 parent。
- v3.39、v3.49、v3.51、v3.62 只提供评分后机制证据；不继承其 prompt、candidate、
  selector、ledger、validator、prediction 或中间 artifact。
- 推理阶段禁止 labels、metrics、scored artifacts、旧预测、错误报告、gold rationale、
  case studies、git history、trajectory/source-model router 与外部资源。
- 50 个 case 的 250 个固定 stage 全部完成并冻结，且独立访问/写入审计通过后才评分。

## 预推理冻结记录

- 离线测试：首次 `18 passed`；预执行 runner 接口修正后重跑为 `19 passed`
  （v3.20、v3.37 和 v3.63 相关测试），其中 v3.63 专属测试 `6 passed`。
- Python compile：protocol、runner、registry 和 tests 全部通过。
- lint：本环境没有安装 `ruff`，记录为工具不可用；compile 和 tests 不受影响。
- prepare-only：50/50 case，固定五阶段，计划 `250` 个 fresh session，最大并发 4，
  每阶段最多两次 attempt；未运行 smoke。
- case input：50 个隔离目录、100 个 manifest/cohort 文件。
- dataset content SHA-256：`fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- cohort content SHA-256：`193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- prepared prediction manifest SHA-256：`56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`
- protocol source SHA-256：`f79303b08116afe51fb4c9b721ff567976936ff266673429db36c42d048c47dd`
- runner source SHA-256：`8c0e24ef15068b213b9b14a430852467c367f513b00b7a0bd97c04fe1273c43f`
- registry source SHA-256：`50c538a5bfff97a0d0164051b1ce6648851b0efd7eeddcf5ac8c5a2e52288bef`
- taxonomy source SHA-256：`d7e4b878059bbecec0a8fd3f078c0aeb5755bf9e65bb938c897dd83685f28c5c`
- test source SHA-256：`b9fddbb519c03bd29fcb4b9e08beffdec263e4dcc724025ca927661b1155d5e0`

首次 `--execute` 在任何 `codex exec`/模型调用创建前，由 sandbox command
wrapper 的 Python 签名不接受 runner 传入的 `model` 参数而失败；50 个 case 仅写入
预生成的 `agent-task.md`，没有 stdout event、预测或其他模型产物。该预推理接口错误
修正为透传冻结 model/effort 后，新增 wrapper 负例测试并重新冻结上述 runner/test
hash；protocol、registry、taxonomy 和 case inputs 均未改变。

以上 source hash 在首次模型调用前冻结；已评分版本不得修改。独立访问/写入审计
将逐项核对这些 hash、250-stage 拓扑、50/50 aggregate 顺序和 attempt workspace
allowlist。

## 冻结运行结果

- 状态：`rejected_runtime_or_validation_failure`
- 完成 case 调度：`50/50`
- anchor attempts：`100`（每例两次）
- 成功 anchor：`0/50`
- specialist/selector sessions：`0`
- predictions：`0/50`
- Step Exact：不可评分；不产生接受或 incumbent 转移
- 重复错误：模型调用成功返回，但其首个 shell command 均在读取 manifest 前被
  `workspace-write` sandbox 初始化拦截；主要错误为
  `bwrap: loopback: Failed RTM_NEWADDR: Operation not permitted`。
- artifact 事实：100 个 stdout log；0 个 anchor prediction、0 个 specialist
  proposal、0 个 selector artifact。
- first divergence：50/50 均为高置信度 `runtime_or_validation_failure`；无 Judge
  semantic first divergence 可分析。
- 接受决定：拒绝；v3.20 `25/50` 继续作为 accepted incumbent。

评分前后都没有可冻结预测，因此本版本不得被赋予 Step 分数。下一版本仍须直接从
v3.20 语义创建；允许重新检验同一 heterogeneous-boundary 单机制，但必须单独版本化
运行时兼容修复，不能修改本版本任何已生成 task/log。

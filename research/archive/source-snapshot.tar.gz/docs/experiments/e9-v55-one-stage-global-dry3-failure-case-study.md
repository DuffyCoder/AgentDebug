# E9 v55 one-stage-global dry3 failure case study

## Result

The frozen v55 dry3 run used one logical DeepSeek Flash completion for all
three cases.  Transport, strict JSON parsing, source ownership, raw-first
persistence, gold isolation, and scoring all succeeded.  Semantic accuracy
did not:

- Step Exact: 0/3
- Step+Module Exact: 0/3
- All Correct: 0/3
- successful parsed predictions: 3/3
- logical completions: 1
- HTTP attempts: 1, with zero retries

The immutable promotion result is rejected.  No full30 or smoke run is
authorized from v55.

## Case attribution

1. ALFWorld: gold is step 30, system/step_limit; v55 selected step 16,
   planning/inefficient_plan.  The global judge invented a preferable search
   strategy and treated reasonable coverage of distinct locations as a local
   planning defect.  The established v30 adjudication correctly preserved the
   terminal enforced boundary.
2. GAIA: gold is step 1, action/misalignment; v55 selected step 4,
   planning/constraint_ignorance.  The judge chose the final wrong-answer
   symptom instead of the initial use of a page-text extractor that could not
   expose the required issue ordering and label-history event.  v30 correctly
   preserved the early capability/action root.
3. WebShop: gold is step 13, planning/inefficient_plan; v55 selected step 8,
   planning/inefficient_plan.  The error type was right but the judge chose an
   earlier plausible query refinement rather than the later plan that called
   already-covered Page 6 unexplored and knowingly continued repeated
   coverage.

## Process attribution

The architectural experiment began from the immediately preceding failed
v54 design rather than from the globally best measured implementation.  It
also misread “simplify the testing workflow” as permission to simplify the
semantic diagnosis and evaluation topology.  Removing candidate generation
and independent selection discarded distinctions that historical results had
already shown to be necessary.

This is the governing mistake.  The low semantic score is a consequence, not
the next implementation baseline.

## Correction

- Freeze v55 as a rejected experiment; do not optimize v56 from its source.
- Restore v30 as the development incumbent because it has the best tuning
  full30 Step Exact result: 10/30.  v25 ties on Step Exact but loses v30's
  secondary metrics.
- Preserve the incumbent semantic/evaluation architecture.  Simplify only
  the engineering test workflow: targeted tests during editing, one full
  regression at freeze, dry screening, then full30 only for an accepted
  challenger.
- Every new challenger must be a declared delta from the incumbent, not from
  the latest attempt.  A failed challenger is archived and the next attempt
  again starts from the incumbent.
- Promote a new tuning incumbent lexicographically by Step Exact,
  Step+Module Exact, All Correct, successful prediction count.  The separate
  goal gate remains Step Exact >= 12/30; held-out smoke stays unopened until
  that gate passes.

No further provider attempt may occur before the v30 frozen implementation is
re-established as the explicit source baseline.

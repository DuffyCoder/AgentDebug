# E9 v29 full30 failure case study

## Outcome

v29 passed dry3 at 2/3 and eliminated the v27 malformed-batch defect, but its
full30 tuning run remained below the semantic promotion threshold:

- Step Exact: 9/30 (30.00%; gate requires 12/30)
- Step+Module Exact: 3/30 (gate requires 2/30)
- All Correct: 3/25 (gate requires 3/25)
- Successful outputs: 29/30 (gate requires 29)
- Failed outputs: 1/30 (gate permits 1)
- New logical completions: 10
- HTTP attempts: 10, with zero retries

Only `step_exact_minimum_correct` failed. Held-out smoke must not run.

## Format attribution

The flat review schema worked across all eleven batches: no batch lost its
JSON envelope and the three cases that were malformed in v27 all parsed.
The sole failed row was a case-local length violation: its flat
`causal_basis` was 774 characters against a 768-character limit. The response
was otherwise strict JSON and the other two cases in that batch remained
valid. Raising this explanatory-only cap to 1024 removes a false format loss
without changing any final semantic field.

## Semantic attribution

The environment breakdown was ALFWorld 3/10, GAIA 5/10, and WebShop 1/10,
the same total and breakdown as v27 after different per-case choices. The
terminal guard fixed its dry ALFWorld case, but Flash still varied on several
early-versus-late decisions.

Three recurring misses provide concrete, general optimization targets:

1. A malformed ALFWorld action that causes `Nothing happens` is already a
   local error at its first occurrence; later repetitions must not replace it.
2. In WebShop, a plan that immediately pages list results without opening any
   product detail can be the first inefficient local event. Waiting for many
   repeated cycles often moves the prediction far beyond the released step.
3. An initial plan/action that visibly omits a literal target-defining
   constraint is erroneous on its face, unlike a broad but constraint-complete
   first probe. Later search stagnation must not replace that earlier defect.

These are evidence-time rules, not numeric shifts or gold-dependent output
repairs. The v13/v25/v29 prediction union contains 12 exact steps, indicating
that the target is present in the existing LLM candidate space but the final
selection is unstable.

## v30 optimization direction

1. Retain v29's terminal guard, flat JSON schema, raw-only final semantics,
   default Flash request, and exact budgets.
2. Add a final first-defect stability audit implementing the three general
   rules above. It must compare text and observable outcomes, never subtract a
   fixed number from a predicted step.
3. Increase only the explanatory `causal_basis` limit from 768 to 1024 and
   state that limit in the prompt.
4. Run dry3, then full30 only after acceptance. Any further failed attempt
   again requires a case study.

No v29 artifact may be mutated or rescored under the v30 parser.

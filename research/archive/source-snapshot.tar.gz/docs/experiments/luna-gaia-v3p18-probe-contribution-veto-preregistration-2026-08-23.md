# Luna GAIA v3.18 Probe-Contribution Veto Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia-v3.18-probe-contribution-veto`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.14-earliest-causal-challenger`
- Frozen incumbent Step Exact: `24/50`
- Original v3.4 baseline Step Exact: `21/50`
- Version acceptance: `Step Exact > 24/50`
- Goal completion: `Step Exact >= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Frozen v3.14 predictions SHA-256: `fe5bcf0a07e5776b0b60d28da835c0bf8ed7f03fb0d7e3eb0a36fbea23835133`
- v3.17 Step audit SHA-256: `a6c1c4de605a5ca7287f12b2c0d26dcc26473b6024d4985a7a250b44155adccc`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the only optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module/type/evidence remain legality constraints only.

## Post-score diagnosis motivating this version

v3.17 produced 31 Step errors. Its largest actionable cluster contains 10
acquisition-capability false positives, all first diverging at
`false_candidate_admission`; 7 diagnoses are High confidence and 3 Medium.
The common trigger projects the final proof requirement backward onto a route
that can still contribute a necessary identifier, page, text, source, or lead.

v3.16 and v3.17 already falsified challenger-recall variants: neither the
optional bidirectional challenger nor 80 validator-enforced earlier-scan rows
produced an earlier challenger. This version therefore changes anchor admission,
not challenger breadth.

## Single major change

Add one mandatory probe-contribution gate to the v3.14 anchor ledger.

Every inspected row records, inside its existing `decision_basis`, exactly one
machine-validated prefix:

```text
boundary_kind=<acquisition_probe|other>; contribution=<possible|observed|zero|not_applicable>;
```

For an acquisition route:

1. `observed` means the route actually supplied task-relevant intermediate
   evidence in its packet.
2. `possible` means no literal prior outcome or interface fact rules out its
   supplying a necessary identifier, page, text, source, transcript lead, or
   immediate-subgoal clue.
3. `zero` requires literal proof that the interface/corpus and history cannot
   expose even a necessary intermediate for the current unresolved subgoal.
4. `possible` or `observed` is a binding veto on Lane-B capability admission.
   It does not veto an independently false Memory/Reflection state, a literal
   System exception, or Lane-C repetition after direct feedback.
5. A true dynamic-video/static-extractor or dynamic-UI/static-interface
   mismatch remains admissible when the exact required predicate is already
   identified and the route has `contribution=zero` for that unresolved subgoal.

The existing v3.14 earliest-causal later challenger and default-keep exact-copy
arbiter remain otherwise unchanged. No candidate pool, global selector, earlier
challenger, case router, historical prediction input, or gold information is
added.

## Falsifiable prediction

The mechanism should move early capability/probe false positives later without
systematically moving true hard-capability anchors. Post-score expected coverage
from the v3.17 audit is 11 errors, with 4 identified incumbent-correct risk
cases. The main observable mechanism checks are:

- every anchor ledger row has a valid contribution prefix;
- no acquisition row with `possible` or `observed` has a Lane-B candidate;
- at least one full-run anchor uses a contributory-probe veto;
- true `zero` capability roots remain representable;
- Step Exact gains exceed losses relative to v3.14.

The hypothesis is falsified if the contract produces no contributory-probe
vetoes, causes candidate flooding/later drift, or yields Step Exact `<= 24/50`.

## Gain and regression analysis

Expected gain cluster:

- initial or alternate searches that can expose an identifier/title/page/lead;
- candidate-publication or academic-source probes that can narrow the subgoal;
- successful changed-source probes that already contributed a needed value;
- acquisition routes rejected only because they cannot alone prove the final answer.

Incumbent-correct risks:

- exact video/timestamp evidence assigned to static extraction;
- interactive database/UI predicates assigned to static corpus tools;
- corpus routes with literal evidence that they cannot expose the required predicate;
- repeated routes after direct feedback has exhausted their contribution.

The explicit `zero` control and the fact that only Lane-B capability admission
is vetoed are intended to contain these regressions. The change is uniform and
does not depend on trajectory IDs, entities, sites, source models, or fixed Steps.

## Execution and acceptance protocol

1. Implement the versioned prompt, contribution-prefix validator, runner, and
   negative tests.
2. Run offline tests and source scans only; do not run a smoke gate.
3. Execute all 50 frozen cases with three fresh serial sessions per case and at
   most four cases concurrently.
4. Freeze all predictions and intermediate artifacts after 50/50 completion and
   gold-free validation.
5. Only then load released labels and score all 50 cases.
6. Compute Step Exact and transitions against v3.4 and v3.14.
7. Accept only if Step Exact is strictly greater than `24/50`; complete the Goal
   only if it is at least `30/50` and every legality/freeze check passes.
8. Otherwise reject the immutable version, audit every Step error, and create a
   new version from one next unified mechanism.

# E9-v31 recovery: attestation finalization failure case study

## Attempt and completed work

The recovery made exactly one DeepSeek call for v31 batch 11. The raw response
was persisted successfully, the recovery ledger advanced from 645 to 646, all
30 rows were rebuilt with provider access disabled, the previous 27 semantic
rows were checked for equality, the complete raw chain validated, and standard
gold scoring artifacts were written.

## Failure

The last, deterministic attestation step raised `KeyError: 'two_stage'` while
reading the incumbent metric. No second provider call was attempted.

## Root cause

The recovery script assumed a stale metric shape:
`metrics["two_stage"]`. AgentErrorBench's actual standard report nests method
metrics under `metrics["by_method"]["two_stage"]["overall"]`. The candidate
metric returned in memory uses the same standard nesting.

## Evidence that the semantic run succeeded

- `recovery-run.json` records status `success`, one logical completion, and
  cumulative count 645 -> 646.
- `predict-run.json` records 30 predictions across 11 batches.
- `metrics.json`, `predictions.jsonl`, and the standard report exist.
- The failure stack begins only after `write_outputs` returned.

## Correction

Fix only the metric lookup and add an offline `finalize` command. Finalization
must reconstruct from the now-complete cache with a judge that raises on any
provider call, validate again, score again, and write only the missing
attestation. It must not invoke DeepSeek or increment the recovery ledger.

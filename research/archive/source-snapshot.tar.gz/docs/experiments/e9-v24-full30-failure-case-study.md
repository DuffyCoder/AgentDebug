# E9 v24 full30 failure case study

## Outcome

The accepted v24 dry3 candidate did not generalize to the frozen 30-case
tuning cohort.  The formal full30 run used the same code archive, provider
identity, frozen v13 predecessor, and first-batch Critic cache as dry3.  It
made exactly ten new logical completions (ten HTTP attempts, zero retries).

- Step Exact: 6/30 (20.00%; gate requires 12/30)
- Step+Module Exact: 4/30 (13.33%)
- All Correct: 4/25 (16.00%)
- Successful outputs: 20/30
- Failed outputs: 10/30

The promotion gate rejected the run.  Held-out smoke must not run from this
candidate.

## Failure taxonomy

### Validator-only rejections

Seven cases had a complete JSON case object but were rejected locally.

1. Three `invalid_text` cases exceeded a prose cap by a very small amount.
   Their `review.causal_basis` lengths were 514, 521, and 516 characters
   against a 512-character limit.  One of the same cases had a 526-character
   `root_cause`.  The safe error text said "must be non-empty text", which hid
   the actual over-length cause.
2. Four `invalid_unrecovered_candidate` cases contained complete final roots,
   but `critical_step` differed from `review.earlier_candidate_step` while
   `later_recovery_step` was null.  The model used the earlier field as a
   considered incumbent/early hypothesis and the final field as its selected
   root.  Rejecting the final LLM judgment is an extra programmatic semantic
   rule, not the repository's original LLM-as-judge behavior.

Accepting these seven raw roots would reduce format failures but would not by
itself improve Step Exact: all seven raw critical steps differ from their
released tuning labels.

### Empty final content

One three-case batch returned HTTP 2xx with `finish_reason=stop`, provider
usage, and 798 output tokens, but an empty OpenAI-compatible
`message.content`.  All three cases therefore became `invalid_json` with
`empty_response`.  This reproduces the v23 default-thinking failure on a
larger cohort despite the v24 final-content instruction.  No retry occurred.

### Semantic late-step bias

Among the 20 structurally successful cases:

- 12 predicted steps were later than gold;
- 2 were earlier than gold; and
- 6 exactly matched gold.

By environment, the run scored ALFWorld 1/10, GAIA 5/10, and WebShop 0/10 on
Step Exact.  The prompt's mature-recommitment and task-closing-recovery rules
systematically moved roots away from earlier observable module errors.  v24
gained two Step matches over v13 and lost two, leaving the same 6/30 total.
The additional Critic therefore did not improve the target metric.

## Root attribution

The failed full30 attempt has three independent causes:

1. **Output contract mismatch:** prose length limits were too tight and their
   failure message was ambiguous.
2. **Programmatic semantic overconstraint:** recovery consistency rules
   rejected otherwise complete LLM final judgments.
3. **Objective mismatch:** the prompt optimized for an unrecovered causal
   root, whereas AgentErrorBench Step Exact rewards the released critical
   module output, which is often an earlier local error.

The API transport was not the primary failure: all ten paid requests returned
without HTTP retry.  Removing the cumulative authorization cap does not fix
any of these diagnostic issues.

## v25 optimization direction

Before another model attempt:

- retain Flash and the provider's default request body;
- retain raw-only LLM final semantics, gold isolation, exact evidence-source
  ownership, taxonomy validation, cache lineage, and per-phase budgets;
- increase audit/root prose limits to tolerate small harmless overages;
- stop enforcing a deterministic equality between a review checkpoint and
  the LLM's final critical step;
- rewrite the selection objective around the earliest directly observable
  erroneous memory/reflection/planning/action/system output that contributes
  to failure, rather than a later mature recommitment or unrecovered root;
- keep the frozen v13 diagnosis as fallible context, not a fallback or vote;
- keep the default Flash API body and strengthen final-content handling
  without adding a custom thinking parameter; and
- run dry3 first.  Only an accepted dry3 may proceed to another full30, and
  only an accepted full30 may proceed to held-out smoke.

No v24 prediction, raw response, or score may be mutated or reclassified.

# GAIA v3.109 direct Responses expanded validator-closure preregistration

Date: 2026-08-31

Status: preregistered and unscored. This document authorizes no network call
and claims no GAIA-50 result.

## Frozen identity and lineage

- Version: `agentdebug.codex-agent-judge.gaia-v3.109-v3p83-sophnet-responses-expanded-validator-closure-gpt55-medium`.
- Semantic parent: accepted v3.83,
  `agentdebug.codex-agent-judge.gaia-v3.83-clean-v3.20-model-only-gpt55-medium`,
  Step Exact `26/50`.
- v3.108 is transport-failure evidence and a frozen implementation dependency,
  not the semantic parent. No v3.108 prediction or run artifact is imported.
- Semantic protocol: unchanged v3.83 packet-state anchor, earliest-causal
  challenger, and default-keep arbiter.
- Dataset: frozen `gaia-paper-v1`, 50 cases; dataset identity
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort identity:
  `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction-manifest identity:
  `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`.
- Model: `gpt-5.5`; reasoning effort: `medium`.

## Read-only v3.108 transport evidence

The completed v3.108 full run produced 45 complete cases and five terminal
legality failures:

- `invalid_evidence_ownership`: 2 anchor cases;
- `cohort_order_mismatch`: 1 anchor case;
- `invalid_embedded_prediction_status`: 1 challenger case; and
- `invalid_embedded_prediction_evidence`: 1 challenger case.

These aggregate post-run facts justify one uniform transport hypothesis. Case
IDs, prior predictions, prior prompts, and failed raw model outputs are absent
from v3.109 inference.

## One falsifiable mechanism

The sole change is an expanded bounded same-stage validator closure. Every
stage begins from the unchanged v3.83 direct Responses prompt and gold-free
JudgeView. After rejection by the unchanged v3.83 validator, the stage may make
at most four additional fresh stateless requests, for five total attempts.

A correction receives only the complete current stage input, an allow-listed
error code with fixed guidance, and the first extractable Step-semantic lock.
For same-Step evidence failures it may also receive deterministic
validator-owned source blocks derived from the current gold-free JudgeView.
Every attempt must return a complete replacement envelope; the host does not
coerce, copy, synthesize, normalize, or repair model fields.

The expansion relative to v3.108 is one mechanism:

1. increase the bounded closure from three to five total attempts; and
2. close two observed challenger legality codes under the already frozen
   challenge decision and proposed Step:
   `invalid_embedded_prediction_status` and
   `invalid_embedded_prediction_evidence`.

## Frozen semantic locks

- Anchor: selected Step only. Module/type/evidence may change only within that
  Step when evidence ownership is invalid.
- Challenger: `challenge_status` and proposed Step. A status correction must
  emit exact `"success"`; an evidence correction may reselect only same-Step
  module/type/evidence using the supplied owner-source map.
- Arbiter: decision, selected Step, and exact selected upstream prediction
  hash.

Missing transport output does not erase an existing lock. Any observable lock
drift fails before ordinary parent validation, even if the new artifact would
otherwise be legal.

## Fail-closed feedback allowlist

Only these seven codes may trigger a correction:

- `missing_stage_artifact`, any stage;
- `arbiter_frozen_step_mismatch`, arbiter only;
- `arbiter_selected_prediction_hash_mismatch`, arbiter only;
- `invalid_evidence_ownership`, anchor only;
- `cohort_order_mismatch`, anchor only;
- `invalid_embedded_prediction_status`, challenger only; and
- `invalid_embedded_prediction_evidence`, challenger only.

An unknown code, wrong-stage code, missing required lock, or lock change stops
that case fail-closed. Validator exception prose and failed model output are
not sent to the next request.

## Audit and transport contract

- Endpoint: `POST https://api.sophnet.com/v1/responses`; no fallback.
- Base Responses contract:
  `agentdebug.v3p83-sophnet-direct-responses.v2`.
- Expanded closure contract:
  `agentdebug.v3p83-direct-responses-expanded-validator-closure.v1`.
- `store=false`, `stream=false`, no tools, conversation, or
  `previous_response_id`; redirects disabled.
- API key source: `SOPHNET_API_KEY` environment variable only; never a CLI
  argument, prompt, artifact, stdout, stderr, or audit value.
- HTTP attempts per logical request: at most 3 byte-identical attempts under
  the frozen transport policy.
- Semantic attempts per stage: exactly configured maximum 5; initial plus at
  most 4 corrections. Each is a fresh stateless POST.
- Cases: 50; required accepted stages: 150; workers: at most 4; no smoke gate
  and no case router.

Before the ordinary gold-free freeze, the version-local closure verifier must
match all disk attempts to `execution-summary.json`, replay cumulative feedback
and locks from materialized artifacts, verify the seven-code stage allowlist,
validate stateless/no-mutation/no-replay flags and accepted-call usage/latency,
and require the model-envelope ordered hash to equal its materialized-artifact
hash. The v3.109 contract is installed only for the run and restored in
`finally`; frozen v3.108 and shared runtime files remain unchanged.

Before benchmark inputs are opened, a non-benchmark preflight must return
exactly `{"v3p109_expanded_validator_closure_ok":true}` from resolved model
`gpt-5.5`. Failure aborts without fallback.

## Acceptance and completion

All 50 predictions and 150 accepted stage artifacts must pass original v3.83
validators, transport audit, credential scan, gold-free freeze, and post-freeze
verification before scoring.

- Selection metric: Step Exact only.
- Accept v3.109 only if Step Exact is strictly greater than `26/50`.
- Complete the Goal only if Step Exact is at least `30/50`.
- Module/type metrics, tokens, latency, and closure counts are diagnostic only.

## Commands

Offline preparation, without network:

```bash
.venv/bin/python -m \
  scripts.run_agent_judge_gaia_v3_109_v3p83_sophnet_responses_expanded_validator_closure_gpt55_medium_paper50
```

Formal run, after tests and operator-provided environment secret:

```bash
.venv/bin/python -m \
  scripts.run_agent_judge_gaia_v3_109_v3p83_sophnet_responses_expanded_validator_closure_gpt55_medium_paper50 \
  --execute --max-workers 4 --max-attempts 5
```

The credential value is intentionally absent from this repository artifact.

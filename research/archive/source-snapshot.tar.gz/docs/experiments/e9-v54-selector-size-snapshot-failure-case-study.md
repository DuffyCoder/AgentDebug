# E9 v54 Selector-size snapshot failure case study

## Result and attribution

The nine previously failing focused tests were rerun. Eight passed; the only
remaining failure was an exact request-size snapshot. V54's added categorical
contradiction-precedence instructions increased the measured worst-case
Selector request from 836,774 to 837,780 characters.

The value remains 62,220 characters below the frozen 900,000-character
preflight limit. This is an expected prompt-size change, not an overflow or a
semantic/parser failure. No provider call occurred.

## Correction

Rename the historical v52 size test to v54, update its exact deterministic
snapshot to 837,780, and preserve the independent assertion that every batch
remains below the 900,000-character hard limit.

# Luna GAIA v3.32 Clean v3.20 Complete-Step-Census Challenger Preregistration

## Frozen identity and decision rule

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.32-clean-v3.20-complete-step-census-challenger`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Single major change: replace the parent's challenger search with one
  validator-audited complete-Step census before anchor classification.
- Accepted incumbent: Luna v3.20, Step Exact `25/50`.
- Version acceptance: Step Exact `>25/50`.
- Goal completion: Step Exact `>=30/50` plus every legality check.
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases.
- Dataset manifest SHA-256:
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort semantic SHA-256:
  `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Cohort file SHA-256:
  `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Prediction-manifest file SHA-256:
  `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Model / reasoning effort: `gpt-5.6-luna` / `medium`.
- No smoke gate; after offline validation run the complete GAIA-50 directly.

Step Exact is the only optimization and acceptance metric. Module, type, and
evidence remain schema/taxonomy/validator legality constraints only.

## Post-score evidence and first divergence

Frozen v3.31 scored `21/50` and was rejected. Relative to v3.20 it produced
zero gains and four losses. Its complete 29-error audit found:

- false candidate admission: 10;
- candidate recall failure: 6;
- early freeze failure: 4;
- annotation ambiguity: 5;
- missing recovery/veto: 2;
- late symptom preference: 1;
- reconciliation selection failure: 1.

The two v3.31 anchors disagreed on 20 cases. Only seven disagreements contained
one exact candidate; the adjudicator selected the exact candidate in six. The
two-anchor oracle was only `22/50`. This falsifies another closed exact-copy
anchor selector as the main repair: the dominant first divergence occurs before
gold enters the selected candidate path.

The accepted v3.20 audit contains 25 errors, including seven candidate-recall,
three early-freeze, two late-symptom, and eleven false-admission cases. Existing
challengers often classify the anchor first and stop; v3.30 emitted only five
later proposals and no earlier proposal. The missing observable contract is a
complete local verdict for every Step before the anchor can terminate search.

## Single uniform mechanism

The v3.20 anchor prompt, packet-state ledger, Step freeze, model, and default-
keep exact-copy arbiter remain semantically unchanged. Only the challenger is
changed:

1. Enumerate every Canonical Step exactly once in chronological order before
   classifying the anchor.
2. Assign one closed verdict to each Step:
   `clear`, `reasonable_probe`, `normal_failure`, `recovered_or_mechanical`,
   `faithful_propagation`, `noncritical_local_error`, or
   `critical_candidate`.
3. Freeze at most one `critical_candidate` across the complete timeline. Do not
   stop at the first surface defect and do not prefer a later symptom merely for
   severity or wording.
4. A critical candidate needs literal local error evidence, an unresolved task
   condition, and a repair counterfactual showing why it owns the benchmark's
   matured critical boundary. Reasonable initial/different probes, normal tool
   failures, completely recovered/mechanical defects, faithful propagation, and
   merely improvable local errors are vetoed.
5. Compare the frozen census candidate with the anchor only after completing
   the census. A different-Step challenge is allowed only when the anchor is a
   reasonable probe, noncritical predecessor, or downstream symptom and the
   candidate remains independently failure-causing after anchor-only repair.
6. Emit at most one exact challenger prediction. The unchanged arbiter keeps
   the anchor on uncertainty and can select only the exact anchor or exact
   challenger prediction.

The challenger JSON retains the incumbent contract. Its `search_summary`
begins with a validator-parsed certificate containing every Step/verdict pair,
the sole candidate Step or `none`, and its direction relative to the anchor.
No trajectory ID, entity, site, released gold, historical prediction, or fixed
Step rule is present in the inference protocol.

This is a clean v3.20 branch. It does not inherit v3.21-v3.31 state ledgers,
capability gates, dual anchors, reconciliation prompts, validators, or output
semantics. Bidirectional challenger JSON validation is transport/schema support
for this newly specified census, not inherited selection behavior.

## Falsifiable gain and regression analysis

Expected gain mechanism: a complete census makes an earlier or later benchmark
boundary observable before anchor short-circuit. The principal post-score
target clusters are candidate recall, early freeze, late symptom, and early
capability false admission. Exact case IDs remain only in post-score artifacts
and are not copied into code, prompts, manifests, or routing.

Regression risks:

- local but noncritical errors may be promoted, especially Planning defects;
- a full scan may prefer a late explicit symptom over an earlier mature cause;
- an initial useful probe or normal tool failure may be mislabeled critical;
- the census may become a disguised candidate flood;
- fresh v3.20 anchor sampling may regress incumbent-correct cases even if the
  challenger mechanism is neutral.

Controls are the closed verdict set, exact one-row-per-Step validation, one-
candidate cap, recovery/probe/normal-failure/faithful-propagation vetoes,
literal evidence requirements, two repair counterfactuals, and unchanged
default-keep arbiter. The hypothesis is falsified if the census is not fully
exercised, produces invalid coverage, generates uncontrolled overrides, or the
complete legal run scores `<=25/50`.

## Execution protocol

1. Implement the versioned prompt, census validator, runner, registration, and
   negative tests.
2. Verify exact parent-anchor equivalence modulo identity, exact Step census,
   one-candidate/proposal binding, direction checks, frozen hashes, and full
   aggregate validation offline.
3. Run no smoke gate. Execute all 50 cases with three fresh serial stages per
   case and at most four cases concurrently.
4. Freeze all predictions and intermediate artifacts after 50/50 completion;
   run gold-free schema, taxonomy, evidence, order, hash, census, exact-copy,
   no-routing, and no-prior-prediction validation.
5. Only then load released labels and score all 50 cases.
6. Compute Step transitions and gains/losses against accepted v3.20.
7. Accept only above `25/50`; complete the Goal only at `>=30/50`. Otherwise
   reject the immutable version, audit every Step error, and create the next
   clean version from the still-accepted incumbent.

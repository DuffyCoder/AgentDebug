# GAIA v3.88 sparse influence-graph challenger result

Date: 2026-08-29

## Decision

Rejected and immutable. Complete GAIA-50 Step Exact is `22/50`, below the
accepted v3.83 incumbent `26/50` and the Goal threshold `30/50`.

## Frozen execution and legality

- Complete cases: `50/50`.
- Stage attempts: `150/150`; retries: `0`; failed cases: `0`.
- Model/effort: `gpt-5.5` / `medium`.
- Gold-free, schema, order, taxonomy, literal evidence, Step range, graph,
  exact-copy, and no-routing validation: passed.
- Sparse graphs: 4 root candidates, 46 null graphs, 6 total edges.
- Directions: 3 later, 1 earlier, 46 none.
- Arbiter: 3 accept challenger, 47 keep anchor.
- Predictions SHA-256: `ec820e958e556dfd6421339b3d1675b5fa3b33fa25fbdf54b9b3c537b60ac612`.
- Prediction audit SHA-256: `6048d91bea49ec585e5682c915c52844816dc7552c0b41723059311c387a60a7`.
- Scored metrics SHA-256: `31955d8f88bdd6f8f1a9880aadf80223c4a04753bf94fedce63036c897832a1b`.

## Step-only mechanism result

- Fresh v3.83-semantic anchor: `24/50`.
- Final: `22/50`.
- Relative to frozen v3.83: 21 both correct, 23 both wrong, 1 gain, 5 losses.
- Proposal Step exact: `0/4`.
- Direct graph-challenger effect over the fresh anchor: 0 gains, 2 losses,
  1 wrong-to-wrong accepted move.
- The only incumbent-relative gain came from fresh-anchor sampling drift; it
  was not produced by the graph mechanism.
- The graph challenger repaired none of the 24 frozen v3.83 Step errors.

The hypothesis is falsified. Literal producer-consumer edges proved that an
atom persisted, but did not establish that its producer Step owned the
benchmark's first critical boundary. The representation reduced v3.87's
proposal volume but did not improve gold-boundary recall or override precision.

## First-divergence audit

The 28 final errors contain 12 `anchor_error`, 6
`candidate_recall_failure`, 5 `false_candidate_admission`, 2
`false_challenger_override`, 1 `early_freeze_failure`, 1
`late_symptom_preference`, and 1 `annotation_ambiguity`.

The mechanism-specific failure is `literal_graph_false_root_override`:
literal value persistence was promoted as sufficient evidence of critical-root
ownership. Both accepted overrides of gold-exact fresh anchors were losses.
There were no graph-gold proposals for the arbiter to recover.

- Step error audit SHA-256: `f5e24f6dc66d2ae3452526c7ebc4277a84e34eadbadbc3a7c9fee8241be4cb21`.
- Cluster audit SHA-256: `f609b5e71fed199be43a39e352d14f463336fa4963ee099c87f11f7f817d775d`.
- Mechanism impact SHA-256: `aab2a2c4dd173c5bfcc1ffaf52fb00963b5b3223a8a6dc0c158d6d44a7388bb8`.
- Post-score builder SHA-256: `6082f309bc5ad327c7981cc3cd3cbd38d724fd417686a1f4e511df9ba5d3fafd`.

## Next falsifiable mechanism

Return to accepted v3.83. Keep its frozen anchor, earliest-causal challenger
contract, arbiter, and validators, but execute only the challenger stage with a
different model. This isolates heterogeneous reviewer evidence from further
prompt-topology changes: the test is whether an independent model recalls a
gold boundary that the GPT-5.5 anchor missed while the existing conservative
arbiter protects incumbent-correct anchors. No v3.86-v3.88 prompt, graph,
prediction, or scored artifact is inherited.

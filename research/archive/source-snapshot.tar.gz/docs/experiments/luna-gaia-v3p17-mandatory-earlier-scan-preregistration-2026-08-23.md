# Luna GAIA v3.17 Mandatory Earlier-Scan Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia-v3.17-mandatory-earlier-scan`
- Semantic parent: accepted
  `agentdebug.codex-agent-judge.luna-gaia-v3.14-earliest-causal-challenger`
- Rejected evidence version: v3.16 bounded bidirectional challenger, Step
  Exact `24/50`
- Current incumbent: v3.14, frozen GAIA-50 Step Exact `24/50`
- Original baseline: v3.4, frozen GAIA-50 Step Exact `21/50`
- Dataset/cohort: frozen `gaia-paper-v1`, 50 cases
- Dataset manifest content SHA-256:
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort file SHA-256:
  `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Cohort content SHA-256:
  `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Prediction manifest file SHA-256:
  `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Prediction manifest content SHA-256:
  `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Version acceptance: full GAIA-50 Step Exact `> 24/50`
- Goal completion: full GAIA-50 Step Exact `>= 30/50`
- Smoke gate: none

Step Exact is the sole optimization, comparison, acceptance, rejection, and
completion metric. Module, type, and evidence remain legality constraints only.

## Audited reason for this version

v3.16 opened a strictly earlier challenger search but left that search as a
free-text instruction inside the existing one-record challenger artifact. The
full run emitted 47 no-challenge records, three later challenges, and zero
earlier challenges. Its 26 errors contained only one gold Step in the complete
candidate set. Therefore the intended stage separation existed nominally but
did not create observable earlier-candidate recall.

The accepted v3.14 has eight errors in its fine-grained candidate-recall cluster,
all with a missed boundary earlier than the final anchor. v3.15's inline anchor
closure repaired only one of those eight and regressed eight incumbent-correct
cases. v3.16's optional independent earlier search proposed none. The next
smallest falsifiable change is to make the earlier comparison an auditable
artifact contract rather than add more semantic prose.

## Single major change

Keep the v3.14 anchor and its later earliest-causal fallback semantics. Add one
mandatory ordered `earlier_scan` ledger to the fresh challenger record.

For anchor Step `A`, the ledger must contain exactly one row for every Step
`1..A-1`, in strict order. Each row records:

- Step identity;
- `clear` or `proposal` status;
- boundary kind: `none`, `result_to_state`, or `target_to_action`;
- literal evidence Step and quote for a proposal;
- compact necessity, literal-boundary, path-effect, and decision bases.

At most one row may be `proposal`, and it must be the earliest qualifying row.
If an earlier proposal exists, the challenger must use that exact Step and
classify the anchor `downstream_symptom`. If every earlier row is clear, the
challenger may either keep the anchor or use the unchanged v3.14 later fallback.
The single-proposal maximum applies across both directions. The independent
arbiter remains default-keep and may copy only the exact anchor or exact single
proposal.

The validator enforces ledger coverage, order, row schema, proposal count,
direction/classification consistency, literal evidence ownership, and exact-copy
arbitration. It does not read gold and cannot require any particular Step to be
proposed.

No case identifier, entity/source-model rule, gold rationale, historical
prediction, score, or post-score audit is visible during inference.

## Falsifiable impact analysis

Expected repair surface: the eight frozen v3.14 fine-grained recall errors. The
mandatory rows make every pre-anchor packet observable in the challenger artifact
and directly test whether optional free-text search, rather than semantic
inability, caused v3.16's zero earlier proposals. Reaching the Goal requires at
least six net repairs over v3.14.

Primary regression surface: v3.14-correct cases with long traces, useful early
acquisition probes, repaired mechanical defects, or direct capability roots.
Explicit enumeration may cause candidate flooding, first-row bias, or speculative
handoff inference. Negative controls are:

- exactly one proposal maximum;
- every non-proposal row remains `clear` with null evidence fields;
- a proposal needs task necessity, a literal adjacent-packet mismatch, and path
  effect;
- successful scalar/string calls, harmless compression, normal tool results,
  initial useful probes, and materially different routes stay clear;
- arbiter defaults to anchor under uncertainty.

The mechanism is falsified if earlier recall remains near zero, if proposal rows
do not cover a common boundary class, or if incumbent-correct regressions erase
the repairs. This is exposed-cohort tuning, not an unknown-data claim.

## Offline validation and execution decision

Before the full run, require:

- compilation and workflow registration;
- exact v3.14 anchor semantics apart from version identity;
- prompt tests for full `1..A-1` ledger coverage and the unchanged later fallback;
- validator tests accepting legal zero-row, all-clear, earlier, and later records;
- negative tests for missing, duplicated, out-of-order, multiple-proposal,
  direction/classification, literal-evidence, and exact-copy violations;
- runner plan validation for 50 cases, 150 planned sessions, Luna medium, no
  smoke gate, and no prior predictions;
- source-input scan for labels, scores, case routing, old predictions, and
  post-score artifacts.

Then run all GAIA-50 cases directly, freeze predictions and every intermediate
artifact under gold-free validation, and score only after hash binding.

- Step Exact `<= 24/50`: reject and audit.
- Step Exact `25..29/50`: accept as the next incumbent only after all legality
  checks, then continue the version loop.
- Step Exact `>= 30/50`: complete the final legality/differential audit and mark
  the Goal complete.

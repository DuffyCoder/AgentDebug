# Luna GAIA v3.12-global 预注册

日期：2026-08-22  
状态：实现与执行前冻结

## 1. 起点与单一改动

本实验只以 `agentdebug.codex-agent-judge.luna-gaia-v3.4` 为基线。v3.4 在冻结的
`gaia-smoke-v1` 30 例上为 Step 16/30、Step+Module 10/30、All 7/30；在发布
`gaia-paper-v1` 50 例上为 Step 21/50、Step+Module 13/50、All 10/50。

v3.12-global 不继承 v3.5--v3.11 的 capability、repetition、claim 或 target-binding
语义规则。它只改变 v3.4 的搜索拓扑：

1. 候选阶段遍历完整轨迹的每个 `step × module`，不得在首个候选处停止；
2. 独立全局裁决阶段看到完整轨迹和冻结的全部候选，再选择 critical root step；
3. 独立最终阶段冻结该 step，重新完成同 step owner、type 和 literal evidence 绑定。

候选、裁决、最终绑定分别使用新的 Luna medium ephemeral session。推理阶段不读取
gold、旧预测、旧评分、case study 或本文件。

## 2. 预注册假设

主假设 H1：v3.4 的主要损失来自“首个存活候选立即冻结”的搜索拓扑；完整候选召回加
全局裁决会使 smoke30 Step exact 严格高于 16/30。

机制假设 H2：候选池对 gold step 的召回率高于最终 Step exact；若不是，瓶颈仍在局部
候选识别，而非全局裁决。

机制假设 H3：在 gold step 已被候选池召回的子集上，全局裁决的条件准确率可被单独
测量；它与 candidate recall 一起解释最终 Step 指标，不以事后规则修改掩盖失败。

## 3. 固定产物与验证

- `candidate-census.json`：完整 step 行和全部局部候选；每个候选绑定 step、module、
  legal type、literal owner evidence、局部 defect、最小修复、恢复状态和失败链。
- `global-selection.json`：逐候选全量 review，并通过候选池 hash 冻结输入；唯一被选候选
  必须被标为 locally valid、outcome material、unrecovered、critical root。
- `predictions.json`：标准十字段结果；`predicted_step` 必须等于全局裁决冻结的 step，
  module/type 可在该 step 内重新绑定，并继续通过现有 owner-source validator。

父进程对每阶段做 fail-closed、gold-free 验证。候选阶段必须覆盖所有轨迹 step；候选与
review 一一对应；阶段间使用稳定内容 hash，禁止 agent 修改上游产物。

## 4. 实验顺序与停止条件

### Gate A：离线结构验证

协议单测、validator 负例、任务 gold-isolation、runner `--execute` 前计划和相关回归测试
全部通过，否则不发起模型实验。

### Gate B：冻结 smoke30 开发集

对全部 30 例一次性执行统一协议，最多每阶段两次格式/验证重试。必须完成 30/30，才计
分。记录：

- candidate gold-step recall；
- final Step exact；
- selection accuracy given gold-step recalled；
- Step+Module 与 All；
- 相对 v3.4 的 early/late miss 变化。

晋级条件预先固定为：`Step exact > 16/30`。等于或低于基线即拒绝，不运行 GAIA-50。
Candidate recall 和次级指标用于解释，不可替代晋级条件。

### Gate C：发布 GAIA-50

仅 Gate B 通过后执行完全相同的冻结协议。晋级条件为 `Step exact > 21/50`；
Step+Module 与 All 作为次级指标报告。GAIA-50 已被用于既往分析，因此这里只能作为
release-tuning 对照，不能宣称未知数据泛化。

## 5. 禁止的事后操作

- 不按 case、来源模型、gold module 或历史错误类别路由 prompt；
- 不在看到 smoke30 评分后修改 v3.12-global 再沿用同一版本号；
- 不替换单条预测、不择优组合 v3.4 与新版本结果；
- 不因候选 recall 较高而忽略 Step 未超过基线的拒绝结论；
- 若要改变语义规则、模型、effort 或门槛，必须新建版本并重新预注册。


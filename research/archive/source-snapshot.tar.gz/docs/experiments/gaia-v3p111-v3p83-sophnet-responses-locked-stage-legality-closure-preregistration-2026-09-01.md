# GAIA v3.111 preregistration: locked-stage legality closure

Status: preregistered and unscored before any v3.111 benchmark request.

The semantic parent is the frozen accepted v3.83 (`gpt-5.5`, medium), Step
Exact 26/50. v3.110 is failure evidence, not a semantic parent: it scheduled all
50 cases but closed only 48 because one locked challenger prediction used an
illegal module/type pair and one locked no-challenge record contained a null
required explanation. No v3.110 prediction or per-case result is visible to
v3.111 inference.

The one major change from the clean v3.83 branch is a bounded, gold-free
locked-stage output-legality closure. Initial anchor, challenger, and arbiter
prompts retain the v3.83 decision semantics. Only after the original validator
rejects an artifact may a fresh stateless request receive an allow-listed code,
the already extracted Step/decision lock, and deterministic sources for that
same Step. The failed model output is not replayed. The host does not create,
unwrap, fill, normalize, or replace model fields.

For a locked challenger proposal, status, identity, ten-field shape,
module/type taxonomy, and literal evidence may be repaired only at the same
proposed Step. For a locked no-challenge, the three conditional fields remain
null and the five required explanation fields must be non-empty compact text.
The v3.110 decision-derived exact-upstream arbiter lock is part of this same
uniform legality mechanism: decision, selected Step, exact current-run upstream
prediction, and hash are immutable. Unknown codes, missing locks, or lock drift
terminate the case.

Frozen scope and execution:

- dataset identity
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`;
- cohort identity
  `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`;
- prediction-manifest identity
  `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`;
- direct stateless `POST https://api.sophnet.com/v1/responses`;
- 50 cases, three serial stages per case, four workers, at most five fresh
  semantic attempts per stage;
- no smoke gate, routing, prior predictions, gold, labels, conversation, or
  previous response ID.

Scoring is forbidden until 50/50 cases and 150/150 stages pass all original
v3.83 validators, request/usage/latency provenance, semantic-lock audit,
model/materialized envelope equality, secret scan, and gold-free tree freeze.
Acceptance is Step Exact >26/50; Goal completion is >=30/50. Step Exact is the
only version-selection metric.

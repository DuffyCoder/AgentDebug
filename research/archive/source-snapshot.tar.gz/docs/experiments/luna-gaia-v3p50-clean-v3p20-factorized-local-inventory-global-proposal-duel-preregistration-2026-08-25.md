# Luna GAIA v3.50 Clean-v3.20 Factorized Local Inventory Global Proposal Duel Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.50-clean-v3.20-factorized-local-inventory-global-proposal-duel`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Frozen accepted incumbent Step Exact: `25/50`
- Original v3.4 baseline Step Exact: `21/50`
- Version acceptance: `Step Exact > 25/50`
- Goal completion: `Step Exact >= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Frozen v3.20 predictions SHA-256: `9df734d95a7c338a9b8ce66fb4d91e16d69961d272ddcc926f7d11f3ddc8add8`
- Frozen v3.20 implementation SHA-256: `3e886325bf0a4b4d4a3e770071c0a36fe81dab2bebaf5015561ca828b6c2e4f9`
- v3.49 Step audit SHA-256: `c95816d5877cde06eb0c586065328205c9b35a9b89fa8b90b688b5d25d071154`
- v3.49 cluster audit SHA-256: `b8207e5f1c98dccd3114a497ff7ffb800ef1541ab5db680657612641ca621a06`
- v3.49 mechanism-impact SHA-256: `2461b5a9c53f29dae2089be1c478fb5ad4f5ccc5a842199940e63314c6930dff`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the sole optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module, type, and evidence remain legality constraints
only.

## Evidence from rejected v3.49

v3.49 completed and froze all 50 cases, passed every gold-free legality check,
and scored `25/50`. It tied rather than exceeded v3.20 and is rejected and
immutable. Relative to v3.20 it produced 20 both-correct, five gains, five
losses, and 20 both-wrong cases.

The fresh clean-v3.20 anchor scored `21/50`. Its one-pass anchor-blind global
proposal plus bounded duel produced six direct gains and two direct losses,
raising the final to `25/50`. The proposal named gold on 16 cases and on six
fresh-anchor-wrong cases. Every such useful proposal was selected: no final
error retained an available gold proposal. The duel is therefore not the main
bottleneck.

The fresh-anchor-plus-proposal post-score oracle was only `27/50`, below the
Goal. The complete error audit assigns 18 errors to
`anchor_error__global_proposal_recall_gap`, six to annotation ambiguity, and
one to a false challenger override. This falsifies further pairwise-duel tuning
as sufficient and identifies pre-compression candidate recall as the main
mechanism to test.

## Single major change

Keep the v3.20 anchor prompt, packet-state ledger, chronological freeze, model,
reasoning effort, prediction schema, and taxonomy semantically unchanged. Add
one paper-style factorized local-to-global proposal mechanism:

1. Five independent anchor-blind owner sessions review Memory, Reflection,
   Planning, Action, and System at every observable Step. Each freezes a
   validator-bound local-error inventory; it does not nominate or rank a
   critical Step.
2. One fresh anchor-blind global session receives only the five frozen local
   inventories and the trace. It compares all inventoried rows against the
   complete chronology, applies recovery/probe/mechanical/propagation/symptom
   vetoes, and exports at most one exact legal proposal.
3. One fresh bounded comparison receives only the unchanged v3.20 anchor and
   the max-one proposal. It emits an exact copy and defaults to the anchor under
   unresolved evidence.
4. Local inventories are evidence, not votes. Module count, row count,
   position, severity, repetition, Planning ownership, and forceful prose are
   never ranking signals.
5. A global proposal need not prove a later consequence when its literal
   current commitment is already incapable, false, constraint-violating, or
   target-mismatched. It must still reject normal negative results, recovered
   defects, mechanical repairs, faithful propagation, and downstream symptoms.
6. An initial probe is not an automatic anchor veto. A contributing-probe
   classification requires a literal positive contribution witness.

The major change is the factorized local-inventory-before-global-compression
topology. The implementation is a clean v3.20 branch. It does not import or
semantically parent any v3.21-v3.49 rejected protocol. Rejected experiments
provide only post-score evidence for this preregistered mechanism.

## Falsifiable predictions

The mechanism is supported only if:

- all five inventories prove complete Step coverage for their assigned owner;
- local sessions are anchor-blind and cannot select a final Step;
- the global session sees all and only the frozen inventories plus trace and
  exports at most one proposal;
- final output is an exact anchor or proposal copy;
- the anchor-plus-proposal post-score oracle is at least `30/50`;
- proposal gold recall exceeds v3.49's `16/50`;
- direct gains exceed direct losses; and
- final Step Exact exceeds `25/50`.

It is falsified if the factorization creates candidate flooding, local rows are
used as votes, global compression still yields an oracle below 30, late
symptoms or Planning dominate, gains do not exceed regressions, or final Step
Exact is at most `25/50`.

## Expected gains and regression risks

The primary expected-gain cluster is the 18 unambiguous v3.49 errors where both
the fresh anchor and sole one-pass proposal miss gold. Post-score trajectory IDs
remain confined to the audit and are not copied here or exposed to inference.

The principal risks are local-error flooding, a salient later defect suppressing
an earlier benchmark boundary, and proposal overrides on incumbent-correct
cases. The controls are five owner-scoped inventories, literal owner evidence,
explicit recovery records, one anchor-blind global proposal maximum, exact-copy
comparison, default keep, and validator-bound positive contribution evidence.

## Execution and acceptance protocol

1. Implement the clean-v3.20 anchor, five local inventories, global proposal,
   bounded comparison, validators, runner, and positive/negative tests.
2. Source-scan inference code for rejected-lineage protocol imports, case IDs,
   labels, metrics, scored artifacts, historical predictions, and routing.
3. Run offline validation only; do not run a smoke gate.
4. Execute all 50 cases with eight fresh serial sessions per case and at most
   four cases concurrently.
5. Freeze predictions and all intermediate artifacts only after 50/50
   completion and gold-free validation.
6. Load labels and score only after freeze.
7. Compare Step transitions, gains, and regressions to v3.20.
8. Accept only if Step Exact is greater than `25/50`. Complete the Goal only if
   Step Exact is at least `30/50` and every legality/freeze check passes.
9. Otherwise reject the immutable version, audit every Step error, and create
   the next clean branch from v3.20.

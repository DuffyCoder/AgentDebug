# Luna GAIA v3.52 预注册：module-factorized local-census proposal panel

日期：2026-08-26

## 冻结身份

- version：`agentdebug.codex-agent-judge.luna-gaia.v3.52-clean-v3.20-module-factorized-local-census-proposal-panel`
- semantic parent：`agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- accepted incumbent：Luna v3.20，Step Exact `25/50`
- original baseline：Luna v3.4，Step Exact `21/50`
- 数据集：冻结 `gaia-paper-v1` 50 例
- dataset content SHA-256：`fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- cohort content SHA-256：`193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- cohort manifest file SHA-256：`31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- prediction manifest file SHA-256：`77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- v3.20 parent source SHA-256：`3e886325bf0a4b4d4a3e770071c0a36fe81dab2bebaf5015561ca828b6c2e4f9`
- 模型：`gpt-5.6-luna`
- reasoning effort：`medium`
- 版本接受条件：完整、合法 GAIA-50 的 Step Exact `> 25/50`
- Goal 完成条件：完整、合法 GAIA-50 的 Step Exact `>= 30/50`
- smoke gate：无；离线验证后直接完整 GAIA-50

## 唯一主要机制变化

相对 v3.20 只增加一个机制：`module-factorized local census -> bounded
critical-proposal panel`。

每例使用六个 fresh、隔离 session：

1. 原样执行 v3.20 packet-state anchor；
2. 四个互相不可见且看不到 anchor 的模块 specialist，分别负责 Memory、
   Reflection、Planning、Action；
3. 一个 anchor-preserving exact-copy selector。

每个 specialist 对其唯一负责模块按时间顺序审查全部 Step，先输出逐 Step 的
local verdict，再从本模块的 positive local verdict 中压缩出至多一个完整合法
critical-boundary prediction。proposal 必须绑定一个本模块 positive row；local
negative、其他模块、未审查 Step 或新造 Step 均不能成为 proposal。四个 specialist
的 proposal 互不共享状态，不构成 vote。

selector 只可 exact-copy fresh v3.20 anchor 或某个冻结 proposal。它不得按 proposal
数量、模块身份、位置、措辞强度或多数选择；不确定时保留 anchor。override 必须同时
有 literal anchor causal-removal witness，以及 selected proposal 在 anchor-only
repair 后仍独立 critical 的同 Step literal evidence。

## 根因依据、gains 与 regressions

v3.20 的强项是 25/50 的保守冻结，主要错误则包含 7 个 candidate recall、3 个
early freeze 和 2 个 late-symptom failure。v3.39 的 typed challenger 对自己的
fresh anchor 有 3 direct gains、0 direct losses，但 max-one 且只向后的搜索令
anchor-plus-proposal oracle 仍只有 25/50。

论文/公开 AgentDebug 的差异是先保留 Step×Module 局部分析，再做完整轨迹全局
critical selection。公开 Phase 1 在评分后覆盖 35/50 gold Step，与 v3.20 的 union
oracle 为 43/50；但它也产生 457 个 positive Step，公开 Phase 2 只有 14/50。
因此高 local recall 是有效信号，跨模块自由 compression 和 candidate vote 是直接
反例。

v3.47/v3.48 证明新的 Luna local profile 能让 fresh-anchor-plus-profile oracle 达到
31/50 与 36/50，但把全画像一次性压缩/晋升只得到 19/50。v3.50 的五模块 inventory
再经单一 global compressor，更把 proposal gold recall 降到 11/50，final 15/50。
v3.51 的三个同质 global proposal 的 union oracle 只有 28/50，说明同 prompt 重采样
不能补足结构性 recall。

本版本只检验“把压缩责任按 module 隔离”能否保留论文式 recall，同时把候选池限制
为常数四。预期修复 v3.20 的 fine-grained recall、state/outcome handoff、Action
alignment 与部分 early/late boundary 错误。主要 regression 风险是 Planning 的
surface error、合理初始/不同 probe、已恢复 defect、忠实传播和晚期症状被压缩为
proposal，并在 selector 中推翻正确 anchor。

## 预注册 falsifiers

- raw module-local positive census 的 gold-Step coverage 未形成相对既有 Luna profile
  的召回证据；或
- fresh anchor + 四个 proposal 的评分后 candidate oracle `< 30/50`；或
- selector 对 fresh anchor 的 direct gains 不严格多于 direct losses；或
- final Step Exact `<= 25/50`。

任一成立即拒绝 v3.52；已评分版本不修改，incumbent 仍为 v3.20。candidate oracle、
module/type 分布与 selector 诊断只用于评分后根因判断，不参与版本接受。

## 继承与隔离纪律

- semantic parent 只有 v3.20；v3.21--v3.51 均不是 parent。
- v3.47--v3.51 只提供评分后 falsifier 和机制证据；不继承其 prompt、prediction、
  profile、proposal、selector、validator state 或逐例结果。
- 本版本从 v3.20 干净构造一个新的 module-factorized panel；对公开 AgentDebug 的
  local-analysis 原则是本次唯一移植机制，不读取其逐例预测。
- 推理阶段禁止 labels、metrics、scored artifacts、旧预测、错误报告、gold rationale、
  case routing、实体/来源特判与 git history。
- 所有 case 的六个 stage 完成并通过 gold-free schema/taxonomy/evidence/hash/order
  audit 后才评分；Step Exact 是唯一接受、拒绝与 Goal 完成指标。

## 推理前实现冻结

待实现、负例测试、50-case dry-run 与静态隔离检查全部通过后，在首次 GAIA-50
推理调用前补充 protocol、runner、registry 与 tests 的 SHA-256；补充仅记录冻结
事实，不改变上述假设或接受条件。

首次推理调用前的离线冻结结果：v3.20、v3.51 回归保护及 v3.52 正/负例共
`16 passed`；50-case dry-run 确认 50 例、每例六个隔离 stage、计划 300 个 session，
模型、effort、semantic parent、接受条件和 Goal 条件均与本预注册一致；静态扫描未
发现 label/scored/error-audit 路径、trajectory/source-model case router 或旧预测读取。

- v3.52 protocol SHA-256：`6285def35aaac263f9bef65392b6e9d4a3a1837e33c28013a26d62bced3dfa71`
- v3.52 runner SHA-256：`4627091d2778c205c3788e84572df8e0ac39af8c3da858434bbd0046cc38072c`
- workflow registry SHA-256：`51b22149e7c679a4361a96a9178041be611f91e08ec731e267388c35518148e6`
- v3.52 tests SHA-256：`6da477ba744fa06eab43926ed98e8e14f01febd210d043b106e53f03b6c95736`

# E9 v58 smoke cap-recovery v1 plan-policy failure case study

## Closed recovery attempt

The first formal cap-recovery command passed its frozen artifact, cache,
ledger, request-size, and request-hash checks, then stopped before any new
provider call. The source ledger remained exactly 24/44 and the Critic and
Reviewer caches remained at one completed batch each.

The local exception was:

```text
BatchedCausalWorkflowError: E9 batch-plan policy is unsupported
BatchedCriticWorkflowError: v14 batch plan is invalid
```

## Attribution

Recovery v1 implemented the 900,000 Critic ceiling by assigning
`_v13.MAXIMUM_REQUEST_CHARS = 900_000`. That constant is not confined to the
Critic preflight: the frozen smoke batch plan also binds the v13 policy whose
declared maximum remains 800,000. The first recovery boundary loaded the plan
before assignment and passed. The frozen smoke runner then loaded it again
after assignment and correctly rejected the policy mismatch.

No semantic hypothesis, heldout prediction, gold label, or model response was
produced by this attempt. This is a recovery-harness scope error.

## Recovery v2 hypothesis

Keep `_v13.MAXIMUM_REQUEST_CHARS` at 800,000 everywhere. Introduce a recovery-
local Critic request builder that is byte-for-byte equivalent to the frozen
builder except for its own 900,000 preflight. Before installation, reconstruct
all eleven requests and prove the same size vector and the same completed
batch-1 request hash. Install only that builder on the extracted workflow for
the formal run. Scout, Arbiter, batch-plan validation, prompt content, request
identity, provider configuration, cache keys, ledger, raw validation, gold
isolation, and scoring remain unchanged.

Recovery v2 requires a new code archive, preregistration, targeted tests, and
one complete repository test pass before another external call.

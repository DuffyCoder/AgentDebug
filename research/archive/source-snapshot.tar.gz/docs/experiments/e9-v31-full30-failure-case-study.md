# E9 v31 full30 failure case study

## Outcome

v31 passed dry3 at 2/3. Its full30 run was then interrupted while the final
batch request was in flight. The durable ledger conservatively contains all
ten allowed new logical completions, but the final request has no response
sidecar, raw cache, or parsed cache. The immutable partial output contains 27
successful rows and no row for the final three trajectories.

Per the frozen evaluation rule, all missing rows remain in the 30-case
denominator and count as wrong:

- Step Exact: 9/30 (30.00%; gate requires 12/30)
- Step+Module Exact: 4/30 (gate requires 3/30)
- Successful outputs: 27/30
- Failed/missing outputs: 3/30 (gate permits at most 1)
- New logical-completion reservations: 10
- Fully persisted new Critic responses: 9
- The first batch was a hit from the accepted dry cache

The formal run is rejected on both Step Exact and failed-output count. The
last request must not be resent inside the frozen v31 ledger because the
provider may have received it before the local process was interrupted.

## Execution attribution

The failure window is narrower than a parser or provider error:

1. the tenth full-run request was durably reserved;
2. the controlling execution session was interrupted before a response
   sidecar existed;
3. without a sidecar there is no authoritative response to recover;
4. conservative accounting correctly prevents an ambiguous duplicate call.

This is the unavoidable request-in-flight crash window. v32 must run to
completion without an external session interruption. It must retain the
conservative ledger rather than delete a reservation or pretend the call was
not made.

## Semantic attribution

The partial result also rejects the same-call pairwise hypothesis. Across the
27 persisted cases:

- final Step Exact was 9/27;
- `earlier_candidate_step` alone matched 7/27;
- `alternate_candidate_step` alone matched 6/27;
- the union of final, earlier, and alternate steps covered 13/27.

Four cases therefore contained the released tuning step in an explicit v31
candidate, but the same completion selected another step. Examples include a
later pot-substitution plan after a recoverable invalid navigation, a PDF
extraction failure versus a later memory omission, and two WebShop cases where
the alternate later decision was more directly task-closing than the early
list-paging concern.

This is evidence that candidate generation is now stronger than final
selection. Adding another fixed early/late preference would be an artificial
weight and would merely trade one subset of errors for another.

An additional post-run audit found that frozen v13 Scout candidates plus
their terminal reviews cover only 8/30 released tuning steps. Exposing Scout
alone is therefore not a sufficient next experiment.

## v32 optimization direction

1. Preserve v31's unscored two-candidate generation, strict source-ID
   evidence binding, terminal guard, first-defect audit, and 1024-character
   explanation limits.
2. Add a separate LLM selector completion. It receives the complete anonymous
   JudgeView and the raw-validated v31 candidate alternatives, challenges
   recovery and causal sufficiency, and emits the only final atomic tuple.
3. The selector receives no gold, historical correctness, scores,
   confidence, votes, numeric weights, or deterministic preference. It may
   reject all supplied candidates and select a fresh trace-grounded root.
4. Candidate-stage failure remains an explicit null input to the selector;
   selector failure produces an empty final diagnosis with no fallback.
5. Extend cache identity, raw reconstruction, telemetry, and topology gates
   to cover both live stages. Tuning uses two calls per uncached batch; held-out
   smoke uses fresh Scout, Arbiter, candidate, and selector calls.
6. Run dry3 before full30. Any further failed attempt again requires a case
   study before another external model attempt.

No v31 artifact or ledger may be mutated or rescored under v32.

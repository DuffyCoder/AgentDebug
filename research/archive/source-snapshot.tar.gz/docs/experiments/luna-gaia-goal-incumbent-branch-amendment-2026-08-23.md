# Luna GAIA Goal Incumbent-Branch Amendment

Effective 2026-08-23, this amendment updates the active Goal without creating a
new Goal or resetting any experiment record.

## Binding inheritance rule

- The accepted incumbent is
  `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`, frozen at
  Step Exact `25/50` with complete GAIA-50 legality validation.
- Every new experiment version must use that accepted incumbent as its direct
  semantic parent until a later complete and legal version scores strictly
  higher and is accepted.
- Rejected versions may supply post-score diagnoses and falsifiable mechanism
  hypotheses, but none of their protocol changes are inherited automatically.
- A mechanism originating in rejected lineage must be reimplemented as one
  isolated change on a clean incumbent branch.
- Gains, regressions, and acceptance are computed against the accepted
  incumbent. Frozen per-case incumbent predictions remain forbidden inference
  input and may be used only after scoring for transition analysis.

## Existing v3.27 disposition

v3.27 had already begun full inference when the amendment arrived. It was
therefore completed, frozen, validated, and scored without mutation. It remains
a rejected historical experiment and cannot be a semantic parent.

The clean follow-up directly branches from v3.20 and ports only the
prior-feedback capability-maturity gate. It removes every accumulated change
from v3.21 through v3.26, including typed state entailment, isolated or
bidirectional state challengers, mandatory state scans, isolated and
predecessor-aligned state ledgers, same-Step consumer witnesses, and their
validator/artifact contracts.

The Goal completion condition remains a complete, frozen, legal GAIA-50 version
with Step Exact at least `30/50`.


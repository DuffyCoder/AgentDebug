# E9 v53 dry3 runtime-path failure case study

## Failure

The first v53 dry3 `predict` invocation failed closed during preregistration
verification. The logical-completion ledger still contained zero entries and
the critic cache was absent, so no provider request was made.

The internal verifier reported:

```text
runtime v14 mode/selection/path/budget differs from preregistration
```

## Attribution

The command supplied `unscored-predictions.json`, while preregistration had
immutably bound the output to `unscored-predictions.jsonl`. All other selected
trajectories, provider settings, paths, and the two-completion budget matched.
The fail-closed guard therefore behaved correctly.

A secondary read-only diagnostic attempted to use `jq`, which is not installed
in this environment; the same files were inspected with standard text tools.
That diagnostic did not mutate artifacts or contact the provider.

## Correction and next attempt

Repeat `predict` with the preregistered `.jsonl` path. Do not change the v53
hypothesis, prompts, model settings, sample selection, gate, or budget. If the
corrected attempt reaches the provider, it may reserve at most the original two
logical completions because the current ledger has no entries.

# Luna GAIA v3.20 Packet-State Closure Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.14-earliest-causal-challenger`
- Frozen incumbent Step Exact: `24/50`
- Original v3.4 baseline Step Exact: `21/50`
- Version acceptance: `Step Exact > 24/50`
- Goal completion: `Step Exact >= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Frozen v3.14 predictions SHA-256: `fe5bcf0a07e5776b0b60d28da835c0bf8ed7f03fb0d7e3eb0a36fbea23835133`
- v3.19 Step audit SHA-256: `0e328c108984648e1f533dfd14b0afa2a7c3a007d93f80869cf5d2f38cbba910`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the only optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module/type/evidence remain legality constraints only.

## Post-score diagnosis motivating this version

v3.19 scored 20/50 and was rejected. Its 30-error audit is led by 10
fine-grained candidate-recall errors (6 High, 4 Medium confidence). Rechecking
the frozen v3.14 incumbent isolates five errors with one common first
divergence: the anchor clears a packet without closing the literal relation
between adjacent tool feedback and its Memory/Reflection state.

The missed boundaries include necessary result facts dropped from Memory,
unsupported entity-to-fact links introduced into state, and Reflection claims
of success/progress contradicted by the adjacent result. Later selected Steps
are downstream plans or repeated instances of the same false state. Earlier
challenger experiments did not recover these packets, so this version modifies
anchor admission only.

## Single major change

Add one validator-audited packet-state closure gate before all existing v3.14
lane decisions. Every ledger row begins:

```text
state_scope=<memory_reflection|none>;
state_fidelity=<faithful|dropped_necessary_fact|unsupported_fact|outcome_misread|not_applicable>;
```

The contract is:

1. Use `state_scope=memory_reflection` when the packet contains Memory or
   Reflection text that retains or interprets the current information state;
   otherwise use `none` with `not_applicable`.
2. `dropped_necessary_fact` requires a concrete fact in the adjacent result
   that is necessary for the unresolved subgoal or next decision and is omitted
   or materially distorted in the retained state. Ordinary compression,
   wording changes, and facts still available to the next decision do not
   qualify.
3. `unsupported_fact` requires a new task-material entity, credential, value,
   or relation asserted by Memory/Reflection with no support in the visible
   observation/history. Harmless speculation not retained downstream does not
   qualify.
4. `outcome_misread` requires a success, failure, progress, or constraint claim
   literally contradicted by the adjacent result.
5. Any non-faithful status is admitted through Lane A only when the false or
   lost state feeds the current/next plan and repairing it can change the later
   path. Lane A must be `candidate` for such a row.
6. `faithful` requires Lane A `clear`; all capability, system, repeated-strategy,
   initial/different-probe, recovery, and causality rules then run unchanged.
7. The first surviving row remains frozen immediately. The existing single
   later challenger and default-keep exact-copy arbiter are unchanged.

No acquisition contribution gate, hard-disqualifier taxonomy, global selector,
candidate pool, earlier challenger, case router, entity/site rule, historical
prediction, or gold information is added.

## Falsifiable prediction

The mechanism should recover observation-to-state boundaries without flooding
the ledger with stylistic summary differences.

Post-score expected direct coverage is five v3.14 errors. Observable checks:

- every anchor row has a valid two-field state prefix;
- every non-faithful row has Lane A `candidate`;
- every faithful Memory/Reflection row has Lane A `clear`;
- every `none` scope pairs with `not_applicable`;
- at least one full-run row exercises a non-faithful state admission;
- Step Exact gains exceed losses relative to v3.14 and the result exceeds
  `24/50`.

The hypothesis is falsified if no non-faithful row fires, if benign compression
creates early candidate flooding, if the five audited state boundaries remain
absent, or if Step Exact is `<= 24/50`.

## Gain and regression analysis

Expected gain cases from post-score analysis:

- a rich result whose necessary titles/values are lost in Memory;
- a result incorrectly called successful progress in Reflection;
- an unsupported entity-to-credential/value relation retained into planning;
- a result-state omission that causes a later substitute or tool choice.

Primary regression risks:

- treating harmless summary compression as a dropped necessary fact;
- promoting a locally false but causally irrelevant phrase;
- mistaking an explicitly marked hypothesis for a retained unsupported fact;
- over-weighting Memory/Reflection and shifting selection systematically early.

The literal adjacent-result requirement, task-materiality test, downstream-use
test, closed status set, and validator-enforced Lane-A relation limit those
risks. The rule is uniform and does not depend on trajectory IDs, entities,
sites, source models, or fixed Steps.

## Execution and acceptance protocol

1. Implement the versioned prompt, state-prefix/status validator, runner, and
   negative tests.
2. Run offline tests and source scans only; do not run a smoke gate.
3. Execute all 50 frozen cases with three fresh serial sessions per case and at
   most four cases concurrently.
4. Freeze all predictions and intermediate artifacts after 50/50 completion and
   gold-free validation.
5. Only then load released labels and score all 50 cases.
6. Compute Step Exact and transitions against v3.4 and v3.14.
7. Accept only if Step Exact is strictly greater than `24/50`; complete the Goal
   only if it is at least `30/50` and every legality/freeze check passes.
8. Otherwise reject the immutable version, audit every Step error, and create a
   new version from one next unified mechanism.

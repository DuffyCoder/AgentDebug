# E9-v18 Conservative LLM Prior Review

E9-v18 keeps the DeepSeek V4 Flash default request body and changes only the
semantic Critic prompt. The frozen v13 Arbiter diagnosis is now an incumbent
LLM judgment: the final LLM keeps it when it remains supported and replaces it
only when a materially stronger timeline-grounded challenger survives the same
ownership, evidence, recovery, and counterfactual checks.

The general tuning hypotheses are:

- a fixed step limit can remain the root when the agent is still exploring
  plausible new states and no earlier output satisfies a taxonomy defect;
- action misalignment may be an operationally incapable target/source even
  when the same-step plan literally names that operation, but irrelevant
  search results alone do not prove incapability;
- a materially refined query starts a new search episode; inefficient planning
  begins only after several results in that episode already establish a stalled
  policy and the plan still recommits without adaptation;
- planning evidence must quote planning text, never the action command.

No deterministic code keeps or replaces the prior. The final tuple remains
solely the raw LLM Critic output. The dry3 development gate is restored to the
original role of a signal gate: at least 2/3 Step, Step+Module, and All Correct,
with all three outputs valid. Full30 and smoke30 remain fixed at 12/30 Step.

The cumulative budget is dry 366 to 367, full 367 to 377, and future fresh
smoke 377 to 410. Current authorization 380 covers dry and full only.

## Mandatory failure-learning loop

Every model-backed attempt that misses its preregistered promotion or
acceptance gate must stop before another attempt is made.  The next action is
one case-study round over the failed cases, not an unchanged retry.  The case
study must record:

1. the expected root and the raw LLM root for every failed case;
2. whether the failure is transport, parsing, evidence validation, taxonomy,
   step localization, module ownership, or error-type classification;
3. the exact trajectory evidence that supports the attribution;
4. the shared failure pattern and its most plausible prompt, protocol, model,
   or data-representation cause;
5. one bounded, falsifiable optimization hypothesis and the cases it should
   change or preserve;
6. the next experiment's preregistered success criterion and call cost.

An optimization may be attempted only after this record exists.  The next
attempt must use a new immutable protocol/cache identity and must test the
recorded hypothesis.  A transport or malformed-output retry is also an
attempt: first attribute the failure, then change a relevant condition or
document why an exact retry is the diagnostic experiment.  Offline test
failures do not consume an LLM attempt, but they must be fixed before an
experiment is frozen.

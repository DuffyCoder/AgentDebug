# Luna GAIA v3.79 pre-registration

## Frozen identity

- Protocol: `agentdebug.codex-agent-judge.luna-gaia.v3.79-clean-v3.20-outcome-conditioned-predicate-handoff-tournament`
- Semantic parent: accepted incumbent `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Incumbent Step Exact: `25/50`
- Original v3.4 baseline Step Exact: `21/50`
- Dataset: frozen `gaia-paper-v1`, 50 cases
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Acceptance: legal full-50 Step Exact `>25/50`
- Goal completion: legal full-50 Step Exact `>=30/50`
- Smoke gate: none

v3.79 is a clean direct child of v3.20. It does not inherit the v3.78 local
inventory, pairwise selector, prompts, intermediate decisions, or predictions.
Owner-explicit response-only runtime and same-Step owner/evidence materialization
are legality-only infrastructure and cannot change the model-selected Step.

## Frozen v3.78 diagnosis

v3.78 legally completed and froze 50/50 cases and scored `22/50`; it is rejected.
Its fresh anchor scored `23/50`. Relative to frozen v3.20 it produced one gain and
four losses. Its native ledger and complete reviewed set covered gold in `33/50`,
but the selector made only two prefix overrides: zero direct gains, one direct
loss, and one wrong-to-wrong change.

The 28 errors split into 15 later-boundary recall failures, six cases where gold
was already reviewed but rejected, three fresh-anchor sampling regressions, three
annotation ambiguities, and one false override. In most of the six reviewed-gold
failures, the frozen local stage called the released boundary a reasonable probe,
normal failure, or no local material error. The defect-only protocol therefore
faithfully applied a benchmark-misaligned permanent probe veto; final ranking
alone cannot recover those boundaries without changing the boundary definition.

## One semantic mechanism

The only major change relative to v3.20 is:

> Outcome-conditioned exact-predicate handoff tournament over every native v3.20 ledger Step.

The unchanged fresh v3.20 stage supplies its anchor, native ledger, and checkpoint.
One fresh tournament stage reviews every and only ledger Step and chooses exactly
one winner. A probe's initial reasonableness is treated as a prior, not a permanent
veto. It matures into an `unresolved_predicate_handoff` only when the exact task
predicate/source/modality is already identifiable, the Step's actual observed
outcome leaves it unresolved or partial, and the subsequent failed path propagates
that same gap through repetition, unsupported inference, premature answer, or
delayed repair. A concrete earlier local defect may also win.

The tournament rejects an informative probe followed by independent progress,
prompt effective repair, recovered defects, faithful propagation, normal failures
without a handoff, and downstream symptoms. Exactly one reviewed Step must have
`boundary_verdict=true`; a prefix winner exact-copies a same-Step legal prediction,
while an anchor winner exact-copies the entire anchor.

There is no later slot, no new candidate recall, no Step-by-Module matrix, no
historical prediction, and no result composition. This version isolates only the
benchmark-boundary effect of observed probe outcome and same-gap propagation.

## Falsifiable gains and regressions

Expected gains are the six v3.78 failures where gold was already a native-ledger
Step but defect-only admission under-promoted it, especially when a reasonable
acquisition outcome handed an unresolved exact predicate into later speculation
or repetition. This is one uniform temporal rule, not a case/entity/source rule.

The direct regression set is every incumbent-correct case with an earlier ledger
row. v3.78 had 27 such prefix rows, many reasonable probes or normal negative
results. A too-permissive outcome rule could therefore create early-probe false
positives and erase v3.20's precision. The explicit same-gap propagation,
informative-progress, prompt-repair, recovery, independent-branch, and downstream
vetoes are the uniform controls. The mechanism is also prefix-limited, so it
cannot address the 15 later recall failures in this version.

All gains, regressions, acceptance, and rejection are computed only against
frozen v3.20. Step+Module, All Correct, module/type distributions, and v3.78
predictions cannot influence selection.

## Frozen inputs and sources

- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort membership SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Semantic prediction-manifest SHA-256: `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`
- Protocol SHA-256: `bdb1350f1c1527fb128f91920b067427c930a6bfc6cf595e8c3977bcce042433`
- Runner SHA-256: `5a9bf829293c1413a20fecbbcca1e136208bd76d136a128465f99a438d3c8d92`
- Access auditor SHA-256: `bfb9199849de8f927ff58655a3c67db526a2c42834034ab0477c8aabf7111f55`
- Registry SHA-256: `515bebd2e4d8204142605162fc5a101ee863a5352aa21d180281037c23c7261e`
- Targeted tests SHA-256: `a5b7e6106f22288be40f882043530f3dbe183cb31db963f2e175cb6f6b41440d`
- Prepared case inputs: exactly 50 under `output/gaia-paper-v3p79-case-inputs`

These inference sources are frozen at execution. Any subsequent semantic source
change invalidates v3.79 and requires a new direct-incumbent version.

## Offline verification and execution contract

- Python compilation, registry import, and 21 targeted/adjacent tests passed.
- Negative tests require a unique winner, reject resolved/non-handoff winners,
  preserve model-selected Step, and verify the inherited two-stage runtime
  interface without inheriting rejected semantic outputs.
- Prepared scope is exactly 50 cases and 100 planned isolated semantic stages.
- Run fresh v3.79 directories only, without smoke or prior predictions.
- Require 50/50 cases, 100 successful semantic stages, all schema/taxonomy/
  evidence validators, passing owner-explicit read-only access/write audit, no
  routing, no prior predictions, and a complete gold-free freeze before scoring.
- Accept only above `25/50`; complete only at `>=30/50`. Otherwise reject v3.79
  unchanged, produce the full first-divergence audit, and branch the next version
  from the then-current accepted incumbent.

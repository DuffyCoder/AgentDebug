# Luna GAIA v3.29 Clean-v3.20 Acquisition-Anchor Zero-Contribution Challenger Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.29-clean-v3.20-acquisition-anchor-zero-contribution-challenger`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Frozen accepted incumbent Step Exact: `25/50`
- Original v3.4 baseline Step Exact: `21/50`
- Version acceptance: `Step Exact > 25/50`
- Goal completion: `Step Exact >= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Frozen v3.20 predictions SHA-256: `9df734d95a7c338a9b8ce66fb4d91e16d69961d272ddcc926f7d11f3ddc8add8`
- v3.20 Step audit SHA-256: `b1c0647d5081a85f469027152ad9d29d674d4fdb8db520cfaed43ddf5921f550`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the sole optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module, type, and evidence remain legality constraints
only.

## Incumbent diagnosis and rejected-lineage evidence

The v3.20 audit has seven acquisition-capability false positives. Every one is
High-confidence and first diverges at `false_candidate_admission`. Their common
defect is projection of the final proof predicate onto an intermediate
acquisition route that could still supply a necessary identifier, page, source,
text, transcript lead, or other immediate-subgoal clue.

Two rejected delivery mechanisms have already failed:

- v3.18 placed a broad contribution veto directly in anchor admission and
  scored 22/50 against its 24/50 parent.
- clean v3.28 placed a prior-feedback maturity gate directly in the v3.20
  anchor and scored 19/50, with 4 gains and 10 losses against v3.20.

Those experiments falsify broad anchor rewrites for this cluster. They do not
test an incumbent-preserving, one-proposal challenger whose only job is to
require literal zero contribution before ratifying an acquisition anchor as a
hard capability root.

## Single major change

Keep the v3.20 packet-state anchor, its chronological stop rule, its ledger and
checkpoint contracts, and the default-keep exact-copy arbiter semantically
unchanged. Change only the existing later challenger:

1. It must classify the anchor with a machine-validated prefix in
   `anchor_falsifier`:

   ```text
   anchor_boundary_kind=<acquisition_probe|other>;
   anchor_contribution=<possible|observed|zero|not_applicable>;
   ```

2. `other` pairs only with `not_applicable`.
3. For an acquisition anchor, `observed` means its packet supplied a
   task-relevant intermediate; `possible` means literal interface/corpus and
   chronology evidence do not rule out such contribution; `zero` requires
   literal proof that even successful use cannot expose a necessary
   intermediate for the immediate unresolved subgoal.
4. `possible` or `observed` forbids `critical_root`/`uncertain`: the challenger
   must classify the anchor as `reasonable_probe` or
   `noncritical_predecessor` and perform the incumbent later-only chronological
   search.
5. `zero` does not force an override. Exact dynamic-media/static-interface and
   interactive-predicate/static-corpus boundaries remain representable as
   critical roots when the required identity-bearing predicate is already
   known and no intermediate contribution is possible.
6. The challenger still emits at most one strictly later proposal. The arbiter
   still defaults to the anchor and may accept only an exact challenger copy
   after the existing path-intervention and earliest-boundary checks.

No anchor rule, packet-state prefix, Lane A/B/C semantics, candidate pool,
earlier challenger, global selector, model, effort, case router, historical
prediction input, or result splice is added. No v3.21-v3.28 prompt, ledger,
challenger, maturity, or validator contract is inherited.

## Falsifiable prediction

The mechanism is intended to recover later critical boundaries hidden behind
the seven v3.20 acquisition false positives without perturbing the v3.20
anchor itself. It is supported only if:

- every challenger record has a valid boundary/contribution prefix;
- every acquisition `possible`/`observed` record uses a probe/predecessor
  anchor classification;
- at least one acquisition `possible`/`observed` anchor produces a later
  challenge during GAIA-50;
- accepted challenger Step gains exceed losses relative to v3.20; and
- overall Step Exact exceeds 25/50.

It is falsified if no target anchor is reclassified, no later proposal is
recalled, hard-capability anchors regress, the challenger creates broad later
drift, or Step Exact is at most 25/50.

## Gain and regression analysis

Expected gain cluster (post-score IDs remain only in this preregistered analysis
record and are never exposed to inference):

- `GPT-4o_001_memory_b000_t00_e00-7743eba0`
- `GPT-4o_010_memory_b001_t00_e02-8d639e26`
- `GPT-4o_014_memory_b001_t00_e06-71f77595`
- `Llama3.3-70B-Turbo_001_memory_b000_t00_e00-7743eba0`
- `Llama3.3-70B-Turbo_008_memory_b000_t00_e09-f0557a9f`
- `Llama3.3-70B-Turbo_011_memory_b001_t00_e02-8d639e26`
- `Qwen3-8B_014_memory_b001_t00_e04-5e8c1dcf`

Incumbent-correct regression risks:

- `Llama3.3-70B-Turbo_014_memory_b001_t00_e05-c9015705`
- `Qwen3-8B_001_memory_b000_t00_e00-7743eba0`
- `Qwen3-8B_003_memory_b000_t00_e02-8d639e26`
- `Qwen3-8B_012_memory_b001_t00_e02-8d639e26`

The change should move only acquisition anchors later. It can regress if the
challenger invents hypothetical contribution for a route whose literal
interface cannot expose the already identified predicate, or if a possible
intermediate is treated as sufficient to erase an independently critical
anchor. The `zero` control, one-proposal bound, later-only direction, exact-copy
selection, and default-keep arbiter are the regression controls.

## Execution and acceptance protocol

1. Implement the challenger prefix, validator, clean-v3.20 runner, and positive
   and negative tests.
2. Verify that the generated anchor task is semantically v3.20 except versioned
   paths, and source-scan v3.29 inference code for rejected-lineage imports,
   case IDs, labels, metrics, and historical predictions.
3. Run offline tests only; do not run a smoke gate.
4. Execute all 50 cases with three fresh serial sessions per case and at most
   four cases concurrently.
5. Freeze predictions and all intermediate artifacts only after 50/50
   completion and gold-free validation.
6. Load labels and score only after the freeze.
7. Compare gains and regressions to accepted incumbent v3.20.
8. Accept only if Step Exact is greater than 25/50. Complete the Goal only if
   Step Exact is at least 30/50 and every legality/freeze check passes.
9. Otherwise reject the immutable version, audit every Step error, and create
   the next clean branch from the accepted incumbent.

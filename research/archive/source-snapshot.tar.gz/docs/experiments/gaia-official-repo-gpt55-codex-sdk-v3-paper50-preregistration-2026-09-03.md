# Official AgentDebug GPT-5.5 Codex SDK v3 GAIA-50 preregistration

Status: preregistered and unscored. This is a reporting-only experiment; it is
not a Luna-lineage candidate and cannot complete the active optimization Goal.

## Parent and sole mechanism

The semantic parent is frozen
`agentdebug.codex-agent-judge.gaia-official-repo-gpt55-codex-sdk-v1`.
The parent supplies only the frozen public source, prompts, topology, model,
reasoning effort, and audited SDK transport semantics. No prior call, Phase-1
result, prediction, or inference output is read or reused. V3 runs all 50 cases
from a clean output directory.

The only new mechanism is a protocol-local bridge between the public
`ErrorDefinitionsLoader` output contract and the repository's prediction
schema. The public detector has 19 positive module/type pairs across six
modules; the exact ordered mapping includes native `others/others`. V3 keeps
the public analyzer's returned Step, module, and type unchanged. It does not
map `others` into an internal module, replace a sentinel, repair an illegal
pair, or draw a new Phase-2 sample.

The frozen ordered taxonomy hash is
`687d9213f72b069051a926f1f8a35658447474b74b64977b3c505f22ed3c5508`.
At runtime the hash-verified official `error_definitions.py` is imported from
the new run's source snapshot, its mapping is reconstructed from
`ErrorDefinitionsLoader`, and mapping, order, pair count, and hash must all
match the preregistration before inference continues.

## Minimal evidence bridge

Memory, Reflection, Planning, Action, and System keep the parent's exact
strict-owner evidence policy. Only `others/others` needs a virtual owner because
`others` is a public classification bucket rather than an internal tagged
module. Its owner is exactly the text visible for the selected Step in the
public Phase-2 Step summary:

- the full assistant output;
- the first 500 characters of the immediately following message, only when
  that message is a user message.

The separate JudgeView `current_input`, tool argument/result details,
stop/error fields, non-immediate feedback, and feedback bytes after 500 are not
owners. This prevents the bridge from broadening evidence beyond the frozen
public prompt. A pre-Phase2, gold-free conformance audit compares every
JudgeView Step to the raw public prompt projection. Formal GAIA-50 execution
requires exact assistant bytes and exact bounded immediate feedback for all
717 Steps.

For a legal `others/others` result, a literal public Phase-2 evidence string is
used when possible; otherwise a deterministic literal excerpt from the exact
virtual owner is the legality fallback. This fallback changes evidence only.
Step/module/type remain the raw public selection. There is no Phase-1
`others` branch in the frozen official source. For the other five modules, the
parent normalizer and owner policy remain unchanged.

The native taxonomy comparison is exact and case-sensitive. Any altered-case
module or type is terminal rather than normalized, so every accepted prediction
preserves the official analyzer's raw module/type bytes.

The following are terminal and cannot trigger semantic resampling: missing
critical result; boolean, non-integer, or out-of-range Step; unknown module or
type; an operationally impossible final Step-1 Memory/Reflection result;
`no_error`; illegal module/type pair; or missing strict selected owner source.
Public parser sentinels such as `unknown/parse_error`,
`unknown/analysis_error`, and `unknown/analysis_failure` therefore fail closed.
Step 1 `others/others` is legal because the frozen public operational contract
permits it. The public analyzer's own Step-1 Memory/Reflection retry remains;
there is no runner-level Phase-2 retry.

## Frozen source, scope, and transport

The public repository snapshot is commit
`7740fe3a5c4822b2143cbde78ecfffeace0bb166`:

- `fine_grained_analysis.py`: `b640537ba4ba3232d9def59ad6d5c7bc1e3bcb2ddc9f07f25e6081586a2712fd`
- `critical_error_detection.py`: `7791fc671eef2b8a1296131ce7a9ef68bbcaa63d518b1e17ab5bc08b9dcecb4c`
- `error_definitions.py`: `415ced442e998133d23526d05064eef908a8e4df50519d7355af12e838d9d9bb`

The frozen scope is the 50-case `gaia-paper-v1` cohort, dataset identity
`fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`,
with 717 assistant Steps. Parent Phase 1 remains exactly 3,202 successful
calls: 2,768 normal module checks and 434 conditional System checks. Phase 2
uses one to three public calls per case solely under the public internal retry,
so a completed run has at least 3,252 successful calls.

Model and transport remain requested `gpt-5.5`, medium reasoning,
`openai-codex==0.147.0`, bundled CLI `0.147.0`, and local ChatGPT
authentication. Temperature is unsupported and not sent. Every public LLM
call uses a fresh ephemeral thread. The stable Responses wire-contract hash is
`79f6d3c17385f550cc19ca434f2e41055029315ef03224bf0562b593599967bd`;
the visible-tool schema hash is
`c33cfea2ab4eb8f8aa8a99c4dba2c55e2fc80f1fe3537845b1ec4c4e011770be`.
Any actual tool or harness item fails the run.

## Freeze and scoring boundary

Completion requires 50/50 predictions, exact Phase-1 count, bounded public
Phase-2 calls, 717/717 projection conformance, unique SDK thread and turn IDs,
zero tool items, exact schema/order/identity, native taxonomy legality, and
strict selected-owner literal evidence. The protocol-local validator returns
the standard four freeze booleans plus the native owner/taxonomy audit facts.
The full gold-free tree is frozen and reverified before the scorer first reads
released labels. Module/type remain reporting fields; this experiment does not
change the active Goal's Step Exact metric.

## Commands

```bash
.venv/bin/python -m scripts.run_agent_judge_gaia_official_repo_gpt55_codex_sdk_v3_paper50 --official-repo /path/to/AgentDebug-official
.venv/bin/python -m scripts.run_agent_judge_gaia_official_repo_gpt55_codex_sdk_v3_paper50 --preflight-only
.venv/bin/python -m scripts.run_agent_judge_gaia_official_repo_gpt55_codex_sdk_v3_paper50 --execute --official-repo /path/to/AgentDebug-official --max-concurrency 4 --max-transport-attempts 3
```

Only for an interrupted, identical v3 run:

```bash
.venv/bin/python -m scripts.run_agent_judge_gaia_official_repo_gpt55_codex_sdk_v3_paper50 --execute --resume --official-repo /path/to/AgentDebug-official --max-concurrency 4 --max-transport-attempts 3
```

# Luna GAIA v3.68 预注册：exact-predicate reducer + compact embedded input

状态：执行前冻结。

## 冻结实验合同

- semantic parent：accepted Luna v3.20，Step Exact `25/50`。
- 版本：`agentdebug.codex-agent-judge.luna-gaia.v3.68-clean-v3.20-exact-predicate-acquisition-boundary-reducer-compact-embedded-input`。
- 数据集：冻结 `gaia-paper-v1` 50 例。
- 模型/effort：`gpt-5.6-luna` / `medium`。
- v3.4 基线：Step Exact `21/50`。
- 接受：合法完整 GAIA-50 Step Exact `>25/50`。
- Goal 完成：合法完整 GAIA-50 Step Exact `>=30/50`。
- 无 smoke 门控；直接完整 GAIA-50。

唯一主要语义机制仍是从 v3.20 clean branch 移植的 `exact-predicate acquisition
boundary reducer`。它最多提出一个 earlier probe-veto row 或一个 later mature boundary，
只有 capability、actual exact-predicate outcome、contribution、later relation、local repair
和 recovery gate 全部成立才 exact-copy candidate；否则 exact-copy fresh v3.20 anchor。
Module/type 只用于合法输出。

本版本不继承任何 rejected proposal/panel/census/challenger/arbiter/selector 组合。v3.66 和
v3.67 只提供运行失败证据及本次显式重检的同一个单一机制；semantic parent 始终是
v3.20，推理不读取 v3.20 或任何历史逐例预测。

## v3.67 runtime first divergence

v3.67 完成全部 50 个 case 尝试但 0 例通过 anchor validator，未合并、未读 gold、未
评分。只读 sandbox 的每次模型侧文件读取均因本机 `bwrap: loopback: Failed
RTM_NEWADDR: Operation not permitted` 失败；50 例最终都表现为派生的
`invalid_evidence_ownership`。该结果只证伪模型侧 read-only file access，不证伪
exact-predicate 语义机制。

## 唯一非语义运行修正

父进程把完整 JudgeView 变成单副本 chronology 并嵌入 prompt，模型不调用任何工具：

- task、execution facts、全部 Step、每步 `assistant_raw_output`、module span offsets、
  feedback-after-step、System evidence source 全部保留；
- 逐例验证证明 Step n+1 的 current input 与 Step n 的 adjacent feedback 完全相等，因此
  只保留一次；
- owner literal text 不再与 `assistant_raw_output` 重复保存，可由 offsets 确定性切片；
- trajectory identity/status 仍由父进程绑定；inactive `none` 字段仍只做确定性规范化；
- 两阶段仍使用 JSON Schema response、read-only sandbox 和父进程 artifact materialization；
- 评分前要求 stdout 中工具事件为 0，case tree 只含白名单文件，同 case 两阶段 compact
  document hash 一致。

50 个 anchor prompt 的长度范围为 `31,444--812,998` 字符，全部低于 CLI 上限
`1,048,576`；信息删除只涉及已验证的重复表示，不改变 Judge 规则或可观察时间线。

## gains、regressions 与判伪

预期 gain 仍来自 earlier ledger probe 在实际 outcome 后无法获得 active subgoal exact
predicate、而 anchor 只重复/传播同一缺口的统一簇。主要风险是把能提供必要 identifier
或 source lead 的合理 probe 过早升级，或把 later symptom 错当独立 mature boundary。

若 candidate union oracle `<30/50`、相对 frozen v3.20 gains 不大于 losses、final Step
Exact `<=25/50`，或 50/50、schema、taxonomy、evidence、hash、gold-free、tool-free、
write-topology 任一验证失败，则拒绝。只有合法 `>=30/50` 才完成 Goal。

## 执行前冻结哈希与离线验证

- protocol：`6d39e4da70d785ed611a267f275e743e6b8f5073fdb4d174a17b39fec3950547`
- runner：`ef8a0fc4723b4470518c0c3457f595250b2dade8df94f1c776d854277b625aa6`
- registry：`8081a6f7fd154ebb5938c7ed2b9fb5461bc7de5781232462a6934de989fc391c`
- taxonomy：`d7e4b878059bbecec0a8fd3f078c0aeb5755bf9e65bb938c897dd83685f28c5c`
- tests：`d2aff41bab808ef1635d9db155bf60a19785c3b64e04fe2a3a91b6e6f4cbc4e6`
- access auditor：`7d0d751709f9839bac10cdb848cce02fec316a27e10919d344878f777421af4c`
- semantic parent v3.20：`3e886325bf0a4b4d4a3e770071c0a36fe81dab2bebaf5015561ca828b6c2e4f9`
- prediction manifest：`77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- cohort：`31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`

离线验证：v3.68/v3.67/v3.66/v3.20 相关测试 `24 passed`；compile、registry、50-case
dry plan、100 sessions、direct parent、prompt-size 上界全部通过。


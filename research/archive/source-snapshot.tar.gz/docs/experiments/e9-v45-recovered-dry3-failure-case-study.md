# E9 v45 recovered dry3 semantic failure case study

## Outcome

The exact missing v45 Selector was recovered under a separately
preregistered one-call protocol. The reconstructed request SHA-256 remained
`4fadfc5080530223bcc88f9077c64cd9ede5a353f3758f79c7b1a9c35b6ab989`;
the original candidate and Selector prompts were unchanged. The recovered
Selector completed with one HTTP attempt, zero retries, 191,436 input tokens,
9,508 output tokens, and finish reason `stop`.

After materializing the original v45 prediction chain from the exact two
successful cached responses, dry3 scored:

- Step Exact: 1/3;
- Step+Module Exact: 1/3;
- All Correct: 1/3;
- successful outputs: 3/3;
- failed outputs: 0/3;
- semantic mutations: zero;
- completed candidate-plus-Selector telemetry: 381,615 input tokens, 30,885
  output tokens, and 412,500 total tokens.

The promotion decision
`cc8f9220071576ccd44fd3d5465fd9a5bf581fd891c9a5bd6be2631b676ececd`
is rejected. v45 must not advance to full30 or smoke.

The separate recovery ledger conservatively advances cumulative logical-call
authorization from 541 to 542 because the interrupted original Selector was
already reserved even though no response was persisted. Any next semantic
experiment starts after 542, not 541.

## Case study

### C01: categorical novel-search boundary succeeds

The released root is step 30 `system/step_limit`. The candidate set includes
that tuple twice plus an earlier step-8 planning alternative. The v45
Selector applies the new boundary check correctly: opening distinct unvisited
cabinets remains feasible novel coverage, while redirecting to some other
unknown receptacle does not prove that one corrected output prevents failure.
It selects step 30 `system/step_limit`, exactly matching step, module, and
type.

This validates the first half of the v45 hypothesis and fixes v44's C01
regression.

### C02: subtype definition exists, but root selection bypasses it

The released root is step 1 `action/misalignment`. The anonymous candidate
set contains that exact tuple as H02, together with two downstream step-4
`planning/constraint_ignorance` alternatives. The Selector chooses the
downstream plan.

Its stated rejection is revealing: it calls the initial text extraction a
"valid exploratory call" because it returned a candidate issue, and says the
later plan independently committed the wrong final answer. This evaluates
partial output as recovery. But the task requires the oldest *closed* issue
with a Regression label and the historical date when that label was added.
The selected dynamic-page text representation never acquires the filtered
membership and label-history facts required to answer. Finding one open,
non-Regression issue is not recovery of that information requirement. The
later plan's use of an issue creation date is the downstream manifestation of
the still-missing discriminator/history data.

The `ACTION_SUBTYPE` check only says how to label a capability root after it
has been selected. It does not require the Selector to preserve an earlier,
unrecovered representation-capability root over a vivid terminal planning
symptom. This is therefore a selector causal-precedence failure, not a
candidate-recall or subtype failure.

### C03: correct category, two steps late

The released root is step 13 `planning/inefficient_plan`; v45 selects step 15
with the same module and type. Step 13 continues pagination after the trace
already reports pages 1--6 explored and no exact product; the released
annotation treats that almost-identical/repeated result path as the critical
inefficient plan. Step 15 is the later reissued search after returning to the
search page.

The candidate set has planning hypotheses at steps 5 and 15 but omits step
13, so exact localization is impossible without a fresh diagnosis. The
Selector adopts H02 at step 15. This remains candidate recall plus late
boundary selection. It is not the next isolated optimization target because
C01 and C02 already supply their exact released roots, enough to test a
selector-only hypothesis at the unchanged 2/3 gate.

## Attribution

There were no provider, retry, JSON, taxonomy-schema, evidence ownership,
step/event mapping, output-length, or semantic validation failures in the
recovered result. All three diagnoses are raw Selector outputs. No
deterministic finding, fallback, score, confidence, weight, vote, or gold
label participated in prediction.

The v45 selector clarification achieved its novel-search boundary objective
but failed its action objective at an earlier decision layer: the model never
selected the available capability root, so the subtype check was not reached.

## v46 falsifiable direction

v46 will leave the v44 candidate generator and every v45 rule unchanged. It
will make one selector-only clarification named `PERSISTENT_INFORMATION_ROOT`:

- When an early concrete operation/interface/returned representation is
  structurally unable to expose an explicit required discriminator, ordering,
  history, or state transition, a partial candidate or superficially useful
  page is not recovery of that requirement.
- Preserve the early `action/misalignment` root if no later step reacquires the
  missing required facts and the terminal planning error relies on substituting
  some available but non-equivalent fact.
- A downstream explicit constraint violation defeats that early root only if
  it is independently introduced after the missing information was actually
  reacquired, or would still occur under a one-output correction to a capable
  acquisition operation.
- This check applies only to observable operation/representation capability,
  not to ordinary irrelevant search results or uncertain open-world outcomes.

These are non-numeric semantic instructions to the raw LLM Selector. No fixed
candidate priority is introduced: the model must establish the explicit data
requirement, the representation's incapability, lack of recovery, and causal
dependence from the complete trajectory.

The hypothesis is accepted only if v46 reaches at least 2/3 Step Exact,
Step+Module Exact, and All Correct on the same frozen dry3, then at least
12/30 Step Exact on full tuning. Any failed provider or benchmark attempt
requires a completed case study before another LLM call.

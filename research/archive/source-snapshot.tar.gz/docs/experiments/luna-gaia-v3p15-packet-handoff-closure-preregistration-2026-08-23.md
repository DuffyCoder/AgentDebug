# Luna GAIA v3.15 Packet-Handoff Closure Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia-v3.15-packet-handoff-closure`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.14-earliest-causal-challenger`
- Current incumbent: v3.14, frozen GAIA-50 Step Exact `24/50`
- Original comparison baseline: v3.4, frozen GAIA-50 Step Exact `21/50`
- Dataset/cohort: frozen `gaia-paper-v1`, 50 cases
- Dataset manifest content SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Cohort content SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Prediction manifest content SHA-256: `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Goal completion condition: full GAIA-50 Step Exact `>= 30/50`
- Version acceptance condition: Step Exact must improve on the frozen incumbent
  `24/50`; a result below 30 remains an intermediate incumbent only if it is
  strictly better than 24 and passes every legality/freeze check.
- Smoke gate: none. Run the complete GAIA-50 immediately after offline
  validation.

Step Exact is the only optimization, comparison, acceptance, and Goal-completion
metric. Module, type, and evidence are legality constraints only.

## Parent result and audited first divergence

v3.14 completed all 50 cases with 150 fresh stage sessions and no retries. It
passed schema, taxonomy, evidence, exact-copy, order, hash, no-routing, and
gold-free validation and scored Step Exact `24/50`.

All 26 Step errors have frozen structured audits. The largest correctable cluster
is `fine_grained_candidate_recall`: eight current errors, seven
`candidate_recall_failure` and one `late_symptom_preference`, with average Step
delta `+1.75`. In each case the anchor cleared a locally observable handoff
defect and later froze a more explicit Planning, unsupported-state, or terminal
symptom. The missed boundary is visible in one of two adjacent contracts:

1. result-to-state: a task-necessary entity/value/provenance fact in the prior
   adjacent observation is omitted, contradicted, or falsely interpreted in the
   next Memory/Reflection; or
2. target-to-action: the current Planning target requires a discriminating
   entity, predicate, evidence route, or value, but the emitted Action drops or
   contradicts it.

The current protocol tells the anchor to inspect these lanes, but it has no
mandatory closure test before a ledger row may be marked clear. The write-once
checkpoint then makes the recall miss unrecoverable. The later-only challenger
cannot propose an earlier missed Step.

## Single major change

Change only anchor candidate recall by adding a task-material packet-handoff
closure before every cleared chronological ledger row. Keep the v3.14
earliest-causal one-later-challenger, default-keep exact-copy arbiter, candidate
topology, lane order, model, effort, case isolation, and validators.

Before an anchor row can be cleared, the Judge must explicitly close both
contracts when applicable:

1. Compare the previous step's adjacent result with the current Memory and
   Reflection. Admit Lane A at the current Step when a task-necessary observed
   entity/value/provenance link is omitted, contradicted, assigned to the wrong
   entity, or read as a false outcome/progress state.
2. Compare the current immediate subgoal and discriminating target with the
   Action. Admit Lane B or Lane C when the Action drops or contradicts a
   necessary target/predicate/evidence route, or repeats the unresolved
   predicate without adding a credible route.
3. Admission requires all three materiality gates: the fact or target is
   necessary for the current task checklist; the mismatch is literal rather
   than inferred from domain knowledge; and repairing this handoff can change
   the next retained state or action path.
4. Harmless wording compression, nonessential detail loss, valid summaries,
   an initial broad acquisition probe that can contribute a needed lead, and a
   materially different evidence route remain clear.

No case identifiers, source-model rules, entity-specific rules, gold rationale,
historical prediction, score, or candidate census is visible to inference.

## Falsifiable impact analysis

Expected current-error repair surface: the eight frozen v3.14 errors in
`fine_grained_candidate_recall`. Their audited mechanisms include one
underconstrained target/action handoff, three lost or unsupported retained-state
links, two false result/Reflection readings, and two unresolved-predicate probes
without a credible new evidence route.

Primary incumbent-correct regression surface: six cases whose correct Step is a
direct table/parameter/capability/state contradiction. The new rule must retain
those Steps because their mismatches are task-necessary, literal, and causal.
The broader risk is candidate flooding from minor naming discrepancies or
ordinary summarization. The three-part materiality gate is the negative control.

Expected direction: earlier only where a closed handoff fails. The mechanism
does not authorize skipping an earlier admitted candidate, choosing a later
symptom, or changing a challenger proposal. Expected best-case Step gain is up
to eight; any regression caused by a nonmaterial omission falsifies the
materiality gate.

This is a cluster-level exposed-cohort hypothesis, not an unknown-data
generalization claim.

## Offline validation and execution decision

Before the full run, require:

- compilation and workflow registration;
- prompt tests proving the two closure contracts and all three materiality
  gates are present only in the anchor stage;
- negative tests for harmless compression, useful acquisition probes, and
  incumbent-correct direct contradictions;
- unchanged challenger/arbiter topology and exact-copy validation;
- runner plan validation for 50 cases, 150 sessions, `gpt-5.6-luna`, medium
  effort, and no smoke gate.

Then run all GAIA-50 cases, freeze every prediction and intermediate artifact
under gold-free validation, verify hashes and legality, and only then score.

- If Step Exact is below `25/50`, reject and freeze v3.15.
- If Step Exact is `25..29/50`, accept it only as the next incumbent after all
  legality checks, audit all Step errors, and continue versioned iteration.
- If Step Exact is at least `30/50`, run the final acceptance audit and complete
  the Goal.

# Luna GAIA v3.38 preregistration

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.38-clean-v3.20-typed-boundary-calibration`
- Direct semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: v3.20, Step Exact `25/50`
- Version acceptance: Step Exact `>25/50`
- Goal completion: Step Exact `>=30/50`
- Frozen cohort: `gaia-paper-v1`, 50 cases; dataset SHA-256 `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`; cohort SHA-256 `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Model: `gpt-5.6-luna`; reasoning effort: `medium`
- No smoke gate; direct complete GAIA-50 after offline validation.

## Single major mechanism

Keep the v3.20 packet-state anchor, later challenger, default-keep arbiter,
schemas, validators, and exact-copy contracts. Add only one binding pre-freeze
calibration to the existing anchor ledger: compare the earliest mature literal
boundary in three mutually exclusive types—state truth, post-feedback
predicate-plus-evidence-family strategy maturity, and direct plan/Action or
explicit-constraint alignment. No v3.37 panel, selector, prompt, validator, or
artifact is inherited.

## Falsifiable impact prediction

The v3.37 audit contains 11 candidate-recall failures and shows that exact
target repetition is too narrow. The calibration should recall earlier gold
boundaries when the same unresolved predicate and evidence family are repeated
without a new evidence dimension, and should prefer literal state-truth or
alignment roots over later symptoms. Expected risk is earlier freezing of
reasonable initial/different probes, local source defects, or recovered
mechanical errors. Negative tests protect those vetoes and direct incumbent
critical anchors. Gains, regressions, and acceptance are computed only against
frozen v3.20; Step Exact is the sole selection metric.

Inference may read only frozen per-case manifests/cohorts and protocol sources.
Labels, gold rationale, historical predictions, scored artifacts, audits,
experiment documents, case studies, and git history are forbidden until all 50
predictions and intermediate artifacts pass gold-free validation and freeze.

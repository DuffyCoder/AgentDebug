# Agent Judge 实验瓶颈综合复盘

日期：2026-08-20

## 结论

优化现已暂停；本报告汇总已经完成的实验和失败运行。v13 unified 已执行完整
tuning-v1 30 条，但 60/60 sessions 因同一个 Codex CLI bootstrap 配置冲突被
严格 audit 拒绝，最终为 0/30 合法 prediction、未评分。它不是准确率结果。

当前没有一轮实验同时满足 tuning-v1 的全部停止条件：合规、完整实验的最佳
Step Exact 仍为 8/30；routed v12 的 13/30 使用了同 case 的已评分 v3 prediction
做 preserve/replace 分流，违反固定边界，不能作为 incumbent。

跨实验证据指向三个分层瓶颈：

1. **候选召回是最大的语义瓶颈。** 四轮 clean-debate 的 90 个最终 Step 错误中，
   76 个（84.4%）没有任何正确候选。
2. **时间边界仲裁是第二瓶颈。** 另外 14 个错误已经生成正确候选，却在最终
   仲裁中丢失；clean-debate v1 的候选 Step oracle 已到 12/30，最终只有 8/30。
3. **证据接口和多阶段交接是有效输出瓶颈。** v10 用 1,190,509 tokens 仍只有
   5/8 case 形成合法 prediction，不能评分；失败集中在 literal evidence、scope
   和下游 defect drift，而不是 HTTP 或 provider 故障。
4. **运行时 conformance 是新的 P0 工程门。** v13 的静态测试、dry-run 和
   strict-config preflight 全过，但它们没有启动到 Luna session event 层；一个
   全局 feature 冲突因此浪费了 3,441,767 input+output tokens。

因此下一轮不应继续堆叠 reviewer 或给 Planning 加新的局部偏置。恢复优化时，
应把重点放在：统一的高召回时间定位、最早成熟根因仲裁、机械证据绑定，以及
让 module/type 只能分类被冻结的同一个 defect predicate。

## tuning-v1 完整实验

| 实验 | Step | Step+Module | All Correct | ALF / GAIA / WebShop Step | 合规性 |
|---|---:|---:|---:|---:|---|
| Luna v3 | 8/30 | 3/30 | 2/25 | 2 / 4 / 2 | clean |
| clean-debate v1 | 8/30 | 3/30 | 2/25 | 2 / 3 / 3 | clean |
| clean-debate v2 | 8/30 | 2/30 | 1/25 | 2 / 4 / 2 | clean |
| clean-debate v3 | 6/30 | 2/30 | 1/25 | 1 / 4 / 1 | clean |
| clean-debate v4 rerun1 | 8/30 | 2/30 | 1/25 | 2 / 3 / 3 | clean |
| standalone v12 | 7/30 | 3/30 | 2/25 | 3 / 3 / 1 | proposal-free；有执行审计缺口 |
| routed v12 | 13/30 | 6/30 | 5/25 | 3 / 6 / 4 | **不合规，不计入目标** |
| unified v13 | — | — | — | — | 0/30 合法 prediction；执行失败、未评分 |

原始 clean-debate v4 目录是 0 completed、未评分；表中有效结果来自 rerun1。
All Correct 的官方分母是 25，因为 5 条没有可评分 gold type。

Routed v12 的 13/30 不能与 standalone 的 proposal-free 属性拼成一轮结果：它
读取同一 tuning-v1 上已经评分的 v3 predictions，17 条非 sink case 逐字段复制，
13 条 `planning/inefficient_plan` case 强制换 Step。它保住 v3 的全部 8 个命中，
再新增 5 个命中，恰恰是后验 preserve/replace routing 的收益，不是统一 judge
学会了可靠仲裁。

## 候选召回与仲裁

下表的 oracle 是评分后分析：任一当轮候选命中即算 oracle，只用于定位瓶颈，
不能用于拼接 prediction。

| 实验 | Step oracle | Final Step | 正确候选被仲裁丢失 |
|---|---:|---:|---:|
| clean-debate v1 | 12/30 | 8/30 | 4 |
| clean-debate v2 | 10/30 | 8/30 | 2 |
| clean-debate v3 | 12/30 | 6/30 | 6 |
| clean-debate v4 rerun1 | 10/30 | 8/30 | 2 |

四轮共有 120 个 case-run，最终错误 90 个：

- 76/90（84.4%）没有正确候选；
- 14/90（15.6%）已有正确候选但仲裁选错；
- 在 44 个已经召回正确 Step 的 case-run 中，arbiter 最终选对 30 个，条件成功率
  只有 68.2%；
- 四轮的 gold Memory 共 20 个 case-run，候选 recall 为 0/20；
- gold `inefficient_plan` 共 24 个 case-run，候选只召回 5/24，final 为 0/24；
- case 19 四轮都生成正确 S2，却四轮都选成 S3；
- case 11 在 v1--v3 都生成正确 S4，却都选成 S5；
- 正确的 terminal `step_limit` 候选在 v1 和 v3 都被丢弃；
- 增加第三候选没有自动改善：v3 的 A 候选单独有 8/30，最终反而只有 6/30。

这说明“再生成一个候选”不是充分解法。候选需要携带可验证的成熟边界证据，
arbiter 也必须比较 causal ownership，而不是答案是否更完整、局部错误是否更
显眼或候选位于列表什么位置。也不能简单地总选更早：GAIA 的早停变体在 29 个
错例中有 19 个预测过早，其中 18 个由硬 capability/repetition lane 触发。真正
的判据必须是错误是否已经成熟、是否被恢复，以及后续只是症状还是独立根因。

## 系统性偏差

把 v3、四轮 clean-debate 和 standalone v12 共六轮 clean final outputs 合并后：

- Step 45/180，Step+Module 15/180，All Correct 9/150；
- 135 次 Step 错误中，96 次（71.1%）比 gold 晚，绝对偏移中位数为 5；
- 88/135（65.2%）被预测为 Planning；
- 64/135（47.4%）被预测为 `inefficient_plan`；
- 六轮逐 case prediction 的 union 也只有 14/30，16 条从未 Step exact；
- 只有 case 12、15、20、30 六轮都命中 Step。

按 gold owner 聚合：

| Gold owner | Step 命中 | Step+Module 命中 |
|---|---:|---:|
| Memory | 1/30 | 0/30 |
| Reflection | 7/36 | 0/36 |
| Planning | 12/72 | 2/72 |
| Action | 18/30 | 12/30 |
| System | 7/12 | 1/12 |

最难的不是 Action，而是早期状态与解释错误。Judge 往往跳过 Memory/Reflection，
等到后续搜索、重复调用或 unsupported final answer 后，再把较晚症状归到
Planning/Action。

`inefficient_plan` 还存在一个看似矛盾、实际很关键的现象：六个 gold
`inefficient_plan` case 跨六轮 final 一共 0/36 Step Exact，但四轮 debate 的
candidate panel 曾产生 5 次正确 Step，5 次全部被仲裁丢掉。Judge 并非完全
看不到重复/低效计划，而是经常把“第一次成熟的重复边界”与更晚的重复或终局
症状混淆。

## Step、Module、Type 的优先级

六轮 clean outputs 的 45 次 Step 命中中，只有 15 次同时命中 Module，条件
owner 准确率为 33.3%；在有 gold type 且 Step+Module 命中的 14 次中，Type
命中 9 次，条件准确率为 64.3%。优化优先级因此是：

1. 先找对 Step；
2. 再把同一 defect 归给正确 owner；
3. 最后校准 error type。

这不表示 type 已经可靠。v10 明确暴露了
`memory_retrieval_failure`/`over_simplification`、
`outcome_misinterpretation`/`progress_misjudge` 等真实重叠；但在 Step 尚未稳定
时继续优化 type，不会提高当前 Step Exact 目标。

## v4--v10 的工程瓶颈

8-case 诊断 gate 不是准确率基准，因为它来自已知 error cases；它只能说明
机制是否可执行。

| 版本 | 合法完成 | Step（仅完整轮） | 总 tokens | 主要问题 |
|---|---:|---:|---:|---|
| serial-v4 | 8/8 | 3/8 | 263,837 | 串行化后仍选错边界 |
| boundary-v5 | 8/8 | 2/8 | 594,967 | C01/最早候选 anchor |
| multiscout-v6 | 0/8 | — | 946,799 | reviewer gate 自相矛盾 |
| coverage-v7 | 7/8 | — | 841,316 | 不完整 |
| strict-v8 | 8/8 | 3/8 | 913,598 | recall 6/8，仲裁后仅 3/8 |
| causal-v9 | 2/8 | — | 583,194 | recommitment/temporal 合同失败 |
| causal-v10 | 5/8 | — | 1,190,509 | evidence binding、scope、defect drift |

从 v4 到 v8，成本约增加 3.5 倍，Step 仍为 3/8。v10 的 78 个 provider 请求
全部 HTTP 200，resolved model 全是 `gpt-4.1-2025-04-14`；失败不是网络问题：

- 67/72 stage 接受；
- 5/8 case 形成 case-local prediction；
- 11 次 semantic validation failure，其中 5 次 repair 成功、3 个 stage 两次
  均失败；
- 总 tokens 1,190,509；被 validator 拒绝的成功响应消耗 213,577 tokens；
- 因 3 条失败，没有全局 predictions/audit/scored，故不存在 v10 准确率。

v10 的三个最终失败分别是：跨历史 step 拼成不存在的 quote；语义正确但
escaped/decoded wire text 不同；quote 位于当前 Memory、模型却按语义来源把
scope 写成 prehistory。完成的 case 还出现 temporal→module→type 对同一 Step
改讲不同 defect 的情况。这证明 hash lineage 只能证明文件链，不能自动证明
语义链。

## v13 全量运行：基础设施失败与第二层有效输出风险

v13 不是 smoke/gate，而是完整冻结的 tuning-v1 30-case 运行。30 条每条都启动
了两个独立 ephemeral Luna sessions，60 个 thread 全部唯一，进程返回码全部为
0，且每次都有一个 JSON-schema 合法的 `agent_message`。但每个 session 都在
正常回答前产生同一个 `item.type=error`：code-mode host 被配置为 disabled。
严格 parser 正确地拒绝了 error item，所以 semantic validator 实际调用 0 次，
也没有任何 prediction、merge、gold load 或 score。

冻结配置同时关闭了 `features.code_mode` 与 `features.code_mode_host`。本机
Codex 0.147.0 的零真实模型 loopback 差分表明：保留 code mode disabled、只把
host 改为 enabled，可消除 startup error；provider payload 仍是 `tools=[]` 且
`parallel_tool_calls=false`。因此未来应修配置，不能把 error item 加入 audit
allowlist。

v13 raw usage 为 input 3,346,470、output 95,297、reasoning output 73,830、
cached input 34,048。按 input+output 是 3,441,767 tokens，且没有形成一个合法
prediction。这暴露出 preflight 范围错误：缺失-schema/参数解析检查没有穿过
模型 metadata 与 event-stream 初始化，不能作为 session conformance 证明。

运行后、不读 gold 的离线 validator replay 还显示了第二层问题：60 个 raw
answers 只有 38 个 semantic-valid；按 attempt-1 优先、失败才用 attempt-2，
只有 23/30 case 至少有一个合法 decision。22 个拒绝中，19 个是 locator quote
不属于所报 step/source，另有 2 个 arbitration basis 不一致、1 个 selected
quote 不属于所报 module。两个 byte-identical sessions 的 selected Step 只在
13/30 case 相同，完整 Step+Module+Type 只在 8/30 相同。

这些 raw answers 来自失败 session，不能补写为 prediction、不能评分，也不能
据此报告 accuracy；但它们证明修复 CLI 只是必要条件。当前自由文本
step/source/quote 接口和候选生成方差仍会妨碍 30/30 合法输出。

## 已经被实验否定或明显降级的方向

1. **继续堆 reviewer/stage。** v4 到 v8 的 8-case 成本从 263,837 增到
   913,598 tokens，Step 都是 3/8；v9/v10 又因阶段合同和 evidence scope
   无法完整结束。更多阶段扩大了 schema surface 和 defect drift。
2. **候选越多自然越好。** debate-v3 的候选 oracle 是 12/30，final 却只有
   6/30；正确候选需要可比的 causal admission，不是数量。
3. **统一向更早或更晚移动。** 71.1% 的历史 miss 虽偏晚，但具体错误包含
   恢复过的早期 probe、成熟 recurrence、next-step interpretation 和 terminal
   System，单一方向偏置会修一类、破坏另一类。
4. **对 Planning/inefficient_plan sink 强制换 Step。** routed v12 借此得到
   13/30，但它依赖同 cohort 的已评分旧 prediction 分流，且 13 个 replacement
   仍有 8 个 wrong→wrong；这 13 条的绝对 Step 偏差总和还从 56 增至 63。
   这是后验路由，不是合法统一策略。
5. **只换 Judge 模型或恢复论文 prompt。** GPT-4.1 的完整 GAIA-50 公开拓扑
   本地结果为 14/50，仍低于论文 29/50；模型切换没有补上缺失的实际 rollout、
   evidence representation 和 provider/commit 差异。
6. **只靠自然语言强调 System/owner 规则。** 模型仍会把 provider fault 判成
   Planning，或把普通内容失败判成 System；高精度 System admission 必须由代码
   限定来源与因果优先级。
7. **把 schema-valid 当成 protocol-valid。** v13 的 60 个 raw answers 全部通过
   JSON Schema，但 gold-free semantic replay 只有 38/60 通过；结构正确不能证明
   quote、step、owner 和 defect 是同一个事实。

因此下一轮的关键不是增加推理调用，而是减少模型必须自报、复制和跨阶段保持
一致的字段；把能机械确定的 identity、geometry、source、scope 和 precedence
全部移回 parent code。

## 与论文结果的关系

完整 GAIA-50 上，本地最优完整结果仍是 Luna v3.4 的 21/50 Step；论文报告是
29/50。GPT-4.1、temperature 0、公开仓库式拓扑的本地完整实验只有 14/50。
切换模型、增加 exhaustive proposal 或恢复公开 Phase 1/2 形式都没有单独复现
论文效果。

因此差距不能归结为一个 prompt 或一个模型版本。公开材料缺少论文实际 commit、
中间 proposal、逐 case prediction、确切 provider snapshot，以及论文描述的
counterfactual rollout 的完整可执行实现。本地结果只能称 release/tuning
结果，不能称未知数据泛化，也不能把“公开仓库拓扑复现”写成“论文实现等价”。

## 恢复优化后的优先方向

### P0：减少自由文本接口，冻结 defect predicate

- 由代码把 JudgeView 变成局部 canonical evidence atoms；每个 atom 固定 step、
  owner span、phase、canonical text 和 hash。
- 关系错误使用 evidence pair：plan→action、observation→next interpretation、
  memory→source observation。
- Step、scope、locus、candidate identity 从选中的 atom 机械派生；模型不再复制
  长 quote 或猜测物理 scope。
- Locator 冻结完整 defect predicate：actor、violated relation、owner event、
  correction、downstream consequence。Module/type 只能分类这个 predicate，
  不得另起一个同-step 缺陷。
- JSON 拒绝重复 key；schema repair 锁住已经合法的语义字段；sole-option stage
  本地旁路或规范化，不再浪费一次 LLM 调用。

### P0：增加真实 session runtime gate

- 正式 full-30 前使用本地 loopback provider 穿过 Luna model metadata、payload
  构造和 event stream 初始化；不调用真实模型，也不选择任何语义 case。
- 断言 provider payload 没有 tools，session 没有 startup `error`、tool、file、
  command 或 network item；静态 `--strict-config` 解析不能代替这一步。
- code-mode host 是 CLI infrastructure，不是暴露给 Judge 的工具。启用 host 时
  仍应关闭 code mode，并在 payload/audit 中机械验证 `tools=[]`。
- 冻结 JS wrapper、native Codex 和 host executable。若正式运行首批 case 出现
  相同确定性 infrastructure signature，停止尚未启动的调用并将整轮判为
  execution-invalid；不得评分或复用其 raw answers。

### P0：建立统一的 chronological owner locator

- 每一步显式比较 Memory 与已有事实、Reflection 与前一 observation、Planning
  与任务约束/前置条件、Action 与当前 plan/接口。
- 对 `none/all/no relevant/complete/matches` 等全称判断做字面反证检查。
- 用事件图表达 `plan/action → observation → next interpretation → recovery →`
  `terminal`，并按信息首次被错误使用的位置归属。
- 对 recurrence 区分：一次失败后回到同 operational channel 的 family return，
  以及至少两次 prior、参数与结果均等价的 third exact recurrence。
- System 只接受互相冲突的输入、合法调用后的独立外部故障或有 provenance 的
  final limit；普通空结果、坏参数和内容级失败不属于 System。

### P0：统一仲裁，不强制替换

- 每条 case 都从当前匿名 JudgeView 现场生成 primary 和不同 Step challenger；
  不读取旧 prediction，不按旧 label pair 分流。
- Challenger 只是候选，arbiter 必须允许保留 primary；不能重复 routed v12 的
  forced replacement。
- 选择最早达到完整 admission gate 的 material root，而不是最早 step、最晚
  step、答案质量或列表顺序。
- 若候选 oracle 不足 12，继续修 locator；若 oracle 已到 12 但 final 未到，才
  集中修 arbitration。两类问题不能混为一次 prompt 修改。

### P1：缩短上下文与拓扑

- Action/terminal 只看任务、当前 step、同-step plan/action 和 decisive local
  observation；Memory/Reflection 才读取按 step 分卡的必要历史。
- 代码完成 recurrence、System exception、terminal identity、span ownership；
  LLM 只做不可机械化的语义比较。
- 不再让 coverage、assessor、selector、temporal reviewer 重复消费整条轨迹。

### P1：保持完整实验纪律

- 每个新协议只跑完整、冻结 tuning-v1 30；不以 smoke/8-case 语义分数晋升。
- 30 个独立 ephemeral sessions，并发不超过 4，单 case 最多 2 次，只重试失败
  case；30 条全部合法后才合并。
- 推理与 prediction/lineage/secret audit 完成前不加载 gold；评分后不替换单条
  prediction，不跨实验拼 oracle。
- 每轮使用新协议名和新 output 目录，冻结实现闭包、prompt、schema、binary、
  input hashes 和 session provenance。
- 所有分数明确标为 tuning-v1 tuning result，而非未知数据泛化。

## 暂停点

当前不启动下一轮实验。v13 unified 的完整 run 目录已冻结并持久化，但它在
session audit 阶段 30/30 失败，没有 prediction 或 score。它只能被视为完整的
execution-invalid 实验和 runtime/evidence-interface 诊断，不能视为准确率结果。

如果用户恢复优化，下一步才是冻结新的协议版本并跑唯一一次完整 tuning-v1 30。评分
后按如下决策树继续：

1. 任何 case 无合法 prediction：先修 evidence/schema/transport，不讨论准确率；
2. candidate Step oracle <12：主攻 chronological recall 与 recurrence；
3. oracle ≥12、final <12：主攻 arbitration 与 late-boundary bias；
4. final Step ≥12：再核验 Module/Type、全部 audit、持久化和报告口径，满足所有
   停止条件后才能完成目标。

## 证据索引

- `docs/experiments/gaia-agent-judge-v10-retrospective.md`
- `docs/experiments/luna-v12-goal-completion-audit-2026-08-20.md`
- `output/agenterrorbench-sophnet-gpt-4.1-gaia-step-error-gate-v8-agent-judge-causal-v10-case8/analysis.md`
- `output/agenterrorbench-codex-gpt-5.6-luna-tuning-v1-agent-judge-luna-v13-unified-v1-case30/analysis.md`
- `output/agenterrorbench-codex-gpt-5.6-luna-tuning-v1-agent-judge-luna-clean-debate-v1-case30/analysis/failure-analysis-2026-08-14.md`
- `output/agenterrorbench-codex-gpt-5.6-luna-gaia-paper-v1-agent-judge-luna-gaia-v3p4-case50/analysis/implementation-gap-and-complete-error-analysis-2026-08-15.md`

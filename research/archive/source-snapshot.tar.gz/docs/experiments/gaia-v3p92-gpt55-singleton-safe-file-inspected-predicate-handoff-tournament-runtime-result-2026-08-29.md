# GAIA v3.92 runtime result

Date: 2026-08-29

v3.92 completed model output and per-case schema validation for all `50/50`
cases (`100/100` stages), but it is **runtime-invalid and unscored**. The
gold-free access audit ran before any label read and found zero successful
inspector commands across all stages. Consequently every stage lacked task and
complete timeline coverage.

The first divergence is `runtime_or_validation_failure`. The local Codex
read-only sandbox failed with `bwrap: loopback: Failed RTM_NEWADDR: Operation
not permitted` before the model could inspect the staged JudgeView. The model
then emitted a system-failure singleton, and deterministic legality
materialization made the record schema-valid without restoring the missing
semantic observation. All 50 final selections therefore degenerated to
singleton `keep_anchor` at Step 1.

The v3.92 runner also exposed a post-merge compatibility-alias bug, but the
direct v3.92 aggregate validator independently passes. That bug is downstream
of the decisive access-audit failure and does not change the rejection reason.
No score is computed because the required gold-free freeze condition failed.

The minimal next correction is transport-only: use a no-bwrap execution mode in
the isolated case directory, post-audit every command against the exact
inspector allowlist, require every command to finish with exit code zero, and
require task plus complete timeline coverage before freeze. The Judge semantic
mechanism remains the clean-v3.83 predicate-handoff tournament hypothesis.


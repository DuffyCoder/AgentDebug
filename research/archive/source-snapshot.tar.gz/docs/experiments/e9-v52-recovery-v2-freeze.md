# E9-v52 full30 recovery v2 freeze

Recovery v1 was frozen before the complete simulated eight-call recovery test
was added. Because the recovery archive deliberately binds that test file,
v1 is retained as historical output but is superseded by v2. No provider call
was made by either preregistration.

V2 evidence:

- complete repository regression: 533 passed;
- simulated recovery: batches 1--7 were cache hits, batches 8--11 consumed
  exactly eight synthetic completions, all 30 raw rows validated, and no gold
  field appeared in captured provider payloads;
- recovery cache origin: 42 files with state hash
  `c7b7952a6f243b033b380f508ccffa109cc754866f48e50559c35bb407d25452`;
- recovery contract hash:
  `a462b2e8066d9d5fd0ba80cfb8008be1e115f219bbf421f384b21778a7006495`;
- preregistration content hash:
  `071272b532efd6fe755f2133e47d0a52963b478123a9648722e58c79b8f74411`;
- preregistration file hash:
  `ac609da8dcdd6500c5acccc795e79b14883c18fb30b9b2e180bb12cbb5ab70c7`;
- code archive file hash:
  `8c30cb387c937f734bad4278d074bdafd2c0a8c784ce0499f16dd561bda5022b`;
- empty recovery ledger file hash:
  `82acb57d7a9ab0342a784223fd0a578121c2d712f82a632d2610208aac75c7eb`.

The live recovery remains limited to cumulative logical completions 632--640.
It must not be started while the bound DeepSeek account returns HTTP 402.

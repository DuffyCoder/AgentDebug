# E9 v58 smoke cap-recovery full-suite failure case study

## Failure

The first full repository pytest run reached the new recovery test and then
left 110 entries in pytest's last-failed cache. Reproducing the first failure
with `--last-failed -x` showed the recovery boundary rejecting its expected
Critic size vector. No provider was constructed and smoke artifacts were not
modified.

## Attribution

The failure is test-process module contamination, not 110 independent
semantic regressions. The historical module extractor prepends a temporary
frozen archive directory but Python reuses any matching modules already in
`sys.modules`. In the full suite, current repository workflow modules had
already been imported, unlike the fresh process used by the earlier targeted
test. The recovery boundary then assigned the 900,000 cap on that shared
module and did not restore it, cascading into later tests whose frozen
contract requires 800,000.

The standalone recovery command is a fresh process and had already passed all
size, hash, cache, and ledger checks. The problem is nevertheless real for
test isolation and must be fixed before freeze.

## Correction

Make `_boundary` restore the original cap by default and retain 900,000 only
when the formal recovery `run` explicitly requests it. Exercise the complete
boundary through a subprocess in the regression test, matching the production
CLI process boundary and avoiding `sys.modules` aliasing. Rerun the targeted
tests and then one new complete suite because the recovery source changed.

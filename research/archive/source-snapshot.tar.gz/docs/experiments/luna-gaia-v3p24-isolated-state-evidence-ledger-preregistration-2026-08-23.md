# Luna GAIA v3.24 Isolated State Evidence Ledger Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia-v3.24-isolated-state-evidence-ledger`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.23-mandatory-state-scan-before-veto`
- Semantic anchor parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Frozen incumbent Step Exact: `25/50`
- Original v3.4 baseline Step Exact: `21/50`
- Version acceptance: `Step Exact > 25/50`
- Goal completion: `Step Exact >= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Frozen v3.20 predictions SHA-256: `9df734d95a7c338a9b8ce66fb4d91e16d69961d272ddcc926f7d11f3ddc8add8`
- Frozen v3.23 predictions SHA-256: `eb7015a3fa1f7f71244375859c76048dc81463643f445665e1719da6c6d6f29c`
- v3.23 Step audit SHA-256: `c522c1e5aacfd70100536d7ede61df576a2c52286711ecc3615634daea908b94`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the sole optimization and decision metric. Module/type/evidence
remain legality constraints only.

## Post-score diagnosis

v3.23 fixed v3.22's pre-scan anchor short circuit: every challenger enumerated
the exact Memory/Reflection Step list and ten non-empty typed candidates were
recorded. Nevertheless, the five preregistered state-recall errors still did
not surface their gold boundary. Six recorded candidates equaled the anchor,
four were later, none was earlier, and no challenger fired.

The first divergence is now observable inside candidate admission. The
validator proves that all Step numbers were listed but accepts one compressed
free-text conclusion about the whole chronology. It cannot prove that each
state Step received a local retained-state/feedback comparison. Four diagnoses
are High-confidence and one Medium-confidence.

## Single major change

Preserve the v3.20 anchor, v3.23 closed state-only candidate taxonomy,
directional repair tests, one-proposal maximum, and default-keep arbiter.
Replace the compressed state scan summary with a validator-enforced ordered
state evidence ledger embedded in the challenger artifact.

The challenger must emit exactly one row for every Memory/Reflection Step, in
chronological order. Each row has exactly:

```json
{
  "step": 3,
  "state_quote": "literal Memory/Reflection excerpt or null only if empty",
  "feedback_quote": "literal adjacent-feedback excerpt or null only if absent",
  "candidate_kind": "none | necessary_fact | entity_relation | outcome_claim",
  "candidate_relation": "not_applicable | omitted | unsupported | contradicted",
  "downstream_consumer_step": "integer or null",
  "verdict": "clear | candidate"
}
```

The validator derives the exact Step list and literal source ranges from
JudgeView. It requires exact row coverage/order, exact closed kind/relation
pairs, literal quotes, and a valid later consumer for every candidate. The
earliest `candidate` row mechanically determines the frozen candidate fields
before anchor comparison. A challenger proposal must exactly use that Step and
remain owned by Memory or Reflection.

The ledger is encoded at the beginning of `search_summary` as a compact JSON
array and is parsed with a JSON decoder rather than delimiter splitting. No
case router, entity/site rule, historical prediction, gold information,
general candidate pool, or non-state proposal is added.

## Falsifiable prediction

- 50/50 challengers contain a validator-complete ordered evidence row for every
  Memory/Reflection Step.
- The five audited state boundaries become candidate rows more often than in
  v3.23.
- At least one frozen state candidate is earlier than its anchor.
- At least one state proposal reaches the arbiter.
- Accepted state proposals produce positive net Step transitions against v3.20.
- Step Exact exceeds `25/50`.

The hypothesis is falsified if exact ledgers still contain no earlier
candidate, if local rows exist but the five target boundaries remain clear, if
candidate flooding creates net regressions, or if Step Exact is `<= 25/50`.

## Gain and regression analysis

Expected gains are the five-case `state_scan_evidence_ledger_gap` cluster:
three earlier omitted-detail/over-compression boundaries, one earlier false
progress state, and one earlier unsupported entity-relation boundary. Their
average Step delta is `+2.2` (current prediction minus gold).

Primary regression risks are the six v3.23-correct cases that already contain
a non-empty state candidate. Per-row forced classification can turn benign
compression, a provisional hypothesis, or a locally false but noncritical
state into an earlier candidate. It also increases output length and validator
surface.

Controls are exact literal ownership, adjacent-feedback evidence, closed typed
pairs, required downstream consumption, chronological earliest derivation,
state-only ownership, one proposal, direction-specific repair tests, and the
independent default-keep arbiter. The anchor remains isolated, avoiding the
v3.21 regression caused by binding typed state classification into every
anchor row.

## Execution and acceptance protocol

1. Implement the evidence-ledger prompt, decoder, validator, runner, and
   negative tests.
2. Verify v3.20 anchor semantic equivalence and exact row coverage/order,
   quote, pair, consumer, and earliest-candidate validation.
3. Run offline validation only; no smoke gate.
4. Execute all 50 frozen cases with three fresh serial sessions per case and at
   most four cases concurrently.
5. Freeze predictions and all intermediates after 50/50 gold-free validation.
6. Then score and compute Step transitions against v3.4 and v3.20.
7. Accept only if Step Exact is `> 25/50`; complete the Goal only at `>= 30/50`
   with every legality and freeze check passing.
8. Otherwise reject immutably, audit every error, and continue from one new
   uniform mechanism.

# GAIA v3.87 evidence-lifecycle challenger result

Date: 2026-08-29

## Decision

Rejected and immutable. Complete GAIA-50 Step Exact is `18/50`, below the
accepted v3.83 incumbent `26/50` and the Goal threshold `30/50`.

## Frozen execution and legality

- Complete cases: `50/50`.
- Stage attempts: `150/150`; retries: `0`.
- Model/effort: `gpt-5.5` / `medium`.
- Gold-free, schema, order, taxonomy, literal evidence, Step range, and exact-copy validation: passed.
- Challenger artifacts: 13 `manifest_active`, 37 `no_challenge`.
- Directions: 12 later, 1 earlier.
- Arbiter: 12 accept challenger, 38 keep anchor.
- Predictions SHA-256: `3f5e8c511abf070fe5ef2d9b13c638668cea88f61f8f04b36b0af2750bbcf02a`.
- Prediction audit SHA-256: `9d12e1238f19857d6b65969601b943ffb145959e9d346c439d2f631e36bf5d0a`.
- Scored metrics SHA-256: `18446fab76fbd685f3c3695c31829e34a3944d8dc49bcd98569b07a7d7713dae`.

## Step-only mechanism result

- Fresh v3.83-semantic anchor: `23/50`.
- Final: `18/50`.
- Relative to frozen v3.83: 18 both correct, 24 both wrong, 0 gains, 8 losses.
- Proposal Step exact: `1/13`.
- Direct challenger effect over the fresh anchor: 1 gain, 6 losses, 5 wrong-to-wrong.
- The sole correct proposal restored a fresh-anchor sampling error; it did not
  repair any of the 24 frozen v3.83 Step errors.
- Among all final errors, the released gold Step was absent from the current
  anchor-plus-proposal candidate set.

The hypothesis is therefore falsified twice: the lifecycle representation did
not improve incumbent-error candidate recall, and its causal narratives were
not precise enough to protect correct fresh anchors.

## First-divergence audit

The 32 final errors contain 10 `anchor_error`, 6
`false_challenger_override`, 6 `candidate_recall_failure`, 6
`false_candidate_admission`, 2 `early_freeze_failure`, 1
`late_symptom_preference`, and 1 `annotation_ambiguity`.

The new mechanism-specific failure is `lifecycle_false_causal_edge_override`:
literal origin, obligation, and downstream manifestation quotes were present,
but the contract did not require an explicit producer-to-consumer provenance
edge. Co-occurring or topically related local defects could therefore be
promoted as one causal chain.

Audit SHA-256: `9f0de381d95c7606ee17e4ddd5b3be0158ef9206fd4e667cc6e57595e084131c`.
Cluster SHA-256: `c2cfd55018ad2428b2b8d9fa415bb75d9c58c7938550518d63296de07cd6b268`.
Impact SHA-256: `ec0efe89d14813b3d25c94ab90993610df6a8b30959ae78e187159e05d393b73`.

## Next falsifiable mechanism

Return to accepted v3.83. Replace its challenger with a sparse influence-graph
reader that may propose one root only when a short chronological edge chain
quotes both the produced fact/predicate and its later consumption at every
handoff. No v3.87 lifecycle status, prompt, prediction, or scored artifact is
inherited. The intended correction is narrower than adding more candidates:
it tests whether explicit influence provenance prevents false causal edges
while recalling a boundary that the anchor missed.

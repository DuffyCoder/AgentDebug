# Luna GAIA v3.49 Clean-v3.20 Anchor-blind Global Causal Proposal Duel Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.49-clean-v3.20-anchor-blind-global-causal-proposal-duel`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Frozen accepted incumbent Step Exact: `25/50`
- Original v3.4 baseline Step Exact: `21/50`
- Version acceptance: `Step Exact > 25/50`
- Goal completion: `Step Exact >= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Frozen v3.20 predictions SHA-256: `9df734d95a7c338a9b8ce66fb4d91e16d69961d272ddcc926f7d11f3ddc8add8`
- Frozen v3.20 implementation SHA-256: `3e886325bf0a4b4d4a3e770071c0a36fe81dab2bebaf5015561ca828b6c2e4f9`
- v3.48 Step audit SHA-256: `35a12eda0f777ae826d0cf596620cd77cc298046f8c46213d9e32ddbf997ec77`
- v3.48 cluster audit SHA-256: `e01828da579517158427f0900cb9a76a8128e192f6043326b6498c0754cf1ec5`
- v3.48 mechanism-impact SHA-256: `17ac94c86a8a128529aac35b397eefc5ccfe6633eaf52b4b7cf360dc5b05b73c`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the sole optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module, type, and evidence remain legality constraints
only.

## Evidence from the rejected v3.48 experiment

v3.48 completed and froze all 50 cases, passed all gold-free legality checks,
and scored `19/50`; it is rejected and immutable. Relative to v3.20 it had 18
both-correct, one gain, seven losses, and 24 both-wrong cases.

The mandatory audit covers all 31 Step errors. First divergence is 25
`anchor_error`, five `annotation_ambiguity`, and one
`false_challenger_override`. The complete local inventories contain the gold
Step for 17 anchor-wrong cases and yield a `36/50` anchor-plus-profile
post-score candidate oracle. Nevertheless, the conjunctive compression/duel
changed only three Steps: one direct gain, one direct loss, and one
wrong-to-wrong change. Fifteen unambiguous current errors therefore have the
gold Step recalled but not selected.

This falsifies the v3.48 all-in-one compression contract: requiring a local row
to prove prior state, same-owner commitment, later consequence, every veto, and
observable dominance over a visible anchor suppresses too many recalled
boundaries. The sole direct loss also supplies a direct counterexample to
demoting an anchor merely because it precedes an unhelpful result and can be
described as an initial probe.

## Single major change

Keep the v3.20 anchor prompt, packet-state ledger, chronological freeze, model,
reasoning effort, and prediction schema semantically unchanged. Add exactly one
mechanism: an anchor-blind global causal proposal followed by a bounded
anchor/proposal duel.

1. A fresh anchor-blind session sees only the frozen trace and taxonomy. It
   must inspect every Step and all five module owners, locally identify concrete
   defects, apply recovery/probe/mechanical/propagation/symptom vetoes, and
   freeze at most one complete legal proposal representing the benchmark's
   critical boundary. It cannot see the anchor, its ledger, its checkpoint, or
   any historical prediction.
2. A separate fresh duel session receives only the clean v3.20 anchor and that
   one frozen proposal. It selects an exact field-for-field copy; it cannot
   invent a third Step, merge fields, or expose more candidates.
3. The anchor remains the default under unresolved evidence. A proposal may
   displace it only when the anchor is observably noncritical and the proposal
   is independently task-material.
4. `initial_probe` is not itself an anchor veto. If the duel calls the anchor a
   contributing probe, it must quote a literal observed contribution witness:
   a necessary identifier, fact, source, route, or other task-material item
   actually supplied by the anchor path. A merely successful call, a generic or
   empty result, or hypothetical possible usefulness is insufficient.
5. The anchor-blind proposal stage does not require a later-consequence
   conjunct. It may select the first already-material bad commitment from its
   literal plan/Action/state evidence, while still rejecting recovered defects,
   normal tool failure, faithful propagation, mechanical repairs, and later
   symptoms.

This is a clean implementation from v3.20. No v3.21-v3.48 prompt, challenger,
profile artifact, ledger extension, selector, or validator is imported or
automatically inherited. The rejected profile evidence is used only to form
and preregister this hypothesis.

## Falsifiable predictions

The mechanism is supported only if all of the following hold:

- every proposal stage proves full Step and five-owner inspection;
- the proposal stage is anchor-blind and exports at most one prediction;
- every final prediction is an exact anchor or proposal copy;
- every accepted `contributing_probe` veto has a validator-bound literal
  contribution witness;
- the anchor-plus-proposal post-score oracle reaches at least `30/50`;
- direct duel gains exceed direct duel losses; and
- final Step Exact exceeds the accepted incumbent's `25/50`.

It is falsified if proposal recall remains below 30-oracle coverage, the duel
again defaults away nearly all useful proposals, any proposal flood occurs,
probe status without observed contribution causes an override, or final Step
Exact is at most `25/50`.

## Expected gains and regression risks

The primary gain cluster is the 15 unambiguous v3.48 errors where the complete
local inventory already contained gold but the conjunctive duel did not select
it. These post-score trajectory IDs remain only in the v3.48 audit and are not
copied here or exposed to inference.

The principal regression surface is every incumbent-correct trajectory on
which an independent global proposal identifies a later local defect. The
mechanism moves selection in both directions, but should move later more often
when the anchor is a genuinely contributing probe or noncritical predecessor.
It can regress by preferring Planning, a vivid downstream symptom, the first
local defect, or a later repeated search over an already-critical anchor.

Controls are: one proposal maximum, anchor blindness during recall, exact-copy
selection, default keep, no later-consequence requirement in proposal recall,
and a positive observed-contribution witness before `contributing_probe` may
veto an anchor. These are a single selection-topology change, not case routing.

## Execution and acceptance protocol

1. Implement the clean-v3.20 anchor, anchor-blind proposal, bounded duel,
   validator, runner, and positive/negative tests.
2. Source-scan inference code for rejected-lineage imports, case IDs, labels,
   metrics, historical predictions, scored artifacts, and routing.
3. Run offline tests only; do not run a smoke gate.
4. Execute all 50 cases with three fresh serial sessions per case and at most
   four cases concurrently.
5. Freeze predictions and all intermediate artifacts only after 50/50
   completion and gold-free validation.
6. Load labels and score only after the freeze.
7. Compare Step transitions and gains/regressions to v3.20; v3.4 is reported
   only as the original frozen baseline.
8. Accept only if Step Exact is greater than `25/50`. Complete the Goal only if
   Step Exact is at least `30/50` and every legality/freeze check passes.
9. Otherwise reject the immutable version, audit every Step error, and create
   the next clean branch from v3.20.

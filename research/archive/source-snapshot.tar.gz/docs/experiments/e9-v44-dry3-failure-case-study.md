# E9 v44 dry3 failure case study

## Outcome

v44 completed its frozen dry3 run with three valid raw diagnoses, but again
missed the preregistered promotion threshold:

- Step Exact: 1/3;
- Step+Module Exact: 1/3;
- All Correct: 0/3;
- successful outputs: 3/3;
- failed outputs: 0/3;
- logical completions: exactly 2;
- HTTP attempts: exactly 2, with zero retries;
- provider tokens: 381,296 input, 24,692 output, 405,988 total.

The rejected promotion is bound by
`c48af173d300642f3149f6ad3febafa5cc1f7367506d3eceab95b01b1747cd86`.
v44 must not advance to full30 or held-out smoke.

## Case study

### C01: the boundary was preserved but the Selector invented an earlier root

The released root is step 30 `system/step_limit`. v44 successfully preserves
that tuple twice: once from the frozen prior and once from
`terminal_guard`. The other lanes emit step 12 `planning/inefficient_plan`
and step 16 `memory/memory_retrieval_failure`. The raw Selector rejects every
supplied item and creates a fresh step 4 `planning/inefficient_plan` root.

This violates the intended failure-preventing test. Moving from cabinet 1 to
cabinet 2 is a feasible action over a distinct unvisited receptacle. A drawer
or another countertop might be more promising, but its unknown result does
not independently establish task success. The Selector restates "prevents
the cabinet sweep" as "prevents the failure" without proving the latter.

Candidate recall is solved; final selection is not.

### C02: correct step/module, wrong action subtype

The released root is step 1 `action/misalignment`. The frozen anonymous prior
contains that exact tuple. The new first-defect lane emits step 1
`action/parameter_error`, while the branch lane emits the downstream step 4
`planning/constraint_ignorance`. The Selector adopts the new step-1 subtype.

Its factual reasoning is sound: extracting a dynamic GitHub HTML search page
cannot provide the ordered filtered issue set. The taxonomy choice is not.
The concrete operation/representation is incapable of realizing the plan's
information requirement, which is `misalignment`; `parameter_error` should
be reserved for invalid arguments to an otherwise capable operation. v44's
wording lets the URL value dominate the operation-level capability mismatch.

This is a selector taxonomy-disambiguation failure. Step Exact and
Step+Module are correct, but All Correct is lost.

### C03: ownership improves, critical step remains too early

The released root is step 13 `planning/inefficient_plan`. v44 changes the
prior v43 step-8 action error into step 8 `planning/inefficient_plan`, which
correctly keeps strategy ownership with planning. The lanes also include
step 6 `planning/inefficient_plan` and step 30 `system/step_limit`, but no
hypothesis contains step 13. The Selector retains step 8 as the restart of a
known-unproductive query epoch.

Thus v44 improves module/error ownership but does not solve the annotation's
later critical boundary. This remains a candidate-recall failure for exact
step and is not the next dry optimization target: C01 and C02 already contain
their exact released roots and can provide the preregistered 2/3 signal via a
selector-only clarification.

## Attribution

There were no provider, retry, JSON, taxonomy-schema, evidence ownership,
step/event mapping, response-length, or output-validation failures. No
deterministic semantic mutation, confidence, score, weight, vote, or fallback
participated.

The v44 candidate change worked as designed in two respects: it always
preserved the real terminal boundary, and it moved C03 ownership from action
to planning. The failure is concentrated in the raw final Selector:

1. it still equates redirecting uncertain exploration with preventing task
   failure, even after the stronger general statement;
2. it chooses a more specific-sounding action subtype without applying the
   operation-capability distinction already present in the taxonomy;
3. C03's later exact step remains absent, but changing the candidate lanes
   again in the same round would make the next result difficult to attribute.

## v45 falsifiable direction

v45 will leave the v44 candidate generator unchanged and make one
selector-only clarification. Before selecting or inventing a root, the raw
Selector must apply two categorical, non-numeric semantic checks:

1. **Novel-search boundary check.** Under a real enforced step limit, moving
   among distinct feasible unvisited targets is still novel coverage. A
   different unknown target, a more promising receptacle class, or a shorter
   hypothetical branch does not prove failure prevention. Such alternatives
   cannot displace `system/step_limit` unless an earlier output is already an
   observable invalid operation, contradiction, known-state repetition, or
   explicit constraint violation whose correction independently avoids the
   failure.
2. **Action subtype check.** If the selected operation/interface or returned
   representation cannot implement an explicit plan requirement, use
   `action/misalignment`. Use `action/parameter_error` only when that operation
   is capable in principle but the supplied argument is malformed, missing,
   out of range, or otherwise invalid.

These are prompt-level semantic definitions applied by the LLM, not
deterministic rules or post-processing. The anonymous candidate list, schema,
raw Selector ownership, no-fallback behavior, and exact two-call topology are
unchanged. No case ID, environment, released answer, score, confidence,
weight, vote, or fixed priority is added.

The hypothesis is accepted only if v45 reaches at least 2/3 on all dry gates
and then at least 12/30 Step Exact on full tuning. Any failure requires a new
case study before another provider call.

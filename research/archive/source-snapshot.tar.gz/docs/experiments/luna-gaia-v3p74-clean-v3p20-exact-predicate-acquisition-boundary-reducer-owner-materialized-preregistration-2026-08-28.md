# Luna GAIA v3.74 预注册：exact-predicate reducer，same-Step owner materialization

状态：执行前冻结。

## 冻结实验合同

- semantic parent：accepted Luna v3.20，Step Exact `25/50`。
- 版本：`agentdebug.codex-agent-judge.luna-gaia.v3.74-clean-v3.20-exact-predicate-acquisition-boundary-reducer-owner-materialized`。
- 数据集：冻结 `gaia-paper-v1` 50 例。
- 模型/effort：`gpt-5.6-luna` / `medium`。
- v3.4 基线：Step Exact `21/50`。
- 接受：合法完整 GAIA-50 Step Exact `>25/50`。
- Goal 完成：合法完整 GAIA-50 Step Exact `>=30/50`。
- 无 smoke 门控；直接完整 GAIA-50。

唯一主要语义机制仍是从 v3.20 clean branch 单独移植的 `exact-predicate acquisition
boundary reducer`。v3.20 anchor Step、candidate gate、binding veto、deterministic selector、
owner-explicit input 和 corrected access auditor 均保持。不继承 rejected lineage 的其他
机制；semantic parent 始终是 v3.20，推理不读取历史逐例预测。

## v3.73 first divergence 与唯一 owner 修正

v3.73 完成 49/50；第 20 例两次 anchor response 都把 Step 1 的 Planning 文本归给
Reflection，但该 Step 的 literal Reflection owner sources 为空，导致
`invalid_evidence_ownership`。评分未开始、gold 未读取。

v3.74 只处理这种同 Step 不可能 ownership，Step 永不改变：

- 若模型选择的非-System Agent Module 在该 Step 有 owner source，保持 v3.71 evidence
  exact-copy 行为，Module/type 不变；
- 若所选 Module 在该 Step 没有任何 literal source，父进程优先选择包含模型 quote 的
  同 Step Agent owner；否则选择固定 taxonomy 顺序中的第一个非空 Agent owner；
- 若原 type 对新 owner 非法，仅取该 owner taxonomy 的第一个合法 type；evidence 仍从
  同 Step 新 owner exact-copy，并同步 ledger；
- root cause、causal summary、candidate/selector 与 predicted Step 全部不变；System 不
  自动改写；每次 owner/type materialization 都进入 provenance audit。

Module/type 仅为输出合法性，不参与版本选择。本修正不使用 gold，且 runner 在写 artifact
后硬断言 predicted Step 与 raw response 相同。

## gains、regressions 与判伪

Step gain/回归仍完全来自 exact-predicate reducer。owner materialization 对 Step 的预期
影响为零；风险是 same-Step Module/type 语义被保守地合法化，但这些字段不参与接受决策。
直接反例是 materialization 改变 Step、已有合法 owner 被改写、或完整运行仍未通过。

若相对 frozen v3.20 gains 不大于 losses、final Step Exact `<=25/50`，或 50/50、schema、
taxonomy、evidence、hash、gold-free、tool-free、write-topology 任一验证失败，则拒绝。
只有合法 `>=30/50` 才完成 Goal。

## 执行前冻结哈希与离线验证

- protocol：`d1da6f2b482f30c718d5034b5bccbb970ed7396e9a43f94e7cfffabf8183ff79`
- runner：`c8fd09ae40fb916f71693b463df543d76fba4e60b42a0069636bf8a04fede341`
- access auditor：`972f94fd59f76c73c6c9483b9124e403232323f2cacf9671d4adfe55bc9037bc`
- registry：`940eaec390ea00faa6d40ff556e0205f341fc6a4f9c78e081c370b56bd356d08`
- tests：`0d80ea1bd04c2d877451b6caaf2d548a7b5e915774eb1c7fb22cd348917b0582`
- taxonomy：`d7e4b878059bbecec0a8fd3f078c0aeb5755bf9e65bb938c897dd83685f28c5c`
- semantic parent v3.20：`3e886325bf0a4b4d4a3e770071c0a36fe81dab2bebaf5015561ca828b6c2e4f9`
- prediction manifest：`77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- cohort：`31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`

离线验证：v3.74--v3.66 及 v3.20 相关测试 `54 passed`；compile、registry、真实 executor
interface、50-case dry plan、100 sessions 和 direct parent 全部通过。测试使用 v3.73 实际
第 20 例失败 response，确认 Step 1 不变、Reflection/causal_misattribution 被同 Step
Planning/constraint_ignorance 合法化并通过 strict validator；已有合法 owner response no-op。

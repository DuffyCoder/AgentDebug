# Luna GAIA v3.77 pre-registration

## Frozen identity

- Protocol: `agentdebug.codex-agent-judge.luna-gaia.v3.77-clean-v3.20-factorized-sparse-ledger-pairwise-selector`
- Semantic parent: accepted incumbent `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Incumbent Step Exact: `25/50`
- Original v3.4 baseline Step Exact: `21/50`
- Dataset: frozen `gaia-paper-v1`, 50 cases
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Acceptance: legal full-50 Step Exact `>25/50`
- Goal completion: legal full-50 Step Exact `>=30/50`
- Smoke gate: none

v3.77 is a clean direct child of v3.20. No Step-selection prompt, challenger,
ledger change, late proposal, candidate expansion, reducer, or selector decision
from rejected v3.21–v3.76 is inherited. Owner-explicit response-only execution,
same-Step owner/evidence materialization, and access auditing are legality-only
scaffolding and are mechanically unable to alter the model-selected Step.

## One semantic mechanism

The only major change relative to v3.20 is:

> Factorize native sparse-ledger local facts from pairwise global selection.

The unchanged fresh v3.20 stage produces its anchor, native sparse ledger, and
checkpoint. An anchor-blind stage then reviews every and only native ledger Step
independently, recording observed defect, outcome, recovery, path relation, and
candidate-only repair state without making a criticality or final-Step decision.
A fresh independent selector sees those frozen local facts and the complete
trajectory, compares every strict-prefix ledger Step pairwise against the anchor,
and may exact-copy at most one prefix. It keeps the anchor unless a prefix owns a
clear earlier, concrete, unrecovered path-changing defect and the anchor is a
noncritical predecessor, faithful propagation, or downstream symptom.

There is no later-candidate slot and no full Step-by-Module inventory. Thus the
mechanism tests separation of evidence acquisition from selection without
reintroducing the candidate flood and late-symptom preference observed in the
paper-style and v3.12-global lineages.

## Falsifiable hypothesis and impact analysis

Post-score v3.76 evidence showed native-ledger gold coverage of `31/50` and
anchor-plus-reviewed coverage of `32/50`, but final Step Exact of only `21/50`.
Among its 29 errors, five had the gold boundary already reviewed but rejected by
the joint selector, and one incumbent-correct anchor was falsely overridden.
Earlier v3.49 pairwise-duel evidence produced six direct gains and two losses,
while v3.60 showed that an overly strict closure gate under-promoted candidates.

The falsifiable hypothesis is that freezing anchor-blind local facts before a
separate pairwise decision reduces joint-selector self-rationalization and
recovers a positive subset of earlier native-ledger boundaries at lower
regression cost than a global multi-candidate selector.

Expected gains are incumbent-wrong cases in which an earlier native-ledger Step
has a concrete unrecovered path effect that can be distinguished from the anchor
by candidate-only versus anchor-only repair. The principal regression risks are
false promotion of an initial probe, normal negative result, recovered defect,
or merely earlier surface flaw over an incumbent-correct anchor. Pairwise
independence, a keep-anchor default, complete prefix comparison, and the explicit
repair-state criterion are the uniform controls. The mechanism cannot repair
gold boundaries absent from the native ledger or later than the anchor, so even
successful selection remains recall-limited.

All gains, regressions, acceptance, and rejection are computed only against
frozen v3.20. Step+Module, All Correct, module/type distributions, and rejected
version outputs cannot affect the decision.

## Frozen inputs and sources

- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort membership SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Semantic prediction-manifest SHA-256: `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`
- Protocol SHA-256: `b10bec9a046b55f98043c01de6f08cacb026847e3a45ab959c364479041bd2d0`
- Runner SHA-256: `a97fc44203904cae3b39c2d15aeaf0ae139846286368e9ab8ff00b90ba3f06ba`
- Access auditor SHA-256: `653bfa462238ea6dadeb37fb8f4f89367575477e282a349beb44a83ec8848664`
- Registry SHA-256: `c8b0974164f178b98d4546b0dce4c4bac69eb45d66b3d22f09924996f29af7d8`
- Targeted tests SHA-256: `ebc52d607df9fef85a3989d312cb8739895b4ac647cf7fcef9d40c1eb07c2f8f`
- Prepared case inputs: exactly 50 under `output/gaia-paper-v3p77-case-inputs`

These inference sources are frozen at execution. Any subsequent semantic source
change invalidates v3.77 and requires a newly versioned direct-incumbent
experiment.

## Offline verification and execution contract

- Python compilation and protocol registration passed.
- 21 targeted and adjacent regression tests passed, including negative schema,
  exact ledger order, pairwise winner, same-Step materialization, three-stage
  runtime, and freeze-contract checks.
- Prepared scope is exactly 50 cases with the frozen dataset/cohort hashes above.
- Run fresh case directories only; do not import any prior prediction or scored
  artifact and do not run a smoke gate.
- Require 50/50 cases, 150 successful semantic stages, all schema/taxonomy/
  evidence validators, the owner-explicit read-only access/write audit, no case
  routing, no prior predictions, and a complete gold-free freeze before scoring.
- Accept only above `25/50`; complete the Goal only at `>=30/50`. Otherwise reject
  v3.77 unchanged, perform the full first-divergence audit, and create the next
  semantic version directly from the then-current accepted incumbent.

# E9-v19 Dry3 Failure Case Study

## Attempt and formal result

E9-v19 ran one frozen dry3 batch with `deepseek-v4-pro` and the default
request body.  The logical-completion counter moved from 367 to 368.  The HTTP
response completed once with `finish_reason=stop`, no retry, and strict valid
JSON.  This confirms the model switch fixed E9-v18's unmatched-brace failure.

The promotion gate still failed: 2/3 outputs were structurally valid, one was
rejected for an invalid audit evidence quote, and only C01 matched the official
root.  Formal metrics are 1/3 Step, 1/3 Step+Module, and 1/3 All Correct with
one failed prediction.

## Per-case attribution

| Case | Official root | Raw Pro root | Attribution |
| --- | --- | --- | --- |
| C01 | step 30, `system/step_limit` | step 30, `system/step_limit` | Correct.  The terminal-boundary rule and incumbent review both worked. |
| C02 | step 1, `action/misalignment` | step 4, `planning/constraint_ignorance` | The final root remained semantically wrong.  In addition, a non-contiguous planning quote in the auxiliary module scan made the case invalid before the otherwise exact final tuple could be accepted.  The model continued to equate literal plan/action agreement with valid action ownership, even though the chosen list-page representation could not supply the requested historical fact. |
| C03 | step 13, `planning/inefficient_plan` | step 30, `system/step_limit` | The model treated different result pages and query rewrites as continuing progress.  Those steps change state but repeatedly yield the same no-match evidence; the plan itself repeatedly acknowledges stagnation.  The step limit is therefore a downstream boundary under the benchmark label, not the critical defect. |

## Root attribution

E9-v19 has three independent findings:

1. `deepseek-v4-pro` resolves the strict JSON conformance problem.
2. The large five-lane audit is counterproductive.  It adds 25 optional
   semantic fields per batch and allows an irrelevant lane quote to invalidate
   an otherwise parseable final tuple.  The final classification does not need
   those fields to remain LLM-as-a-judge.
3. The causal rules still conflate new interface state with new task evidence,
   and they let a later conspicuous plan error displace an earlier incapable
   action merely because the action literally followed its plan.

## Bounded optimization hypothesis

E9-v20 will retain Pro, the default request body, complete gold-free traces,
and the frozen priors.  It will replace the five-lane response with a minimal
LLM review object plus the final atomic tuple.  Only the final quote is bound
to trajectory evidence; no auxiliary quote can invalidate a case.

The semantic protocol will add two general distinctions:

- a changed page is task progress only when it adds evidence relevant to an
  unmet constraint; repeated no-match pages after the plan recognizes
  stagnation are an inefficient policy, and a later deliberate query reset
  can recover the earlier page loop before a new repetition becomes active;
- literal intention/action agreement does not rescue an action aimed at a
  representation known to omit the required information.  A later visible
  error does not displace that earlier action when the later branch never
  reconnects to the abandoned constraints.

The next dry3 attempt is preregistered for one logical completion (368 to 369)
and must produce three valid outputs with at least 2/3 Step, Step+Module, and
All Correct.  No deterministic rule selects or repairs the root; all final
semantic fields remain the raw Pro output.

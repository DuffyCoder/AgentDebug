# Luna v3.20 / v3.39 与论文 AgentDebug 的 Step 定位差异

日期：2026-08-25

## 结论

v3.20 与 v3.39 的共同优势是高精度冻结：v3.20 以 25/50 成为 accepted
incumbent；v3.39 的新 challenger 在它自己的 fresh anchor 上造成三次 direct
gain、零次 direct regression。共同上限则是召回不足：v3.20 会在第一个存活
候选处冻结，v3.39 只允许一个严格更晚的 proposal，其 anchor-plus-proposal
oracle 仍是 25/50。

论文 AgentDebug 的公开描述先对每个 Step×Module 做局部 taxonomy 分析，再把
完整轨迹、所有局部分析和 critical criterion 一起做全局根因选择。这个结构的
主要价值是候选覆盖，不是最终仲裁精度。冻结的公开仓库式 GPT-4.1 复现实验中，
Phase 1 在发布 gold Step 上至少产生一个 positive 局部错误的覆盖是 35/50；它
与 v3.20 exact 的评分后 union oracle 是 43/50，其中覆盖 v3.20 的 18/25 个
错例。但同一 Phase 1 共报出 457 个 positive Step，平均 9.14 个/例，而公开
Phase 2 最终只有 14/50。

因此下一步的最小统一方向是测试“local recall 与 critical promotion 分离”：
从干净 v3.20 产生完整、anchor-blind 的局部错误画像，但画像中的 local error
不自动成为候选；一个 anchor-preserving causal promotion 阶段只有在候选通过
局部 owner、恢复/探针 veto、candidate-only repair 和 anchor-only repair 的
对称检查后，才允许晋升一个 earlier-or-later proposal。其余情况精确保留
v3.20 anchor。

## 可比较事实

| 维度 | Luna v3.20 | Luna v3.39 | 论文/公开 AgentDebug |
|---|---|---|---|
| Step Exact | 25/50 | 25/50 | 论文报告 29/50；本地公开拓扑复现 14/50 |
| semantic parent | v3.4 系列 anchor，经 packet-state closure | 直接 v3.20 | 独立 GPT-4.1、temperature 0 两阶段 detector |
| 局部扫描 | 单一 chronological ledger；多 lane 在同一扫描内竞争 | 与 v3.20 anchor 完全相同 | 每个 Step 的 Memory/Reflection/Planning/Action 分别做局部 taxonomy 映射 |
| 候选冻结 | 第一个通过 admission/veto 的 Step 写入 checkpoint | anchor 冻结后只找一个严格更晚 typed boundary | Phase 1 保留全轨迹局部错误画像；Phase 2 再做全局 critical selection |
| 回看能力 | checkpoint 后主要靠一个保守 challenger | 可否定 reasonable-probe/noncritical anchor，但只能向后 | Phase 2 可读取完整轨迹和全部 Phase 1 分析，不受单一 anchor 方向限制 |
| counterfactual | prompt 内 local-repair 与 causal-boundary 判断 | 分开写 anchor-only 与 proposal-only repair | 论文 prose 称逐步替换并测试；同版 Algorithm 1 又明确写 Stage 2 是 LLM、无 rollout/counterfactual |
| incumbent 保护 | write-once Step freeze；default keep | default keep；不确定即 no-challenge | 公开 Phase 2 没有外部 incumbent，直接产生最终 critical Step |
| 合法性 | Canonical JudgeView、literal evidence、taxonomy/schema、hash 与 gold-free audit | 同 v3.20 加 typed witness contract | 公开代码使用宽松 JSON repair，并会按 error type 自动改 module；不是本地严格 validator 等价物 |

论文来源：[arXiv 论文](https://arxiv.org/html/2509.25370)；
[公开仓库](https://github.com/ulab-uiuc/AgentDebug)。论文 Table 1 报告 GAIA
Step 58.0%，即 29/50。论文 Algorithm 1 的 Stage 2 注释与 3.2 节的
counterfactual prose 互相矛盾；公开 detector 实际执行的是局部 LLM 分析后的一次
全局 LLM 选择，真实 re-rollout 位于定位完成后的 downstream debugging 阶段。

## v3.20 与 v3.39 为什么停在 25

v3.20 的 25 个 Step 错误按 first divergence 分为：11 个
`false_candidate_admission`、7 个 `candidate_recall_failure`、3 个
`early_freeze_failure`、2 个 `late_symptom_preference`、1 个
`challenger_recall_failure` 和 1 个 `annotation_ambiguity`。按机制簇看，9 个属于
细粒度召回/晚症状边界，7 个属于 acquisition capability 过早报错，4 个属于
strategy maturity 过早冻结，另有 2 个机械参数 false positive。

v3.39 改善了“anchor 是合理 probe、稍后才出现成熟状态/策略边界”的一部分：
11 个 proposal 中 3 个 proposal Step exact，arbiter 接受 6 个，其中三次是
direct gain、三次是 wrong-to-wrong，没有直接推翻正确 fresh anchor。但它没有
形成目标所需的新覆盖：fresh anchor 22/50，final 25/50，anchor-plus-proposal
oracle 也只有 25/50。相对冻结 v3.20 的正式转移是 4 gains、4 losses，净值 0；
四个 losses 都来自 fresh-anchor sampling drift，而不是 challenger override。

这说明 v3.39 的 causal promotion 精度值得保留为设计性质，但它的 challenger
同时承担“发现局部错误”和“证明 critical root”，导致过度保守。v3.45 把同类
anchor-aware challenger 扩为四个独立 session 后仍只有 7 个 raw challenge，
48 个完成 selector 中 45 个 keep-anchor，进一步支持这个诊断。

## 论文方法带来的有效信号与无效信号

### 有效信号：先完整保留局部错误，再判断 criticality

公开 Phase 1 的评分后 gold-Step-positive 覆盖是 35/50，明显高于任一最终
Judge。与 v3.20 exact 的 union oracle 达到 43/50，证明局部画像中存在足够多的
潜在增益信号。尤其 Memory/Reflection 的局部检查可以在后续 Planning 症状出现
前保留状态丢失或 outcome misread，而 v3.20 的跨 lane 首候选竞争容易把这些信号
压掉。

### 无效信号：把所有 local positive 直接交给自由全局 selector

公开 Phase 1 有 457 个 positive Step、739 个 positive module verdict；中位数
每例 5 个 positive Step，最大 26 个。公开 Phase 2 最终只有 14/50。v3.44 也给出
同方向反例：独立全边界 ballots 把候选 oracle 提到 29/50，但自由 selector 将
final 降到 13/50，造成 12 次 direct regression。

所以完整画像只能是 evidence inventory，不能成为 votes、majority、最早 positive
或最强措辞排序。anchor 的已验证精度必须在独立的 promotion gate 中显式保留。

### 不能据公开材料归因的部分

论文没有发布 Table 1 的逐例预测、中间 Phase 1/2 artifacts、实际实验 commit、
provider snapshot 或调用日志。论文对 detection-stage counterfactual 的算法与
文字说明也不一致。本地以 GPT-4.1、temperature 0 对齐公开仓库拓扑仍只有
14/50。因此不能把 29/50 归因于换模型、公开 prompt 字面文本或真实 replay 中的
任何一个单独因素。

## 下一版本的单一假设

新版本应直接以 v3.20 为 semantic parent，只增加一个主要机制：

`module-complete local error profile -> anchor-preserving causal promotion`

1. 画像阶段不读 anchor，不判断最终 critical Step；按模块覆盖全部可观察 Step，
   只记录 literal local error、owner、相邻反馈关系和是否出现可观察 recovery。
2. promotion 阶段读取冻结 v3.20 anchor、完整画像和匿名当前轨迹，但不读取任何
   旧预测或评分产物。
3. local positive 只有同时满足以下条件才可成为唯一 proposal：owner 与证据同
   Step；不是 initial/different probe、normal failure、mechanical repair、recovered
   defect、faithful propagation 或 downstream symptom；candidate-only repair 能改变
   失败路径。
4. proposal 还必须证明 anchor 是 reasonable probe/noncritical predecessor 或已
   recovery，并证明 anchor-only repair 不能独立避免 later failure。不满足任一项就
   exact-copy keep anchor。
5. proposal 可早于或晚于 anchor，避免 v3.39 的单向 recall ceiling；最终仍只允许
   v3.20 anchor 或一个新生成 proposal，禁止候选投票与逐例拼接。

预期修复对象是 v3.20 的 9 个细粒度召回/晚症状错误和部分 4 个 early-freeze
错误。主要回归风险是局部画像中的 surface error、合理探针和已恢复缺陷使正确
anchor 被推翻；公开 Phase 1 的 9.14 positive Steps/例与 v3.44 的 12 次 direct
regression 是直接反例。故本版本的可证伪条件不仅是 final Step Exact 未超过
25/50，也包括 promotion 对 fresh-anchor 产生任何明显的 false override 集群。

v3.39、v3.40--v3.45 的 prompt、validator、candidate、selector 和 prediction 均
不作为 semantic parent，也不进入 inference。它们只提供上述评分后机制证据。

## v3.47 完整实验后的修正结论

上述 `module-complete local error profile -> anchor-preserving causal promotion`
已经由干净 v3.20 分支上的 v3.47 完整检验并被拒绝。v3.47 合法完成 50/50，
Step Exact 为 `19/50`；相对 v3.20 是 1 gain、7 losses。fresh anchor 自身只有
18/50，promotion 在 50 例中 49 次 keep、1 次 promote；唯一 promote 把错误
anchor 修正为 gold，没有 direct regression。

五个模块画像共生成 576 条 local-error rows，在 23/50 例覆盖 gold Step；其中只
覆盖 v3.20 错例的 10/25，同时也在 v3.20 正例的 13/25 覆盖 gold。对 v3.47 自己
的 fresh anchor，anchor 或 profile 包含 gold 的评分后 oracle 是 31/50。这说明
画像确实产生了足以越过目标线的候选覆盖，但 local-positive 本身不是 criticality
信号：它既大量漏召回，也大量出现在 incumbent-correct case 中。

因此下一步不应继续扩大 local-error recall，也不应直接放宽 promotion。更小且更
可证伪的方向是：先把完整画像压缩为至多一个 anchor-blind critical-boundary
proposal，再只让该 proposal 与 fresh v3.20 anchor 做 pairwise duel；压缩时显式
执行 probe、different-probe、normal failure、recovery、mechanical predecessor、
faithful propagation 和 downstream symptom veto。未形成唯一可观察优势时保留
anchor。该方向保留论文的“局部分析后全局选择”，同时把 v3.44 的自由 tournament
和 v3.47 的 576-row all-positive proof gate 都排除在外。

## v3.49 / v3.50 完整实验后的修正结论

v3.49 从干净 v3.20 分支直接测试了一个 anchor-blind、全轨迹、max-one
global causal proposal，再与 fresh v3.20 anchor 做 exact-copy duel。完整
GAIA-50 合法完成，Step Exact 为 `25/50`，因此与 incumbent 打平并被拒绝。
它的 fresh anchor 是 `21/50`；proposal 命中 gold Step `16/50`，其中在
anchor-wrong case 命中 6 例；duel 产生 6 次 direct gain、2 次 direct loss，
把 final 提升到 `25/50`。这说明 v3.49 的 selection 有正净收益，主要上限是
max-one proposal recall：anchor-plus-proposal oracle 只有 `27/50`。

v3.50 随后从干净 v3.20 分支测试论文式因子化：五个 anchor-blind Module
inventory、一个 global compression、一个 bounded duel。完整 GAIA-50 也合法
完成，但 Step Exact 降至 `15/50`，相对 v3.20 为 1 gain、11 losses。五个
inventory 共生成 703 条 local-error rows，却只覆盖 `20/50` 个 gold Step、
`10/50` 个 gold Step+owner；global proposal 只命中 `11/50`，fresh
anchor-plus-proposal oracle 只有 `22/50`。duel 对 fresh anchor 的 direct 结果为
0 gain、6 losses、3 wrong-to-wrong。因而 v3.50 同时复现了论文公开拓扑的两个
失败面：局部错误候选洪泛并未带来足够 critical-boundary recall，自由的定性
override 又会把正确 anchor 推错。

这两轮把下一步方向进一步收窄：不再扩大 local-error inventory，也不再把
局部 positive 当候选或 vote。最有希望的未检验单一机制，是从 v3.20 干净分支
复制若干个彼此隔离、每个最多输出一个 complete critical boundary 的
anchor-blind global proposal；候选池保持常数上界，并由一个 anchor-preserving
selector 进行 exact-copy 选择。历史评分后诊断显示，v3.20、v3.39 typed
proposal 与 v3.49 global proposal 的候选 union 为 `31/50`；但该数字只用于
提出可证伪假设，不能进入 inference、routing 或逐例拼接。新实验必须用 fresh
proposal 重新证明候选 oracle 与最终 Step Exact，且任何版本仍只相对 v3.20
incumbent 接受或拒绝。

## v3.54 / v3.56 对论文差异的进一步定位

v3.54 和 v3.56 都从 accepted v3.20 干净分支重新测试了论文式“先局部、后全局”
信号。v3.54 的完整 Step-local census 在 `31/50` 覆盖 gold，fresh anchor 与局部
positive 的 union oracle 是 `36/50`；但单 proposal 压缩将候选 union oracle
降到 `24/50`，duel 又产生 1 gain、4 losses，final 只有 `18/50`。

v3.56 保留完整局部矩阵直到一个 anchor-aware selector，并加入五类 causal
representative、literal veto 和 two-sided repair relation。它合法完成全部
`817/817` sessions，Step Exact 为 `22/50`，相对 v3.20 是 3 gains、6 losses，
因此拒绝。它的 fresh anchor 为 `21/50`，完整局部矩阵 gold coverage 升到
`36/50`，anchor-union oracle 达 `41/50`；但是五类 representative 仅覆盖
`5/50` gold，anchor-union representative oracle 只剩 `22/50`。selector 48 次
keep、2 次 override，相对 fresh anchor 是 1 gain、0 loss、1 wrong-to-wrong。

这使与论文 AgentDebug 29/50 的差异更具体：Luna 当前并不缺少论文 Phase 1 风格
的局部 evidence inventory，缺少的是把局部 Step×Module 信号带入全局比较时不先
用“已经证明是独立 critical root”的过强门槛将其丢弃。v3.56 的 28 个错误中，
17 个在 gold 已是 taxonomy-valid local positive 后仍被 maturity/class gate 删除；
7 个是更早的 Step-local recall miss；4 个属于发布 annotation ambiguity。

下一步的最小统一方向是从 v3.20 再建干净分支，只移植 Step-isolated local
taxonomy 信号，并把五类 causal-maturity admission 换成确定性的 paper-module
reservoir：每个 Module 保留最早一个 positive row，最多五个；随后由独立的
anchor-aware exact-copy selector 判断 criticality。评分后候选分析表明，该
reservoir 覆盖 `25/50` gold，fresh-anchor union oracle 为 `33/50`，在当前错误中
有 11 个 gold 候选；但它也让 18 个 incumbent-correct case 暴露于非-gold 候选，
所以候选覆盖不是接受依据，完整 GAIA-50 的 Step Exact `>25/50` 才能接受，
`>=30/50` 才能完成 Goal。

## v3.57 对下一方向的完整验证

v3.57 从 v3.20 干净重建了 Step-isolated taxonomy、确定性的每 Module 最早正例
reservoir 和一个 anchor-aware selector。完整 GAIA-50 合法完成，但 Step Exact
只有 `20/50`；相对 v3.20 是 1 gain、6 losses，因此拒绝。fresh anchor 为
`19/50`，selector 对 fresh anchor 是 2 gains、1 loss、5 wrong-to-wrong。

关键分层不是最终分数本身，而是局部到全局的信息损失位置：完整 local matrix
覆盖 `35/50` gold，fresh-anchor union oracle 为 `41/50`；earliest-per-Module
压缩后 gold coverage 降到 `22/50`，但 anchor-reservoir oracle 仍有 `31/50`。
最终 30 个错误中，9 个 gold 已经作为 representative 出现却没有被 selector
选择，另 9 个 gold 是同 Module 的较晚 local positive，被 earliest-only 规则
丢弃。也就是说，v3.57 同时证明了：候选上限已经越过目标线；Module 最早正例
不是 criticality 排序信号；当前主要瓶颈是比较关系，而不是继续增加 local
positive 数量。

这也校正了 v3.20/v3.39 与论文的差异结论。v3.20 和 v3.39 各为 `25/50`，只共享
21 个 exact，评分后 union 只有 `29/50`；即使存在一个完美的二选一器也只能追平
论文，无法达到 Goal 的 `30/50`。论文式 Step×Module 局部分析确实能提供两者都
没有的新边界，但不能把 local positive 当 vote、最早正例或最强措辞。下一步
最小可证伪方向是把 anchor 与每个有界 representative 隔离成一对一比较，隐藏
候选来源并显式闭合 probe/recovery/propagation/normal-failure 与两侧 repair
关系；只有独立比较一致否定 anchor 时才允许 exact-copy override。该方向的直接
反例是 v3.44 的 provenance-blind 自由 tournament（13/50）和 v3.57 的一次 false
override，因此必须保持有界候选、逐对隔离、默认保留和一致性门槛，不能恢复自由
全局投票。

## v3.59 后的结论：论文式 local inventory 不是当前最短路径

v3.59 从 v3.20 干净分支完整重建了 `717/717` Step-local census、最早
per-Module reservoir、observed-continuation pairwise assessment 和确定性结果组装。
50/50 推理、gold-free freeze 与全部合法性验证通过，但 Step Exact 只有
`18/50`；fresh anchor 为 `19/50`。相对 fresh anchor，reducer 是 0 gain、1
loss、4 wrong-to-wrong；相对 frozen v3.20 是 0 gain、7 losses。

信息损失再次发生在论文两阶段接口处：完整 local matrix 覆盖 `35/50` gold，
但 earliest-per-Module reservoir 只有 `22/50`；fresh-anchor-plus-reservoir oracle
仅 `28/50`。即使 gold 已进入 representative，强制所有 pair 共享同一个 global
anchor class 仍会让 observed-continuation closure 无法改变 eligibility。因而继续
调这个 pairwise selector 最多只能到 28，不能完成 30/50 Goal。

新的更小对照来自 accepted v3.20 自身，而不是 rejected local lineage。v3.20
chronological ledger 只有 131 行，平均 2.62 行/例、最多 9 行，却在评分后覆盖
`32/50` gold Step；其中 8 个 incumbent 错例的 gold 已是 selected anchor 之前的
ledger row。23 个保持 v3.20 anchor 语义的历史 fresh run 中，ledger gold coverage
平均 `31.26/50`，20/23 次达到至少 30。相比论文公开 Phase 1 的 457 个 positive
Step，这个候选集同时满足稀疏和 Goal-level recall。

因此下一步不再扩大 Step×Module local positives。更有希望的统一机制是：从干净
v3.20 保留全部已扫描的 prefix ledger rows，对每个 pre-anchor row 在看到其实际
Step outcome 后做强制、独立的 retrospective closure；`initial_probe` 和
`different_probe` 是先验信息，不再是 outcome 后的类别性 veto。只有 literal local
defect、observed outcome、path effect、recovery 与 earliest-boundary 检查一致时，
才允许机械地将 Step 向前移动，否则 exact-copy keep anchor。主要风险是 17 个
incumbent-correct case 也暴露于 earlier rows，因此本机制的成败取决于早选 precision，
而不是 candidate recall。

## v3.62 / v3.64 / v3.65 后的最终差异定位

后续三个完整实验进一步排除了“只要扩大候选或加强全轨迹因果门就能复现论文
29/50”的解释。v3.62 的完整 local matrix 覆盖 `29/50` gold、与 fresh anchor 的
union 为 `39/50`，但 whole-trajectory replaceability gate 只让 gold candidate 在
pairwise 中赢 2 例，最终只有 `18/50`。v3.64 的三个异构 specialist 合计只覆盖
`15/50` gold，anchor-plus-panel oracle `26/50`，final `18/50`，并且 attempt-scope
写拓扑不合法。异构 role 并没有自动补齐 benchmark boundary。

v3.65 从 v3.20 干净重建了 outcome-conditioned max-one global proposal，并把
`reasonable probe` 重新看作可由实际 outcome 推翻的先验。完整 50 例的 fresh
anchor 是 `19/50`，proposal gold recall `15/50`，anchor-plus-proposal oracle 只有
`23/50`；duel 相对 fresh anchor 是 3 gain、3 loss，final 仍为 `19/50`。它相对
冻结 v3.20 是 2 gain、8 loss。独立审计还发现 84 次目录枚举、11 次 attempt 外
file change、10 个非法文件和 26 个非法目录，因此版本永久拒绝。

v3.65 最重要的新信号不在 final proposal，而在它未送入 duel 的 v3.20 稀疏
ledger：共 140 行，覆盖 `29/50` gold；ledger 与 global proposal 的评分后 union
是 `33/50`。其中 10 个 fresh-anchor 错例的 gold 已是 earlier ledger row，主要被
`veto_initial_probe` 或 `veto_different_probe` 排除。v3.60 已证明“产生任意可复用
中间线索就永久保留 probe”的绝对规则过强；v3.65 又证明“必须零贡献”才成熟同样
过强。两者之间尚未检验的边界是 exact-predicate maturity：一个 probe 即使给出
部分线索，只要按当时参数/模态无法直接暴露任务要求的精确谓词，实际 outcome
仍未解决该谓词，并且后续 anchor 只是重复或传播同一缺口，它就可能是更早的
benchmark critical boundary。

因此下一步不继承 v3.62--v3.65。应从 v3.20 干净分支只测试一个
`exact-predicate acquisition boundary reducer`：保留 v3.20 的稀疏 ledger，允许
一个 later boundary，使用“精确任务谓词是否可由该 Step 直接获得”而不是“是否
产生任何中间贡献”或“是否单独修好全轨迹”做相对比较。为消除 v3.61/v3.64/v3.65
反复出现的路径写错，新 runner 应使用 read-only、JSON-schema、response-only
session，由父进程在 attempt 内物化并验证 artifact；这只是合法性基础设施，不是
额外语义机制。

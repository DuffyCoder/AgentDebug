# Luna GAIA v3.72 预注册：exact-predicate reducer，binding materialization

状态：执行前冻结。

## 冻结实验合同

- semantic parent：accepted Luna v3.20，Step Exact `25/50`。
- 版本：`agentdebug.codex-agent-judge.luna-gaia.v3.72-clean-v3.20-exact-predicate-acquisition-boundary-reducer-binding-materialized`。
- 数据集：冻结 `gaia-paper-v1` 50 例。
- 模型/effort：`gpt-5.6-luna` / `medium`。
- v3.4 基线：Step Exact `21/50`。
- 接受：合法完整 GAIA-50 Step Exact `>25/50`。
- Goal 完成：合法完整 GAIA-50 Step Exact `>=30/50`。
- 无 smoke 门控；直接完整 GAIA-50。

唯一主要语义机制仍是从 v3.20 clean branch 单独移植的 `exact-predicate acquisition
boundary reducer`。v3.20 anchor、candidate maturity gate、owner-explicit JudgeView、
evidence exact-copy materialization 和 deterministic selector 均保持不变。不继承 rejected
lineage 的其他机制；semantic parent 始终是 v3.20，推理不读取历史逐例预测。

## v3.71 first divergence 与唯一 binding 修正

v3.71 完成全部 50 例尝试，49 例通过；唯一失败是第 31 例 reducer 两次都提出
`unbound_exact_predicate_prefix_candidate`，因此未评分、未读 gold。其 evidence
materialization 共在 9 个 anchor attempt 生效并全部通过 strict validator，说明该合法性
修正有效。

v3.72 只把既有 validator 的结构 binding 变成父进程确定性 admission veto：

- `prefix_ledger` 仅在 candidate Step 早于 anchor，且唯一 matching ledger row 的 lane_c
  为 `veto_initial_probe` 或 `veto_different_probe` 时保留；
- `later_boundary` 仅在 candidate Step 晚于 anchor 时保留；
- origin/Step 未绑定时，把 assessment 的 candidate payload 和 gate 字段按既有
  `candidate_status=none` contract 规范化，deterministic selector 因而保留 fresh v3.20
  anchor；
- 所有已绑定 candidate 原样保留；不新增候选、不修改 anchor、不读取 gold；每次 veto
  写入 materialization record 和评分前 audit。

该修正机械执行原已冻结的候选集合边界，不是逐例路由。它会让无效 candidate 的 Step
回到 anchor，但这些 candidate 在原 validator 下本就不能进入任何合法 frozen result。

## gains、regressions 与判伪

Step gain/回归仍由 exact-predicate reducer 决定。结构 veto 的风险是模型虽选错 origin，
但其 Step 可能在另一 origin 下语义可辩；本版本选择保守地保留 incumbent anchor，而不
猜测重分类。直接反例是 50/50 仍失败、valid candidate 被改变、或结果相对 v3.20 没有
正净收益。

若相对 frozen v3.20 gains 不大于 losses、final Step Exact `<=25/50`，或 50/50、schema、
taxonomy、evidence、hash、gold-free、tool-free、write-topology 任一验证失败，则拒绝。
只有合法 `>=30/50` 才完成 Goal。

## 执行前冻结哈希与离线验证

- protocol：`56f6b2dc5e4db1697811cfe4ffebf93a9a400a210c203c917ca83c87d03d4db1`
- runner：`847092877e5bc1546493410a2df7798ab02abb2a3ce8c24cb9c09028f2d0768d`
- access auditor：`87be2218aa195bc9d63b5cf5b041e0e47eaa67415b92bf2e27838e65f26fb58f`
- registry：`71c755f609ac757f1587eef971603256bbab8bd193f120f4f5eecf88ab674e44`
- tests：`480121331d85ff8d060529f7f85bef90b68226112eb490ed0a374a8d273cbe39`
- taxonomy：`d7e4b878059bbecec0a8fd3f078c0aeb5755bf9e65bb938c897dd83685f28c5c`
- semantic parent v3.20：`3e886325bf0a4b4d4a3e770071c0a36fe81dab2bebaf5015561ca828b6c2e4f9`
- prediction manifest：`77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- cohort：`31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`

离线验证：v3.72--v3.66 及 v3.20 相关测试 `44 passed`；compile、registry、真实 executor
protocol-interface inventory、50-case dry plan、100 sessions 和 direct parent 全部通过。
测试使用 v3.71 实际第 31 例失败 artifact，确认 unbound candidate 变为 none 后 strict
assessment validator 通过；并用 v3.71 实际合法 candidate 证明 no-op。

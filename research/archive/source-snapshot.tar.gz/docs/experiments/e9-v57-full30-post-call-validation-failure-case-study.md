# E9-v57 full30 post-call validation failure case study

## Completed external work

The full30 phase consumed its exact ten-call budget (cumulative 648 -> 658),
reused the accepted dry batch, and persisted 30 unscored rows plus a complete
predict-run document. No further LLM call is required or authorized for this
run.

## Observed failure

Offline validation crashed before gold loading with `JudgeOutputError: The
judge response must be a JSON object.` The failing value was `None`.

## Root cause

Batch 8's provider call was persisted as a batch-level `judge_exception`, so
its three cases correctly became failed predictions with no raw semantic JSON.
The prediction path handled this state and wrote three invalid rows. The
validator, however, unconditionally called the semantic JSON parser for every
cached stage, including non-success stages. It should instead require
`parsed_output is None` for a failed stage and validate the already-persisted
failure outcome.

## Offline finalization attempt 1

The corrected raw-chain validator passed all 30 rows. The subsequent scoring
adapter then repeated the same mistake while constructing its per-trajectory
root map: it unconditionally parsed the failed batch's `None` raw response.
This second failure occurred after gold loading but before output/promotion
writing. The completion ledger remained byte-identical and no provider was
constructed.

The additional correction is the same state transition at the scoring join:
successful stage -> parse adjudications; failed stage -> assign `None` roots to
all cases and retain their already-validated failure statuses. This does not
alter any semantic output and keeps the three failures in every metric
denominator.

This is a validator state-machine bug, not a reason to retry batch 8. Retrying
would violate the frozen `retry_failures=False` contract and change the exact
full30 attempt.

## Bound evidence

- unscored row count: 30
- reviewer success rows: 27
- batch-8 judge-exception rows: 3
- final semantic success rows after case-level validation: 26
- other invalid rows: 1 contract/format failure
- full ledger entries: 10/10
- predict-run exists and binds the 30-row file

## Correction

For a stage whose cached status is `success`, reconstruct and compare the
parsed semantic document as before. For any non-success stage, require cached
`parsed_output` to be `None` and never call the JSON parser. Add a provider-free
`finalize` command that validates the existing 30 rows, then loads gold, scores,
and writes promotion. It must accept the original frozen execution archive as
historical code identity while binding the patched offline finalizer; it must
not construct a provider or modify the logical-completion ledger.

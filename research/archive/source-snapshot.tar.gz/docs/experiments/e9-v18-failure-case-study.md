# E9-v18 Dry3 Failure Case Study

## Attempt and observed failure

E9-v18 ran the frozen three-case tuning batch once with
`deepseek-v4-flash`, the default request body (`model` and `messages` only),
and no HTTP retry.  The logical-completion counter moved from 366 to 367.
The provider reported `finish_reason=stop`, but the raw response ended with
`}}]}` where the requested top-level shape required `}]}`.  The unmatched
object close is at zero-based character 4743.  Strict parsing therefore
classified all three rows as `invalid_json`; the formal result is 0/3 Step,
0/3 Step+Module, 0/3 All Correct, with three failed predictions.

This is a model-output conformance failure, not a transport failure: there was
one successful HTTP response, nonzero provider usage, no retry, and no
truncation finish reason.  It reproduces the extra-closing-brace family seen
with earlier Flash outputs even though the request uses no thinking or other
custom body field.

## Per-case semantic counterfactual

Removing only the unmatched final character permits an *offline diagnostic*
parse.  This is not accepted as a prediction and no production artifact is
repaired or rescored from it.

| Case | Official root | Diagnostic raw root | Attribution |
| --- | --- | --- | --- |
| C01 | step 30, `system/step_limit` | step 30, `system/step_limit` | Semantically correct.  The incumbent rule preserved a supported terminal boundary. |
| C02 | step 1, `action/misalignment` | step 4, `planning/constraint_ignorance` | The Critic treated the list-page extraction as a reasonable recovered probe.  That recovery was not task-closing: the later search abandoned the required closed/Regression constraints and the run never identified the required issue or label-addition date. |
| C03 | step 13, `planning/inefficient_plan` | step 6, `planning/inefficient_plan` | Module/type are correct but the Critic selected the mature repetition in the first search episode.  The official annotation points to step 13 in the second episode, while its prose says the plan issued an almost-identical query; the canonical step-13 output instead plans another page click.  This is an observed annotation/timeline inconsistency, not something to hide with post-processing. |

Even under the diagnostic parse the attempt would be only 1/3 Step Exact, so
syntax repair cannot make v18 pass the 2/3 signal gate.

## Root attribution

There are two independent causes:

1. Flash failed the strict JSON contract with one unmatched closing brace.
2. The semantic protocol's recovery test is too permissive for an incapable
   information source: changing tools counts as recovery even when the new
   branch never restores the original constraints.  Its search-episode rule
   also chooses the first mature repetition, which conflicts with the C03
   annotation's step despite agreeing on module and type.

## Bounded optimization hypothesis

The next attempt will be E9-v19 and will change two conditions:

- use the user-requested `deepseek-v4-pro` model with the same default request
  body and no thinking or response-format option, to test whether Pro obeys
  the exact JSON envelope;
- strengthen the general recovery rule: an exploratory action aimed at a
  representation that cannot expose the required item-level historical fact
  is action misalignment, and a later tool change is recovery only if it
  reconnects to every unmet task constraint.  Merely abandoning the failed
  branch is not recovery.

C01 must remain step 30 `system/step_limit`; C02 should return to step 1
`action/misalignment`.  C03 may remain a known noisy localization case.  The
preregistered v19 dry gate is at least 2/3 Step, Step+Module, and All Correct,
all three outputs valid, for one additional logical completion (367 to 368).
No unchanged retry is permitted.

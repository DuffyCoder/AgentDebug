# Luna GAIA v3.70 预注册：exact-predicate reducer，owner-explicit contract

状态：执行前冻结。

## 冻结实验合同

- semantic parent：accepted Luna v3.20，Step Exact `25/50`。
- 版本：`agentdebug.codex-agent-judge.luna-gaia.v3.70-clean-v3.20-exact-predicate-acquisition-boundary-reducer-owner-explicit`。
- 数据集：冻结 `gaia-paper-v1` 50 例。
- 模型/effort：`gpt-5.6-luna` / `medium`。
- v3.4 基线：Step Exact `21/50`。
- 接受：合法完整 GAIA-50 Step Exact `>25/50`。
- Goal 完成：合法完整 GAIA-50 Step Exact `>=30/50`。
- 无 smoke 门控；直接完整 GAIA-50。

唯一主要语义机制仍是从 v3.20 clean branch 单独移植的 `exact-predicate acquisition
boundary reducer`：最多提出一个满足全部 capability/outcome/contribution/route/repair/
recovery/chronology gate 的 earlier probe-veto row 或 later mature boundary，否则 exact-copy
fresh v3.20 anchor。Module/type 只用于合法输出。

本版本不继承 rejected lineage 的其他 proposal、panel、challenger、arbiter 或 selector
机制。v3.66--v3.69 只提供同一个待重检机制及运行失败证据；semantic parent 始终是
v3.20，推理不读取 v3.20 或历史逐例预测。

## v3.69 runtime first divergence 与唯一 artifact-contract 修正

v3.69 完成全部 50 例尝试，45 例通过，5 例未通过合法性，因此未评分、未读 gold：

- 3 例 anchor 在两次重试后仍为 `invalid_evidence_ownership`；compact JudgeView 要求模型
  用 character offsets 从 `assistant_raw_output` 重建 Module owner，实际 response 引用了
  非对应 owner 的文本。
- 2 例 reducer 为 `unbound_exact_predicate_prefix_candidate`；response 把普通 pre-anchor
  row 标为 `prefix_ledger`，但既有 validator 只允许 lane_c 为 `veto_initial_probe` 或
  `veto_different_probe` 的 matching row。

v3.70 只修正同一个模型—validator artifact contract，不改变 candidate 资格或选择算法：

- 直接嵌入逐 Step、逐 Module 的完整 `literal_owner_sources`，删除需要模型自行切片的
  raw+offset 重复表示；原始完整 owner 文本、feedback 时间线和 System sources 均保留。
- 在 reducer task 中逐字暴露既有 prefix/later binding：prefix 必须早于 anchor 且 matching
  row 的 lane_c 为两个 probe veto 之一；later 必须晚于 anchor。validator 本身不放宽。
- response-only、read-only、两次安全结构重试、模型、effort 和 exact-copy selector 不变。

## gains、regressions 与判伪

Step gain 假设仍是 exact-predicate reducer 可以纠正 v3.20 对 earlier matured probe 或 later
independent acquisition boundary 的遗漏。主要 Step 回归风险仍是有用 probe 被过早升级，
或 later symptom 被误当独立边界。artifact-contract 修正本身可能改变模型注意力分配，但
没有扩大合法候选集合；直接反例是 owner 显式化后仍不能在两次重试内合法完成 50/50。

若相对 frozen v3.20 gains 不大于 losses、final Step Exact `<=25/50`，或 50/50、schema、
taxonomy、evidence、hash、gold-free、tool-free、write-topology 任一验证失败，则拒绝。
只有合法 `>=30/50` 才完成 Goal。

## 执行前冻结哈希与离线验证

- protocol：`c0c9881505623cda39d4eddf219bb68c7206c7cf5c6074b856793fc386eb1cf6`
- runner：`e1b3d69a823d297d915a651681f0efbf3458f780e07dfa9d94d915b0d4ef7ae0`
- access auditor：`d35237fd41edbf5927bae34f6e369a02e2945bfadd78c00f037690892df96e92`
- registry：`84dcb13931c9177798c1479661ff92c630acc20ac549191f9656d52f0e1a9255`
- tests：`e4f4c284c4cee955335b3a4236dc4178b907d12253d5e554c5dc5649d3b9e1bc`
- taxonomy：`d7e4b878059bbecec0a8fd3f078c0aeb5755bf9e65bb938c897dd83685f28c5c`
- semantic parent v3.20：`3e886325bf0a4b4d4a3e770071c0a36fe81dab2bebaf5015561ca828b6c2e4f9`
- prediction manifest：`77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- cohort：`31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`

离线验证：v3.70/v3.69/v3.68/v3.67/v3.66/v3.20 相关测试 `34 passed`；compile、
registry、真实 executor protocol-interface inventory、owner-source equality、既有
prefix-binding prompt、50-case dry plan、100 sessions 和 direct parent 全部通过。50 个
anchor prompt 长度为 `30,893--802,805`，均低于 CLI 上限 `1,048,576`。

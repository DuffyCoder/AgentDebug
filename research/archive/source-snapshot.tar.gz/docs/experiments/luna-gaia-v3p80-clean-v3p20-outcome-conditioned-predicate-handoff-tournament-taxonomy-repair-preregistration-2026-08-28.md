# Luna GAIA v3.80 pre-registration

## Frozen identity

- Protocol: `agentdebug.codex-agent-judge.luna-gaia.v3.80-clean-v3.20-outcome-conditioned-predicate-handoff-tournament-taxonomy-repair`
- Semantic parent: accepted incumbent `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Incumbent Step Exact: `25/50`
- Original v3.4 baseline: `21/50`
- Dataset/model/effort: frozen `gaia-paper-v1` 50, `gpt-5.6-luna`, `medium`
- Acceptance: legal full-50 Step Exact `>25/50`
- Goal completion: legal full-50 Step Exact `>=30/50`
- Smoke gate: none

## Semantic mechanism and runtime-only repair

v3.80 is a clean direct semantic child of v3.20 and re-tests exactly the one
v3.79 mechanism:

> Outcome-conditioned exact-predicate handoff tournament over every native v3.20 ledger Step.

Anchor and tournament inference prompts are byte-equivalent to v3.79 after
version-name normalization. No v3.79 prediction or artifact enters inference.

v3.79 completed 49/50 cases and stopped before freeze and scoring. The only failed
case returned the same explicit Step and unique winner in both attempts, but copied
the intermediate `unresolved_predicate_handoff` role into `selected_error_type`.
The existing owner materializer repaired Module/evidence but did not guarantee a
validator-compatible Module/type/evidence triple.

The v3.80 runtime-only repair first preserves any already valid triple. Otherwise,
after `selected_step` is frozen, it deterministically enumerates taxonomy-valid
types for the selected Module, then other legal owners only if necessary, and
exact-copies evidence from the selected Step's validator owner sources. It accepts
the first triple that passes the unchanged strict prediction validator. It never
changes `selected_step`, winner row, decision, handoff role, or tournament prose.

This is legal output materialization, not another Step-selection mechanism.
Module/type/evidence are schema/taxonomy constraints and cannot affect version
selection. Any Step change aborts the run.

## Falsifiable hypothesis and risk

The semantic gain/regression hypothesis is exactly v3.79's: an initially reasonable
probe may mature into the benchmark critical boundary only after its actual outcome
leaves an identifiable exact predicate unresolved and the same gap propagates.
Expected gains are v3.78's six reviewed-gold underpromotions; regression risk is an
early probe incorrectly defeating an incumbent-correct anchor. Same-gap,
informative-progress, prompt-repair, recovery, independent-branch, and downstream
vetoes remain unchanged.

The runtime risk is accidentally changing semantic Step ownership. Offline replay
of all 49 valid v3.79 final attempts plus both failed attempts passes 51/51 after
repair with 51/51 selected Steps unchanged. The two failed attempts acquire valid
taxonomy and exact selected-owner evidence without altering their Step-2 winner.

## Frozen inputs and sources

- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort membership SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Semantic prediction-manifest SHA-256: `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`
- Protocol SHA-256: `694d7d83b4ccca10a82c88cffa4519cc847c1a086e28c41dc70c454e72604b74`
- Runner SHA-256: `ad7636996aecbb40941e670c5bec775054f2f7c51f947adba0b7c847e39cea19`
- Access auditor SHA-256: `7e43f46e6964be62968fb6edf605aebc82ee409b6ae890d9a5d310989cce4fee`
- Registry SHA-256: `c8040a2ae3d95b630fcd7fd77b3637c22810b073ee1cf1e8022de2c102e4cec5`
- Targeted tests SHA-256: `2d3e4626fd90cf5bd0fd8f336a840aeaaeaac59986d9a7cdb51bddbd70e441d6`
- Prepared case inputs: exactly 50 under `output/gaia-paper-v3p80-case-inputs`

These sources are frozen at execution; any semantic source change requires a new
direct-incumbent version.

## Offline and execution contract

- Compilation, registration, prompt equivalence, strict negative validation, and
  17 targeted/adjacent tests passed.
- Run 50 fresh cases and 100 planned isolated stages, with no smoke or prior
  predictions.
- Require 50/50 completion, full legality, access/write audit, no routing or gold
  access, and gold-free freeze before scoring.
- Accept only above `25/50`; complete only at `>=30/50`. Otherwise reject unchanged,
  perform full first-divergence analysis, and branch from the accepted incumbent.

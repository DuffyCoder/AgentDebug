# Luna GAIA v3.75 预注册：sparse-ledger global boundary selector

日期：2026-08-28  
状态：执行前冻结；尚未运行推理、尚未读取本版本 gold

## 冻结身份

- version：`agentdebug.codex-agent-judge.luna-gaia.v3.75-clean-v3.20-sparse-ledger-global-boundary-selector`
- direct semantic parent：`agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- accepted incumbent：Luna v3.20，Step Exact `25/50`
- original baseline：Luna v3.4，Step Exact `21/50`
- dataset：冻结 `gaia-paper-v1`，50 例
- dataset manifest SHA-256：`fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- cohort membership SHA-256：`193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- cohort manifest file SHA-256：`31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- prediction-manifest semantic SHA-256：`56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`
- prediction-manifest file SHA-256：`77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- model：`gpt-5.6-luna`
- reasoning effort：`medium`
- smoke gate：无
- version acceptance：完整、合法 GAIA-50 且 Step Exact `>25/50`
- Goal completion：完整、合法 GAIA-50 且 Step Exact `>=30/50`

## 上一轮 evidence 与唯一假设

v3.74 合法完成 GAIA-50，但 Step Exact 为 `21/50`，相对 frozen v3.20 是
2 gains、6 losses。它的 unchanged fresh v3.20 anchor 为 `20/50`；
exact-predicate reducer 仅在 2/50 例输出 candidate，candidate Step 仅 1/50
命中 gold，对 fresh anchor 是 1 direct gain、0 direct loss。该机制因此被拒绝，
且不作为本版本 semantic parent。

评分后事实显示，同一 fresh anchor 的 v3.20 sparse ledger 只有 144 行，却覆盖
`31/50` gold Step；fresh anchor 与 ledger 的 union oracle 同为 `31/50`。在
fresh anchor 错误的 case 中，11 个 gold Step 已经是 ledger row，但 v3.74 的
probe/maturity pre-admission gate 将其中绝大多数在比较前删除。first divergence
分布为 24 个 `anchor_error` 和 5 个 `annotation_ambiguity`；主要可操作簇是
gold ledger row 被 maturity gate 删除、sparse inventory recall gap，以及单次
fresh anchor 采样回归。

本版本唯一假设是：保留 v3.20 已经稀疏的 ledger boundary Steps 到一次全局比较，
不先用 reasonable-probe、recovery、exact-predicate maturity 或 whole-trajectory
repair 作为类别性 admission gate；同时只允许从 anchor 之后完整时间线补充至多一个
later boundary。一个结构化 selector 必须逐一比较全部 ledger Steps、可选 later
Step 与 frozen anchor，最后只输出一个 Step。这样可保留论文 AgentDebug 的全局选择
优点，同时避免 v3.12-global 的 446-candidate 洪泛。

## 相对 v3.20 的唯一主要机制变化

保留并重新执行完全相同的 v3.20 packet-state anchor、chronological ledger 和
checkpoint。相对 v3.20 只增加：

`all sparse-ledger Steps + at most one backward-traced later Step -> one structured global critical-boundary selector`

具体 contract：

1. selector 看到完整、gold-free、owner-explicit 当前 JudgeView、fresh anchor Step 和
   ledger Step 数字；看不到 ledger lane、veto、surviving-lane、decision-basis 等来源
   判决，避免把 v3.20 的旧 admission 当成 vote。
2. ledger 中每个 Step 都必须进入 `candidate_reviews`，不得在比较前删除；Step 按
   chronology 保留。
3. selector 可从 anchor 之后完整时间线补充至多一个 later Step，不能建立无界候选池。
4. 每个候选统一记录 observable local defect、实际 outcome、recovery、与最终失败的
   relation 和 criticality；合理 probe、normal failure、recovered defect、faithful
   propagation、downstream symptom 是比较证据，但不是候选删除规则。
5. critical boundary 是最早的、具体的、改变物质失败分支的局部错误；只要求修复该
   Step 会重定向下一条物质路径，不要求它单独修好完整轨迹。
6. 未形成相对 anchor 的明确 literal-evidence 优势时 exact-copy keep anchor；replace
   只能选一个 reviewed prefix Step 或唯一 later Step。
7. 模型冻结 Step；父进程只做 identity、same-Step owner/evidence、taxonomy 合法性
   materialization，绝不改变模型选中的 Step。

v3.66--v3.74 的 exact-predicate prompt、maturity gate、candidate origin 约束和逐例
prediction 不继承。复用的 response-only、owner-explicit、read-only、hash/freeze
scaffolding 是显式迁移并重新验证的非语义合法性基础设施，不进入 Step 选择规则。

## 预期 gains 与 regressions

预期 gain 来源：v3.74 fresh anchor 错误但 gold 已在 sparse ledger 的 11 例，以及
ledger 未覆盖但一个 backward-traced later boundary 能召回的部分 case。它们共享的
failure mode 是候选在全局比较前被 gate 删除或 anchor 之后根本没有候选槽位。

回归风险：

- 25 个 frozen incumbent-correct case 会暴露于 earlier ledger Steps；
- selector 可能把合理初始 probe 当 root，整体变早；
- 唯一 later slot 可能恢复 v3.12-global 的晚期症状偏置；
- 单次 fresh anchor 仍可能发生采样漂移；
- sparse-ledger union 的评分后 `31/50` 不是最终分数保证，selector 必须几乎不损失
  候选信号才能达到 Goal。

防护：candidate 数量由 sparse ledger 加至多一个 later Step 常数限制；逐候选 review
覆盖由 validator 强制；selected Step 必须出现在 review；keep 时 exact-copy anchor；
不允许 source-model、trajectory ID、实体、网站或旧预测进入决策。

## 可证伪条件

以下任一条件即可拒绝该机制：

- 完整合法 GAIA-50 Step Exact `<=25/50`；
- 相对本轮 fresh anchor，selector 的 direct gains 不严格多于 direct losses；
- reviewed candidate oracle 评分后 `<30/50`；
- gold ledger row 仍系统性在 selector 中被标为 noncritical，而 false override 形成新的
  early-probe 或 late-symptom 集群；
- 50/50、schema/taxonomy/evidence、gold-free、case-routing、hash、order、read/write
  isolation 或 freeze 任一验证失败。

## 执行与冻结

- 每例两个 fresh Luna medium stage：unchanged v3.20 anchor；sparse-ledger global
  boundary selector。最终结果由父进程按 frozen selector Step 机械组装。
- 计划 100 个 stage completions，每阶段最多一次结构/合法性 retry。
- 无 smoke；离线验证通过后直接完整 GAIA-50。
- 推理阶段不读取 labels、metrics、scored artifacts、旧预测、错误审计、case study、
  gold rationale、实验文档或 git history。
- 冻结所有 anchor、ledger、checkpoint、candidate reviews、selection、predictions、
  validator audits、access audit 与 hashes 后才评分。
- gains、losses、接受/拒绝只相对 frozen v3.20；Step Exact 是唯一版本选择指标。

## 执行前 source freeze

首次 inference 前冻结如下；此后若任一文件变化，必须使用新版本号：

- protocol：`4172649f6aeec05b7b939eae0bcb1b10bf05f7ce332e7c1992ca6db597461977`
- runner：`01cf29d27c85442a25a023a7585e89d7227159508193df7441e6f9a5b8340d3f`
- access auditor：`17e10c47280d021baa7066cc30b395364d3f2d0202ba67db574caaa150cb1d44`
- registry：`159562a5916eddffb6c068f9e817a322dffb9832203685a8f824193b5bd0b5ad`
- tests：`dfafaafcf9979cc8682cec85aaee47e83d67022c0b7fe1fce09d90ad0940af47`
- direct parent v3.20 source：`3e886325bf0a4b4d4a3e770071c0a36fe81dab2bebaf5015561ca828b6c2e4f9`
- prediction manifest file：`77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- cohort manifest file：`31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`

离线验证：新版本与 v3.20/v3.66/v3.67/v3.70/v3.74 相关测试共 `37 passed`；
新版本定向测试 `8 passed`；`git diff --check` 通过；gold-free full-50 plan
成功生成，计划 50 cases、100 stage completions、无 smoke。

# GAIA v3.102 GPT-5.5 tournament result

Date: 2026-08-30

## Decision

Rejected and immutable. v3.102 completed all `50/50` cases and passed every
gold-free access, schema, taxonomy, evidence, ordering, exact-copy, and freeze
gate, but Step Exact was only `21/50`, below accepted v3.83 at `26/50`.

## Step transitions against v3.83

- both correct: 13;
- v3.83 wrong / v3.102 correct: 8;
- v3.83 correct / v3.102 wrong: 13;
- both wrong: 16;
- net Step change: `8 - 13 = -5`.

The tournament itself changed a fresh anchor from wrong to exact in six cases,
from exact to wrong in eleven, and wrong to a different wrong Step in eight.
The remaining two gains and two losses arose before the tournament from fresh
anchor sampling differences.

## First divergence

All 29 Step errors have structured post-score audits. Distribution:

- `false_challenger_override`: 11;
- `false_candidate_admission`: 6;
- `arbiter_selection_failure`: 5;
- `anchor_error`: 4;
- `early_freeze_failure`: 2;
- `annotation_ambiguity`: 1.

The strongest uniform defect is loss of native initial-probe veto precedence.
The tournament selected a row whose v3.83 ledger had
`lane_c=veto_initial_probe` in eleven Step-transition cases: two gains and nine
losses, net `-7`. Applying only a hard final veto to those selections on the
already frozen v3.102 artifacts gives a descriptive counterfactual `28/50`.
This is post-score impact analysis, not an accepted result and not a prediction
splice.

Authoritative artifacts:

- `analysis/step-error-audit.json`;
- `analysis/step-error-clusters.json`;
- `analysis/predicate-handoff-tournament-impact.json`;
- `gold-free-freeze-audit.json`;
- `scored/metrics.json`.


# E9-v23 Flash Novelty-Calibrated Recovery

E9-v23 retains Flash, the default request body, raw-only semantics, evidence
source IDs, verbatim evidence projection, and the narrow single-tail-brace
repair.

The review must now provide one concrete earlier candidate step.  A later
recovery is optional, but when present it must follow the candidate and the
final root must occur at or after recovery.  Novel state coverage remains
plausible exploration: opening an admissible container that has not previously
been inspected is not a repetitive plan solely because earlier containers
were empty.

For search episodes, the first deliberate reset can recover an initial page
walk.  Later queries do not reset maturity when they are exact or semantic
near-duplicates of a query whose results already demonstrated the same
failure signal.  Reordering words, changing punctuation, or dropping a still
required constraint is not a new acquisition strategy.

The frozen budgets are dry3 371 to 372, full30 372 to 382, and future fresh
smoke 382 to the implementation ceiling 415.  Only dry3 fits the current user
authorization through 380.

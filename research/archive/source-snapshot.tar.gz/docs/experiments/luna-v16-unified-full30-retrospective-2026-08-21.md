# Luna v16 unified：tuning-v1 full-30 实验复盘

日期：2026-08-21

## 结论

正式实验 `agentdebug.codex-agent-judge.luna-v16-unified-v1` 完成了完整、冻结的
`tuning-v1` 30 条运行。30/30 prediction 合法，30 个 accepted thread 彼此独立，
所有 runtime、session、lineage、implementation、prediction、secret、pre-score 与
post-score audit 均通过；gold 只在 prediction 冻结并完成 pre-score audit 后加载。

官方结果为：

- Step Exact：**6/30（20.0%）**；
- Step+Module：**2/30（6.7%）**；
- All Correct：**1/25（4.0%）**；
- ALFWorld / GAIA / WebShop Step：**1/10 / 4/10 / 1/10**。

这是一次严格有效的 tuning 负向实验，但低于 v14 的 9/30、v15-v2 的 7/30 和最终
目标 12/30，不能晋升，也不能表述为 held-out 或未知数据上的泛化结果。

本轮最重要的结论是：

1. **候选召回恢复到 14/30，但仲裁只保留 6/14。** 24 个 Step 错误中，16 个是
   recall miss，8 个是 gold 已在候选池内却被选错。v16 的首要瓶颈已从“有没有
   candidate”转成“如何公平比较 candidate”。
2. **parent 添加的 strategy predecessor 有召回价值，却在行为上被完全忽略。**
   C/L/S 三个 witness 的 Step union 只有 9/30；加入 strategy `S-1` 后升至
   14/30。新增的 5 个 gold candidate 全是仅由 parent 生成的 predecessor，但
   最终一个也没被选中。
3. **所谓 lane-blind 只在持久化 card 字段上成立。** 同一响应中，模型先生成
   witness，再仲裁，所以仍记得候选来源和重复提名次数。双 witness card 18/19
   被选，P-only card 0/22 被选，形成了实质投票偏差。
4. **Step/owner 的结构解耦没有形成推理解耦。** 28/30 最终 owner atom 直接复制
   所选 Step 上的某个 witness atom；Reflection、System 一次也没被恢复。6 个
   Step 正确样本中只有 2 个 Module 正确、1 个 Type 正确。
5. **Planning sink 仍然严重。** 最终 Module 为 Planning 23、Action 5、Memory 2、
   Reflection 0、System 0；而 gold 分布为 Planning 12、Action 5、Memory 5、
   Reflection 6、System 2。
6. **运行可靠性不是本轮分数瓶颈。** 34 次 session 全部 transport/process/session
   正常；4 次首次失败均为 parent semantic-contract 拒绝，重试后 Step 和 owner
   4/4 不变。它们增加了约 12.46% input 成本，但没有改变官方 Step 指标。

下一轮不应再加入一个自由文本 locator，也不应无差别扩展大范围 `±k` 候选。最有
证据的方向是：对每个 witness 机械形成 `{X-1, X}`，先做完全对称、exact-evidence
的局部边界比较，再对 2--3 个 pair winner 做全局仲裁；同时消除 nomination
重复投票，并把 owner/type 改成在 witness 与仲裁之前完成的可审计预提交。

## 正式运行的有效性与成本

本轮满足当前固定实验边界：

- frozen `tuning-v1` 30 条，环境分布 10/10/10；
- 固定 `gpt-5.6-luna`、reasoning effort `medium`；
- 30 个 fresh ephemeral accepted session，每个 session 只接收一条匿名轨迹；
- 34 个 thread ID 全局唯一，30 个 accepted thread ID 唯一；
- 最大并发 4，每条最多 2 次，只重试失败 case；
- model-visible tools 为 0，实际 tool/file/network calls 为 0；
- 30/30 decision、prediction、evidence binding 和 parent lineage 重算通过；
- 推理阶段不可见历史 prediction、proposal、case identity、gold 或评分文件；
- implementation snapshot、frozen prompts、decision、prediction、audit、metrics、
  per-example 与 score artifacts 均已持久化；
- 正式 audit 如实记录 classification 并非上下文隐藏：
  `classification_context_isolated=false`、`classification_context_hidden=false`、
  `single_response_autoregressive_visibility=true`。

Token 使用：

| 项目 | 总量 | Accepted attempts | 废弃的首次尝试 |
|---|---:|---:|---:|
| attempts | 34 | 30 | 4 |
| input tokens | 2,590,813 | 2,268,115 | 322,698 |
| cached input tokens（包含在 input 中） | 24,320 | 24,320 | 0 |
| output tokens | 61,839 | 56,495 | 5,344 |
| reasoning output tokens（包含在 output 中） | 28,702 | 27,230 | 1,472 |

四个废弃 attempt 占总 input 的 12.46%、总 output 的 8.64%。产物没有美元价格
元数据，因此不能可靠换算货币成本；官方 `scored/report.md` 中约 56 秒是评分进程
时长，不是 30 条模型推理的总 wall time。

关键冻结哈希：

| 产物 | SHA-256 |
|---|---|
| v16 protocol 源文件 | `fc991c973fc677aa5b4fac4470ac588e6dbe5a3f4c13940cec957a423039573b` |
| v16 runner | `f492f73ea93ed98c2de120dcee56b4d815f66c0eff59d2523c03abe2e602eb9a` |
| implementation aggregate | `cd11533614d43b13cd5c19f7dc742e6788604cb3eb3de685924a0735b0c95cb3` |
| frozen predictions | `506b9178a9acd20154728bda7569ad6fba8dda8426d230b25d8a8e5a8e296384` |
| official metrics | `d5d9b57ad92505a71571131df65471d5c09027339133848cda68ab5a4b4c0fc8` |

## Candidate recall 与仲裁

以下 `C/L/S/P` 分别表示 chronological witness、local witness、strategy witness，
以及 parent 机械添加的 strategy predecessor `S-1`。Candidate oracle 仅在完整预测
和 pre-score audit 冻结后用 gold 计算，是评分后诊断上限，不是预测准确率。

| 环境 | Pool 含 gold | Final Step | Recall miss | Arbitration loss |
|---|---:|---:|---:|---:|
| ALFWorld | 4/10 | 1/10 | 6 | 3 |
| GAIA | 6/10 | 4/10 | 4 | 2 |
| WebShop | 4/10 | 1/10 | 6 | 3 |
| **总计** | **14/30** | **6/30** | **16** | **8** |

候选池平均 3.03 个 Step：1 个候选的 case 有 1 条，2 个候选的有 1 条，3 个
候选的有 24 条，4 个候选的有 4 条。

| 来源 | Gold Step 命中 | 独占贡献 |
|---|---:|---|
| C | 7 | case 26 |
| L | 3 | case 27 |
| S | 5 | 无 |
| C/L/S union | 9 | — |
| P | 7 | cases 01、02、08、18、28；case 19 与 L 重合 |
| C/L/S/P union | 14 | — |

来源锚定非常明显：

- 22 张 card 仅由 P 产生，其中 5 张是 gold，但最终 **0/22** 被选择；
- 被两个直接 witness 重复提名的 card 为 19 张，最终 **18/19** 被选择，但只有
  4 张是 gold；
- 只被一个直接 witness 提名且不与 P 重合的 card 为 44 张，最终只有 9/44 被选；
- 最终选择来源组合为 C+S 16、S 5、C 4、L+S 2、C+P 2、C+L+S 1，P-only 0。

因此问题并不是 card 上是否显示 lane 名称，而是同一个自回归响应已经看见自己在
前面提名了什么、提名了几次。后续“忽略来源”无法删除这些 token。

### 30-case 候选账本

| Case | Gold owner/type | C | L | S | P | Pool | Final owner/type | 结果 |
|---:|---|---:|---:|---:|---:|---|---|---|
| 01 | S3 Planning/— | 4 | 5 | 4 | 3 | 3/4/5 | S4 Planning/inefficient | 仲裁错 |
| 02 | S5 Reflection/causal | 4 | 9 | 6 | 5 | 4/5/6/9 | S4 Planning/inefficient | 仲裁错 |
| 03 | S1 Action/— | 18 | 26 | 18 | 17 | 17/18/26 | S18 Planning/impossible | 召回错 |
| 04 | S5 Memory/— | 8 | 28 | 8 | 7 | 7/8/28 | S8 Action/format | 召回错 |
| 05 | S30 System/step_limit | 6 | 16 | 16 | 15 | 6/15/16 | S6 Planning/inefficient | 召回错 |
| 06 | S4 Planning/— | 8 | 5 | 8 | 7 | 5/7/8 | S8 Planning/inefficient | 召回错 |
| 07 | S6 Reflection/progress | 6 | 13 | 6 | 5 | 5/6/13 | S6 Planning/constraint | Step |
| 08 | S5 Memory/retrieval | 6 | 22 | 6 | 5 | 5/6/22 | S6 Planning/inefficient | 仲裁错 |
| 09 | S4 Planning/impossible | 12 | 20 | 12 | 11 | 11/12/20 | S12 Action/parameter | 召回错 |
| 10 | S4 Planning/inefficient | 11 | 14 | 14 | 13 | 11/13/14 | S14 Planning/inefficient | 召回错 |
| 11 | S4 Reflection/outcome | 4 | 5 | 4 | 3 | 3/4/5 | S4 Planning/inefficient | Step |
| 12 | S1 Planning/constraint | 1 | 1 | 1 | — | 1 | S1 Action/parameter | Step |
| 13 | S1 Action/misalignment | 4 | 2 | 3 | 2 | 2/3/4 | S3 Planning/constraint | 召回错 |
| 14 | S3 Memory/over_simple | 7 | 8 | 7 | 6 | 6/7/8 | S7 Planning/inefficient | 召回错 |
| 15 | S1 Action/parameter | 1 | 13 | 2 | 1 | 1/2/13 | S1 Action/parameter | All |
| 16 | S6 Planning/inefficient | 4 | 28 | 4 | 3 | 3/4/28 | S4 Planning/inefficient | 召回错 |
| 17 | S4 Reflection/outcome | 9 | 10 | 9 | 8 | 8/9/10 | S9 Planning/inefficient | 召回错 |
| 18 | S5 Planning/inefficient | 6 | 20 | 6 | 5 | 5/6/20 | S6 Planning/inefficient | 仲裁错 |
| 19 | S2 Planning/inefficient | 1 | 2 | 3 | 2 | 1/2/3 | S3 Planning/inefficient | 仲裁错 |
| 20 | S2 Action/misalignment | 2 | 6 | 2 | 1 | 1/2/6 | S2 Action/parameter | Step+Module |
| 21 | S13 Planning/inefficient | 4 | 15 | 6 | 5 | 4/5/6/15 | S4 Planning/inefficient | 召回错 |
| 22 | S6 Reflection/causal | 12 | 29 | 12 | 11 | 11/12/29 | S12 Planning/inefficient | 召回错 |
| 23 | S2 Memory/hallucination | 10 | 23 | 24 | 23 | 10/23/24 | S24 Planning/constraint | 召回错 |
| 24 | S21 Planning/inefficient | 8 | 25 | 8 | 7 | 7/8/25 | S8 Planning/inefficient | 召回错 |
| 25 | S8 Planning/constraint | 4 | 24 | 1 | — | 1/4/24 | S1 Planning/constraint | 召回错 |
| 26 | S4 Planning/— | 4 | 11 | 6 | 5 | 4/5/6/11 | S6 Planning/constraint | 仲裁错 |
| 27 | S7 Action/misalignment | 4 | 7 | 5 | 4 | 4/5/7 | S4 Planning/inefficient | 仲裁错 |
| 28 | S4 Memory/over_simple | 2 | 5 | 5 | 4 | 2/4/5 | S5 Memory/hallucination | 仲裁错 |
| 29 | S2 Reflection/progress | 14 | 21 | 16 | 15 | 14/15/16/21 | S14 Memory/hallucination | 召回错 |
| 30 | S1 System/environment | 1 | 3 | 1 | — | 1/3 | S1 Planning/constraint | Step |

## 24 个 Step error 的逐例归因

下述 gold 与 label rationale 只在 predictions、lineage、prediction audit 与
pre-score audit 冻结后用于分析。9 条 gold label 没有 rationale：cases
`01,03,04,06,22,23,26,28,30`；它们不能驱动逐例硬规则。

### ALFWorld

| Case | Gold → Pred | 失败层 | 深层原因与通用修复 |
|---:|---|---|---|
| 01 | S3 → S4 | 仲裁 | P 已加入 S3，但没有与直接 witness 等价的 exact defect 证据；仲裁把它视作合理首探，选择 S4 的“成熟重复”。需要对 `{X-1,X}` 完全对称取证，而非无条件左移。 |
| 02 | S5 → S4 | 仲裁 | S5 Reflection 固守“desk 1 最可能有灯”的错误因果假设；仲裁却选择较早、较泛化的 Planning 重复。需要 `previous result → current interpretation` 双证据。 |
| 03 | S1 → S18 | 召回 | 官方 Action S1 无 type/rationale，所有 locator 被晚期 drawer/prerequisite 链吸走。应保留标注噪声可能性，不能据此把所有 Action 边界左移。 |
| 04 | S5 → S8 | 召回 | S5 Memory 根因没有被任何 witness 提名，显眼的 S8/S28 后续 Action/重复抢占。需要 Memory material-omission/retrieval 专项关系。 |
| 05 | S30 → S6 | 召回/不可表达 | Gold 是 System/step_limit，但输入没有 typed stop、cap 或 termination fact。不得用“30 步”或最后一步猜 System；上游必须提供可审计 termination provenance。 |
| 06 | S4 → S8 | 召回 | S4 是首次偏离 targeted locations、转向 generic `look` 的策略边界；L=S5 已相邻。对每个 anchor 都生成 `X-1` 可召回，当前只扩了 strategy。 |
| 08 | S5 → S6 | 仲裁 | S5 Memory 忘记 S2 已执行 `look`，S6 只是消费错误状态的后继计划。仲裁却把 S5 称为合理 confirmation。需要 historical action/result 对 Memory claim 的直接反证。 |
| 09 | S4 → S12 | 召回 | S4 在尚未定位 desklamp 时就计划使用它；locator 被 S12/S20 更显眼的 malformed execution 吸引。需要 task affordance/prerequisite 与 plan 的结构检查。 |
| 10 | S4 → S14 | 召回 | 冰箱无 tomato 后，S4 开始低信息 cabinet brute force；模型直到 S11/S14 才认定 repetition 成熟。需要显式 strategy epoch onset 与 maturity，而非只报后者。 |

### GAIA

| Case | Gold → Pred | 失败层 | 深层原因与通用修复 |
|---:|---|---|---|
| 13 | S1 → S3 | 召回 | S1 对 GitHub issues 搜索 URL 使用不适合的 extractor；L 落在相邻 S2 的表现。`L-1` 可召回，但必须用 tool/source capability evidence 判断 owner。 |
| 14 | S3 → S7 | 召回 | S3 Memory 省略 PDF 已损坏/不可用的决定性信息；局部 contradiction locator 无法识别 material omission。需要 current claim 与 omitted observation 的双原子。 |
| 16 | S6 → S4 | 召回 | 同类低效检索到 S6 才是第三次成熟重做；v16 反而把 S4 的合理确认过早判错。应由代码按 tool、canonical args、result hash 和 epoch 计数。 |
| 17 | S4 → S9 | 召回 | S4 Reflection 把只获得链接/失败结果误判为成功；locator 直到后续搜索重复才响应。严格 external atom 应自动产生 Step candidate，但最终 owner 仍在同 Step 后置比较 Reflection/System。 |
| 18 | S5 → S6 | 仲裁 | P 精确加入 S5；S5 是首次回到相似无效检索，S6 才是更显眼的后续重复。需要 onset/consumer 的局部 pair comparison。 |
| 19 | S2 → S3 | 仲裁 | S2 将未验证假设继续写入 query，S3 unsupported answer 只是消费它。需要 hypothesis-contamination/answer-conditioned-query evidence，不能按终局文字显眼程度选择。 |

### WebShop

| Case | Gold → Pred | 失败层 | 深层原因与通用修复 |
|---:|---|---|---|
| 21 | S13 → S4 | 召回 | S13 才是近重复 query；模型跨 query epoch 累计 pagination，过早把普通翻页 S4 判为成熟错误。需 normalized query、constraint delta 与 result-set hash 划分 epoch。 |
| 22 | S6 → S12 | 召回 | S6 Reflection 错误归因上一动作/结果并把无关浏览称为 progress；locator 只看到 S12 后的导航循环。需要 previous action/result → current state claim 关系。 |
| 23 | S2 → S24 | 召回 | S2 Memory 只凭可见子集就断言全部商品不匹配；需要对 `none/all/no relevant result` 等全称状态 claim 做证据覆盖检查。 |
| 24 | S21 → S8 | 召回 | 真正重复属于后一个 query epoch 的 S21；全局累计把早期 pagination 当 root。和 case 21 一样，需要 epoch reset，而非整轨迹 recurrence。 |
| 25 | S8 → S1 | 召回 | S8 才把不满足品类/属性的商品当候选；模型偏向最早且抽象的 query 压缩。Task constraint 必须绑定具体 product/action decision。 |
| 26 | S4 → S6 | 仲裁 | C 已精确命中 S4 的低效继续翻页，仲裁却被 S6 更显眼的 constraint-drop query 吸走。应比较 earliest qualified defect，而不是解释文字强度。 |
| 27 | S7 → S4 | 仲裁 | L 精确命中“plan 要先验证颜色，Action 却直接购买”；模型反而选择更早、更推测性的 S4 backtrack。该例证明不能采用 blanket-earlier rule。 |
| 28 | S4 → S5 | 仲裁 | P 精确加入 S4 Memory omission，assessment 却声称无 Memory defect，选择 S5 的后继 hallucination。需要 omitted-observation 双证据与 producer/consumer 优先级。 |
| 29 | S2 → S14 | 召回 | S2 在页面已有相关商品时声称无结果并翻页；state locator 直到 S14/S21 才识别类似 false match。需要 state-claim family 的 earliest unsupported member。 |

## Step、owner 与 type

Step exact cases 为：`07,11,12,15,20,30`。

| Case | Gold owner/type | Pred owner/type | Gold pair 在所选 Step 可表达 |
|---:|---|---|---|
| 07 | Reflection / progress_misjudge | Planning / constraint_ignorance | 是 |
| 11 | Reflection / outcome_misinterpretation | Planning / inefficient_plan | 是 |
| 12 | Planning / constraint_ignorance | Action / parameter_error | 是 |
| 15 | Action / parameter_error | Action / parameter_error | 是 |
| 20 | Action / misalignment | Action / parameter_error | 是 |
| 30 | System / environment_error | Planning / constraint_ignorance | 否，无 System atom |

因此 owner@correct-Step 为 2/6，type@correct-Step 为 1/6，只有 case 15 All
Correct。忽略 Step 的 Module exact 为 13/30、covered Type exact 为 8/25，但这些
数值被错误 Step 上反复预测 Planning/inefficient_plan 放大，不能代表条件分类能力。

Gold 与预测 Module 分布：

| Module | Gold | Pred |
|---|---:|---:|
| Planning | 12 | 23 |
| Action | 5 | 5 |
| Memory | 5 | 2 |
| Reflection | 6 | 0 |
| System | 2 | 0 |

24 个 Step 错例中，Module 为 Planning 20、Action 2、Memory 2；error type 为
`inefficient_plan` 15、`constraint_ignorance` 4、`hallucination` 2，其余各 1。

结构上，25/30 selected Step 同时有 Memory、Reflection、Planning、Action atom，
另 5/30 有 Planning、Action atom；但：

- selected owner atom 在 28/30 中直接等于所选 Step 上的某个 witness atom；
- selected owner 在 29/30 中与所选 Step 的至少一个 witness owner 相同；
- witness owner 冲突的 5 个 case 全部复制其中一个 witness atom；
- Reflection/System 从未由 classification 独立恢复。

当前生成顺序是：

`owner-bearing witness → 每个候选的五类 module prose → classification`

Phase D 已经用自然语言完成了一次 module/type 判断；Phase E 只是复述。validator
能证明 classification 没有在数据依赖上读取 witness 字段，却无法让模型忘掉同一
响应里已经生成的 token。

此外，case 05 的 System/step_limit 与 case 30 的 System/environment_error 在各自
gold Step 都没有严格 System atom，是表示能力缺口。不得重新放宽为“任意 Step-1
task text”或“任意 30-step 终止”即可触发 System；必须补 typed、可审计的上游事实。

## 重试分析

四条首次失败全部是 semantic-contract 摩擦，而非 API、进程、JSON schema 或
session 故障：

| Case | 第一次失败码 | 具体问题 | attempt-2 稳定性 |
|---:|---|---|---|
| 07 | `assessment_not_nominated` | 漏评强制 P card，并加入非法 card | Step/owner/atom/type 均不变 |
| 08 | `arbitration_provenance_leak` | 理由写出 “first candidate” | Step/owner/atom/type 均不变 |
| 09 | `assessment_not_nominated` | 评估了池外 predecessor | Step/owner/atom 不变，type 从 invalid_action 变 parameter_error |
| 20 | `incomplete_candidate_assessments` | 漏评强制 P card | Step/owner/atom/type 均不变 |

selected Step、owner 和 exact owner atom 在 4/4 retry 前后稳定，type 为 3/4；但
候选池只有 1/4 完全稳定。这说明 witness 生成仍高方差，而冗长 assessment/schema
约束制造了昂贵但不改变 Step 的 retries。下一版应减少模型复制动态候选集合和无
信息量的字段。

## 与 v14、v15 的关系

| 实验 | 状态 | Step | Step+Module | All | Candidate oracle | Oracle→Final |
|---|---|---:|---:|---:|---:|---:|
| v14 unified | 正式合规 | 9/30 | 2/30 | 1/25 | 12/30 | 9/12 |
| v15-v2 | 正式合规 | 7/30 | 2/30 | 1/25 | 7/30 | 7/7 |
| v16 unified | 正式合规 | 6/30 | 2/30 | 1/25 | 14/30 | 6/14 |

v16 相对 v15 的候选池新增 cases `01,02,08,19,26,27,28`，并保住 v15 的全部
7 个 gold candidate；这些新增候选没有一个转化成 final Step 命中，反而丢失 v15
正确的 case 18。相对 v14，v16 的最终 6 个 Step 命中完全是 v14 命中集合的子集，
没有新增 case。

因此 v16 的 6/30 不能归因于 locator recall 太低：它证明了恢复 recall 本身还不够。
同响应 nomination multiplicity、parent card 证据不对称和 owner-bearing arbitration
会把新增 recall 全部吞掉。

旧 routed v12 的 13/30 明确读取同 case 的 v3 prediction，并按旧答案分流
preserve/replace，违反当前固定边界，仍不能作为合法 incumbent 或目标完成证据。

## 评分后邻域诊断

以下只用于统一协议设计，不能作为成绩或逐 case 路由依据：

| 通用候选集合 | Gold Step coverage | 平均候选数 | 最大候选数 |
|---|---:|---:|---:|
| C/L/S | 9/30 | 2.30 | 3 |
| 当前 C/L/S + strategy `S-1` | 14/30 | 3.03 | 4 |
| 所有 anchor 加 `X-1` | 16/30 | 4.07 | 6 |
| 所有 anchor 加 `±1` | 16/30 | 5.57 | 8 |
| 所有 anchor 加 `±2` | 18/30 | 8.13 | 12 |
| 所有 anchor 加 `±3` | 19/30 | 10.47 | 16 |

对所有 anchor 加 predecessor 只增加适中的候选量，并新增 cases 06、13；继续加入
`+1` 没有额外 recall，`±2/±3` 则候选数迅速膨胀。因此下一版应采用有界 pair，
而不是扁平大池。

## 当前瓶颈

### P0：仲裁中的 nomination multiplicity 泄漏

lane 名称虽从 candidate card 删除，模型仍在同一响应里看见自己前面生成的 witness。
重复提名近似成为投票，parent-only candidate 没有任何行为权重。单靠 prompt 声明
“顺序与来源无偏好”已经被本轮数据证伪。

### P0：parent predecessor 没有对称证据

P card 只有 Step/local context，没有生成 witness 时的 exact atom、defect predicate、
历史反证和 counterfactual。仲裁自然把它称为“合理 probe”，再选证据更完整的 X。
新增候选因此提升 oracle，却没有提升 final。

### P0：边界比较混合了不同问题

当前 assessment 对每个候选同时写 Memory、Reflection、Planning、Action、System 五段
自由文本，并直接进行全局比较。这既放大 owner anchor，也让 later explicit symptom
压过 earlier subtle producer；case 27 又显示 blanket-earlier 会反过来压过 later
literal plan-action breach。

### P1：state/Reflection 的关系表示仍不足

Memory/Reflection 错误不是单个 Step 文本分类，而是：

- current claim 与 prior observation 矛盾；
- current Memory 遗漏 material fact；
- current progress/complete 判断不满足 task acceptance；
- current causal explanation 错配上一动作或结果。

没有“current claim atom + contradicted/omitted source atom”就无法稳定取证。

### P1：owner/type 没有 token-level precommit

字段后置不等于推理隔离。只要 classification 在 witness/arbitration prose 之后生成，
它就会复制前面的 owner 叙事。当前固定边界要求 30 条对应 30 个 session，因此不能
未经用户授权拆成额外 reviewer session；需要在单响应内改变生成顺序并强校验。

### P1：两类 System gold 缺 typed provenance

case 05、30 是上游表示缺口，不是 prompt 文案问题。在缺 typed stop/interface
signal 时，应保留不可表达的诚实上限，而不是放宽 System 造成广泛假阳性。

## 下一轮优化方向

在恢复新实验前，建议冻结以下统一、gold-free 方向：

1. **局部 pair-first topology。** 每个独立 anchor X 机械形成 `{X-1,X}`；先用
   完全相同字段、相同证据预算做 pair boundary comparison，再只把 2--3 个 pair
   winner 交给全局仲裁。
2. **给邻居等价 evidence。** Parent 为 X-1 解析 same-step candidate atom、
   local violation status、与 X 的 producer/consumer 关系及 counterfactual；不能
   只加入裸 Step card。
3. **消除重复投票。** C/L/S 指向同一步时只能形成一个 anchor，不把提名次数传给
   后续比较。Strategy 必须提供不同 Step 或显式 no-candidate；它在 v16 没有独占
   recall，不应通过复制 C 增权。
4. **用 qualified defect 决定前后归属。** Earlier 只有在有 literal/qualified
   defect 且 later 明确消费它时才能胜；若 earlier 是合理 probe、later 是收到反证
   后首次错误 recommitment，则选择 later。这样同时覆盖 cases 01/08/18/19/28，
   又避免 case 27 的 blanket-earlier 回退。
5. **重做 state witness。** 强制输出 `current Memory/Reflection claim atom +
   contradicted or omitted observation/result atom`；无法给双证据则 no-candidate。
6. **机械 recurrence 与 epoch。** Parent 用 tool、canonical args、query、target、
   result hash 与 constraint delta 生成 onset/maturity事实，避免过早 S4 或过晚 S14。
7. **owner/type 前置预提交。** 在 witness、candidate source、nomination 次数和
   arbitration prose 出现之前，先对 Step 建立 classification bank；最终 Step
   选出后只能机械读取预提交值。Raw phase 顺序必须由 parser/validator 强校验，
   witness 与仲裁不得输出 module/type/owner atom ID。
8. **缩窄 type admissibility。** allowed type 应由 evidence predicate 限制，而非
   每个 Module atom开放完整 taxonomy。
9. **保持严格 System 边界。** 只接受 typed termination/cap、明确外部失败或
   结构化 interface contradiction；普通 task text、普通失败和纯 step count 不触发。
10. **简化 schema。** Parent 机械生成候选全集与 comparison skeleton，模型只填
    必需判据，降低本轮 4 次无指标收益 retry 的成本。

按评分后诊断，保住当前 6 个命中、修复 5 个 P-only 仲裁，再由统一 predecessor
closure 恢复 cases 06、13，理论上可形成 13/30 的设计余量。这个数字只能用于评估
统一机制是否值得做，不能读取 case ID 选择规则、拼接历史预测或当作正式成绩。

下一轮正式验收建议为：

- full-30 candidate Step oracle 至少 16/30；
- arbitration 至少实现 oracle 的 75%，且 loss 不超过 4；
- predecessor-only gold candidate 不再出现 0/5 被选；
- Memory/Reflection candidate recall 非零且有双证据；
- 30/30 legal，所有 runtime/session/lineage/implementation/prediction/secret/
  gold-free audit 继续通过；
- 只有正式 Step Exact 达到至少 12/30 才晋升并结束目标。

## 权威产物

- 完整运行：
  `output/agenterrorbench-codex-gpt-5.6-luna-tuning-v1-agent-judge-luna-v16-unified-v1-case30/`
- 官方 metrics：`scored/metrics.json`
- 官方逐例结果：`scored/per_example.csv`
- 冻结 predictions：`predictions.json`
- 执行与 token：`execution-summary.json`
- lineage audit：`lineage-audit.json`
- pre-score audit：`pre-score-audit.json`
- prediction audit：`prediction-audit.json`
- v16 protocol：`agentdebug/diagnostics/agent_judge_luna_v16_unified.py`
- v16 runner：`scripts/run_agent_judge_luna_v16_unified_tuning.py`
- v14 对照报告：
  `docs/experiments/luna-v14-unified-full30-retrospective-2026-08-20.md`
- v15 对照报告：
  `docs/experiments/luna-v15-unified-full30-retrospective-2026-08-20.md`

# E9 v40 full30 failure case study

## Outcome

v40 passed dry3 at 2/3 for Step Exact, Step+Module Exact, and All Correct,
with no failed output. Its promoted full tuning run completed all 30 frozen
cases but did not reach the semantic gate:

- Step Exact: 9/30 (30.00%; gate requires 12/30);
- Step+Module Exact: 4/30 (13.33%; gate requires 3/30);
- All Correct: 4/25 (16.00%; gate requires 3/25);
- successful outputs: 29/30;
- failed outputs: 1/30, within the allowed maximum of one;
- environment Step Exact: ALFWorld 2/10, GAIA 5/10, WebShop 2/10;
- new logical completions: exactly 20;
- HTTP attempts: exactly 20, with zero retries;
- provider tokens: 3,660,212 input, 288,450 output, 3,948,662 total.

Only `step_exact_minimum_correct` failed. The rejected promotion is bound by
`8cd4a01f9560966dd8947220de0ba689ebca23f62fdfdb4ab1eadfe1cebf8223`.
Held-out smoke must not run from v40.

## Format attribution

The v40 length change removed the exact v39 dry blocker. All three dry
Selector cases were valid, including C02's exact raw
`1/action/misalignment` tuple.

One different full-run row exceeded the new bound:
`Llama3.3-70B-Turbo_003_003` returned a strict Selector object whose C03
`causal_basis` was 1307 characters against the 1280-character maximum. Its
raw semantic tuple was `4/action/format_error`; the released critical step is
4. The other two cases in the same response used 1262 and 1234 characters
and remained valid. This is another explanation-only boundary loss, not
malformed JSON, transport failure, or missing semantics. A future contract
should allow up to 1536 characters while asking for at most 1400. It must not
truncate, repair, or reinterpret the text.

## Semantic attribution

Among the 21 wrong or invalid rows, the final output is later than gold in 11
valid cases, earlier in 9 valid cases, and invalid in one case. There is no
single numeric early/late correction. The dominant environment weaknesses are
ALFWorld and WebShop, both 2/10.

The selected module is also unstable. Concrete action and late planning
symptoms frequently replace released memory/reflection/planning owners. For
example, one ALFWorld trace chooses step 5 `action/invalid_action` instead of
the released step 6 reflection error; a WebShop trace chooses step 3 memory
instead of the released step 7 action; and repeated list browsing is localized
at step 2 even when the released error is a later mature recommitment.

The Candidate/Selector behavior remains proposal-anchored:

- 24 of 29 valid rows emit `accept_proposed`;
- the Selector final step equals the Candidate proposal in nearly every one
  of those rows;
- a frozen incumbent contains the released step for six cases;
- frozen Scout candidates contain it for eight cases;
- v40 first/alternate/proposal candidates contain it for nine cases;
- the unscored union of incumbent, Scout, and v40 candidate steps contains the
  released step for 13/30 cases.

That union is a post-score diagnostic only. It must never become a vote,
score, fallback, or deterministic selector. It shows that the 12/30 target is
already inside the LLM candidate space, while the final judge is not comparing
the hypotheses effectively.

The asymmetry is structural. The Selector receives a full proposed tuple and
root-cause explanation, a full incumbent, but only integer steps for the
first-defect and alternate lanes. The Candidate's prose ledger contains more
details, yet requiring the Selector to reconstruct those details from free
text does not give the alternatives equal semantic representation. The model
therefore repeatedly confirms the richly specified proposal.

## v41 falsifiable direction

v41 will replace the privileged proposal with an official-inspired local
module census. In one Candidate completion per frozen batch, the LLM must
emit at most one fully structured, evidence-bound local hypothesis for each
of memory, reflection, planning, action, and system. A hypothesis states its
step, atomic taxonomy pair, source ID, local defect, observed consequence or
recovery, and one-error counterfactual. It is not a final diagnosis and has no
confidence, score, rank, weight, vote, or priority.

The final Selector receives the complete timeline plus a symmetric anonymous
hypothesis list: valid local-census hypotheses and the frozen incumbent. No
entry is called proposal, winner, earlier, or alternate. The Selector must
first reconstruct the failure and then compare every hypothesis for local
validity, recovery, and causal sufficiency. It may reject every supplied
hypothesis and emit a fresh root. Its raw response remains the sole final
semantic source.

The falsifiable hypothesis is that removing proposal privilege and exposing
module-specific local candidates will preserve at least 2/3 dry accuracy and
raise full tuning Step Exact from 9/30 to at least 12/30. The explanation cap
will be 1536 characters with a 1400-character prompt target. If dry3 fails,
or full30 remains below 12/30, v41 is rejected and requires another case study
before any further model call.

# Luna GAIA v3.34 Clean v3.20 Observable-Impact Challenger Preregistration

## Frozen identity and decision rule

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.34-clean-v3.20-observable-impact-bidirectional-challenger`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Single major change: replace the incumbent's challenger judgment with one
  evidence-stratified bidirectional adjudication rule that gives literal
  adjacent execution impact precedence over hypothetical capability claims.
- Accepted incumbent: Luna v3.20, Step Exact `25/50`.
- Version acceptance: Step Exact `>25/50`.
- Goal completion: Step Exact `>=30/50` plus every legality check.
- Original frozen baseline: Luna v3.4, Step Exact `21/50`.
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases.
- Dataset manifest SHA-256:
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort semantic SHA-256:
  `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Cohort file SHA-256:
  `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Prediction-manifest file SHA-256:
  `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Model / reasoning effort: `gpt-5.6-luna` / `medium`.
- No smoke gate; after offline validation run the complete GAIA-50 directly.

Step Exact is the only optimization, comparison, acceptance, rejection, and
completion metric. Module, type, and literal evidence remain output-legality
constraints only.

## Post-score evidence and first divergence

Frozen v3.33 completed all 50 cases legally and scored `22/50`, so it is
rejected. Relative to v3.20 it had three gains and six losses, net `-3`. Its
complete 28-error first-divergence distribution is:

- annotation ambiguity: 6;
- candidate recall failure: 6;
- false candidate admission: 5;
- late symptom preference: 4;
- early freeze failure: 3;
- challenger recall failure: 2;
- false challenger override: 2.

The independent census emitted 37 candidates. The fresh v3.20 anchor scored
`22/50`, the final scored `22/50`, and the anchor/census pair oracle was
`26/50`. The comparator made eight Step changes: two direct gains, two direct
regressions, and four wrong-to-wrong changes. On two errors the census froze
the released exact Step but speculative early capability anchors were retained.
On two other errors the anchor already matched the released Step and contained
literal adjacent tool or parameter rejection, yet it was overridden by a later
local/repetition candidate.

The earliest common divergence is therefore evidence-class comparison, not
final freezing. v3.33's census topology is not inherited: its audit is used
only to formulate the present one-challenger rule.

## Single uniform mechanism

The v3.20 packet-state anchor prompt, candidate ledger, Step freeze, model,
reasoning effort, artifact schema, one-proposal limit, exact-copy arbiter, and
default-keep behavior remain unchanged. Only challenger adjudication changes:

1. Classify anchor support before searching.
2. An unrecovered task-material anchor with literal adjacent tool rejection,
   parameter rejection/misparse, or direct same-packet plan/Action
   contradiction is `proven_execution_impact`. It cannot be displaced by a
   strictly later repetition, persistence, terminal answer, or path-dependent
   reaction.
3. An acquisition/capability anchor without literal adjacent proof of
   incapability is `unsupported_capability_anchor`. If its probe yielded a
   usable lead or its alleged dependency was later mechanically repaired, it
   is eligible for a later challenge as a reasonable probe or noncritical
   predecessor.
4. A strictly earlier proposal remains possible only for a literal necessary
   handoff defect whose repair changes the path and which anchor-only repair
   cannot remove.
5. If no earlier proposal exists and the anchor lacks proven execution impact,
   scan later Steps chronologically for the earliest independently
   failure-causing boundary under successful anchor-only repair.
6. A repeated strategy qualifies only after literal feedback rules out the
   same normalized target/corpus/interface/route. A false-progress state
   requires literal contradiction from adjacent feedback.
7. Emit at most one complete legal prediction; uncertainty keeps the anchor.
   The existing arbiter may only keep the exact anchor or accept the exact
   proposal.

This is a clean v3.20 branch. No v3.21-v3.33 prompt, ledger, census artifact,
candidate, prediction, or scored result is a runtime input. Existing generic
bidirectional artifact parsing and validation code is reused only as structural
transport; the rejected v3.16/v3.30 challenger rule is replaced in full and is
not part of the semantic protocol.

## Falsifiable gain and regression analysis

Expected gains arise from two uniform classes: capability anchors that lack
literal impossibility evidence and later have an independent critical boundary,
and correct anchors whose adjacent execution rejection should veto a later
override. In the frozen v3.33 post-score counterfactual these classes cover four
selector errors. Their IDs remain only in post-score audits and are absent from
the prompt, code, validator, manifests, and routing.

Regression risks:

- literal tool failure can be mistaken for Agent-owned execution impact;
- the capability gate can move predictions later and amplify repetition or
  terminal-symptom preference;
- an earlier handoff scan can preempt an already-correct anchor;
- fresh anchor sampling can lose incumbent-correct cases independently of the
  challenger mechanism.

Controls are task-material ownership, explicit adjacent rejection or
contradiction, recovery and normal-failure vetoes, separate anchor-only and
proposal-only repair counterfactuals, chronological first-eligible selection,
one proposal maximum, exact-copy validation, and default keep under uncertainty.
The hypothesis is falsified if structural validation fails or the complete
legal run scores `<=25/50`.

## Execution and freeze contract

1. Implement only the versioned challenger rule, identity/validator retagging,
   runner registration, and negative tests over the frozen v3.20 parent.
2. Verify the anchor task is text-identical to v3.20 modulo version identity,
   the old rejected bidirectional rule is absent, and the new evidence-class
   rule is present in challenger and arbiter tasks.
3. Use the existing three fresh serial sessions per case: unchanged v3.20
   anchor, one challenger, and default-keep arbiter; at most four cases run
   concurrently.
4. Run no smoke gate. Execute all 50 cases after prepare-only validation.
5. Freeze anchors, ledgers, checkpoints, challengers, arbiters, predictions,
   audits, and hashes after 50/50 completion. Validate schema, taxonomy,
   evidence, order, Step range, one-proposal limit, exact copies, no routing,
   and no prior-prediction or gold access before reading labels.
6. Score all 50 and compute Step transitions relative to frozen v3.20 and v3.4.
7. Reject immutably at `<=25/50`; accept as the new incumbent at `26-29/50`;
   complete the Goal only at `>=30/50` after every legality check passes.

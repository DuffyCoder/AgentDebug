# E9 v54 dry3 semantic failure case study

## Closed attempt

- Experiment: `e9_v54_contradiction_first_planning_deepseek_v4_flash_default_body`.
- Model: `deepseek-v4-flash`, default request body, temperature 0, one
  worker.
- Preregistration content hash:
  `f218d916e075a5fd0a8bc8b44c87d1c813113d9474ea12caf5e46e35776aa236`.
- Predict-run content hash:
  `131d2130fe4b9bb291e0743356653a20b60dc7ab5f4d39a0b8965c58e0f8efaa`.
- Promotion content hash:
  `71e9135d16144f8d19ff9d2911a3298da52d37cc4d69935761d2ddf9775c1974`.
- Result: 3/3 structurally valid raw Selector predictions, but Step Exact,
  Step+Module Exact, and All Correct were all 0/3. The promotion was rejected
  on all semantic minima; every structural, raw-final, gold-isolation,
  telemetry, and exact-budget check passed.
- Provider use: two logical completions, two HTTP attempts, zero retries;
  384,237 input, 40,796 output, and 425,033 total tokens.
- The completed audit ordinal is 644.

The full30 phase is not authorized.

## Regression from v53

| Case | Released | v53 | v54 |
|---|---|---|---|
| ALFWorld | 30 system/step_limit | exact | 6 planning/inefficient_plan |
| GAIA | 1 action/misalignment | exact | 4 planning/constraint_ignorance |
| WebShop | 13 planning/inefficient_plan | 2 planning/inefficient_plan | 6 planning/inefficient_plan |

V54 did not merely fail to fix the WebShop row. Its stronger local-
contradiction precedence overturned both diagnoses that v53 got exactly
right, reducing 2/3 to 0/3.

## Attribution

The Critic did not expose the WebShop released step. Its dedicated
`planning_state_contradiction` lane selected step 22; its first-defect and
global lanes selected step 4. Although step 13 contains the benchmark's
annotated state contradiction, the complete trace contains several similar
or arguably stronger contradictions. Prompting the model to choose the
"most explicit" one therefore did not uniquely identify the annotation.

The Selector then over-applied the new rule:

- for ALFWorld it treated an early acknowledgement of stalled progress as
  proof that continued search of distinct cabinets was inefficient, defeating
  the correct external step-limit boundary;
- for GAIA it preferred the terminal plan's explicit constraint conflict over
  the earlier incapable information-acquisition operation;
- for WebShop it selected the first recognized no-progress continuation at
  step 6 rather than the annotated later contradiction at step 13.

These are coherent LLM diagnoses. The failure is benchmark localization under
an over-specified rule set, not malformed output or weak evidence. Adding
categorical exceptions to recover the first two cases would directly conflict
with the rule added to recover the third and would further entangle the
prompt.

## Rejected explanations

- Transport, retry, truncation, or JSON repair: both stages returned `stop`
  in one HTTP attempt and parsed without semantic mutation.
- Gold leakage: raw predictions were closed before labels were loaded.
- Selector-only candidate choice for WebShop: the released step 13 was absent
  from the candidate bundle.
- A generic preference for later steps: contradicted by the correct step-1
  and terminal-boundary examples and unsupported as a causal principle.
- Another narrow exception layered onto the same Selector: rejected because
  v54 demonstrates interference between exceptions and global judgment.

## Next falsifiable hypothesis: simplify to one original-style judge

The next experiment should remove Candidate generation and anonymous
Selector comparison from the active prediction path. One raw LLM call per
batch receives each complete anonymous trajectory, the literal taxonomy, and
the original AgentDebug global instruction: identify the earliest and most
important error that led to failure, explain the causal chain, and emit one
step/module/type with owner-bound evidence.

It must not receive deterministic findings, released labels, historical
predictions, candidates, manual scores, confidence weights, or votes. The raw
one-stage response remains the sole source of final semantics; deterministic
code only validates schema, step/module ownership, and verbatim evidence.

This simplification is falsifiable on the same dry3:

- exactly one logical completion instead of two;
- 3/3 Step Exact, Step+Module Exact, and All Correct;
- zero invalid rows and zero semantic mutation;
- only then authorize full30.

The production-facing workflow should expose one command and one linear path:

`OpenClaw trace -> canonical trace -> one global LLM judge -> evidence validation -> report`.

Experiment-only code freezing, gold-isolated scoring, promotion gates, and
historical anchors remain behind that command and do not complicate normal
trajectory diagnosis.

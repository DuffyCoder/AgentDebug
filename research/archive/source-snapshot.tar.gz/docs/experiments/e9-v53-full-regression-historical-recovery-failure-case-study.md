# E9 v53 full-regression historical-recovery failure case study

## Failed attempt

The first complete v53 regression run finished with 529 passes and four
failures. No provider or external LLM call occurred.

## Attribution

All four failures are historical recovery-test assumptions:

- one v45 archival test still asserted that the active pipeline identity ends
  in v52, although the active candidate is now v53;
- three v52 recovery tests attempted to reconstruct v52 request hashes through
  the active Critic prompt. The v53 prompt correctly produces different
  content-addressed requests, so the historical v52 cache has no matching
  files and the workflow fails closed with `required v14 stage cache artifact
  is missing` before any provider call.

The completed v52 recovery was a one-time, hash-bound operation. Its durable
result is already frozen: 30 successful raw-final rows, an eight-entry recovery
ledger, immutable cache state, metrics, promotion rejection, and a mandatory
semantic case study. Requiring a new active prompt to reproduce old request
hashes is incompatible with content-addressed cache isolation and would weaken
rather than strengthen the experiment boundary.

## Correction and next check

Replace the three executable historical-recovery tests with archival checks
that verify the completed v52 artifact hashes, 30-row denominator, exact
Critic/Selector ledger order, zero semantic mutations, raw Selector final
fields, and the frozen 66-file cache state. Retain one explicit test that the
old recovery script fails closed under v53 before a provider can be invoked.
Update the v45 archival assertion to the active v53 identity.

Then rerun the complete suite. The expected result is 533 passes with no loss
of current workflow, Canonical Trace, OpenClaw, recovery-integrity, or
gold-isolation coverage. No LLM call is allowed until the suite passes.

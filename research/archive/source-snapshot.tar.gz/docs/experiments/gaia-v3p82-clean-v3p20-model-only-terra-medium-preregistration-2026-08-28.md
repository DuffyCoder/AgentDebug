# GAIA v3.82 clean-v3.20 model-only Terra/medium preregistration

Date: 2026-08-28

## Frozen identity

- Version: `agentdebug.codex-agent-judge.gaia-v3.82-clean-v3.20-model-only-terra-medium`.
- Direct semantic parent: accepted Luna v3.20, Step Exact `25/50`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Cohort SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Prediction manifest SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Frozen v3.20 protocol source SHA-256: `3e886325bf0a4b4d4a3e770071c0a36fe81dab2bebaf5015561ca828b6c2e4f9`.
- Frozen v3.20 runner source SHA-256: `e9af16c69494caaa06e4bcba44e242abc96f6ba41106bab44e02e7e1ec9257d6`.
- Frozen v3.20 predictions SHA-256: `9df734d95a7c338a9b8ce66fb4d91e16d69961d272ddcc926f7d11f3ddc8add8`.
- Model: `gpt-5.6-terra`.
- Reasoning effort: `medium`.

## Single major change

Change only the executing model from `gpt-5.6-luna` to `gpt-5.6-terra`.
The complete v3.20 packet-state anchor, earliest-causal challenger,
default-keep arbiter, prompts, artifact contracts, validators, three-session
topology, case order, concurrency, and retry bounds remain unchanged.

The rejected v3.81 Sol lineage is not a semantic parent and contributes no
prompt, validator, artifact, or prediction. Task text differs from v3.20 only
in truthful experiment-version and model metadata. No incumbent/prior
prediction, label, metric, scored artifact, error report, or gold rationale is
visible during inference.

## Falsifiable hypothesis

Terra's reasoning profile will improve benchmark-relative critical-boundary
selection under the accepted v3.20 protocol while preserving 50/50 evidence
legality. Reject the hypothesis if the completed frozen run has Step Exact
`<=25/50` or fails any completeness, schema, taxonomy, evidence, ordering,
hash, or gold-isolation check.

## Acceptance and Goal completion

- Accept only if Step Exact is strictly greater than `25/50` and all legality
  checks pass.
- Complete the Goal only if Step Exact is at least `30/50` and all legality
  checks pass.
- Step+Module, All Correct, module/type distributions, token use, and latency
  are diagnostic only and do not affect acceptance.
- No smoke gate is used; after offline validation this version runs the full
  GAIA-50 directly.

# E9 v47 dry3 invocation failure case study

## Outcome

The first v47 dry3 `predict` invocation failed closed before constructing a
provider. It produced no prediction rows and consumed no logical or HTTP
completion:

- durable ledger entries: 0;
- v47 Critic/Selector cache files: 0;
- unscored prediction file: absent;
- predict-run file: absent.

The preregistration, source archive, predecessor, source cache, provider
identity, phase budget, and authorization claim all remain valid.

## Attribution

The command omitted the three repeated `--trajectory-id` arguments. The CLI
therefore resolved the prediction-manifest default selection as all 30 tuning
trajectories, while the frozen dry batch plan and preregistration authorize
only these three ordered IDs:

1. `Qwen3-8B_024_id_24___chat_b013_t00_e01-5b8f974f`;
2. `Llama3.3-70B-Turbo_015_memory_b001_t00_e06-71f77595`;
3. `GPT-4o_008_chat_b000_t00_e07-d50ae81f`.

The preregistration verifier rejected the selection mismatch before reading
credentials or creating the judge. A direct read-only invocation of the same
verifier with the exact three IDs succeeded, and regenerating the source
archive produced the same archive SHA-256
`6679258357e2bc20686f6223869bfaa13481e4acd02ed4af2095dfe0ae8c4ff6`
and code-bundle SHA-256
`b33fe75910d6b1dfe648873100a3e1ca8e0c55c8d8abee479fb073f96bb7ba76`.

This is an operator invocation error, not evidence for changing the five-lane
semantic hypothesis, prompt, parser, provider configuration, or phase budget.

## Next attempt

Reuse the exact preregistration
`31c76ce9bd904638fa072b224539d7d789daac445ed9cbd1d4a55d7eb1f17ba6`
and empty v47 cache. Repeat `predict` once with all three ordered
`--trajectory-id` arguments. The corrected run remains bounded to two new
logical completions and cumulative hard stop 566. Any new failure again
requires a completed case study before another LLM request.

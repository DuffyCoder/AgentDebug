# E9 v41 dry3 failure case study

## Outcome

v41 completed the frozen three-case dry run with valid raw Candidate and
Selector responses, but failed every preregistered semantic promotion gate:

- Step Exact: 1/3 (33.33%; gate requires 2/3);
- Step+Module Exact: 1/3 (33.33%; gate requires 2/3);
- All Correct: 1/3 (33.33%; gate requires 2/3);
- successful outputs: 3/3;
- failed outputs: 0/3;
- new logical completions: exactly 2;
- HTTP attempts: exactly 2, with zero retries;
- provider tokens: 381,012 input, 24,484 output, 405,496 total.

The run is rejected by promotion artifact
`ac5b076812402d3a950aa09c58eb81658cdda401e71171887dffdf8661cba1f1`.
It must not advance to full30 or held-out smoke.

## Case study

### C01: candidate and selection both succeed

The released root is step 30 `system/step_limit`. The anonymous hypotheses
contain the frozen step-30 system root and a local step-30
`planning/inefficient_plan` alternative. The raw Selector adopts the system
hypothesis. It correctly observes that each cabinet action covers a distinct
unvisited state and that the final action has no result because execution
ends at the enforced boundary.

This case shows that symmetric representation does not inherently destroy a
valid terminal-boundary diagnosis.

### C02: the correct hypothesis is recalled and then rejected

The released root is step 1 `action/misalignment`. The anonymous hypothesis
set contains that exact frozen tuple, plus step-4 reflection and planning
hypotheses from the local census. The raw Selector explicitly reviews all
three but chooses step 4 `planning/constraint_ignorance`.

The selection is understandable from the current contract: the step-1 URL
extraction literally follows its plan, whereas the step-4 plan visibly uses
an open issue without the required Regression label. However, the released
annotation treats the first operation as the critical mismatch because the
chosen representation cannot expose the collection ordering and label-event
history required by the task. v41's rule that action/misalignment requires a
literal plan/action contradiction makes the correct benchmark hypothesis
almost impossible for the final judge to retain.

This is a Selector-policy failure, not candidate recall failure.

### C03: the local census omits the released step

The released root is step 13 `planning/inefficient_plan`. The local census
emits only the single *strongest* planning hypothesis and chooses step 22.
The frozen predecessor contributes step 1 `action/misalignment`; neither is
the released step. The Selector rejects both and creates a fresh step-8
`planning/inefficient_plan` diagnosis.

The trajectory distinguishes these points. Step 8 starts a refined query
after the initial search epoch. Step 13 has already traversed the refined
query through page 5 and nevertheless plans another page turn. Step 22 is a
still later repetition after another query epoch. Asking for the strongest
local error discards the chronological Phase-1 signal needed by the released
step; asking the final judge to reconstruct a fresh root then favors the
earliest defensible repetition at step 8.

This is first a candidate-recall failure and then a Selector-localization
failure.

## Attribution

The failure is semantic, not transport, JSON, taxonomy, source ownership, or
length validation. The correct released tuple is present in the supplied
hypothesis set for 2/3 cases, while the final Selector selects only 1/3.

Two design choices cause the loss:

1. **Strongest-per-module census.** The original AgentDebug Phase 1 evaluates
   module outputs step by step. v41 collapses that chronology to one
   "strongest" hypothesis per module before Phase 2. C03 demonstrates that
   this can retain a late manifestation and erase the released critical
   decision.
2. **Over-constrained final adjudication.** v41 requires a long trace-first
   ledger and imposes a narrower action/misalignment test than the released
   annotation exhibits. The model therefore optimizes for its own locally
   clean causal explanation instead of applying the original Phase-2 rule to
   the Phase-1 candidates.

Anonymous hashing and equal field structure solved the v40 representation
asymmetry, but equal representation alone did not solve candidate chronology
or final selection.

## v42 falsifiable direction

v42 will preserve the raw two-stage LLM architecture, strict source-ID
binding, gold isolation, immutable ledgers, and raw Selector authority. It
will make one controlled semantic revision inspired directly by the original
AgentDebug two-phase process:

- the local census will emit the **chronologically earliest locally
  demonstrable error for each module**, not the strongest error anywhere in
  the trajectory; this preserves Phase-1 chronology without code-side
  selection;
- action evaluation will consider whether the concrete operation can
  implement the current plan and explicit task constraints, not only whether
  its verb superficially repeats the plan;
- the Selector will use the original concise global Phase-2 test: inspect the
  complete trajectory and untrusted Phase-1 hypotheses, then choose the
  earliest important error whose one-error correction would fundamentally
  redirect the failed trajectory. The mandatory causal-ledger serialization
  and per-hypothesis rebuttal taxonomy will be removed.

The Candidate and Selector remain LLM judges. No hypothesis is assigned a
confidence, score, rank, vote, probability, weight, or privileged provenance.
Code does not choose, repair, or fall back to a semantic tuple.

The hypothesis is accepted only if v42 reaches at least 2/3 on all dry gates
and then at least 12/30 Step Exact on full tuning. Otherwise v42 is rejected
and another completed case study is required before any further external
model call.

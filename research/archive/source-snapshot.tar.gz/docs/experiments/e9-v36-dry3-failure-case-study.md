# E9 v36 dry3 failure case study

## Result

The v36 concise original-AgentDebug causal contract failed its frozen dry3
promotion gate:

- Step Exact: 1/3 (required 2/3)
- Step+Module Exact: 1/3 (required 2/3)
- All Correct: 1/3 (required 2/3)
- valid predictions: 3/3
- logical completions: 2
- HTTP attempts: 2
- retries: 0
- provider tokens: 380,747 input, 26,495 output, 407,242 total
- deterministic semantic mutations: 0

The run is rejected and must not advance to full30 or smoke.

## Case analysis

### ALFWorld

Gold and prediction both select step 30, `system/step_limit`. The model
correctly distinguishes a coherent search over previously unvisited cabinets
from a locally demonstrable agent defect.

### GAIA

Gold selects step 1, `action/misalignment`; v36 selects step 4,
`planning/constraint_ignorance`, three steps late. The frozen v13 incumbent
contains the correct step-1 action hypothesis: the selected page-text
representation cannot expose the required filtered issue collection and
label-event history. The v36 Candidate rejects it because literal plan/action
agreement is treated as evidence that the action is sound. Candidate then
emits only its replacement proposal. The independent Selector receives the
replacement but not the incumbent's complete tuple, so it cannot directly
reconsider the correct hypothesis.

### WebShop

Gold selects step 13, `planning/inefficient_plan`; v36 selects step 4 with the
same taxonomy pair, nine steps early. Pagination at step 4 is still ordinary
coverage. The v36 wording asks for the earliest important error but does not
state when repeated search becomes a demonstrable ineffective policy. Both
LLM stages therefore call the first continuation a root before explicit
no-progress and repeated-policy evidence matures.

## Attribution

This is a semantic failure, not a transport or parser failure. It has two
separable causes:

1. **Hypothesis information loss.** The Candidate sees the frozen incumbent,
   but the Selector sees only the Candidate's chosen proposal plus bare
   alternate step numbers. Rejection by one LLM stage irreversibly hides a
   potentially correct complete hypothesis from the final LLM judge.
2. **Uncalibrated exploration maturity.** The concise causal contract
   correctly protects steps 1--3, but it does not provide an evidence-based
   boundary for later search and navigation. This creates early-root bias at
   the first page continuation.

## Falsifiable v37 hypothesis

Keep the concise module-local and backward-causal AgentDebug contract, but:

- expose the complete frozen incumbent hypothesis to the independent Selector
  as untrusted LLM output alongside the Candidate proposal;
- clarify that literal plan/action agreement does not make an operation sound
  when concrete interface or result evidence proves that its selected
  representation cannot expose an explicitly required fact;
- clarify that repeated search becomes `planning/inefficient_plan` only at the
  first recommitment after contemporaneous no-progress, exhausted coverage, or
  substantially repeated-policy evidence, not at an early novel page turn.

The Selector remains the sole source of final semantic fields and may reject
both hypotheses. No confidence, score, weight, deterministic finding, semantic
fallback, or code-side root selection is introduced. The dry3 promotion
criterion remains 2/3 on all three gated metrics.

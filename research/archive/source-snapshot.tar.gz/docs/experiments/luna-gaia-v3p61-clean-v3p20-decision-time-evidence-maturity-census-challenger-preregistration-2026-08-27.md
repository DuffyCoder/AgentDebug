# Luna GAIA v3.61 Clean-v3.20 Decision-Time Evidence-Maturity Census Challenger Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.61-clean-v3.20-decision-time-evidence-maturity-census-challenger`
- Direct semantic parent: `agentdebug.codex-agent-judge.luna-gaia.v3.20-packet-state-closure`
- Accepted incumbent: Luna v3.20, Step Exact `25/50`
- Original baseline: Luna v3.4, Step Exact `21/50`
- Version acceptance: legal frozen full-GAIA Step Exact `>25/50`
- Goal completion: legal frozen full-GAIA Step Exact `>=30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction-manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Model / reasoning effort: `gpt-5.6-luna` / `medium`
- Smoke gate: none; after offline validation, run the full GAIA-50 directly

Step Exact is the only optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module, type, and evidence remain schema, taxonomy, and
literal-evidence legality constraints only.

Frozen post-score inputs used to form this hypothesis:

- v3.60 Step-error audit SHA-256: `ce702a71bdf95828678fe757420a7a213d743fc9dcb64ebde2abdd31923c2a9d`
- v3.60 cluster audit SHA-256: `bc9ad42424a046a7022851300455b7cab39b5a312e6165c75da95b108d3346fe`
- v3.60 mechanism-impact SHA-256: `c8f2280a5278b1397cb28583029e1dce0324ad522cbb6fa896dee21796c47faa`
- v3.60 inference-access audit SHA-256: `4621947176d362d3ad71ae30e1d1353c34ab8dae12021af9fdd179fc96c92d38`

These are preregistration evidence only. They are forbidden inference inputs.

## First-divergence basis

Rejected v3.60 legally completed `50/50` at Step Exact `21/50`. Its 29 errors
split into 17 `candidate_recall_failure`, seven
`arbiter_selection_failure`, four `annotation_ambiguity`, and one
`false_candidate_admission`. Sixteen of the 17 recall diagnoses are High
confidence: the released Step is later than the stopping anchor and cannot
enter a prefix-only retrospective set. The seven selection errors already have
the released Step in a prefix row, but an absolute five-gate test rejects it as
an informative different probe, reasonable probe, or normal failure. v3.60
selected only two prefix rows, producing one direct gain and no direct loss
against its fresh anchor, while fresh anchor plus its available sparse rows had
oracle `32/50`.

The public paper method supplies the complementary negative control. Complete
Step×Module local recall creates enough coverage but floods the global stage;
the local public-topology reproduction emitted 457 positive Steps and selected
only `14/50`. Luna v3.54--v3.59 similarly showed local-matrix oracle above the
Goal but severe compression and selection loss. Therefore v3.61 does not add a
local-positive inventory or candidate pool.

The earliest shared defect is the stopping topology plus an overstrong notion
of causal independence. A later benchmark boundary may be the first decision
that is no longer justified by evidence visible at that time, even though it
is causally downstream of earlier reasonable probes. Requiring the later row
to remain independently failure-causing after hypothetical anchor repair can
erase precisely that chronological boundary.

## Single major mechanism

Keep the fresh v3.20 packet-state anchor, its write-once ledger and checkpoint,
the one-proposal exact-copy artifact contract, and the default-keep arbiter
unchanged. Replace only the existing later challenger judgment with one
complete decision-time evidence-maturity census:

1. Inspect every Canonical Step exactly once, before classifying the anchor.
2. Give every Step exactly one verdict:
   `clear`, `justified_probe`, `ordinary_observation`,
   `recovered_or_mechanical`, `faithful_propagation`,
   `locally_improvable`, or `decision_boundary`.
3. Freeze at most one `decision_boundary`: the chronologically earliest
   task-material Agent decision that was no longer justified by information
   visible by that Step and whose local repair can change the subsequent failed
   path.
4. A first or materially different acquisition action is `justified_probe`
   when it can expose any necessary intermediate, identifier, page, source,
   text, or lead. It need not prove the final predicate itself.
5. A capability mismatch is immediately mature only when the task, interface,
   or action contract already proves that the selected route cannot expose even
   a necessary intermediate for the immediate subgoal. Do not require prior
   failure for such literal hard mismatches.
6. After literal feedback shows zero contribution, rejected parameters, a
   violated constraint, false state/progress, or an unavailable assumption, a
   plan/Action that recommits without a new evidence dimension may be the first
   `decision_boundary`.
7. Normal tool/site failure, useful negative evidence, a genuinely different
   probe, a fully recovered defect, mechanical repair, faithful propagation,
   and downstream symptoms cannot own the boundary.
8. Candidate generation is chronological and time-local. It explicitly does
   not require the candidate to remain independently failure-causing after a
   hypothetical repair of an earlier reasonable probe.
9. If the one boundary equals the anchor, emit no challenge. If it differs,
   challenge only when the anchor's census verdict is a justified probe,
   recovered/mechanical predecessor, faithful propagation, or local-only
   defect, and the candidate is the first mature decision boundary. Otherwise
   keep the anchor.

The census is a single bounded artifact, not a collection of votes: exactly
one verdict per Step, at most one boundary, at most one formal proposal, and no
third prediction. Module/type never order candidates.

## Rejected-lineage boundary

v3.61 is implemented directly over v3.20 semantics. It does not inherit a
v3.21--v3.60 prompt, prediction, challenger result, ledger mutation, selector,
local matrix, scored output, or per-case artifact. Generic bidirectional
challenger parsing and validation may be reused only as structural transport.

The rejected v3.32 complete-census result is an explicit counterexample rather
than a semantic parent. v3.32 scored `21/50`; it asked for the globally best
critical candidate and required a later candidate to remain independently
failure-causing after anchor-only repair. v3.61 replaces both clauses with the
chronologically earliest decision-time justification boundary. No v3.32
verdict vocabulary or candidate output is inherited.

## Gains and regressions

Expected gains concentrate in the 17 v3.60 errors whose released Step is later
than the stopping anchor, especially early acquisition/capability false
admissions followed by a mature post-feedback recommitment. The seven prefix
selection errors are secondary evidence that absolute root-cause gates are too
strong, but v3.61 does not add an earlier-prefix override mechanism.

Primary regression risks are:

- ordinary failure followed by a still-reasonable different route is called a
  mature repetition;
- a locally inefficient later plan displaces an incumbent-correct hard
  capability, constraint, parameter, state-truth, or terminal boundary;
- a later explicit symptom is preferred over the first unjustified decision;
- complete enumeration recreates a disguised candidate flood or late-salience
  bias;
- fresh v3.20 anchor sampling differs from the frozen incumbent independently
  of the challenger.

Controls are exact complete chronology, a seven-value closed verdict set, one
boundary maximum, immediate-subgoal rather than final-predicate capability
testing, explicit different-probe and normal-failure protection, earliest
decision-time ordering, exact-copy-only challenge, and default keep on
uncertainty. The mechanism is uniform: no trajectory ID, entity, site, source
model, absolute Step rule, released rationale, or historical prediction enters
inference.

Diagnostic falsifiers are candidate oracle below `30/50`, candidate selection
that systematically drifts later, direct gains not exceeding direct losses,
or any census/order/copy/access failure. These diagnostics do not accept the
version. Only frozen legal Step Exact `>25/50` accepts it; only `>=30/50`
completes the Goal.

## Planned execution

1. Implement the v3.61 protocol, validator, runner, registry entry, and positive
   and negative contract tests from a clean v3.20 branch.
2. Prove anchor-task semantic identity to v3.20 modulo version identity; prove
   the rejected v3.32 rule text and all v3.60 artifacts are absent.
3. Prepare all 50 cases, source-scan inference inputs, and run offline tests.
4. Run exactly three successful fresh stages per case: unchanged v3.20 anchor,
   decision-time census challenger, and unchanged default-keep arbiter, with at
   most four cases concurrent and at most two attempts per stage.
5. Freeze all predictions and intermediate artifacts after `50/50`, complete
   gold-free validation, and independently audit inference access and hashes.
6. Only then score all 50, compute Step transitions against frozen v3.20 and
   v3.4, and perform the mandatory first-divergence audit for every error.

## Pre-inference validation and frozen source hashes

- Prepare-only completed for all 50 cases and exactly 150 planned successful
  fresh stages; every staged JudgeView is nonempty.
- Focused v3.61 plus v3.20/v3.32 regression tests: `18 passed`.
- Tests cover clean-parent anchor identity, registered model/effort, exact
  complete-Step ordering, zero-or-one boundary binding, direction binding,
  unknown verdict rejection, aggregate exact-copy validation, and explicit
  removal of the anchor-repair-independence clause.
- Static inference-source scan found no label, metric, scored-artifact,
  historical-prediction, post-score-audit, case-ID/entity/source router, or git
  history reader. The v3.32 semantic prompt and every v3.60 runtime artifact
  are absent; the v3.16 import is generic bidirectional artifact transport only.
- Model / effort are frozen as `gpt-5.6-luna` / `medium`; no smoke gate is
  present.

Frozen pre-inference hashes:

- Protocol SHA-256: `f3d22016066c43da060cb630105e44f75bc0aad15f71ae1cacf0ea415a2314ee`
- Runner SHA-256: `01fee2dc9bd69f5905ea4cb11aadfdfb1d24d2ad44d83545884235d9ec2330d6`
- Registry SHA-256: `42d456f358136c1964c12527a448e3da6d7dd8c66ee0b3703ada0456e6870cd2`
- Taxonomy SHA-256: `d7e4b878059bbecec0a8fd3f078c0aeb5755bf9e65bb938c897dd83685f28c5c`
- Focused-test SHA-256: `d6cb44dda8dab33df434bb10f9774bee026156927a1adb8f5406674fb4275bf3`

## Frozen full-run outcome

The preregistered full GAIA-50 run completed all 150 planned stages across all
50 cases with zero runner retries and zero permanent failures. The canonical
aggregate has 50 unique predictions in cohort order. The runner's gold-free
schema, taxonomy, evidence, range, order, copy, and forbidden-read validators
all passed, and all preregistered source hashes still match.

The frozen Step result is `20/50`. Relative to the frozen v3.20 incumbent this
is 18 both-correct, 2 incumbent-wrong/new-correct, 7
incumbent-correct/new-wrong, and 23 both-wrong: net `-5`. A fresh v3.20 anchor
sample scored `21/50`; the new mechanism itself produced zero direct gains,
one direct loss, and one wrong-to-wrong move. It found a census boundary in
49 cases but emitted only two challenges. Among the 30 wrong final
predictions, the released Step was classified `decision_boundary` only once;
the other verdicts were `justified_probe` 9, `ordinary_observation` 8,
`faithful_propagation` 5, `locally_improvable` 3, `clear` 3, and unmapped 1.
This falsifies the hypothesis that complete decision-time enumeration plus the
current maturity definition supplies usable benchmark-boundary recall.

The independent post-run access/write audit inspected 150 stdout logs and
1,371 command executions. It found zero released-label, scored-artifact,
historical-prediction, metric, post-score-audit, git-history, or raw-trajectory
content reads, and every source hash matches. It nevertheless failed the
artifact contract: inference created 59 top-level case directories instead of
50, including nine unexpected top-level directories, 40 unexpected directory
nodes in total, and nine unexpected files; at least eight command logs directly
reference the wrong paths. The canonical aggregate remains intact, but frozen
artifacts are not modified or cleaned. This is an independent
`runtime_or_validation_failure` and would make the version ineligible even if
its Step score had passed.

The mandatory post-score audit covers all 30 Step errors. First divergence is
`anchor_error` 24, `annotation_ambiguity` 5, and
`false_challenger_override` 1. The main clusters are 15 early-anchor freezes
where a later released boundary was not promoted, eight late-anchor freezes
where an earlier released boundary was classified probe/observation/clear,
one explicitly recognized later gold boundary suppressed by an uncertainty
gate, one false later override, and five low-confidence annotation cases.

Decision: **reject v3.61**. The accepted incumbent remains frozen Luna v3.20 at
`25/50`; v3.61 cannot be a semantic parent. Frozen post-run artifacts are:

- `analysis/inference-access-write-audit.json`
- `analysis/step-error-facts.json`
- `analysis/first-divergence-diagnoses.json`
- `analysis/step-error-audit.json`
- `analysis/step-error-clusters.json`
- `analysis/post-score-fact-summary.json`
- `analysis/mechanism-impact.json`

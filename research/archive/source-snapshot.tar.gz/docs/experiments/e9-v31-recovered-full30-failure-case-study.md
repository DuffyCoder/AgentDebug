# E9-v31 recovered full30 failure case study

## Result and promotion decision

The recovered v31 run completed all 30 tuning cases with exactly one new
logical LLM completion (cumulative 645 -> 646). It scored:

- Step Exact: 10/30
- Step + Module: 4/30
- All Correct: 4/25
- Successful predictions: 29/30

The frozen v30 incumbent remains:

- Step Exact: 10/30
- Step + Module: 5/30
- All Correct: 4/25
- Successful predictions: 29/30

The candidate is rejected. Step Exact ties, but the first tie-breaker, Step +
Module, regresses by one. The 12/30 development gate is not reached, so heldout
smoke remains closed.

## What v31 changed

v31 added explicit pairwise candidate comparison to the v30-derived final
Critic. Across the complete cohort it changed the selected semantics on 22/30
cases. This was not a small refinement: it frequently replaced the incumbent
candidate with an earlier, more generic action/planning defect.

It gained three Step Exact cases that v30 missed:

- ALFWorld `Llama...019_054`: step 7 -> gold step 5
- GAIA `Llama...012...`: step 5 -> gold step 4
- WebShop `Llama...008...`: step 4 -> gold step 2

It lost three v30 Step Exact cases:

- WebShop `Llama...011...`: gold step 4 -> step 2
- WebShop `Qwen...015...`: gold step 7 -> step 3
- WebShop `GPT-4o_004...`: gold step 2 -> invalid output

The gains and losses therefore cancel at Step Exact. Module selection is worse
on the tie, leaving v31 strictly below v30 under the frozen promotion rule.

## Final-batch analysis

The recovered batch contained three cases:

1. `Llama...010_webshop`: v31 selected step 2 planning/inefficient-plan; gold is
   step 4 memory/over-simplification. The explanation is locally plausible but
   treats repetitive paging as the root cause rather than the earlier/later
   information-state failure represented by the benchmark label.
2. `GPT-4o_004_webshop`: the model's case-level output failed the recovery
   checkpoint validator, turning a v30 correct step into an invalid output.
3. `Llama...005_webshop`: step 1 was preserved, but planning/constraint-
   ignorance disagrees with gold system/environment-error.

The final batch therefore contributed no new correct step and removed one v30
correct step.

## Root cause

The pairwise field expansion improves candidate recall but destabilizes final
selection. It has two coupled failure modes:

- **generic-first bias:** the Critic often prefers an early visible action or
  inefficient-search defect even when the benchmark root lies later or in a
  different cognitive module;
- **selection surface expansion:** requiring more comparison/checkpoint fields
  increases output fragility and produced one invalid case.

This supports the earlier v30 case study: candidate coverage is useful, but a
global pairwise replacement rule is too broad. The missing improvement is a
selective arbitration policy that preserves v30 when challenger evidence is
not materially stronger.

## Next optimization direction

The next candidate must branch from frozen v30, not v31. Reuse v31 only as
offline evidence for which cases benefit from alternate candidates. A justified
experiment should preserve v30 by default and expose a challenger only behind
a narrow, preregistered semantic condition (for example, a first-defect versus
later-root conflict with explicit causal evidence). It must not add required
output fields merely for instrumentation.

Testing remains simplified: targeted local tests while editing, one freeze
suite, one dry screen, then one full30 only for a passing challenger. The
30-case evaluation and LLM-as-Judge semantics remain unchanged.

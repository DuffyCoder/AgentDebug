# E9-v24 Flash Final-Content Contract

E9-v24 is a transport-conformance retry of v23.  It preserves the default
DeepSeek request body, Flash model, source-ID evidence, narrow brace repair,
novelty-calibrated recovery semantics, and review/final consistency checks.

The sole prompt delta tells the model to place its strict JSON object in the
final OpenAI-compatible `message.content` after any internal reasoning.  The
adapter never treats `reasoning_content` as a final answer and never persists
it.  If final content is empty or whitespace, parsing fails closed as
`empty_response` and is not automatically retried.

Budgets are dry3 372 to 373, full30 373 to 383, and future fresh smoke 383 to
the implementation ceiling 416.  Only dry3 fits the current authorization.

# E9 v35: symmetric final-brace repair

## Scope

v35 preserves v34's Candidate and independent Selector prompts and all
semantic behavior. The raw Selector remains the sole source of the final
diagnosis. There are no deterministic semantic findings, scores, confidence
values, votes, weights, label fallbacks, or semantic mutations.

## Mechanical format change

v34 observed a complete two-case Selector object ending in `}]`, with only
the enclosing top-level `}` absent. v35 extends the existing exact one-extra-
brace repair with its symmetric one-missing-brace case:

1. strict parsing of the original response must fail;
2. the trimmed response must end in `}]`;
3. appending exactly one `}` must produce one strict JSON object;
4. normal case count, field, taxonomy, source-ID, ownership, and evidence
   validation must still pass.

No other character is inserted, removed, or changed. Other truncation,
Markdown, multiple missing closes, and schema-invalid content stay invalid.

## Frozen topology

- dry3: cumulative 459 to 461, exactly Candidate + Selector.
- full30: cumulative 461 to 481, exactly 20 new calls after dry reuse.
- smoke30: cumulative 481 to 525, exactly 44 fresh four-stage calls.

The cumulative start includes v34 full30's 13 reservations: 12 completed
responses through batch 7 and one interrupted in-flight batch-8 Candidate.

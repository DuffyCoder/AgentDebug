# E7: fresh global causal critic over a fallible prior

Status before external calls: preregistration candidate.

## Frozen evidence from E6

- Dataset manifest SHA-256:
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Tuning-v1 content SHA-256:
  `e21b1034470577688b68aad2a0e006facc658fed28bdb986fed039bc0347bd6f`
- E6 prediction-manifest file SHA-256:
  `0c719f41255eb20f53ad233f18dd3fadf64c5b8f9f2df8980951279e1967f7b4`
- E6 unscored file SHA-256:
  `46696bf75f9f3f4bf5e25ab49b83c8350cfcf99f63e0937b4134510becc00fc0`
- E6 predict-run file SHA-256:
  `878230b52751129d768f8a1aac02ff11f8ef68f48aa6c11c51b0d1d877f5377a`
- E6 tuning result: Step `5/30`, Step+Module `3/30`, All `3/25`,
  failed `4/30`.
- Among 26 valid E6 roots, 16 selected Action; 13 of those 16 were
  Action-module false positives. Reflection was never selected and System was
  never selected.
- The loose E6 ledger had only `10/30` gold-step recall. The selector copied a
  ledger tuple in 23 of 26 valid outputs. Therefore both candidate coverage and
  anchoring were limiting, and a selector restricted to that ledger cannot
  reach the `12/30` target.

No smoke-v1 per-case artifact was inspected or used for this hypothesis.

## Falsifiable hypothesis

E6 is harmed by its Action-heavy ledger and by selector anchoring. A fresh
global LLM critic that receives the complete compact JudgeView and, at most,
the prior selector root as an explicitly fallible claim—but receives no
ledger, audit, candidate count, score, confidence, weight, vote, or benchmark
label—will improve causal step localization and module ownership.

The global critic is the sole semantic classifier. It must construct and
falsify a materially different challenger, may reject the prior root, and must
still diagnose from the timeline when the prior root is null. Deterministic
code only parses the five output fields, maps the selected step to an event,
checks taxonomy/evidence, and performs at most one evidence-only repair with
step/module/type/root-cause frozen.

This hypothesis is rejected if the dry gate below fails. There is no semantic
retry, prior-root fallback, deterministic root, or post-hoc answer repair.

## Frozen dry5 selection

The subset is selected only from the already-frozen tuning-v1 cohort. It does
not alter either official cohort. The rule stratifies the E6 error analysis by
the five gold modules, selects the largest absolute E6 step error within the
Reflection, Planning, and System strata, selects an E6 structural failure in
the Memory stratum, and retains one Step+Module-correct Action control. Ties
are resolved by trajectory ID. Provider execution follows prediction-manifest
order:

1. `Qwen3-8B_024_id_24___chat_b013_t00_e01-5b8f974f`
2. `Llama3.3-70B-Turbo_015_memory_b001_t00_e06-71f77595`
3. `GPT-4o_011_memory_b001_t00_e03-21a3a421`
4. `GPT-4o_008_chat_b000_t00_e07-d50ae81f`
5. `GPT-4o_004_chat_b000_t00_e03-21a3a421`

The targeted dry subset is only a go/no-go signal. Any promotion claim must be
based on all 30 frozen tuning cases, including the dry5 cases.

## Frozen dry gate

All conditions must hold:

- denominator `5`;
- five successful, strict-evidence-valid outputs and zero hard failures;
- Step Exact at least `3/5`;
- Step+Module Exact at least `3/5`;
- All Correct at least `2/5`;
- the Action control remains Step+Module exact;
- at least one of the Reflection/System cases is Step exact;
- at least one of the Planning/Memory cases is Step exact;
- every final tuple is rebuilt from global-critic raw output;
- any evidence repair changes no semantic field;
- provider payload/artifacts contain no gold, score, confidence, or weight;
- logical completions equal five critics plus the mechanically eligible
  evidence repairs.

## Frozen provider and budget

- Provider: `openai-compatible`
- Endpoint: `https://api.sophnet.com/v1/chat/completions`
- Model: `gpt-4.1`
- Temperature: `0`
- Timeout: `600`
- Max output tokens: `8192`
- Max transport retries: `5`
- Retry backoff: `2`
- Workers: `1`
- Credential variable name: `API_KEY`
- Cumulative logical completions before E7: `307`
- Dry maximum new logical completions: `10`
- Dry hard cumulative stop: `317`
- User-authorized cumulative ceiling: `380`

If dry5 passes, full tuning reuses its content-addressed cache. Across dry and
full tuning, E7 can issue at most 30 critic calls plus 30 evidence-only repair
calls, so the worst cumulative total is `367`, below the authorized ceiling.


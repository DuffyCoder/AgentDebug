# Luna GAIA v3.25 Predecessor-Feedback-Aligned State Ledger Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia-v3.25-predecessor-feedback-aligned-state-ledger`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.24-isolated-state-evidence-ledger`
- Frozen incumbent: v3.20, Step Exact `25/50`
- Original v3.4 baseline: Step Exact `21/50`
- Version acceptance: `Step Exact > 25/50`
- Goal completion: `Step Exact >= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Frozen v3.24 predictions SHA-256: `a9bb95aa539726a4d87d571703824b8e042c2af89e2d3efb1d198e5d337baad5`
- v3.24 Step-error audit SHA-256: `9ebd0fc0d49d405b4d722642f69e8e02cf372597cd365c9403917249c190a65d`
- v3.24 cluster audit SHA-256: `cac0e509f5896f6f7c862e460639c3f6964446e439c72f49d337f209ebf0343b`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the only optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module/type/evidence remain legality constraints only.

## Post-score diagnosis motivating this version

v3.24 completed all 50 cases at `20/50`, with 150/150 successful stages and no
retry. Its exhaustive challenger produced exactly 625 Memory/Reflection rows,
but no earlier candidate and no proposal. Five Step errors form the new
High-confidence `state_feedback_alignment_gap` cluster.

In all five, the released state Step is present in the frozen ledger and marked
`clear`. The ledger contract binds `feedback_quote` to that state Step's own
`adjacent_feedback`. A Memory/Reflection at Step `s`, however, normally
summarizes the tool outcome produced by Step `s-1`. Frozen gold rows therefore
quote unrelated task/system context or the wrong tool packet instead of the
result the state claims to retain. Coverage was complete, but the compared
state/evidence pairs were temporally misaligned.

The larger 11-case acquisition-capability cluster is not selected: v3.18
already tested a validator-enforced probe-contribution gate and scored `22/50`.
The selected mechanism is a narrower, newly observed artifact-contract defect.

## Single major change

Replace same-Step feedback binding in the isolated state ledger with mechanical
predecessor-feedback binding. No other anchor, admission, challenger, arbiter,
or final-freeze semantics change.

For every Memory/Reflection Step `s`, emit exactly one row with fields:

```text
step, state_quote, source_step, source_feedback_quote,
candidate_kind, candidate_relation, downstream_consumer_step, verdict
```

Rules:

1. `source_step` is mechanically `s - 1`; it is `null` only when `s == 1`.
2. `source_feedback_quote` must be a literal excerpt from the structured
   current-observation slice presented to Step `s`. Canonically this is the
   result produced by `source_step`; task/history/interface boilerplate is
   excluded. It is `null` only when that predecessor-result slice is empty.
3. The model compares the complete Memory/Reflection claim at Step `s` with the
   result produced by `source_step`, not with Step `s`'s own feedback.
4. The three v3.24 closed pairs remain unchanged:
   `necessary_fact/omitted`, `entity_relation/unsupported`, and
   `outcome_claim/contradicted`.
5. A candidate still requires a later downstream consumer. Harmless
   compression, unused speculation, and causally irrelevant inaccuracies stay
   clear.
6. The earliest candidate row still mechanically freezes the sole state
   candidate. The one-proposal cap and default-keep arbiter remain unchanged.

No case router, entity/source heuristic, historical prediction input, gold
information, candidate pool, global selector, or result splice is added.

## Falsifiable prediction

The mechanism should make predecessor-result omissions and false outcome
readings visible before the fresh anchor while avoiding broad state candidate
flooding.

Expected post-score gain cluster: five frozen v3.24 errors sharing the same
first divergence. The primary online checks are:

- every state row has the mechanically correct predecessor `source_step`;
- every non-null source quote is literal in that predecessor's feedback;
- exact state-row coverage and chronology remain valid;
- at least one earlier aligned state candidate is emitted;
- only the mechanically earliest candidate may reach comparison;
- all final predictions remain exact copies of anchor or sole challenger.

The hypothesis is falsified if predecessor alignment produces no earlier
candidate, causes broad candidate flooding, violates artifact legality, or
yields Step Exact `<= 25/50`.

## Gain and regression analysis

Expected gains arise when state:

- records success but discards the concrete list/value needed by the next step;
- calls a predecessor search uninformative even though its result contains the
  required page or discriminating lead;
- asserts a task-material entity relation absent from predecessor evidence;
- claims failure or progress contradicted by the predecessor outcome.

Incumbent-correct risks are state Steps whose summaries legitimately compress a
large result, retain only the fact needed for the next decision, or mention
provisional hypotheses never consumed later. Exact predecessor binding alone
does not admit them: the unchanged closed pair, necessity test, downstream
consumer, earliest-candidate rule, one-proposal cap, and default-keep arbiter
remain regression controls.

The correction is uniform and independent of trajectory ID, entity, website,
source model, or fixed Step.

## Execution and acceptance protocol

1. Implement the versioned prompt, predecessor-source validator, runner, and
   negative tests.
2. Run offline tests and source scans only; do not run a smoke gate.
3. Execute all 50 frozen cases with three fresh serial sessions per case and at
   most four cases concurrently.
4. Freeze all predictions and intermediate artifacts after 50/50 completion and
   gold-free validation.
5. Only then read released labels and score all 50 cases.
6. Compute Step Exact transitions against v3.4, incumbent v3.20, and v3.24.
7. Accept only if Step Exact is strictly greater than `25/50`; complete the Goal
   only at `>= 30/50` with every legality/freeze check passed.
8. Otherwise reject the immutable version, audit every Step error, and create a
   new version from one next unified mechanism.

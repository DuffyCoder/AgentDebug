# GAIA v3.104 v3.83 Codex SDK transport preregistration

Date: 2026-08-31

Status: preregistered and unscored. No GAIA-50 inference result is claimed by
this document.

## Frozen identity

- Version:
  `agentdebug.codex-agent-judge.gaia-v3.104-v3p83-codex-sdk-transport-gpt55-medium`.
- Direct semantic parent: accepted v3.83,
  `agentdebug.codex-agent-judge.gaia-v3.83-clean-v3.20-model-only-gpt55-medium`,
  Step Exact `26/50`.
- Semantic protocol: `gaia-v3.83-clean-v3.20-model-only-gpt55-medium`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Dataset identity SHA-256:
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort file SHA-256:
  `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Cohort identity SHA-256:
  `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction-manifest file SHA-256:
  `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Prediction-manifest identity SHA-256:
  `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`.
- Frozen v3.83 protocol source SHA-256:
  `a97908a78cec8df5fe9e4777d30aa9ecf498d1cdd1d692a42cc66976e9844531`.
- Frozen v3.83 wrapper-runner source SHA-256:
  `a1613a04ad21b3306c61cd3082753ff5890ad09ab3d939f4c292c15e1dac483d`.
- Model: `gpt-5.5`.
- Reasoning effort: `medium`.

## Single major change

Change only the per-stage execution transport from the v3.83 `codex exec`
process to the Python Codex SDK/app-server interface pinned at
`openai-codex==0.147.0`. The v3.83 task text remains byte-identical at the SDK
boundary. The packet-state anchor, earliest-causal challenger, default-keep
arbiter, schemas, validators, case order, concurrency, retry bounds, and
freeze-before-score boundary remain those of v3.83.

The SDK transport runs the task as a local agent, so the task retains the same
filesystem reads, write-once stage artifacts, and local validator invocation
as the reference v3.83 execution. It does not import any prompt, prediction,
or mechanism from rejected post-v3.83 lineages.

## Frozen transport contract

- SDK package: `openai-codex==0.147.0`.
- Additive requirements SHA-256:
  `f78c35e99b400eb802979d7756321dedcd09bc8c7c13756defccf737ddede9c5`.
- Frozen parent `uv.lock` SHA-256:
  `ac122fd9a87762dd20f491df918f8431907c5fe890dfcfc3a895e3e43f0569a2`.
- Provider: `sophnet`.
- Provider base URL: `https://api.sophnet.com/v1`.
- Required native wire endpoint: `POST /v1/responses`.
- Wire API: `responses`; no Chat Completions translation or fallback is
  permitted in v3.104.
- Credential source: the process environment variable `SOPHNET_API_KEY` only.
  The value must not appear in a CLI argument, repository file, task, model
  shell environment, stdout/stderr, request audit, or frozen artifact.
- SDK and provider request/stream retries are disabled. The existing maximum
  of two semantic attempts per stage remains the only semantic retry bound.
- Every semantic attempt starts a new ephemeral SDK helper process and a new
  ephemeral Codex thread. No thread, conversation, or cross-case state may be
  reused.
- The executing agent receives the requested model `gpt-5.5`, reasoning effort
  `medium`, deny-all approvals, and the v3.83 full-access sandbox contract.

OpenAI's public interface descriptions used to classify this experiment are
the [Codex SDK documentation](https://learn.chatgpt.com/docs/codex-sdk) and the
[Responses API reference](https://developers.openai.com/api/reference/cli/resources/responses/methods/create).

## Mandatory capability preflight

Before any benchmark input is opened, the runner must execute one
non-benchmark SDK turn against the frozen provider base URL. The preflight must
complete through the native Responses wire and produce valid secret-free SDK
provenance.

If the provider lacks a compatible `/v1/responses` implementation, the SDK
package/version is wrong, authentication fails, or the preflight otherwise
fails, v3.104 stops before GAIA-50 inference. It must not fall back to
`/v1/chat/completions`, another provider, another model, or the reference CLI.
Such an outcome is a transport-capability failure, not a scored benchmark
result.

## Frozen execution topology

- Run all 50 cases; there is no smoke gate or case router.
- Run exactly three serial stages per accepted case:
  `packet-state-anchor`, `earliest-causal-challenger`, and
  `default-keep-arbiter`.
- The target accepted topology is `50 x 3 = 150` fresh SDK sessions/threads.
- Maximum workers: `4`.
- Maximum semantic attempts per stage: `2`.
- Upstream state may enter a later stage only through the frozen v3.83 stage
  artifacts.
- No label, gold rationale, metric, scored artifact, historical prediction,
  error report, or cross-case state is available during inference.

After all 150 accepted stages, every v3.83 schema, taxonomy, literal-evidence,
ordering, checkpoint, challenger, arbiter, and manifest validator must pass.
The run must contain exactly 50 merged predictions with no missing or repaired
case. Transport provenance, credential-hygiene audit, and the gold-free
artifact tree are frozen before labels can be loaded. Scoring may begin only
after the frozen tree is reverified.

## Falsifiable hypothesis and decision rule

The falsifiable hypothesis is that replacing only the execution transport
with the pinned Codex SDK preserves the v3.83 judge semantics and may change
Step Exact through transport/runtime behavior alone.

- Selection metric: Step Exact only.
- Accept v3.104 only if the complete legal GAIA-50 run has Step Exact
  `>26/50`.
- Complete the Goal only at Step Exact `>=30/50` with every legality and
  isolation check passing.
- Step+Module, All Correct, module/type distributions, token counts, and
  latency are diagnostic only.
- A partial run, missing case, illegal artifact, failed preflight, credential
  leak, or post-freeze mutation is not a score and cannot be accepted.

## Formal invocation

Install the frozen base environment and the separately pinned additive SDK
runtime, inject `SOPHNET_API_KEY` through the operator's secret environment,
and run:

```bash
uv sync --frozen --extra dev
uv pip install --python .venv/bin/python -r requirements-v3p83-transports.txt
.venv/bin/python -m \
  scripts.run_agent_judge_gaia_v3_104_v3p83_codex_sdk_transport_gpt55_medium_paper50 \
  --execute --max-workers 4 --max-attempts 2
```

The additive requirements file is separate by design: the published v3.83
`uv.lock` remains byte-for-byte immutable and continues to pass its frozen
release hash verification.

The key value is intentionally absent from this preregistration and from the
checked-in configuration.

# Luna GAIA v3.45 preregistration

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.45-clean-v3.20-anchor-preserving-independent-typed-challenger-panel`
- Direct semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: v3.20, Step Exact `25/50`
- Acceptance: Step Exact `>25/50`; Goal completion: Step Exact `>=30/50`
- Frozen `gaia-paper-v1` 50 cases; dataset SHA-256 `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`; cohort SHA-256 `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- `gpt-5.6-luna`, reasoning `medium`; no smoke gate; full GAIA-50 after offline validation.

Single major mechanism: retain one clean v3.20 anchor, packet-state ledger, and
checkpoint unchanged. Replace only the downstream single-challenger topology
with an anchor-preserving independent typed-challenger panel. Four fresh,
mutually isolated, anchor-aware sessions each receive the same frozen anchor
bundle and full Canonical Trace. Each must emit either `no_challenge` or at
most one complete later proposal under one uniform typed-boundary contract:
`state_truth`, `post_feedback_maturity`, or `alignment`. A proposal is legal
only after a literal certificate falsifies the anchor as a reasonable probe or
noncritical predecessor. The runner deduplicates proposal Steps into a bounded
pool of the anchor plus at most four alternatives. One fresh exact-copy
selector sees the anchor explicitly, defaults to it, and may override only when
one proposal's literal owner/predicate/maturity/veto/local-repair certificate
falsifies the anchor and dominates every other proposal.

The frozen v3.44 result is the immediate negative control. It was complete and
legal at Step Exact `13/50`, with fresh anchor `21/50` and candidate oracle only
`29/50`. Its selector changed 32 Steps: four direct gains, 12 direct
regressions, and 16 wrong-to-wrong moves. The completed 37-error audit locates
17 errors at the anchor, 11 at false override of a correct anchor, four at
selector loss of an already-recalled gold Step, and five at annotation
ambiguity. Thus anonymous full-boundary voting failed both recall and anchor
preservation.

The positive evidence comes from the frozen v3.39 clean-v3.20 experiment. Its
single bounded typed challenger raised its own fresh anchor from `22/50` to
`25/50`, producing three direct gains and zero direct regressions; its four
incumbent-relative losses were fresh-anchor sampling differences retained by
the arbiter, not challenger overrides. However, one session proposed only 11
alternatives and its anchor-plus-proposal oracle remained `25/50`. v3.45 tests
whether four independent applications of that single typed-challenge
mechanism increase recall while an explicit anchor-falsification selector
preserves the zero-direct-regression property.

Expected gains are wrong clean anchors for which at least one independent
challenger closes a literal later `state_truth`, `post_feedback_maturity`, or
`alignment` boundary and the selector verifies that anchor-only repair cannot
avert it. Regression risks are incumbent-correct direct execution, explicit
constraint, and state-truth anchors displaced by persuasive later maturity
narratives. Controls are four fixed challengers for every case, fresh sessions,
identical inputs, no case/model/source routing, no candidate sharing between
challengers, zero-or-one proposal per challenger, at most five total Steps,
explicit anchor identity, default keep, exact-copy-only output, and literal
anchor-falsification plus pairwise dominance checks before override.

v3.21 through v3.44 remain immutable rejected experiments and are not semantic
parents. v3.45 is built over v3.20 anchor semantics. It transplants only the
single bounded typed-challenge mechanism for an independent replicated test;
it does not inherit any rejected anchor, ledger, prediction, selector,
validator result, case output, or historical decision. Inference may not read
labels, scores, audits, prior predictions, experiment documents, case studies,
or git history.

Diagnostic falsifiers are candidate oracle below `30/50`, more than four
distinct challenger proposal Steps, any proposal without a complete typed
boundary and witness certificate, any selected prediction that is not an exact
anchor/proposal copy, or any direct selector regression. These diagnostics do
not accept a version: the sole version acceptance rule remains final Step Exact
`>25/50`, and Goal completion remains final Step Exact `>=30/50` after all
legality checks.

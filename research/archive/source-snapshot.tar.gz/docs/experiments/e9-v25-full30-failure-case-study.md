# E9 v25 full30 failure case study

## Outcome

v25 passed dry3 at 2/3 with no failed output, but its frozen full30 tuning run
did not reach the 40% Step Exact promotion threshold.

- Step Exact: 10/30 (33.33%; gate requires 12/30)
- Step+Module Exact: 3/30 (10.00%)
- All Correct: 3/25 (12.00%)
- Successful outputs: 28/30
- Failed outputs: 2/30
- New logical completions: 10
- HTTP attempts: 10, with zero retries

The promotion gate rejected v25.  Held-out smoke must not run from it.

## What v25 fixed

Compared with v24 full30, v25 improved Step Exact from 6/30 to 10/30 and
reduced failed outputs from 10 to 2.  Every former prose-length rejection and
every former review-checkpoint/final-step equality rejection became a normal
raw LLM judgment.  The change therefore removed false validator failures
without copying, repairing, or replacing any semantic root.

The environment Step Exact breakdown became ALFWorld 4/10, GAIA 4/10, and
WebShop 2/10.  v24 had 1/10, 5/10, and 0/10 respectively.  The local-error
objective materially improved ALFWorld and WebShop, but did not yet meet the
12/30 full gate.

## Remaining transport failure

One two-case GAIA batch returned HTTP 2xx with provider usage and
`finish_reason=stop`, but no strict final JSON content.  Both cases were kept
as `invalid_json/empty_response`.  One of those cases had been Step-correct in
v24, so the repeated default-thinking final-content defect plausibly costs at
least one Step match.  No custom thinking option was sent and no HTTP retry
occurred.

## Remaining semantic error pattern

Of the 28 structurally successful cases:

- 10 exactly matched the released critical step;
- 13 selected a later step; and
- 5 selected an earlier step.

Four wrong predictions were exactly one step from gold.  Their recurring
pattern is an upstream module output immediately followed by a downstream
symptom:

- an erroneous plan followed by a misaligned/invalid action;
- an erroneous memory or reflection followed by a bad plan; or
- an earlier agent defect followed by a system/tool symptom.

The v25 prompt already states module ownership, but its final comparison does
not force a last upstream-owner audit.  As a result, the model often selects
the visible action/system consequence one step after the faulty module that
introduced it.  Conversely, the dry WebShop case moved from v24 step 12 to
v25 step 9 while gold is step 13, showing that an unconditional "earliest"
preference can also over-correct.  The next change must be ownership-based,
not a numeric step shift.

## v26 optimization direction

Before another model attempt:

1. Keep the v25 local-error objective, raw-only final semantics, taxonomy,
   evidence-source ownership, gold isolation, lineage validation, and exact
   per-phase call budgets.
2. Add a final upstream-owner audit: immediately before accepting an action
   or system root, inspect the preceding same/previous-step memory,
   reflection, and planning output.  Prefer the earlier module only when it
   already contains the specific false fact, ignored constraint, or defective
   strategy that directly causes the downstream symptom.  Do not move a step
   merely because it is earlier.
3. Keep Flash's default request body.  When `message.content` is empty, allow
   a transport-only recovery from `reasoning_content` only if that field ends
   in one complete strict JSON object.  Persist only that exact JSON suffix;
   never persist or expose free-form chain-of-thought and never derive a root
   in code.
4. Run dry3 first, then full30 only after an accepted dry.  A failed v26
   attempt requires another case study before further optimization.

No v25 artifact may be mutated or rescored under the v26 parser.

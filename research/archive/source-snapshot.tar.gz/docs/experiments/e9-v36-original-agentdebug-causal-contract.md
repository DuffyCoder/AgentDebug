# E9 v36: original AgentDebug causal contract

## Hypothesis

The v35 full30 failure study shows that transport validity is no longer the
bottleneck.  Its accumulated environment-specific tie breakers produce an
unstable selection policy: 23/30 steps are wrong, 16 misses are later than
gold, and 14 wrong roots are assigned to Action even though 22 of those gold
owners are Memory, Reflection, or Planning.

v36 tests whether a shorter decision contract derived from the released
AgentDebug Phase 1 and Phase 2 prompts improves stable causal localization.
The final judge must select the earliest important, locally observable error
whose one-error correction would fundamentally redirect the failed branch.

## Semantic design

Candidate generation and independent final selection both use the same core
review:

1. inspect every visible module output using only contemporaneous inputs;
2. follow the within-step dependency order Memory to Reflection to Planning
   to Action;
3. reconstruct the final failure and trace causality backward;
4. distinguish the introducing owner from later actions and symptoms;
5. apply the one-error counterfactual;
6. treat steps 1--3 as usually exploratory but retain a clear fundamental
   early error;
7. allow an actual external failure or enforced boundary to own System.

The frozen v13 prior and the Candidate response remain untrusted hypotheses.
The independent raw Selector emits every final semantic field and may reject
all proposed steps.

## Preserved non-semantic controls

v36 preserves v35's:

- strict JSON and exact case-order contract;
- exact extra-brace and exact missing-final-brace mechanical repairs;
- atomic taxonomy pair;
- opaque source-ID evidence ownership and verbatim projection;
- no semantic fallback or mutation;
- gold-isolated prediction and post-closure scoring;
- durable logical-completion ledger and exact phase topology;
- DeepSeek Flash default request body with no thinking configuration.

There is no confidence, score, probability, rank, vote, weight,
deterministic semantic finding, or label-derived rule.

## Frozen topology

- dry3: cumulative 481 to 483, exactly Candidate plus Selector;
- full30: cumulative 483 to 503, exactly 20 new calls after dry reuse;
- smoke30: cumulative 503 to 547, exactly 44 fresh Scout, Arbiter,
  Candidate, and Selector calls.

The dry3 gate remains 2/3 exact steps, 2/3 exact step-plus-module pairs, 2/3
All Correct, and no failed row.  The tuning full30 gate remains at least
12/30 Step Exact.  Held-out smoke is still one-shot and cannot run unless the
tuning gate accepts v36.

# E9 v40: causal-ledger length contract

## Pre-registered change

v40 changes one output-format boundary inherited from v39. The maximum accepted
length of `causal_basis` increases from 1024 to 1280 characters, while the prompt
asks the model to stay at or below 1200 characters. The final semantic tuple,
taxonomy validation, evidence validation, candidate lanes, causal ledger,
selector topology, model settings, and raw-selector-only decision rule are
unchanged.

The validator now distinguishes an empty value from a value that exceeds its
declared maximum. This changes only the diagnostic error message and does not
repair or reinterpret model output.

## Failure-derived hypothesis

The rejected v39 dry3 run produced a semantically complete C02 selector record
whose `causal_basis` was 1027 characters, three characters above the frozen
limit. If that record had satisfied the format contract, its raw tuple would
have been the exact answer `1/action/misalignment`, raising dry3 Step Exact from
1/3 to 2/3 with no semantic mutation.

Therefore the falsifiable hypothesis is: a small, explicitly bounded allowance
for the judge's causal comparison will eliminate that format-only failure and
let the otherwise unchanged v39 method pass the dry3 2/3 gate. If dry3 does not
reach 2/3 with zero failed outputs, v40 is rejected and must receive a new case
study before any further model call.

## Evaluation order

1. Freeze and byte-verify the v40 code bundle after all local tests pass.
2. Run the same three tuning cases with exactly two logical completions.
3. Promote to full tuning only if dry3 reaches Step Exact, Step+Module Exact,
   and All Correct of at least 2/3 with no failed output.
4. Promote to held-out smoke only if full tuning reaches at least 12/30 Step
   Exact and its other frozen gates.

The held-out smoke cohort remains unopened during tuning.

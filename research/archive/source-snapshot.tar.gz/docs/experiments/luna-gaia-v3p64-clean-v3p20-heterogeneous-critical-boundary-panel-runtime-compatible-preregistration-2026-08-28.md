# Luna GAIA v3.64 预注册：runtime-compatible heterogeneous boundary panel

日期：2026-08-28

## 冻结身份与接受条件

- version：`agentdebug.codex-agent-judge.luna-gaia.v3.64-clean-v3.20-heterogeneous-critical-boundary-panel`
- semantic parent：`agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- accepted incumbent：Luna v3.20，Step Exact `25/50`
- original baseline：Luna v3.4，Step Exact `21/50`
- 数据集：冻结 `gaia-paper-v1` 50 例
- dataset content SHA-256：`fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- cohort content SHA-256：`193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- cohort manifest file SHA-256：`31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- prediction manifest file SHA-256：`77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- v3.20 parent source SHA-256：`3e886325bf0a4b4d4a3e770071c0a36fe81dab2bebaf5015561ca828b6c2e4f9`
- 模型：`gpt-5.6-luna`
- reasoning effort：`medium`
- 版本接受条件：完整、合法 GAIA-50 的 Step Exact `>25/50`
- Goal 完成条件：完整、合法 GAIA-50 的 Step Exact `>=30/50`
- smoke gate：无；离线验证后直接完整 GAIA-50

## v3.63 冻结 first-divergence 审计

v3.63 调度完 50/50 case、100 次 anchor attempt，但 100/100 均在首个 shell
command 初始化前复现 `bwrap: loopback: Failed RTM_NEWADDR`。独立 runtime audit
确认 100/100 没有 command execution、没有 manifest read、没有 anchor artifact；最终
0/50 predictions，不能评分。50 个 case 的 first divergence 全部是高置信度
`runtime_or_validation_failure`，不是 Judge semantic failure。v3.63 已冻结拒绝，
v3.20 继续作为 25/50 incumbent。

离线复现显示 `workspace-write + network_access=true` 改为 UID-map permission failure，
legacy Landlock 又与当前 permission profile 不兼容。因此继续修改 Judge prompt 无法
解决；最小统一修正必须作用于 runner 执行兼容层。

## 唯一 Judge 机制

从 v3.20 干净语义重新加入且只加入 `heterogeneous complete-boundary panel`：

1. 原样 v3.20 packet-state anchor；
2. 一个 `state_constraint` complete-boundary specialist，最多一个 prediction 或 none；
3. 一个 `capability_action` specialist，最多一个 prediction 或 none；
4. 一个 `feedback_terminal` specialist，最多一个 prediction 或 none；
5. anchor-preserving exact-copy selector，只能保留 anchor 或精确复制一个 proposal。

specialist 均全轨迹审查、互相隔离且看不到 anchor。selector 禁止 vote、来源、Step
位置、module/type 或措辞强度排序。proposal 只需拥有并能通过局部修复改变第一个
benchmark-relevant failed path，不要求一次修复消除所有后续独立错误；override 仍需
anchor noncritical/recovered/predecessor/symptom 与 proposal owner 的双侧 literal evidence。

这与 v3.63 是同一尚未得到任何语义预测的可证伪机制，不自动继承 v3.21--v3.63 的
其他 prompt、ledger、challenger、validator 或 prediction。semantic parent 仍只有 v3.20。

## 运行时兼容修复（非 Judge 选择机制）

- 使用历史已证明可执行的 `danger-full-access`，因为当前嵌套环境不能启动两个受限
  sandbox 后端；这不是模型、effort、prompt 或 selector 改动。
- anchor、三个 specialist、selector 的每次 fresh session 都把 `-C` 和 subprocess
  cwd 固定为其独立 attempt 目录。
- 每个 attempt 只复制阶段所需 frozen manifest/sidecar；task 仍声明 exact read/write
  boundary 和 forbidden sources。
- inference 后独立扫描全部 command logs，拒绝 labels、metrics、scored artifacts、
  old predictions、post-score audit、git history、original trace 越界读取和 external
  resource access。
- 独立重建完整文件树 allowlist；任何意外目录/文件、缺失文件、hash/顺序差异均使
  版本非法并直接拒绝。

## 预期 gains、regressions 与 falsifiers

语义预期与 v3.63 相同：v3.62 已证明 local candidate recall oracle 39/50，但 reducer
只有 18/50；论文式开放 inventory 的瓶颈是 global selector。三个互斥 family 将候选
上界固定为 anchor+3，同时保留 state、capability/action、feedback/terminal 的异质
召回。主要回归风险仍是 family split 漏掉跨 owner 边界、reasonable probe 被包装成
critical proposal、selector 晚选及 false override。

预注册 falsifiers：

- 50 例中任一 case/stage 无法完成；
- candidate oracle `<30/50`；
- selector 相对 fresh anchor 的 direct gains 不多于 direct losses；
- final Step Exact `<=25/50`；
- 任一 source hash、command access、write topology、50/50 顺序、schema/taxonomy/
  evidence、exact-copy、case-routing 或 gold-free 审计失败。

Candidate oracle 和 family/module/type 仅用于评分后根因判断；版本接受、拒绝与 Goal
完成仍只使用 Step Exact。实现测试、prepare-only 计划和 source hashes 将在首次
GAIA-50 模型调用前追加并冻结。

## 预推理冻结记录

- Python compile：protocol、runner、registry、tests 和独立 access/write auditor
  全部通过。
- 离线测试：`19 passed`（v3.20、v3.37、v3.64 相关测试）；v3.64 专属测试
  `6 passed`。
- sandbox compatibility：同一 `gpt-5.6-luna` / `medium`、fresh ephemeral
  `danger-full-access` 会话，在独立临时目录 `-C` 下成功执行唯一只读 `pwd` 命令；
  command event 的 cwd 与临时 attempt 完全一致。
- prepare-only：50/50 case，固定五阶段，计划 `250` 个 fresh session，最大并发 4，
  每阶段最多两次 attempt；未运行 smoke。
- case input：50 个隔离目录、100 个 manifest/cohort 文件。
- prepared prediction manifest content SHA-256：
  `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`
- protocol source SHA-256：`586d4e1ef926b9115ad0ecc7416aed610dd65af6880d68b004382b480bfced2e`
- runner source SHA-256：`634cb038ead80354b02d460948b9457dbc0bda954630dc46b4d29ec1b3f2e7b7`
- registry source SHA-256：`b8636c006d3737867b19da3d5e054e78cba8b4270b433557783037aea470ee82`
- taxonomy source SHA-256：`d7e4b878059bbecec0a8fd3f078c0aeb5755bf9e65bb938c897dd83685f28c5c`
- test source SHA-256：`d3049159b4b8c0f1586c28a9a1265c820931a8d5b7da0c273343b78da5154d67`

以上五个 inference-semantic/source hash 已写入独立 auditor 并在首次 GAIA-50
模型调用前冻结。auditor 本身只在全部推理与 gold-free aggregate 冻结后运行；在
评分前必须确认 250 个成功 stage、50/50 顺序、零 forbidden command 和零意外写入。

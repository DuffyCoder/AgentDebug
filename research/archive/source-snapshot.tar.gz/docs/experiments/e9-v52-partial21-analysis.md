# E9-v52 partial full30 analysis

This analysis uses only the 21 tuning-v1 rows persisted before the HTTP 402
boundary. It does not inspect smoke-v1 labels and does not alter any semantic
output.

## Observed result

- Persisted rows: 21; successful raw Selector outputs: 18; HTTP failures: 3.
- On the 18 successful rows: Step Exact is 6/18 (33.3%), Step+Module is 3/18,
  and All Correct is 3/18.
- With the three HTTP failures retained in the current denominator, the
  partial figures are 6/21, 3/21, and 3/21.
- Step direction over all 21 rows: 6 exact, 5 early, 7 late, and 3 missing.
- Environment coverage is not balanced at this boundary: ALFWorld contributes
  10 rows (3 Step Exact), GAIA 10 rows (3 Step Exact, including 3 HTTP
  failures), and WebShop only 1 row (0 Step Exact).

## Comparison and localization

On the same first 18 successful trajectory IDs, v51 also achieved exactly
6 Step Exact. V52 gained one case and lost one case, so its module-local census
has not produced a net step improvement on the observable prefix.

The raw v52 Critic candidate set contains the gold step for 9/18 cases, while
the raw Selector is exact on 6/18. Candidate recall is therefore still a
material ceiling, but it is not the only error: three recalled gold steps were
not selected. The Selector can also diagnose directly from the trace, so its
chosen step is not required to appear among the Critic candidates.

V52 currently has 6 correct steps. To pass the 12/30 tuning gate it must obtain
at least 6 exact steps among the 12 unresolved trajectories (the failed batch
plus the three unattempted batches). V51 obtained only one exact step on those
same 12 IDs. This does not prove v52 will fail, but it makes a large late-cohort
gain necessary and means the accepted dry3 signal did not generalize to the
observed full prefix.

## Next decision

The exact v52 recovery should still be completed once the bound DeepSeek
provider accepts requests, because replacing the interrupted run with an
estimate would violate the 30-row denominator. If the recovered full30 misses
12/30, the required failure study should target both candidate recall and
Selector choice rather than treating module census alone as the solution.

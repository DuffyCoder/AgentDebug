# E9 incumbent and test policy

## Current scoreboard

The primary metric is tuning-v1 full30 Step Exact with all invalid outputs in
the denominator.

1. **Development incumbent: v58 v30-incumbent copy Reviewer** — 12/30 Step
   Exact, 5/30 Step+Module Exact, 4/25 All Correct, 30/30 successful outputs.
2. v30 first-defect Critic — 10/30 Step Exact, 5/30 Step+Module Exact, 4/25
   All Correct, 29/30 successful outputs.
3. v25 local-error Critic — 10/30 Step Exact, 3/30 Step+Module Exact, 3/25
   All Correct, 28/30 successful outputs.
4. v52 module-census recovery — 9/30 Step Exact, 5/30 Step+Module Exact,
   4/25 All Correct, 30/30 successful outputs.

Dry3 has many tied 2/3 results and is only a cheap screening set. It does not
define the incumbent. v58 passed the development gate and was evaluated once
on smoke-v1 with fresh DeepSeek semantics. Its audited result is 8/30 Step
Exact, 3/30 Step+Module Exact, and 3/27 All Correct, with three conservative
invalid outputs. All 27 valid Reviewer decisions were KEEP, so its fresh v30
incumbent baseline was also 8/30. The 12/30 heldout goal failed. smoke-v1 is
now spent and must not be used for further unbiased prompt tuning.

## Incumbent rule

Every semantic challenger starts from the frozen code bundle and behavior of
the best full30 incumbent, currently v58. “Latest version” has no privileged
status.  After a failed challenger, the next challenger starts from the same
incumbent unless another run has formally displaced it.

Compare challengers lexicographically:

1. full30 Step Exact correct count;
2. full30 Step+Module Exact correct count;
3. full30 All Correct correct count;
4. successful prediction count;
5. fewer logical completions, only if semantic metrics remain tied.

A challenger that improves this tuple becomes the development incumbent even
if it has not reached the separate goal gate.  The goal gate remains Step
Exact >= 12/30.  Held-out smoke may run once only after that gate passes.

## Simplified testing workflow

The semantic diagnosis and benchmark evaluation contracts are not simplified.
Gold isolation, raw LLM final semantics, evidence ownership, strict
denominators, content-addressed caches, ledgers, preregistration, and held-out
gates remain unchanged.

Only engineering validation is shortened:

1. During editing, run the smallest tests covering the modified prompt,
   parser, workflow boundary, and incumbent-regression cases.
2. Do not rerun unrelated historical archive tests after every small edit.
3. Run the complete repository test suite exactly once after the challenger
   is ready to freeze.  Any subsequent source change invalidates that freeze
   and requires one new full run.
4. Run the fixed dry screen once.  Reject immediately if it regresses the
   incumbent dry behavior or fails structural validity.
5. Run tuning full30 only after dry acceptance.  Score against the incumbent,
   not merely against the previous failed version.
6. Run held-out smoke only after tuning reaches 12/30.  Never use smoke to
   tune prompts.

Every failed external attempt still requires one case study before another
provider call.  The case study must state both the semantic failure and why
the challenger did or did not preserve incumbent strengths.

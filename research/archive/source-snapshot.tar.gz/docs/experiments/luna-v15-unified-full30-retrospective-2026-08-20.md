# Luna v15 unified：tuning-v1 full-30 实验复盘

日期：2026-08-20

## 结论

正式实验 `agentdebug.codex-agent-judge.luna-v15-unified-v2` 完成了完整、冻结的
`tuning-v1` 30 条运行。30/30 prediction 合法，30 个 accepted thread 彼此独立，
所有 session、lineage、implementation、prediction、secret、pre-score 与
post-score audit 均通过；gold 只在 prediction 冻结并完成 pre-score audit 后加载。

官方结果为：

- Step Exact：**7/30（23.3%）**；
- Step+Module：**2/30（6.7%）**；
- All Correct：**1/25（4.0%）**；
- ALFWorld / GAIA / WebShop Step：**1/10 / 5/10 / 1/10**。

这低于 v14 的 9/30，也低于目标 12/30，因此不能晋升，目标仍未完成。本报告是
同一已公开 `tuning-v1` 上的评分后调优分析，不是 held-out 或未知数据上的泛化结果。

本轮最重要的结论不是“仲裁仍不够好”，而是：

1. **23 个 Step 错误全部是 candidate recall miss。** 候选池只覆盖 7/30，最终也
   正好命中这 7 条；没有一条是 gold 已在池中却被仲裁丢掉。
2. **名义四路召回实际塌缩为 strategy 单路。** strategy 命中 7 条并被最终选择
   29/30；local 唯一命中与 strategy 重合；state 提出 16 个候选却 0 命中、0
   入选；predecessor 30 条中一次也没有产生候选。
3. **错误链通常找到了，critical boundary 没校准好。** 23 个 miss 中，gold 距
   最近候选 1 步的有 11 条、2 步的有 7 条；只有 5 条距离超过 2。对所有现有
   nominee 做统一 `±1` 邻域闭包，评分后 candidate oracle 为 18/30；`±2` 为
   25/30。它们只是分析上限，不是预测准确率。
4. **Step/owner 的字段解耦没有带来推理解耦。** 7 个 Step 正确样本中 owner 仅
   2/7 正确，type 仅 1/7 正确；最终 owner 为 Planning 24、Action 6，Memory、
   Reflection、System 全为 0。
5. **locator 方差很高。** v15-v1 与 v15-v2 的 30 份 prompt 除版本号一行外逐字
   相同，但 candidate pool 完全相同仅 5/30，selected step 相同仅 15/30。
   当前 7--9/30 的波动不是稳定地修复少量 case，而是候选定位在独立 session
   间大幅漂移。

下一轮不应继续增加自由文本规则或再加一个同质 locator。最有证据的方向是：

- parent 机械生成中性的局部候选闭包，不再让同一模型决定邻居是否有资格入池；
- 候选保留 literal witness atom 用于锚定 Step，但不提前冻结最终 owner；
- 去掉 `root_status` 对候选的预先封杀，改为候选间的反事实边界比较；
- classification 不再接收 locator basis、lane 名称或 arbitration prose，只接冻结
  Step 的原始局部上下文与同 Step owner atoms；
- 对 recurrence、query epoch、typed System provenance 做机械建模，而不是继续用
  prompt 解释“成熟”“新策略”或“step limit”。

## 正式运行的有效性与成本

v15-v2 满足当前固定实验边界：

- frozen `tuning-v1` 30 条，环境分布 10/10/10；
- `gpt-5.6-luna`，reasoning effort `medium`；
- 30 个 fresh ephemeral Codex session，每个 session 只接收一条匿名轨迹；
- 30 个 thread ID 全局唯一，全部 attempt-01 成功；
- 最大并发 4，最多 2 次，只重试失败 case；本轮没有 retry；
- read-only workspace，model-visible tools 为 0，实际 tool calls 为 0；
- 30/30 decision、prediction、evidence atom binding 与 parent lineage 重算通过；
- 推理阶段不可见历史 prediction、proposal、case identity、gold 或评分文件；
- implementation snapshot、frozen prompts、decision、prediction、audit、metrics、
  per-example 与 score artifacts 均已持久化。

Token 使用：

| 项目 | 数量 |
|---|---:|
| input tokens | 2,274,475 |
| cached input tokens（已包含在 input 中） | 19,456 |
| output tokens | 51,761 |
| reasoning output tokens（已包含在 output 中） | 33,444 |
| accepted predictions | 30/30 |
| attempts | 30 |

`scored/metrics.json` 中约 56 秒是官方评分进程耗时，不是 30 条推理的总 wall time；
运行产物没有持久化可用于报告的全局推理 wall time。

### v15-v1 为什么不计正式结果

先前的 `luna-v15-unified-v1` 已得到 30 个冻结 prediction，但在评分前的全局
lineage audit 失败。原因是 decision audit 内存中的 tuple 在 JSON 持久化后变为
list；30/30 直接 Python equality 失败，但 canonical JSON 比较 30/30 完全相等，
且没有任何值差异、prediction 漂移或 implementation 漂移。

这个工程问题在 v2 中通过 JSON-native audit 与 canonical JSON comparator 修复，
并使用全新版本和全新目录重新运行完整 30 条。v1 没有被事后放宽、续跑或评分；
其冻结预测的后验 Step 7/30、candidate oracle 10/30 只能用于稳定性诊断，不能称为
正式合规实验结果。

## 结果分解

### Candidate recall 与 arbitration

| 项目 | 数量 |
|---|---:|
| candidate pool 含 gold Step | 7/30 |
| final Step Exact | 7/30 |
| recall miss | 23 |
| arbitration loss | 0 |
| strategy locator 命中 | 7/30 |
| local locator 命中 | 1/30，且与 strategy 同步命中 case 12 |
| state-fidelity locator 命中 | 0/16 nominations |
| predecessor candidate | 0/30 |
| final 选择 strategy | 29/30 |

候选池平均只有 2.2 个 Step：1 个候选的 case 有 1 条，2 个候选的有 22 条，3 个
候选的有 7 条。strategy candidate 29 次被判 `direct_root`、3 次被判
`causal_predecessor`；local candidate 则有 22/30 被标为 `downstream_symptom`。
同一响应先提出 strategy，再把 strategy 判成 root、把替代项判成 downstream，
最后 validator 又禁止选择 downstream，形成了自证闭环。

predecessor audit 的设计目标是检查 strategy 的 `C-1`，实际结果是 27 次
`not_material`、3 次 `not_applicable`。然而 v15-v2 中 gold 正好等于 strategy
`C-1` 的 case 有 `01, 06, 08, 19, 22, 28`。这说明“由模型先判断邻居是否有资格
入池”的 gate 过于保守，直接删除了 6 个最有价值的候选。

### 时间边界几何

23 个错误的 final offset：17 个偏晚、6 个偏早；signed median 为 `+1`，绝对
offset median 为 2，MAE 为 5.43。按 gold 到最近候选的距离分组：

| 最近候选距离 | Case | 数量 |
|---:|---|---:|
| 1 | 01, 02, 03, 04, 05, 06, 08, 09, 19, 22, 28 | 11 |
| 2 | 13, 16, 17, 23, 26, 27, 29 | 7 |
| 3 | 25 | 1 |
| >3 | 10, 14, 21, 24 | 4 |

统一的评分后 candidate coverage 诊断为：

| 候选集合 | Gold Step coverage |
|---|---:|
| 原 v15-v2 pool | 7/30 |
| 所有 nominee 加 `±1` | 18/30 |
| 所有 nominee 加 `±2` | 25/30 |
| 所有 nominee 加 `±3` | 26/30 |

这些数字不能作为准确率或用来逐 case 路由。它们只说明：大部分 locator 已靠近
正确失败链，下一步的主要问题是局部时间归属，而非完全重新搜索整条轨迹。

### Step、owner 与 type

Step Exact cases 为：`07, 11, 12, 15, 18, 20, 30`。

| Case | Gold owner/type | Pred owner/type | 条件结果 |
|---:|---|---|---|
| 07 | Reflection / progress_misjudge | Planning / constraint_ignorance | owner、type 均错 |
| 11 | Reflection / outcome_misinterpretation | Planning / inefficient_plan | 均错 |
| 12 | Planning / constraint_ignorance | Action / parameter_error | 均错 |
| 15 | Action / parameter_error | Planning / inefficient_plan | 均错 |
| 18 | Planning / inefficient_plan | Planning / inefficient_plan | 全对 |
| 20 | Action / misalignment | Action / parameter_error | owner 对、type 错 |
| 30 | System / environment_error | Planning / constraint_ignorance | 均错 |

因此 owner@correct-Step 为 2/7，type@correct-Step 为 1/7，完整 owner+type 为
1/7。忽略 Step 的 module exact 为 10/30，表面数值同样被错误 Step 上反复预测
Planning 放大，不能代表条件分类能力。

Gold owner 分布是 Planning 12、Reflection 6、Action 5、Memory 5、System 2；预测
分布却是 Planning 24、Action 6、其余全为 0。Gold Memory 5 条的 pool/Step/owner
命中全部为 0；Gold Reflection 6 条只有 2 个 Step 命中，owner 为 0；Gold System
2 条只有 1 个 Step 命中，owner 为 0。

结构上，30/30 selected Step 都有多个 owner atom，说明 validator 确实允许在
冻结 Step 后选择 owner；行为上却没有实现去锚定：selected basis 为
`mature_repetition` 的 16 条中，15 条直接映射成 Planning/inefficient_plan。
classification 仍在同一 LLM 响应中看到 locator 与 arbitration 的完整叙事，实际
只是确认前面的解释。

atom 表示层可表达 28/30 条 gold Step+owner。两条例外是：

- case 05：S30 System/step_limit，输入没有 typed termination/max-step fact；
- case 30：S1 System/environment_error，严格过滤普通 task text 后没有 typed
  task/interface contradiction atom。

不能重新把任意 30-step 轨迹或任意 Step-1 task text开放给 System；正确修复是让
上游 JudgeView 提供可审计的 typed execution cap/termination reason 与结构化
task-interface contradiction。

## 23 个 Step error 的逐例归因

下表中的 gold 与标签只在 v15-v2 prediction 冻结、所有 pre-score audit 通过后用于
分析。`S/L/F` 分别表示 strategy、local、state-fidelity nominee。

### ALFWorld

| Case | Gold | v15 pool -> final | 深层原因与通用修复 |
|---:|---|---|---|
| 01 | S3 Planning | S4/S5 -> S4 | strategy 找到重复已成熟的 S4，却把首次错误边界 S3 判为“合理探索”。gold 是 `C-1`；应机械加入 onset/predecessor，而不是让同一模型先决定其是否 material。 |
| 02 | S5 Reflection/causal_misattribution | S4/S18 -> S4 | S4 的早期重复抢占了 S5 对“desk 1 最可能有灯”的固执错误归因。需要把 observation 后的 next interpretation 作为候选，gold 是 strategy `C+1`。 |
| 03 | S1 Action | S2/S16 -> S16 | local/state 实际定位到相邻 S2 的 false-success claim，却没有 S1；gold 无 rationale，存在 Action/observation 相邻归属噪声。应保留 `S-1/S` 几何，不能据单例把所有 Action 左移。 |
| 04 | S5 Memory | S6/S8 -> S8 | state 看见 S6 对前一步的错误表述，却漏掉 gold S5 Memory；S8 的重复动作更显眼。需要 Memory/Reflection 专项窗口和 local `C-1`。 |
| 05 | S30 System/step_limit | S6/S29 -> S6 | S29 已靠近终止边界，但 pool 不含 S30，且 S30 无合法 System atom。需 typed termination provenance；不能用 `turn_count==30` 猜标签。 |
| 06 | S4 Planning | S5/S13 -> S5 | S4 是低信息 `look` 策略的 onset，S5 才显得“成熟重复”。又是 strategy `C-1`；需要同时保留 onset 与 maturity。 |
| 08 | S5 Memory/memory_retrieval_failure | S2/S6 -> S6 | S5 忘记早先已执行 `look`，S6 只是消费错误记忆的重复计划；state locator 却被更早的显式但次要矛盾吸引。需要跨历史 retrieval/omission 检查。 |
| 09 | S4 Planning/impossible_action | S3/S12/S20 -> S12 | S4 在尚未具备 desklamp 前提时规划相关操作；机械 action-format 缺陷和 S3 结果解释更显眼。需把 task affordance/prerequisite 与 next plan 绑定，gold 是 state `C+1`。 |
| 10 | S4 Planning/inefficient_plan | S14/S15 -> S14 | fridge 无 tomato 后从 S4 开始进入低信息 cabinet brute force；locator 直到后期 epoch 才认定错误。这是真正的长程 strategy-onset miss，需要确定性 strategy epoch。 |

### GAIA

| Case | Gold | v15 pool -> final | 深层原因与通用修复 |
|---:|---|---|---|
| 13 | S1 Action/misalignment | S3/S4 -> S3 | S1 把 GitHub issues 搜索 URL 交给不适合的 extractor；locator 只看到下游 issue verification/日期推理。需要 tool/source capability 与 action target 的结构化关系。 |
| 14 | S3 Memory/over_simplification | S7/S8 -> S7 | S3 Memory 丢掉 PDF 提取损坏/不可用的决定性细节；state locator因没有 literal contradiction 返回空。state-fidelity 必须覆盖 material omission，而非只查显式矛盾。 |
| 16 | S6 Planning/inefficient_plan | S4/S28 -> S4 | S2/S4/S6 是同站点重复提取，S6 才是第三次成熟 recommitment；模型把第二次 S4 提前判成熟。需按 tool、canonical params、result hash 机械计数。 |
| 17 | S4 Reflection/outcome_misinterpretation | S6/S8 -> S6 | S4 附近有高精度 external failure 与错误解释，但 strategy/state 都未提名；后续 source pivot 抢占。typed external atom应自动产生 Step candidate，owner再从同 Step 后置选择 Reflection/System。 |
| 19 | S2 Planning/inefficient_plan | S1/S3 -> S3 | S2 首次把未验证的 plane 假设写入下一条 query；S3 unsupported conclusion只是消费它。gold 位于两个 nominee 中间，需要 hypothesis-contamination basis 与中间邻居。 |

### WebShop

| Case | Gold | v15 pool -> final | 深层原因与通用修复 |
|---:|---|---|---|
| 21 | S13 Planning/inefficient_plan | S5/S28 -> S5 | 不同 query epoch 的分页停滞被混成一个全局 repetition，导致边界过早。应按 normalized query 与 result-set hash 重置 epoch。 |
| 22 | S6 Reflection/causal_misattribution | S3/S7/S29 -> S7 | S6 错误概括上一动作/结果，S7 才据此继续分页；state locator却只抓到 S29 的晚期显式矛盾。gold 是 strategy `C-1`，需 previous-action -> current-interpretation 几何。 |
| 23 | S2 Memory/hallucination | S4/S10/S23 -> S4 | S2 未逐项验证便形成“结果都不满足”的全称状态；state只在 S23 找到晚期错误。需要对 `none/all/no relevant result` 等 claim 建立证据覆盖检查并回到最早成员。 |
| 24 | S21 Planning/inefficient_plan | S8/S14 -> S8 | 真正错误属于后一个 query epoch，locator 把全局首次分页重复当 root，边界提前 13 步。需要 query/result epoch，而非全轨迹累计次数。 |
| 25 | S8 Planning/constraint_ignorance | S11/S24/S25 -> S24 | S8 首次选择不满足品类/约束的商品；模型被 S24 更明确的 fit mismatch 吸引。task constraint 必须绑定到具体 product/action decision，并保留 earliest concrete violation。 |
| 26 | S4 Planning | S6/S28 -> S6 | S4 是无关结果后的 strategy-stall onset，S6 的 query relaxation只是更显眼的后续决策。需要 onset/maturity bundle，gold 距 strategy 为 `-2`。 |
| 27 | S7 Action/misalignment | S2/S5 -> S2 | S7 plan 要求先核验颜色，action 却直接购买；locators停在早期约束不确定与重复搜索。需机械生成同 Step plan-action contract candidate。 |
| 28 | S4 Memory/over_simplification | S5/S13/S21 -> S5 | S4 Memory 丢失最新页面状态，S5 action消费该压缩状态；state却定位到更晚的 page-count矛盾。又是 strategy `C-1`，需最新 observation omission 检查。 |
| 29 | S2 Reflection/progress_misjudge | S4/S21 -> S4 | Page 1已有可核验候选，S2却断言无相关结果并翻页；state只在 S21识别类似 false match。需要对同类 progress claim 找 earliest unsupported member。 |

## 与 v14、v15-v1 和历史 clean 实验的关系

| 实验 | 状态 | Step | Step+Module | All | Candidate oracle |
|---|---|---:|---:|---:|---:|
| v14 unified | 正式合规 | 9/30 | 2/30 | 1/25 | 12/30 |
| v15-v1 | lineage 前工程失败；只作后验分析 | 7/30 | 1/30 | 0/25 | 10/30 |
| v15-v2 | 正式合规 | 7/30 | 2/30 | 1/25 | 7/30 |

v14 命中 `02,04,07,11,12,15,20,27,30`；v15-v2 保留
`07,11,12,15,20,30`，新增 `18`，丢失 `02,04,27`，净下降 2。v14 的问题是
12 个正确候选只选中 9 个；v15-v2 则把候选 recall 从 12 降到 7，因而即使
7/7 都选对也无法提高最终成绩。

候选层的差异更直接：v14 pool 命中
`02,04,05,07,11,12,15,17,19,20,27,30`，v15-v2 pool 只命中
`07,11,12,15,18,20,30`。v15 丢掉的 6 个 v14 候选是
`02,04,05,17,19,27`，只新增 `18`。这说明完全 step-only 的 locator 并没有比
owner-bound evidence witness 更会找边界；它反而更容易输出可套用到整条失败链的
抽象 strategy/Planning 解释。

v14 的三个例子尤其重要：case 04 用 Action witness 锚到 gold Memory 的同一
Step，case 17 用 System witness 锚到 gold Reflection 的同一 Step，case 27 用
Planning witness 锚到 gold Action 的同一 Step。正确解耦不是删除 witness，而是
让 witness 只负责锚 Step、最终 owner 再从同 Step 独立选择。

v15-v1 与 v15-v2 的 frozen prompt 在规范化唯一版本号行后 30/30 完全相同，
evidence/step-card catalog 也相同；但：

- selected Step 相同 15/30；
- strategy anchor 相同 15/30；
- local anchor 相同 12/30；
- candidate pool 完全相同 5/30；
- 完整 owner atom 相同 14/30。

v14、v15-v1、v15-v2 三轮共同 Step 命中只有 `07,11,12,20,30`，并集也只有
11 条。这证明当前主要不是稳定 plateau 上的精细校准，而是自由文本 locator 的
高方差。

更早的 proposal-free/clean full-30 Luna 实验大多落在 6--8/30；v14 的 9/30 是
当前最优合规 incumbent。旧 routed v12 的 13/30 明确读取同 case 的 v3 prediction，
按旧答案分流 preserve/replace，违反当前“不得依据上一轮答案选择策略”的固定
边界，因此不能作为合法 incumbent 或目标已达成的证据。

## 当前瓶颈

### P0：自由文本 candidate generation 高方差

Evidence atom 解决了“quote、Step、owner 是否机械可验证”，却没有解决“应该把
哪个 Step 放进候选池”。v15 去掉 owner-bound witness 后，strategy locator 更容易
输出抽象的 Planning 解释；v14 candidate recall 12，v15-v2 反降到 7。

作为纯评分后设计诊断，重新运行统一的 v14-style witness locator、v15 locator，
再机械加入 strategy `C-1` 的候选并去重，历史产物上的 union coverage 是 18/30，
平均约 4.1 个候选、最大 6；它比无差别 `±2` 的约 8.5 个、最大 15 更可控。新
协议若采用这一拓扑，必须对每条轨迹重新生成候选，不能读取或复用这些历史候选。

### P0：strategy 自证与来源锚定

final 29/30 选择 strategy。locator、candidate assessment、selection、owner/type
由同一响应共同生成；模型可以先提出一个 strategy 解释，再称它是 direct root，
再把其他候选标成 downstream，最后把 mature repetition 映射到
Planning/inefficient_plan。schema 顺序并不等于独立判断。

### P0：时间边界不是单点分类问题

Memory/Reflection 需要 `previous observation -> current claim`；Planning/Action
需要 `current plan -> action -> result`；repetition 需要 `episode onset -> prior
failures -> recommitment`。当前候选只给单个 Step ID和自由文本理由，无法稳定表达
这些关系，因此产生系统性的 `S-1/S/S+1` 偏移和 query epoch 错位。

### P0：state lane 设计失败

state-fidelity 两轮独立运行分别提出约 15/16 个候选，却对 11 个 gold
Memory/Reflection case 都是 0 命中。它偏爱晚期、显式、局部的文字矛盾，漏掉：

- 跨历史 retrieval failure；
- material omission/over-simplification；
- progress/outcome misjudge；
- causal misattribution；
- 最早的 unsupported universal claim。

继续微调同一 state prompt 的边际价值很低，需要改变输入关系表示或删除该 lane。

### P1：owner/type 仍受前置叙事污染

Step 后置 classification 在 validator 层是正确的，但不是独立推理阶段。分类输入
必须去掉 locator basis、lane、reason 与 arbitration prose；否则即使 Step recall
提高，Step+Module 与 All Correct 仍会停留在当前水平。

### P1：两类 System gold 在输入中不可表达

C05 与 C30 不是 type prompt 可以修复的问题。必须增加 typed、可审计的上游事实，
否则严格 System 过滤与官方标签之间存在结构性上限。

## 下一轮优化方向

当前先暂停新实验。若恢复优化，建议按以下顺序冻结下一版，而不是立即再跑：

1. **恢复 evidence-grounded witness。** 使用统一的 chronological/local witness
   locator 选择 literal atom，parent 机械派生 Step；witness owner 只用于证明
   “为什么看这个 Step”，不能约束最终 Module/Type。
2. **机械候选闭包。** 对 strategy `C>1` 无条件加入 `C-1` 中性 Step card，删除
   `material_status` gate；必要时再对 witness 加受限 `±1`。邻居只携带局部
   `S-1/S/S+1` 因果窗口，不复制全量 catalog，也不直接采用候选爆炸的全体
   `±2`。
3. **中性 arbitration。** 隐藏 strategy/local/state 来源和原 locator 结论；候选
   使用固定但无语义的 ID。删除 `root_status` 的选择资格门，直接比较：修复哪个
   Step 能最早、最小地切断后续失败，以及该候选是否消费更早候选的错误事实。
4. **机械 recurrence/epoch。** 用 tool、canonical params、query、target、result
   hash 与约束变化划分 episode；同时产生 onset 与 maturity cards，禁止模型把
   第二次调用随意称为“第三次成熟”。
5. **重做 state evidence。** 生成结构化 claim cards：claim 所在 Step、所解释的
   observation、完整历史支持、任务验收条件、是否为 `none/all/success/complete`
   全称判断。若不能做到，先删除当前零召回 state lane。
6. **classification 最小交接。** 只给 frozen Step 的原始局部上下文与同 Step
   owner atoms，不给 candidate source、basis 或先前说服性 prose。当前固定边界
   要求一条轨迹对应一个 Codex session，因此不能未经重新批准把 reviewer 拆成
   额外 session；可采用同一 session 内可审计的分阶段交接，或让 parent 机械完成
   候选扩展后只保留一次中性选择。
7. **补 System provenance。** 只接收 typed termination/cap 与 structured
   interface contradiction；继续拒绝普通 task text、普通失败与纯 step count。

下一轮的结构性验收门建议为：

- full-30 candidate Step oracle 至少 16/30，理想约 20/30；
- final 至少实现 candidate oracle 的 75%，且 arbitration loss 不超过 4；
- predecessor/neighbor 对当前六个 `C-1` 类型不再 0/6；
- Memory/Reflection candidate recall 必须非零，不能再出现 16 nominations / 0 hit；
- 30/30 legal，所有 session/lineage/implementation/prediction/secret/gold-free audit
  继续通过；
- 只有正式 Step Exact >=12/30 才晋升。

这些 oracle 和 case 分组已经使用 tuning-v1 gold，只能用于统一协议的设计与证伪，
不得在新运行中按 case 选择候选范围、拼接不同实验预测或替换单条结果。

## 权威产物

- v15-v2 完整运行：
  `output/agenterrorbench-codex-gpt-5.6-luna-tuning-v1-agent-judge-luna-v15-unified-v2-case30/`
- 官方 metrics：`scored/metrics.json`
- 官方逐例结果：`scored/per_example.csv`
- 冻结 predictions：`predictions.json`
- 运行摘要：`run-result.json`
- lineage audit：`lineage-audit.json`
- pre-score audit：`pre-score-audit.json`
- prediction audit：`prediction-audit.json`
- v15 protocol：`agentdebug/diagnostics/agent_judge_luna_v15_unified.py`
- v15 runner：`scripts/run_agent_judge_luna_v15_unified_tuning.py`
- v14 对照报告：
  `docs/experiments/luna-v14-unified-full30-retrospective-2026-08-20.md`

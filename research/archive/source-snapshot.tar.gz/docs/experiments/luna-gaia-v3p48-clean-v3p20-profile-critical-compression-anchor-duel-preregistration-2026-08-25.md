# Luna GAIA v3.48 preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.48-clean-v3.20-profile-critical-compression-anchor-duel`
- Direct semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: v3.20, Step Exact `25/50`
- Original frozen baseline: v3.4, Step Exact `21/50`
- Dataset: frozen `gaia-paper-v1`, 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Prediction manifest SHA-256: `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none
- Acceptance: complete/legal GAIA-50 and Step Exact `> 25/50`
- Goal completion: complete/legal GAIA-50 and Step Exact `>= 30/50`

## Evidence available before execution

v3.20 and v3.39 both score 25/50 but share only 21 exact cases; their post-score
union is 29/50. v3.39's bounded typed challenger changed its fresh anchor from
22/50 to 25/50 with three direct exact gains and no direct regression, but it
recalled only one later proposal and could not repair fresh-anchor sampling loss.

The rejected v3.47 run scored 19/50. Its fresh v3.20 anchor scored 18/50. Five
anchor-blind module profiles emitted 576 local-error rows, marked gold in 23/50
cases, and raised the fresh-anchor/profile post-score candidate oracle to 31/50.
The causal promotion stage nevertheless kept 49/50 anchors. Among the 31 final
errors, 12 had gold already present in a profile but not promoted; 10 of those
are non-ambiguous high-confidence cases. Conversely, 22 incumbent-correct cases
had nonempty profiles, so directly loosening the all-positive gate has a large
regression surface.

Frozen motivating artifacts:

- v3.47 `step-error-audit.json`: SHA-256 `2fe23ce65f052d676c04cd3c9c22f22bd620229861a811e6220f62408ba11e0c`
- v3.47 `step-error-clusters.json`: SHA-256 `78f7dfa8d55932e6e598a750ee0e632c052022904e9d8675461926fa12256109`
- v3.47 `mechanism-impact.json`: SHA-256 `c9cbf3261564f7ee5e0c53cda10815661bf1064eba4783acbccb98f940d925b8`

These scores, IDs, labels, audits, and historical predictions are post-score
design evidence only. They are forbidden from every v3.48 inference task.

## Single major change

Starting from clean v3.20, add one unified mechanism:

`module-complete evidence profile -> one critical-boundary compression -> anchor duel`

Five anchor-blind owner profiles inspect every observable Step and preserve
literal same-owner defects, adjacent facts, and recovery facts. Their output is
evidence inventory, never votes. One fresh compression/duel stage must first
reduce the entire positive inventory to zero or one critical proposal by applying
the same explicit veto taxonomy across all rows:

- reasonable initial probe;
- materially different evidence probe;
- normal negative tool result;
- recovered defect;
- mechanical predecessor or repair;
- faithful propagation;
- downstream symptom.

A surviving proposal must identify the first observable point where its owner
changes an unresolved task predicate from viable exploration to a failure-causing
commitment. The stage then compares only that proposal with the fresh unchanged
v3.20 anchor. It may select only the exact anchor or a prediction bound to the
single profile row. It defaults to the anchor unless the anchor is observably one
of the veto categories and the proposal has a literal maturity witness. No
counterfactual fact may be treated as proven merely because it is imaginable.

This is a clean reimplementation from v3.20. No v3.39 or v3.47 prompt, frozen
profile, prediction, candidate, selector, score, validator output, or per-case
artifact enters inference. The rejected versions contribute only the abstract
hypothesis above. Relative working-directory addressing is a transport property,
not a semantic lineage change.

## Falsifiable hypothesis and impact analysis

The v3.47 gate failed because it asked observational artifacts to prove two
counterfactual worlds while simultaneously comparing up to 54 local positives.
Compressing first to one veto-closed boundary should make the 10 high-confidence
recalled-gold errors actionable without exposing the anchor to a free tournament.

Expected gain class: wrong early/late anchors where one profile row already
contains the first mature task-material boundary and the anchor is a reasonable
probe, recovered/noncritical predecessor, faithful propagation, normal failure,
or downstream symptom.

Primary regression risks:

- the compressor may nominate a vivid local error rather than the critical root;
- earliest-positive or later-symptom bias may reappear under different prose;
- a correct capability anchor may be misclassified as a reasonable probe;
- 22 incumbent-correct cases had nonempty v3.47 profiles, so weak veto evidence
  can cause false overrides;
- profile recall still missed 19 v3.47 errors and cannot be repaired by selection.

The hypothesis is falsified if the complete run fails to exceed 25/50, if gains
are offset by anchor losses, or if the compressor recreates candidate flooding.
No result is accepted from candidate oracle, Module, type, or any hybrid of frozen
versions; Step Exact on the single frozen v3.48 predictions is the sole metric.

## Execution and freeze contract

- Seven fresh serial stages per case: unchanged v3.20 anchor, five independent
  module profiles, one compression/duel; maximum four cases concurrently.
- At most one safe retry per stage; retries never change prompt semantics.
- No labels, gold rationales, metrics, scored artifacts, historical predictions,
  error audits, experiment documents, git history, or external resources are
  visible to inference.
- Freeze anchors, ledgers, checkpoints, all five profiles, profile bundles,
  compression/duel records, predictions, audits, hashes, and order before scoring.
- Complete offline schema/taxonomy/evidence/hash/isolation tests, then run full
  GAIA-50 directly with no smoke gate.
- Reject at `<=25/50`; accept as incumbent at `26-29/50`; complete only at
  `>=30/50` after all legality and gold-free checks pass.

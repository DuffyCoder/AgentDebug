# E9 v39 multi-hypothesis causal-ledger selector

## Falsifiable hypothesis

The v38 candidate stage already exposed a step union of 12/30 across its
incumbent, proposal, earlier, and alternate hypotheses, but the final Selector
chose only 9 exact steps and copied the proposal step in 25/30 cases. Requiring
materially different terminal-guard, first-defect, and causal-owner lanes,
followed by a trace-first causal ledger and a separate rebuttal of every
supplied hypothesis, will reduce proposal anchoring and reach at least 12/30
Step Exact on full30 tuning.

The hypothesis is rejected if dry3 fails any 2/3 semantic gate, if full30 has
fewer than 12 exact steps, or if the raw chain or output-validity gates fail.

## Semantic authority

Candidate lanes and the frozen v13 incumbent are untrusted LLM hypotheses.
They contain no gold labels, historical correctness, scores, confidence,
weights, rankings, or votes. The complete anonymous trajectory is the only
evidence. The raw independent Selector response remains the sole source of
critical step, module, error type, evidence source ID, and root cause.

Deterministic code validates only the strict JSON envelope, schema, taxonomy,
step range, source-ID ownership, artifact lineage, and exact logical-call
ledger. It never chooses among hypotheses, mutates semantic fields, or falls
back after a Selector failure.

## Candidate contract

For each case the Candidate performs three independent audits before seeing
the incumbent:

1. terminal guard: determine whether a real boundary owns the failure after
   coherent progress or is defeated by an earlier agent error;
2. first defect: find the earliest important locally demonstrable error,
   excluding hindsight-only improvements and recovered detours;
3. causal owner: trace backward through action, planning, reflection, and
   memory to the output whose one-error correction redirects the branch.

The Candidate preserves the existing strict final tuple, earlier and
alternate steps, and compact causal basis. The basis must name the step,
taxonomy pair, source ID, recovery status, and counterfactual for each lane.
This enriches alternatives without making them final semantics.

## Selector contract

Before comparing supplied hypotheses, the Selector reconstructs a trajectory-
only ledger with the final outcome, owner dependency chain, recoveries, and
one-error counterfactual. It then rebuts incumbent, proposal, earlier, and
alternate separately as an introducing owner, downstream symptom, recovered
detour, unsupported speculation, or surviving competitor. A bare
`accept_proposed` verdict is explicitly insufficient.

The final compact `causal_basis` records the outcome, owner chain, four
rebuttals, and counterfactual. The Selector may still select any supplied step
or a fresh step, but it must derive the final tuple directly from the timeline.

## Frozen topology

v38 consumed cumulative logical completions 485 through 507: two for its
accepted dry3 and twenty for its rejected full30. v39 uses the unchanged
two-live-stage tuning and four-live-stage held-out topology:

- dry3: 507 to 509, exactly two new logical completions;
- full30 after accepted dry3: 509 to 529, exactly twenty new completions;
- held-out smoke after accepted full30: 529 to 573, exactly forty-four new
  completions.

The full30 first batch must reuse the exact accepted dry Candidate and
Selector records. Held-out smoke must freshly execute Scout, Arbiter,
Candidate, and Selector for all eleven batches. No global authorization cap
is applied; every phase still has its topology-derived durable hard stop.

Any failed provider or benchmark attempt requires a completed case study and
an explicit optimization direction before another external call.

# E9 v43 dry3 failure case study

## Outcome

v43 completed its frozen dry3 run with three valid raw diagnoses, but missed
the preregistered 2/3 promotion threshold:

- Step Exact: 1/3;
- Step+Module Exact: 1/3;
- All Correct: 1/3;
- successful outputs: 3/3;
- failed outputs: 0/3;
- logical completions: exactly 2;
- HTTP attempts: exactly 2, with zero retries;
- provider tokens: 381,043 input, 30,328 output, 411,371 total.

The rejected promotion is bound by
`1d25d576d79f9181744fad46b3b8d1aa70f82b0ff0f81197acb5a9901896e256`.
v43 must not advance to full30 or held-out smoke.

## Case study

### C01: an uncertain alternative search path displaced the real boundary

The released root is step 30 `system/step_limit`. The frozen anonymous prior
contains that exact tuple. The three new lanes emit step 8
`planning/inefficient_plan` and twice emit step 16
`memory/memory_retrieval_failure`. The raw Selector adopts step 16.

The local observation is real: step 15 mentions drawers and countertops,
while the next memory returns to the cabinet sweep. The causal claim is not
established, however. Correcting that memory only redirects the agent to a
different unvisited receptacle whose result is unknown. It does not establish
that the ladle is found, cleaned, and placed before the limit. The agent is
still taking feasible novel search actions at step 30. v43 incorrectly treats
"cuts this observed branch" as equivalent to "prevents the observed task
failure", allowing a plausible alternative search to defeat the enforced
boundary.

This is a selection failure, not a recall failure: the correct boundary is
already H01.

### C02: capability-root preservation succeeds

The released root is step 1 `action/misalignment`, and both the frozen prior
and the `first_defect` lane contain that tuple. The `branch_commitment` lane
also supplies the downstream step 4 `planning/constraint_ignorance`
alternative. The raw Selector correctly retains step 1.

Its reason is appropriately causal rather than positional: extracting text
from a dynamic GitHub search page cannot supply the ordered, filtered issue
membership and history explicitly required by the task, and later outputs
never reacquire those data. This is the v43 hypothesis's positive case.

### C03: the lanes stop at the start of a repeated search epoch

The released root is step 13 `planning/inefficient_plan`. v43 emits step 6
`planning/inefficient_plan` and step 8 `action/parameter_error`; the raw
Selector adopts step 8. The trace does show that step 8 launches a nearly
identical query after returning from six unhelpful pages, but that action is
syntactically valid and faithfully realizes the current plan. The benchmark
localizes the critical error later, after the renewed result epoch has again
accumulated repeated no-progress and the plan still continues pagination.

The `branch_commitment` instruction therefore fires too early. It equates
entering a recoverable repeated epoch with the later point where accumulated
evidence makes continuing that epoch the unrecovered task-failing strategy.
It also shifts ownership from the strategy-forming plan to the valid concrete
search operation.

This is both a candidate-recall and final-selection failure: no v43
hypothesis contains step 13.

## Attribution

There were no provider, retry, JSON, taxonomy, evidence ownership, step/event
mapping, response-length, or output-validation failures. No deterministic
semantic mutation, confidence, score, weight, or fallback participated. The
failure is entirely in raw LLM causal judgment.

The dry result supports one part of the v43 hypothesis and rejects two parts:

1. Symmetric lanes recover the action-capability root in C02 and let the
   Selector reject its downstream symptom.
2. `CAUSAL_SUFFICIENCY` remains underspecified for open-world search. Merely
   choosing a different unknown target can change the branch without making
   success materially established, so it should not defeat a real
   `step_limit` boundary.
3. `branch_commitment` is underspecified across repeated-result epochs. It
   selects the query/reset that begins an epoch rather than the later planning
   checkpoint where accumulated no-progress makes continuing the epoch the
   critical failure.

## v44 falsifiable direction

v44 will make one attributable semantic change: replace branch-cutting
sufficiency with **failure-preventing causal sufficiency** in both the lane
generator and final Selector.

- `terminal_guard` must preserve an observed external boundary as its own
  complete alternative; it may not replace the boundary with an earlier
  challenger inside that lane.
- An earlier search/memory/strategy hypothesis defeats a real step limit only
  when correcting that one output fixes an invalid operation or explicit
  constraint, reaches evidence already shown to be task-satisfying, or
  otherwise prevents the failure independently. Redirecting exploration to
  another feasible target with an unknown result is not enough.
- For repeated search epochs, a valid query/reset is not automatically an
  action parameter error. The branch lane must inspect the later planning
  checkpoints after multiple same-epoch no-progress observations and choose
  the point where continuing the known-unproductive strategy becomes the
  unrecovered commitment. Ownership remains with planning when the concrete
  action validly implements that strategy.

The candidate and Selector remain two raw LLM calls. The frozen prior and all
lane outputs remain anonymous and unscored; the Selector may reject all of
them and is still the sole source of final step, module, and error type. No
case ID, environment, released label, deterministic root rule, vote, score,
confidence, priority, or semantic repair is introduced.

The hypothesis is accepted only if v44 reaches at least 2/3 on every dry
gate and then at least 12/30 Step Exact on full tuning. Any failure requires a
new case study before another provider call.

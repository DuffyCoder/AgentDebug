# E9-v56 local fixture failure case study

## Attempt

Six targeted tests were run for the conservative v30 incumbent reviewer.

## Failure

All six failed before entering prompt construction or parsing. The fixture
passed an in-memory dictionary to `adapt_trajectory`, which called
`Path(dictionary)` and raised `TypeError`.

## Root cause

The repository adapter's public contract accepts a trajectory file path, not
an already-decoded dictionary. The new tests used the wrong API shape. This is
a test-fixture construction error; it provides no evidence against the v56
prompt or parser.

## Correction

Build the same two-step trajectory as the repository's other judge tests do:
write a temporary OpenClaw-style `messages` JSON file, pass its path and an
explicit trajectory ID to `adapt_trajectory`, then build a judge view and
batched case. Re-run only the targeted reviewer tests.

## Attempt 2

The path-based fixture then reached `build_batched_case`, but supplied its two
arguments positionally. All six tests again stopped in the shared fixture with
`TypeError: build_batched_case() takes 0 positional arguments but 2 were
given`.

This helper deliberately exposes a keyword-only contract, as shown throughout
the existing causal/critic tests. The correction is purely mechanical:
`build_batched_case(case_key="C01", view=...)`. No reviewer prompt or parser
change is justified by this second setup-only failure.

# E9 v55 local failure case study 02

## Failed attempt

The first workflow test run produced 3 passes and 1 failure.  Prediction made
exactly one fake provider call and wrote all raw-first artifacts successfully.
Scoring stopped inside the pre-gold validator with `AttributeError` while
checking the stage dependency digest.

## Attribution

`StageRequest` exposes `stage`, `request_sha256`, `prompt_sha256`, and
`identity`.  `dependency_sha256` is deliberately embedded in the immutable
identity mapping; it is not a direct dataclass attribute.  The new validator
read the wrong level of the established cache contract.

## Correction

Compare the persisted digest against
`request.identity["dependency_sha256"]`.  Retain the fail-closed validation
order: run hash, file hashes, ledger, row hash, request identity, raw semantic
reconstruction, then and only then benchmark labels.

No external LLM request was made.

# E9-v20 Minimal-Final Pro Critic

E9-v20 implements the bounded hypothesis from the mandatory E9-v19 case
study.  It retains `deepseek-v4-pro`, the default request body, complete
gold-free canonical trajectories, frozen v13 priors, strict evidence binding,
and raw LLM output as the sole source of final semantics.

The response protocol is reduced from a five-lane audit to:

- one `review.incumbent_verdict` (`keep`, `replace`, or `no_incumbent`);
- one short `review.causal_basis`; and
- the final step, atomic taxonomy pair, exact evidence quote, and root cause.

Only the final quote is validated against trajectory evidence.  No
analysis-only candidate is deterministically promoted, repaired, scored, or
allowed to invalidate another case.

The prompt distinguishes interface-state change from task progress.  A new
page is progress only if it adds evidence relevant to an unmet constraint;
repeated no-match pages after recognized stagnation form an inefficient plan.
A deliberate query reset can recover the earlier loop, after which a new
repetition must be localized within the new episode.  Literal plan/action
agreement does not rescue an action aimed at a representation that cannot
expose the required item-level or historical information.

The preregistered dry3 gate requires all three outputs valid and at least 2/3
Step, Step+Module, and All Correct.  The budget is one logical completion,
from cumulative 368 to 369.  A passing dry may proceed to full30 from 369 to
379 under the current 380 authorization.  A future fresh smoke would require
33 calls from 379 to 412 and therefore needs additional user authorization.

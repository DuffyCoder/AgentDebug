# Luna GAIA v3.58 preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.58-clean-v3.20-step-isolated-module-reservoir-pairwise-observed-continuation-reducer`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: Luna v3.20, Step Exact `25/50`
- Original v3.4 baseline: Step Exact `21/50`
- Version acceptance: Step Exact `> 25/50`
- Goal completion: Step Exact `>= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the sole optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module, type, and evidence remain legality constraints
only.

## Clean-parent boundary

v3.58 is a direct semantic child of accepted v3.20. The v3.20 packet-state
anchor is rerun in fresh sessions and is neither read from the incumbent run
nor composed with an old prediction. No v3.21--v3.57 prompt, selector,
challenger, ledger, validator output, prediction, score, or runtime artifact is
an inference input or semantic parent.

The post-score audits of rejected versions supply only the falsifiable
hypothesis. The Step-local matrix, bounded module reservoir, isolated pair
assessment, and mechanical reduction below are implemented and rerun as one
integrated local-to-global mechanism on a clean v3.20 branch. They do not import
or reuse v3.57 inference artifacts.

## Single major mechanism

Add one integrated Step-isolated module-reservoir pairwise
observed-continuation reducer:

1. One fresh prefix-bounded session inventories literal taxonomy-valid local
   errors for each owner at every observable Step. It cannot see the anchor,
   later Steps, scores, gold, or prior predictions.
2. Admission is deterministic and bounded: export exactly the earliest local
   positive for each represented Module in canonical order, at most five.
3. Compare the immutable fresh v3.20 anchor with each representative in
   isolation. When the representative is later, close the anchor as a
   non-error while preserving the actual action and feedback. Do not invent a
   better route whose hypothetical effects erase the observed continuation.
4. Each pair must record the pre-candidate observation, the same global anchor
   class, observed-continuation anchor closure, anchor-only repair,
   representative-only repair, winner relation, and a falsifier.
5. A representative is eligible to win only when it is `critical_root` and
   the anchor is consistently classified as one enumerated noncritical veto
   class. `uncertain`, ties, and inconsistent assessments keep the anchor.
6. The validator mechanically keeps the anchor when no eligible pair wins;
   otherwise it selects the chronologically earliest eligible winner, with a
   same-Step canonical-Module tiebreak. The final prediction must be an exact
   anchor or representative copy.

This pairwise observed-continuation critical-boundary reduction is the sole
major mechanism. v3.57's free all-candidate final selection, its generated
choice ordering, and all other rejected-lineage changes are removed rather
than inherited.

## Post-score hypothesis and impact analysis

v3.57 froze Step Exact `20/50`, so it remains rejected. Among its 30 Step
errors, the first-divergence distribution was 25 `anchor_error`, four
`annotation_ambiguity`, and one `false_challenger_override`. Its complete local
matrix contained the released gold Step in `35/50`; the fresh anchor plus any
local positive had an oracle ceiling of `41/50`. The bounded earliest-per-Module
reservoir contained gold in `22/50`, while fresh anchor plus reservoir had an
oracle ceiling of `31/50`.

The most direct selection cluster contains nine errors where the released gold
Step was already a representative but the selector did not choose it. Six
were called downstream symptoms and the remainder were split across normal
tool failure, noncritical predecessor, and faithful propagation; seven of
these selections were early relative to gold. This supports the falsifiable
hypothesis that a global causal anchor prior is using hypothetical upstream
repair to erase literal later defects.

Expected gains are concentrated in that common nine-case selection cluster.
The strongest regression evidence is v3.57's one false override of a correct
fresh anchor and the rejected provenance-blind v3.44 tournament's low Step
Exact. The change can move choices later when a later candidate remains
independently invalid on the observed continuation, or earlier only when an
earlier candidate has a decisive one-sided repair effect. It cannot increase
the reservoir beyond five, but it can still amplify local false positives,
Planning salience, and overconfident anchor veto classifications.

The controls are pair isolation, identical anchor classification across every
pair, explicit two-sided repair fields, an enumerated representative-win gate,
deterministic earliest-winner reduction, and default keep. This is a uniform
mechanism, not case-specific routing: no trajectory ID, entity, source, site,
released Step, or gold rationale appears in any inference rule.

## Falsifiers

- any inference source reads labels, scores, old predictions, error audits,
  experiment documents, case routes, git history, or external resources;
- the semantic parent is not clean v3.20 or a rejected artifact enters
  inference;
- local coverage is not exactly `717/717` or the full run is not `50/50`;
- representatives are omitted, substituted, invented, or exceed five;
- pairwise anchor classifications drift, or an ineligible representative is
  allowed to win;
- final reduction differs from the deterministic earliest eligible winner;
- any final prediction is not an exact anchor/representative copy;
- final Step Exact is `<= 25/50`.

Only Step Exact controls version acceptance. Only a frozen legal Step Exact
`>= 30/50` can complete the Goal.

## Execution topology and pre-inference validation

- 50 fresh v3.20 anchors + 717 fresh Step-local sessions + 50 fresh pairwise
  reducers = exactly `817` planned successful model stages.
- Fresh one-case sessions, maximum concurrency `4`, maximum two attempts per
  stage, and no smoke gate.
- Focused v3.58 plus cross-version v3.20/v3.57 tests: `28 passed`.
- Full-cohort dry-run: 50 cases, 717 legal Steps, 817 planned stages.
- Static inference-source scan: no case ID/entity route, score/gold reader,
  rejected-version import, old prediction, or git-history input.

## Pre-inference source hashes

- Protocol SHA-256: `4c5a08d033675e1d3baaa3f7beaab62a58682bb33f50371713d9f0220082af96`
- Runner SHA-256: `50bb616f4899519f5208975ead3694684930c7ae95b21bee566fe9eca4dba1fd`
- Registry SHA-256: `37da7d3e55aa2e7eb35369372fc075f9d722679de65ff41e534636380ac1a4d5`
- Taxonomy SHA-256: `d7e4b878059bbecec0a8fd3f078c0aeb5755bf9e65bb938c897dd83685f28c5c`
- Focused-test SHA-256: `db2ed3af22fdd6f6e9c0f804b0516ddaf3fc483da1970a1a744e76810d1d2e22`

## Frozen runtime outcome

- All `717/717` Step-local stages completed, and 49/50 cases completed every
  legal stage.
- One pairwise reducer case exhausted both authorized attempts. Attempt one
  transcribed the frozen ledger hash with one misplaced character; attempt two
  omitted `trajectory_sha256` from the duplicated selected anchor prediction.
- The final error was `invalid_embedded_prediction_fields`. No aggregate was
  frozen and no scoring was performed.
- v3.58 is `invalid_unscored`, cannot be accepted, and v3.20 remains the
  accepted incumbent at `25/50`.
- The first divergence is high-confidence `runtime_or_validation_failure`.
  The minimal uniform correction is deterministic assembly of every immutable
  identity/hash/representative/prediction/reducer field, leaving the model to
  emit only ordered pairwise semantic assessments.

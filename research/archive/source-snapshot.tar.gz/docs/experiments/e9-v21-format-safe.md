# E9-v21 Flash Format-Safe Critic

E9-v21 pauses semantic tuning to address the two observed output-conformance
families.  It returns to the user-preferred `deepseek-v4-flash` model and
keeps the default HTTP body (`model` and `messages` only).

The format boundary is deliberately narrow and raw-preserving:

1. The raw provider string is always stored unchanged.  If strict parsing
   fails and the response has exactly the observed Flash suffix `}}]}`, the
   parser may remove only the single unmatched object-close immediately before
   the cases-array close.  The candidate must then parse as one strict JSON
   object with no duplicate fields.  No other JSON repair is allowed.
2. The LLM no longer transcribes `evidence_quote`.  Each case includes an
   opaque catalog of existing evidence source IDs with step, module, and an
   exact preview.  The LLM selects one ID.  The validator requires that ID to
   belong to the selected step/module and projects its already-stored verbatim
   preview into the report.  This prevents quote-character normalization such
   as `"Aug 8, 2017"` becoming `'Aug 8, 2017'`.

Neither mechanism chooses a root step, module, error type, or cause.  The LLM
still supplies all root semantics; deterministic code only restores JSON
structure in the one proven case and dereferences the LLM-selected evidence
source.  Repairs are recorded in `critic_audit.format_repairs`, and the raw
response remains available for independent validation.

The next dry3 attempt uses one logical completion, cumulative 369 to 370.  A
passing result can run full30 from 370 to the current authorized ceiling 380.
A future fresh smoke would require 33 calls from 380 to 413 and is not
authorized.

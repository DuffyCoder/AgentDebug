# E9 v36 dry3 invocation failure case study

## Outcome

The first v36 `predict` invocation failed closed before provider construction.
It consumed zero logical completions and made zero HTTP attempts. This was a
local CLI selection error, not an LLM, transport, output-format, or semantic
failure.

## Evidence

- The preregistered dry3 selection contains exactly three frozen trajectory
  IDs and has logical-completion interval 481 through 483.
- The durable ledger still has zero entries after the failed invocation.
- No v36 Critic or Selector cache artifact was created.
- Re-running the complete preregistration verifier locally with the same three
  frozen IDs succeeds.

## Root cause

The `predict` invocation omitted the three repeated `--trajectory-id`
arguments. For this CLI, an omitted selection means all 30 trajectories in
the prediction manifest, rather than the three trajectories in the dry batch
plan. The runtime selection therefore differed from the immutable
preregistration and was correctly rejected before reading the API key or
constructing the provider.

## Corrective action

Repeat the unchanged preregistered invocation with the exact three frozen IDs
in manifest order. Do not change prompts, code, cache, budget, cohort, or
provider configuration. Because no logical completion was reserved or sent,
the original 481 through 483 ledger remains authoritative.

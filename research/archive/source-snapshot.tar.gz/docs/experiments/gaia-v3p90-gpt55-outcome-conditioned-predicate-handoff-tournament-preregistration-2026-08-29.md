# GAIA v3.90 GPT-5.5 outcome-conditioned predicate-handoff tournament preregistration

Date: 2026-08-29

## Frozen identity

- Version: `agentdebug.codex-agent-judge.gaia-v3.90-gpt55-outcome-conditioned-predicate-handoff-tournament`.
- Direct semantic parent: accepted v3.83, Step Exact `26/50`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Dataset manifest identity SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort identity SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Cohort manifest file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Frozen v3.83 protocol SHA-256: `a97908a78cec8df5fe9e4777d30aa9ecf498d1cdd1d692a42cc66976e9844531`.
- Frozen v3.83 predictions SHA-256: `f74161b06c456461ccacdcf7c708157154e8e9810cb5dffa8ef09352698fca3d`.
- Model and reasoning effort: `gpt-5.5` / `medium` for both fresh stages.

## Prior evidence and first-divergence motivation

Rejected v3.87-v3.89 repaired zero frozen v3.83 errors through their direct
mechanism effects. Same-model lifecycle and influence-graph challengers did not
recall useful alternatives; the Sol challenger proposed one exact Step, but its
only accepted direct repair corrected fresh-anchor sampling drift on a case
already correct in frozen v3.83. The repeated failure is therefore not merely
arbiter conservatism: the one-proposal challenger topology does not expose
enough benchmark-correct alternative Steps.

Historical v3.80 is the only tested mechanism whose frozen native-ledger
candidate set had a Step oracle above the Goal threshold: anchor plus reviewed
ledger Steps covered `31/50`. Its Luna selector nevertheless scored only
`17/50`, with four direct gains and nine direct losses, so the candidate source
was sufficient while selection precision was not. This result is diagnostic
evidence for a clean mechanism retest, not a parent or inference input.

## Single major change

Keep the accepted v3.83 GPT-5.5 packet-state anchor and its native chronological
ledger semantics. Replace the v3.83 one-proposal challenger plus default-keep
arbiter tail with exactly one outcome-conditioned predicate-handoff tournament:

- review every native ledger Step from the fresh anchor through the anchor Step;
- judge the actual observable outcome and subsequent resolution of the exact
  task predicate;
- select exactly one winner, either the anchor or a strict prefix;
- permit only `unresolved_predicate_handoff` or `concrete_local_defect` winners;
- deterministically copy the model-selected winner into the frozen prediction;
- allow only same-Step deterministic Module/type/evidence legality repair.

The tournament prompt, response schema, winner constraints, and selector are a
clean port of the v3.80 mechanism. v3.80's Luna model, version identity, parent
metadata, predictions, and all other rejected-lineage changes are not inherited.
The direct semantic parent is v3.83.

## Falsifiable hypothesis and impact analysis

GPT-5.5 may exploit the complete ledger tournament more precisely than the
historical Luna executor, converting the demonstrated high candidate recall
into at least one net gain over v3.83. The mechanism targets incumbent errors
where the gold Step is already an anchor-prefix ledger Step but was never
surfaced by the bounded challenger.

The principal regression risk is systematic early movement: a reasonable
initial acquisition probe may be misclassified as a mature unresolved-predicate
handoff merely because later Steps continue the same evidence gap. Additional
risks are early-freeze bias and selecting a locally real but noncritical
predecessor. The complete-ledger review can also increase cognitive load, but it
cannot create out-of-ledger candidates or select a Step later than the anchor.

The mechanism is falsified if final Step Exact is `<=26/50`, if gains on frozen
v3.83 errors are offset by early-probe regressions, if the fresh candidate oracle
does not remain high, or if any legality check fails. Candidate oracle and
mechanism-direct transitions are post-score diagnostics only and do not select
the version.

## Acceptance and Goal completion

- Accept only if Step Exact is strictly greater than `26/50` and every legality check passes.
- Complete the Goal only if Step Exact is at least `30/50` and every legality check passes.
- Only Step Exact selects, accepts, rejects, or completes versions.
- No smoke gate is used; after offline validation run the complete GAIA-50 directly.

## Pre-inference freeze

- Protocol source SHA-256: `da6a03982443bec969f9a70fbeeb8248070d76cef696c47e944d028a50858b81`.
- Runner source SHA-256: `f9c91230d1a604ccaab74bc086bd89ba74c6f15534ee6893ed7b45e2f660127e`.
- Negative/identity test source SHA-256: `6f3adefb4780f0d8bfccba79401b443ccb5891273881c42b1d68b471811785e9`.
- Frozen tuning plan SHA-256: `dec577592d6053c909bcf37ce1cc5c41f7123f24d23220aa48b56cfc2ce42ddd`.
- Offline validation: compilation passed; 12 targeted and inherited tests passed; registry,
  v3.83 direct-parent identity, task-equivalence normalization, truthful GPT-5.5
  provenance, Step-invariant legality repair, and 50-case dry preparation passed.
- Static inference-source scan found no labels, metrics, scored artifacts,
  historical predictions, case/entity router, or post-score audit reader.

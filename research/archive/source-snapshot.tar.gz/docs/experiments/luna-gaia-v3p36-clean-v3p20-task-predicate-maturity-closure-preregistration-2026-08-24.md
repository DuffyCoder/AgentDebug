# Luna GAIA v3.36 Clean v3.20 Task-Predicate Maturity Closure Preregistration

## Frozen identity and decision rule

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.36-clean-v3.20-task-predicate-maturity-closure`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Single major change: one task-predicate maturity-closure challenger that
  requires every alternative boundary to bind an Agent-owned commitment, its
  immediate task predicate, and one literal maturity witness.
- Accepted incumbent: Luna v3.20, Step Exact `25/50`.
- Version acceptance: Step Exact `>25/50`.
- Goal completion: Step Exact `>=30/50` plus every legality check.
- Original frozen baseline: Luna v3.4, Step Exact `21/50`.
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases.
- Dataset manifest SHA-256:
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort semantic SHA-256:
  `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Cohort file SHA-256:
  `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Prediction-manifest file SHA-256:
  `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Model / reasoning effort: `gpt-5.6-luna` / `medium`.
- No smoke gate; after offline validation run the complete GAIA-50 directly.

Step Exact is the only optimization, comparison, acceptance, rejection, and
completion metric. Module, type, and literal evidence remain output-legality
constraints only.

## Frozen v3.35 evidence and first divergence

Frozen v3.35 completed 50/50 with 151 stage attempts, one recovered retry, all
legality checks, and Step Exact `22/50`; it is rejected and immutable. Relative
to v3.20 it had two gains and five losses, net `-3`. Its fresh clean-v3.20
anchor scored `21/50`. Six challenger Step changes produced two direct gains,
one direct regression, and three wrong-to-wrong moves.

All 28 errors are audited in frozen post-score artifacts. First-divergence
distribution:

- false candidate admission: 11;
- annotation ambiguity: 5;
- candidate recall failure: 4;
- early freeze failure: 4;
- challenger recall failure: 2;
- false challenger override: 1;
- late symptom preference: 1.

The new current-stage evidence exposes one shared closure failure with three
observable manifestations:

1. A later repeated route is selected using an earlier same-route Step as its
   maturity witness even though that earlier Step was just rejected without a
   prefix maturity check.
2. A raw normal tool rejection is frozen before the first Agent-owned
   post-outcome plan/reflection that chooses what to do with the failure.
3. Successful transport or returned static text is treated as proof that an
   interface can expose the immediate task-required predicate, even when the
   returned content lacks that predicate and a later symptom follows from the
   acquisition choice.

These are all failures to close the relation among decision owner, immediate
task predicate, and literal maturity witness. This supports one uniform
mechanism; it does not support inheriting v3.35 or any other rejected lineage.

## Single uniform mechanism

The v3.20 packet-state anchor prompt, ledger, Step freeze, model, reasoning
effort, schemas, one-proposal limit, exact-copy arbiter, and default-keep
behavior remain unchanged. The complete challenger judgment is replaced by
one clean task-predicate maturity closure:

1. Scan the full trace in chronological order and close each plausible
   boundary as a tuple of Agent-owned commitment, immediate unresolved task
   predicate, and literal maturity witness.
2. A proposal must use exactly one witness class:
   `intrinsic_predicate_incapability`, `post_feedback_recommitment`,
   `state_handoff_contradiction`, or `execution_impact`.
3. Raw tool/site outcomes cannot own a proposed boundary. Execution impact is
   owned by the Agent Step only when its plan, Action, or parameter choice is
   literally rejected or contradicted and remains unrecovered.
4. Acquisition transport success is not capability proof by itself. Intrinsic
   incapability requires literal evidence that the named interface cannot
   expose the plan's immediate required content/state and that the returned
   content lacks it. A route that can still contribute an identifier, source,
   page, text, or lead remains a reasonable probe.
5. Repetition maturity requires negative feedback followed by an Agent-owned
   recommitment to the same normalized target, corpus, interface, and
   extraction route with no material change. It is prefix-closed: if a later
   repeated Step cites an earlier same-route Step, test the earlier Step first.
6. State/handoff maturity requires a literal necessary-fact loss, unsupported
   retained fact, false outcome/progress reading, or plan-to-Action target loss
   that changes the next decision.
7. Compare the frozen v3.20 anchor with the earliest surviving closed boundary.
   Emit at most one complete legal prediction. The arbiter may only keep the
   exact anchor or accept the exact proposal and defaults to anchor under
   uncertainty.

This is a clean v3.20 branch. No v3.21-v3.35 prompt, prediction, challenger,
ledger, scored artifact, case ID, entity, or result is a runtime input. Generic
three-stage schema transport is structural only; its rejected semantic rule is
replaced in full.

## Falsifiable gains and regression risks

The v3.35 frozen audit predicts four direct repair opportunities under the
closed tuple: one non-prefix repetition, one raw normal-failure freeze, one
correct anchor incorrectly displaced after static-interface misclassification,
and one skipped later interface-capability commitment. IDs remain only in
post-score analysis and do not enter prompts, validators, manifests, or case
routing.

The main regression risks are incumbent-correct acquisition cases in which a
static or indirect interface can still supply a useful lead, and correct early
execution-impact anchors followed by more explicit downstream symptoms. The
controls are literal predicate binding, Agent ownership, probe contribution,
prefix-closed chronology, recovery veto, one witness per proposal, one proposal
maximum, exact-copy validation, and default keep.

The hypothesis is falsified if a proposal lacks a bound task predicate or
literal witness, if a normal tool outcome owns the proposed boundary, if
repetition selection is not prefix-closed, if legality fails, or if complete
GAIA-50 Step Exact is `<=25/50`.

## Execution and freeze contract

1. Implement only the versioned task-predicate maturity-closure challenger,
   its validator/audit contract, runner registration, and negative tests over
   frozen v3.20.
2. Verify the anchor task is text-identical to v3.20 modulo version identity;
   no rejected semantic rule or runtime artifact is inherited.
3. Use three fresh serial sessions per case: unchanged v3.20 anchor, one
   maturity-closure challenger, and default-keep exact-copy arbiter; at most
   four cases run concurrently.
4. Run no smoke gate. Execute all 50 cases after prepare-only validation.
5. Freeze and validate hashes, schema, taxonomy, evidence, order, Step range,
   witness contract, one-proposal limit, exact copies, no routing, and no
   prior-prediction/gold access before scoring.
6. Score all 50 and compute Step transitions relative to frozen v3.20 and v3.4.
7. Reject immutably at `<=25/50`; accept as new incumbent at `26-29/50`;
   complete the Goal only at `>=30/50` after every legality check passes.

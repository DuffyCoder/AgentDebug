# GAIA v3.99 GPT-5.5 CWD-robust access tournament preregistration

Date: 2026-08-30

## Frozen identity

- Version: `agentdebug.codex-agent-judge.gaia-v3.99-gpt55-cwd-robust-access-audited-predicate-handoff-tournament`.
- Direct semantic parent: accepted v3.83, Step Exact `26/50`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Dataset identity SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort identity SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Cohort manifest file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Frozen v3.83 protocol SHA-256: `a97908a78cec8df5fe9e4777d30aa9ecf498d1cdd1d692a42cc66976e9844531`.
- Model/reasoning effort: `gpt-5.5` / `medium` in both stages.

## Single semantic mechanism

Relative to accepted v3.83, the only semantic change remains one outcome-
conditioned predicate-handoff tournament over every native Step in the fresh
v3.83 ledger, replacing the incumbent challenger/arbiter. Anchor semantics,
candidate admission, model, effort, evidence ownership, taxonomy legality,
singleton keep, and exact-copy freeze are unchanged. Rejected predictions and
per-case routing data are unavailable to inference.

The falsifiable semantic hypothesis remains that the global tournament recovers
incumbent-error boundaries already admitted to the ledger with positive Step
Exact net gain.

## Runtime-only correction

- Every prompt command is bound to the current attempt's absolute inspector
  path; the inspector resolves its sole staged document beside its own file.
- The post-inference audit requires the exact command path to equal that
  attempt's inspector path. A different attempt or external path is fatal.
- Chunk `K` remains one-based; `K=0` is a deterministic alias for chunk 1.
- Feedback chunks are split by JSON-encoded output cost with a raw-character
  cap. Bounded exact ASCII-printable runs plus exact head/tail text are exposed
  in the feedback overview; exact chunks remain available on demand.
- Anchor still requires task plus every original Step; reducer requires task
  plus every native-ledger candidate Step. Whole-Step reads, missing coverage,
  failed/incomplete calls, mutation, shell composition, general Python, or
  nonallowlisted tools remain fatal.

None of these rules adds, removes, orders, ranks, or selects a Step.

## Gains and regression risks

- Expected semantic gains: incumbent errors whose gold boundary is already in
  the fresh ledger but absent from the incumbent challenger.
- Main semantic regression: false promotion of reasonable early probes.
- Transport regression risk: printable-run extraction could focus attention on
  human-readable fragments; exact raw chunks remain available as a countercheck.
- Candidate flood risk: none.

## Decision rules

- No smoke gate; run complete GAIA-50 after offline validation.
- Freeze all predictions and intermediate/access/legal artifacts before labels.
- Reject on any incomplete/illegal run or Step Exact `<=26/50`.
- Accept only if Step Exact `>26/50`; complete Goal only at `>=30/50`.
- Step Exact is the sole selection metric.

## Pre-inference freeze

- Protocol SHA-256: `e784b7469a19d662dacad40b42189ac70a768d46d28102d2e76336b0c2bc16d2`.
- Runner SHA-256: `44d250fbc9002ddf0da2105be3425fbc0dd884138d99407cceac18e42a209b28`.
- Inspector SHA-256: `605b1473ff18fe0c7ddadf8f47074e23c689f4328137be297c86c75141a97160`.
- Targeted test SHA-256: `e2052986968521478099256c61f810041418f0a5aed371a7b3ca589b0c4053c0`.
- Registry SHA-256: `a0ac5610107ff23a5eabc6ae5026b607b1dca871f1e786ebe087e13e24cf20b3`.
- Offline validation: compilation and 50-case dry preparation passed; 32
  targeted/inherited tests passed, including absolute attempt binding, wrong-CWD
  execution, zero-index alias, encoded-output bounds, stage-specific coverage,
  strict parser rejection, direct parent, thresholds, registry, and static
  gold/router scans.

This pre-inference identity is frozen and immutable.

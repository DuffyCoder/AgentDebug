# GAIA v3.105 v3.83 Sophnet Chat Completions transport preregistration

Date: 2026-08-31

Status: preregistered and unscored. No GAIA-50 inference result is claimed by
this document.

## Endpoint classification

The supplied URL is `https://api.sophnet.com/v1/chat/completions`. Its path is
the Chat Completions wire protocol, not the OpenAI Responses API
`POST /v1/responses`. Therefore v3.105 accurately records its wire API as
`chat_completions`. In this experiment, "response-only" describes the model's
I/O capability: the model receives a stateless prompt and returns a strict
stage envelope without filesystem or tool access. It does not relabel the HTTP
endpoint as a Responses API endpoint.

## Frozen identity

- Version:
  `agentdebug.codex-agent-judge.gaia-v3.105-v3p83-sophnet-chat-completions-transport-gpt55-medium`.
- Direct semantic parent: accepted v3.83,
  `agentdebug.codex-agent-judge.gaia-v3.83-clean-v3.20-model-only-gpt55-medium`,
  Step Exact `26/50`.
- Semantic protocol: `gaia-v3.83-clean-v3.20-model-only-gpt55-medium`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Dataset identity SHA-256:
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort file SHA-256:
  `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Cohort identity SHA-256:
  `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction-manifest file SHA-256:
  `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Prediction-manifest identity SHA-256:
  `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`.
- Frozen v3.83 protocol source SHA-256:
  `a97908a78cec8df5fe9e4777d30aa9ecf498d1cdd1d692a42cc66976e9844531`.
- Frozen v3.83 wrapper-runner source SHA-256:
  `a1613a04ad21b3306c61cd3082753ff5890ad09ab3d939f4c292c15e1dac483d`.
- Model: `gpt-5.5`.
- Reasoning effort: `medium`.

## Single major change

Change only the per-stage execution transport from the v3.83 filesystem agent
to one stateless, response-only Sophnet Chat Completions request. The host
virtualizes only the filesystem operations that the direct API cannot perform:
permitted input reads, write-once stage artifact materialization, and local
validator execution. The complete original v3.83 task is retained inside the
adapter as the semantic contract.

The packet-state anchor, earliest-causal challenger, default-keep arbiter,
schemas, taxonomy, evidence rules, stage order, case order, concurrency,
semantic retry bound, gold-free boundary, and freeze-before-score sequence
remain unchanged. No prompt, prediction, or mechanism from rejected
post-v3.83 lineages is inherited.

## Frozen response-only I/O virtualization

For each stage the adapter supplies exactly:

1. the complete original v3.83 stage task;
2. one deterministic, gold-free, deduplicated JudgeView for that case;
3. the frozen one-case cohort identity for validation only; and
4. only the exact upstream v3.83 stage artifacts permitted for that stage.

The projection removes only reconstructible cumulative wrapper history or an
exact repeated prefix. It retains assistant source text, module spans, tool
calls and results, adjacent feedback, event identities, trajectory identity,
and source hashes. No label, rationale, metric, historical prediction, or
error analysis is present.

The model has no tools, path access, or cross-request state. It must return one
strict JSON object with the frozen stage envelope and no markdown. The host
materializes envelope values without semantic normalization or repair, then
runs the original v3.83 validator. Invalid JSON, duplicate keys, wrong field
order, wrong model resolution, truncation, missing artifacts, or validator
failure consumes a semantic attempt; it is never repaired into a prediction.

## Frozen HTTP contract and credential boundary

- Endpoint: `POST https://api.sophnet.com/v1/chat/completions`.
- Additive requirements SHA-256:
  `f78c35e99b400eb802979d7756321dedcd09bc8c7c13756defccf737ddede9c5`.
- Frozen parent `uv.lock` SHA-256:
  `ac122fd9a87762dd20f491df918f8431907c5fe890dfcfc3a895e3e43f0569a2`.
- Wire API: `chat_completions`.
- Request model: `gpt-5.5`; a response whose resolved model is not exactly
  `gpt-5.5` fails closed.
- Request reasoning effort: `medium`.
- Request body: one system message and one user message; the authorization
  value is never part of the body.
- Credential source: the process environment variable `SOPHNET_API_KEY` only.
  The value must not appear in a CLI argument, repository file, prompt,
  stdout/stderr, request audit, response audit, or frozen artifact.
- Per-request timeout: 600 seconds.
- Maximum HTTP attempts per logical completion: 3, limited to transport/rate
  limit/server failures. These retries preserve identical request bytes and do
  not count as new semantic completions.
- Redirects are disabled. Request/response content is represented in audit by
  hashes and normalized usage/latency metadata, not by authorization data.

## Mandatory capability preflight

Before any benchmark input is opened, the runner sends one non-benchmark
request whose user message includes the provider-required lowercase token
`json`, and requires the exact strict JSON object
`{"v3p83_transport_ok":true}` from resolved model `gpt-5.5`. If endpoint,
authentication, model resolution, `reasoning_effort`, or strict JSON behavior
is incompatible, v3.105 stops before GAIA-50 inference. It must not switch to
another endpoint, model, SDK/CLI transport, or response parser.

A failed preflight is a transport-capability failure, not a scored benchmark
result.

## Frozen execution topology

- Run all 50 cases; there is no smoke gate or case router.
- Run exactly three serial stages per accepted case:
  `packet-state-anchor`, `earliest-causal-challenger`, and
  `default-keep-arbiter`.
- The target accepted topology is `50 x 3 = 150` fresh stateless logical
  requests.
- Maximum workers: `4`.
- Maximum semantic attempts per stage: `2`.
- Upstream state may enter a later stage only through the frozen stage
  artifacts embedded by the adapter.

After all 150 accepted stages, every original v3.83 schema, taxonomy,
literal-evidence, ordering, checkpoint, challenger, arbiter, and manifest
validator must pass. The run must contain exactly 50 merged predictions with
no missing or repaired case. Transport provenance, usage/latency diagnostics,
credential-hygiene audit, and the gold-free artifact tree are frozen before
labels can be loaded. Scoring may begin only after the frozen tree is
reverified.

## Falsifiable hypothesis and decision rule

The falsifiable hypothesis is that a deterministic response-only I/O adapter
can preserve v3.83's decision semantics while direct stateless model calls may
change Step Exact through transport/runtime behavior alone.

- Selection metric: Step Exact only.
- Accept v3.105 only if the complete legal GAIA-50 run has Step Exact
  `>26/50`.
- Complete the Goal only at Step Exact `>=30/50` with every legality and
  isolation check passing.
- Step+Module, All Correct, module/type distributions, token counts, and
  latency are diagnostic only.
- A partial run, missing case, illegal artifact, failed preflight, credential
  leak, or post-freeze mutation is not a score and cannot be accepted.

## Formal invocation

Install the frozen base environment and additive transport runtime, inject
`SOPHNET_API_KEY` through the operator's secret environment, and run:

```bash
uv sync --frozen --extra dev
uv pip install --python .venv/bin/python -r requirements-v3p83-transports.txt
.venv/bin/python -m \
  scripts.run_agent_judge_gaia_v3_105_v3p83_sophnet_chat_completions_transport_gpt55_medium_paper50 \
  --execute --max-workers 4 --max-attempts 2
```

The additive requirements file does not modify the frozen v3.83 `uv.lock`.

The key value is intentionally absent from this preregistration and from the
checked-in configuration.

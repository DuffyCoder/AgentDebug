# Luna GAIA v3.22 Isolated Bidirectional State Challenger Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia-v3.22-isolated-bidirectional-state-challenger`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Frozen incumbent Step Exact: `25/50`
- Original v3.4 baseline Step Exact: `21/50`
- Version acceptance: `Step Exact > 25/50`
- Goal completion: `Step Exact >= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Frozen v3.20 predictions SHA-256: `9df734d95a7c338a9b8ce66fb4d91e16d69961d272ddcc926f7d11f3ddc8add8`
- v3.20 Step audit SHA-256: `b1c0647d5081a85f469027152ad9d29d674d4fdb8db520cfaed43ddf5921f550`
- Rejected v3.21 predictions SHA-256: `622fe43fb9cf73ef2bfa219e2fc8403d15164753926c16ef5f4a29722ce1d4fb`
- v3.21 Step audit SHA-256: `555b23ac56854c0220b2b65dec0c1b3f73f3ae43d73ac7d0e2e005480bea17b3`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the sole optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module/type/evidence remain legality constraints only.

## Post-score diagnosis motivating this version

The v3.20 audit contains five missed Memory/Reflection boundaries sharing one
literal result-to-state defect: necessary fact omission, unsupported answer
relation, or a result-contradicting outcome claim. Four are High-confidence and
one Medium-confidence. A sixth error is the reverse direction: a provisional
query-quality hypothesis was incorrectly admitted before a later
result-contradicting state boundary.

v3.21 attempted to solve this by binding typed state classification before every
anchor row. It scored 16/50: one incumbent error became correct while ten
incumbent-correct cases regressed. That experiment falsified global anchor
salience as the delivery mechanism, not the literal state distinctions
themselves.

## Single major change

Keep the complete v3.20 anchor task semantically unchanged. Replace its
later-only challenger with one isolated, state-only, bidirectional challenger.
It may emit at most one proposal and may ignore the anchor ledger's candidate
set, but only for a literal Memory/Reflection boundary.

The challenger scans the complete chronology and records exactly one proposal
kind when a proposal exists:

- `necessary_fact` + `omitted`;
- `entity_relation` + `unsupported`;
- `outcome_claim` + `contradicted`.

An earlier proposal is legal only when the anchor is a downstream symptom of
that state defect. A later proposal is legal only when the anchor is a
reasonable probe or noncritical predecessor. Each proposal must:

1. quote literal adjacent feedback and Memory/Reflection evidence;
2. be owned by Memory or Reflection;
3. feed the current or next plan;
4. survive an anchor-only repair counterfactual;
5. be the earliest qualifying state boundary in the relevant chronology.

Explicit vetoes remain for harmless compression, facts still available to the
next decision, provisional query-quality hypotheses compatible with irrelevant
feedback, unsupported wording not consumed downstream, and outcome summaries
not literally contradicted.

The independent arbiter defaults to the v3.20 anchor and accepts the state
proposal only if the type/relation, direction, literal entailment failure, and
path effect all survive re-reading. No candidate pool, general earlier scan,
acquisition rule, entity/site rule, case router, or historical prediction is
added.

## Falsifiable prediction

The state-only challenger should recover up to six audited state-boundary errors
without perturbing the v3.20 anchor protocol. Observable checks:

- every challenger has a validator-audited state kind/relation/direction prefix;
- `challenge` proposals are owned only by Memory or Reflection;
- no-challenge records use `none/not_applicable/none`;
- at least one full-run proposal is earlier than its anchor;
- at least one full-run proposal exercises a non-clear state relation;
- accepted state proposals produce more Step gains than losses relative to
  v3.20;
- final Step Exact exceeds 25/50.

The hypothesis is falsified if the target state boundaries are not proposed,
if benign state compression floods the challenger, if arbiters override direct
incumbent-correct roots, or if Step Exact is `<= 25/50`.

## Gain and regression analysis

Expected gains:

- concrete result titles/values/provenance omitted from retained state;
- unsupported entity/value/credential relations consumed downstream;
- false success/progress claims contradicted by adjacent feedback;
- later state boundaries hidden behind a provisional query hypothesis.

Primary regression risks:

- benign compression proposed as necessary-fact omission;
- a real later anchor displaced by a locally false but noncritical earlier state;
- a provisional retrieval hypothesis mislabeled as an answer relation;
- bidirectional scan producing more challenge salience than the default-keep
  arbiter can safely reject.

Isolation from the anchor, the Memory/Reflection owner restriction, the closed
three-pair taxonomy, one-proposal maximum, literal-evidence checks, path-effect
test, and default-keep arbiter are the regression controls.

## Execution and acceptance protocol

1. Implement the versioned challenger, validator, runner, and negative tests.
2. Verify that anchor semantic instructions equal v3.20 except versioned paths.
3. Run offline tests and source scans only; do not run a smoke gate.
4. Execute all 50 frozen cases with three fresh serial sessions per case and at
   most four cases concurrently.
5. Freeze all predictions and intermediate artifacts after 50/50 completion and
   gold-free validation.
6. Only then load released labels and score all 50 cases.
7. Compute Step Exact and transitions against v3.4 and v3.20.
8. Accept only if Step Exact is strictly greater than `25/50`; complete the Goal
   only if it is at least `30/50` and every legality/freeze check passes.
9. Otherwise reject the immutable version, audit every Step error, and continue
   from one new uniform mechanism.

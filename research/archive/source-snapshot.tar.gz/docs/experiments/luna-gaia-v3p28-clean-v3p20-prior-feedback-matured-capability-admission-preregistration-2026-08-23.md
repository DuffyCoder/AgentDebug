# Luna GAIA v3.28 Clean-v3.20 Prior-Feedback Capability Maturity Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.28-clean-v3.20-prior-feedback-matured-capability-admission`
- Direct semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: v3.20, Step Exact `25/50`
- Original v3.4 baseline: Step Exact `21/50`
- Version acceptance: `Step Exact > 25/50`
- Goal completion: `Step Exact >= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Frozen v3.20 predictions SHA-256: `9df734d95a7c338a9b8ce66fb4d91e16d69961d272ddcc926f7d11f3ddc8add8`
- Frozen v3.27 predictions SHA-256: `41b21ad71c12b5585334767b2a114fbfedade9e87c4cfdcb923059afaf9082ca`
- v3.27 Step-error audit SHA-256: `8ff3096c119cca8e4c55ca2572098aa95f644c393c83a7fdbf79b03cbffbdd66`
- v3.27 cluster audit SHA-256: `22ea7c913a5455f6d9902a143378fc979e9e2cfd26c04fe691b0619d4af097e1`
- Model / reasoning effort: `gpt-5.6-luna` / `medium`
- Smoke gate: none

Step Exact is the only optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module/type/evidence remain legality constraints only.

## Clean-branch guarantee

This implementation imports v3.20 directly. It retains v3.20's packet-state
anchor, earliest-causal challenger, default-keep arbiter, validator semantics,
and artifact contracts. It does not import or reproduce the protocol changes
introduced by v3.21 through v3.27.

Specifically removed are typed state-claim entailment, isolated/bidirectional
state challengers, mandatory state scans, isolated state-evidence ledgers,
predecessor-feedback alignment, same-Step consumer witnesses, and every related
validator or inter-stage field. Post-score diagnoses from those versions are
evidence for this preregistration only and are not inference inputs.

## Single major change

Append one validator-enforced capability-maturity segment immediately after
v3.20's required packet-state prefix on every anchor ledger row:

```text
capability_maturity=<not_applicable|unobserved|observed>;
prior_limitation_step=<none|positive integer>;
```

Rules:

1. `not_applicable/none` covers rows that do not make an interface/corpus
   capability claim; all v3.20 rules remain unchanged.
2. `unobserved/none` means no feedback strictly before the current Step has
   exposed the exact selected interface/corpus limitation. It is a binding
   Lane-B initial- or different-probe veto.
3. `observed/N` requires a strictly earlier Step N whose literal feedback
   demonstrates the same limitation. The current Step's result does not count.
4. After `observed/N`, recommitment may be admitted under unchanged v3.20 rules;
   observation does not force admission.

No contribution exemption, hard-modality exception, route-equivalence repair,
state challenger change, case router, entity/source rule, historical
prediction, candidate pool, or result splice is added.

## Prior evidence, gains, and regressions

The rejected v3.27 run is a deliberately disclosed negative prior: its final
predictions were all maturity-gated anchors, scoring `21/50` against v3.20's
`25/50`, with four gains and eight losses. It also used a rejected downstream
challenger/ledger lineage, although that challenger made zero final overrides.

This clean run tests whether the same single anchor mechanism, composed only
with the accepted v3.20 protocol, reproduces that negative result or changes
under v3.20's own challenger topology. Expected gain coverage remains the four
observed transitions; eight incumbent-correct cases are the measured regression
risk. The preregistered empirical expectation is therefore non-positive, while
the acceptance requirement remains strictly greater than 25/50. A full run is
required for clean attribution by the amended Goal.

## Falsifiers and execution

The mechanism is falsified if it does not fire, admits an `unobserved` Lane-B
capability candidate, records a non-earlier prior Step, causes net incumbent
regression, or scores `<=25/50`.

After offline tests and prepare-only validation, run all 50 frozen cases with
three fresh sessions per case and at most four cases concurrently. Freeze all
predictions and intermediates only after 50/50 gold-free validation, then score
and compute transitions against v3.20 and v3.4. Accept only above 25/50; complete
the Goal only at or above 30/50 with every legality check passing.


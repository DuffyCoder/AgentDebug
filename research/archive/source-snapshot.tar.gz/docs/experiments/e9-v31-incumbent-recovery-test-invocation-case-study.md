# E9 v31 incumbent-recovery test invocation case study

## Failed attempt

The first targeted validation of the frozen v31 archive reported 35 failures
and 96 passes.  Test expectations named v31, while imported constants and
parsers came from the current v54 workspace.

## Attribution

The command set `PYTHONPATH` to the extracted archive but kept the process
working directory at the live AgentDebug repository.  Python places the empty
path for the current working directory ahead of `PYTHONPATH`, so the live
`agentdebug` package shadowed the frozen archive.  This created an invalid
cross-version test environment.

The archive hashes still match the v31 preregistration.  No evidence indicates
a v31 implementation failure.

## Correction

Run Python and pytest with the extracted archive itself as the working
directory.  Assert the imported module `__file__` is inside that directory
before accepting any result.  Keep the live repository out of the archive
test import path.

No external LLM request was made.

# E9 v38 full30 failure case study

## Outcome

v38 passed its frozen dry3 gate at 2/3 for Step Exact, Step+Module Exact,
and All Correct. The promoted full30 phase then completed the entire raw
chain but failed the preregistered Step Exact threshold:

- Step Exact: 9/30 (30.00%; gate requires 12/30);
- Step+Module Exact: 4/30 (13.33%; gate requires 3/30);
- All Correct: 3/25 (12.00%; gate requires 3/25);
- successful outputs: 30/30;
- failed outputs: 0/30;
- new full30 logical completions: exactly 20;
- HTTP attempts: exactly 20, with zero retries;
- provider tokens: 3,651,144 input, 277,727 output, 3,928,871 total.

Only `step_exact_minimum_correct` failed. The rejected promotion artifact is
self-bound by
`e447689b3d362b3f7c4dac461456c6b3f9b02a8eb05ae29a209fbd501252f57c`.
Held-out smoke must not run from v38.

## Format and execution attribution

This was not a transport, parsing, or evidence-projection failure. All 30
rows had valid final semantic tuples. The 20 live logical completions map
one-to-one to 20 HTTP attempts and the provider reported `stop` for every
response. No response was retried. The default request body was used and no
thinking option was sent.

The bounded JSON suffix handling was exercised four times on
`reasoning_content`, but it did not replace or repair any semantic field.
Every critical step, module, error type, root cause, and evidence selection
still came from the raw Selector response. The dry first batch was the only
cache hit, as preregistered.

## Semantic result by environment

The Step Exact breakdown is:

- ALFWorld: 4/10;
- GAIA: 4/10;
- WebShop: 1/10.

Among the 21 wrong-step rows, ALFWorld selected a later step in five of six
misses, while GAIA selected a later step in four of six misses. WebShop was
bidirectional: four predictions were too late and five were too early. v38
therefore did not merely have one global early/late bias. It applied the
first-defect and search-maturity rules inconsistently across environments.

The module confusion is also material. Only 9/30 predictions used the gold
module, and only 4 of those also had the exact step. Common errors were
planning outputs relabeled as concrete action defects and reflection or
memory outputs replaced by later search symptoms.

## Selector attribution

v38 was intended to make the final Selector independently compare a fresh
Candidate with the frozen incumbent. In practice the Selector mostly acted
as a proposal confirmer:

- `accept_proposed`: 23 rows, only 5 Step Exact;
- `accept_incumbent`: 2 rows, both Step Exact;
- `fresh`: 5 rows, 2 Step Exact;
- final step equaled the proposed step in 25/30 rows;
- final step was outside both supplied steps in only 3/30 rows.

The supplied incumbent and proposal step union covered only 8/30 gold steps,
and the Selector added one net exact localization beyond that union. Its
long causal explanation often sounded independent, but the decision behavior
shows strong proposal anchoring. An `accept_proposed` verdict was therefore
not an effective adversarial causal check.

This explains several representative misses:

1. In ALFWorld, the Selector sometimes replaced an introducing plan,
   reflection, or memory defect with a later executable symptom. Examples
   include step 27 instead of gold step 4 and terminal step 30 instead of
   gold step 4.
2. In GAIA, it often found the correct local issue but chose the downstream
   point where the issue was summarized or acted upon: step 5 instead of
   gold step 3, and step 13 instead of gold step 4.
3. In WebShop, the capability/maturity contract overfit both directions. It
   chose step 2 immediately from incomplete listings in some traces, but
   waited until steps 21 or 22 in others whose released error was already
   visible at steps 2 or 4. The visible UI facts alone did not supply a stable
   maturity boundary.
4. The terminal guard was correct for the dry ALFWorld step-limit case but
   over-applied to a full30 ALFWorld case whose released introducing plan was
   at step 4. Distinct container visits are not enough to prove the absence of
   an earlier inefficient plan.

## Candidate-space audit

The failure is not evidence that no useful raw LLM hypotheses exist. On the
same frozen tuning cohort:

- v29 alone has 9 exact steps;
- v30 alone has 10 exact steps;
- v38 final has 9 exact steps;
- the v29 and v30 step union is 14/30;
- the v29, v30, and v38 step union is 16/30.

Those unions are a post-score diagnostic only. They must not become a score,
vote, deterministic preference, or label fallback. They do show that the
12/30 target lies inside the already observed raw LLM candidate space. The
remaining problem is to expose genuinely different causal hypotheses to one
independent LLM judge and require a trace-grounded comparison instead of
letting one freshly worded proposal anchor the answer.

## v39 optimization direction

Before another provider call, v39 should implement a candidate-blind causal
comparison rather than add another early/late rule:

1. Preserve v38's strict raw-response chain, default Flash request, source-ID
   evidence validation, atomic taxonomy pair, gold isolation, exact ledger,
   and raw Selector as the sole final semantic source.
2. Present separately identified, untrusted raw hypotheses from materially
   different LLM judging contracts: terminal guard, first-defect audit, and
   the current causal proposal/incumbent. Do not include historical scores,
   correctness, version names, or any ordering that implies preference.
3. Before revealing those hypotheses to the final comparison section, require
   the Selector to write a trace-derived causal ledger containing the failure
   outcome, candidate introducing events, recoveries, and the owner output.
   It must then rebut every surviving hypothesis against that ledger.
4. Disallow `accept_proposed` as a sufficient rationale. The final response
   must state why correcting the selected output redirects the failure and
   why correcting each competing step does not, or why that competitor is a
   downstream symptom, recovered detour, or unsupported speculation.
5. Keep all final semantics LLM-authored. Deterministic code may validate
   schema and source IDs only; it must not rank, score, vote, repair, or fall
   back to any hypothesis.
6. Use the same semantic topology for tuning and held-out smoke. Frozen raw
   tuning hypotheses may be rebound without new calls; held-out hypotheses
   must be generated fresh by their corresponding prompt lanes before the
   final Selector.
7. Preregister dry3 first and promote to full30 only if all dry gates pass.
   Any failed attempt again requires a completed case study before another
   provider call.

No v29, v30, or v38 artifact may be mutated or rescored under v39.

# E9: Batched semantic Scout and independent causal Arbiter

Status: E9-v1 through E9-v12 dry3 rejected. E9-v13 is the current candidate
and has not made a provider call. Its source snapshot, gold-free plans, fresh
empty cache, request hashes, preregistration, and authorization chain must all
be frozen and verified before that call. This document does not by itself
authorize a provider call.

E9-v1 consumed two logical completions (`321 → 323`) with no retry. All
three outputs were valid, but the dry result was Step Exact 1/3,
Step+Module 1/3, and All Correct 1/3. Its rejected promotion, ledger, raw
outputs, and a verified archive of all 48 preregistered source files remain
under the v1 dry output directory.

E9-v2 consumed two more logical completions (`323 → 325`) with no retry.
Its five-module scout was valid, but the arbiter copied a quote longer than
the 512-character validation limit, so all three predictions correctly
remained invalid rather than being repaired. The raw output also showed
first-non-null-candidate anchoring. Its rejected promotion, ledger, raw
outputs, and verified 48-file source archive remain under the v2 dry output
directory.

E9-v3 consumed two logical completions (`325 → 327`). All three predictions
were valid, but the dry result was Step Exact 1/3, Step+Module 0/3, and All
Correct 0/3, so the frozen promotion gate rejected it. Its rejected promotion,
ledger, raw outputs, and exact preregistered source snapshot remain under the
v3 dry output directory. The 48-file snapshot archive has SHA-256
`d9fa4306c7d349f90086d9e233bbc9eaa5850a078832b081fe870267ca4cb666`.

E9-v4 consumed two logical completions (`327 → 329`). Only one of three
predictions was successful and two were invalid; the dry result was Step Exact
0/3, Step+Module 0/3, and All Correct 0/3. Before validation, its raw semantic
choices were C01 step 6 planning, C02 step 1 planning, and C03 step 7 planning.
The frozen promotion gate therefore rejected it. Its exact 48-file
preregistered source snapshot archive has SHA-256
`605127418ae2c1534cdbfef76d09f2a72889e8162e032f195233e69a6a8317b5`.

E9-v5 consumed two logical completions (`329 → 331`) with no retry. Two of
three predictions were successful and one was invalid because its selected
planning evidence source belonged to an earlier step. The dry result was Step
Exact 1/3, Step+Module 1/3, and All Correct 1/3, so the frozen gate rejected
it. One successful prediction recovered the complete action/misalignment
tuple. Another selected a mid-trajectory planning root even though its own
boundary proof recorded distinct new coverage and an unobserved final action
outcome. The invalid raw prediction selected planning/inefficient_plan but
placed the root later than the first locally contradictory revisit. Its exact
48-file preregistered source snapshot archive has SHA-256
`40b220ef816c395068925c276f9001fd3351a3dae8a036f9572cb89088263ba3`.

E9-v6 consumed two logical completions (`331 → 333`). Its dry3 result was
Step Exact 0/3, with one successful prediction and two invalid predictions,
so it failed the frozen promotion gate and was rejected. Its preregistered
48-file code bundle is archived with SHA-256
`8a8ce8f59de863a2239946047c16d5f1eaf944d0c44bfda551c323da3098f519`.

E9-v7 reused the paid scout response and consumed one arbiter completion
(`333 → 334`). One of three predictions was valid and two were invalid; the
raw arbiter step choices were wrong for all three cases, so Step Exact,
Step+Module, and All Correct were all 0/3. The frozen promotion gate rejected
it. Its exact preregistered 49-file archive has SHA-256
`a45f48b5d051552dce07418a819e37979159c4d064a68513271fbd27be7101df`.

E9-v8 reused the paid scout response and consumed one arbiter completion
(`334 → 335`). All three outputs were valid, and it correctly recovered one
complete tuple, but Step Exact, Step+Module, and All Correct were each only
1/3. The frozen promotion gate therefore rejected it. Its preregistered
49-file content bundle has SHA-256
`8f25c358139ad8a76269a42f7b1200853925c8d3953d831d2ff669924d21b643`;
the preserved tar archive has SHA-256
`b28b3ce89787aff1106dc378e7a38423ce954ea81ad9ef064adbbdcddc67a315`.

E9-v9 reused the paid scout response and consumed one arbiter completion
(`335 → 336`). All three outputs were valid. Step Exact, Step+Module, and All
Correct were each 1/3, with zero failed outputs, so the frozen promotion gate
rejected it. It continued to select a later answer instead of an
underspecified initial acquisition and selected a terminal system boundary
instead of an earlier known-coverage contradiction. Its preregistered
49-file content bundle has SHA-256
`19fa02f5e428dc3b4e15701fea88f770eae28652061d72b506c2dc516afa9d9e`;
the preserved tar archive has SHA-256
`ce8200383ca714be456c682692b5440d1d7aaec4870306e01527be7d938c6d7b`.

E9-v10 reused the paid scout response and consumed one arbiter completion
(`336 → 337`) with no HTTP retry. Two outputs were structurally valid and one
failed exact evidence validation. Step Exact, Step+Module, and All Correct
were all 0/3, with one failed output, so the frozen promotion gate rejected
it. The raw decisions selected an initial plan by hindsight, a later wrong
answer instead of an earlier acquisition defect, and a false acquisition
omission whose alleged missing qualifiers were visibly present. Its exact
49-file archive has SHA-256
`0334daf5f343724ee60e0c2f1976bd3700c421ebc00eb7aa0d8e0e09549afc6b`.

E9-v11 reused the paid chronology-only scout response and consumed one
arbiter completion (`337 → 338`) with no HTTP retry. One of three outputs was
valid and two failed closed: one copied a Scout paraphrase instead of an
exact provenance-backed execution fact, and one exceeded the frozen audit
text limit before its final tuple could be accepted. The one valid tuple
selected step 4 instead of the annotated earlier action root. Step Exact,
Step+Module, and All Correct were therefore all 0/3, with one successful and
two failed outputs, so the frozen gate rejected v11. Its exact 49-file source
archive has SHA-256
`1b5aaeb9092ec7a8a913a1143652f4f7b987b35b7abdc7303a63c55342295d0e`.

E9-v12 started both stages from a fresh cache and consumed two logical
completions (`338 → 340`) with no HTTP retry. All three final Arbiter outputs
were valid, but Step Exact, Step+Module, and All Correct were each only 1/3,
so the frozen gate rejected it. Provider usage was 297,980 input tokens,
2,336 output tokens, and 300,316 total tokens.

The raw Scout had in fact produced a correct terminal candidate for one case
and a correct local candidate for another, but it wrote complete values such
as `system/step_limit` and `action/misalignment` into a split
`error_type` field. The Scout parser required a leaf error type, isolated all
three case bundles as unavailable, and the Arbiter therefore received no
Scout candidate for any case. This was a protocol contradiction, not a
truncation or evidence-ownership failure. A separate promotion check also
used a stale semantic-classifier literal; raw-chain reconstruction and zero
semantic mutation still proved the three final tuples came from raw Arbiter
output. The classifier check was an additional false negative, but correcting
it cannot change the independently failing 1/3 Step Exact result. V12 remains
rejected. Its verified 49-file archive has SHA-256
`a1ab86b3e8730fef30b3f326c94428c654924d88a81d8a43cafd9513e70515b1`.

## E9-v13 falsifiable hypothesis and atomic Scout contract

V13 is a single-variable test of the semantic Scout architecture that v12
never actually exercised. The falsifiable hypothesis is: if every Scout
classification is emitted as one strict atomic `module/error_type` value and
that value reaches the unchanged independent Arbiter, all three Scout bundles
will be usable and the unchanged dry3 panel will reach at least 2/3 Step
Exact with zero failed outputs.

The dry protocol is accepted only if denominator is 3, successful is 3,
failed is 0, Step Exact is at least 2/3, Step+Module is at least 1/3, and All
Correct is at least 1/3. Failure rejects v13 before full tuning.

The v13 change is deliberately narrow:

1. Scout candidate `module` plus `error_type` is replaced by one
   `taxonomy_pair`. Terminal review likewise uses a nullable
   `taxonomy_pair`.
2. The exact whitelist is generated from the existing taxonomy and contains
   18 valid pairs. Leaf-only values, aliases, changed case, surrounding
   whitespace, unlisted pairs, and the old split-field object are rejected.
3. Parser splitting is used only to validate taxonomy membership and bind the
   exact evidence quote to the pair's owner module. The normalized candidate
   bundle preserves the LLM's original atomic pair and does not rewrite it.
4. Scout candidate semantics, capability/history instructions, terminal
   review, Arbiter audit, and Arbiter final response schema remain unchanged
   from v12. No new semantic rule or mandatory audit field is introduced, so
   a measured delta is attributable to making the already-paid Scout
   conclusion structurally usable.
5. The Arbiter may reject every candidate or add a supplemental root. Its raw
   `critical_step`, `module`, `error_type`, `evidence_quote`, and
   `root_cause` remain the sole final semantic classification.
6. One shared `E9_SEMANTIC_CLASSIFIER` constant now binds workflow generation,
   reconstruction, scoring, preregistration, and promotion. This repairs the
   mechanical v12 gate drift without changing a semantic answer.
7. There is no v12 cache or parser compatibility path. V13 starts from a
   fresh empty cache; v12 is referenced only as a rejected usage anchor
   proving cumulative consumption through 340.

The frozen implementation identities are:

- experiment:
  `e9_v13_atomic_taxonomy_pair_scout_causal_arbiter_judge`;
- pipeline:
  `e9-batched-semantic-candidate-scout-arbiter-v13`;
- Scout prompt:
  `agentdebug-e9-scout-v13-atomic-taxonomy-pair`;
- unchanged Arbiter prompt:
  `agentdebug-e9-arbiter-v12-independent-review-capability-history`;
- evidence validator:
  `e9-raw-arbiter-same-step-owner-exact-substring-no-length-cap-v13`;
- prediction schema:
  `agentdebug.benchmark.e9-unscored-prediction.v11`;
- planner:
  `e9-v13-gold-free-manifest-order-greedy-char-cap-v13`;
- Scout cache compatibility:
  `e9-v13-fresh-atomic-taxonomy-pair-scout-v13`;
- preregistration and promotion schemas:
  `agentdebug.benchmark.e9-preregistration.v8` and
  `agentdebug.benchmark.e9-promotion.v8`.

## E9-v12 falsifiable hypothesis and semantic design

V11 showed that a visible audit over a label-free chronology map was not
enough. The Arbiter still lacked semantic candidates for defects that depend
on operation capability or persistent historical coverage, while the
chronology Scout's free-form system summary was unsafe to reuse as final
evidence.

V12 tested the following falsifiable hypothesis on the unchanged tuning dry3
panel: an unranked LLM semantic-candidate Scout that explicitly audits
operation capability and cumulative historical state, followed by an
independent complete-timeline causal Arbiter with provenance-ready execution
fact lines, can recover at least two exact critical steps with all three
outputs valid and without deterministic semantic assistance.

The protocol was accepted only if denominator was 3, successful was 3, failed
was 0, Step Exact was at least 2/3, Step+Module was at least 1/3, and All
Correct was at least 1/3. The observed 1/3 Step Exact result falsified the
hypothesis and rejected v12 before full tuning.

The v12 design is:

1. The Scout receives complete anonymous compact timelines and starts from a
   fresh empty cache. It emits zero to four independently checkable semantic
   candidates in nondecreasing step order. Candidate order is chronology, not
   preference. There is no confidence, score, probability, weight, vote,
   priority, or ranking field.
2. Candidate search uses four lenses:
   `capability_mismatch`, `known_state_contradiction`,
   `literal_constraint_omission`, and `other_taxonomy_defect`. Every candidate
   contains an LLM-selected taxonomy tuple, exact same-step/module owner
   quote, contemporaneous basis, counterfactual, and later recovery status.
3. Both Scout and Arbiter perform an operation-capability audit before
   argument-syntax checks. A tool accepting free-form input or a syntactically
   valid parameter does not prove that the operation can query, filter,
   order/sort, verify, or implement the relation promised by the plan.
4. Both stages maintain cumulative historical coverage over the entire prior
   timeline. Navigating back to an earlier display cannot erase a previously
   visited page, state, or target. A retained contradiction must name the same
   concrete state on both sides and is localized to its first contemporaneous
   owner output.
5. The Scout independently reviews the terminal boundary. Small
   provenance-backed execution fact lines are copied verbatim into both stage
   prompts and the system evidence owner source. No Scout paraphrase is final
   evidence, and the full evidence-source catalog is not embedded in either
   prompt.
6. The Arbiter rereads every complete timeline and treats the Scout bundle as
   untrusted analysis. It can reject every candidate and can record a
   supplemental root missed by the Scout. Its visible audit reviews
   candidates, supplemental possibilities, the terminal boundary, and their
   causal comparison before emitting the final tuple.
7. The raw Arbiter fields `critical_step`, `module`, `error_type`,
   `evidence_quote`, and `root_cause` are the sole final semantic
   classification. Parser and workflow code validate JSON shape, taxonomy,
   public step mapping, exact owner-source containment, and provenance only.
   They do not derive, repair, rank, score, reweight, or overwrite any final
   semantic field from the Scout or audit.
8. The v12 runtime contains no chronology-seed import path or legacy Scout
   format adapter. Old rejected artifacts remain referenced only by the
   preregistration usage ledger to prove cumulative paid calls; they are never
   semantic or cache predecessors.

The frozen implementation identities are:

- pipeline:
  `e9-batched-semantic-candidate-scout-arbiter-v12`;
- Scout prompt:
  `agentdebug-e9-scout-v8-unranked-semantic-candidates-capability-history`;
- Arbiter prompt:
  `agentdebug-e9-arbiter-v12-independent-review-capability-history`;
- evidence validator:
  `e9-raw-arbiter-same-step-owner-exact-substring-no-length-cap-v12`;
- prediction schema:
  `agentdebug.benchmark.e9-unscored-prediction.v10`;
- planner:
  `e9-v12-gold-free-manifest-order-greedy-char-cap-v12`;
- Scout cache compatibility:
  `e9-v12-fresh-semantic-candidate-scout-v12`.

For untagged OpenClaw output, exact quote provenance is still available from
the neutral assistant source. Module ownership in that case is an LLM
semantic attribution, not a claim that an original benchmark-style module
tag existed.

## E9-v11 falsifiable hypothesis and semantic design

E9-v10 showed that reordering private instructions is insufficient: the model
still emitted `critical_step` before any observable proof and rationalized the
choice afterward. It also exposed a rule error: requiring an underspecified
acquisition result to be used downstream excludes a locally defective action
that is abandoned only after it has already consumed an opportunity or forced
a detour. E9-v11 tests whether a bounded, visible audit certificate generated
before the final tuple can make those checks operational without allowing
deterministic code to choose or repair a root.

The hypothesis is falsifiable on the unchanged frozen tuning dry3 panel. The
protocol is accepted only if all three outputs are valid, Step Exact is at
least 2/3, Step+Module is at least 1/3, All Correct is at least 1/3, and there
are no hard failures. Failure rejects v11 without spending the calls reserved
for its full-tuning and held-out-smoke phases.

The v11 protocol changes the independent LLM arbiter response contract:

1. The paid E9-v6 scout request remains byte-identical and produces only a
   label-free chronology map. The complete anonymous `JudgeView` timelines
   remain authoritative.
2. Each case emits `audit` before `critical_step`. The certificate has bounded
   `initial_probe`, `acquisition`, `known_coverage`, `other_local`, `terminal`,
   and `chronology_selection` records. These are LLM semantic conclusions,
   not confidence values, scores, weights, votes, rankings, or deterministic
   findings.
3. `initial_probe` prevents hindsight from turning one feasible first probe of
   an unchecked state into `planning/inefficient_plan` merely because the
   later trace is long or another probe was possible.
4. `acquisition.constraint_check` starts with operation-category suitability,
   then lists every currently applicable qualifier with an exact implementing
   phrase or `MISSING`. The acquisition need not be used downstream to remain
   locally defective. Abandonment or tool switching is not complete recovery;
   recovery requires implementing the missing requirement and obtaining or
   verifying the needed evidence.
5. `known_coverage` scans every planning output, including steps absent from
   the chronology map. A retained contradiction must record exact
   `KNOWN="..."` and `PLAN="..."` text naming the same state.
6. The certificate also records any other local defect and terminal
   eligibility, then compares all surviving roots chronologically before the
   LLM emits the unchanged final taxonomy tuple.
7. Final evidence must be a 1-to-12-word, at-most-80-character exact
   same-step/module substring. The parser keeps no semantic repair and no
   deterministic quote-length-derived root.
8. Deterministic code validates only certificate shape, enums, booleans,
   nullable public steps, bounded audit prose, the final taxonomy and step,
   and exact final evidence containment. It persists the normalized
   certificate but never derives, ranks, overrides, or repairs the final
   tuple from it.

The frozen version identities are:

- pipeline:
  `e9-batched-visible-audit-certificate-arbiter-v11`;
- arbiter prompt:
  `agentdebug-e9-arbiter-v11-visible-audit-certificate`;
- evidence validator:
  `e9-arbiter-same-step-owner-exact-substring-no-length-cap-v11`;
- unscored prediction schema:
  `agentdebug.benchmark.e9-unscored-prediction.v9`;
- verified Scout seed and binding schemas:
  `agentdebug.benchmark.e9-verified-scout-seed.v5` and
  `agentdebug.benchmark.e9-verified-scout-seed-binding.v5`.

The final semantic tuple remains solely an LLM-as-judge output. Deterministic
code only performs serialization, schema and taxonomy checks, public
step/event mapping, exact quote containment and provenance binding,
persistence, and isolated post-prediction scoring.

### V11 verified paid scout seed and rejected-run usage anchor

The v11 dry run reuses only the already-paid E9-v6 scout response. A
zero-provider-call import must verify the source request, messages, response,
sidecar, schemas, hashes, and telemetry, then reparse that raw response into
an otherwise fresh v11 cache. Only the v11 arbiter may be a dry cache miss.
The generated seed records `provider_completion_called: false` and is fixed
by:

- seed content SHA-256:
  `758b2090e919cf35a7ee2ca49fec4769e8fec466c98ab8ed868453bd27acde2e`;
- serialized seed-file SHA-256:
  `6642df42018c9da468353cd49dddcd5d3692554d20722fe97b0f90cde840ec8c`;
- reused Scout request SHA-256:
  `a20c9e4555667cc26b57508e96a48bd8758b92020777755fec5f2f532800905e`;
- exact three-file target-cache aggregate SHA-256:
  `635bfcbaa0c763825ae701c623369ae934b8d6705b6fa6766b667d441ab1b4b0`.

The rejected v10 artifacts are hash-bound solely to prove cumulative use
`336 → 337`. The validator recomputes v10's stored v9 anchor, v9's v8 anchor,
and v8's v7 anchor first, yielding the nested usage-only chain
`333 → 334 → 335 → 336 → 337`. None is a semantic or promotion predecessor
of v11. The promoted v11 dry cache becomes the full-tuning cache; held-out
smoke uses a separate empty cache.

## E9-v10 falsifiable hypothesis and semantic design (rejected)

E9-v10 moved acquisition and known-coverage checks ahead of terminal fallback
and required a chronological all-step scan. Its raw output demonstrated that
the private audit was still skipped: all three semantic choices remained
prominent chronology checkpoints, one acquisition omission was invented
despite visible literal equivalents, and the initial reasonable probe was
judged by later hindsight. The observed 0/3 Step Exact result, with one
invalid final quote, falsified the hypothesis. E9-v11 retains the useful
ordering rules but makes their bounded conclusions visible before the final
tuple and removes downstream reliance as an acquisition-eligibility
requirement.

## E9-v9 falsifiable hypothesis and semantic design (rejected)

E9-v8 showed that a post-timeline all-step audit can recover a terminal
system boundary, but its acquisition rule still accepted unsupported claims
that a concrete query omitted qualifiers which were visibly present. It also
allowed an underspecified initial acquisition to be displaced by a later
wrong answer. E9-v9 tests whether an explicit, generally applicable
constraint-implementation audit can distinguish a truly absent current
qualifier from a merely unsuccessful query, while preserving the successful
terminal-boundary behavior.

The unchanged frozen tuning dry3 panel produced three valid outputs but only
1/3 Step Exact, 1/3 Step+Module, and 1/3 All Correct. The result falsified the
hypothesis and ended v9 without running full tuning or smoke.

The v9 protocol is:

1. The scout request remains byte-compatible with the paid E9-v6 scout
   request. It receives complete anonymous compact `JudgeView` timelines and
   produces only label-free chronology checkpoints and terminal coverage
   state. Its response has no taxonomy, semantic label, root cause,
   confidence, score, weight, vote, or ranking field.
2. The scout parser accepts one to eight ordered checkpoints followed by a
   valid terminal-boundary record. It no longer requires a redundant
   checkpoint at the timeline's final step when the terminal-boundary record
   already describes that boundary. This is structural parser compatibility:
   code neither invents a checkpoint nor derives a semantic finding from the
   boundary.
3. The independent arbiter receives every complete timeline and the available
   scout map as an untrusted navigation aid. Immediately after the timelines,
   a final pre-emit audit states that checkpoints are not candidate roots and
   requires a fresh scan of every step. The full timeline remains
   authoritative if a scout case is unavailable.
4. For each case the arbiter emits exactly six semantic fields:
   `case_key`, `critical_step`, `module`, `error_type`, `evidence_quote`, and
   `root_cause`. There is no nested boundary, cycle, source-selection,
   confidence, score, or counterevidence object in the response contract.
5. The tail audit distinguishes exploration over different concrete targets
   or states from inefficient repetition. If feasible distinct coverage
   continues until a fixed observed boundary prevents the final feasible
   action or result, and no earlier explicit local defect survives the audit,
   it directs the LLM to select the final `system/step_limit` boundary.
6. Before classifying an acquisition, the LLM privately compares each
   qualifier that the current plan makes applicable with the literal URL,
   query, filter, argument, or operation. A staged action need not implement
   requirements reserved for a later task phase. An omission exists only if
   an applicable qualifier and any clear semantic equivalent are absent and
   the trajectory relies on that underspecified result.
7. Poor results, unknown returned attributes, rewording, reordering, or the
   absence of a structured filter cannot by themselves prove omission. If
   every applicable qualifier is implemented, the LLM must reject that
   action/misalignment candidate and continue its chronological audit. A
   truly underspecified acquisition remains the root rather than a later
   answer symptom.
8. At later planning steps, an input that says state K was covered while its
   plan calls K unvisited is localized to that exact
   `planning/inefficient_plan` step. A generic step-1 plan is not erroneous
   merely because it could have named more detail.
9. `evidence_quote` must be an exact contiguous non-whitespace substring of
   evidence owned by the selected `critical_step` and `module`. The prompt
   prefers the shortest decisive quote, normally at most 120 characters, but
   validation has no deterministic quote-length cap. Code may bind an exact
   matching source ID solely for provenance. It rejects missing, cross-step,
   cross-module, or ambiguous ownership; it cannot repair the quote or change
   the LLM's step, module, error type, or root cause.
10. Observable execution facts, including a terminal benchmark step boundary,
   may be exposed as neutral system evidence at the final public step. They
   are never converted by code into `system/step_limit` or any other
   deterministic finding.

The frozen version identities are:

- pipeline:
  `e9-batched-literal-constraint-audit-arbiter-v9`;
- arbiter prompt:
  `agentdebug-e9-arbiter-v9-literal-constraint-coverage-audit`;
- evidence validator:
  `e9-arbiter-same-step-owner-exact-substring-no-length-cap-v9`.

The final semantic tuple is therefore solely an LLM-as-judge output.
Deterministic code is limited to serialization, schema and taxonomy checks,
public step/event mapping, exact same-step/module quote containment,
provenance binding, persistence, and post-isolation scoring. There are no
deterministic findings, semantic priorities, weights, confidence values,
scores, votes, or semantic-repair completions. Validation may reject an
answer but may not supply, mutate, rank, or reweight it.

### Verified paid scout seed and rejected-run usage anchor

The v9 dry run reuses only the already-paid E9-v6 scout response. Before
preregistration, a zero-provider-call import must verify the exact v6 request,
messages, raw response, response sidecar, hashes, schema, and telemetry, then
reparse that raw response with the v9-compatible scout parser into a new,
initially empty v9 cache. The imported cache must contain exactly the raw
response, response sidecar, and current parsed artifact. It must not copy the
old parsed artifact or an arbiter response.

The fixed source identities are:

- scout request SHA-256:
  `a20c9e4555667cc26b57508e96a48bd8758b92020777755fec5f2f532800905e`;
- scout prompt SHA-256:
  `50315a38181c87bc4707b6a461204ded50e32f9052590ba2ff212c83a7c457ef`;
- scout dependency SHA-256:
  `16e7c55f3fb0dadb87d263ee5a4bd08e99ad43cef311617140cf6434c355c2dd`;
- provider raw-response SHA-256:
  `a55a734b050035f7e3a69712ab337a66c9b648233687b399a623981c46ce2a08`;
- source raw artifact SHA-256:
  `28eeab1b4ce1fe656ddbed65d5df7af93d8e800597dacfab44052406b73514e1`;
- source response-sidecar SHA-256:
  `a018080552065ff2e11f56549f92e8f7f18e0f69ba61b24d8138c5692449e608`.

The seed operation must record a self-hashed provenance manifest proving the
source and target file hashes and `provider_completion_called: false`.
Preregistration must verify that manifest and the exact initial cache state.
The intended dry topology is therefore scout cache hit and arbiter cache
miss: only the v9 arbiter incurs a new logical completion. The promoted dry
cache becomes the full-tuning cache, so the first full batch must be a scout
hit and an arbiter hit. Held-out smoke uses a separate empty cache, so every
attempted scout and arbiter stage must be a fresh miss.

The rejected v8 artifacts are hash-bound only to prove that one logical
completion moved cumulative use from 334 to 335. Their stored v7 usage anchor
is recomputed and checked first, proving the nested `333 → 334 → 335` usage
chain. The v9 preregistration labels both relationships
`usage_only_rejected_not_semantic_predecessor`, verifies both rejected
promotions and one-entry arbiter ledgers, and places neither run in v9's
semantic or promotion lineage.

## E9-v8 falsifiable hypothesis and semantic design (rejected)

E9-v8 moved the decisive causal audit after the complete timelines, required
an all-step rescan rather than checkpoint-only selection, distinguished
distinct-state exploration from repetition, traced wrong answers backward to
acquisition, and removed the deterministic quote-length cap. Its flat
six-field result remained solely an LLM output.

The observed 1/3 Step Exact result falsified the hypothesis. The terminal
boundary case was recovered, but another case selected a later answer instead
of the initial underspecified operation, and a third case falsely claimed
that a query omitted qualifiers that were visibly present. E9-v9 preserves
the successful v8 rules and adds only the literal applicable-qualifier audit.

## E9-v7 falsifiable hypothesis and semantic design (rejected)

E9-v7 tested whether the remaining failures came from an over-specified
arbiter response contract and an unnecessarily strict scout parser. It kept
the v6 scout request byte-compatible, allowed a terminal-boundary record
without a redundant final checkpoint, and flattened each arbiter result to
the six semantic fields used by v8. It also enforced exact same-step/module
quote ownership and exposed neutral terminal execution facts without
deterministically converting them into findings.

The observed one-valid/two-invalid result and 0/3 Step Exact falsified that
hypothesis. Forensics showed that every selected step was a scout checkpoint,
while correct roots could occur at a terminal boundary or at a non-checkpoint
step. E9-v8 therefore preserves the flat LLM-only contract but moves its
decisive causal audit after the complete timelines and removes the old hard
quote-length validation cap.

## E9-v6 falsifiable hypothesis and semantic design (rejected)

E9-v6 tests whether a denser but still label-free course ledger, an explicit
agent-versus-system boundary fork, a first-mature-repetition proof, and an
atomic tuple/source decision can close the three observed v5 failure modes
without deterministic semantic assistance. On the unchanged frozen tuning
dry3 panel, it is accepted only if all three outputs are valid, Step Exact is
at least 2/3, Step+Module is at least 1/3, All Correct is at least 1/3, and
there are no hard failures. Its observed 0/3 Step Exact result, with one
successful and two invalid predictions, falsified this hypothesis.

The frozen target protocol is:

1. One scout completion receives up to three complete anonymous compact
   `JudgeView` timelines. For each case it returns one to eight short,
   strictly ordered course checkpoints plus a terminal three-state coverage
   ledger. Checkpoints preserve the first course, substantive course, target,
   or query-policy changes, recommitments to a materially equivalent course
   after feedback, and the final decision. `confirmed_covered`,
   `pending_action`, and `uncovered_visible` are kept distinct. The scout has
   no taxonomy, module, error, root, confidence, score, weight, vote, or
   ranking field.
   Parser limits match the advertised 120/200-character field limits. Each
   normalized case is also capped at 12,000 characters after both its own JSON
   encoding and the enclosing request serializer's second escaping pass; an
   oversized map is isolated as unavailable while the arbiter still reads
   that case's complete timeline. Three accepted maps therefore remain below
   the frozen 40,960-character arbiter reserve.
2. A separate arbiter rereads the complete timeline and treats the scout map
   only as an untrusted navigation aid. For repeated-cycle allegations it
   applies an A/F/R cutoff: an earlier equivalent attempt, feedback already
   visible before the selected output, and the earliest later planning output
   that knowingly recommits without new coverage. Adjacent feedback may show
   effect but cannot retroactively make a reasonable choice erroneous.
3. The arbiter explicitly chooses the agent or system side of a boundary
   fork. A visibly enforced cutoff during coherent distinct coverage, with a
   pending final outcome and no independently proven local agent defect,
   supports terminal `system/step_limit`. An agent root overrides that
   boundary only when the selected owner output itself proves a
   contemporaneous defect and the needed correction is grounded rather than
   imagined.
4. The final step, module, error type, basis, opaque evidence-source ID,
   preview excerpt, ownership comparison, dependent decision, and root cause
   are emitted together in one atomic `decision` object. Immediately before
   returning JSON, the LLM filters the displayed evidence catalog to the
   selected step and module and copies one exact contiguous non-whitespace
   preview substring. Sources are displayed by step and module to reduce
   adjacent-step copying.
5. Code checks only JSON shape, taxonomy, public step/event mapping,
   source/preview containment, and internal agreement among the LLM's own
   `selected_side`, `basis`, optional cycle proof, and final decision. It may
   reject a contradiction but cannot create, mutate, rank, score, vote on, or
   reweight the semantic tuple. There is no format, evidence, or semantic
   repair completion.
6. A malformed individual case is isolated after a valid top-level response.
   A malformed top-level response fails the batch. An unavailable scout case
   does not prevent the arbiter from judging that case's complete timeline.

## E9-v4 falsifiable hypothesis (rejected)

E8's 1/5 dry result suggests that the dominant error is not taxonomy
coverage. The single-pass judge preferred a globally compelling story over
the benchmark's annotated local module defect:

- it retroactively classified reasonable first exploration as an early
  planning error;
- it selected a late wrong answer instead of an earlier task-to-action
  handoff defect;
- it transferred ownership from a same-step memory omission to a difficult
  tool result; and
- it selected the first page/query rather than the later step where repetition
  became demonstrably ineffective.

E9-v3 falsified the narrower hypothesis that forcing an explicit five-module
review was sufficient to recover the annotated step. E9-v4 tested a
chronology-first variant: before assigning module and error type, the LLM
arbiter compared ordinary early exploration, the first
feedback-mature defect, and the terminal boundary, then selected the earliest
causally supported transition rather than anchoring on the first attractive
module candidate. The invalid outputs and all-planning raw choices reject this
hypothesis. The final semantic roots nevertheless remained direct LLM outputs;
there was no deterministic finding, priority, score, confidence, vote, or
repair.

The hypothesis is rejected on the frozen tuning dry3 panel unless all three
outputs are valid, Step Exact is at least 2/3, Step+Module is at least 1/3,
All Correct is at least 1/3, and there are no hard failures.

## E9-v5 semantic design

E9-v4 showed two separable failure modes. First, representative plan/action
pairs in the scout map made planning language disproportionately salient even
though the scout was intended to be label-free. Second, evidence validation
allowed a long source-level quote contract that was difficult for the model
to satisfy and did not force the chosen defect to appear in the short owner
text actually presented beside its source ID.

E9-v5 tests the falsifiable hypothesis that a strictly descriptive coverage
map, followed by an independent arbiter with local ownership, novelty,
maturity, and terminal-boundary invariants, can recover the annotated local
defect without deterministic semantic assistance. On the frozen tuning dry3
panel, the hypothesis is accepted only if all three outputs are valid, Step
Exact is at least 2/3, Step+Module is at least 1/3, All Correct is at least
1/3, and there are no hard failures. The full tuning and smoke gates remain
the preregistered gates below.

The frozen v5 protocol is:

1. One scout completion receives up to three complete anonymous compact
   `JudgeView` timelines. It returns only one to four contiguous strategy
   phases, zero to three evidence-based revisit links, and the observable
   terminal boundary. Phase and revisit items total at most six. The scout
   has no taxonomy, module candidate, error candidate, score, confidence, or
   plan/action-pair field. Distinct feasible targets are new coverage, and a
   revised course is a new phase until its own feedback demonstrates an
   equivalent revisit.
2. A separate arbiter completion rereads every complete timeline and treats
   the scout map as an untrusted navigation aid. It directly emits one final
   `(critical_step, module, error_type, root_cause)` per case plus chronology,
   ownership, boundary, and counterevidence explanations. Four invariants are
   present both in the system instruction and immediately after the complete
   timelines: no hindsight; ownership by the selected module's own output;
   protection of novel coverage and still-live course revisions; and an
   explicit comparison of demonstrated agent correction against the system
   boundary.
3. Planning is eligible only when the plan text is independently defective.
   If a reasonable high-level intent is implemented by the wrong concrete
   tool, query, click, command, argument, or operation, the owner is
   `action/misalignment`. `action/parameter_error` is reserved for the right
   operation category with a missing, malformed, invalid, or unreasonable
   parameter.
4. The arbiter selects one opaque evidence-source ID and copies a contiguous,
   non-whitespace `owner_excerpt` of 1-160 characters from the exact
   128-character preview shown for that source. Short substantive content is
   valid as-is; a complete short owner wrapper may represent an empty body.
   Stitched fragments, ellipses, preview-external text, cross-step evidence,
   and cross-module evidence are rejected. The accepted excerpt becomes the
   reported root evidence; there is no quote repair.
5. Boundary reasoning explicitly reports any directly demonstrated feasible
   agent correction, observable new coverage at termination, and whether the
   final action outcome is visible. These are LLM-produced proof fields. Code
   validates their types but never converts them into a finding, priority, or
   final label.
6. A malformed individual case is isolated after a valid top-level response.
   A malformed top-level response fails the batch. A missing or invalid scout
   case does not block the arbiter from reading that case's complete timeline.
   There is no format-repair or semantic-repair completion.

The only deterministic operations after the provider response are structural
validation, taxonomy validation, public step/event mapping, exact preview and
owner-source containment, persistence, and scoring after gold isolation. They
can reject a response but cannot supply, mutate, rank, vote on, or reweight a
semantic answer.

## E9-v4 frozen semantic design (rejected)

Each provider completion contains at most three anonymous cases.

1. The first LLM rereads each complete compact `JudgeView` and returns only a
   label-free chronology map: at most four contiguous strategy phases, three
   state/strategy revisit links, three representative plan/action text pairs,
   and the observable terminal boundary. It cannot emit a module, error type,
   critical step, root candidate, confidence, or rank. Each case has at most
   eight total map items and short fields so a three-case response remains
   comfortably inside the provider output limit.
2. The arbiter rereads each complete timeline and the untrusted chronology
   map. It directly emits one final `(critical_step, module, error_type,
   evidence_source_id, evidence_quote, root_cause)` record per case, together
   with chronology, owner, terminal-boundary, and counterevidence proofs. The
   proofs are LLM reasoning, not deterministic findings or rankings.
3. The final semantic tuple and evidence quote come only from the arbiter raw
   response. Code checks JSON shape, taxonomy, public step/event mapping,
   opaque evidence-source ownership, and exact quote containment. It never
   changes or supplies a semantic field.
4. An invalid chronology map does not block the arbiter from judging the full
   timeline. A malformed individual case is isolated to that case after a
   valid top-level response; no field is repaired or inferred. A malformed
   top-level response still fails the whole batch. There is no evidence-repair
   or format-repair completion.

Observable AgentErrorBench execution metadata is available as neutral trace
evidence. It is not converted into a `step_limit` finding. Missing benchmark
module tags are likewise neutral: for untagged OpenClaw output, the complete
assistant output is an owner-neutral evidence carrier and module ownership
remains an LLM decision.

## Gold isolation and evidence

Prediction consumes only the hash-locked, reversible, gold-free
`PredictionManifest`. Dataset labels are loaded only by the independent
scoring phase after raw stage artifacts and unscored predictions are closed.
No gold field, case-level score, prior prediction, or gold-derived ordering
may enter planning, seeding, prompts, cache keys, prediction, validation, or
promotion input.

Evidence sources have opaque content-addressed IDs. The v13 Arbiter copies an
exact quote from the full timeline; only after the response does code bind an
exact same-step/module source ID for provenance. The prompt prefers a short
decisive quote, but validation has no length cap. It can reject a forged,
ambiguous, or wrong-owner quote, but cannot derive, replace, or re-rank the
Arbiter's step/module/type.

Held-out smoke is one-shot. Before the single formal execution, only
gold-free aggregate planning facts such as batch count and maximum serialized
request size may be inspected. The v13 source snapshot, smoke plan,
preregistration, authorization chain, empty cache state, and cumulative call
budget must be frozen first. After execution, raw artifacts and unscored
predictions are closed before the scorer loads labels. Smoke is not rerun or
tuned from per-case trajectories, IDs, labels, predictions, alignments, or
errors; only the preregistered aggregate metrics determine acceptance.

For audit completeness, two earlier hygiene incidents are recorded without
using their contents for v7 through v13 design: an earlier baseline metrics
file exposed nested per-case smoke rows, and a later plan-header inspection
displayed a few held-out trajectory IDs. No held-out trace, label, or
prediction from either incident was used to alter v7 through v13 prompts,
semantics, batching, or code.

## Batch and call budget

The planner is deterministic, gold-free, limited to three cases, and measures
the final serialized scout and arbiter prompts. It uses:

- maximum request size: 800,000 characters;
- reserved semantic-candidate-bundle growth in the Arbiter prompt:
  40,960 characters;
- a frozen dry3 seed batch reused byte-for-byte by full tuning; and
- manifest-order greedy packing for the remaining cases.

The frozen E9-v13 gold-free aggregate plans contain 11 tuning batches and
11 smoke batches. Dry3 is the first tuning batch and starts with an empty
cache, so both its fresh atomic-taxonomy-pair Scout and Arbiter are misses:

- dry3 plan SHA-256:
  `b943a0148b073135a242a96be3511a930679b1c82ae4e4945bd72b817e5c26b0`,
  file SHA-256
  `290a1daeb8cb879a621a3062a8b7848d1e0b349a4d426b1e62e94ad6ded88f3a`,
  one batch, maximum estimated request size 624,483 characters;
- full tuning plan SHA-256:
  `201c2688f1fa72b445d3a5645ebf571365fd644d946fc2cfdcd7bab161cee2d9`,
  file SHA-256
  `247af86a75d12f2369c83e2f5da82e270b15de7ec12281f1b97e1794820faa43`,
  eleven batches, maximum estimated request size 661,609 characters;
- held-out smoke plan SHA-256:
  `debe54754e421658b1bed6c698baba7c059d0aeda10ad62962a205e528ace3b3`,
  file SHA-256
  `e6c3b0b1fcbea0f457864e26acfc894d3041993847749e664cbd2f346dca5b65`,
  eleven batches, maximum estimated request size 732,723 characters;

- rejected v7 dry3: 1 logical completion already consumed, `333 → 334`;
- rejected v8 dry3: 1 logical completion already consumed, `334 → 335`;
- rejected v9 dry3: 1 logical completion already consumed, `335 → 336`;
- rejected v10 dry3: 1 logical completion already consumed, `336 → 337`;
- rejected v11 dry3: 1 logical completion already consumed, `337 → 338`;
- rejected v12 dry3: 2 logical completions already consumed, `338 → 340`;
- v13 dry3: at most 2 new logical completions, `340 → 342`;
- promoted v13 full tuning: 20 new logical completions across the remaining
  ten batches, `342 → 362`; the first batch reuses both dry stage results;
- held-out smoke: 22 new logical completions across eleven fresh two-stage
  batches, `362 → 384`;
- total v13 additions: at most 44 if every gated stage is attempted;
- E9-v1 used 2 completions, ending at 323;
- E9-v2 used 2 completions, ending at 325;
- E9-v3 used 2 completions, ending at 327;
- E9-v4 used 2 completions, ending at 329;
- E9-v5 used 2 completions, ending at 331;
- E9-v6 used 2 completions, ending at 333;
- E9-v7 used 1 completion, ending at 334;
- E9-v8 used 1 completion, ending at 335;
- E9-v9 used 1 completion, ending at 336;
- E9-v10 used 1 completion, ending at 337;
- E9-v11 used 1 completion, ending at 338;
- E9-v12 used 2 completions, ending at 340.

The implementation ceiling is 384, but the current explicit user-authorized
absolute ceiling is 380. That authorization covers v13 dry and, if promoted,
full tuning through cumulative 362. It does not authorize smoke: a smoke
preregistration or provider call must fail closed until the user explicitly
authorizes at least 384.

The required cache topology is part of the budget contract:

- dry3: fresh empty cache, Scout miss, Arbiter miss;
- full tuning first batch: scout hit, arbiter hit;
- full tuning remaining batches: one scout miss and one arbiter miss each;
- smoke: fresh cache, one scout miss and one arbiter miss in every attempted
  batch.

Actual messages are checked against the size ceiling immediately before any
completion. HTTP retries inside one provider completion do not increase the
logical-completion count, but are reported separately. No phase may exceed
its preregistered hard stop (`342`, `362`, or `384`), and no new logical
completion may make the cumulative count exceed the explicit authorization
frozen into that phase's preregistration.

## Promotion gates

Dry3:

- denominator 3, successful 3, failed 0;
- Step Exact at least 2;
- Step+Module at least 1;
- All Correct at least 1.

Full tuning and held-out smoke:

- denominator 30, successful at least 29, failed at most 1;
- Step Exact at least 12;
- Step+Module at least 3;
- All Correct at least 3;
- semantic mutation count 0;
- raw-chain reconstruction and gold-isolation checks pass.

Smoke may be claimed only after accepted dry and full promotions. Its cache
must be fresh and every attempted stage must be a cache miss.

## Interpretation boundary

The arbiter prompt intentionally calibrates to AgentErrorBench's released
annotation convention, including the possibility that a local module defect
remains annotated after a same-turn recovery. Passing this benchmark would
show smoke-set consistency, not generalization to arbitrary real OpenClaw
sessions. The tag-free projection and evidence contract are designed to
remain usable on OpenClaw, but that requires a separate real-trace benchmark.

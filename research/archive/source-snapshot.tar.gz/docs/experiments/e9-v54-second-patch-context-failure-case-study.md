# E9 v54 second patch-context failure case study

## Failure and attribution

The second combined prompt patch was rejected atomically. Two adjacent
`sed` ranges both printed their shared boundary line, which was mistakenly
encoded as a duplicated source line in the patch context. The source itself
contains only one such line.

The earlier independent constants patch remains valid; none of this failed
patch's prompt changes were applied. No provider call occurred.

## Correction

Patch the candidate function name, body sections, call site, parser mapping,
and Selector text as separate hunks using context copied from one non-overlap
source view. Then run focused tests before freezing any experiment.

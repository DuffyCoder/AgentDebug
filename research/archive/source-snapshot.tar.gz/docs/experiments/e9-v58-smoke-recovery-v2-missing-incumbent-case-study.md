# E9 v58 smoke recovery v2 missing-incumbent case study

## Closed attempt boundary

Recovery v2 passed the three formerly oversized Critic request preflights and
made three new logical calls:

- ordinal 25: batch-2 Critic, success;
- ordinal 26: batch-2 Reviewer, success;
- ordinal 27: batch-3 Critic, persisted `invalid_json`.

The durable source ledger is 27/44. Five unscored rows from batches 1 and 2
are persisted. Batch 3 has no Reviewer request, no prediction rows, and no
gold access. The v2 process stopped with `fresh v30 and v13 both lack an
incumbent root` before another provider boundary.

## Raw-output diagnosis

The batch-3 Critic returned one JSON object surrounded by a Markdown
`json` fence. The frozen strict parser therefore persisted the whole stage as
`invalid_json`; retry is disabled and the raw artifact is immutable.

For attribution only, removing the single outer fence and applying the same
case-isolated semantic validator yielded:

- C01: a valid Critic root; Arbiter fallback is null;
- C02: a valid Critic root; Arbiter fallback is null;
- C03: invalid evidence ownership; Arbiter fallback is null.

Thus accepting Markdown fences would not make the complete incumbent table
valid. C03's emitted evidence source is not owned by its selected step/module.
Repairing that source, inventing a fallback root, or changing the Reviewer to
an open-ended no-incumbent prompt after observing heldout output would change
the semantic method and contaminate the heldout evaluation.

## Attribution

The frozen smoke harness assumed every case would have either a valid v30 root
or a valid v13 fallback. It had no preregistered fail-closed row transition for
the state where both are absent. The Critic format failure exposed this missing
state-machine branch. The v58 incumbent-copy hypothesis is undefined for such
a case; it has not produced a final semantic judgment for batch 3.

## Conservative recovery v3

Recovery v3 will not parse or repair the fenced Critic output and will not call
a Reviewer for batch 3. It will persist all three batch-3 trajectories as
invalid predictions with `missing_valid_incumbent`, keep them in every fixed
denominator, and resume the unchanged Critic/Reviewer flow at batch 4.

The expected maximum final topology becomes 43 calls rather than 44: the
original 22 upstream calls, 11 Critic calls, and at most 10 Reviewer calls.
If any later newly called stage is non-success, recovery must stop before the
next provider call for another case study. Complete raw-chain validation still
precedes the first gold access. This is conservative failure accounting, not a
semantic fallback or score repair.

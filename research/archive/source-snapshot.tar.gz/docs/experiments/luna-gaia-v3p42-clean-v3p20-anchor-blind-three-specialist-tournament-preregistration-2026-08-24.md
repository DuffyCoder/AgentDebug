# Luna GAIA v3.42 preregistration

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.42-clean-v3.20-anchor-blind-three-specialist-tournament`
- Direct semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: v3.20, Step Exact `25/50`
- Acceptance: Step Exact `>25/50`; Goal completion: Step Exact `>=30/50`
- Frozen `gaia-paper-v1` 50 cases; dataset SHA-256 `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`; cohort SHA-256 `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- `gpt-5.6-luna`, reasoning `medium`; no smoke gate; full GAIA-50 after offline validation.

Single major mechanism: retain the clean v3.20 anchor, packet-state ledger, and
checkpoint unchanged. Add one anchor-blind candidate-generation and tournament
contract with three mutually exclusive evidence specialists: literal
state-truth/handoff, post-feedback strategy maturity, and direct
alignment/task-predicate contradiction. One fresh specialist-panel session
inspects the full trace without seeing the anchor and may freeze at most one
complete legal prediction per class, with no duplicate Step. A fresh bounded
selector sees only the clean anchor and up to three frozen exact-copy
candidates, defaults to the anchor under uncertainty, and may select only one
existing prediction. The candidate pool is therefore capped at four Steps.

The v3.41 frozen result is the immediate falsifiable basis. It was fully legal
at Step Exact `23/50`; its fresh anchor also scored `23/50`. The owner census
emitted 48 candidates but only two formal proposals, neither exact; its
anchor-plus-candidate oracle was `23/50` and it made one wrong-to-wrong change.
On five audited errors the released Step contained a locally typed owner that
was demoted before export because one global `critical_candidate` was reserved
for an anchor-aligned owner from another evidence class. Across earlier clean
experiments, isolated observable-impact and typed challengers produced direct
Step gains with no direct override regressions, but their useful cases were not
identical. v3.42 tests whether class-independent recall preserves those
complementary candidates before selection.

Expected gains are candidate-recall and typed-owner-demotion errors covered by
the three literal classes. The main regression risks are selector overrides of
incumbent-correct direct execution anchors, initial probes misclassified as
intrinsic incapability, and candidate flooding from loose repetition rules.
Controls are anchor blindness during recall, exactly three mutually exclusive
lanes, one candidate per lane, no duplicate Step, explicit literal falsifiers,
exact-copy-only selection, and default keep. A raw tool failure cannot own a
strategy candidate; normal failure, recovery, harmless state compression,
faithful propagation, terminal symptoms, and query/source name heuristics are
vetoed.

v3.37, v3.39, v3.40, v3.41, and all other rejected versions remain immutable
and are not semantic parents. Their predictions, prompts, validators, panels,
and selectors are not inherited or visible to inference. v3.42 is implemented
afresh over v3.20 anchor semantics and shared execution utilities. Inference
may not read labels, scores, audits, prior predictions, experiment documents,
case studies, or git history.

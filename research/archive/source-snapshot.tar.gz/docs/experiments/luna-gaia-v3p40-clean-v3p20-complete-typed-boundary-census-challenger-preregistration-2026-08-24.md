# Luna GAIA v3.40 preregistration

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.40-clean-v3.20-complete-typed-boundary-census-challenger`
- Direct semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: v3.20, Step Exact `25/50`
- Acceptance: Step Exact `>25/50`; Goal completion: Step Exact `>=30/50`
- Frozen `gaia-paper-v1` 50 cases; dataset SHA-256 `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`; cohort SHA-256 `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- `gpt-5.6-luna`, reasoning `medium`; no smoke gate; full GAIA-50 after offline validation.

Single major mechanism: keep the clean v3.20 anchor, ledger, and checkpoint
unchanged. Replace only the challenger/adjudication contract with one complete
chronological typed-boundary census. It must classify every observable Step
exactly once with a literal owner/predicate/maturity/veto tuple across
state-truth, post-feedback strategy maturity, alignment, or none; it may freeze
at most one critical candidate across the entire trace. That candidate may be
earlier or later than the anchor. A default-keep exact-copy arbiter may select
only the unchanged clean anchor or that one frozen proposal.

The v3.39 post-score audit supplies the falsifiable basis: its isolated typed
challenger improved its own fresh anchor by three Step Exact cases with zero
direct regressions, but six remaining errors first diverged at challenger
recall. Five missed boundaries were later than the anchor and one was earlier.
The v3.39 anchor-plus-proposal oracle therefore remained only 25/50. Historical
complete-census and bidirectional experiments each produced some direct Step
gains but broader contracts also showed incumbent-relative regressions. v3.40
tests whether validator-enforced complete enumeration plus mutually exclusive
typed maturity/veto closure improves recall without candidate flooding.

Expected gains are the six current challenger-recall errors as a unified
failure mode. The main regression risk is a false earlier or later override of
an incumbent-correct anchor. Secondary risks are declaring a first or
materially different probe mature, treating normal failure as Agent error,
failing to recognize recovery/mechanical repair, and longer census output
causing runtime or validation failures. Controls are exact one-row-per-Step
coverage, one critical candidate maximum, explicit witness binding, probe/
normal-failure/recovery/faithful-propagation vetoes, and default keep under
uncertainty.

v3.39 remains rejected and immutable. Its prompt, predictions, challenger
records, and arbiter records are not inherited or visible to inference. The new
implementation is rebuilt from v3.20 semantics; only the single census
hypothesis is ported. Inference may not read labels, scores, audits, prior
predictions, experiment documents, case studies, or git history.

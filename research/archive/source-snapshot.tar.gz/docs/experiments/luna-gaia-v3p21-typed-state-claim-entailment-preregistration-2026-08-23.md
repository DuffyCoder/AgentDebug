# Luna GAIA v3.21 Typed State-Claim Entailment Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia-v3.21-typed-state-claim-entailment`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Frozen incumbent Step Exact: `25/50`
- Original v3.4 baseline Step Exact: `21/50`
- Version acceptance: `Step Exact > 25/50`
- Goal completion: `Step Exact >= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Frozen v3.20 predictions SHA-256: `9df734d95a7c338a9b8ce66fb4d91e16d69961d272ddcc926f7d11f3ddc8add8`
- v3.20 Step audit SHA-256: `b1c0647d5081a85f469027152ad9d29d674d4fdb8db520cfaed43ddf5921f550`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the only optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module/type/evidence remain legality constraints only.

## Post-score diagnosis motivating this version

v3.20 became incumbent at 25/50. Its packet-state gate admitted seven rows and
four were Step-exact. The remaining 25-error audit exposes both sides of the
same semantic imprecision:

- four High-confidence gold state boundaries were marked `faithful` even though
  they contain a necessary-fact omission, unsupported entity relation, or
  result-contradicting outcome claim;
- one incumbent-correct boundary regressed because a provisional explanation
  of why a query returned irrelevant content was labeled `unsupported_fact` as
  if it were an answer-state assertion.

The free-form fidelity category does not force the Judge to identify what kind
of claim is being checked. This version replaces that category with one typed
claim/relation pair; it does not add a second mechanism.

## Single major change

Replace the v3.20 state prefix and free-form fidelity decision with:

```text
state_claim_kind=<none|necessary_fact|entity_relation|outcome_claim|query_hypothesis>;
state_relation=<not_applicable|entailed|omitted|unsupported|contradicted|compatible>;
```

Binding pairing and admission rules:

1. `none` pairs only with `not_applicable` when no Memory/Reflection state is
   task-material in the packet; Lane A must be `clear`.
2. `necessary_fact` identifies one concrete result fact needed for the unresolved
   subgoal or next decision. It pairs with `entailed` or `omitted`; `omitted`
   requires Lane A `candidate`, while `entailed` requires `clear`.
3. `entity_relation` identifies a concrete task-answer entity/value/credential/
   relation asserted as evidence and consumed downstream. It pairs with
   `entailed` or `unsupported`; `unsupported` requires Lane A `candidate`.
4. `outcome_claim` identifies a success, failure, progress, or constraint claim
   about adjacent feedback. It pairs with `entailed` or `contradicted`;
   `contradicted` requires Lane A `candidate`.
5. `query_hypothesis` identifies an explicitly provisional explanation of why
   retrieval was irrelevant or failed. It pairs with `compatible` or
   `contradicted`; `compatible` requires Lane A `clear`. It is never converted
   to an unsupported answer fact merely because it is not proven.
6. A non-clear relation is admitted only when the affected state feeds the
   current/next plan and repairing it can change the later path.
7. All v3.20 non-state lanes, vetoes, chronological freeze, single later
   challenger, and default-keep exact-copy arbiter remain unchanged.

No acquisition gate, hard-disqualifier taxonomy, candidate pool, global
selector, earlier challenger, case router, entity/site rule, historical
prediction, or gold information is added.

## Falsifiable prediction

The typed pair should improve recall of concrete state claims while rejecting
provisional-hypothesis false positives.

Post-score expected direct coverage is five missed state boundaries plus one
state-gate regression recovery. Observable checks:

- every anchor row has a valid typed prefix;
- every kind/relation pairing is legal;
- `omitted`, `unsupported`, and `contradicted` on non-hypothesis claim kinds
  require Lane A `candidate`;
- `entailed`, `compatible`, and `none/not_applicable` require Lane A `clear`;
- at least one full-run row exercises a non-clear state relation;
- Step Exact gains exceed losses relative to v3.20 and the result exceeds
  `25/50`.

The hypothesis is falsified if the five audited claim boundaries remain clear,
if query hypotheses are still promoted as unsupported answer facts, if typed
claim scanning causes early candidate flooding, or if Step Exact is `<= 25/50`.

## Gain and regression analysis

Expected gains:

- necessary titles, values, or provenance omitted from retained state;
- unsupported entity-to-credential/value relations consumed downstream;
- false success/progress claims contradicted by the adjacent result;
- recovery of a compatible query-quality hypothesis incorrectly frozen by
  v3.20.

Primary regression risks:

- choosing the wrong single claim kind when a packet has several statements;
- treating harmless compression as `omitted`;
- treating an explicit hypothesis as a concrete entity relation;
- losing incumbent-correct v3.20 state admissions through over-narrow pairing;
- systematic early selection from typed-claim prompt salience.

The closed compatibility matrix, concrete-answer-state requirement, downstream-
use test, literal adjacent-result check, and validator-enforced Lane-A relation
limit those risks. The rule is uniform and does not depend on trajectory IDs,
entities, sites, source models, or fixed Steps.

## Execution and acceptance protocol

1. Implement the versioned prompt, typed-pair validator, runner, and negative
   tests.
2. Run offline tests and source scans only; do not run a smoke gate.
3. Execute all 50 frozen cases with three fresh serial sessions per case and at
   most four cases concurrently.
4. Freeze all predictions and intermediate artifacts after 50/50 completion and
   gold-free validation.
5. Only then load released labels and score all 50 cases.
6. Compute Step Exact and transitions against v3.4 and v3.20.
7. Accept only if Step Exact is strictly greater than `25/50`; complete the Goal
   only if it is at least `30/50` and every legality/freeze check passes.
8. Otherwise reject the immutable version, audit every Step error, and create a
   new version from one next unified mechanism.

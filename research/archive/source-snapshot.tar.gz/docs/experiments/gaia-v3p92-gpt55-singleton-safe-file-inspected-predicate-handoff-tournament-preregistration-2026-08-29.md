# GAIA v3.92 GPT-5.5 singleton-safe file-inspected predicate-handoff tournament preregistration

Date: 2026-08-29

## Frozen identity

- Version: `agentdebug.codex-agent-judge.gaia-v3.92-gpt55-singleton-safe-file-inspected-predicate-handoff-tournament`.
- Direct semantic parent: accepted v3.83, Step Exact `26/50`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Dataset manifest identity SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort identity SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Cohort manifest file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Frozen v3.83 protocol SHA-256: `a97908a78cec8df5fe9e4777d30aa9ecf498d1cdd1d692a42cc66976e9844531`.
- Frozen v3.83 predictions SHA-256: `f74161b06c456461ccacdcf7c708157154e8e9810cb5dffa8ef09352698fca3d`.
- Model and reasoning effort: `gpt-5.5` / `medium` for both stages.

## Prior evidence and first divergence

The semantic hypothesis remains the clean v3.83 tournament hypothesis first
preregistered for v3.90. v3.80 is the only historical mechanism with a native
anchor-plus-ledger Step oracle above the Goal threshold (`31/50`), but its final
selector scored only `17/50`. v3.90 showed that the direct embedded prompt is
not runnable for the longest case under the local 272,000-token endpoint limit.
v3.91's uniform file transport fixed that exact context failure, including the
previously failing long case, but the run stopped gold-free at `37/50` valid.

The first divergence for all 13 v3.91 failures is runtime/validation rather than
Step selection. Six selected anchor ledger rows copied execution metadata or a
whitespace-normalized preview instead of a contiguous same-Step owner quote.
The other seven were singleton ledgers: there was no strict-prefix alternative,
yet the inherited tournament schema required the model to manufacture a
complete critical winner row. All 13 are structurally forced to keep the sole
anchor Step, so the following repair cannot alter their selected Step.

## One semantic mechanism and Step-invariant runtime repair

The only semantic mechanism changed relative to accepted v3.83 is:

- retain v3.83's GPT-5.5 packet-state anchor and native chronological ledger;
- replace its one-proposal challenger/default-keep arbiter tail with one
  outcome-conditioned exact-predicate handoff tournament over every native
  ledger Step;
- select exactly one anchor-or-prefix winner and freeze an exact copy.

The lossless owner-explicit JudgeView is staged through the same uniform bounded
read-only inspector introduced in v3.91. Two validator/materialization changes
make that one mechanism executable without changing a model-selected Step:

1. the selected anchor ledger quote is deterministically copied from a
   contiguous assistant or adjacent-feedback string in that exact Step packet;
2. a singleton ledger is a vacuous keep-anchor tournament: it may contain zero
   semantic rows or one honest noncritical anchor row, but it must keep the sole
   anchor Step. Every non-singleton and every prefix override retains the full
   original tournament constraints.

These are uniform structural conditions, not case, entity, source-model, or
gold routers. No v3.91 prediction is reused.

## Falsifiable hypothesis and impact analysis

The tournament may improve incumbent errors when the correct critical boundary
is already represented by a native prefix candidate but the v3.83
challenger/arbiter tail fails to compare it globally. The expected gain is
therefore concentrated in candidate-present selection failures, not in cases
where the native ledger omitted the needed Step.

The principal regression risk is an overall earlier shift: an informative but
reasonable acquisition probe may be treated as a mature predicate handoff just
because later Steps inherit the evidence gap. Additional risks are false
confidence from timeline previews and candidate flooding on long ledgers. Exact
owner evidence, complete ledger review, strict non-singleton winner constraints,
and an exact-copy freeze are the direct falsifiers. The singleton repair itself
has zero Step gain and zero Step regression capacity because no alternative Step
exists.

Reject the version if Step Exact is `<=26/50`, if gains are offset by early-probe
regressions, if any of 50 cases is incomplete, or if any legality/access audit
fails. Oracle analysis and case-level transitions are post-score diagnostics
only.

## Acceptance and Goal completion

- Accept only if Step Exact is strictly greater than `26/50` and every legality check passes.
- Complete the Goal only if Step Exact is at least `30/50` and every legality check passes.
- Only Step Exact selects, accepts, rejects, or completes versions.
- No smoke gate is used; after offline validation run the complete GAIA-50 directly.

## Pre-inference freeze

- Protocol source SHA-256: `67967fe7d7471bb72cf2a77d31d74e08a310843025dc7931837e47a827612711`.
- Runner source SHA-256: `aa5dc597bfbdd78d1ea32b19901182ad78257674aa73d669500ba695e4778c81`.
- Inspector source SHA-256: `556e8fe1e77186a55521f74734b05d35a33fe482a50d30b5bc21ce7ef02f7677`.
- Negative/identity test source SHA-256: `838a9184a291bff91a0db443b7f18aa405de92ec8450a72ba8e10859fb97d3e0`.
- Offline validation: compilation passed; 18 targeted and inherited tests
  passed; direct-parent identity, same-Step evidence repair, singleton empty-row
  and forced-keep negatives, inherited tournament behavior, registry, and
  50-case dry preparation passed.
- Static inference-source scan found no labels, metrics, scored artifacts,
  historical predictions, trajectory/entity router, or post-score audit reader.


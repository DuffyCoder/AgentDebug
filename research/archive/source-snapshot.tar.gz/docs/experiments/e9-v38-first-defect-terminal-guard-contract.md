# E9 v38 first-defect terminal-guard contract

## Falsifiable hypothesis

Restoring the historically best first-defect and distinct-state terminal
guard contract will recover at least the two previously stable dry3 exact
localizations while retaining strict JSON, source-ID evidence projection, and
independent final LLM selection.

v38 removes v37's broad rule that search becomes inefficient at the first
recommitment after generic no-progress evidence. It distinguishes material
repetition from applying the same feasible operation to a new target or
state. It also restores the capability boundary for aggregate/dynamic
representations that visibly cannot expose required collection ordering or
change-history facts.

## Authority and topology

Candidate and frozen incumbent remain untrusted LLM hypotheses. The raw
Selector response is the sole source of critical step, module, error type,
and root cause. Deterministic code only validates and projects evidence.

The v37 rejected dry3 run consumes cumulative calls 483 through 485. The v38
phase topology is therefore:

- dry3: 485 to 487, at most two calls;
- full30 after accepted dry3: 487 to 507, at most twenty new calls;
- held-out smoke after accepted full30: 507 to 551, at most forty-four calls.

# E9-v31 recovery: full-suite invocation failure case study

## Attempt

The freeze check invoked `pytest -q` from the repository root after the
standalone v31 recovery script had passed compilation and its read-only source
boundary check.

## Observed failure

Pytest stopped during collection with 37 identical import failures:
`ModuleNotFoundError: No module named 'agentdebug'`. No test body ran, no
benchmark artifact changed, and no external LLM call occurred.

## Root cause

This checkout is not installed into the active Python environment. Invoking
the `pytest` console entry point exposes its installation directory on
`sys.path`, but does not guarantee that the current repository root is an
import root. The project test suite therefore requires the repository root to
be supplied explicitly as `PYTHONPATH=.` (or an equivalent editable install).
This is a test-harness invocation error, not an implementation failure.

## Correction

Run the single freeze regression as `PYTHONPATH=. pytest -q`. Do not change
application code or the recovery protocol in response to this collection-only
failure. The next external call remains prohibited until that corrected suite
passes.

# E9-v22 Dry3 Failure Case Study

## Attempt and formal result

E9-v22 used `deepseek-v4-flash`, the default request body, and one logical
completion from cumulative 370 to 371.  The response required one HTTP
attempt, no retry, and ended with `finish_reason=stop`.  All three cases were
valid; no brace repair or evidence-text transcription was needed.

The semantic promotion gate still rejected the run at 1/3 Step,
Step+Module, and All Correct.

## Per-case attribution

| Case | Official root | V22 root | Attribution |
| --- | --- | --- | --- |
| C01 | step 30, `system/step_limit` | step 16, `planning/inefficient_plan` | Regression.  The model described opening cabinets 8-16 as "reopening" them, although these were previously unobserved valid receptacles.  This converted genuine state coverage into a fictitious loop and displaced the correct terminal boundary. |
| C02 | step 1, `action/misalignment` | step 1, `action/misalignment` | Corrected.  The dynamic collection-page representation rule caused the model to retain the incumbent, and source-ID evidence remained exact. |
| C03 | step 13, `planning/inefficient_plan` | step 23, `planning/inefficient_plan` | Over-correction.  The model treated every later reordered or shortened query as a fresh recovery, although several were exact or near duplicates of already failed queries.  It kept restarting the search episode and delayed the root to the final pagination block. |

## Root attribution and next bounded change

The recovery concept is useful for C02 and for rejecting step 6 in C03, but
v22 made it too permissive and allowed the required candidate checkpoint to be
null.  E9-v23 therefore makes three bounded changes while preserving the v21
format boundary:

1. inspecting a previously unobserved, admissible container or state is new
   coverage, not repetition, unless direct evidence says the state class is
   irrelevant;
2. the first deliberate query reset may recover initial pagination, but an
   exact or semantically near-duplicate of any already failed query is not a
   later recovery merely because its words are reordered or shortened; and
3. `earlier_candidate_step` becomes mandatory.  The final root must be that
   unrecovered candidate or a defect after the recorded recovery.

The next dry3 costs one logical completion from 371 to 372.  Full30 would then
end at 382 and remains unauthorized under the current ceiling of 380.

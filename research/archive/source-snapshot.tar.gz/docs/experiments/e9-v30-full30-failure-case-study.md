# E9 v30 full30 failure case study

## Outcome

v30 passed dry3 at 2/3, but its full30 tuning result did not reach the
preregistered semantic threshold:

- Step Exact: 10/30 (33.33%; gate requires 12/30)
- Step+Module Exact: 5/30 (gate requires 3/30)
- All Correct: 4/25 (gate requires 3/25)
- Successful outputs: 29/30 (gate requires 29)
- Failed outputs: 1/30 (gate permits 1)
- New logical completions: 10
- HTTP attempts: 10, with zero retries

Only `step_exact_minimum_correct` failed. Held-out smoke must not run.

## Format attribution

All eleven batch envelopes were strict JSON and no response used a thinking
configuration or deterministic semantic repair. The sole case-local failure
was `GPT-4o_011_memory_b001_t00_e03-21a3a421`: its `root_cause` contained 785
characters against the still-frozen 768-character root-cause cap. v30 had
raised only `causal_basis` to 1024, so it removed v29's explanatory-field
failure but exposed the same artificial limit in the final explanation. The
selected step, taxonomy pair, and evidence ID were otherwise present in raw.

This is a validation-boundary loss rather than invalid JSON. A later version
may align both explanatory limits at 1024, but must not repair or rescore the
frozen v30 artifact.

## Semantic attribution

The environment breakdown changed from v29's ALFWorld 3/10, GAIA 5/10,
WebShop 1/10 to ALFWorld 2/10, GAIA 4/10, WebShop 4/10. The first-defect audit
therefore helped WebShop substantially, but displaced several previously
correct ALFWorld and GAIA choices. The net gain was only one exact step.

The predictions are not stable even with temperature zero. Relative to v29,
v30 gained five exact cases and lost four exact cases. The exact-step union of
the independently generated v29 and v30 outputs is 14/30, while neither
single output exceeds 10/30. This is direct evidence that the remaining
bottleneck is final candidate selection, not absence of useful candidates.

Three failure patterns recur:

1. A single long prompt asks one Flash completion both to generate competing
   roots and select among them. Small wording changes move the selected step
   across early, repeated, and terminal candidates.
2. The first-defect rules over-correct toward an early plausible event in
   some cases. They need an independent causal-sufficiency challenge, not
   another unconditional preference for earlier steps.
3. One monolithic final decision has no way to preserve two independently
   defensible candidates and ask a separate judge to compare them.

## v31 optimization direction

Before another model attempt:

1. Preserve the v29 terminal-guard candidate lane and the v30 first-defect
   candidate lane as two separately identified, raw LLM outputs.
2. Add a final Flash selector stage that sees the trace evidence and both
   candidate roots, challenges each candidate for chronological priority and
   causal sufficiency, and emits the complete atomic final tuple. The selector
   must not receive gold, scores, historical correctness, or deterministic
   candidate weights.
3. For tuning, bind and reparse the already paid v29/v30 raw candidates; for
   held-out smoke, generate both lanes fresh before the selector. This keeps
   the selection mechanism identical while avoiding duplicate tuning calls.
4. Raise both `causal_basis` and `root_cause` text caps to 1024 and state them
   in the output contract. Invalid candidates remain explicit null lanes; no
   prior or other candidate may silently replace a failed final selector.
5. Preregister exact topology-derived budgets with no global authorization
   ceiling. Run dry3 first, then full30 only after dry acceptance. Any failed
   attempt again requires a case study before another model attempt.

No v30 artifact may be mutated or rescored under the v31 parser.

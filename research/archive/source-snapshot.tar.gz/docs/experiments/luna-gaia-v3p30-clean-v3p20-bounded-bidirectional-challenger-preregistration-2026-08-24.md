# Luna GAIA v3.30 Clean-v3.20 Bounded Bidirectional Challenger Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.30-clean-v3.20-bounded-bidirectional-challenger`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: v3.20, Step Exact `25/50`
- Original v3.4 baseline: `21/50`
- Acceptance: `Step Exact > 25/50`
- Goal completion: `Step Exact >= 30/50`
- Dataset: frozen `gaia-paper-v1`, 50 cases
- Dataset/cohort semantic SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11` / `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Model/effort: `gpt-5.6-luna` / `medium`
- Smoke gate: none

## Single major change

Keep the complete v3.20 packet-state anchor unchanged. Replace only its
later-only challenger with one bounded bidirectional challenger:

- first scan strictly earlier than the anchor for the earliest literal
  task-material result-to-state or immediate-target-to-Action handoff defect;
- permit an earlier proposal only when the anchor is a downstream symptom and
  the earlier repair changes the path;
- if no earlier boundary qualifies, run the existing v3.20 earliest-causal
  later fallback;
- emit at most one proposal total;
- retain the v3.20 default-keep exact-copy arbiter discipline, extended only to
  validate the legal earlier direction.

This is a clean re-test of the single v3.16 bidirectional mechanism on the
accepted v3.20 packet-state anchor. No v3.21-v3.29 anchor, state ledger,
capability/maturity/contribution gate, case rule, candidate pool, historical
prediction, or result splice is inherited.

## Impact analysis

The v3.20 audit contains nine fine-grained recall errors, including multiple
High-confidence earlier handoff boundaries hidden behind later Planning or
capability symptoms. Expected coverage is those literal omissions,
contradictions, target losses, and false result readings. Incumbent-correct
risks are benign compression, locally false but noncritical earlier wording,
and first-probe bias. The necessity, literal-boundary, path-effect, earliest
only, one-proposal, and default-keep checks are the regression controls.

The mechanism is falsified if no earlier proposal is emitted, earlier proposals
create net regressions, Step Exact is at most 25/50, or any legality/freeze
check fails. Predictions remain gold-free; labels and historical outputs are
available only after the complete freeze.

# GAIA v3.102 GPT-5.5 three-attempt access-validated tournament preregistration

Date: 2026-08-30

- Direct semantic parent: accepted v3.83 (`26/50`).
- Dataset: frozen `gaia-paper-v1` 50; dataset/cohort identities
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11` /
  `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Model/effort: `gpt-5.5` / `medium`.
- Only semantic change from v3.83: the same single native-ledger predicate-
  handoff tournament.
- Runtime-only change from v3.101: maximum fresh attempts per stage is exactly
  three rather than two. Every attempt remains isolated; semantic and access
  validators are unchanged, and rejected attempts cannot enter predictions.
- No smoke gate; full GAIA-50; freeze before labels.
- Reject at Step Exact `<=26/50`; accept above 26; Goal completes at `>=30/50`.

Pre-inference hashes:

- Protocol: `abfd79b4916b5c0085ce8374a8cf62b4057d46d2035a3b458a86ce67f6943a6c`.
- Runner: `dda3e71b2f2621445d10ba8ce15cd26d04d776abbd84934484f470706953f97a`.
- Inspector: `605b1473ff18fe0c7ddadf8f47074e23c689f4328137be297c86c75141a97160`.
- Test: `ab45ff80a79db5c68545a8908fd5ea8f27b4165de87e57bdafe0345ddafd917e`.
- Registry: `8e85e626d9b50e3b48f2c2eaaf037f582012a65e1476adb2419c594072a68f45`.
- Offline: compilation, 50-case dry preparation with `max_attempts=3`, 4 new,
  5 stage-local, and 32 inherited tests passed in isolated processes.

This version is frozen before inference.

# Luna GAIA v3.41 preregistration

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.41-clean-v3.20-owner-factored-boundary-census-challenger`
- Direct semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: v3.20, Step Exact `25/50`
- Acceptance: Step Exact `>25/50`; Goal completion: Step Exact `>=30/50`
- Frozen `gaia-paper-v1` 50 cases; dataset SHA-256 `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`; cohort SHA-256 `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- `gpt-5.6-luna`, reasoning `medium`; no smoke gate; full GAIA-50 after offline validation.

Single major mechanism: keep the clean v3.20 anchor, packet-state ledger, and
checkpoint unchanged. Replace only the challenger/adjudication contract with a
complete owner-factored boundary census. Instead of assigning one mutually
exclusive verdict to an entire Canonical Step, enumerate every observable
Agent-authored Planning, Action, Memory, and Reflection span in literal order.
Each owner receives its own verdict, boundary type, and maturity witness. A raw
tool/site outcome may establish normal failure for the Action owner but may not
erase a same-Step Planning, Memory, or Reflection commitment. After owner-local
probe, normal-failure, recovery, propagation, and noncritical vetoes, freeze at
most one earliest task-material Step candidate. The default-keep exact-copy
arbiter may select only the unchanged clean anchor or that frozen proposal.

The v3.40 frozen result is the falsifiable basis. It completed and passed all
legality validation at Step Exact `22/50`, with fresh anchor `21/50`. Its 45
complete-census candidates scored only `17/50`; anchor-plus-candidate oracle was
only `22/50`. Two accepted proposals caused one direct Step gain, zero direct
regressions, and one wrong-to-wrong move. Thus selection was not the binding
failure. None of the 28 erroneous released gold Steps entered the formal
candidate set. Twelve errors show the new shared recall defect: the single Step
verdict classified gold as `normal_failure` or `faithful_propagation`, masking
an Agent-authored module owner. Ten of those twelve are non-ambiguous under the
current audit; two remain low-confidence annotation ambiguities.

Expected gains are the non-ambiguous owner-collapse cases, especially a
same-Step Agent plan hidden by normal tool feedback and later Agent commitments
hidden by a propagation verdict. The direct regression risks are incumbent-
correct cases containing useful initial probes, normal tool failures, faithful
post-outcome reactions, or several harmless Planning spans within one Step.
Owner enumeration may also exceed the compact artifact limit or cause candidate
flooding. Controls are validator-enforced exact owner coverage, compact bounded
codes, mutually exclusive owner-local types, literal witness binding, one
critical owner maximum, one Step proposal maximum, and anchor-default selection.

v3.40 and every other rejected version remain immutable and are not semantic
parents. No rejected prompt, validator, prediction, challenger, arbiter, or
ledger is inherited or visible to inference. The owner-factored mechanism is
implemented afresh over v3.20 anchor semantics and the shared frozen transport
contract. Inference may not read labels, scores, audits, prior predictions,
experiment documents, case studies, or git history.

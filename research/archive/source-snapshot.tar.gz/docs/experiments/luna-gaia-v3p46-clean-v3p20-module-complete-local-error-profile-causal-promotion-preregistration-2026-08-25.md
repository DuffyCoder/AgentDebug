# Luna GAIA v3.46 preregistration

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.46-clean-v3.20-module-complete-local-error-profile-causal-promotion`
- Direct semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: v3.20, Step Exact `25/50`
- Acceptance: Step Exact `>25/50`; Goal completion: Step Exact `>=30/50`
- Frozen `gaia-paper-v1` 50 cases; dataset SHA-256 `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`; cohort SHA-256 `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- `gpt-5.6-luna`, reasoning `medium`; no smoke gate; full GAIA-50 after offline validation.

Single major mechanism: retain one freshly executed clean v3.20 anchor, its
packet-state ledger, and its Step checkpoint unchanged. Add an anchor-blind,
module-complete local-error profile followed by one anchor-preserving causal
promotion gate. Five mutually isolated profile sessions inspect Memory,
Reflection, Planning, Action, and System over every Step. A profile records
literal local error owner, taxonomy type, adjacent fact, and observable
recovery status, but cannot choose, rank, nominate, or predict a critical
Step. The profiles are an evidence inventory rather than votes or candidates.

One fresh promotion session receives the frozen anchor, all five frozen
profiles, and the current Canonical Trace. It must compare every positive
profile row but may emit only the exact anchor or one complete newly generated
proposal. A proposal may be earlier or later than the anchor. Override is
legal only when the proposed row owns a non-vetoed critical defect,
candidate-only repair changes the task-material failure path, and a symmetric
anchor-only repair test proves that the anchor is a reasonable probe,
noncritical predecessor, or recovered defect. Uncertainty, normal tool
failure, initial/different probe, mechanical repair, faithful propagation,
recovery, and downstream symptom all preserve the anchor by default.

The comparison with the paper's public method motivates the separation. The
paper reports AgentDebug Step `29/50`, versus direct `13/50`, brute-force
`9/50`, and binary `11/50`. Its public two-phase topology performs per-Step,
per-module local classification before global selection. In the frozen local
reproduction, at least one public Phase-1 module marked the released gold Step
positive in `35/50`; the union of that signal with frozen v3.20 exact reaches
`43/50`. This is post-score aggregate evidence only. It supplies neither case
identities nor old predictions to inference.

The same evidence gives the direct negative control: public Phase 1 produces
457 positive Steps and 739 positive module verdicts, averaging 9.14 positive
Steps per case, while its public Phase-2 final selection reaches only `14/50`.
The frozen v3.44 independent-ballot experiment similarly reached candidate
oracle `29/50` but final `13/50`, including 12 direct regressions. Therefore
local positives cannot be passed to an unconstrained vote, earliest-positive
rule, or salience selector. Conversely, frozen v3.39 showed that a conservative
typed override can produce three direct gains and zero direct regressions
relative to its fresh anchor, but its one later-only proposal caps recall.

Expected gains are wrong v3.20 anchors in the aggregate fine-grained-recall,
late-symptom, and early-freeze clusters where a module-local owner was hidden
by cross-module competition. The main regression risk is that plentiful
surface errors, reasonable probes, recovered defects, and downstream symptoms
falsely displace an incumbent-correct anchor. Controls are full fixed module
coverage for every case, isolated anchor-blind profiling, literal owner and
adjacent-fact validation, no profile voting, one proposal maximum, symmetric
repair tests, explicit vetoes, default keep, and exact anchor copying.

v3.21 through v3.45 remain immutable rejected experiments and are not semantic
parents. v3.46 reimplements this one mechanism on clean v3.20 semantics. It
does not inherit any rejected prompt, challenger, ledger, selector, validator,
prediction, case output, or historical decision. Inference may not read
labels, scores, audits, prior predictions, experiment documents, case studies,
or git history.

Diagnostic falsifiers are incomplete five-module/whole-timeline coverage,
profile rows without literal owner evidence, any profile that makes a final
prediction, a promoted Step absent from the frozen profile, an override without
both repair tests and veto assessment, more than one proposal, or an observable
false-override cluster. These diagnostics do not accept the version: the sole
version acceptance rule remains final Step Exact `>25/50`, and Goal completion
remains final Step Exact `>=30/50` after all legality checks.

# E9 v52 recovered full30 semantic failure case study

## Closed attempt

- Experiment: `e9_v52_http402_full30_exact_prefix_recovery`.
- Semantic pipeline: `e9-module-census-v52-deepseek-v4-flash-default`.
- Provider/model: DeepSeek OpenAI-compatible / `deepseek-v4-flash`, default
  request body, temperature 0, one worker.
- Recovery preregistration content hash:
  `071272b532efd6fe755f2133e47d0a52963b478123a9648722e58c79b8f74411`.
- Predict-run content hash:
  `802353ca5658c4e74f0350b9e23ee5d5a2ba5508a7b2d709b6226549aac63e6c`.
- Promotion content hash:
  `a0d2da928235ec3126c33d851f6b6bb013364aa0a68d0438d4d580cac2c43276`.
- Artifact-manifest content hash:
  `b53387bffcdd14b6a297cf6ad3702440e7c7bb1930edaf6b74c213d8758c5e80`.
- Output validity: 30/30 raw Selector predictions succeeded; there were no
  failed rows, retries, semantic mutations, deterministic semantic fallbacks,
  or final-output repairs.
- Result: Step Exact 9/30 (30.0%), Step+Module Exact 5/30, and All Correct
  4/25. The preregistered Step Exact minimum of 12/30 was the only failed
  promotion check.

This is the final, denominator-complete result of the exact v52 HTTP-402
recovery. It replaces the partial 21-row estimate for semantic decisions, but
does not erase or rewrite the earlier provider-failure record. V52 is rejected
and must not be promoted to the held-out smoke cohort.

## Exact recovery and usage audit

The recovery imported the immutable successful prefix into a disjoint cache
and issued exactly the eight preregistered completions for batches 8 through
11: four Critic and four Selector requests. All eight requests returned
`finish_reason=stop` in one HTTP attempt each.

- Recovery logical ledger: 8/8 entries, content hash
  `68dbbd6624ca69e224cbba91299d6327004528ebfeb0467a6f86c3a53a1a7660`.
- Current-run HTTP attempts: 8; retries: 0.
- Current-run provider usage: 1,602,677 input, 146,048 output, and 1,748,725
  total tokens.
- Current-run request input: 5,573,262 characters.
- Recovery cache: 42 files before execution and 66 files afterward, matching
  the exact eight new stage responses and their sidecars/parsed records.
- The run began at the historical cumulative count 632 and ended at the
  phase-exact stop 640. This number is an audit ordinal, not a provider quota
  or a new global authorization cap.

## Comparison with v51

V52 made a real but insufficient improvement over the complete v51 result:

| Metric | v51 | v52 | Change |
|---|---:|---:|---:|
| Step Exact | 7/30 | 9/30 | +2 |
| Step+Module Exact | 3/30 | 5/30 | +2 |
| All Correct | 3/25 | 4/25 | +1 |
| ALFWorld Step | 3/10 | 3/10 | 0 |
| GAIA Step | 4/10 | 4/10 | 0 |
| WebShop Step | 0/10 | 2/10 | +2 |

At the case level, six Step-correct rows stayed correct, three v51 misses
became correct, one v51 correct row regressed, and twenty rows remained wrong.
On the twelve trajectories not semantically observable in the earlier partial
analysis, v51 had one correct Step and v52 had three. That gain completed the
run at 9/30 rather than the required 12/30.

V52 also removed v51's large late-step bias. Of v52's 30 predictions, nine
are early, nine exact, and twelve late; mean signed error is +1.77 steps. V51
had eighteen late misses and a +9.0 mean signed error. The new first-error
wording therefore changed temporal behavior in the intended direction, but
exact localization did not improve enough.

## Candidate recall versus final selection

The principal bottleneck is now directly measurable:

- Any supplied candidate at the released Step: 14/30.
- Any supplied candidate at released Step+Module: 7/30.
- Final Step Exact: 9/30.
- The exact Step was absent before final selection in 16/30 cases. All sixteen
  remained wrong.
- Five cases exposed the exact Step but the raw Selector chose another Step.
- Nine cases exposed the exact Step and the Selector chose it.

Thus candidate recall puts an observed 14/30 ceiling on merely choosing among
the existing hypotheses. Selector policy still matters in five cases, but it
is not the dominant source of the 21 final errors. Improving only the
Selector could at most reach 14/30 on this frozen candidate set and would
have to correct at least three of five selection misses without regressing
any current correct row.

The source-level post-score audit is consistent with that attribution. The
current v52 Critic independently includes the released Step in 11/30 cases;
the frozen Scout does so in 7/30 and the frozen prior root in 6/30. Their
unscored union is 14/30. This diagnostic is not a vote, score, fallback, or
replacement prediction.

## Planning compression is the dominant recall loss

Candidate recall by released module is sharply asymmetric:

| Released module | Cases | Step candidate | Step+Module candidate | Final Step correct |
|---|---:|---:|---:|---:|
| planning | 12 | 2 | 1 | 2 |
| reflection | 6 | 3 | 1 | 1 |
| action | 5 | 3 | 3 | 2 |
| memory | 5 | 4 | 1 | 2 |
| system | 2 | 2 | 1 | 2 |

Ten of the sixteen candidate-absent failures are released planning roots. The
v52 `planning_local` lane emits one earliest clear planning error, while
`global_critical` often repeats the same early point. This discards later,
distinct planning commitments. The release does not consistently annotate the
earliest arguable inefficiency: in repeated-result WebShop traces it can mark
the later output that visibly reissues a near-identical query or recommits to
equivalent results.

Representative examples:

- `GPT-4o_008_chat_b000_t00_e07-d50ae81f`: released step 13
  planning/inefficient_plan; v52 supplies and selects step 6, when no-progress
  is first recognized. The released reasoning instead identifies the later
  near-duplicate query that actually causes repeated results.
- `GPT-4o_011_chat_b000_t00_e10-69d80a84`: released step 21 planning; v52's
  new candidates are at steps 5 and 8 and the final is step 8. The decisive
  later re-query is absent.
- `Qwen3-8B_001_chat_b000_t00_e00-d3248f80`: released step 8 planning; v52
  has nearby steps 7, 9, and 11 but omits step 8. V51's different causal lanes
  did include step 8, showing that the trace supports the location but v52's
  lane compression loses it.
- `Llama3.3-70B-Turbo_001_memory_b000_t00_e00-7743eba0`: released step 6
  planning; v52 collapses the repeated-search history to step 4. V51 includes
  step 6 among its alternatives.

Across the same fixed cohort, the v51 and v52 supplied-candidate union covers
17/30 released Steps, three more than v52 alone. A third historical prompt
adds one further Step. This is evidence for complementary temporal views, not
authorization to ensemble their answers deterministically.

## Remaining selection and ownership errors

Five rows have the released Step somewhere in the v52 candidate bundle but a
different final Step. Three expose only the Step under the wrong module, so
the final judge would need to reconsider ownership rather than copy the
candidate tuple. Two expose the released Step and module and are clearer
Selector failures:

- `Llama3.3-70B-Turbo_015_webshop_task_015` supplies step 6
  reflection/causal_misattribution but selects step 2 memory/over_simplification.
- `Qwen3-8B_015_chat_b000_t00_e15-75a3b882` supplies step 7
  action/misalignment, where the action buys before the plan's required color
  verification, but selects step 3 memory/hallucination.

Module ownership is generally weaker than Step localization. Predictions are
planning-heavy (13/30) and action-heavy (8/30), while only two outputs each
select reflection and system. This explains why Step+Module remains 5/30 even
after Step Exact rises to 9/30. The immediate 40% gate, however, is Step Exact;
the next experiment must broaden Step candidates without adding a code-side
semantic selector.

## Rejected explanations

- **Transport or payment failure:** rejected for the recovered suffix. All
  eight exact requests succeeded with no retry.
- **Malformed final JSON:** rejected. All 30 final raw Selector records parsed
  and validated.
- **Deterministic fallback or mutation:** rejected. Semantic mutation count is
  zero and `raw_selector_final` passed.
- **A simple early/late numeric correction:** rejected. V52 has both nine early
  and twelve late predictions, and official annotations use both early atomic
  defects and later decisive commitments.
- **Only tune the final Selector:** insufficient as the primary hypothesis,
  because 16/21 wrong rows lack the released Step in all supplied candidates.

## Next falsifiable hypothesis: v53 dual-timescale planning census

V53 will keep the raw v52 Selector contract unchanged so that the candidate
change is attributable. It will change only the untrusted LLM candidate census
from six single-point lanes to six dual-timescale lanes:

1. `memory_local`;
2. `reflection_local`;
3. `planning_first_defect`;
4. `planning_decisive_commitment`;
5. `action_local`;
6. `global_critical`.

`planning_first_defect` asks for the earliest locally demonstrable planning
error. `planning_decisive_commitment` asks for a distinct later planning
output, if one exists, that explicitly recommits to known failed coverage,
issues a materially equivalent query after prior results, violates a concrete
task constraint, or turns a recoverable detour into the final failing branch.
It must not duplicate the first lane merely to fill a slot. The dedicated
`system_local` slot is removed because the frozen Scout terminal review already
supplies the external-boundary candidate and system recall is already 2/2;
`global_critical` may still emit a system root. This replaces one empirically
redundant lane instead of increasing the candidate or output bound.

The six new LLM hypotheses plus the frozen prior/Scout hypotheses still fit
the existing maximum of twelve after exact semantic deduplication. They remain
anonymous, unscored suggestions. The raw Selector may reject all of them and
remains the sole source of final step/module/type. Code will not rank, vote,
weight, score, truncate by semantic preference, repair, or fall back to a
candidate.

The dry3 test is deliberately stronger than the historical 2/3 promotion
signal. V51 and v52 both already score 2/3 on those exact rows while missing
the released step-13 planning commitment. V53 must produce 3/3 Step Exact,
3/3 Step+Module, 3/3 All Correct, zero invalid rows, and expose the step-13
planning candidate before a full30 run is allowed. If it merely repeats 2/3,
the dual-timescale hypothesis has not demonstrated its intended effect and is
rejected without a full run.

If dry3 passes, the full tuning prediction must still reach at least 12/30
Step Exact with all preregistered structural and semantic gates. Any failed
provider or benchmark attempt requires a new completed case study before the
next external LLM call.

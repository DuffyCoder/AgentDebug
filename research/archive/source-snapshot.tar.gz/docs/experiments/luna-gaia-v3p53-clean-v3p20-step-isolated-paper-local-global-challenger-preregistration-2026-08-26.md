# Luna GAIA v3.53 Step-Isolated Paper-Local Global Challenger Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.53-clean-v3.20-step-isolated-paper-local-global-challenger`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: Luna v3.20, Step Exact `25/50`
- Original v3.4 baseline: Step Exact `21/50`
- Version acceptance: Step Exact `> 25/50`
- Goal completion: Step Exact `>= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the only optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module/type/evidence remain legality constraints only.

## Completed audit basis

Luna v3.52 was a clean v3.20 child that assigned one complete-trajectory local
census and max-one proposal to each of Memory, Reflection, Planning, and Action.
It legally completed 50/50 but scored `19/50`; relative to v3.20 it had 1 gain,
7 regressions, and net `-6`. Its own fresh anchor was `19/50`.

The mandatory audit covers all 31 Step errors. First divergence is 26
`anchor_error`, 4 `annotation_ambiguity`, and 1 `false_challenger_override`.
The downstream mechanism split is more diagnostic: 18 errors have no positive
gold row in any assigned-module census, 4 have a positive gold row that is
discarded by per-module max-one compression, 4 retain a gold proposal that the
selector does not choose, and 1 correct fresh anchor is falsely overridden.

Across all 50 cases, v3.52 local-positive gold-Step coverage was `20/50`; its
four compressed proposals covered `12/50`; fresh-anchor plus any local-positive
row had oracle `28/50`; fresh-anchor plus any exported proposal had oracle
`24/50`. The selector made only 1 direct gain and 1 direct loss. Thus neither
compression nor selector tuning can reach 30 from v3.52's frozen evidence.

The public AgentDebug topology differs at the first stage: it evaluates each
Step locally, applies taxonomy detection without deciding critical ownership,
and only then gives the complete evidence matrix to a global root selector. In
the frozen public-repository reproduction, Phase 1 covered the released gold
Step in `35/50`, and its scoring-phase union with v3.20 was `43/50`. The same
artifacts also produced 457 positive Steps and a public Phase-2 final of only
`14/50`, so local recall is useful while unrestricted global selection is a
direct regression warning.

## Single major mechanism

Add one step-isolated paper-local-to-global challenger path to an otherwise
unchanged fresh v3.20 anchor:

1. Deterministically project each legal Step using only the task/current input,
   the current assistant output and owner spans, the adjacent observation, and
   current execution facts. No later Step is visible to that local call.
2. Run one fresh anchor-blind local session per Step. It returns Memory,
   Reflection, Planning, Action, and System verdicts for that Step only.
3. A local positive means only a literal same-Step taxonomy defect. The local
   stage must not decide whether the defect is critical, recovered, a probe,
   a predecessor, faithful propagation, or a downstream symptom.
4. Freeze the complete validated matrix, then deterministically expose only its
   positive rows, with stable anonymous row IDs, to one fresh anchor-blind
   global proposal session. That session may export at most one complete
   critical boundary or `none` after comparing the full trajectory and every
   positive row.
5. One fresh anchor-preserving duel sees the unchanged v3.20 anchor and the
   frozen proposal. It exact-copies the anchor by default. It may select the
   proposal only with literal anchor-only-repair and proposal-only-repair
   evidence showing that the anchor is a reasonable probe, recovered defect,
   noncritical/mechanical predecessor, faithful propagation, normal tool
   failure, or downstream symptom while the proposal remains independently
   critical.

This is one topology-level mechanism: defer all critical-boundary decisions
until after a Step-isolated, high-recall local evidence matrix has been frozen.
No v3.21--v3.52 prompt, prediction, local row, proposal, selector state, or
validator state is inherited. The code is constructed directly from v3.20;
rejected runs provide only the post-score falsifiers above.

## Gains and regression risks

Expected gains are v3.20 errors whose released boundary is a fine-grained
Memory/Reflection state defect, an Action alignment/parameter defect, or a
mature Planning boundary suppressed when a complete-trajectory specialist
simultaneously performs local recall and critical compression. Step isolation
removes competition between distant same-module rows, and paper-local admission
removes premature probe/recovery/propagation vetoes from recall.

Primary regression risks are the public Phase-1 candidate flood, Planning
surface-error dominance, normal negative tool results mislabeled as System or
Action errors, and late textual symptoms winning the global stage. A second
risk is fresh-anchor sampling drift: formal gains and losses are therefore
computed against the frozen v3.20 predictions, not only the fresh anchor.

The mechanism is uniform: no trajectory ID, source model, entity, website,
fixed Step, released rationale, historical prediction, or score-dependent
router is available to inference.

## Pre-registered falsifiers

- Step-local positive gold-Step coverage does not improve on v3.52's `20/50`;
  or
- fresh anchor plus any local-positive row has scoring-phase oracle `< 30/50`;
  or
- fresh anchor plus the one global proposal has oracle `< 30/50`; or
- the duel's direct gains are not strictly greater than direct losses; or
- final Step Exact is `<= 25/50`.

Any falsifier rejects v3.53 as a mechanism test. Candidate/local oracle and all
module/type distributions are diagnostic only; they cannot accept a version.
Formal acceptance requires legal frozen full-GAIA Step Exact `> 25/50`; Goal
completion requires `>= 30/50`.

## Execution and isolation

- Planned successful sessions: 50 unchanged anchors + 717 Step-local sessions
  + 50 global proposals + 50 duels = `867`.
- Each session is fresh and one-case only; local sessions additionally receive
  exactly one prefix-bounded Step projection.
- At most four cases execute concurrently; a case's local Steps execute in
  chronological order so total live model sessions remain at most four.
- Each stage has at most two attempts. Invalid attempts are retained but cannot
  enter the frozen matrix or final prediction.
- Inference may read only its staged current inputs and frozen protocol/taxonomy
  source. Labels, metrics, scored artifacts, old predictions, error reports,
  gold rationales, case studies, git history, and external resources are
  forbidden.
- After 50/50 completion, all local matrices, proposals, duels, predictions,
  order/hashes, schema, taxonomy, literal evidence, exact-copy relations, and
  access logs are frozen and validated before labels are loaded for scoring.

## Pre-inference implementation hashes

Frozen before the first GAIA-50 inference call:

- Protocol SHA-256: `1df9e6cfa956324f43efaa9b267d3459cef22b0599ddfd48d6bc25a5567a4589`
- Runner SHA-256: `093347b8ae55925dd4bf6bac32bedef86bcc3de11e4e3dfb816e5a50b979ae3d`
- Registry SHA-256: `0f3f974139a3af453a48259d7fe425f51ff893bf7f393b5c365192ac03874f7c`
- Focused-test SHA-256: `de93fcfc96d2d8592f367e1848c8a3771f073823197ff8bf93eb1e65a87ceca3`
- Focused v3.53 tests: `5 passed`
- Cross-version v3.20/v3.52/v3.53 tests: `17 passed`
- Full-cohort dry-run: `50` cases, `717` legal Steps, exactly `867` planned
  successful model sessions, concurrency capped at `4`
- Static source scan: no case-specific Step/entity/source rule, rejected-version
  semantic import, inference-time label/metric/scored-artifact reader, or
  prior-prediction input was found

This section records freeze facts only and does not change the hypothesis or
acceptance conditions.

## Runtime outcome

Rejected before scoring due to a gold-free `runtime_or_validation_failure`.
After 4 complete frozen cases, 8 validated anchors, and 92 validated Step-local
records, case 6 exposed a System-evidence contract mismatch: the local stage
accepted full adjacent-feedback text, while the promotion/final validator
accepted only its normalized external-observation slice. The deterministic
matrix therefore rejected positive row `P004` with
`invalid_embedded_prediction_evidence`. No labels were read and no scoring was
performed. The run was stopped because 50/50 legality had become impossible;
all v3.53 inference artifacts remain unchanged.

The next clean v3.20 child may retain the single registered step-isolated
mechanism only after pre-registering the uniform contract correction: derive
System `owner_sources` from the same owner-source resolver used for final
prediction legality. No v3.53 prediction or state is eligible for reuse.

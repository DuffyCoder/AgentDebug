# Luna GAIA v3.35 Clean v3.20 Veto-Closed Observable-Impact Challenger Preregistration

## Frozen identity and decision rule

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.35-clean-v3.20-veto-closed-observable-impact-challenger`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Single major change: one veto-closed observable-impact challenger in which a
  probe/predecessor veto is irreversible and its counterfactual is identity on
  the observed probe and feedback, rather than a hypothetical route rewrite.
- Accepted incumbent: Luna v3.20, Step Exact `25/50`.
- Version acceptance: Step Exact `>25/50`.
- Goal completion: Step Exact `>=30/50` plus every legality check.
- Original frozen baseline: Luna v3.4, Step Exact `21/50`.
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases.
- Dataset manifest SHA-256:
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort semantic SHA-256:
  `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Cohort file SHA-256:
  `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Prediction-manifest file SHA-256:
  `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Model / reasoning effort: `gpt-5.6-luna` / `medium`.
- No smoke gate; after offline validation run the complete GAIA-50 directly.

Step Exact is the only optimization, comparison, acceptance, rejection, and
completion metric. Module, type, and literal evidence remain output-legality
constraints only.

## Post-score evidence and first divergence

Frozen v3.34 completed 50/50 with 150 stage attempts, zero retry, all legality
checks, and Step Exact `23/50`; it is rejected and immutable. Relative to v3.20
it had four gains and six losses, net `-2`. Its fresh anchor scored `21/50`.
Three challenger overrides produced two direct Step gains, zero direct Step
regressions, and one wrong-to-wrong move.

All 27 errors were audited. First-divergence distribution:

- false candidate admission: 11;
- candidate recall failure: 7;
- early freeze failure: 4;
- annotation ambiguity: 4;
- challenger recall failure: 1.

The critical protocol inconsistency is observable in four current errors. The
challenger explicitly classifies an acquisition/capability anchor as
`unsupported_capability_anchor` and `reasonable_probe`, but then describes a
successful *repair* that replaces this already-vetoed probe with another route.
It uses that hypothetical route change to mark every later local defect
path-dependent and emits no proposal. A reasonable probe is not a critical
error to repair; its observed feedback must remain the comparison boundary.

This supports a single falsifiable failure mode: the veto contract and the
anchor-only counterfactual contract are inconsistent. It does not support
inheriting v3.34 as parent or accumulating any other rejected mechanism.

## Single uniform mechanism

The v3.20 packet-state anchor prompt, ledger, Step freeze, model, reasoning
effort, artifact schema, one-proposal limit, exact-copy arbiter, and default
keep behavior remain unchanged. The complete challenger judgment is replaced
by one clean veto-closure mechanism:

1. Classify the anchor only from literal adjacent evidence.
2. An unrecovered task-material adjacent tool rejection, parameter
   rejection/misparse, or direct same-packet plan/Action contradiction is
   `proven_execution_impact`; it cannot be displaced by a later repetition or
   terminal symptom.
3. A capability/acquisition claim without literal adjacent proof is
   `unsupported_capability_anchor`. If it is a reasonable probe or noncritical
   predecessor, that veto is final for this case.
4. After such a veto, `anchor_only_repair_counterfactual` must explicitly be
   identity: keep the observed anchor action and feedback and close it as a
   non-error. It may not substitute a better tool, source, query, or route.
5. Scan later Steps chronologically on that observed continuation. Propose the
   earliest literal local error that is task-material, independently
   repairable, and survives normal-failure, recovery, faithful-propagation,
   repetition-maturity, and terminal-symptom vetoes.
6. For anchors not vetoed, keep the ordinary repair intervention. A strictly
   earlier proposal remains limited to a literal necessary handoff defect.
7. Emit at most one complete legal prediction. The existing arbiter can only
   keep the exact anchor or accept the exact proposal and defaults to anchor.

This is a clean v3.20 branch. No v3.21-v3.34 prompt, prediction, census,
challenger, ledger, scored artifact, or case-level result is a runtime input.
Generic bidirectional schema parsing is structural transport only; the prior
semantic rule is replaced in full by this one mechanism.

## Falsifiable gain and regression analysis

Post-score impact analysis identifies four current errors where an explicitly
vetoed capability/probe anchor is retained only because hypothetical anchor
repair erases a later released boundary. Closing the veto should make those
later boundaries eligible. IDs remain solely in post-score artifacts and do
not enter any prompt, code, validator, manifest, or router.

Four incumbent-correct unsupported-capability cases are direct counterexamples:
they contain later repetitions, tool outcomes, or terminal symptoms. The
mechanism could wrongly override their correct anchors if identity closure is
treated as permission to select any later defect. Controls therefore remain
strict: literal local ownership, task materiality, chronological earliest
selection, normal-failure and recovery vetoes, unchanged-target repetition
maturity, unsupported-terminal-answer veto, one proposal maximum, exact-copy
validation, and default keep under uncertainty.

The hypothesis is falsified if a vetoed anchor uses a route-changing repair,
if a proven execution-impact anchor receives a later override, if structural
validation fails, or if the complete legal run scores `<=25/50`.

## Execution and freeze contract

1. Implement only the versioned veto-closed challenger rule, its audit prefix,
   identity/validator retagging, runner registration, and negative tests over
   frozen v3.20.
2. Verify the anchor task is text-identical to v3.20 modulo version identity;
   the rejected prior semantic rule is absent; every vetoed probe challenge
   certifies `veto_counterfactual=identity`.
3. Use three fresh serial sessions per case: unchanged v3.20 anchor, one
   challenger, and default-keep arbiter; at most four cases run concurrently.
4. Run no smoke gate. Execute all 50 cases after prepare-only validation.
5. Freeze and validate all artifacts, hashes, schema, taxonomy, evidence,
   order, Step range, one-proposal limit, exact copies, no routing, and no
   prior-prediction/gold access before scoring.
6. Score all 50 and compute Step transitions relative to frozen v3.20 and v3.4.
7. Reject immutably at `<=25/50`; accept as new incumbent at `26-29/50`;
   complete the Goal only at `>=30/50` after every legality check passes.

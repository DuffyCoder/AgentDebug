# E9-v20 Dry3 Failure Case Study

## Attempt and formal result

E9-v20 used `deepseek-v4-pro`, a default request body, and a minimal review
schema for one frozen dry3 batch.  The logical-completion counter moved from
368 to 369 with one successful HTTP response and no retry.  Two cases parsed;
C02 failed final evidence validation.  Formal metrics remained 1/3 Step,
1/3 Step+Module, and 1/3 All Correct, with one failed prediction.

## Per-case attribution

| Case | Official root | Raw root | Attribution |
| --- | --- | --- | --- |
| C01 | step 30, `system/step_limit` | step 30, `system/step_limit` | Correct and valid. |
| C02 | step 1, `action/misalignment` | step 4, `planning/constraint_ignorance` | Semantically wrong again.  The final evidence also changed the trajectory's double quotes around `Aug 8, 2017` to single quotes, so it was not an exact owner substring.  Removing the auxiliary lane did not change the model's preference for the later conspicuous error. |
| C03 | step 13, `planning/inefficient_plan` | step 6, `planning/inefficient_plan` | Module/type are now correct, but the model still selected the first episode's mature pagination.  It did not treat step 7's return to search and step 8's rewritten query as recovery before evaluating the second episode. |

## Root attribution

The minimal schema successfully removed audit-only invalidation, but two
reasoning defects remain:

1. the model scans for a stronger later symptom without explicitly recording
   whether the earlier incumbent remained causally active; and
2. it recognizes an early repetitive-policy candidate before scanning forward
   for a genuine recovery checkpoint.

The final quote failure is coupled to the first defect: after replacing the
incumbent, the model paraphrased a new final quote instead of copying an exact
source substring.

## Bounded optimization hypothesis

E9-v21 retains Pro, the default request body, and final-only semantics.  Its
small review adds `earlier_candidate_step` and `later_recovery_step` so the LLM
must scan forward before final selection.  A direct response showing that an
interactive or dynamic representation did not expose required records is
execution evidence that the chosen extraction operation was incapable in that
run; a later tool switch is not task-closing recovery if the branch never
restores the abandoned constraints.

When the verdict is `keep`, the LLM must reproduce the incumbent's complete
final tuple exactly, including the evidence quote.  Code validates but never
copies or selects those fields.  When the verdict is `replace`, the LLM must
copy a new exact owner substring.  The next dry3 attempt costs one logical
completion (369 to 370) and requires three valid outputs plus at least 2/3
Step, Step+Module, and All Correct.

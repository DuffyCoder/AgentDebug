# Official AgentDebug GPT-5.5 Codex SDK v3 rest150 preregistration

Status: preregistered and unscored. This is an evaluation-scope-only
completion run for all 100 released ALFWorld and 50 released WebShop failure
trajectories. It is not a semantic version-selection experiment.

## Frozen semantic and transport identity

The semantic protocol is exactly
`agentdebug.codex-agent-judge.gaia-official-repo-gpt55-codex-sdk-v3`.
The public detector implementation, prompts, sequential per-Step Phase-1 call
topology, conditional System rule, positive-only Phase-2 input construction,
public internal Step-1 Memory/Reflection retry, native 19-pair taxonomy bridge,
and literal evidence-owner rules are unchanged from the completed GAIA-50 v3
experiment. The only change is the disjoint evaluation scope.

The public repository snapshot remains commit
`7740fe3a5c4822b2143cbde78ecfffeace0bb166`:

- `fine_grained_analysis.py`: `b640537ba4ba3232d9def59ad6d5c7bc1e3bcb2ddc9f07f25e6081586a2712fd`
- `critical_error_detection.py`: `7791fc671eef2b8a1296131ce7a9ef68bbcaa63d518b1e17ab5bc08b9dcecb4c`
- `error_definitions.py`: `415ced442e998133d23526d05064eef908a8e4df50519d7355af12e838d9d9bb`

The model remains requested `gpt-5.5` with medium reasoning through
`openai-codex==0.147.0` and bundled CLI `0.147.0`, authenticated by the local
ChatGPT Codex account. Temperature is unsupported and is not sent. Each public
LLM call receives a fresh ephemeral thread with byte-exact system and user
prompt mapping. No output schema is supplied. The stable Responses wire hash
is `79f6d3c17385f550cc19ca434f2e41055029315ef03224bf0562b593599967bd`;
the three-tool schema hash is
`c33cfea2ab4eb8f8aa8a99c4dba2c55e2fc80f1fe3537845b1ec4c4e011770be`.
Any observed tool or harness item fails the run.

## Source-only scope and exact call plan

The input cohort is `agenterrorbench-paper-rest150-v1`, ordered as ALFWorld100
then WebShop50, with lexical trajectory order inside each environment. Its
cohort identity is
`51a94e91e53ad4b7e9d7c525cb2f34dac081d189a9d3d05fbcde766096dfbdb6`
and its source-only prediction-manifest identity is
`020eb6d0695797c3c84c18d222be1c4474c8f830a1a0b7f418438f13307eecf6`.
GAIA cases are excluded. Before inference, every live raw source path and byte
hash must match its cohort entry. The 150 unique source files contain
32,848,002 bytes; the ordered canonical source aggregate is
`7caaa9e5a36fb7201f015f0b15264109f723d087567a5b3861a8c438d450fa1b`.

Before any formal sample, the frozen official parser was applied offline to
all 150 source trajectories. The scope contains 4,296 assistant Steps. The
exact public Phase-1 topology produces 16,884 non-System calls and zero
conditional System calls, for 16,884 Phase-1 calls total. Phase 2 has one base
call per case and may use up to two additional calls only under the public
Step-1 Memory/Reflection retry. The minimum completed-run total is therefore
17,034 successful calls.

The public Phase-2 projection was also checked offline for all 150 cases and
all 4,296 Steps: every full assistant output and the first 500 characters of
the immediately adjacent user message match the JudgeView owner projection.
No `current_input`, tool, stop/error, later-feedback, or feedback-suffix field
is admitted by the native `others/others` bridge.

## Isolation, failure, and freeze policy

The live transport preflight runs before either benchmark input is opened.
Inference then sees only the source-only rest150 manifest and raw source
trajectories. No label, prior prediction, previous inference output, scored
artifact, per-case routing signal, or smoke result is visible. The first
formal launch requires a clean output directory. Concurrency is four and each
logical call has at most three same-prompt transport attempts. An explicit
same-run process resume may reuse only a contract-identical successful call
from that interrupted run; it cannot reset an attempt budget or use a
cross-run cache.

The run is fail-closed. A public parser, normalization, native taxonomy,
strict-owner evidence, tool-use, non-retryable transport, or exhausted
same-prompt transport failure leaves the entire 150-case scope incomplete and
unscored. There are no failure rows, implicit zero scores, post-hoc case
replacement, per-case repair, semantic resampling, or prediction stitching.
The public analyzer's own retry is the only Phase-2 semantic retry.

Completion requires 150/150 successful predictions, exactly 16,884 successful
Phase-1 calls, at least 150 public Phase-2 calls, 4,296/4,296 projection
conformance, unique SDK thread and turn IDs, zero tool items, exact ordered
scope identity, schema/taxonomy legality, and selected-owner literal evidence.
The full gold-free run tree is frozen and reverified before the scorer first
opens released labels. Step and Step+Module use the fixed 150-case denominator;
All Correct uses the post-freeze observed available-gold-type denominator and
reports missing-type coverage explicitly. Scoring writes only the rest150
result. Any later union
with a separately frozen GAIA-50 result is a distinct post-score operation and
is not an inference input or part of this preregistration snapshot.

## Commands

```bash
.venv/bin/python -m scripts.run_agent_judge_agenterrorbench_official_repo_gpt55_codex_sdk_v3_rest150 --official-repo /path/to/AgentDebug-official
.venv/bin/python -m scripts.run_agent_judge_agenterrorbench_official_repo_gpt55_codex_sdk_v3_rest150 --preflight-only
.venv/bin/python -m scripts.run_agent_judge_agenterrorbench_official_repo_gpt55_codex_sdk_v3_rest150 --execute --official-repo /path/to/AgentDebug-official --max-concurrency 4 --max-transport-attempts 3
```

Only for the identical interrupted run:

```bash
.venv/bin/python -m scripts.run_agent_judge_agenterrorbench_official_repo_gpt55_codex_sdk_v3_rest150 --execute --resume --official-repo /path/to/AgentDebug-official --max-concurrency 4 --max-transport-attempts 3
```

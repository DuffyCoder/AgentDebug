# GAIA v3.112 preregistration: validated semantic-core closure

Status: preregistered and unscored before any v3.112 benchmark request.

The semantic parent is the frozen accepted v3.83 (`gpt-5.5`, medium), Step
Exact 26/50. v3.111 is transport-failure evidence only: it completed 45/50;
two challengers had invalid anchor-veto evidence, two emitted the semantic
conflict `challenge + critical_root`, and one arbiter had a narrow structural
copy defect without an extractable lock. No v3.111 prediction, case result, or
frozen run artifact is visible to v3.112 inference.

The single major change from the clean v3.83 branch is one bounded two-phase
validated-semantic-core closure. Before a semantic core exists, an eligible
fresh stateless resample must receive the exact initial v3.83 prompt bytes: no
validator feedback, failed output, owner sources, gold, or prior prediction is
added. Its prompt hash is audited against attempt one. This pre-lock phase is a
uniform bounded sampling policy and may establish only the first fully
validated stage-specific semantic core.

After that core exists, every fresh correction receives only an allow-listed
legality code, the immutable core, and deterministic current-case validator
sources needed for that same locked Step. Challenger cores bind the current
identity and upstream hashes, anchor Step, challenge decision, classification,
proposed Step, and every already validated veto boundary. An
`invalid_anchor_veto_evidence` repair is admitted only when the emitted veto
Step is already an in-range integer; the Step remains locked and only a literal
quote may be corrected. Without that valid Step core, the same code receives
only an exact original-prompt pre-lock resample. `challenge_lacks_anchor_veto`
is never repairable.
Likewise, `no_challenge` establishes a core only when veto Step, veto quote,
and proposal are all JSON null; an inconsistent conditional payload receives
only an exact original-prompt pre-lock resample, never a fabricated null lock.

Arbiter cores bind the decision, uniquely selected current-run upstream
prediction, selected Step, and exact prediction hash. A lowercase exact
`step N` intent may establish the same core only when all outer bindings,
selection-core fields, and `N` already agree with that upstream prediction.
The host never creates, unwraps, fills, normalizes, copies, or replaces a model
field. Unknown codes, stage-scope mismatches, missing required cores, core
drift, or exhaustion terminate the case.

Frozen scope and execution:

- dataset identity
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`;
- cohort identity
  `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`;
- prediction-manifest identity
  `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`;
- direct stateless `POST https://api.sophnet.com/v1/responses`;
- 50 cases, three serial stages, four workers, at most seven fresh semantic
  attempts per stage;
- no smoke gate, case routing, prior predictions, gold, labels, conversation,
  previous response ID, or failed-output replay.

Scoring is forbidden until 50/50 cases and 150/150 stages pass the original
v3.83 validators. The pre-score verifier must recompute every phase transition,
current-case input projection, prompt hash, semantic core, feedback/source hash,
request provenance,
model/materialized ordered hash, secret scan, and the full gold-free tree
freeze from disk. Acceptance is Step Exact >26/50; Goal completion is >=30/50.
Step Exact is the only version-selection metric.

# Official AgentDebug GPT-5.5 Codex SDK v2 GAIA-50 preregistration

Status: preregistered and unscored. This is a reporting-only experiment; it is
not a Luna-lineage candidate and cannot complete the active optimization Goal.

## Parent and sole change

The semantic parent is frozen
`agentdebug.codex-agent-judge.gaia-official-repo-gpt55-codex-sdk-v1`.
V1 supplies only the frozen source, prompt, model, effort, and transport
semantics inherited by this preregistration. No v1 call, Phase-1 result,
prediction, or output artifact is read or reused here.

V2 changes one mechanism only: after a fresh public Phase-2 analyzer returns,
the runner may draw a fresh Phase-2 sample when and only when the result is
missing or cannot be normalized into the frozen legal prediction contract.
There are at most three semantic attempts total per case.

The retryable outcome codes are exactly:

- `official_result_missing`, only after at least one audited public call;
- `normalization_invalid`, with one of
  `critical_step_not_integer`, `critical_step_out_of_range`,
  `critical_module_invalid`, `module_error_type_pair_invalid`, or
  `strict_owner_source_missing`.

Every semantic attempt constructs a new public analyzer, and every public LLM
call uses a new ephemeral SDK thread. The initial public Phase-2 prompt hash
must be identical across semantic attempts. The failed output and its audit
are persisted, but neither is passed to the next analyzer. No warning,
feedback, repair instruction, previous prediction, label, gold rationale, or
case-specific text is added. An accepted result ends the loop immediately.

Transport retry is a separate lower-level budget. Tool/harness observations,
provenance mismatch, exhausted transport attempts, persistence errors, and
unclassified host exceptions are terminal and never authorize a semantic
resample. Three retryable semantic outcomes exhaust the case and the clean run
remains unscored. A zero-call analyzer return (including the public successful-
task early-return path) is terminal rather than `official_result_missing`.

## Frozen inherited identity

The public repository snapshot is commit
`7740fe3a5c4822b2143cbde78ecfffeace0bb166`:

- `fine_grained_analysis.py`: `b640537ba4ba3232d9def59ad6d5c7bc1e3bcb2ddc9f07f25e6081586a2712fd`
- `critical_error_detection.py`: `7791fc671eef2b8a1296131ce7a9ef68bbcaa63d518b1e17ab5bc08b9dcecb4c`
- `error_definitions.py`: `415ced442e998133d23526d05064eef908a8e4df50519d7355af12e838d9d9bb`

The frozen scope is the 50-case `gaia-paper-v1` cohort, dataset identity
`fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`,
with 717 assistant steps. Phase 1 is byte-identical to the parent and requires
exactly 3,202 successful calls: 2,768 normal module checks and 434 conditional
System checks. Its public Step-1 and WebShop skips and the public serializer's
omission of System verdicts remain unchanged.

Model and transport remain requested `gpt-5.5`, medium reasoning,
`openai-codex==0.147.0`, bundled CLI `0.147.0`, and local ChatGPT
authentication. Temperature is unsupported and not sent. Each official
system prompt maps byte-exactly to `thread.base_instructions`; each official
user prompt maps byte-exactly to `turn.input`. No output schema is supplied.

This remains an agentic-transport approximation, not direct API equivalence.
The stable Responses wire-contract hash is
`79f6d3c17385f550cc19ca434f2e41055029315ef03224bf0562b593599967bd`;
the visible-tool schema hash is
`c33cfea2ab4eb8f8aa8a99c4dba2c55e2fc80f1fe3537845b1ec4c4e011770be`.
The model sees `apply_patch`, `request_user_input`, and `update_plan` with
parallel tool calls enabled. Any actual tool or harness item fails the run.

## Call bounds, persistence, and scoring boundary

Every case has one to three semantic attempts. Each semantic attempt may make
one to three public calls because the frozen official implementation retains
its own Step-1 memory/reflection retry. Therefore the clean GAIA-50 run has:

- exactly 3,202 successful Phase-1 calls;
- between 50 and 450 successful Phase-2 calls;
- between 3,252 and 3,652 successful calls overall.

The first formal launch requires a clean v2 run directory. An explicit same-run
process resume may reuse only contract-identical successes already frozen in
that same v2 directory; it never resets transport or semantic budgets. There
is no cross-run, cross-version, v1, or global cache, and no prediction
stitching.

Every attempt persists its prompt hashes, public call count, outcome code,
normalization detail code, retry decision, and no-feedback/no-replay facts.
Completion requires 50/50 legal predictions, exact Phase-1 count, contiguous
bounded semantic attempts, unique SDK thread and turn identifiers, zero tool
items, and strict taxonomy/schema/literal-owner-evidence validation. The full
gold-free tree is frozen and reverified before the scorer first reads released
labels. The final report includes Step Exact, Step+Module, All Correct, tokens,
and latency; it does not select a Luna version.

## Commands

```bash
.venv/bin/python -m scripts.run_agent_judge_gaia_official_repo_gpt55_codex_sdk_v2_paper50 --official-repo /path/to/AgentDebug-official
.venv/bin/python -m scripts.run_agent_judge_gaia_official_repo_gpt55_codex_sdk_v2_paper50 --preflight-only
.venv/bin/python -m scripts.run_agent_judge_gaia_official_repo_gpt55_codex_sdk_v2_paper50 --execute --official-repo /path/to/AgentDebug-official --max-concurrency 4 --max-transport-attempts 3
```

Only for an interrupted, identical v2 run:

```bash
.venv/bin/python -m scripts.run_agent_judge_gaia_official_repo_gpt55_codex_sdk_v2_paper50 --execute --resume --official-repo /path/to/AgentDebug-official --max-concurrency 4 --max-transport-attempts 3
```

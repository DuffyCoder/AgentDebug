# Luna GAIA v3.19 Hard-Disqualifier Precedence Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia-v3.19-hard-disqualifier-precedence`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.18-probe-contribution-veto`
- Frozen incumbent: `agentdebug.codex-agent-judge.luna-gaia-v3.14-earliest-causal-challenger`
- Frozen incumbent Step Exact: `24/50`
- Original v3.4 baseline Step Exact: `21/50`
- Version acceptance: `Step Exact > 24/50`
- Goal completion: `Step Exact >= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Frozen v3.14 predictions SHA-256: `fe5bcf0a07e5776b0b60d28da835c0bf8ed7f03fb0d7e3eb0a36fbea23835133`
- Frozen v3.18 predictions SHA-256: `b0c7ef91b9a6919af14d59c791285bdb46047f782eeec1b6bba2ed6590a957f2`
- v3.18 Step audit SHA-256: `cd68ae7dec0b5cd43752a0117d7779c190bd233005620de83568626e74f9abf5`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the only optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module/type/evidence remain legality constraints only.

## Post-score diagnosis motivating this version

v3.18 produced 22/50 and was rejected. Its contribution contract fired on
190/220 ledger rows. The full 28-error audit found 17 candidate-recall failures;
six High-confidence errors form `overbroad_probe_exemption`.

In those six cases, the protocol's hypothetical intermediate-contribution test
suppressed an earlier packet even though that same packet contained a stronger
literal defect. Four are directly covered by one narrow taxonomy: an unrelated
bound target, an argument rejected by the declared interface, a source/corpus
that contradicts an explicit task predicate, or a literally malformed query.
The other two involve static text extraction for dynamic video evidence and are
deliberately excluded because exposed labels show direct counterexamples.

## Single major change

Add one hard-disqualifier precedence field and ordering rule to the v3.18 anchor
ledger. Every row must begin:

```text
boundary_kind=<acquisition_probe|other>;
contribution=<possible|observed|zero|not_applicable>;
hard_disqualifier=<none|wrong_target|invalid_argument|source_constraint|malformed_query>;
```

The only semantic change is:

1. Evaluate `hard_disqualifier` before applying the `possible`/`observed`
   Lane-B veto.
2. `wrong_target` requires a literally bound URL, entity, or document that is
   unrelated to the task target. Low recall or a merely indirect source does
   not qualify.
3. `invalid_argument` requires a value/type contradicted by the declared tool
   schema or rejected by adjacent feedback. An external service exception or
   inferred hidden constraint does not qualify.
4. `source_constraint` requires the plan/action to commit to a source or corpus
   explicitly excluded by the task-defined predicate. An alternative corpus
   capable of supplying a lead does not qualify.
5. `malformed_query` requires a literal semantic contradiction, incompatible
   title/entity composition, or wrong target inside the emitted query. A broad,
   vague, or low-probability query does not qualify.
6. When any hard disqualifier is present on an acquisition row, Lane B must be
   `candidate` even if contribution is `possible` or `observed`.
7. With `hard_disqualifier=none`, the v3.18 contribution gate is unchanged.
8. Static-page versus dynamic-video/UI capability is not a hard-disqualifier
   category in this version; its existing `contribution=zero` path remains.

The challenger, arbiter, earliest-causal rule, Step freeze, and all other lanes
remain unchanged. No case router, entity/site rule, historical prediction,
gold information, candidate pool, or result composition is added.

## Falsifiable prediction

The mechanism should recover literal hard-defect packets skipped by v3.18 while
retaining its valid probe exemptions.

Post-score expected direct coverage is four High-confidence errors. The main
observable checks are:

- every anchor row has the validated three-field prefix;
- every possible/observed acquisition row with a non-`none` hard disqualifier
  has Lane B `candidate`;
- every possible/observed row with `hard_disqualifier=none` retains an initial-
  or different-probe Lane-B veto;
- at least one full-run row exercises hard-disqualifier precedence;
- Step Exact gains exceed losses relative to v3.18 and the result exceeds the
  frozen 24/50 incumbent.

The hypothesis is falsified if no hard disqualifier fires, if broad alternative
sources are promoted as source contradictions, if earlier candidate flooding
returns, or if Step Exact is `<= 24/50`.

## Gain and regression analysis

Expected gains:

- literal wrong-target URLs or documents;
- literal schema/argument defects hidden by initial-probe status;
- explicit task-source violations hidden by a hypothetical indirect lead;
- literally contradictory or composite malformed queries.

Primary regression risks:

- treating a different but potentially informative source as task-forbidden;
- treating a broad or awkward query as literally malformed;
- conflating an external system failure with an invalid argument;
- reintroducing early static-media capability roots already moved correctly by
  v3.18.

The closed category set, literal-evidence requirements, exclusion of static
media capability, and validator-enforced status relation limit those risks. The
rule is uniform and does not depend on trajectory IDs, entities, sites, source
models, or fixed Steps.

## Execution and acceptance protocol

1. Implement the versioned prompt, prefix/status validator, runner, and negative
   tests.
2. Run offline tests and source scans only; do not run a smoke gate.
3. Execute all 50 frozen cases with three fresh serial sessions per case and at
   most four cases concurrently.
4. Freeze all predictions and intermediate artifacts after 50/50 completion and
   gold-free validation.
5. Only then load released labels and score all 50 cases.
6. Compute Step Exact and transitions against v3.4, v3.14, and v3.18.
7. Accept only if Step Exact is strictly greater than `24/50`; complete the Goal
   only if it is at least `30/50` and every legality/freeze check passes.
8. Otherwise reject the immutable version, audit every Step error, and create a
   new version from one next unified mechanism.

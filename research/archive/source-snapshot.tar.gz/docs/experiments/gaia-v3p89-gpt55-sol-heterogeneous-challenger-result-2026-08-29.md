# GAIA v3.89 GPT-5.5/Sol heterogeneous challenger result

Date: 2026-08-29

## Decision

Rejected and immutable. Complete GAIA-50 Step Exact is `26/50`, equal to but
not strictly above the accepted v3.83 incumbent `26/50`, and below the Goal
threshold `30/50`.

## Frozen execution and legality

- Complete cases: `50/50`.
- Stage attempts: `150/150`; retries: `0`; failed cases: `0`.
- Anchor/arbiter: `gpt-5.5` / `medium`; challenger: `gpt-5.6-sol` / `medium`.
- Gold-free, stage-model provenance, schema, order, taxonomy, literal evidence,
  Step range, exact-copy, and no-routing validation: passed.
- Arbiter: 3 accept challenger, 47 keep anchor.
- Predictions SHA-256: `4eafe0ff5405111d86eaa25d38da0a7a34bfcbb4965add580d2d67e71a139397`.
- Prediction audit SHA-256: `358e6601eaf6296e2b8b9891225f884946fece8e5bcaab0ae180f8f3ae86a307`.
- Scored metrics SHA-256: `03f1fbbf743b26183963a238c1a23f734280eee2d7ff40db64d9dd44cc7eb5d0`.

## Step-only mechanism result

- Fresh v3.83-semantic GPT-5.5 anchor: `25/50`.
- Final: `26/50`.
- Sol proposals: 5; proposal Step exact: `1/5`.
- Direct challenger effect over the fresh anchor: 1 gain, 0 losses,
  2 wrong-to-wrong accepted moves.
- Relative to frozen v3.83: 24 both correct, 22 both wrong, 2 gains, 2 losses.
- Both incumbent-relative gains and both losses came from fresh-anchor sampling
  differences. The sole exact Sol proposal restored a current anchor drift on
  a case already correct in frozen v3.83.
- The heterogeneous challenger repaired none of v3.83's 24 frozen Step errors.

The hypothesis is only partially supported: heterogeneous execution is stable
and the conservative arbiter avoided direct regression, but the independent
model did not improve frozen-incumbent error recall. Step Exact therefore does
not satisfy the strict acceptance rule.

## First-divergence audit

The 24 final errors contain 9 `anchor_error`, 6
`candidate_recall_failure`, 5 `false_candidate_admission`, 2
`early_freeze_failure`, 1 `late_symptom_preference`, and 1
`annotation_ambiguity`.

The dominant new observation is not an override failure. It is the persistence
of candidate-source under-recall: changing the challenger model while retaining
the exact conservative challenger contract produced no gold proposal for an
incumbent-error case. Meanwhile, four incumbent-relative changes were entirely
explained by fresh anchor sampling drift.

- Step error audit SHA-256: `ceb3bebd049df590b13b83817ef6f2cd70be02d858d3f48189d541cd4cfcac2c`.
- Cluster audit SHA-256: `a189ad78e2c6762809907ad35d29c0969120d3a460ef003a6ebe9da5f00dacd7`.
- Mechanism impact SHA-256: `106182b8473877e8d967bd2a7e5d8a99966de732ddca4013395588532b6633bb`.
- Post-score builder SHA-256: `b4327a1f43be5f1bdc26e7ecfd8477fb8fa6a4d7b0e0c7fdba3903eb08463a75`.

## Next falsifiable mechanism

Return to accepted v3.83 and address the now-observed sampling instability
directly. Generate multiple fresh, independent v3.83-semantic anchors inside
the same gold-free run and use an anchor-blind stability adjudicator to freeze
one exact candidate before running the unchanged conservative challenger and
arbiter. Historical v3.83/v3.89 predictions remain unavailable to inference;
only current-version fresh replicas may be compared. The intended test is
whether independent replication preserves incumbent-correct boundaries while
recovering complementary current-run misses, without result stitching.

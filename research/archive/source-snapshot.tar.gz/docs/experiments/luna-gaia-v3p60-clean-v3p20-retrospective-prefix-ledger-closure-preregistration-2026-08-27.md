# Luna GAIA v3.60 preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.60-clean-v3.20-retrospective-prefix-ledger-closure`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: Luna v3.20, Step Exact `25/50`
- Original v3.4 baseline: Step Exact `21/50`
- Version acceptance: Step Exact `> 25/50`
- Goal completion: Step Exact `>= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the only optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module, type, and evidence remain legality constraints
only.

## Clean-parent and rejected-lineage boundary

v3.60 is a direct child of accepted v3.20. It reruns the unchanged v3.20
anchor and sparse chronological ledger in fresh isolated sessions. No v3.21–
v3.59 prompt, challenger, ledger, local inventory, selector, prediction, or
runtime artifact is an inference input. The rejected experiments and their
post-score audits informed this hypothesis only; their protocol changes do not
accumulate into v3.60.

## Comparison-derived diagnosis

v3.20 and v3.39 both score `25/50`, but share only 21 exact cases. Their frozen
prediction union has an oracle of `29/50`, so choosing between those two outputs
cannot reach this Goal. The public paper topology obtains high local recall but
the local reproduction generated 457 positives (9.14 per case) and selected
only `14/50`, identifying candidate flood and global late selection as its main
failure in this runtime.

The accepted v3.20 ledger is a more useful middle ground. It has 131 total rows
(2.62 per case, maximum nine) and covers the released Step in `32/50`. Eight
incumbent errors already have the released Step in a strictly earlier ledger
row, while 17 incumbent-correct cases are exposed to at least one earlier row.
Across 23 historical clean-v3.20-child anchor runs, sparse-ledger coverage
averaged `31.26/50`, ranged from 27 to 35, and reached at least 30 in 20 runs.
These are post-score aggregate facts only; no trajectory ID, gold Step, source
entity, or historical prediction enters inference.

## Single major mechanism

Add one retrospective prefix-ledger closure after a fresh unchanged v3.20
anchor:

1. Mechanically retain every v3.20 ledger row strictly earlier than the frozen
   anchor, in chronological order. No new candidate search is allowed.
2. One fresh semantic-only session must assess every retained row using a
   deterministic full-timeline JudgeView projection, that row's literal
   evidence and original v3.20 lane verdict, and the actual observed
   continuation. Repeated cumulative prompt/history wrappers are removed, but
   every Step output and incremental observation/feedback remains visible.
3. `veto_initial_probe` and `veto_different_probe` are ex-ante evidence, not
   categorical post-outcome vetoes. A row qualifies only if the actual Step
   exposes a concrete taxonomy-valid owner defect or material task-state
   boundary, the later path consumes that defect, it is not fully recovered,
   and repairing only that row would materially change the failed path.
4. Reasonable informative probes, ordinary negative/tool results, recovered
   defects, noncritical predecessors, faithful propagation, downstream
   symptoms, and uncertain rows remain nonqualifying.
5. The program binds identity, hashes, Step, original ledger row, prediction,
   decision, and final exact copy. The model emits no identity, hash, Step,
   decision, or selected output.
6. The deterministic reducer selects the chronologically earliest qualifying
   earlier row; if none qualifies it exact-copies the fresh v3.20 anchor.

This is one integrated retrospective-boundary mechanism. Deterministic binding
and reduction are its artifact contract, not additional learned heuristics.
Module and type are not used to rank candidates.

## Expected gains and regression risks

The mechanism targets the eight incumbent errors whose released Step already
exists in the incumbent's sparse prefix ledger. It tests one general failure:
v3.20's first-pass probe veto is made before the full outcome is observable and
can hide the benchmark's first concrete boundary.

The primary risk is an early override in the 17 incumbent-correct cases with
earlier rows. The gate therefore requires all of: literal local ownership,
taxonomy-valid classification, observed material outcome, downstream path
consumption, absence of full recovery, and a row-only repair effect. Candidate
order is bounded by the accepted anchor ledger, so the mechanism cannot create
paper-style candidate flooding. It moves Steps only earlier; it cannot repair
an incumbent prediction that is already too early.

## Falsifiers

- any prefix row is skipped, reordered, invented, or sourced outside the fresh
  accepted-parent ledger;
- any model-authored semantic artifact contains trajectory identity, hashes,
  Step, final decision, selected prediction, gold, scores, or case routing;
- aggregate validation cannot reconstruct every binding and final exact copy
  from the frozen anchor, ledger, checkpoint, and semantic-only assessment;
- the fresh sparse ledger covers fewer than 30 released Steps (post-score
  diagnostic, not acceptance metric), showing insufficient run-level recall;
- the reducer has nonpositive Step net gain relative to its own fresh anchor;
- any inference reads labels, scores, old predictions, error audits, experiment
  documents, git history, or external resources;
- legal frozen coverage is not `50/50`, or final Step Exact is `<= 25/50`.

Only Step Exact controls acceptance. Only a frozen, legal full GAIA-50 result
of at least `30/50` completes the Goal.

## Planned execution topology

- 50 fresh unchanged-v3.20 anchor sessions.
- 50 fresh retrospective prefix-ledger semantic sessions, including an empty
  assessment for cases with no earlier ledger row.
- Exactly 100 planned successful model stages, one trajectory per fresh
  session, maximum concurrency four, maximum two attempts per stage.
- Deterministic per-case assembly, aggregate validation, gold-free freeze, then
  direct full GAIA-50 scoring; no smoke gate.

## Pre-inference validation and source hashes

- Deterministic full-cohort dry-run: 50 cases and exactly 100 planned model
  stages; no smoke gate.
- All 50 deduplicated full-timeline projections passed gold-free validation;
  they retain 717/717 Steps. Their total serialized size is 14,559,847 bytes,
  with a maximum single-case projection of 1,302,188 bytes.
- A synthetic keep-anchor aggregate exercised all 50 accepted-parent anchor,
  ledger, checkpoint, semantic-only, deterministic selector, input-binding,
  final-copy, and aggregate validators successfully.
- Focused v3.60 tests: `8 passed`; cross-version v3.20/v3.59/v3.60 tests:
  `28 passed`.
- Static inference-source scan found no rejected-version import, gold/score
  reader, case router, trajectory-specific condition, or git-history input.

Frozen pre-inference hashes:

- Protocol SHA-256: `b242028afad207ca495a2a5df41118a3c17619158af265d5676cad5ff9f821b8`
- Runner SHA-256: `3b29aa6bc11b76a53b21fef7542512c83ec093acd625fbad8ecd6a7b9a0f62c3`
- Registry SHA-256: `06357b4a41a9d912be7fa0e1ee3ecc9a587d1d447d47d5146bbd97253cd25072`
- Taxonomy SHA-256: `d7e4b878059bbecec0a8fd3f078c0aeb5755bf9e65bb938c897dd83685f28c5c`
- Focused-test SHA-256: `6a05c31a273727fff4928a62547c90514397b2f653a1a1be833f04de1824a912`

## Frozen full-run outcome

v3.60 completed all 50 cases. The 100 planned stages produced 100 successful
stage attempts; one incomplete attempt failed literal-evidence validation and
was followed by the single runner-authorized attempt-2, so the immutable run
contains 101 attempts, one retry, and zero permanent failures. Schema,
taxonomy, literal evidence, identity, hash, order, aggregate coverage, and
gold-free freeze validation all passed.

An independent scan of all 101 inference stdout logs and 703 executed commands
found zero direct or output-visible reads of released labels, scored artifacts,
metrics, historical predictions, post-score audits, or git history. All five
pre-inference source hashes match this preregistration. The access audit is
frozen at `analysis/inference-access-audit.json` under the v3.60 run directory.

The sole acceptance metric was Step Exact. v3.60 scored `21/50`, so it is
rejected and v3.20 remains the accepted incumbent at `25/50`. Relative to
frozen v3.20, the transition is 20 both correct, one gain, five losses, and 24
both wrong. Its fresh unchanged-v3.20 anchor scored `20/50`; the retrospective
reducer produced one direct gain, zero direct loss, and one wrong-to-wrong
change relative to that fresh anchor. It selected a prefix row only twice and
kept the anchor 48 times.

The fresh sparse ledger covered the released Step in `32/50`; its strictly
earlier rows covered `12/50`, and fresh anchor plus prefix-row oracle remained
`32/50`. Thus candidate availability could in principle exceed the Goal, but
the absolute five-gate selector admitted too little of it.

All 29 Step errors have frozen facts, first-divergence diagnoses, required
`step-error-audit.json` entries, and cluster statistics. The distribution is:
17 `candidate_recall_failure`, seven `arbiter_selection_failure`, four
`annotation_ambiguity`, and one `false_candidate_admission`. The dominant
17-case cluster has gold later than the stopping anchor and is structurally
unreachable by a prefix-only mechanism. Seven further errors have the released
Step in the prefix set but the independent absolute gate rejects it, most often
as an informative different probe, reasonable probe, or normal tool failure.

This run therefore falsifies retrospective prefix closure as the next accepted
mechanism. The next clean v3.20 child must primarily repair post-anchor recall,
while bounding candidates strongly enough to avoid the public paper method's
candidate flood. v3.60 protocol, prompt, selector, ledger changes, predictions,
and runtime artifacts remain rejected and are not inherited.

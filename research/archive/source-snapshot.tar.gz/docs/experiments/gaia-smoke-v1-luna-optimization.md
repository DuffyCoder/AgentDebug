# Luna optimization on gaia-smoke-v1

Date: 2026-08-14

## Scope and interpretation

- Cohort: `gaia-smoke-v1`, 30 GAIA trajectories.
- Cohort SHA-256: `517dd62b931b2671ff734e3edcfc716d716efd86c1c29c2010a651a16cc59f61`.
- Prediction-manifest SHA-256: `6519788f442e87fbc0ba3cecbaf534c5dcf5813f9e8767cabd18ad408f66f846`.
- Ranks 1--10 exactly preserve the GAIA portion of `smoke-v1`; ranks 11--30
  continue the same fixed, gold-independent SHA-256 ranking.
- The cohort is disjoint from frozen `tuning-v1` and contains only GAIA.
- This is an exposed development/tuning cohort. Results must not be described
  as held-out accuracy or unknown-data generalization.

## Fixed execution contract

- Model: `gpt-5.6-luna`; reasoning effort: `medium`.
- One fresh ephemeral Codex session per trajectory; no cross-case state.
- Maximum concurrency: 4; maximum attempts per case: 2; retry failed cases only.
- Every candidate uses one pre-frozen uniform protocol on all 30 cases.
- Predictions and strict audit must be complete before gold-bearing scoring.
- No same-case historical prediction, gold label, or score-dependent routing is
  visible during inference.

## Iteration contract

Each iteration is a mandatory closed loop:

1. Run and strictly validate all 30 predictions, then score the frozen output.
2. Analyze every Step Exact error case, including the trace evidence, predicted
   and gold causal locations, root-cause attribution, and the prompt mechanism
   that caused the miss.
3. Aggregate the case analyses into a falsifiable failure taxonomy and quantify
   each proposed direction's reachable cases and regression risks.
4. Freeze exactly one evidence-backed protocol change and its hypothesis.
5. Only then start the next complete 30-case run.

A completed run alone does not authorize another prompt iteration. No candidate
may start until the preceding run's full error-case analysis is persisted here
or in a linked analysis artifact.

## Runs

### Baseline: luna-v3

- Protocol: `agentdebug.codex-agent-judge.luna-v3`.
- Status: failed closed before merge/score; 29/30 cases produced valid audited
  predictions and case 14 failed evidence ownership on both allowed attempts.
- Output: `output/agenterrorbench-codex-gpt-5.6-luna-gaia-smoke-v1-agent-judge-luna-v3-baseline-case30`.
- No metric is reported for this run because a 29-case partial result is not an
  admissible semantic evaluation.

#### Pre-score failure analysis

- Affected case: rank 14,
  `Qwen3-8B_006_memory_b000_t00_e06-71f77595`.
- Both attempts wrote a structurally valid ten-field prediction at step 1 with
  Planning evidence copied literally from `assistant_raw_output`; both were
  rejected as `invalid_evidence_ownership`.
- The public step contains a 25,616-character text block and valid offset
  ranges. `TextBlockRange` intentionally stores offsets rather than a `text`
  field, so absence of `text_blocks[0].text` is not data loss.
- The actual incompatibility is nested recognized tags: one outer `think`
  Planning span contains one inner Action span. The inherited v2.4/v3 evidence
  resolver treats every overlap, including proper containment, as invalid and
  therefore exposes zero Planning or Action sources.
- Rank 4 has the same shape (outer Planning `think` containing inner Action).
  Its first attempt failed ownership, and its second attempt passed only by
  switching to a System/step-limit claim. This demonstrates a semantic bias,
  not merely one malformed quote.
- A gold-free scan of all 30 public JudgeViews found exactly two nested-span
  cases (ranks 4 and 14), both properly contained and neither crossing. Thus the
  repair scope is concrete and bounded.

#### Engineering repair hypothesis

Freeze `luna-gaia-v1` with unchanged v3 semantic selection rules and a new
general evidence policy:

- accept disjoint spans and properly nested spans;
- for an outer owner, subtract every nested different-owner interval and expose
  only the remaining contiguous fragments;
- expose the nested owner's own span normally;
- continue to reject crossing, duplicate, or out-of-bounds geometry;
- tell the judge explicitly that TextBlockRange and ModuleSpan carry offsets
  into `assistant_raw_output`, not embedded text.

This should make all 30 cases mechanically diagnosable without relaxing
cross-owner evidence checks. It may also remove the false System fallback on
rank 4. The hypothesis is verified by 36 focused regression tests and by
validating rank 14's previously rejected literal Planning quote under the new
resolver. That prior output is used only as an engineering test and will not be
reused in the new semantic run.

### Candidate 1: luna-gaia-v1

- Protocol: `agentdebug.codex-agent-judge.luna-gaia-v1`.
- Semantic hypothesis: same as v3; only ownership-safe nested evidence differs.
- Status: complete; 30/30 valid predictions and strict audit passed.
- Output: `output/agenterrorbench-codex-gpt-5.6-luna-gaia-smoke-v1-agent-judge-luna-gaia-v1-case30`.
- Metrics: Step Exact 10/30; Step+Module 9/30; All Correct 5/30.
- Error direction: 20 Step misses, of which 15 were late and 5 were early.
- Complete post-freeze analysis:
  `output/agenterrorbench-codex-gpt-5.6-luna-gaia-smoke-v1-agent-judge-luna-gaia-v1-case30/analysis/step-error-analysis-2026-08-15.md`.

### Candidate 2: luna-gaia-v2

- Status: failed closed before merge/score.  Cases 1--16 and 18--30 were valid
  on their first attempt; case 17 produced no prediction in either allowed
  attempt.  No partial metric is reported.
- Single semantic change: replace the stateless first-mature scan with a
  recovery-aware causal-state ledger covering task predicates, claim support,
  tool/evidence modality, normalized strategy epochs, causal-interval closure,
  non-final external tool failures, and terminal premature abandonment.
- Evidence geometry and the strict ten-field output/audit contract remain
  unchanged.
- Output directory must be new and must not reuse candidate-1 predictions.
- Execution failure analysis:
  `output/agenterrorbench-codex-gpt-5.6-luna-gaia-smoke-v1-agent-judge-luna-gaia-v2-case30/analysis/execution-failure-analysis-2026-08-15.md`.

### Candidate 2.1: luna-gaia-v2.1

- Status: complete; 30/30 valid predictions, zero retries, strict audit passed,
  and official scoring completed.
- Semantics are byte-for-byte v2's recovery-aware decision rules.
- Execution-only repair: tasks receive short indexed write-once aliases for
  case inputs and short case output directory components.  Alias contents and
  SHA-256 values are persisted, while normal parent merge validation remains
  unchanged.
- No prediction from failed candidate 2 may be reused.
- Metrics: Step Exact 9/30; Step+Module 7/30; All Correct 5/30.  This regressed
  from candidate 1's 10/30 and is not promoted.
- Complete analysis of all 21 Step errors, three gains, and four regressions:
  `output/agenterrorbench-codex-gpt-5.6-luna-gaia-smoke-v1-agent-judge-luna-gaia-v2p1-case30/analysis/step-error-analysis-2026-08-15.md`.

### Candidate 3: luna-gaia-v3

- Status: complete; 30/30 valid predictions, zero retries, all 30 immutable
  step checkpoints and strict audits passed, and official scoring completed.
- Single semantic change: replace global dominant-unrecovered-interval selection
  with a shorter lane-ordered chronological scan and narrowly scoped recovery
  vetoes.
- Step is frozen before owner/type.  Memory/Reflection fact fidelity and hard
  task/interface/capability/System conditions are audited before generic
  strategy repetition.
- Candidate 3 must retain v2.1's short, write-once indexed execution aliases and
  must use a new protocol and output directory.
- Metrics: Step Exact 11/30; Step+Module 8/30; All Correct 6/30.  This is the
  best GAIA Step result so far, but does not beat candidate 1 on Step+Module.
- Complete analysis of all 19 Step errors, five gains, and three regressions:
  `output/agenterrorbench-codex-gpt-5.6-luna-gaia-smoke-v1-agent-judge-luna-gaia-v3-case30/analysis/step-error-analysis-2026-08-15.md`.

### Candidate 3.1: luna-gaia-v3.1

- Status: complete; 30/30 valid predictions, zero retries, all checkpoint and
  strict audits passed, and official scoring completed.
- Single semantic delta: make adjacent external exceptions an explicit step
  packet fence.  A literal failure in step N feedback is resolved before any
  Memory/Reflection in step N+1 can be inspected; step N+1 is not a same-step
  competitor.
- Same-step assistant defects, strict System admission exclusions, lane order,
  recovery vetoes, step checkpoint, short aliases, model, effort, and execution
  topology remain unchanged.
- The broader evidence-sufficiency/capability and search-epoch changes are
  deferred so the high-confidence System-order fix can be measured in
  isolation on the full 30-case cohort.
- Metrics: Step Exact 14/30; Step+Module 11/30; All Correct 9/30.  Candidate
  3.1 gains three Step matches and loses none versus candidate 3, so it is the
  current GAIA incumbent.
- Complete analysis of all 16 Step errors and the three gains:
  `output/agenterrorbench-codex-gpt-5.6-luna-gaia-smoke-v1-agent-judge-luna-gaia-v3p1-case30/analysis/step-error-analysis-2026-08-15.md`.

### Candidate 3.2: luna-gaia-v3.2

- Status: complete; 30/30 valid predictions, zero retries, all checkpoint and
  strict audits passed, and official scoring completed.
- Single semantic axis: correct capability admission.  A tool need only expose
  some necessary evidence, not prove the full task in one call; open-ended
  Google/Wikipedia discovery is not impossible merely because direct database
  access is absent.
- Definitionally disjoint specialized corpora remain impossible for another
  database's UI metadata, and static page text remains impossible for dynamic
  video narration/frames at the first concrete target commitment.
- Packet fence, lane order, recovery/strategy rules, checkpoint, aliases,
  model, effort, and execution topology remain unchanged.
- Metrics: Step Exact 12/30; Step+Module 9/30; All Correct 7/30.  Candidate
  3.2 gains two Step matches but loses four versus v3.1, so it is rejected and
  v3.1 remains incumbent at 14/30.
- Complete analysis of all 18 Step errors, two gains, and four regressions:
  `output/agenterrorbench-codex-gpt-5.6-luna-gaia-smoke-v1-agent-judge-luna-gaia-v3p2-case30/analysis/step-error-analysis-2026-08-15.md`.

### Candidate 3.3: luna-gaia-v3.3

- Status: complete; 30/30 valid predictions, zero retries, all 30 immutable
  checkpoints and checkpoint hashes passed, the cohort-order merge and strict
  audit passed, and official scoring completed.
- Branch from incumbent v3.1, not rejected v3.2.
- Single semantic axis: normalize search strategy identity using unresolved
  predicates, source/host, endpoint representation, modality, and target.
  Real new discriminators and different endpoint representations reset an
  epoch; restating an implicit predicate does not.
- A first direct-platform query remains exploratory, while exact known-failing
  target/endpoint reuse remains a repeat.  Rejecting a Planning repeat never
  exempts same-step Memory/Reflection claims from fact audit.
- Packet fence, original v3.1 capability behavior, recovery rules, checkpoint,
  aliases, model, effort, and execution topology remain unchanged.
- Metrics: Step Exact 12/30; Step+Module 10/30; All Correct 6/30.  Candidate
  3.3 gains one Step match but loses three versus v3.1, so it is rejected and
  v3.1 remains incumbent at 14/30.
- The gate failed in both directions: it ignored real discriminators on ranks
  8 and 26, oversplit repeated information routes on ranks 5, 7, and 30, and
  lost earlier Lane-A candidates on ranks 23 and 25 despite explicit contrary
  instructions.  This disproves further exception-list growth as the immediate
  direction.
- Complete analysis of all 18 Step errors, the gain, and the three incumbent
  regressions:
  `output/agenterrorbench-codex-gpt-5.6-luna-gaia-smoke-v1-agent-judge-luna-gaia-v3p3-case30/analysis/step-error-analysis-2026-08-15.md`.

### Candidate 3.4: luna-gaia-v3.4

- Status: complete; 30/30 valid predictions, zero retries, all ledger,
  checkpoint, prediction, per-case audit, merged-order, and full-cohort strict
  audit checks passed before official scoring.
- Branch from incumbent v3.1.  Neither v3.2 capability semantics nor v3.3
  strategy semantics may be inherited.
- Single process axis: require a compact schema-validated chronological
  step-candidate ledger before writing the immutable step checkpoint.  The
  first surviving Lane-A/Lane-B/System/Lane-C candidate deterministically owns
  the step; module and error type remain downstream decisions.
- V3.1 semantic admission and recovery rules remain unchanged.  No parameter,
  corpus, case, source-model, or environment exception is added in this
  experiment.
- The ledger is gold-free per-case diagnostic output, produced inside each
  isolated session.  Its purpose is to test whether explicit candidate state
  prevents later salience from overriding already-stated chronology rules.
- Four focused v3.4 tests pass, including schema/order/evidence failure cases
  and an exact prompt-normalization assertion showing that removal of only the
  ledger process restores the v3.1 task byte-for-byte.
- Metrics: Step Exact 16/30; Step+Module 10/30; All Correct 7/30.  Candidate
  3.4 gains four Step matches and loses two versus v3.1, so it is the current
  GAIA Step incumbent.
- The two losses and four additional Step misses share a capability/immediate-
  subgoal overreach: the ledger now exposes early Lane-B judgments that were
  previously hidden by later salience.  This supports a narrow semantic follow-
  up without invalidating the process result.
- Complete analysis of all 14 Step errors plus all nine Step-correct taxonomy
  errors:
  `output/agenterrorbench-codex-gpt-5.6-luna-gaia-smoke-v1-agent-judge-luna-gaia-v3p4-case30/analysis/complete-error-analysis-2026-08-15.md`.

### Candidate 3.5: luna-gaia-v3.5

- Status: failed closed before merge, full-cohort audit, or scoring. Cases
  1--28 and 30 completed on their first attempt; case 29 exhausted both
  permitted attempts. No partial metric is reported and none of the 29 valid
  shards may be reused.
- Branch from incumbent v3.4 and retain its validated ledger/checkpoint
  process unchanged.
- Single semantic axis: positive capability admission for the current
  immediate subgoal.  A plan is impossible only when even successful tool use
  cannot expose any necessary evidence assigned to that immediate subgoal;
  normal poor results cannot retroactively prove incapability.
- General discovery, static HTML/PDF extraction, and partial arithmetic-method
  evidence remain capable.  Exact-target dynamic video narration/frames via
  static text and external database UI metadata via disjoint arXiv/PubMed
  corpora remain incapable.
- The gate affects Lane B only and may not erase Lane-A claims, source
  constraints, System packet ordering, Action validation, or Lane-C strategy
  candidates.  The claimed Step targets are ranks 1, 5, 6, 15, 18, and 24;
  rank 21 is excluded because its earlier strategy error remains unresolved.
- Twenty-six focused GAIA v3--v3.5, shard, and tuning tests pass.  A prompt-
  normalization assertion proves that removing only the positive capability
  gate restores v3.4 byte-for-byte.
- Case 29 exposed an execution-protocol contradiction rather than a scored
  semantic result: the supposedly step-only immutable ledger requires literal
  evidence before the declared owner/type/evidence phase. Both fresh attempts
  paraphrased the same quote. The second attempt then misdiagnosed the hidden
  failure after its traceback was truncated and replaced a correct entry hash
  with the prediction-manifest file hash.
- Complete gold-free execution failure analysis and the bounded v3.5.1 repair
  direction:
  `output/agenterrorbench-codex-gpt-5.6-luna-gaia-smoke-v1-agent-judge-luna-gaia-v3p5-case30/analysis/execution-failure-analysis-2026-08-15.md`.

### Candidate 3.5.1: luna-gaia-v3.5.1

- Status: complete; 30/30 valid predictions, 31 total attempts with one safe
  isolated retry at rank 11, all per-case and merged audits passed, and
  official scoring completed.
- Semantic rules must remain v3.5. The immutable ledger will freeze only
  chronology, lane state, surviving lane, decision basis, and selected step;
  its `evidence_quote` will be `null`. Literal owner evidence remains mandatory
  and strictly validated in the downstream final prediction.
- Local validation failures must expose a compact terminal code/message instead
  of a truncation-prone traceback. Task wording must distinguish the manifest
  file digest from the entry `trajectory_sha256`.
- This is a uniform gold-free workflow repair. It adds no case-, model-, or
  label-conditioned branch and requires a fresh full 30-case run in a new
  output directory.
- Twenty-four focused v3.1--v3.5.1 and shard tests pass. The wider GAIA v1--v3.5.1,
  tuning, and shard selection passed 43 relevant tests; three pre-existing
  generic workflow tests still assume the old default protocol while the
  repository default is `luna-v12`, and fail on its missing incumbent proposal.
  They do not exercise v3.5.1.
- A gold-free replay of v3.5 case 29 confirms that its corrected final
  prediction, immutable checkpoint, and owner evidence pass the inherited
  validator, while the uniformly null step-only ledger passes the new ledger
  validator with the exact step chain `1 -> 1 -> 1`. No old artifact will be
  reused in the fresh run.
- Metrics: Step Exact 15/30; Step+Module 9/30; All Correct 6/30. This gains
  ranks 1 and 6 but loses ranks 10, 27, and 30 versus v3.4, so it is rejected;
  v3.4 remains the Step incumbent at 16/30.
- Rank 29, the v3.5 execution failure, passed on its first attempt. All 30
  successful ledgers have null evidence and valid ledger -> checkpoint ->
  prediction step chains.
- Complete analysis of all 15 Step errors, all nine additional taxonomy
  errors, the v3.4 delta, the rank-11 retry, and a newly discovered validator
  shell-quoting defect:
  `output/agenterrorbench-codex-gpt-5.6-luna-gaia-smoke-v1-agent-judge-luna-gaia-v3p5p1-case30/analysis/complete-error-analysis-2026-08-15.md`.

### Candidate 3.6: luna-gaia-v3.6

- Status: complete; 30/30 valid predictions, all cases completed on their first
  isolated attempt, all per-case and merged audits passed, and official
  scoring completed.
- Branch from v3.5.1. Single semantic axis: a successful, expected-shape tool
  result makes a coercible argument serialization mismatch non-material; an
  Action parameter candidate requires rejection, changed semantics, or false
  state consumption. Existing repair vetoes remain unchanged.
- Claimed Step targets are ranks 10, 15, and 16. Rank 16 step 1 is the negative
  control: its string arguments are genuinely rejected but subsequently
  repaired; step 2's string argument succeeds and must be clear.
- Execution-only repair: replace the nested-quote validator command, which
  produced recoverable SyntaxErrors in 29/31 attempts, with a module CLI using
  ordinary argv. No v3.5.1 artifact may be overwritten or reused.
- Owner consistency, claim extraction, strategy persistence/discriminators,
  and taxonomy conventions are deliberately deferred so this candidate has
  one measurable semantic hypothesis.
- Twenty-eight focused v3.1--v3.6/shard tests and 43 wider GAIA, tuning, and
  shard tests pass. Prompt normalization proves that removing only the Action
  materiality gate and module-CLI execution repair restores v3.5.1 byte for
  byte. The generated module command is also executed in a shell regression
  test and returns a compact validator code without SyntaxError or traceback.
- Metrics: Step Exact 15/30; Step+Module 13/30; All Correct 10/30. Step does
  not improve over v3.5.1 and remains one below incumbent v3.4, so v3.6 is not
  promoted on the Step objective. It is the best taxonomy result so far.
- The Action materiality gate recovers rank 10 and clears rank 15's tolerated
  parameter, but rank 15 then freezes on a literal external exception. Rank
  16 correctly treats its rejected parameter as material but fails to apply
  the existing local repair veto. Unrelated Step gains at rank 30 are offset
  by losses at ranks 8 and 25.
- The module-CLI execution repair succeeds: the 30 sessions contain none of
  v3.5.1's nested-quote/leading-zero validator SyntaxErrors. Recoverable
  in-session evidence-ownership corrections and helper-command noise are
  documented separately from the valid final artifacts.
- Complete analysis of all 15 Step errors, all five additional taxonomy
  errors, the controlled delta, and execution integrity:
  `output/agenterrorbench-codex-gpt-5.6-luna-gaia-smoke-v1-agent-judge-luna-gaia-v3p6-case30/analysis/complete-error-analysis-2026-08-15.md`.

### Candidate 3.7: luna-gaia-v3.7

- Status: failed closed before merge, full-cohort audit, or scoring. The fresh
  full run made 38 attempts; 25/30 cases passed parent validation, while ranks
  1, 9, 11, 26, and 30 exhausted both attempts. No partial metric is reported
  and no shard may be reused.
- Branch from v3.6 so capability, Action materiality, null step-ledger
  evidence, and the module-CLI execution repair remain fixed. Promotion still
  requires beating Step incumbent v3.4's 16/30.
- Single process/semantic axis: add a compact schema-validated strategy-state
  record to every chronological ledger row before Lane C classification. The
  record names an anchor step, query/source/modality/target delta, anchor
  feedback disposition, and resulting route disposition.
- The validator must enforce consistency between route disposition and
  `lane_c`. A literal source/host restriction is a real delta. An identical
  query after productive candidate discovery is not automatically mature;
  exact reuse after uninformative feedback is mature, and an accumulated
  failed-access route can remain mature across an intervening probe.
- Claimed Step targets are ranks 5, 8, and 21. Rank 30 is the persistent
  exact-reuse preservation control. Rank 26 is a negative control: its step-2
  query is an exact repeat apart from capitalization and must remain a
  candidate under the protocol, despite the released later boundary.
- Capability, Action materiality, recovery, source constraints, Lane A,
  owner/type, and evidence geometry remain unchanged. A fresh full 30-case run
  and another complete post-score error analysis are required.
- Twenty-four focused v3.4--v3.7 tests and 46 wider GAIA/tuning/shard tests
  pass. Prompt normalization proves that removing only the strategy-state gate
  and its two schema-example objects restores v3.6 byte-for-byte. Focused
  controls cover productive first-route reuse, accumulated productive-route
  maturity, new hosts, failed-access returns, terminal abandonment, and strict
  route-disposition-to-Lane-C validation. The module CLI remains shell-safe.
- Attempt outcomes were 25 valid, seven `invalid_new_strategy_state`, five
  `invalid_strategy_anchor_step`, and one `missing_predictions`. The prompt and
  validator overload `anchor_step`: a new route must identify an earlier
  comparison anchor, but its feedback must simultaneously be erased as
  `not_applicable`. Luna repeatedly encoded either the real anchor feedback or
  no same-route anchor; both reasonable readings are rejected.
- Retry-success cases do not rescue the design. Ranks 5, 16, and 27 changed
  their frozen step and/or owner rather than mechanically repairing one
  ledger. Rank 26 self-corrected a modality distinction only after its
  immutable freeze, and rank 30 failed the preregistered preservation control.
- Complete gold-free analysis of every final failure, all eight retried cases,
  target/control behavior, artifact hashes, and the frozen v3.7.1 repair:
  `output/agenterrorbench-codex-gpt-5.6-luna-gaia-smoke-v1-agent-judge-luna-gaia-v3p7-case30/analysis/execution-failure-analysis-2026-08-15.md`.

### Candidate 3.7.1: luna-gaia-v3.7.1

- Status: complete; 30/30 valid predictions, all cases completed on their
  first isolated attempt, every draft ledger passed pre-commit validation,
  all final ledger/checkpoint/prediction chains and strict audits passed, and
  official scoring completed.
- This is a uniform gold-free schema/workflow repair. It may not add or remove
  a semantic Lane-C candidate, change Lane A/B/System/Action/recovery rules, or
  consult rank, trajectory ID, prior predictions, or gold.
- `same_route_anchor_step`, prior same-route attempt count, and
  `same_route_feedback` describe only an earlier occurrence of the same
  normalized route. Initial/new/terminal/not-applicable states have no
  same-route anchor. `initial` means the first comparable information route in
  the chronology; later unseen routes use exactly one explicit material-delta
  class.
- A schema-validated draft ledger must pass a gold-free pre-commit check before
  the immutable final ledger and step checkpoint are written. Final ledger,
  checkpoint, prediction, evidence, and audit validation remain write-once.
- The repair requires focused contradiction tests, prompt-normalization proof
  against v3.7 semantics, then a new full 30-case run. No v3.7 shard may be
  copied or accepted into the new run.
- Thirty-four focused tests and 55 wider relevant tests passed before the
  run. The repaired coordinate contract eliminated v3.7's strategy-state and
  anchor validation failures: all 30 cases passed on attempt one and no draft
  remained after the immutable hard-link freeze.
- Metrics: Step Exact 13/30; Step+Module 11/30; All Correct 8/30. This gains
  ranks 5 and 8 but loses ranks 3, 10, 23, and 30 versus semantic parent v3.6,
  so it is rejected. V3.4 remains the Step incumbent at 16/30, and v3.6
  remains the best taxonomy run at 13/30 Step+Module and 10/30 All Correct.
- The structured strategy hypothesis succeeds locally on failed-route
  persistence and productive-route maturity, but over-splits already implicit
  targets, misses literal Memory/Reflection support defects, and does not
  guarantee compliance with the external-exception packet fence. Another
  strategy exception is therefore not the next direction.
- Complete analysis of all 17 Step errors, all five additional taxonomy
  errors, controlled deltas, execution integrity, and the next falsifiable
  direction:
  `output/agenterrorbench-codex-gpt-5.6-luna-gaia-smoke-v1-agent-judge-luna-gaia-v3p7p1-case30/analysis/complete-error-analysis-2026-08-15.md`.

### Candidate 3.8: luna-gaia-v3.8

- Status: complete; 30/30 valid predictions, all cases completed on their
  first isolated attempt, every claim-ledger draft passed pre-commit
  validation, all immutable ledger/checkpoint/prediction chains and strict
  audits passed, and official scoring completed.
- Semantic branch point is v3.6, not rejected v3.7.1. V3.6 already preserves
  official Steps for ranks 3, 10, 23, and 30 and scores 15/30. V3.7.1's
  validated draft-to-immutable freeze may be reused only as execution safety;
  its structured strategy semantics must not be inherited.
- Single semantic axis: add a structured Lane-A claim-support state before
  Lane B and Lane C. A requested entity-attribute assertion needs a literal
  prior-observation support pointer. A Memory/Reflection assertion that a
  result contained or lacked a requested article, link, or fact must be
  checked against literal prior feedback. Unsupported, contradicted, and
  salient-omission states make Lane A a candidate; supported/no-material-claim
  states remain clear.
- Preregistered Step targets are ranks 11, 23, and 25. Negative controls are
  ranks 1, 9, 14, and 30. These ranks define analysis expectations only and
  may not be visible to inference or used for case-conditioned routing.
- Strategy identity, immediate capability, Action materiality, recovery,
  packet ordering, same-step owner/type, evidence geometry, model, effort,
  session isolation, and execution topology remain v3.6 semantics. No label,
  old prediction, or score may enter a case session.
- Implementation requires schema contradiction tests, a draft pre-commit
  failure/revision test, prompt-normalization proof back to v3.6 semantics,
  and the existing focused/wider suites before one fresh 30-case run. Every
  error from that run must be deeply analyzed before another candidate starts.
- The implementation records exactly one five-field claim state per inspected
  row: claim kind, Memory/Reflection source, task-or-earlier-observation support
  pointer, support status, and derived Lane-A disposition. The validator
  rejects current/future support pointers, support pointers on unsupported
  claims, task-step pointers for salient result omissions, and every mismatch
  between support status, disposition, and `lane_a`.
- A revisable draft must pass compact validation before an atomic hard-link
  creates the immutable ledger. Focused tests include an invalid-current-step
  draft that leaves no final ledger and then succeeds after a bounded draft
  repair. The semantic decision section normalizes exactly to v3.6 after
  removing only the claim gate and pre-commit order wording; no structured
  v3.7 strategy state appears.
- Eleven v3.8-specific tests and 66 total v3--v3.8/tuning/shard tests pass;
  `py_compile`, `git diff --check`, protocol resolution, frozen 30-case input
  validation, and the no-execute runner preflight also pass.
- Metrics: Step Exact 15/30; Step+Module 12/30; All Correct 9/30. V3.8 is
  rejected. V3.4 remains the Step incumbent at 16/30, and v3.6 remains the
  taxonomy incumbent at 13/30 Step+Module and 10/30 All Correct.
- Relative to v3.6, ranks 18 and 24 gain Step while ranks 1 and 30 lose it.
  The gains select Planning through non-claim lanes; both losses are new
  Lane-A selections. The claim gate therefore contributes no new Step win and
  directly contributes two regressions.
- Across 95 ledger rows the gate emits ten unsupported/contradicted Lane-A
  candidates. Only rank 19 is Step exact, and it was already exact in v3.6.
  Rank 23, a preregistered target, is incorrectly classified as having no
  material claim. Ranks 1 and 30 expose negation and objective/result
  distortions; rank 16 exposes a frozen decision basis that is not entailed by
  the actual module text or final evidence.
- Complete analysis of all 15 Step errors, all six additional taxonomy
  errors, controlled deltas, claim-gate precision, released-label geometry,
  and execution integrity:
  `output/agenterrorbench-codex-gpt-5.6-luna-gaia-smoke-v1-agent-judge-luna-gaia-v3p8-case30/analysis/complete-error-analysis-2026-08-15.md`.
- The next candidate must branch from v3.4 and may not inherit the v3.8 claim
  state. The admitted bounded direction is static-document capability versus
  normal raw-output outcome: a static URL extractor is ex-ante capable on a
  static document/PDF, while dynamic video, database UI, open discovery,
  disjoint corpora, and missing-prerequisite cases remain unchanged.

### Candidate 3.9: luna-gaia-v3.9

- Status: complete; 30/30 valid predictions, all cases completed on their
  first isolated attempt, all per-case and merged audits passed, and official
  scoring completed.
- Semantic branch point is Step incumbent v3.4. V3.8 claim state, v3.7
  strategy state, later predictions, and scored shards are not inherited.
- Single semantic axis: when Planning explicitly assigns static text retrieval
  from a specific static document/PDF URL to the URL text extractor, the plan
  is ex-ante capable. Normal raw/unreadable document output is an outcome and
  cannot retroactively create Planning `impossible_action`; any later false
  content claim remains a Lane-A decision at the later step.
- Claimed Step target is rank 1. Dynamic video/audio, interactive database UI,
  open-web discovery, disjoint specialized corpora, missing task-specific
  computation inputs, malformed Actions, source constraints, and external
  exceptions are explicit negative controls.
- Preservation controls are every v3.4 Step-exact row, with ranks 8, 25, 27,
  and 30 emphasized because later candidates lost them. Promotion requires
  strictly exceeding v3.4's 16/30 Step score after a new 30-case run.
- Prompt normalization must restore v3.4 byte-for-byte after removing only the
  new gate and version/validator substitutions. All case sessions remain
  uniform, gold-free, isolated, and fresh.
- Metrics: Step Exact 14/30; Step+Module 10/30; All Correct 7/30. V3.9 is
  rejected; v3.4 remains the 16/30 Step incumbent.
- The claimed rank-1 target succeeds and becomes All Correct. Preservation
  fails at ranks 8, 27, and 30, so the controlled Step delta is `+1 - 3 = -2`.
  Ranks 8 and 27 over-apply the prompt's explicit UI/database negative-control
  wording; rank 30 selects a new early Memory chronology defect unrelated to
  static-document capability.
- The inherited v3.4 inline validation command creates 37 recoverable non-zero
  helper/validator commands, including 18 leading-zero path `SyntaxError`s.
  Every case still passes attempt one, but the next workflow must reuse the
  tested ordinary-argv module CLI as an execution-only repair.
- Complete analysis of all 16 Step errors, seven additional taxonomy errors,
  target/control causality, within-packet lookahead, and execution integrity:
  `output/agenterrorbench-codex-gpt-5.6-luna-gaia-smoke-v1-agent-judge-luna-gaia-v3p9-case30/analysis/complete-error-analysis-2026-08-15.md`.
- The next admitted semantic delta must keep only the literal positive PDF
  condition and omit all enumerated negative media/corpus examples. It must
  branch from v3.4 and preserve all v3.4 exact rows in one fresh full run.

### Candidate 3.10: luna-gaia-v3.10

- Status: complete; 30/30 valid predictions, all cases completed on their
  first isolated attempt, all per-case and merged audits passed, and official
  scoring completed.
- Semantic branch point is v3.4. The only semantic delta applies when the plan
  literally gives a visible `.pdf` URL to `url_text_extractor` to retrieve
  that PDF's text. Raw/unreadable PDF bytes are a normal outcome and cannot
  retroactively create Planning `impossible_action`; a later result claim is
  assessed later in Lane A.
- The delta names no media, UI, database, discovery, corpus, or prerequisite
  negative class. When the literal PDF conditions do not all hold, the prompt
  says to use v3.4 unchanged and infer no analogy.
- Claimed Step target is rank 1. All 16 v3.4 Step-exact rows are preservation
  controls; ranks 8, 25, 27, and 30 receive emphasis only in post-score
  analysis and are never visible to inference.
- Execution-only repair: replace v3.4's quoted inline validator with an
  ordinary-argv module CLI and compact code/message errors. Prompt
  normalization restores v3.4 exactly after removing the PDF rule, version
  substitutions, and this command-only repair.
- Promotion requires a fresh 30-case run to score above v3.4's 16/30 Step
  Exact with no shard reuse or post-score replacement.
- Metrics: Step Exact 14/30; Step+Module 10/30; All Correct 8/30. V3.10 is
  rejected; v3.4 remains the 16/30 Step incumbent.
- Ranks 1 and 6 gain Step; ranks 10, 27, 28, and 30 lose Step, for a net delta
  of `+2 - 4 = -2`. Rank 3 also becomes All Correct without changing Step.
- The literal PDF mechanism is locally repeatable at rank 1, but the prompt
  addition still perturbs unrelated Lane-B/Action priorities. Ranks 10/15
  newly select accepted numeric strings as parameter errors, rank 28 projects
  a dynamic requirement onto discovery, and rank 30 rejects a useful direct
  GitHub probe. Further PDF wording variants are closed as a direction.
- The compact module CLI eliminates all 18 v3.9 leading-zero validator
  failures. Remaining raw-log noise is 25 recoverable helper/evidence errors;
  every case still passes attempt one.
- Complete analysis of all 16 Step errors, all six additional taxonomy errors,
  preservation failures, temporal lookahead, and the next bounded direction:
  `output/agenterrorbench-codex-gpt-5.6-luna-gaia-smoke-v1-agent-judge-luna-gaia-v3p10-case30/analysis/complete-error-analysis-2026-08-15.md`.
- The next admitted semantic hypothesis is announced-subgoal/action-target
  binding, branching from v3.4 without the PDF rule. It claims only rank 2;
  all v3.4 Step-exact rows remain preservation controls.

### Candidate 3.11: luna-gaia-v3.11

- Status: preregistered and implemented after complete v3.10 error analysis;
  engineering validation and fresh full execution are pending.
- Semantic parent is v3.4. The only semantic delta compares an explicit,
  unambiguous next information target in Planning with the direct object of
  the same-step Action. A new tool/host/URL is not alignment when the Action
  instead retrieves an already identified object and no trace statement links
  that inspection to the named target.
- The rule does not change capability, Lane-A claims, constraints,
  prerequisites, Action argument validity, recovery, System packet ordering,
  Lane C, owner, or taxonomy. Ambiguous or implicit targets remain clear.
- Claimed Step target is rank 2. Rank 27 is a later literal target mismatch,
  but v3.4's earlier official-step-3 boundary is a preservation control.
  Every v3.4 Step-exact row remains a control invisible to inference.
- The compact ordinary-argv validator is retained as an execution-only repair.
  Removing the target-binding block and command-only substitutions must restore
  v3.4 exactly.
- Promotion requires a fresh complete 30-case result above v3.4's 16/30 Step
  Exact, with no reuse of v3.10 or prior shards.

# E9-v52 partial-analysis invocation failure

The first read-only attempt to score the 21 persisted partial rows failed
before producing metrics. The script referenced the source label column name
`critical_failure_step` as a `GoldLabel` attribute. Dataset ingestion instead
normalizes that column to `GoldLabel.original_step`; normalized module and
error type are exposed as `module` and `error_type`.

This is an analysis-script schema mismatch. It did not call an LLM, write a
prediction, touch either semantic cache, or inspect any held-out smoke label.
The next falsifiable attempt uses the typed model fields exactly and analyzes
only the already-persisted tuning-v1 rows.

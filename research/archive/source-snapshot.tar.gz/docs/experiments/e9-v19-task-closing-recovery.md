# E9-v19 Pro Task-Closing Recovery Review

E9-v19 is the bounded follow-up to the rejected E9-v18 dry3 attempt and its
case study.  It keeps the complete gold-free trajectories, frozen v13
Scout/Arbiter priors, LLM-only final classification, strict raw validation,
and default provider request body.  It changes only:

- the model from `deepseek-v4-flash` to the user-requested
  `deepseek-v4-pro`; and
- the general recovery test in the semantic prompt.

Recovery must now close the original task requirements.  Merely changing a
tool, query, or branch does not recover an earlier defect when the later path
abandons unresolved constraints.  An operation aimed at a representation
that is explicitly unable to expose the required item-level or historical
fact may be `action/misalignment`; a general search that can return candidates
for later verification is not treated as incapable without direct interface
evidence.

The preregistered dry3 hypothesis is that Pro returns strict JSON, preserves
C01 at step 30 `system/step_limit`, and restores C02 to step 1
`action/misalignment`.  C03 is retained as a known annotation/timeline
localization risk.  Promotion requires all three outputs valid and at least
2/3 Step, Step+Module, and All Correct.

The cumulative budget is dry 367 to 368, full 368 to 378, and future fresh
smoke 378 to 411.  Current authorization 380 covers dry and full only.  Every
failed attempt must complete the mandatory case-study loop documented in
E9-v18 before another model-backed attempt.

# v3.83 / v3.107 AgentErrorBench rest150 scope completion

Date: 2026-09-01

Status: prepared. v3.83 Codex CLI capability preflight passed. v3.107 requires a
fresh Sophnet capability preflight and was not started while the required API
key was absent from the execution environment.

## Purpose and frozen scope

The existing frozen runs cover the released GAIA-50 cohort. This scope
completion evaluates the same semantic Judge protocol on every remaining
released AgentErrorBench trajectory:

- ALFWorld: 100 cases;
- WebShop: 50 cases;
- rest150 total: 150 cases;
- full release after post-score composition: 200 cases.

The source-only cohort is
`agenterrorbench-paper-rest150-v1`. Its order is all ALFWorld trajectory IDs in
lexical order, followed by all WebShop trajectory IDs in lexical order. The
cohort and prediction manifest are frozen before any model execution. Input
preparation reads only `Original_Failure_Trajectory`; it does not open
`Label/`.

This is a transfer/evaluation-scope extension of a protocol tuned on the
exposed GAIA-50 cases. It is not a new Judge semantic version, an official
reproduction of the paper's AgentDebug main method, or a claim of unknown-data
generalization.

## Semantics held fixed

Both executions retain the exact v3.83 semantic protocol:

- protocol: `gaia-v3.83-clean-v3.20-model-only-gpt55-medium`;
- model: `gpt-5.5`;
- reasoning effort: `medium`;
- stages: `packet-state-anchor` → `earliest-causal-challenger` →
  `default-keep-arbiter`;
- one case per fresh stage session/thread;
- upstream state moves only through frozen JSON artifacts;
- at most four cases in parallel;
- at most two semantic attempts per stage;
- no smoke gate, case routing, previous predictions, labels, metrics, or gold
  rationale in inference prompts.

Each complete rest150 run must contain 150 final predictions and 450 accepted
stages, with zero failed cases. Schema, taxonomy, Step range, evidence ownership,
anchor/challenger validation, arbiter exact-copy selection, cohort order, and
gold-free validation must all pass. A complete run tree is hashed before the
first label read, then reverified.

If any stage exhausts its two attempts, the run remains incomplete and
unscored. It is never repaired by replacing one case or stitching predictions.
A retry must be a clean full-150 replicate in a new run directory with the same
frozen protocol and scope.

## Transport-specific executions

### v3.83 Codex CLI

The new scope uses the original `codex exec --ephemeral --ignore-user-config
--ignore-rules` stage contract. The local executable is recorded as
`codex-cli 0.150.1`; a non-benchmark `gpt-5.5`/medium preflight passed on
2026-09-01. The CLI JSONL audit aggregates token usage and scans persisted
command-execution events for reads of labels, scored outputs, metrics, or git
history. The frozen CLI JSONL contract does not expose stage elapsed time, so
the runner separately records end-to-end wall time.

The historical v3.83 GAIA-50 release did not record its Codex CLI build.
Therefore its eventual 200-case report proves composition under the same
semantic protocol/model and abstract CLI transport, not a bit-exact match of
the two CLI builds.

### v3.107 Codex SDK

The SDK execution retains:

- `openai-codex==0.147.0` and its bundled app-server/CLI runtime;
- Sophnet native Responses at `https://api.sophnet.com/v1/responses`;
- provider request retries = 2;
- SSE stream retries = 2;
- outer semantic attempts per stage = 2;
- a fresh ephemeral SDK thread for every semantic attempt;
- API key read only from `SOPHNET_API_KEY`, never from argv/config/artifacts.

The SDK preflight occurs before the benchmark manifest/cohort is opened or
hashed. It must verify the exact model, effort, Responses wire, retry policy,
sentinel hash, fresh thread provenance, usage fields, and secret hygiene. The
latest observed Sophnet state before this preregistration included HTTP 402 in
the v3.112 run, so quota recovery is an external prerequisite. The runner must
not fall back to Chat Completions, a different model, or a different effort.

## Gold boundary and AgentErrorBench-200 composition

The core scorer writes only rest150 results after pre-score freeze verification.
Only after the runner has completed scoring and reverified the frozen tree does
the post-score composer read the matching historical GAIA-50 scored source:

- v3.83 uses its frozen 26/50 GAIA result;
- v3.107 uses its frozen 23/50 GAIA result.

The composition is a set union, not per-case selection. It verifies that the
two ID sets are disjoint and cover exactly 200 released labels, that the
protocol/model/effort/provider/endpoint match, and that the frozen GAIA
prediction, legality audit, and gold-free freeze hashes match. Output order is
ALFWorld 100 → GAIA 50 → WebShop 50. Reported Step Exact denominators are
rest150=150 and full release=200, with environment denominators 100/50/50.

## Commands

Use module invocation from the repository root:

```bash
.venv/bin/python -m scripts.prepare_agent_judge_agenterrorbench_rest150

.venv/bin/python -m scripts.run_agent_judge_agenterrorbench_v3_83_rest150 \
  --preflight-only
.venv/bin/python -m scripts.run_agent_judge_agenterrorbench_v3_83_rest150
.venv/bin/python -m scripts.run_agent_judge_agenterrorbench_v3_83_rest150 \
  --execute --max-workers 4 --max-attempts 2

.venv/bin/python -m scripts.run_agent_judge_agenterrorbench_v3_107_rest150 \
  --preflight-only
.venv/bin/python -m scripts.run_agent_judge_agenterrorbench_v3_107_rest150
.venv/bin/python -m scripts.run_agent_judge_agenterrorbench_v3_107_rest150 \
  --execute --max-workers 4 --max-attempts 2
```

The 93 MiB prediction manifest and case shards remain generated output and are
not intended for Git. The small cohort, scripts, configs, tests, preregistration,
and final release artifacts are the repository-facing reproduction surface.

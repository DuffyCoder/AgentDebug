# E9-v14: Batched five-lane causal Critic

Status: preregistration design. No E9-v14 provider call is authorized by this
document, and none has been made as part of writing it. E9-v13 full30 is
rejected and is used only as the frozen semantic predecessor and cumulative
usage anchor for this single-variable experiment.

## Authoritative E9-v13 result

The authoritative tuning result is the frozen `tuning-v1` full30 run under:

- `output/agenterrorbench-gpt-4.1-tuning-v1-e9-v13-atomic-taxonomy-pair-full30/metrics.json`;
- `output/agenterrorbench-gpt-4.1-tuning-v1-e9-v13-atomic-taxonomy-pair-full30/predictions.jsonl`;
- `output/agenterrorbench-gpt-4.1-tuning-v1-e9-v13-atomic-taxonomy-pair-full30/unscored-predictions.jsonl`;
- `output/agenterrorbench-gpt-4.1-tuning-v1-e9-v13-atomic-taxonomy-pair-full30/predict-run.json`;
- `output/agenterrorbench-gpt-4.1-tuning-v1-e9-v13-atomic-taxonomy-pair-full30/promotion.json`.

Its frozen result is:

| Scope | N | Step Exact | Step+Module | All Correct | Failed |
|---|---:|---:|---:|---:|---:|
| Overall | 30 | 6/30 (20%) | 3/30 (10%) | 3/25 (12%) | 1 |
| ALFWorld | 10 | 2/10 | 1/10 | 1/6 | 0 |
| GAIA | 10 | 3/10 | 2/10 | 2/10 | 1 |
| WebShop | 10 | 1/10 | 0/10 | 0/9 | 0 |

The one failed output is an `invalid_taxonomy` result. It remains in the
30-case Step and Step+Module denominators. The 22 logical completions used by
the complete run had 22 HTTP attempts, zero retries, 3,151,547 provider input
tokens, 21,676 provider output tokens, and 3,173,223 total tokens. Only 20 of
those completions were new during full30 because its first batch reused the
two dry3 stage results.

Post-prediction tuning analysis shows that the failure is systematic rather
than a formatting-only problem:

- among 29 successful predictions, 15 steps are early, eight are late, and
  six are exact;
- the predicted modules are `action=22`, `system=6`, `planning=1`,
  `memory=0`, and `reflection=0`, while the released gold modules are
  `planning=12`, `reflection=6`, `action=5`, `memory=5`, and `system=2`;
- only 4/22 action-module predictions have an action gold module. The 18
  action false positives comprise eight planning, five reflection, four
  memory, and one system gold cases;
- the Scout emitted 27 candidates: 26 used the `capability_mismatch` search
  category, 21 used an action taxonomy pair, five used a system pair, one
  used a planning pair, and none used memory or reflection;
- a Scout candidate covered the gold step in only 4/30 cases, covered the
  gold step and module in only 2/30, and covered the complete scorable gold
  tuple in only 2/25;
- for the 26 candidate reviews preserved in successful normalized Arbiter
  audits, the Arbiter marked 24 as `survives` and only two as `rejected`.
  Its final tuple exactly matched a Scout candidate in 22/29 successful
  predictions;
- WebShop has nine early predictions and one same-step/wrong-module
  prediction. Nine of its ten final roots are placed at step 1 and the other
  at step 2. Seven step-1 roots came from Scout candidates and two from
  Arbiter supplemental roots.

The repeated WebShop rationale treats a free-text retrieval query as
defective because it cannot guarantee structured filtering. This is an
unsupported capability inference: an initial retrieval probe may reasonably
return candidates for later inspection, and irrelevant results cannot make
that earlier choice retroactively defective. Several ALFWorld and GAIA
errors have the same temporal shape: later feedback such as `Nothing
happens`, a missing object, or an eventual wrong answer is used to relabel an
earlier admissible action, while an intervening memory, reflection, or plan
defect is never surfaced. The v13 Arbiter is therefore independent in its
contract but strongly anchored in its observed behavior.

## Single-variable E9-v14 hypothesis

E9-v14 changes one semantic component: it appends one fresh batched LLM
Critic after the byte-identical E9-v13 Scout and Arbiter predecessor. It does
not change Canonical Trace conversion, JudgeView projection, batching,
taxonomy, provider configuration, E9-v13 Scout prompt, or E9-v13 Arbiter
prompt.

The falsifiable hypothesis is:

> A final Critic that must perform a fixed five-lane chronological scan before
> reviewing the untrusted E9-v13 prior root, and that distinguishes a
> reasonable first probe from the first mature recommitment to an observably
> failed policy, will preserve the two existing dry3 exact steps, recover the
> missed WebShop step, and raise full30 Step Exact to at least 12/30 with no
> more than one failed output.

The hypothesis is rejected if either the dry3 or full30 gate below fails.
There is no fallback threshold, per-environment exception, post-hoc semantic
repair, or choice between the v13 and v14 answers.

## Predecessor isolation and Critic input

The E9-v13 Scout and Arbiter remain provenance-bearing predecessors, not
alternative classifiers. Before a case may enter the Critic stage, the
workflow must strictly verify their frozen stage identities, dependency and
request hashes, raw-response hashes, batch and case ordering, strict JSON
contracts, taxonomy membership, evidence ownership, and raw-chain
reconstruction. Validation may reject or isolate malformed predecessor
semantic content but may never repair, infer, rewrite, or choose a root.

The Critic receives the complete gold-free anonymous JudgeView and only one
semantic object from the E9-v13 chain: the exact validated raw Arbiter prior
root. It does **not** receive Scout candidates, Scout summaries, Arbiter
candidate reviews, Arbiter audit prose, released labels, scores, or tuning
metrics. If the frozen Arbiter envelope is structurally valid but its
case-level final root is unavailable, the Critic receives `prior_root: null`
and must still diagnose directly from the complete timeline. A faithfully
persisted Arbiter transport or envelope failure likewise supplies null priors
for that batch so the complete timelines can still be judged and the failure
remains visible. A source-cache byte, request identity, dependency, ordering,
or raw-versus-parsed integrity failure stops before the Critic call; an
invalid predecessor tuple is never normalized into a plausible prior root.

The prior root is explicitly untrusted. It is presented after the complete
timeline as a prompt-order late exposure. Its purpose is to give the Critic
one concrete hypothesis to falsify, not a default answer or a vote. Because
the timeline and prior coexist in one request, this ordering does not prove
that the model completed an independent scan before noticing the prior; v14
is therefore described as a *prior-late balanced rescan*, not as two
causally isolated Critic passes.

## Fixed five-lane scan

For every case, the Critic must emit exactly five lane entries in this order,
using `null` when no candidate survives in a lane:

1. **Memory** — compare memory claims with all observable history available
   before that output. Look for hallucination, retrieval failure, or harmful
   simplification without treating a missing tag as an error.
2. **Reflection** — compare reflection with the direct action result and
   environment feedback it assesses. Localize progress, outcome, and causal
   misinterpretation before downstream plan or action symptoms.
3. **Planning** — hide the concrete action and test the plan against task
   constraints and known state. A repeated policy becomes eligible only at
   the first *mature recommitment*: prior observable feedback has already
   shown the same material target, state, or query policy to be unproductive,
   the agent has an opportunity to revise it, and the plan recommits without
   a meaningful semantic change. The first probe of unobserved state and the
   same operation over a distinct target are normal exploration.
4. **Action** — hide downstream outcomes and compare the concrete action with
   a sound current plan and the admissible interface. Free text, lack of a
   structured filter, inability to guarantee every qualifier, or later poor
   results do not establish misalignment or parameter error. A capability
   limitation requires affirmative contemporaneous interface or execution
   evidence, not conjecture.
5. **System** — consider only an external tool, environment, model, or fixed
   boundary that is independently causal after local roots and recovery have
   been audited. A large step number or failed episode is insufficient.

Each lane selects zero or one chronological possibility with an exact
same-step, owner-module evidence quote, a short basis covering the
contemporaneous defect and counterfactual, and a recovery enum. Lane order is
an audit order only; it
is not a priority, rank, weight, or vote. After the lane scan, the Critic must
review the v13 prior root for contemporaneous validity, ownership, hindsight,
recovery, and causal sufficiency, compare it with all lane possibilities, and
emit exactly one fresh final root.

## Sole raw semantic classification

The Critic's raw fields

- `critical_step`;
- `taxonomy_pair` (the exact atomic `module/error_type` pair);
- `evidence_quote`;
- `root_cause`;

are the sole E9-v14 semantic classification. The v13 prior root, all five
lane records, and the prior-root review are untrusted reasoning artifacts and
cannot overwrite or backfill those fields. Deterministic code may only parse
the strict schema, validate taxonomy, map the Critic-selected step to an
event, bind the exact quote to same-step/module provenance, enforce stage
lineage and budgets, and fail closed. It must not select between v13 and v14,
derive a tuple from a lane, or use confidence, scores, weights, votes,
priorities, heuristics, or deterministic findings.

## Frozen promotion gates

### Dry3

The dry3 cohort and order remain frozen. E9-v13 achieved 2/3 Step Exact on
this panel: the ALFWorld terminal root and GAIA action root were exact, while
the WebShop case was prematurely assigned to step 1 instead of its mature
step-13 planning recommitment.

E9-v14 dry3 is promoted only when all of the following hold:

- trajectory denominator is exactly 3;
- Step Exact is exactly 3/3;
- Step+Module Exact is exactly 3/3;
- All Correct is exactly 3/3;
- successful predictions are exactly 3 and failed outputs are exactly 0;
- all raw-chain, predecessor, gold-isolation, evidence, cache, and budget
  integrity checks pass.

A 2/3 result does not test the stated hypothesis and is rejected even if it
selects a different pair of correct examples.

### Full30

Only a passing dry3 candidate may run full tuning. E9-v14 full30 is promoted
only when all of the following hold:

- trajectory denominator is exactly 30;
- Step Exact is at least 12/30;
- Step+Module Exact is at least the frozen original GPT-4.1 baseline, 3;
- All Correct is at least 3;
- failed outputs are at most 1/30;
- failed or invalid outputs remain in the denominator;
- the full run reuses only the byte-identical frozen dry first batch;
- all raw-chain, predecessor, gold-isolation, evidence, cache, and budget
  integrity checks pass.

Environment results, status counts, requests, retries, and provider token
usage must also be reported. Step+Module and All Correct are secondary guard
rails; neither replaces the Step Exact promotion condition.

### Smoke30

Only a passing full30 candidate may be frozen for the held-out one-shot run.
Smoke-v1 is accepted only when all of the following hold:

- trajectory denominator is exactly 30;
- Step Exact is at least 12/30;
- Step+Module Exact is at least the original GPT-4.1 baseline, 2;
- failed outputs are at most 1/30;
- All Correct is reported but has no promotion minimum;
- all 33 Scout, Arbiter, and Critic requests are fresh phase misses;
- all invalid outputs remain in the denominator and every raw-chain,
  gold-isolation, cache-origin, one-shot, and budget check passes.

## Freeze order and code archive

Every phase follows one irreversible order: freeze the final source, tests,
and this protocol; create one deterministic write-once archive with
`freeze-code-bundle`; then create the phase preregistration with the same
archive passed as `--code-bundle-archive`. The preregistration records the
archive's absolute path, file hash, member-set hash, member count, and exact
per-file source identity. Prediction and promotion reopen the archive and
require every member byte to remain identical to the current closed local
import graph. Any later source, test, or protocol edit therefore invalidates
the archive and preregistration; a new archive must be created before a new
preregistration. Dry3, full30, and any later authorized smoke phase use the
same archive identity and path through the predecessor chain.

Promotion also requires complete provider telemetry for every current-phase
cache miss. Each live stage must account for one logical completion, at least
one HTTP attempt, retries equal to attempts minus one, a nonempty request,
and structurally valid usage, token, and finish-reason counters. Their exact
aggregate must equal the predict-run telemetry and the preregistered new-call
budget: one for dry3, ten for the remainder of full30, and 33 for fresh
three-stage smoke. Reused dry3 telemetry is not charged to full30.

## Logical-completion authorization

The rejected E9-v13 full30 run is the usage anchor at 362 cumulative logical
completions. E9-v14 reuses its verified Scout and Arbiter tuning cache and
adds only the Critic stage:

| Stage | New logical completions | Cumulative bound |
|---|---:|---:|
| Before E9-v14 | 0 | 362 |
| Dry3: one fresh Critic batch | 1 | 363 |
| Remaining full30: ten fresh Critic batches | 10 | 373 |

The current user-authorized cumulative ceiling is 380, so it covers the
preregistered E9-v14 dry3 and, only after a passing dry gate, the remaining
full30 Critic calls. Any hard stop must occur before launching a provider
request whose logical completion could exceed the relevant bound. HTTP
attempts and retries are reported separately and do not silently change the
logical-completion accounting.

A future smoke-v1 evaluation has no reusable E9-v14 stage cache. Its eleven
batches require a fresh Scout, Arbiter, and Critic completion per batch:
33 new logical completions, taking the cumulative maximum from 373 to 406.
The current ceiling of 380 does **not** authorize that run. Even if full30
passes, the workflow must freeze the final candidate and request explicit
authorization to at least 406 before making any smoke provider call.

## Gold and smoke hygiene

Tuning gold was loaded only after unscored E9-v13 predictions had been
persisted, as permitted for post-prediction error analysis. E9-v14 provider
payload construction must continue to accept only Canonical Trace or a
gold-free JudgeView; it must not receive `critical_failure_step`, gold module,
gold failure type, `step_annotations`, gold reasoning, metrics, or any mapping
from trajectory ID to answer. E9-v14 hypotheses, schemas, gates, prompt
versions, plans, code hashes, and authorization claims must be frozen before
their first corresponding provider call.

No smoke trace, label, prediction, or per-example answer was used to design
this experiment. During the v13 forensic analysis, one broad path-only
locator command included the `benchmarks` directory and reported the
`benchmarks/cohorts/smoke-v1.json` filename as a matching path. It did not
open or display that manifest's contents, IDs, labels, traces, predictions,
or per-example or aggregate results, and no such information influenced the
v14 hypothesis. This path-only touch is retained here rather than omitted
from the hygiene record.

The smoke cohort must not be run or inspected during v14 tuning. If the
candidate passes full30 and receives the additional authorization, smoke is
run exactly once from a fresh three-stage cache, with all failures retained
in the fixed 30-case denominator.

## Scope of any eventual result

Passing tuning and smoke would establish only consistency with the frozen
AgentErrorBench cohorts under the preregistered GPT-4.1 Sophnet configuration.
It would not by itself demonstrate correctness or generalization on real
Moltbot/OpenClaw sessions. OpenClaw validation requires a separately frozen,
representative trace set and independently annotated evaluation protocol.

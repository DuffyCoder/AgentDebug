# E9 v37 dry3 failure case study

## Result

v37 failed the frozen dry3 gate and is rejected:

- Step Exact: 0/3 (v36: 1/3)
- Step+Module Exact: 0/3 (v36: 1/3)
- All Correct: 0/3 (v36: 1/3)
- valid predictions: 3/3
- logical completions: 2
- HTTP attempts: 2
- retries: 0
- provider tokens: 381,173 input, 24,783 output, 405,956 total
- deterministic semantic mutations: 0

## Hypothesis check

The incumbent-preservation mechanism worked mechanically. The Selector's raw
reasoning explicitly compares every frozen incumbent with the fresh proposal,
including the correct GAIA step-1 `action/misalignment` incumbent. Therefore
the failure is not hidden or dropped hypothesis data.

The semantic hypothesis failed. The Selector actively rejected the correct
GAIA incumbent as a valid exploratory probe. It accepted the fresh Candidate
proposal in all three cases.

## Case attribution

- **ALFWorld:** gold 30/system/step_limit; prediction
  16/planning/inefficient_plan. The new recommitment wording incorrectly
  treats cabinet 8 as repeating a failed policy even though it is a distinct,
  previously unvisited state. This destroys v36's correct terminal-boundary
  diagnosis.
- **GAIA:** gold 1/action/misalignment; prediction
  4/planning/constraint_ignorance. Complete incumbent visibility is
  insufficient. Without a concrete interface contract in the visible trace,
  Flash treats the page-text extraction as a valid first probe and assigns
  the later obviously wrong answer plan.
- **WebShop:** gold 13/planning/inefficient_plan; prediction
  6/planning/inefficient_plan. The maturity clarification moves v36's step 4
  to step 6 but remains seven steps early. It selects the first acknowledged
  poor page sequence rather than the benchmark's later critical
  recommitment.

The miss-direction distribution is one late prediction (GAIA) and two early
predictions (ALFWorld and WebShop). There are no parser, taxonomy, evidence,
or transport failures.

## Reproducibility observation

Flash at temperature zero remains semantically unstable on the very large
three-case prompt. Earlier v34/v35 runs selected the correct ALFWorld and GAIA
steps with a more explicit first-defect/terminal-guard contract, while v37
selects neither. Temperature zero is not a guarantee of identical output for
this provider/model.

## Next direction

Do not continue the v37 maturity rule. Return to the historically best
full30 semantic contract: the v30 first-defect critic achieved 10/30 Step
Exact, 5/30 Step+Module, and 4/25 All Correct, while passing this dry set at
2/3. Preserve its two evidence-based boundaries:

1. the same operation over distinct, previously unvisited states is novel
   coverage and preserves a genuine terminal step-limit root;
2. a representation known from visible interface/target semantics to omit
   required collection identity, ordering, or change history can be an
   action capability mismatch even at the first probe.

Use that contract as the next controlled baseline rather than accumulating
new maturity heuristics. The final raw LLM output remains the only semantic
decision; incumbent and fresh proposals remain untrusted and no deterministic
selection, confidence, score, vote, or weight is introduced.

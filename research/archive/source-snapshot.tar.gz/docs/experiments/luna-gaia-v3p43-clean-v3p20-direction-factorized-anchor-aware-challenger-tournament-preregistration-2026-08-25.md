# Luna GAIA v3.43 preregistration

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.43-clean-v3.20-direction-factorized-anchor-aware-challenger-tournament`
- Direct semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: v3.20, Step Exact `25/50`
- Acceptance: Step Exact `>25/50`; Goal completion: Step Exact `>=30/50`
- Frozen `gaia-paper-v1` 50 cases; dataset SHA-256 `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`; cohort SHA-256 `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- `gpt-5.6-luna`, reasoning `medium`; no smoke gate; full GAIA-50 after offline validation.

Single major mechanism: retain the clean v3.20 anchor, packet-state ledger, and
checkpoint unchanged. Add one anchor-aware, direction-factorized challenger
tournament. A fresh bounded panel sees only that frozen anchor bundle and the
trace, performs complete chronology, and may freeze at most one strict-earlier
candidate and at most one strict-later candidate. The lanes cannot emit the
anchor Step and do not compete for one global slot. A fresh selector sees only
the clean anchor and the two frozen exact-copy candidates, defaults to the
anchor under uncertainty, and may select only one existing prediction. The
candidate pool is capped at three Steps.

The frozen v3.42 result is the immediate falsifiable basis. It was complete and
legal at Step Exact `22/50`; its fresh anchor was `21/50` and its bounded
candidate oracle was only `26/50`, below the Goal. Its three evidence-class
lanes emitted 49 candidates, including 29 maturity candidates. The selector
made four actual Step changes: one direct gain, three wrong-to-wrong, and no
direct regression. Across 28 errors, 24 lacked the released Step in the
candidate set and four contained it but retained the wrong anchor. The audit
classified eight candidate-recall failures and two late-symptom preferences;
the earlier/later split is therefore tested as the missing search factor rather
than adding another evidence taxonomy or state-only ledger.

Expected gains come from anchors that are later symptoms and anchors that are
reasonable probes, recovered defects, mechanical predecessors, or other
noncritical predecessors before an independently mature later boundary. The
principal regression risk is an incumbent-correct direct execution or literal
constraint anchor being reclassified as a probe/downstream symptom. Controls
are strict direction relative to the immutable anchor, at most one candidate
per direction, literal owner/evidence/repair certificates, normal-failure and
recovery vetoes, no raw tool-outcome owner, exact-copy-only selection, and
default keep. Position alone cannot win.

v3.21 through v3.42 and all other rejected versions remain immutable and are
not semantic parents. Their prompts, panels, challengers, selectors, ledgers,
validators, and predictions are not inherited or visible to inference. v3.43
is implemented afresh over v3.20 anchor semantics and shared execution
utilities. Inference may not read labels, scores, audits, prior predictions,
experiment documents, case studies, or git history.

Falsifiers: the anchor-plus-two-direction candidate oracle is below `30/50`,
the panel emits more than two candidates or violates strict direction, any
selected prediction is not an exact input copy, or final Step Exact does not
exceed the accepted incumbent `25/50`.

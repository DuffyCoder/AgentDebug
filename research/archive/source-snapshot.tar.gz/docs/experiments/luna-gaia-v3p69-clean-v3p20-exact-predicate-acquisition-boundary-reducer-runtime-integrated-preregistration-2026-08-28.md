# Luna GAIA v3.69 预注册：exact-predicate reducer，完整运行接口

状态：执行前冻结。

## 冻结实验合同

- semantic parent：accepted Luna v3.20，Step Exact `25/50`。
- 版本：`agentdebug.codex-agent-judge.luna-gaia.v3.69-clean-v3.20-exact-predicate-acquisition-boundary-reducer-runtime-integrated`。
- 数据集：冻结 `gaia-paper-v1` 50 例。
- 模型/effort：`gpt-5.6-luna` / `medium`。
- v3.4 基线：Step Exact `21/50`。
- 接受：合法完整 GAIA-50 Step Exact `>25/50`。
- Goal 完成：合法完整 GAIA-50 Step Exact `>=30/50`。
- 无 smoke 门控；直接完整 GAIA-50。

唯一主要语义机制是从 v3.20 clean branch 显式移植的 `exact-predicate acquisition
boundary reducer`。它最多提出一个 earlier probe-veto row 或一个 later mature boundary；
只有 capability、actual exact-predicate outcome、contribution、later relation、local repair
和 recovery gate 全部成立才 exact-copy candidate，否则 exact-copy fresh v3.20 anchor。
Module/type 只用于合法输出。

本版本不继承 rejected lineage 中的 proposal panel、candidate census、challenger、arbiter、
selector 组合或其他规则。v3.66--v3.68 仅提供同一个待重检机制和运行失败证据；semantic
parent 始终是 v3.20。推理不读取 v3.20 或任何历史逐例预测。

## v3.68 runtime first divergence 与唯一运行修正

v3.68 已完成全部 50 例尝试但未评分：46 例通过 anchor、reducer 和 selector 后，因为
继承 executor 调用缺失的
`validate_and_write_agent_judge_luna_gaia_v3_67_audit` 而失败；另 4 例在两次安全重试
后仍因 `invalid_evidence_ownership` 停在 anchor。该结果不构成 exact-predicate 语义机制
的 Step 实验。

v3.69 只补齐并测试 inherited response-only `_execute_case` 所引用的全部 protocol symbol，
特别是 final audit compatibility entry point。compact embedded JudgeView、严格 evidence
validator、两次结构重试上限、模型、effort 和选择语义均不改变。新增 interface inventory
集成测试从真实 `_execute_case` 源码枚举 `protocol.*` 调用并验证接口存在，避免再次发生
相同 post-inference failure。4 例 ownership 风险保持可证伪：不放宽 validator；若重现并
造成非 50/50，本版本按合法性失败拒绝。

## gains、regressions 与判伪

预期 gain 来自 earlier ledger probe 在实际 outcome 后无法获得 active-subgoal exact
predicate、而 anchor 只重复或传播同一缺口的统一簇。主要 Step 回归风险是把获得必要
identifier/source lead 的合理 probe 过早升级，或把 later symptom 错当独立 mature
boundary。运行风险是 fresh response 再次耗尽两次 literal-evidence ownership 重试。

若相对 frozen v3.20 gains 不大于 losses、final Step Exact `<=25/50`，或 50/50、schema、
taxonomy、evidence、hash、gold-free、tool-free、write-topology 任一验证失败，则拒绝。
只有合法 `>=30/50` 才完成 Goal。

## 执行前冻结哈希与离线验证

- protocol：`2feca29a6f3af535d35aaa95ca765d1f6b6d8f0a71ab7dfc07190cfb87220700`
- runner：`b44aa21c595273a5b9a68b665684bcbcf1c63ae8b9f999bbcf2d2fdf92327199`
- access auditor：`6adbef2e0e6bd1e83e955e54c3c93311213abcd55689a99463a4d7e389e039fc`
- registry：`ec001b5e9c229c3d4595950bcfb20afe6df36a56a4fd7b42a3659914dc05ec53`
- tests：`54f9a86ca39229558cbdea1ae47d6c75a8195599ef57c107d64054c65467ff71`
- taxonomy：`d7e4b878059bbecec0a8fd3f078c0aeb5755bf9e65bb938c897dd83685f28c5c`
- semantic parent v3.20：`3e886325bf0a4b4d4a3e770071c0a36fe81dab2bebaf5015561ca828b6c2e4f9`
- prediction manifest：`77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- cohort：`31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`

离线验证：v3.69/v3.68/v3.67/v3.66/v3.20 相关测试 `29 passed`；compile、registry、
真实 executor protocol-interface inventory、50-case dry plan、100 sessions、direct parent、
单例 final aggregate validator 和 prompt 长度 `31,444--812,998` 全部通过。

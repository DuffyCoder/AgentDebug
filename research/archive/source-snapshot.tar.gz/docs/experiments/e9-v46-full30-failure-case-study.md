# E9 v46 full30 failure case study

## Outcome

v46 passed the frozen dry3 gate at 2/3 on Step Exact, Step+Module Exact, and
All Correct. Its full30 tuning run then completed all 30 cases with valid raw
Selector outputs, but did not reach the semantic promotion threshold:

- Step Exact: 9/30 (30.00%; gate requires 12/30);
- Step+Module Exact: 3/30 (10.00%; gate requires 3/30);
- All Correct: 3/25 (12.00%; gate requires 3/25);
- successful outputs: 30/30;
- failed outputs: 0/30;
- environment Step Exact: ALFWorld 3/10, GAIA 4/10, WebShop 2/10;
- new full30 logical completions: exactly 20;
- HTTP attempts: exactly 20, with zero retries;
- provider tokens: 3,654,148 input, 397,937 output, 4,052,085 total.

The rejected promotion is bound by
`5d69876962d95958b1870f1f6c9d12aec0e186575dc39122771e255b83a33ce6`.
Every integrity, gold-isolation, raw-Selector, runtime-budget, cache-reuse, and
minimum secondary-metric check passed. Only
`step_exact_minimum_correct` failed. Held-out smoke must not run from v46.

## Provider and format attribution

This was not a provider, transport, JSON, length, taxonomy, evidence-owner,
or event-mapping failure. All twenty live requests ended with `stop`; the
number of HTTP attempts equals the number of logical completions, so there
were no retries. Every one of the 30 final records has `status=success`.

The score report marks aggregate telemetry coverage as 10/11 batches because
the first active Candidate/Selector pair was reused byte-for-byte from the
accepted dry3 run. The promotion verifier separately checks current-run
telemetry and the exact dry reuse, and both checks passed. That reporting
field therefore did not reject the run.

## Candidate-recall attribution

The dominant blocker moved upstream of the Selector. Reconstructing the raw
v44 Candidate response for each case gives:

- the union of `terminal_guard`, `first_defect`, and `branch_commitment`
  contains the released critical step in only 10/30 cases;
- the final Selector is Step Exact on 9/30 cases;
- the frozen Arbiter prior contains the released step in 6/30 cases;
- the frozen Scout candidate/terminal union contains it in 8/30 cases;
- the unscored union of v44 lanes, Arbiter prior, and Scout steps contains it
  in 13/30 cases.

The last union is diagnostic evidence only. It is not a vote, score, fallback,
or permitted deterministic root selector. It proves that the 12/30 target is
present in independent LLM hypothesis space, while the three v44 lanes omit
two useful defect shapes and the Selector rejects two other present steps.

v46's persistent-information Selector rule did what its dry3 hypothesis
claimed: it retained C01's real step-limit boundary, corrected C02 to the
early action/misalignment root, and preserved a later repeated-search root for
C03. Its full30 failure therefore does not justify another narrow change to
that rule alone.

## High-leverage semantic misses

Four wrong cases expose a path from 9/30 to the 12/30 gate without any
numeric correction or gold-dependent runtime behavior.

1. `Qwen3-8B_022_id_22___chat_b012_t00_e04-7e3c13ba`: the released root is
   step 5 reflection/causal_misattribution. The v44 first-defect lane contains
   step 5 but describes planning/inefficient_plan; the Selector chooses the
   terminal step limit. By step 5 the observation has repeatedly failed to
   show a desklamp at the desk, yet reflection persists in attributing the
   target to that location. This is a mature contradicted assumption, not
   novel coverage that the step-limit guard should protect.
2. `GPT-4o_011_memory_b001_t00_e03-21a3a421`: the released root is step 3
   memory/over_simplification. The v44 lanes first mention step 5, while the
   frozen Scout contains step 3. A memory summary can become defective at the
   first task-relevant omission even when a later summary makes the missing
   fact more conspicuous. The current temporal lanes have no dedicated audit
   for lossy state summaries.
3. `Qwen3-8B_015_chat_b000_t00_e15-75a3b882`: the released root is step 7
   action/misalignment. At that step the plan says to verify color before
   purchase but the action buys immediately. The v44 Candidate represents
   the final step only as a terminal boundary and the Selector chooses an
   earlier search-plan inefficiency. A same-step plan/action handoff violation
   is independently observable and causally sufficient.
4. `Llama3.3-70B-Turbo_019_054`: the released step is 5 with an empty released
   failure type. v44 includes step 5 but the Selector chooses a later malformed
   action. With no released reasoning or scorable type, this row is weak
   evidence for a new general rule and will not drive v47.

The wider error table supports the same diagnosis. All six released
`inefficient_plan` cases miss the exact step, but their predictions fall on
both sides of gold and often identify a defensible repetition checkpoint.
No global early/late offset is supported. WebShop's 2/10 result is especially
consistent with missing plan/action handoff and state-summary candidates.

## v47 falsifiable direction

v47 will retain the v46 final Selector policy and replace the three-lane
Candidate census with five independent, fully structured LLM lanes:

1. the existing `terminal_guard`;
2. the existing `first_defect`;
3. the existing `branch_commitment`;
4. `state_summary_loss`, which audits memory/reflection summaries for the
   first task-relevant observed fact, uncertainty, or completed coverage that
   is omitted or distorted and then changes a dependent decision;
5. `plan_action_handoff`, which audits whether a concrete action implements
   verification, filtering, ordering, state-change, and other requirements
   that the same-step plan explicitly makes applicable before commitment.

All lanes remain untrusted LLM hypotheses. They have no confidence, score,
rank, weight, probability, vote, or deterministic priority. The independent
Selector remains the sole source of final step, module, error type, evidence,
and root cause; it may reject every lane and emit a fresh diagnosis.

The Selector receives three matching categorical checks:

- a repeatedly retained assumption that is contradicted by observations is
  not protected as novel search merely because the episode later hits a step
  limit;
- a task-relevant lossy summary owns the branch only when a dependent output
  actually relies on the omitted/distorted state and no later recovery occurs;
- an action that commits, buys, answers, or mutates state before a same-step
  planned verification is complete is action/misalignment, unless that
  verification had already been completed earlier.

This hypothesis is falsified if the frozen v47 dry3 run falls below 2/3 on any
semantic gate, or if a promoted full30 run remains below 12/30 Step Exact.
After the v46 cumulative stop at 564, v47 reserves exactly two new calls for
dry3 (564 to 566), twenty for the remaining full30 batches after dry reuse
(566 to 586), and forty-four for a future fresh four-stage smoke run (586 to
630). These are phase hard stops and durable audit ledgers, not a restored
global authorization cap. Any failed provider or benchmark attempt requires
another completed case study before a further LLM call.

# GAIA v3.100 GPT-5.5 short-bound access tournament preregistration

Date: 2026-08-30

## Frozen identity and semantic mechanism

- Version: `agentdebug.codex-agent-judge.gaia-v3.100-gpt55-short-bound-access-audited-predicate-handoff-tournament`.
- Direct semantic parent: accepted v3.83, Step Exact `26/50`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Dataset/cohort identities: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11` / `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction/cohort manifest file hashes: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc` / `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Model/reasoning effort: `gpt-5.5` / `medium` in both stages.
- Only semantic change relative to v3.83: one outcome-conditioned predicate-
  handoff tournament over every native fresh-ledger Step, replacing the
  incumbent challenger/arbiter.

Anchor, admission, evidence ownership, taxonomy, singleton behavior, and final
exact-copy freeze remain unchanged. No rejected predictions, labels, case IDs,
or routing information enters inference.

## Runtime-only correction

- A short, unique, versioned symlink is created per case/stage/attempt under
  `/tmp`; its target is the exact real attempt inspector.
- The prompt names only this short path. The audit resolves it and requires
  equality with the real attempt inspector; any other target/path is fatal.
- The real inspector continues to resolve its staged document beside itself, so
  symlink invocation does not change evidence bytes.
- Stage-specific coverage, output-budgeted chunks, zero-first-chunk alias,
  strict command parsing, failed/incomplete-call rejection, and all gold-free
  constraints remain unchanged.

This correction cannot add, remove, rank, or select a Step.

## Risks and decisions

- Semantic gain target: incumbent errors whose gold Step is already in the
  native ledger.
- Main semantic regression risk: false promotion of reasonable early probes.
- Transport risk: stale or redirected short links; the runner refuses a
  collision and the audit resolves every command path to the exact attempt.
- No smoke gate. Freeze before scoring.
- Reject if illegal/incomplete or Step Exact `<=26/50`; accept only above 26.
- Goal completes only at Step Exact `>=30/50`.
- Step Exact is the sole selection metric.

## Pre-inference freeze

- Protocol SHA-256: `d0ef2da041cd97f2ee75b4b2f54511b7cfd99da7e4e8a1eb24802a667f8c9ea9`.
- Runner SHA-256: `55a2ac28c14d73bff74beebfe53e7691ca90500613eb19fb3e73035a0c1ee334`.
- Inspector SHA-256: `605b1473ff18fe0c7ddadf8f47074e23c689f4328137be297c86c75141a97160`.
- Targeted test SHA-256: `b57ef1a5063f72a5526da45b790763d76d95fc0dd0fb6f58244881533580dc9b`.
- Registry SHA-256: `a0c4e8ea375c5606ff470dca2a0b2a59242b0023f0eea39c353490ccba672486`.
- Offline validation: compilation, 50-case dry preparation, and 37 targeted/
  inherited tests passed, including short-link collision/target checks, parser
  resolution, prompt shortening, encoded bounds, stage coverage, parent,
  thresholds, registry, and gold/router scans.

This version is frozen before full inference.

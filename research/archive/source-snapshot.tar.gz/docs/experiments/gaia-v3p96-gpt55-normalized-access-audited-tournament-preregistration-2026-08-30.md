# GAIA v3.96 GPT-5.5 normalized-access audited tournament preregistration

Date: 2026-08-30

## Frozen identity

- Version: `agentdebug.codex-agent-judge.gaia-v3.96-gpt55-normalized-access-audited-predicate-handoff-tournament`.
- Direct semantic parent: accepted v3.83, Step Exact `26/50`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Dataset manifest identity SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort identity SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Cohort manifest file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Frozen v3.83 protocol SHA-256: `a97908a78cec8df5fe9e4777d30aa9ecf498d1cdd1d692a42cc66976e9844531`.
- Frozen v3.83 predictions SHA-256: `f74161b06c456461ccacdcf7c708157154e8e9810cb5dffa8ef09352698fca3d`.
- Model and reasoning effort: `gpt-5.5` / `medium` for both stages.

## Single semantic mechanism

Relative to accepted v3.83, replace only its challenger/arbiter tail with one
outcome-conditioned predicate-handoff tournament over every Step in the fresh
native v3.83 ledger. The fresh v3.83 packet-state anchor, model, effort, ledger
construction, module/type legality, evidence ownership, and exact-copy final
freeze remain unchanged. No rejected-version prediction or per-case route is
available to inference.

The tournament tests one falsifiable hypothesis: comparing every native prefix
by the first observable unresolved requested predicate handoff will recall
incumbent errors missed by the conservative challenger, while global comparison
and exact-copy selection protect incumbent-correct boundaries.

## Runtime correction needed to measure that mechanism

v3.95 stopped before scoring because its prompt asked the model to type a shell
wrapper that the runtime also records. v3.96 asks for the exact inspector leaf
only. The access parser may strip zero, one, or two strictly parsed
`/bin/bash -lc` wrappers and then requires the leaf to be exactly one allowlisted
`python inspect_case.py ...` command. A third wrapper, chaining, redirection,
mutation, general Python, non-inspector tool, incomplete event, nonzero exit, or
out-of-range page remains fatal.

The only zero-command exception is a validator-proven singleton reducer. With
one native Step there is no strict prefix and the selected Step is structurally
forced to equal the anchor. The exception requires zero command events and a
completed validated keep-anchor artifact. Every anchor and every non-singleton
reducer must independently inspect the task and cover the complete timeline.
This correction has no Step-ranking capacity.

## Impact and regression analysis

- Expected gains: incumbent-error cases whose benchmark boundary is already a
  native v3.83 ledger prefix but was not recalled by the conservative challenger.
- Main regressions: early capability/acquisition probes promoted after an
  unresolved outcome; long ledgers may also encourage global early bias.
- Direct counterexample: an informative failed probe followed by independent
  effective repair must remain excluded even if the requested predicate was not
  satisfied at that Step.
- Candidate-flood control: the tournament may choose only an existing native
  ledger Step and freezes exactly one winner; it creates no new Step candidate.
- Overfitting control: no trajectory ID, entity, site, historical prediction,
  gold Step, error report, or post-score artifact occurs in inference sources.

## Acceptance and completion

- No smoke gate; run full GAIA-50 after offline validation.
- Freeze predictions, intermediate artifacts, access audit, and all validators
  before opening labels.
- Reject if any case or legality gate fails, or Step Exact is `<=26/50`.
- Accept as incumbent only if Step Exact is `>26/50`.
- Complete the Goal only if Step Exact is `>=30/50` and all legality checks pass.
- Step Exact is the only selection metric.

## Pre-inference source freeze

- Protocol SHA-256: `db7cfc8cc50b3a536187f49aa0bc43a593c7b0215c8cdf5612f7108e0e67aa88`.
- Runner SHA-256: `d751b2b9d549977346b309b769aa874479742c6df1134d2d62c166d363c07511`.
- Inspector SHA-256: `556e8fe1e77186a55521f74734b05d35a33fe482a50d30b5bc21ce7ef02f7677`.
- Targeted test SHA-256: `fae07d48856c59d1cd06298d50d10e927b5b9f3d8a45d21360f2539a96178551`.
- Registry SHA-256: `924a74f8eec5e28dc070436453713fae8b9edfcb87995787c0bc45af41d4d682`.
- Offline validation before inference: Python compilation passed; 33 targeted
  and inherited tests passed; direct-parent registry, dual-stage task building,
  strict wrapper normalization, mutation/chaining rejection, reducer-only
  singleton exemption, compatibility aliases, and gold/router static scans passed.

# E9 v31 incumbent-recovery history-root case study

## Failed attempt

After correcting Python import precedence, frozen v31 targeted tests produced
112 passes and 19 failures.  Every failure came from preregistration functions
that resolve authoritative v13--v30 artifacts beneath the repository root.

## Attribution

The v31 code archive intentionally contains source and tests, not the full
historical `output/` tree.  Running it from the extraction directory made that
directory the repository root, so byte-bound history anchors were absent.
Judge, parser, workflow, and CLI behavior were no longer cross-version and did
not cause these failures.

## Correction

Expose the live repository's immutable historical `output/` tree to the
temporary archive root through a read-only-purpose symbolic link, then rerun
only the failed preregistration tests.  Do not copy, edit, or recompute the
anchored artifacts.

No external LLM request was made.

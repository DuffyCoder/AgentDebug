# Luna GAIA v3.59 preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.59-clean-v3.20-step-isolated-module-reservoir-pairwise-observed-continuation-deterministic-assembly`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: Luna v3.20, Step Exact `25/50`
- Original v3.4 baseline: Step Exact `21/50`
- Version acceptance: Step Exact `> 25/50`
- Goal completion: Step Exact `>= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the sole optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module, type, and evidence are legality constraints
only.

## Clean-parent and rejected-lineage boundary

v3.59 is a new direct child of accepted v3.20. Every anchor, Step-local review,
and pairwise semantic assessment is rerun in a fresh isolated session. No v3.58
prompt artifact, local matrix, prediction, selector, ledger, runtime result, or
case output is an inference input. v3.58 remains immutable and unscored.

The v3.58 runtime audit supplies only a general contract falsifier: requiring a
model to transcribe immutable hashes and a complete nested exact-copy
prediction caused one of 50 cases to fail both attempts. The successor does
not copy or repair that case artifact.

## Single major mechanism

Add one clean-v3.20 Step-isolated observed-continuation pairwise mechanism with
deterministic assembly:

1. Fresh prefix-bounded Step sessions inventory literal taxonomy-valid local
   positives without anchor, later Steps, scores, gold, or prior predictions.
2. The program binds at most one earliest positive representative per Module
   in canonical order.
3. A fresh model session outputs only semantic fields for each ordered
   anchor-versus-representative pair: both roles, pre-candidate observation,
   observed-continuation anchor closure, both one-sided repairs, winner
   relation, and falsifier.
4. A representative can win only when it is `critical_root` and the consistently
   classified anchor is in an enumerated noncritical veto class. Ties and
   uncertainty keep anchor.
5. The program, not the model, constructs trajectory identity, hashes, row
   bindings, representative predictions, decisions, selected index, selected
   exact copy, and final reducer record. Aggregate validation recomputes the
   complete deterministic record from the semantic-only artifact.

This is one integrated critical-boundary mechanism relative to v3.20. The
deterministic assembly is its artifact contract, not a second Step-selection
heuristic. It removes v3.58's model-authored mechanical fields and does not
inherit any other rejected-lineage mechanism.

## Hypothesis, expected gains, and regressions

The semantic hypothesis remains the high-confidence v3.57 selection cluster:
nine final Step errors already had the released gold Step as a bounded module
representative, but the selector rejected it; six were labeled downstream
symptom and three were split among normal tool failure, noncritical
predecessor, and faithful propagation. The observed-continuation closure tests
whether this came from an overstrong hypothetical upstream-repair rule.

The bounded fresh-anchor-plus-reservoir oracle was `31/50`, so the candidate
set can in principle reach the Goal but leaves only one-case headroom. Expected
gains are the common representative-present selection errors. The strongest
regression risks are false override of an incumbent-correct early anchor,
Planning salience, and treating an independently invalid but noncritical later
row as the benchmark boundary. Pair isolation, the enumerated win gate,
consistent anchor class, earliest eligible reduction, and default keep are the
uniform controls.

Deterministic assembly is expected to eliminate the observed v3.58 schema
failure without moving a Step for the same semantic assessments. It does not
claim to improve semantic accuracy by itself.

## Falsifiers

- any model-authored semantic artifact contains identity, hash, row binding,
  representative prediction, decision, selected index, or selected output;
- aggregate validation cannot reproduce the final selector exactly from the
  frozen anchor, matrix, and semantic-only artifact;
- any inference reads labels, scores, old predictions, error audits,
  experiment documents, case routes, git history, or external resources;
- local coverage is not `717/717`, the legal case count is not `50/50`, or any
  final prediction is not an exact deterministic anchor/representative copy;
- final Step Exact is `<= 25/50`.

Only Step Exact controls acceptance. Only a frozen legal Step Exact `>= 30/50`
can complete the Goal.

## Execution topology and offline validation

- 50 fresh v3.20 anchors + 717 fresh Step-local sessions + 50 fresh semantic
  pairwise sessions = exactly `817` planned successful model stages.
- Fresh one-case sessions, maximum concurrency `4`, maximum two attempts per
  stage, and no smoke gate.
- Focused v3.59 tests: `14 passed`; cross-version v3.20/v3.58/v3.59 tests:
  `32 passed`.
- Full-cohort dry-run: 50 cases, 717 legal Steps, 817 planned stages.
- Static inference-source scan: no rejected-version import, case route,
  score/gold reader, old prediction, or git-history input.

## Pre-inference source hashes

- Protocol SHA-256: `fcfb902dabe0659a262e9b7756dd8c48b9628bde6fd3733b02d3154f51b2a41a`
- Runner SHA-256: `69e0570d501be6c3a422e26f132f1bee993e01e75c1e5e582a646c21ba2d8fcb`
- Registry SHA-256: `d635f389bb16522a0bf5f7d288a8f814f02778333dbf3c571f990f7c72a70c0b`
- Taxonomy SHA-256: `d7e4b878059bbecec0a8fd3f078c0aeb5755bf9e65bb938c897dd83685f28c5c`
- Focused-test SHA-256: `af4a9eb83768af11bce90a0f099a417d5242697569d5bedf993863c469c4080c`

## Frozen full-run outcome

v3.59 completed and froze all `50/50` cases with exactly `817/817`
successful model stages, `717/717` Step-local sessions, zero retries, and zero
permanent failures. All schema, taxonomy, evidence, order, hash,
deterministic-assembly, case-routing, and gold-free checks passed. The
independent access audit inspected 817 session logs and 4,988 commands, found
zero forbidden direct/output reads, and matched every preregistered source
hash.

The sole acceptance metric was Step Exact. v3.59 scored `18/50`, so it is
rejected and v3.20 remains the accepted incumbent at `25/50`. Relative to
v3.20 the transition was 18 both-correct, zero gains, seven losses, and 25
both-wrong. The fresh v3.20 anchor itself scored `19/50`; the reducer's direct
effect was zero gains, one loss, and four wrong-to-wrong Step changes.

The complete local matrix covered the released Step in `35/50`, but the
earliest-per-Module reservoir covered only `22/50`. Fresh anchor plus reservoir
had an oracle of `28/50`, below the Goal before final selection. The reducer
made 43 keep-anchor and seven representative decisions; its semantic gate
forced one global anchor classification into every isolated pair. In the
representative-present error cluster, the recorded anchor closure could not
change that class, so pair-local closure was descriptive rather than
selection-effective. The first-divergence audit contains 26 `anchor_error`,
five `annotation_ambiguity`, and one `false_challenger_override`.

This falsifies both the compression and selection hypotheses. The next version
does not inherit v3.59. Post-score analysis instead found that the accepted
v3.20 sparse chronological ledger contains only 131 rows (2.62 per case,
maximum nine) while covering `32/50` released Steps. Eight incumbent errors
already have gold in an earlier ledger row; 17 incumbent-correct cases are
exposed to earlier rows. Across 23 clean historical v3.20-child anchor runs,
sparse-ledger coverage averaged `31.26/50` and reached at least 30 in 20 runs.
That supports a clean-v3.20 retrospective prefix-selection experiment with
strict early-regression controls, rather than another full local inventory.

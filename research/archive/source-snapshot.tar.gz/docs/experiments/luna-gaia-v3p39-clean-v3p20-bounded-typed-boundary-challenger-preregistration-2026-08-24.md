# Luna GAIA v3.39 preregistration

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.39-clean-v3.20-bounded-typed-boundary-challenger`
- Direct semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: v3.20, Step Exact `25/50`
- Acceptance: Step Exact `>25/50`; Goal completion: Step Exact `>=30/50`
- Frozen `gaia-paper-v1` 50 cases; dataset SHA-256 `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`; cohort SHA-256 `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- `gpt-5.6-luna`, reasoning `medium`; no smoke gate; full GAIA-50 after offline validation.

Single major mechanism: keep the clean v3.20 anchor, ledger, checkpoint, and
default-keep exact-copy arbiter unchanged. Replace only the later challenger
search with one bounded typed-boundary challenger that may emit at most one
literal candidate across state truth, post-feedback predicate/evidence-family
maturity, and direct plan/Action or constraint alignment. It must veto initial
or materially different probes, productive specialized-resource changes,
recovery, mechanical/local defects, and downstream symptoms.

This cleanly tests whether v3.38's three gains are portable as independent
proposals without its eight anchor regressions. Regression risk is a false
override of an incumbent-correct anchor. v3.38 prompt, calibrated anchor,
predictions, and artifacts are not inherited. Inference remains gold-free and
may not read labels, scores, audits, old predictions, case studies, experiment
documents, or git history.

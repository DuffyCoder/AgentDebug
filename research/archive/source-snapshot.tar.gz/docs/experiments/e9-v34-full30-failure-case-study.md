# E9 v34 full30 failure case study

## Outcome and termination

v34 passed its frozen dry3 gate at 2/3 on Step Exact, Step+Module Exact, and
All Correct. The tuning full30 phase then reused dry batch 1 and completed
batches 2 through 7 before batch 7 produced two invalid rows. The run was
manually stopped before allowing another completed LLM attempt, as required by
the failure-study rule.

At the stop point:

- persisted predictions: 18/30 across batches 1 through 7;
- successful predictions: 16;
- invalid predictions: 2, both from the same batch-7 Selector response;
- new completed provider responses: 12 (Candidate + Selector for batches
  2 through 7);
- logical-completion reservations: 13;
- the thirteenth reservation is batch 8's Candidate request
  `b9619f5ee52da7035a410e9b763d4695bd5555248a3c54683751502a473fa4cb`,
  which was already in flight when the process was interrupted and therefore
  has no raw response, sidecar, parsed cache entry, or predictions;
- cumulative logical-completion accounting: 446 to 459.

This is an incomplete rejected attempt, not a full30 score or promotion.

## Format failure

Batch 7's Candidate response was valid. The independent Selector returned all
required semantic fields for both cases, but the response ended with `}]`
instead of `}]}`: exactly one outer object-close was missing. The provider
reported `finish_reason=stop`, not a length finish. The response therefore
failed strict JSON parsing and both rows were correctly counted as
`invalid_json`.

The existing non-semantic Flash repair covers a previously observed, proven
shape with one *extra* final object-close. It deliberately does not guess at
arbitrary malformed JSON and did not cover this mirror-image missing-close
case.

Appending exactly one `}` to the preserved raw response makes it one strict
JSON object that passes the existing Selector schema and evidence validation.
This counterfactual check was performed read-only; the authoritative v34
artifacts were not modified. The proposed v35 repair may therefore accept
only this exact condition: original strict parsing fails, the trimmed response
ends with `}]`, appending one `}` yields a strict object, and full downstream
schema/evidence validation still applies. It changes no string or semantic
field.

## Partial semantic audit

The 18 persisted rows are not an official full30 result, but a gold-opened
post-failure audit gives useful evidence:

- Step Exact: 9/18 (50%);
- Step+Module Exact: 3/18;
- All Correct: 3/18;
- valid output: 16/18.

Thus the incomplete prefix already has more than the target 40% Step Exact.
That number must not be promoted or extrapolated to 30 cases.

Applying the one-byte repair only for case-study inspection yields:

- batch-7 C01: predicted `4/planning/inefficient_plan`, gold
  `6/planning/inefficient_plan`;
- batch-7 C02: predicted `13/memory/over_simplification`, gold
  `4/reflection/outcome_misinterpretation`.

Both remain semantic misses. The repair improves validity, not accuracy, and
must never be counted as a semantic correction.

## Root attribution and v35 direction

Primary failure: an unhandled, mechanically provable one-missing-final-brace
Flash format defect at the Selector boundary.

Secondary audit finding: the two repaired batch-7 diagnoses are semantically
wrong, so no format fix is sufficient evidence of benchmark improvement.

v35 preserves v34's prompts and LLM-only semantic architecture. It adds only
the symmetric one-missing-final-object-close repair described above, with
tests proving that arbitrary truncation, missing array closes, Markdown,
multiple missing braces, or schema-invalid content remains invalid. It also
binds this interrupted run's 13 reservations, 18-row prefix, 42-file cache,
and missing-response crash window before another provider call.

No further LLM attempt is permitted until the repair, regression tests,
incomplete-run anchor, full test pass, code archive, and new preregistration
are complete.

# Luna GAIA v3.71 预注册：exact-predicate reducer，evidence exact-copy materialization

状态：执行前冻结。

## 冻结实验合同

- semantic parent：accepted Luna v3.20，Step Exact `25/50`。
- 版本：`agentdebug.codex-agent-judge.luna-gaia.v3.71-clean-v3.20-exact-predicate-acquisition-boundary-reducer-evidence-materialized`。
- 数据集：冻结 `gaia-paper-v1` 50 例。
- 模型/effort：`gpt-5.6-luna` / `medium`。
- v3.4 基线：Step Exact `21/50`。
- 接受：合法完整 GAIA-50 Step Exact `>25/50`。
- Goal 完成：合法完整 GAIA-50 Step Exact `>=30/50`。
- 无 smoke 门控；直接完整 GAIA-50。

唯一主要语义机制仍是从 v3.20 clean branch 单独移植的 `exact-predicate acquisition
boundary reducer`。candidate gate、v3.20 anchor 语义、owner-explicit JudgeView、prefix/later
binding 和 deterministic exact-copy selector 均与 v3.70 相同。不继承 rejected lineage 的
其他 proposal、panel、challenger、arbiter 或 selector 机制；semantic parent 始终是
v3.20，推理不读取历史逐例预测。

## v3.70 first divergence 与唯一合法性修正

v3.70 完成全部 50 例尝试，48 例通过；第 36、44 例在两次 anchor 重试后仍为
`invalid_evidence_ownership`，因此未评分、未读 gold。owner-explicit contract 已把 v3.69
的 5 个失败降为 2 个，并消除两个 prefix-binding failure，但模型仍可能选择某 Step/
Module 后复制另一个 Module 的文本。

v3.71 仅增加 gold-free 的 deterministic evidence materialization：

- 保留模型选择的 Step、Module、type、root cause、causal summary、ledger lane、candidate
  status 和 selector 决策；
- 若且仅若 Agent-owned prediction 的 evidence quote 不属于已选择 Step/Module，父进程从
  该 Step/Module 的 public JudgeView owner resolver exact-copy 首个非空 literal，最多
  900 字符，并同步 selected ledger row；
- 已合法 quote 原样保留；System prediction 不自动修复；strict evidence validator 不放宽；
- 每次发生修复都写入 `materialization-record.json` 和评分前 access audit。

这是输出合法性 materialization，不使用 gold，也不改变唯一 Step 指标上的语义选择。

## gains、regressions 与判伪

Step gain/回归假设仍完全来自 exact-predicate reducer：预期修复 matured earlier probe 或
later independent acquisition boundary；风险是有用 probe 被过早升级、或 later symptom
被误认作独立边界。evidence materialization 不应改变任何 predicted Step；直接反例是
仍不能 50/50 合法完成，或 materialization 改动任一 Step/Module/type/selector 字段。

若相对 frozen v3.20 gains 不大于 losses、final Step Exact `<=25/50`，或 50/50、schema、
taxonomy、evidence、hash、gold-free、tool-free、write-topology 任一验证失败，则拒绝。
只有合法 `>=30/50` 才完成 Goal。

## 执行前冻结哈希与离线验证

- protocol：`3e507fb46f177a25bfa04a2d2f40a1ca09ac6158d7e70f86a8d9c898c1e7ffad`
- runner：`89c1a9ec6f0053d16af37f1c4f227322626c525f5feaff8f993b26de8cf66fff`
- access auditor：`0d41a838e4eb1819f54c3ceb9256b1309367c1acd1e51f3113b5f9ef284a69f1`
- registry：`309765642f737746c59389d170f55e9ba15073c267dd5f03f7d586d933c15718`
- tests：`59ed197e1f8d46403cf528634b7e82fe3e59ec04be496f034b7e07ccd9c1dc07`
- taxonomy：`d7e4b878059bbecec0a8fd3f078c0aeb5755bf9e65bb938c897dd83685f28c5c`
- semantic parent v3.20：`3e886325bf0a4b4d4a3e770071c0a36fe81dab2bebaf5015561ca828b6c2e4f9`
- prediction manifest：`77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- cohort：`31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`

离线验证：v3.71--v3.66 及 v3.20 相关测试 `39 passed`；compile、registry、真实 executor
protocol-interface inventory、50-case dry plan、100 sessions 和 direct parent 全部通过。
测试使用 v3.70 的实际第 36 例失败 response，确认 quote 被修复、所有语义字段不变且严格
anchor validator 通过；另有合法 quote no-op 负例。

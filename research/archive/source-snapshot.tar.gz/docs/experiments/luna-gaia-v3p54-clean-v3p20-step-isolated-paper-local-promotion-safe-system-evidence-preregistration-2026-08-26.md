# Luna GAIA v3.54 Promotion-Safe System Evidence Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.54-clean-v3.20-step-isolated-paper-local-promotion-safe-system-evidence`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: Luna v3.20, Step Exact `25/50`
- Original v3.4 baseline: Step Exact `21/50`
- Version acceptance: Step Exact `> 25/50`
- Goal completion: Step Exact `>= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the sole optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module/type/evidence are legality constraints only.

## Parent and rejected-lineage boundary

v3.54 is a clean child of the accepted v3.20 protocol. It does not inherit a
v3.53 prediction, local record, matrix, proposal, duel, hidden state, or case
route. v3.53 contributes only its post-run falsifier: a frozen local System row
could pass local literal validation but fail promotion because the local and
final validators used different observable source normalizations.

## Single major mechanism

Add the same one registered topology-level mechanism to otherwise unchanged
v3.20 semantics:

1. run one prefix-bounded, anchor-blind taxonomy-only review per legal Step;
2. freeze all legal positive rows before any criticality decision;
3. let one anchor-blind global stage export at most one row-grounded critical
   proposal;
4. let one default-keep exact-copy duel select the v3.20 anchor or proposal.

Within this mechanism, every System `owner_sources` entry is now constructed
with exactly the v2 owner-source resolver used by promotion/final prediction
validation. This is a required artifact-contract closure, not an additional
selection heuristic. Memory, Reflection, Planning, Action, anchor, global
critical-boundary, and duel rules are unchanged from the registered mechanism.

## Expected gains and regressions

The intended Step gains remain cases where v3.20 misses a fine-grained local
taxonomy defect before the mature benchmark boundary. The contract correction
adds no expected semantic gains by itself; it makes complete GAIA-50 legality
falsifiable.

The correction can remove System rows whose quote exists only in a feedback
wrapper rather than the normalized external observation. That should reduce
System false positives and candidate flood. A direct counter-risk is losing a
genuine System signal present only in wrapper text, but such a row could never
be exported as a legal final prediction under the frozen validator, so keeping
it would add no reachable Step gain. All incumbent gains/losses remain computed
against frozen v3.20 predictions after scoring.

## Pre-registered falsifiers

- any Step-local positive cannot be projected into a legal standard prediction
  using the same Step/module/type/evidence; or
- any frozen local-record set cannot deterministically rebuild its matrix; or
- Step-local positive gold-Step coverage does not exceed v3.52's `20/50`; or
- fresh anchor plus any local-positive row has scoring-phase oracle `< 30/50`;
  or
- fresh anchor plus the one global proposal has oracle `< 30/50`; or
- duel gains are not strictly greater than duel losses; or
- final Step Exact is `<= 25/50`.

Diagnostics cannot accept a version. Formal acceptance requires a legal frozen
full-GAIA Step Exact `> 25/50`; Goal completion requires `>= 30/50`.

## Execution and isolation

- 50 anchors + 717 Step-local sessions + 50 global proposals + 50 duels =
  exactly `867` planned successful sessions.
- Fresh one-case sessions, chronological local Steps, maximum concurrency `4`,
  maximum two attempts per stage.
- No smoke gate, historical prediction input, case routing, gold/labels,
  metrics, scored artifact, error report, case study, git history, or external
  resource is available to inference.
- All local records, matrices, proposals, duels, predictions, hashes, order,
  taxonomy, literal evidence, and exact-copy relations must freeze and validate
  before scoring.

## Pre-inference implementation hashes

Frozen before the first v3.54 inference call:

- Protocol SHA-256: `2f00fef8a7a98f1a7f4c5ceb4a1f6e9e035b648fef11f0a3fa92067b204c59f3`
- Runner SHA-256: `21a1de0b5f3f284461cd62b18daf2df39598f73f53e7e5dd7b6d22495584b7d9`
- Registry SHA-256: `e6ddb9a2a5e280aa7c3be8899918c2c3e95b105cf5c41eb886b52e214b830231`
- Focused-test SHA-256: `2e3aab47300bb0ff617269ec7926a5a3b45fa1198f1e28084d586d54edbceb6a`
- Focused v3.54 tests: `6 passed`, including exact promotion-source equality
  for all `717` Steps and the frozen v3.53 failure replay
- Cross-version v3.20/v3.52/v3.53/v3.54 tests: `23 passed`
- Full-cohort dry-run: `50` cases, `717` legal Steps, exactly `867` planned
  successful model sessions, concurrency capped at `4`
- Static source scan: no rejected-version semantic import, case-specific
  Step/entity/source rule, inference-time score/label reader, or old-prediction
  input was found

## Frozen post-run outcome

- Full GAIA-50 completed and froze `50/50` predictions.
- Actual stage attempts: `868`; one isolated global-proposal attempt failed
  `invalid_global_proposal_boundary_class`, attempt 2 passed, and there were no
  permanent failed cases.
- Step Exact: `18/50`.
- Relative to frozen v3.20: `17` both correct, `1` gain, `8` losses, `24` both
  wrong; net `-7`.
- Fresh v3.20 anchor: `21/50`.
- Gold Step local-positive coverage: `31/50`; fresh-anchor plus any positive-row
  oracle: `36/50`.
- Gold global proposal: `11/50`; fresh-anchor plus proposal oracle: `24/50`.
- Duel relative to fresh anchor: `1` gain, `4` losses, `7` wrong-to-wrong Step
  changes.
- All prediction legality checks and the independent inference-access audit
  passed. The version is rejected because Step Exact did not exceed `25/50`.
- First divergence across all `32` Step errors: `23 anchor_error`,
  `5 annotation_ambiguity`, `4 false_challenger_override`. Downstream analysis
  isolates `10` global-compression gaps, `11` Step-local recall gaps, and `2`
  proposal-present duel-selection gaps.

# E9-v21 Dry3 Failure Case Study

## Attempt and formal result

E9-v21 returned to `deepseek-v4-flash` with the provider's default request
body.  One logical completion moved the cumulative counter from 369 to 370.
The provider made one HTTP attempt with no retry and returned `finish_reason`
`stop`.

The format intervention succeeded: all three cases parsed, every selected
evidence source ID resolved to an exact trajectory-owned source, no evidence
punctuation was transcribed by the model, and `format_repairs` was empty for
all three cases.  The formal result was nevertheless rejected on semantics:
1/3 Step, 1/3 Step+Module, and 1/3 All Correct.

## Per-case attribution

| Case | Official root | V21 raw root | Attribution |
| --- | --- | --- | --- |
| C01 | step 30, `system/step_limit` | step 30, `system/step_limit` | Correct.  The source-ID projection preserved the exact execution-fact text. |
| C02 | step 1, `action/misalignment` | step 4, `planning/constraint_ignorance` | The prompt incorrectly encouraged the model to treat the first extractor call as harmless exploration.  The official annotation instead treats applying a general text extractor to a dynamic GitHub issue-search collection as a hallucinated/misaligned operation.  The later step-4 answer is a downstream symptom because the abandoned collection/order/label-history constraints were never restored. |
| C03 | step 13, `planning/inefficient_plan` | step 6, `planning/inefficient_plan` | The model found a real early pagination candidate but failed to mark step 7's return to search and step 8's constraint-preserving rewritten query as recovery.  It therefore never restarted the stagnation clock for the second search episode, whose mature repetitive plan is step 13. |

## Root attribution

The output-format problem is resolved for this attempt and is not the reason
for rejection.  The remaining failure has two semantic causes:

1. the general "first probe is reasonable" rule is too broad for operations
   whose visible target representation cannot supply collection enumeration,
   ordering, or label-history facts required by the task; and
2. the short review does not force the judge to record a later recovery
   checkpoint before choosing among an early candidate and a later active
   defect.

## Bounded optimization hypothesis

E9-v22 keeps Flash, the default request body, source-ID evidence, and the
single-brace structural repair unchanged.  It makes only a semantic review
change:

- the review records `earlier_candidate_step` and `later_recovery_step` before
  final selection;
- a deliberate query rewrite that retains every unmet task constraint starts
  a new search episode even when keywords overlap and even when it does not
  immediately find a match; and
- using a generic text extractor on a visible dynamic search/index collection
  is an action-representation mismatch when the task requires reliable
  enumeration, ordering, filtering, or change history that the operation does
  not expose.  A later answer based on a different item is not recovery unless
  it restores those constraints.

The next dry3 attempt is one logical completion, cumulative 370 to 371.  It
must retain three valid outputs and achieve at least 2/3 Step, Step+Module,
and All Correct.  If it passes, full30 would require ten more calls and end at
381, which exceeds the currently authorized ceiling of 380; no full run is
permitted without new authorization.

# GAIA v3.86 GPT-5.5 bounded typed-boundary challenger preregistration

Date: 2026-08-29

## Frozen identity

- Version: `agentdebug.codex-agent-judge.gaia-v3.86-gpt55-bounded-typed-boundary-challenger`.
- Direct semantic parent: accepted v3.83, Step Exact `26/50`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction manifest SHA-256: `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`.
- Frozen v3.83 protocol SHA-256: `a97908a78cec8df5fe9e4777d30aa9ecf498d1cdd1d692a42cc66976e9844531`.
- Frozen v3.83 runner SHA-256: `a1613a04ad21b3306c61cd3082753ff5890ad09ab3d939f4c292c15e1dac483d`.
- Frozen v3.83 predictions SHA-256: `f74161b06c456461ccacdcf7c708157154e8e9810cb5dffa8ef09352698fca3d`.
- Model: `gpt-5.5`; reasoning effort: `medium`.

## Single major change

Replace only v3.83's earliest-causal challenger contract with one bounded
typed-boundary later challenger. It may emit at most one later `state_truth`,
`post_feedback_maturity`, or `alignment` proposal after an explicit anchor
falsification gate. The v3.83 packet-state anchor, default-keep exact-copy
arbiter, model, effort, case order, concurrency, retry bounds, and all other
validators remain unchanged.

This ports only the isolated mechanism whose v3.39 run produced three direct
Step gains and zero direct regressions over its fresh anchor. v3.39 is not a
semantic parent: its Luna anchor samples, predictions, artifacts, identities,
and other results are not inference inputs. No labels, metrics, case IDs,
historical predictions, or gold rationales are visible during inference.

## Falsifiable hypothesis and regression risk

The typed challenger will recover complementary later critical boundaries
among v3.83's candidate/challenger recall failures without overriding correct
anchors. The mechanism is falsified if final Step Exact is `<=26/50`, if any
legality check fails, or if direct override regressions outweigh gains. Main
risks are missing earlier alternatives, post-feedback candidate under-recall,
and persuasive late-symptom proposals.

## Acceptance and Goal completion

- Accept only if Step Exact is strictly greater than `26/50` and all legality checks pass.
- Complete the Goal only if Step Exact is at least `30/50` and all legality checks pass.
- Only Step Exact selects versions; all other metrics are diagnostic.
- No smoke gate is used; after offline validation run full GAIA-50 directly.

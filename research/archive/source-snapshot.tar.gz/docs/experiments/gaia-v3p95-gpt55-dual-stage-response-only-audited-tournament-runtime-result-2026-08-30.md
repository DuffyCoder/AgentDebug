# GAIA v3.95 dual-stage response-only tournament runtime result

Date: 2026-08-30

## Decision

v3.95 is runtime-incomplete and unscored. The frozen run directory contains 12
completed per-case final predictions and partial work for cases 13--16, but no
50-case execution summary, merged predictions, gold-free freeze, or score. No
partial result is eligible for acceptance or comparison.

## First divergence

The first divergence is `runtime_or_validation_failure`, before any label read.
The dual-stage prompt correctly reached both semantic stages, but it instructed
the model to wrap each exact inspector command in `/bin/bash -lc`. The Codex
runtime independently records its own shell wrapper, so many otherwise exact
reads appeared as a redundant two-wrapper form, for example an outer strict
wrapper around `/bin/bash -lc 'python inspect_case.py task'`. The preregistered
v3.95 access parser accepts exactly one wrapper and would reject those events.

Singleton reducers exposed a second structural mismatch. When the native ledger
contains only the anchor Step, the validated tournament has no alternative and
must deterministically keep the anchor. Several such reducers correctly emitted
no inspector command, while the access audit required independent task plus full
timeline coverage from every reducer regardless of whether a Step choice existed.

The run was stopped once both uniform contract mismatches were observed. Existing
artifacts remain immutable. The semantic predictions were not merged or scored.

## Next falsifiable runtime correction

Return directly to accepted v3.83 and transplant only the preregistered
outcome-conditioned predicate-handoff tournament. Normalize at most two exact
`/bin/bash -lc` recording wrappers down to one allowlisted inspector leaf, while
continuing to reject chaining, mutation, general Python, extra tools, failures,
and incomplete events. Permit zero commands only for a validator-proven singleton
reducer with deterministic keep-anchor semantics; every anchor and every
non-singleton reducer must still inspect task plus the complete timeline.

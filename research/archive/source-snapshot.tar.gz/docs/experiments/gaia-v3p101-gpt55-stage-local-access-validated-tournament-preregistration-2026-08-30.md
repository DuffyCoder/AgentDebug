# GAIA v3.101 GPT-5.5 stage-local access validated tournament preregistration

Date: 2026-08-30

## Frozen experiment

- Version: `agentdebug.codex-agent-judge.gaia-v3.101-gpt55-stage-local-access-validated-predicate-handoff-tournament`.
- Direct semantic parent: accepted v3.83 (`26/50`).
- Frozen dataset: `gaia-paper-v1`, 50 cases; identities
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11` /
  `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Model/effort: `gpt-5.5` / `medium` in both stages.
- Only semantic change from v3.83: one outcome-conditioned predicate-handoff
  tournament over all native fresh-ledger Steps.

## Runtime-only correction

Before a stage response can be materialized, a gold-free validator now requires
every command to be valid, successful, and attempt-bound; task access; complete
anchor timeline coverage; or complete reducer native-candidate timeline
coverage. A noncompliant response is discarded and may receive the existing one
fresh structural retry. Retry feedback states only the violated transport rule,
never labels or Step quality. The prompt explicitly forbids module-first command
abbreviations. Short paths and encoded-output bounds remain unchanged.

This cannot rank or change a Step; it only prevents an access-illegal response
from entering frozen predictions.

## Decision

- No smoke gate; full GAIA-50 after offline validation.
- Freeze access/legal/prediction artifacts before labels.
- Reject if illegal/incomplete or Step Exact `<=26/50`.
- Accept above 26; Goal completes only at `>=30/50`.
- Step Exact is the sole optimization metric.

## Pre-inference freeze

- Protocol SHA-256: `fb91fa9d010cce8d5d903c1d8e1ebc42f47dc5d73833779a21d7543b83a84953`.
- Runner SHA-256: `ae69cbef68ad34e2803aeecb80b4dae4a9d4b4ed7695c6d1047d36b9111c8841`.
- Inspector SHA-256: `605b1473ff18fe0c7ddadf8f47074e23c689f4328137be297c86c75141a97160`.
- Test SHA-256: `9d01f9f7febe3a9d2c373d7f0ac47c9df00f52da88b40bd9c8d7d21a566b98a9`.
- Registry SHA-256: `27369e6e95543193d7b8111ca80df5eef74a7963e126bdc0cc28b7b954a6d122`.
- Offline validation: compilation and 50-case dry preparation passed; 5 new
  stage-local tests and 32 inherited tests passed in isolated processes.

The version is frozen before full inference.

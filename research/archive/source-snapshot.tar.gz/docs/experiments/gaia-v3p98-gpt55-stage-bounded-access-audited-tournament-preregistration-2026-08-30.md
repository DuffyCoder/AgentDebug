# GAIA v3.98 GPT-5.5 stage-bounded access tournament preregistration

Date: 2026-08-30

## Frozen identity

- Version: `agentdebug.codex-agent-judge.gaia-v3.98-gpt55-stage-bounded-access-audited-predicate-handoff-tournament`.
- Direct semantic parent: accepted v3.83, Step Exact `26/50`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Dataset manifest identity SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort identity SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Cohort manifest file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Frozen v3.83 protocol SHA-256: `a97908a78cec8df5fe9e4777d30aa9ecf498d1cdd1d692a42cc66976e9844531`.
- Frozen v3.83 predictions SHA-256: `f74161b06c456461ccacdcf7c708157154e8e9810cb5dffa8ef09352698fca3d`.
- Model/reasoning effort: `gpt-5.5` / `medium` for both stages.

## Single semantic mechanism

Relative to accepted v3.83, the only semantic change is one outcome-conditioned
predicate-handoff tournament over every native Step in the fresh v3.83 ledger,
replacing the incumbent challenger/arbiter. Anchor semantics, candidate
admission, model, effort, evidence ownership, taxonomy legality, singleton keep,
and exact-copy final freeze remain unchanged. No rejected prediction or per-case
routing information is available to inference.

Hypothesis: global comparison by the earliest mature unresolved exact-predicate
handoff will recover incumbent-error boundaries already present in the ledger,
with fewer regressions than gains.

## Runtime-only access correction

v3.97 completed `50/50` but was not scored because its access audit failed. v3.98
pre-registers a stage-specific, gold-free contract:

- Anchor: task plus every original timeline Step is mandatory.
- Reducer: task plus every native-ledger candidate Step is mandatory; original
  noncandidate Steps are optional because they cannot win the frozen tournament.
- A valid timeline request of at most five Steps may extend beyond the final
  Step; the inspector deterministically clamps only that final page.
- `feedback N` returns bounded exact head/tail text and size metadata;
  `feedback-chunk N K` returns an exact bounded 4,000-character chunk.
- Whole-Step reads, failed/incomplete calls, unbounded Python, filesystem
  mutation, shell composition, nonallowlisted tools, missing required coverage,
  and more than two strict transport wrappers remain fatal.
- Validator-proven singleton reducers may make zero calls and structurally keep
  the anchor, as previously frozen.

These corrections govern evidence transport and legality only; they do not add,
remove, order, rank, or select a Step.

## Expected gains and regressions

- Expected gains: incumbent errors whose gold Step is already admitted into the
  fresh ledger but omitted by the conservative incumbent challenger.
- Main regression risk: promotion of reasonable early acquisition attempts.
- Transport risk: a relevant system observation may lie outside the feedback
  preview; explicit exact chunks preserve full on-demand access.
- Candidate flood risk: none; no candidate is added.
- Direct counterexample: an informative initial probe followed by independent
  effective repair must remain vetoed.

## Decision rules

- No smoke gate; full GAIA-50 follows offline validation.
- Freeze all 50 predictions, intermediate artifacts, access audit, and legality
  audit before labels.
- Reject on incomplete execution, failed legality/access gate, or Step Exact
  `<=26/50`.
- Accept only if Step Exact `>26/50`; complete Goal only at `>=30/50`.
- Step Exact is the sole selection metric.

## Pre-inference freeze

- Protocol SHA-256: `9c120500667cf4f810f2a0325f1b29813c172a8902c1d34bb60bb0c5471c8caa`.
- Runner SHA-256: `64c908aa0ff1ec61a57f75712416a20fc8bd3dad6b43e47f3240090a5e3d2b26`.
- Inspector SHA-256: `8c4b6a2a04b96206b74012eb6c3dedcefe6e0d5bbaa371846097d8c2f20800f3`.
- Targeted test SHA-256: `6452e7d4e0e8ad2e052bcbcdbe6e1e967cfad94dcdf4a06637aa760e5e0f0484`.
- Registry SHA-256: `a198bed649ce46bf086b472007ffdb82a6e3fc5922f8f19ac0786ae0305fb560`.
- Offline validation: compilation passed; dry preparation resolved the frozen
  50-case cohort; 26 targeted and inherited tests passed, including direct
  parent and thresholds, distinct anchor/reducer coverage, final-page clamping,
  bounded feedback, exact feedback chunks, strict command parsing, whole-Step
  and shell-feature rejection, registry, and static gold/router scans.

This pre-inference identity is now frozen and immutable.

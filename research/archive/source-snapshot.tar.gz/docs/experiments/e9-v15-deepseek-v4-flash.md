# E9-v15 DeepSeek V4 Flash Critic

E9-v15 changes only the live judge identity and transport parameters of the
v14 batched-Critic candidate. The prompt protocol, gold isolation, raw-output
reconstruction, evidence validation, batching, and promotion gates remain
frozen.

The provider contract is exact:

- provider: `openai-compatible`
- endpoint: `https://api.deepseek.com/v1/chat/completions`
- model: `deepseek-v4-flash`
- API-key environment variable: `DEEPSEEK_API_KEY`
- temperature: `0`
- thinking mode: explicitly `disabled`
- maximum output tokens: `8192`
- timeout: `600` seconds
- retries: at most `5`, with a `2` second base backoff

Thinking is disabled because DeepSeek V4 Flash enables thinking by default and
ignores temperature while thinking. The explicit request field is included in
both the HTTP body and the content-addressed provider configuration.

Tuning is a hybrid experiment: it reuses the immutable v13 GPT-4.1
Scout/Arbiter predecessor and calls DeepSeek only for the final Critic. This
preserves the prior tuning evidence while isolating the effect of the new
Critic. A future held-out smoke run uses DeepSeek for fresh Scout, Arbiter, and
Critic stages.

The rejected v14 dry call is part of the cumulative usage history. Therefore
the exact budgets are dry `363 -> 364` (one batched Critic call), full
`364 -> 374` (ten new Critic calls after the dry cache hit), and smoke
`374 -> 407` (33 fresh three-stage calls). The current authorization ceiling
of 380 covers dry and full, but not smoke.

All previous v14 inputs, caches, outputs, and authorization claims remain
immutable. E9-v15 uses a new code archive, Critic cache, run directories, and
authorization chain.

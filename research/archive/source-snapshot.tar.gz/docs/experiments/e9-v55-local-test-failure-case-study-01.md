# E9 v55 local failure case study 01

## Failed attempt

`python3 -m pytest -q tests/test_batched_global_judge.py` produced 5 passes
and 1 failure.  The failed assertion searched the JSON-serialized message list
for an unescaped `"cases"` token.

An earlier syntax-check command also invoked the unavailable `python` binary;
the repository environment exposes `python3` instead.  Re-running the same
read-only check with `python3` succeeded.

## Attribution

The judge prompt was correct.  The test serialized the already-string-valued
message content a second time, so quotes inside the prompt were escaped.  This
is a test-observation error, not a prompt, parser, taxonomy, or evidence-binding
error.

## Correction

Inspect the user message content directly for the schema token.  Keep the
serialized aggregate only for anonymity and forbidden-key checks.  Continue
using `python3` for repository commands.

No external LLM request was made and no semantic result was consumed.

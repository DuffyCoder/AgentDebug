# GAIA v3.99 GPT-5.5 CWD-robust access tournament runtime result

Date: 2026-08-30

## Decision

v3.99 completed `50/50` cases and `100/100` semantic stages in exactly 100
attempts, but failed the mandatory access gate before scoring. It is frozen,
unscored, and rejected as a runnable experiment; no gold was read.

## Access facts

- Required task/anchor/native-candidate coverage failures: `0`.
- Runtime-contract failures: `0`.
- Failed completed-but-allowlisted commands: `0`.
- Invalid commands: `6`, all reducer calls to a nonexistent shortened path.
- Successful commands: task `100`, timeline `229`, owner `509`, feedback `234`, feedback-chunk `13`.

The output-budgeted chunks fixed the v3.98 incomplete control-heavy command, and
cases 25, 41, 46, and 47 all completed semantically. However, six reducers
abbreviated the long absolute path by dropping the `...case50/cases/case-XX/`
segment. The resulting paths were outside the exact attempt binding and failed
with exit code 2. This is `runtime_or_validation_failure`; no Step-quality
conclusion can be drawn.

## Minimal next correction

v3.100 keeps the same clean-v3.83 tournament. Each attempt exposes its real
inspector through a short unique `/tmp/agentdebug-v3p100-.../inspect_case.py`
symlink. The audit accepts it only when resolving the link yields the exact real
attempt inspector; the inspector then resolves the document beside that real
file. No candidate or Step rule changes.

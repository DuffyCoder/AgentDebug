# E9 v50 full30 whitespace-sensitive brace failure case study

## Closed attempt

- Experiment: `e9_v50_selector_capacity_deepseek_v4_flash_default_body`
- Full30 preregistration content hash: `672e5b36bd63743f4fd308318aca622c573cf978963251860463bb5485bcab22`
- Frozen budget: cumulative 587, at most 20 new logical completions, hard stop 607.
- Persisted prefix: 11/30 rows: eight `success` rows followed by three `invalid_json` rows from batch 4. This is not a full30 score or promotion result.
- Successfully persisted provider stages: six logical completions, six HTTP attempts, zero retries; 1,199,178 input, 111,816 output, and 1,310,994 total tokens.
- The durable ledger contains a seventh logical reservation for the next batch's Critic. That HTTP request had already started when the process was manually interrupted to enforce the user-required failure case study. It has no persisted provider response or usage telemetry and will never be replayed under this experiment.
- Cumulative logical completions after closing the attempt: 594.

The first batch reused the accepted v50 dry cache. Batches 2 and 3 completed
normally. Batch 4's Critic also completed normally. Its Selector response is
stored under request hash
`7d5032477f023ef9ca204c5dfb31c0b9572e24654a86b94c13cf2fa16f94c886`.
The unintentionally started batch-5 Critic reservation is
`972141b7c631c58e4f683382b8647c9a1da72c284d34b42aefd15d20fe0aa418`;
no cache artifact exists for it.

## Exact format failure

The batch-4 Selector returned 3,391 characters with `finish_reason=stop` and
no retry. It begins with the requested top-level object and contains three
complete case objects, but its final bytes are:

```text
  }
]
```

The required final top-level `}` is absent. Appending exactly that one
structural byte produces one strict JSON object; no string, field, case, or
semantic value is changed.

The existing bounded Flash repair was intended to recognize precisely this
defect, but its trigger was `stripped.endswith("}]")`. That condition only
matches compact JSON where the last case's `}` and the cases-array `]` are
adjacent. DeepSeek emitted pretty-printed JSON with a newline between those
two structural characters, so the repair did not run. All three rows were
therefore classified as `invalid_json` even though the one-byte repair is
unambiguous and already within the project's accepted non-semantic repair
policy.

This is a parser trigger defect exposed by provider formatting, not semantic
truncation and not a capacity failure. The 742,928-character Selector request
was below v50's 900,000 cap.

## Offline semantic counterfactual

Appending the missing top-level close only for case-study inspection yields:

| Case | Official root | Raw Selector tuple after syntax-only parse | Result |
| --- | --- | --- | --- |
| `GPT-4o_043_alfworld_task_043` | step 6, `reflection/inaccurate_progress_assessment` | step 6, `planning/constraint_ignorance` | step only |
| `GPT-4o_008_alfworld_task_008` | step 5, `memory/memory_retrieval_failure` | step 3, `action/format_error` | wrong |
| `GPT-4o_056_alfworld_task_056` | step 4, `planning/impossible_action` | step 27, `planning/inefficient_plan` | wrong |

These diagnostic values are not written back into v50 artifacts and are not
scored as accepted predictions. They show that the format repair alone does
not hide a semantic miss: only one of the three steps would be correct, and
none of the complete tuples would be correct.

## Failure-response race

The workflow persists and prints an invalid batch, then immediately starts the
next batch. By the time the three `invalid_json` progress lines were visible,
the batch-5 Critic had already reserved logical call 7 and entered an HTTP
read. The manual interrupt prevented any later batch from running, but the
reservation and started attempt must still be counted. This behavior conflicts
with the explicit project rule that a case study must be completed before any
LLM call after a failed attempt.

## Next falsifiable hypothesis: v51

v51 will keep v50's 900,000 Selector cap and all v49 Critic/Selector semantic
instructions byte-for-byte unchanged. It will make two non-semantic control
changes:

1. For the already bounded missing-final-object-close repair, try appending
   exactly one `}` whenever the whitespace-trimmed raw response ends in `]`.
   Accept the repair only if the resulting entire payload parses as one strict
   JSON object and then passes the unchanged exact schema and evidence checks.
   Arrays, truncation, multiple missing bytes, Markdown, and semantic/schema
   errors remain invalid.
2. After persisting any batch containing a non-success prediction, stop the
   workflow before constructing or reserving the next batch's Critic request.
   This enforces the mandatory case-study boundary mechanically.

Neither change synthesizes or selects a root cause. Final step, module, error
type, evidence source, and explanations remain the raw Selector fields; the
repair only restores one missing JSON delimiter and is recorded in
`format_repairs`.

v51 starts from cumulative 594. A fresh dry3 cache must first pass the frozen
2/3 Step, Step+Module, and All Correct gate using two calls (hard stop 596).
Only then may a newly preregistered full30 run use twenty calls (hard stop
616). Any new provider or benchmark failure again requires a completed case
study before another LLM call.

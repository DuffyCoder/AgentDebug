# GAIA v3.96 normalized-access tournament runtime result

Date: 2026-08-30

## Decision

Rejected as runtime/access invalid and immutable. All 50 cases and all 100
semantic stages completed; the execution used 103 stage attempts and produced
50 per-case frozen predictions. The preregistered access gate failed before any
label read, so v3.96 is unscored and cannot be accepted.

## First divergence

The first divergence is `runtime_or_validation_failure`. The prompt required
the leaf `python inspect_case.py ...`, but this host has no `python` executable.
Models therefore first produced failed exit-127 commands and then repaired them
to `python3` or `/usr/bin/python3`. Failed commands are correctly fatal, while
the v3.96 parser also incorrectly classified every successful `python3` repair
as non-allowlisted. The runtime recorded otherwise exact leaves through both
`bash -c` and `bash -lc`, whereas the parser admitted only one wrapper spelling.

Two whole-Step drilldowns over unusually large observations had only an
`in_progress` event and no completed event. They are independently fatal under
the frozen successful-command requirement. Nine zero-command reducers were
correctly recognized as validator-proven singleton structural keeps. Topology
and runtime-contract structure otherwise passed.

No merged score, Step comparison, or post-score error audit was produced.

## Next uniform correction

Return directly to accepted v3.83 and transplant the same single tournament
mechanism. Require the host-available `python3` leaf, remove unbounded whole-Step
drilldowns from the advertised/allowlisted interface, and validate shell
recording wrappers separately from the exact inspector leaf. Continue to reject
every failed or incomplete event, command chain, mutation, general Python,
extra tool, missing anchor/non-singleton coverage, or non-structural zero-read
stage.

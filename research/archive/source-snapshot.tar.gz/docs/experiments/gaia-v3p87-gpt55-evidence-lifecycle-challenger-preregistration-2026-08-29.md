# GAIA v3.87 GPT-5.5 evidence-grounded lifecycle challenger preregistration

Date: 2026-08-29

## Frozen identity

- Version: `agentdebug.codex-agent-judge.gaia-v3.87-gpt55-evidence-lifecycle-challenger`.
- Direct semantic parent: accepted v3.83, Step Exact `26/50`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction manifest SHA-256: `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`.
- Frozen v3.83 protocol SHA-256: `a97908a78cec8df5fe9e4777d30aa9ecf498d1cdd1d692a42cc66976e9844531`.
- Frozen v3.83 runner SHA-256: `a1613a04ad21b3306c61cd3082753ff5890ad09ab3d939f4c292c15e1dac483d`.
- Frozen v3.83 predictions SHA-256: `f74161b06c456461ccacdcf7c708157154e8e9810cb5dffa8ef09352698fca3d`.
- Model: `gpt-5.5`; reasoning effort: `medium`.

## Single major change

Replace only v3.83's later-only Step challenger with one bidirectional,
evidence-grounded error-lifecycle challenger. It independently reads the
complete frozen JudgeView, groups downstream manifestations into one error
instance, assigns a recovery/terminal-relevance state, and may emit at most
one complete proposal whose origin Step differs from the anchor.

The lifecycle artifact must bind the proposal to a literal wrong commitment,
a literal task or trace obligation, a literal downstream manifestation, and
observable recovery evidence when claiming costly resolution. A challenge is
legal only for `manifest_active` or failure-material `costly_resolution`.
`clean_resolution`, `latent_active`, reasonable probes, normal tool failures,
mechanical repair, faithful propagation, and downstream symptoms are vetoed.

The v3.83 packet-state anchor, GPT-5.5/medium configuration, one-proposal
maximum, default-keep exact-copy arbitration, taxonomy, final prediction
schema, case order, retry bounds, and gold-free boundary remain unchanged.
Validator changes are limited to transporting and checking the new lifecycle
artifact, including legal bidirectional exact-copy selection.

v3.16, v3.34, v3.39, v3.47, v3.54--v3.65, and v3.86 are rejected evidence,
not semantic parents. Their prompts, predictions, scored artifacts, candidate
inventories, typed boundaries, and selectors are not inference inputs.

## Falsifiable hypothesis and regression risk

All 24 v3.83 Step errors omit the gold Step from the final candidate set, and
the current later-only challenger cannot reach an earlier alternative. The
new error-instance representation should recover a small number of terminal-
relevant origins without reproducing the local-error inventories that flooded
earlier experiments.

Expected gains are concentrated in fine-grained candidate recall, recovered
acquisition-capability false positives, and downstream-symptom cases. The main
risks are invented causal edges, treating mere inefficiency as costly
resolution, admitting normal failure results, and persuasive challengers that
override incumbent-correct anchors. Post-score candidate recall and direct
override gains/losses are diagnostic only and do not select the version.

## Acceptance and Goal completion

- Accept only if Step Exact is strictly greater than `26/50` and all legality checks pass.
- Complete the Goal only if Step Exact is at least `30/50` and all legality checks pass.
- Only Step Exact selects, accepts, rejects, or completes versions.
- No smoke gate is used; after offline validation run the complete GAIA-50 directly.

## Pre-inference freeze

- Protocol source SHA-256: `2e4fa65aaf12041c5db4279f7e14d1ca14fec16f96f8f3838767427049d9405a`.
- Runner source SHA-256: `5882a9defc0539d5dab998b23ba3df4bea8c933176a9c7c02e1e11d96b7f6aa4`.
- Negative/identity test source SHA-256: `87babed97974454836e59ebe75270a459f9c5b3b0055a6853137c8bf17320cb9`.
- Frozen tuning plan SHA-256: `88fb56b98a1bbdf55220731c8501219c663e2f80087c2c13ff54b73f56b0525b`.
- Offline validation: 27 targeted and inherited tests passed; protocol registry,
  model/effort, exact v3.83 anchor semantics, lifecycle nullability/vetoes,
  workflow compatibility, compilation, and 50-case dry preparation passed.
- Static inference-source scan found no label, metric, scored-artifact,
  historical-prediction, case/entity router, or post-score audit reader.

# E9 v47 dry3 failure case study

## Outcome

After the zero-call invocation failure was corrected, v47 completed its
frozen dry3 run with three valid raw diagnoses, but failed every semantic
promotion gate:

- Step Exact: 1/3 (33.33%; gate requires 2/3);
- Step+Module Exact: 1/3 (33.33%; gate requires 2/3);
- All Correct: 1/3 (33.33%; gate requires 2/3);
- successful outputs: 3/3;
- failed outputs: 0/3;
- logical completions: exactly 2;
- HTTP attempts: exactly 2, with zero retries;
- provider tokens: 383,220 input, 32,131 output, 415,351 total.

Only C01 was exact. The rejected promotion is bound by
`8b725013182f478d71178a8c6d6acc1da06d85666624ab026027434069bd3970`.
v47 must not advance to full30 or held-out smoke.

## Case study

### C01: the real external boundary remains stable

The released root and v47 output are both step 30 `system/step_limit`. The
five-lane Candidate emits the boundary plus speculative steps 4 and 16
planning inefficiencies. The Selector correctly rejects them because every
cabinet is a distinct feasible state with unknown contents. The two new lanes
emit null. This confirms that adding state-summary and plan/action audits does
not inherently displace a real terminal boundary.

### C02: correct early root remained present but was rejected

The released root is step 1 `action/misalignment`, and the frozen anonymous
prior still contains that exact tuple. v46 selected it correctly. v47 instead
selects step 4 `planning/constraint_ignorance`, reasoning that the final wrong
issue and creation date are a later independent commit point.

The new Candidate lanes expose step 2 reflection and memory alternatives, but
neither changes the core evidence. The initial dynamic GitHub collection-page
text extraction cannot supply the ordered, filtered set of closed Regression
issues or the label-event history required by the plan. The later Google
result and issue page substitute an available issue creation date; they never
reacquire the missing ordered membership and label-add event. Treating that
downstream substitution as independent reverses v46's successful
`PERSISTENT_INFORMATION_ROOT` decision.

This is a Selector-policy regression, not candidate recall failure. v48 must
apply the persistent-information categorical test before treating a
downstream answer or constraint violation as independently sufficient. It
must still require observable interface incapability; ordinary irrelevant
search results remain ineligible.

### C03: richer candidates still omit the released checkpoint

The released root is step 13 `planning/inefficient_plan`. v47 emits valid
hypotheses at steps 6, 9, 10, 20, and 30, then selects step 30. Step 13 follows
the second near-identical search and another repeated-result pagination epoch:
memory claims pages 1--6 were exhausted while the current result state is page
5, reflection acknowledges no progress, and planning nevertheless calls page
6 unexplored and continues. The released reasoning describes this mature
near-identical-search repetition, while v47 compresses it to earlier step 10
or later step 20.

This remains a candidate recall failure. There is no supported global numeric
offset: full30 v46 errors occur both earlier and later than gold. The useful
general rule is to audit the first mature checkpoint where a repeated-result
epoch is falsely described as unexplored after accumulated no-progress, not
the query that starts the epoch or an arbitrary final repetition.

## Attribution

There were no provider, retry, malformed JSON, taxonomy, evidence ownership,
step mapping, length, gold isolation, cache, or budget failures. The run is a
pure semantic rejection.

The five-lane hypothesis is insufficient by itself:

1. extra candidate coverage can distract the Selector when an early
   information-capability root remains causally active;
2. `state_summary_loss` currently finds the earliest omission, not the mature
   repeated-epoch checkpoint used by the released WebShop annotation;
3. the frozen v13 Scout contains independent LLM candidates that are verified
   and retained in the raw chain but are currently discarded when constructing
   the final anonymous hypothesis set.

On v46 full30, the released step appears in 10/30 v44 lane sets, 6/30 frozen
Arbiter priors, and 8/30 frozen Scout sets. Their unscored union covers 13/30.
That union is diagnostic only; it must not become a deterministic union vote,
fallback, score, rank, weight, or final selector.

## v48 falsifiable direction

v48 retains five active Candidate lanes and the v47 categorical checks, with
two changes:

1. the independent final Selector also receives the verified raw Scout
   candidates from the same frozen or fresh semantic chain, projected into the
   same anonymous evidence-bound hypothesis DTO as every other suggestion;
2. the Selector performs `PERSISTENT_INFORMATION_ROOT` before downstream
   branch comparison and adds a mature repeated-epoch check: when accumulated
   history already establishes the current result set or page as covered but
   memory/planning calls it unexplored and continues, that checkpoint can own
   planning/inefficient_plan.

Raw Scout candidates remain fallible LLM text. Deterministic code validates,
anonymizes, and deduplicates only byte-identical hypothesis DTOs; it never
chooses the final tuple. Hypothesis multiplicity, source stage, ID, and list
position convey no preference. The raw independent Selector remains the sole
source of final step, module, error type, evidence, and root cause, and may
emit a fresh diagnosis.

The v48 hypothesis is rejected if dry3 falls below 2/3 on any semantic gate
or if a promoted full30 remains below 12/30 Step Exact. After v47's cumulative
stop at 566, dry3 reserves exactly two new logical calls (566 to 568), full30
reserves twenty after dry reuse (568 to 588), and future fresh smoke reserves
forty-four (588 to 632). Any failed provider or benchmark attempt requires a
new case study before another LLM request.

# GAIA Agent Judge：截至 v10 的实验复盘

日期：2026-08-20

## 摘要

截至 v10，最重要的结论不是“还缺一条 prompt 规则”，而是当前系统已经达到
了 **复杂度负收益点**：更多 specialist、assessor、selector、temporal reviewer
和严格自由文本字段提高了局部可审计性，但没有提高已完成实验的 Step Exact
上限，反而显著降低了完整输出率并放大 token 成本。

当前可比较的核心结果是：

- 论文发布 GAIA-50 上，本地最优完整结果仍是 Luna v3.4：Step Exact
  21/50、Step+Module 13/50、All Correct 10/50。
- 论文报告为 29/50、22/50、19/50；本地 Step 仍差 8 条。
- 使用 GPT-4.1、temperature 0 并对齐公开仓库调用拓扑的完整实验只有
  14/50、9/50、5/50。公开拓扑本身没有复现论文结果。
- 在 8 条基于既往错误选出的诊断子集上，serial-v4 和 strict-v8 的 Step
  Exact 都是 3/8。v8 把 All Correct 从 1/8 提高到 2/8，但没有提高 Step。
- v9 仅完成 2/8，v10 仅完成 5/8，二者都没有合法准确率。v10 不能被描述为
  相比 v8 提升或下降。

这些结果全部是对已发布、且多轮分析过的 GAIA 数据进行调优或诊断，不是
未知数据上的泛化准确率。8-case gate 更是由历史 error cases 构成，只能用于
机制诊断。

## 可比较结果

### 完整 GAIA-50

| 实验 | 模型/拓扑摘要 | Step | Step+Module | All |
|---|---|---:|---:|---:|
| 论文 AgentDebug | 论文报告 | 29/50 | 22/50 | 19/50 |
| Luna v3.4 | lane/checkpoint 单 agent | **21/50** | **13/50** | **10/50** |
| GPT-5.5 raw causal serial | step→module→type | 17/50 | 8/50 | 4/50 |
| faithful-local | 本地官方式复现变体 | 16/50 | 9/50 | 7/50 |
| GPT-5.5 official Phase 2 | exhaustive proposals + official-style arbiter | 16/50 | 4/50 | 4/50 |
| GPT-4.1 public-repo topology | 官方公开拓扑、temperature 0 | 14/50 | 9/50 | 5/50 |
| forced census | 五 module exhaustive census | 13/50 | 6/50 | 5/50 |
| Terra global census | global census | 11/50 | 6/50 | 4/50 |

这里最关键的反事实证据是：切换模型、增加 exhaustive proposal、恢复公开仓库
Phase 1/Phase 2，均没有超过 Luna v3.4 的 21/50。因而“模型换成 GPT-4.1”
或“拓扑形式看起来像官方”都不是充分条件。

GAIA smoke-30 上，Luna v3.4 达到 16/30 Step、10/30 Step+Module、7/30
All；v3.6 达到 15/30、13/30、10/30。它们是同一公开 cohort 上的调优结果，
不能作为 held-out 指标。v3.4 在 smoke-30 的 53.3% 也没有转化成 GAIA-50
上接近论文的 58%，说明小型已暴露 cohort 上的提升不足以证明完整分布改进。

### 8-case 诊断 gate

| 版本 | 完整性 | Step | Step+Module | All | 总 tokens | 主要结论 |
|---|---|---:|---:|---:|---:|---|
| v3 | 8/8 | 2/8 | 1/8 | 1/8 | 9,753,993 | joint/proposal baseline；调用拓扑与后续不直接可比 |
| serial-v4 | 8/8 | **3/8** | 2/8 | 1/8 | 263,837 | 三段串行能提高 Step，但仍有边界错误 |
| boundary-v5 | 8/8 | 2/8 | 2/8 | 1/8 | 594,967 | 运行中改 validator，仅作开发诊断；C01 anchor |
| multiscout-v6 | 0/8 | — | — | — | 946,799 | reviewer ontology/schema 自相矛盾 |
| coverage-v7 | 7/8 | — | — | — | 841,316 | 不完整，不能评分 |
| strict-v8 | 8/8 | **3/8** | 2/8 | **2/8** | 913,598 | clean run；candidate recall 6/8，但 Step 未增 |
| causal-v9 | 2/8 | — | — | — | 583,194 | recommitment 和 temporal 合同失败 |
| causal-v10 | 5/8 | — | — | — | 1,190,509 | v9 合同已修，但 evidence binding/type 失败 |

从 v4 到 v8，token 增加约 3.5 倍，Step Exact 仍是 3/8；v10 消耗约 v4 的
4.5 倍，却连完整 8-case prediction 都没有形成。严格 validator 很有价值，
因为它阻止了虚构或错位证据进入评分；但“多 agent + 多自由文本 handoff”本身
不是提升准确率的路径。

## 各阶段实验真正教会了什么

### v3/v4：串行化解决了信息污染，但没有解决根因选择

Step→Module→Type 的冻结顺序避免了一个 joint response 同时随意改三个标签，
也把 8-case Step 从 2 提到 3。但一旦 Step agent 冻结错误边界，下游只能在
错误 step 上合理化 module/type。串行化提高可解释性，不自动提高因果定位。

### v5/v6：扩大候选集之后，reviewer 成为新瓶颈

v5 的 proposer→reviewer 本应比较 top candidates，实际 8/8 reviewer 都选
最早的 C01，且多数候选没有被真正审查；候选排序和示例制造了位置 anchor。
v6 强制全候选三门审核，却把 `locally_clear` 理解成“该步骤是清楚/正确的”，
把 `causally_sufficient` 理解成“足以完成任务”。16/16 raw reviewer 都给出
完整 JSON，但没有一个 selected candidate 同时通过三个互相耦合的 gate。

这证明 schema 越详细不等于语义越明确。布尔 gate、pairwise ranking、全局
opaque evidence ID 给模型增加了元任务，反而稀释了“哪个是 critical error”
这一核心判断。

### v7/v8：工程可信度显著提高，Step 仍停滞

v7/v8 建立了实现快照、request/response/model provenance、resume lineage
和严格字段；inference、prediction freeze 与 audit 全程 gold-free，只有全部
审计完成后 `_score()` 才加载 gold。这使 clean v8 结果可信。v8 还修复了
唯一的 guarded provider error，并把 All Correct 提到 2/8。

但 v8 的 gold step 已在候选集中的比例是 6/8，最终 Step 只有 3/8。也就是说，
一半损失发生在 candidate 已召回之后。剩余核心不是单纯 Phase-1 recall，
而是 temporal ownership 和 benchmark critical-boundary convention。

### v9：正确方向被错误接口合同阻断

v9 加入 exact recurrence、family return 和 top-3 temporal owner，但
recommitment schema 同时要求一个 prior 和两个 placeholder，四条 case 在该
阶段耗尽；temporal 又让 nonterminal candidate 看到下一步 terminal output，
并把任何 `rank 1` 字样当位置偏置。v9 的 17 个成功但被拒响应消耗 157,270
tokens。失败主要在协议合同，不足以检验语义假设。

### v10：候选合同改善后，证据层暴露为主瓶颈

v10 的 recommitment 8/8 首轮通过，temporal 7/8 通过，说明 v9 的主要合同
问题已被修复。但最终仍有 3 条失败：

- 一条把不同历史 step 的 plan/action 拼成不存在的同-step quote；
- 一条正确识别文本差异，却因嵌套 JSON 的 escaped/decoded 表示不同而不能
  通过 literal validator（第一次还插入了原文不存在的省略号）；
- 一条 quote 物理位于当前 memory，却把 scope 按“语义上谈论历史”填成
  prehistory。

更重要的是，5 条完成 prediction 中存在跨阶段 defect drift：temporal 说
错误是重复 plan/action，module/type 却改判 memory omission；另一些 case 的
type reasoning 解释了与 frozen root cause 不同的问题。Lineage hash 能证明
“文件来自哪个上游”，却不能证明“所有阶段在分析同一个缺陷”。

事后只读对照 gold（不构成正式评分）显示：v10 的候选池已覆盖 7/8 个 gold
Step，但 selector 只选中 3/8；5 条走完全部阶段的局部 prediction 中恰有
3 条 Step exact、2 条 Step+Module、2 条 All Correct。这个对照说明 v10 的
Phase-1 recall 已不再是唯一主因，候选仲裁、temporal owner 与下游合法性共同
阻断了候选信号转化。由于 cohort 不完整，这些数字只能用于机制诊断。

11 个被拒响应应进一步拆开：纯 schema/interface 3 次（38,060 tokens）、
selector policy 2 次（64,478 tokens）、literal/scope evidence binding 6 次
（111,039 tokens）。因此 v10 不是 provider/transport 失败；主要损耗发生在
确定性 post-parse 合同和证据表示层。

## 当前瓶颈分解

### 1. Critical step 不是普通分类，而是时间归属问题

同一个失败链通常同时包含：坏 plan、执行该 plan 的 action、失败 observation、
下一步对 observation 的错误解释和最终 unsupported answer。Exact benchmark
只奖励其中一个人工选择的边界。当前 judge 经常识别到真实缺陷，却把它归给
相邻 step：

- plan/action defect 应归发出选择的 step；
- observation content 的首次错误解释应归 next agent step；
- 独立 provider exception 才归产生 observation 的 system step；
- terminal answer 若只是未修复上游错误的症状，不应覆盖上游 owner。

这些规则无法靠“偏早”或“偏晚”的单一提示修复，因为不同 case 的正确方向
相反。

### 2. Candidate recall 必要但不充分

v8 的 6/8 recall 对应 3/8 exact。两个 recall miss 是不同 recurrence ontology：
一个是一次失败后换通道、再回到原 evidence channel；另一个是第三次完全相同
tool+parameters 且 observation byte-identical。v10 的 deterministic recurrence
修复了后一类结构召回，但 selector/temporal/module 仍可能改变 owner。

因此下一阶段不能继续只追求更多候选。候选必须携带“为什么这个 episode 已
成熟”的结构证据，且最终 owner binder 必须能机械核验该证据属于哪个 step。

### 3. Evidence representation 与语义任务脱节

当前模型既要完成诊断，又要手工复制长 literal quote、判断物理 scope、复制
opaque ID、选择 locus。v6 的全局 ID crosswalk 会把证据抄到别的 step；v10
改成长 quote 后又出现转义不一致和跨 span 拼接。

最根本的问题是 prompt renderer 与 validator 没共享一个小型、canonical 的
证据对象。只要 evidence 仍以任意长自由文本传递，严格性和成功率就会持续
冲突。

### 4. 串行 handoff 冻结了标签，没有冻结 defect predicate

`selected_step`、`module`、`type` 的 hash lineage 都可以正确，而三个阶段仍
可以分别解释三个不同缺陷。后续 agent 看到上游 step，却没有被约束为对同一
原子命题进行 owner/type 分类。这是当前“形式审计通过、语义仍漂移”的主要
来源。

### 5. Module/type taxonomy 有真实重叠

主要歧义包括：

- `memory_retrieval_failure` 与 `over_simplification`；
- `inefficient_plan`、`impossible_action` 与 `constraint_ignorance`；
- `outcome_misinterpretation` 与 `progress_misjudge`；
- cumulative `<think>` 中的 planning 与 reflection；
- observable provider failure 与已有错误计划的 causal precedence。

v10 的 module retry 没有改变 module 标签，真实标签不稳定主要集中在 type；
但 temporal→module 的跨阶段 defect predicate 漂移很明显。一次纯 extra-field
repair 甚至使 type 从 retrieval failure 翻转成 over-simplification，说明
schema retry 正在无意中承担 taxonomy resampling。

### 6. 公开材料不足以精确复现论文 29/50

公开论文、仓库和 release 之间存在可验证差异：

- 论文描述的 counterfactual rollout 与公开 critical detector 的单次 LLM
  arbitration 不一致；
- 公开 Phase 1 能检测 system，但序列化路径没有稳定地把 system 交给 Phase 2；
- Table 1 的逐 case prediction、中间 proposal、确切代码 commit 和调用日志未
  发布；
- 发布 GAIA-50 至少一条轨迹只有一个可映射 assistant step，而 label 是 S3；
- 当前 provider 的 resolved model 是 `gpt-4.1-2025-04-14`，无法证明与论文
  实际 endpoint/model snapshot 完全相同。

Canonical input repair 在一个先验选出的 10-case structural gate 上把 Step
从 8/10 提到 9/10，但 Step+Module 仍是 3/10。这进一步说明输入重建确有影响，
而 Phase-2 owner/ontology 仍是更大的剩余问题。

### 7. 评测已高度暴露，存在调优过拟合风险

GAIA smoke-30、GAIA-50 和 hard-8 均已多轮读取错误并修改协议。hard-8 的成员
就是按旧实验失败挑出的。继续在同 8 条上加入规则，很容易提高记忆式匹配，
却不能支持泛化结论。任何后续分数必须明确是 GAIA release tuning result。

## 未来优化方向

下面只是暂停点后的设计建议；本轮没有实现或启动新实验。

### P0：先重做证据契约，再改诊断语义

1. 从 JudgeView 由代码生成局部 canonical evidence atoms。每个 atom 固定包含
   step、module/span、causal phase、normalized text 和 hash；raw/decoded JSON
   使用同一规范化表示。
2. 每个 candidate 只展示自己的少量 atom，不使用全轨迹 opaque-ID catalog，
   也不要求模型复制长 quote。
3. `scope`、`locus`、candidate ID 和 selected step 均由选中的 atom/卡片机械
   派生；模型只输出真正需要语义判断的选择和短理由。
4. 关系型错误使用 evidence pair：plan↔action、observation↔next interpretation、
   memory↔source observation。单 quote schema 应被淘汰。
5. JSON parser 拒绝重复 key；sole-option stage 确定性旁路；null/extra-field
   等无语义错误本地规范化或进行字段锁定 repair。

可证伪目标：在不改变 v10 的语义选择逻辑时，先把 8/8 合法输出恢复；若仍
失败，说明问题不只是表示层。

### P0：缩减拓扑和上下文

建议从 9 个 LLM stage 收缩为最小的四类职责：

1. 高召回 candidate locator；
2. temporal owner binder；
3. module owner；
4. late-bound type。

Deterministic recurrence、provider exception、terminal identity、可见 module
span 和 evidence source 由代码完成。不要再为 coverage、assessor、selector
分别重复整条轨迹。Action/terminal 只看 task、当前 step 和 decisive local
context；memory/reflection 才看按 step 分卡的必要历史。

可证伪目标：调用数和 token 至少显著低于 v8，同时保持 8/8 合法；如果精简后
candidate recall 和 Step 不降，说明中间 assessor/selector 没有净贡献。

### P1：把 temporal ownership 变成显式事件图

由代码建立：

`plan/action emission → observation → next memory/reflection → later recovery → terminal`

候选卡携带 tool signature、canonical parameters、observation hash、prior episode、
是否出现 new evidence。Exact recurrence 取 earliest mature episode；同 subgoal
但不同 operational channel 不合并；后续真正恢复时降低早期 transient candidate。

模型只比较少量已经结构化的 owner 候选，并必须回答“缺陷命题是什么、修复该
点是否会改变失败链”。最终 step 从 owner event 机械派生。

### P1：冻结 defect predicate，防止下游换题

Temporal stage 应输出结构化 defect predicate，例如：

- actor/action；
- violated relation；
- owner event；
- counterfactual repair；
- evidence atom pair。

Module/type 只能分类这个冻结 predicate，不得重新生成 root cause。若某个 type
与 predicate 不兼容，应返回 `no_legal_type` 让实验失败，而不是改讲另一个
缺陷。这样 lineage audit 才从“文件哈希链”升级成“语义对象链”。

### P1：单独校准 type，而不是借 schema retry 重采样

在完整 GAIA release 上统计容易混淆的合法 type pair，用统一定义和最小对照
上下文做 comparator；不要按 case ID 或 gold 增加规则。Repair 只修结构字段，
已合法的 type ID 和 reasoning 必须锁定。若需要第二个 type reviewer，应作为
预先冻结的正式阶段，而不是错误触发的隐式重抽样。

### P2：把“复现论文”与“改进本地 judge”拆开

复现线应优先获取或确认：论文实际 commit、GAIA artifact 版本、GPT-4.1 model
snapshot、Phase-1 intermediate proposals、Table-1 per-case predictions 和 System
补丁。缺少这些材料时，只能称“公开仓库拓扑复现”，不能称论文 implementation
等价。

改进线则以本地 frozen GAIA-50 为目标，明确记录与论文协议的差异。两条线不要
再混用“官方”名称或把一个拓扑近似的低分归因成单一模型问题。

### P2：恢复实验时采用新的评测纪律

- 先用 gold-free structural tests 验证 8/8 输出与 lineage，再冻结协议；
- 任何语义候选必须完整跑相同 GAIA cohort，失败输出计错，禁止 partial score；
- 同一版本/目录不得运行中修改 validator；
- 把 hard-8 仅作为开发诊断，最终报告只称 release-tuning；
- 若希望评价泛化，必须另建从未用于 prompt/error analysis 的 GAIA validation
  cohort，而不是继续复用当前 8/30/50 条。

## 建议的决策顺序

如果之后恢复优化，最合理的顺序是：

1. 先解决 canonical evidence、scope 派生、字段锁定 repair 和重复 JSON key；
2. 再删减 assessor/selector 等重复阶段，建立最小 owner event graph；
3. 只有在 8/8 合法且成本下降后，才检验 candidate recall 与 temporal ownership；
4. Step 可靠后再校准 module/type；
5. 最终只能通过全量、冻结、gold-free GAIA-50 运行与论文 29/50 比较。

继续直接增加 reviewer 或 case-specific prompt 规则，最可能重复 v5--v10 的模式：
局部错误被修复，接口数量、token 和新失败类型同步增加，而 Step Exact 上限不变。

## 当前暂停点与报告口径

本报告严格以 GPT-4.1 hard-8 causal-v10 为分析截点。workspace 后来出现的
post-v10 协议、运行与文档不属于本报告的证据集，也不能反向改变 v10 的协议、
prediction 或结论。当前优化已经再次暂停；v10 保持为不完整、未评分的冻结
失败实验，禁止续跑、拼接 5 条局部 prediction 或事后放宽 validator 后评分。

当前本地 GAIA-50 incumbent 仍是 Luna v3.4 的 21/50 Step Exact，这一结果是
GAIA release tuning result，不是未知数据上的泛化准确率。它也不能代替当前
`tuning-v1` 目标的 30-case 实验：历史 routed Luna v12 的 13/30 使用了同 case
v3 prediction 做 preserve/replace 分流，按当前固定边界无效；proposal-free
standalone v12 虽然 30/30 合法，但只有 7/30。详细合规审计见
`docs/experiments/luna-v12-goal-completion-audit-2026-08-20.md`。

## 证据索引

- v10 失败分析：
  `output/agenterrorbench-sophnet-gpt-4.1-gaia-step-error-gate-v8-agent-judge-causal-v10-case8/analysis.md`
- v9 失败分析：
  `output/agenterrorbench-sophnet-gpt-4.1-gaia-step-error-gate-v7-agent-judge-causal-v9-case8/analysis.md`
- strict-v8 完整 error analysis：
  `output/agenterrorbench-sophnet-gpt-4.1-gaia-step-error-gate-v6-agent-judge-strict-v8-case8/analysis.md`
- Luna GAIA-50 v3.4 与论文差距：
  `output/agenterrorbench-codex-gpt-5.6-luna-gaia-paper-v1-agent-judge-luna-gaia-v3p4-case50/analysis/implementation-gap-and-complete-error-analysis-2026-08-15.md`
- GPT-4.1 公开仓库拓扑完整报告：
  `output/agenterrorbench-sophnet-gpt-4.1-gaia-paper-v6-agent-judge-official-repo-topology-v1-case50/scored/report.md`
- Canonical-input 10-case analysis：
  `output/agenterrorbench-sophnet-gpt-4.1-gaia-structural-gate-v1-agent-judge-official-repo-canonical-v2-case10/analysis.md`
- GAIA smoke-30 Luna 优化记录：
  `docs/experiments/gaia-smoke-v1-luna-optimization.md`

# GAIA v3.88 GPT-5.5 sparse influence-graph challenger preregistration

Date: 2026-08-29

## Frozen identity

- Version: `agentdebug.codex-agent-judge.gaia-v3.88-gpt55-sparse-influence-graph-challenger`.
- Direct semantic parent: accepted v3.83, Step Exact `26/50`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction manifest SHA-256: `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`.
- Frozen v3.83 protocol SHA-256: `a97908a78cec8df5fe9e4777d30aa9ecf498d1cdd1d692a42cc66976e9844531`.
- Frozen v3.83 runner SHA-256: `a1613a04ad21b3306c61cd3082753ff5890ad09ab3d939f4c292c15e1dac483d`.
- Frozen v3.83 predictions SHA-256: `f74161b06c456461ccacdcf7c708157154e8e9810cb5dffa8ef09352698fca3d`.
- Model: `gpt-5.5`; reasoning effort: `medium`.

## Prior falsification evidence

Rejected v3.87 completed 50/50 legally at Step Exact `18/50`. Its lifecycle
challenger proposed 13 Steps, only one proposal was exact, and direct overrides
caused 1 gain, 6 losses, and 5 wrong-to-wrong moves. It repaired none of the 24
frozen v3.83 errors. Six errors first diverged at false challenger override.

The common defect was an unverified causal edge: literal origin, obligation,
and manifestation quotes could be topically related without the later Step
actually consuming a value, state, target, predicate, or control decision
produced at the proposed root.

## Single major change

Replace only v3.83's later-only challenger with one sparse influence-graph
challenger. It may emit at most one earlier-or-later proposal and must encode a
single chronological chain of one to three typed producer-to-consumer edges.
Every edge binds:

- producer Step and literal producer quote;
- consumer Step and literal consumer quote;
- a literal atom substring on each side;
- relation type: state inheritance, observation consumption, target handoff,
  or control dependency;
- observed effect: preserved, distorted, dropped, or recommitted.

The chain must start at the proposed root and end at an observable terminal
failure manifestation. The proposal is illegal if the chain is empty, broken,
nonchronological, only topically similar, cleanly recovered, or not failure-
material. A task or trace obligation quote is also required. The graph is not
a candidate inventory: it represents only the single strongest claimed root.

The v3.83 packet-state anchor, GPT-5.5/medium, one-proposal maximum,
direction-specific anchor falsification, default-keep exact-copy arbiter,
taxonomy, final schema, case order, and gold-free boundary remain unchanged.
Generic bidirectional artifact transport may be reused, but no rejected prompt,
prediction, candidate, lifecycle classification, or scored artifact is an
inference input or semantic parent.

## Falsifiable hypothesis and risk

Explicit producer-consumer provenance will suppress v3.87-style false causal
overrides while allowing a root outside the anchor's first-surviving-candidate
prefix to be recalled. Main risks are under-recall from an overly strict atom
contract, invented semantic equivalence between different literal atoms, and
late-symptom chains whose first edge already starts downstream.

Post-score graph-root recall, proposal exactness, and direct override precision
are diagnostic only. They do not select the version.

## Acceptance and Goal completion

- Accept only if Step Exact is strictly greater than `26/50` and all legality checks pass.
- Complete the Goal only if Step Exact is at least `30/50` and all legality checks pass.
- Only Step Exact selects, accepts, rejects, or completes versions.
- No smoke gate is used; after offline validation run the complete GAIA-50 directly.

## Pre-inference freeze

- Protocol source SHA-256: `2a79f223c76c2c0687eab3ec6ae6ba5ccfa3adda9da7c75c256b26edad14f2cb`.
- Runner source SHA-256: `d8ce20c5300000b36e96e6dc900aebc2eb0e8ba4347e8920034930af067a6c2b`.
- Negative/identity test source SHA-256: `c0e4aa44fac1d148f234cbc8c9ecb0df09bb555602c1549fa1af2fb275f36ba8`.
- Frozen tuning plan SHA-256: `1770a9734875c6a6becba5890b769c72dd05ab03bd0b8e0de655c18cb9669e8a`.
- Offline validation: 25 targeted and inherited tests passed; exact v3.83
  anchor semantics, registry/model/effort, graph JSON nullability, contiguous
  chronology, literal endpoint/atom checks, bidirectional exact-copy transport,
  compilation through import, and 50-case dry preparation passed.
- Static inference-source scan found no label, metric, scored artifact,
  historical prediction, v3.87 semantic import, case/entity router, or
  post-score audit reader.

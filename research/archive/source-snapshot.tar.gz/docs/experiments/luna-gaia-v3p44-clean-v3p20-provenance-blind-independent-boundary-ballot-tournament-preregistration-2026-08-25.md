# Luna GAIA v3.44 preregistration

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.44-clean-v3.20-provenance-blind-independent-boundary-ballot-tournament`
- Direct semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: v3.20, Step Exact `25/50`
- Acceptance: Step Exact `>25/50`; Goal completion: Step Exact `>=30/50`
- Frozen `gaia-paper-v1` 50 cases; dataset SHA-256 `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`; cohort SHA-256 `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- `gpt-5.6-luna`, reasoning `medium`; no smoke gate; full GAIA-50 after offline validation.

Single major mechanism: retain one clean v3.20 anchor, packet-state ledger, and
checkpoint unchanged. Replace the downstream challenger/arbiter topology with
one provenance-blind independent-boundary ballot tournament. Four fresh,
mutually isolated, anchor-blind sessions each read the full Canonical Trace and
emit exactly one complete critical-Step ballot under the same uniform
benchmark-boundary contract. The runner combines those four frozen ballots
with the unchanged v3.20 anchor, groups exact Step duplicates, and exposes at
most five anonymous candidate packets. A fresh selector does not receive
candidate provenance, generation order, historical predictions, or any gold
information and may select only one exact frozen prediction from that bounded
pool.

The frozen v3.43 result is the immediate falsifiable basis. It was complete and
legal at Step Exact `21/50`; its unchanged clean anchor also scored `21/50`.
The earlier/later panel emitted zero earlier candidates and only two later
candidates, neither exact. Both overrides were wrong-to-wrong, giving zero
direct gains, zero direct regressions, and an anchor-plus-panel candidate oracle
of only `21/50`. All 29 final errors lacked the released Step. The completed
first-divergence audit classified 12 false candidate admissions, six candidate
recall failures, five annotation ambiguities, three early freezes, two missing
veto/recovery errors, and one late-symptom preference. Direction relative to an
anchor therefore over-protected the anchor and failed as a recall topology.

Additional post-score evidence constrains this new hypothesis. Across 15
frozen clean-v3.20 anchor samplings from v3.29 through v3.43, the union oracle
was `29/50` but simple majority was only `24/50`; five recent samplings had
union `27/50`. The v3.42 anchor-plus-specialist pool reached oracle `26/50` but
its single shared specialist session remained highly correlated. v3.44 tests
whether independent, identically governed, anchor-blind full-boundary ballots
can add the missing recall diversity without inheriting any rejected lane or
candidate rule. Historical predictions support only this post-score impact
estimate and are not visible to inference.

Expected gains are current wrong anchors for which at least one independent
ballot recalls the released Step and the provenance-blind selector recognizes
its literal owner, evidence, maturity, veto status, and local-repair boundary.
The main regression risk is that a diverse but wrong ballot displaces an
incumbent-correct direct execution or literal-constraint boundary. Controls are
four fixed ballots for every case, identical data access, no source/model/case
routing, full chronology, explicit reasonable-probe/recovery/mechanical-repair/
faithful-propagation/normal-failure vetoes, Step grouping, a five-Step hard cap,
anonymous candidate IDs, exact-copy-only selection, and a selector requirement
to compare every distinct Step before freezing.

v3.21 through v3.43 and all other rejected versions remain immutable and are
not semantic parents. Their prompts, panels, challengers, selectors, ledgers,
validators, and predictions are not inherited or visible to inference. v3.44
is implemented afresh over v3.20 anchor semantics and shared execution
utilities. Inference may not read labels, scores, audits, prior predictions,
experiment documents, case studies, or git history.

Diagnostic falsifiers are a candidate oracle below `30/50`, more than five
distinct candidate Steps, any ballot or final that is not schema-valid, any
selected prediction that is not an exact input copy, or non-positive direct
selector net gain. These diagnostics do not accept a version: the sole version
acceptance rule remains final Step Exact `>25/50`, and Goal completion remains
final Step Exact `>=30/50` after all legality checks.

# E9 v35 full30 failure case study

## Outcome

v35 passed its frozen dry3 gate at 2/3 for Step Exact, Step+Module Exact,
and All Correct.  Its full30 tuning run then completed the entire raw chain,
but failed the preregistered semantic promotion gate:

- Step Exact: 7/30 (23.33%; gate requires 12/30);
- Step+Module Exact: 4/30 (13.33%; gate requires 3/30);
- All Correct: 4/25 (16.00%; gate requires 3/25);
- successful outputs: 30/30;
- failed outputs: 0/30;
- new full30 logical completions: exactly 20;
- HTTP attempts: exactly 20, with zero retries.

Only `step_exact_minimum_correct` failed.  The rejected promotion artifact is
self-bound by
`56929b4280ac5604907fc7bb160962687c9ec01046299e0a15b2ba11e3c0141c`.
Held-out smoke must not run from v35.

## Format attribution

The v35 symmetric repair was exercised by a real Flash Selector response.
The accepted dry batch response contained all three complete case objects but
ended in `}]`, omitting exactly the enclosing top-level `}`.  Appending that
one character produced a strict object which then passed the unchanged case
count, field, taxonomy, source-ID, ownership, and evidence validation.  All
three cases record
`added_single_missing_final_object_close` in their raw adjudication audit.

The full30 run reused that accepted dry pair for batch 1 and completed the
remaining ten batches without any invalid row.  Thus v35 fixed the v34 format
blocker without changing a critical step, module, error type, or cause.  The
remaining failure is semantic, not transport or parsing.

## Semantic attribution

The environment Step Exact breakdown is:

- ALFWorld: 1/10;
- GAIA: 4/10;
- WebShop: 2/10.

Of the 23 wrong critical steps, 16 are later than gold and 7 are earlier.
Their released owner modules are planning in 11 cases, reflection in 6,
memory in 5, and action in 1.  The corresponding wrong predictions select
action in 14 cases, including nine `action/format_error` diagnoses.  The
dominant failure mode is therefore choosing a concrete action symptom instead
of the earlier memory, reflection, or planning output which introduced the
failed branch.  A second failure mode selects a terminal repetition or
boundary after the released critical decision.

The six released `inefficient_plan` cases are all Step-wrong.  The prompt's
accumulated special rules for first defects, mature recommitments, query
epochs, capability contracts, terminal guards, and pairwise lanes do not
define one stable annotation policy.  They give Flash several defensible but
incompatible selection objectives inside the same completion.

## Reproducibility attribution

v34 and v35 have byte-equivalent semantic instructions; v35 changes only the
one-character mechanical parser repair and protocol identities.  On the 18
overlapping prefix cases, however:

- v34 selected 9 exact steps;
- v35 selected 4 exact steps;
- only 7/18 complete step/module/type tuples agree.

Both runs used `deepseek-v4-flash`, temperature zero, the default request
body, and no thinking configuration.  Temperature zero therefore does not
make this provider/model deterministic on these long prompts.  Re-running an
unchanged prompt is not a valid optimization: it can exchange correct cases
without fixing the decision rule.

## Divergence from the original AgentDebug judge

The released repository's Phase 2 prompt is materially simpler.  It asks for
the earliest and most important error that led to failure, treats steps 1--3
as ordinary exploration unless a clear fundamental error is already visible,
traces causality backward from final failure, tests whether correcting only
the selected error would fundamentally redirect the trajectory, and permits
a system boundary to be the true cause.  It does not contain the growing list
of environment-specific tie breakers now present in v35.

The v35 prompt is therefore over-specified relative to the annotation process
it is trying to reproduce.  Its many locally reasonable clauses amplify
Flash's selection instability and over-focus the judge on concrete action
outcomes.

## v36 optimization direction

Before another provider call:

1. Preserve v35's strict raw-response chain, symmetric one-brace repair,
   source-ID evidence binding, atomic taxonomy pair, gold isolation, exact
   ledger accounting, and raw Selector as the sole final semantic source.
2. Replace the accumulated Candidate and Selector tie-breaker prose with the
   original AgentDebug Phase 1/Phase 2 causal contract: inspect each visible
   module output at each step, then choose the earliest *important* error
   whose one-error correction would fundamentally redirect the failed
   trajectory.
3. Explicitly retain the original early-exploration qualification: steps
   1--3 are usually probes, but a contemporaneously clear fundamental error
   may still be critical.  This is a causal test, not a fixed early-step ban.
4. Require the final Selector to trace backward from the observed failure and
   distinguish an introducing owner output from an action, repetition, or
   terminal symptom.  Do not add an unconditional preference for any module
   or numeric step direction.
5. Keep the predecessor and Candidate output as untrusted hypotheses.  They
   are neither evidence nor fallback; the independent raw Selector still
   emits every final semantic field.
6. Add no confidence, score, rank, vote, weight, deterministic semantic
   finding, or semantic repair.  Run a new frozen dry3 and proceed to full30
   only if that gate passes.  Any later failure again requires a case study
   before another LLM attempt.

No v35 prediction, cache entry, score, promotion, or ledger may be mutated or
reinterpreted under v36.

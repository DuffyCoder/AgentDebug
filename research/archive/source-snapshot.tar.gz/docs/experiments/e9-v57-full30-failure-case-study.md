# E9-v57 earlier-only incumbent review full30 failure case study

## Result

v57 completed the full 30-case tuning evaluation with ten new logical calls
(cumulative 648 -> 658) after reusing its accepted dry batch. The exact result
was:

- Step Exact: 10/30
- Step + Module: 4/30
- All Correct: 3/25
- Successful predictions: 26/30

It tied v30 on the primary metric but lost every relevant tie-breaker, so v30
remains the sole incumbent and heldout remains closed.

## Semantic gains and losses

Compared with v30, the earlier-only reviewer changed only six cases and kept 24.
It gained two exact steps:

- ALFWorld `GPT-4o_043...`: step 9 -> gold step 6
- GAIA `GPT-4o_011...`: v30 invalid -> gold step 3

It lost two v30 exact steps:

- GAIA `GPT-4o_004...`: v30 gold step 1 -> invalid reviewer output
- GAIA `Llama...003...`: v30 gold step 2 -> batch-level judge exception

The other two changed cases were already wrong in v30 and became failed rows
because they shared the judge-exception batch. Thus the two genuine gains and
two losses cancel at 10/30.

## Failure modes

1. **Step-1 contract violation.** For the first lost case, the incumbent was
   step 1 system/step-limit. The reviewer emitted `replace` at the same step
   with memory/hallucination. This violates the earlier-only contract; its
   evidence ID also belonged to a different step/module owner, so the raw case
   was invalid. A reviewer should recognize mechanically that a step-1
   incumbent has no strictly earlier replacement and can only be kept.
2. **One batch-level provider exception.** Batch 8 returned no semantic JSON,
   producing three failures, including one v30-correct case. The frozen
   no-retry policy correctly retained these as failures; they cannot be patched
   or retried inside v57.
3. **Module selection remains weaker.** Even both new correct steps used a
   module different from gold, so Step+Module did not improve.

## Evidence-backed next direction

v57 is the first reviewer candidate whose semantic union with v30 reaches the
12/30 development target: preserve v30's ten correct cases and retain v57's two
new exact-step gains. The next experiment therefore remains a fresh branch from
v30 and strengthens only the incumbent-copy contract:

- show an explicit per-case copy table containing incumbent step, taxonomy
  pair, and exact evidence source ID;
- state that incumbent step 1 makes `KEEP` mandatory because no earlier step
  exists;
- require `KEEP` to emit the exact copy-table fields;
- retain the strict causal burden for any earlier `REPLACE`;
- continue treating violations and provider failures as incorrect, with no
  deterministic fallback.

This uses v57 only as failure-analysis evidence. The new Judge still receives
the complete trajectory plus frozen v30 roots, not v57 predictions. If it
preserves the two known v30 losses while retaining the two independently found
earlier roots, it reaches 12/30 without changing the evaluation pipeline.

# Official AgentDebug GAIA-50 over GPT-5.5 Codex SDK

Status: preregistered and unscored.

This is a reporting-only method/transport reproduction. It is not a candidate
in the accepted Luna v3.83 lineage, and its score cannot complete the active
Step Exact optimization Goal.

## Question and frozen deviations

The frozen local reproduction of the public AgentDebug repository used GPT-4.1
through a Chat Completions-compatible endpoint and scored 14/50 Step Exact on
the frozen `gaia-paper-v1` cohort. That number is a contextual reference, not a
controlled model-only comparator. Besides using requested `gpt-5.5`, medium
reasoning, and local ChatGPT authentication through `openai-codex==0.147.0`,
this experiment removes the old local runner's non-public outer Phase-2
semantic retries and its post-hoc retry/normalization amendments. It keeps only
the public `CriticalErrorAnalyzer` retry.

The public detector source, prompts, raw parser, Phase-1 topology, Phase-2
topology, and normalization code remain unchanged. The official source snapshot
is commit `7740fe3a5c4822b2143cbde78ecfffeace0bb166` with:

- `fine_grained_analysis.py`: `b640537ba4ba3232d9def59ad6d5c7bc1e3bcb2ddc9f07f25e6081586a2712fd`
- `critical_error_detection.py`: `7791fc671eef2b8a1296131ce7a9ef68bbcaa63d518b1e17ab5bc08b9dcecb4c`
- `error_definitions.py`: `415ced442e998133d23526d05064eef908a8e4df50519d7355af12e838d9d9bb`

The run imports only its copied and hash-verified source snapshot. It removes
same-name Python modules from `sys.modules`, imports the frozen definitions
first, and asserts every imported `__file__` and loader class identity.

## Scope and topology

The input is the frozen 50-case GAIA paper cohort, dataset identity
`fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
It contains 717 parsed assistant steps.

Phase 1 preserves the public sequential, independent checks. Across GAIA-50 it
requires exactly 3,202 successful model calls: 2,768 module checks and 434
conditional system checks. Step-1 memory/reflection and absent WebShop
memory/reflection checks retain the public skips. The public implementation's
omission of system verdicts from the serialized `StepAnalysis` is retained.

Phase 2 makes one global critical-error call per case. The only semantic retry
is the public `CriticalErrorAnalyzer` retry when it selects Step 1
memory/reflection, for at most three public calls in that case. There is no
runner-level Phase-2 retry, repair, or normalization retry. The clean run
therefore has at least 3,252 successful model calls.

## Transport approximation and known differences

This is explicitly an **agentic-transport approximation**, not a claim of
direct API equivalence or reproduction of the paper's published number.

The public system prompt maps byte-for-byte to Codex thread
`base_instructions`; the public user prompt maps byte-for-byte to the turn
input. Each public LLM call uses a fresh ephemeral thread and carries no
cross-call conversation state. Preflight requires ChatGPT authentication, one
exact `gpt-5.5` catalog entry with medium reasoning support, and a fixed
non-benchmark JSON probe before benchmark input is read.

The unavoidable differences from the old API call are frozen:

- Codex exposes no temperature control, so no temperature is sent.
- No output schema is supplied. The old `response_format={"type":"json_object"}`
  has no lossless high-level SDK mapping.
- The app-server uses the Responses wire path and does not expose the resolved
  per-turn model identifier.
- The captured Responses request uses exactly these 13 top-level keys:
  `client_metadata`, `include`, `input`, `instructions`, `model`,
  `parallel_tool_calls`, `prompt_cache_key`, `reasoning`, `store`, `stream`,
  `text`, `tool_choice`, and `tools`. It uses streaming, `store=false`,
  `tool_choice=auto`, low text verbosity, and includes
  `reasoning.encrypted_content`. It does not send `conversation`,
  `previous_response_id`, `max_output_tokens`, `temperature`, or `top_p`.
- Every formal process launch must reproduce stable wire-contract hash
  `79f6d3c17385f550cc19ca434f2e41055029315ef03224bf0562b593599967bd`
  and model-visible-tools hash
  `c33cfea2ab4eb8f8aa8a99c4dba2c55e2fc80f1fe3537845b1ec4c4e011770be`.
  The first values are frozen in the run plan, every resume must match them,
  and the final summary revalidates all persisted process preflights.
- Loopback capture shows that SDK 0.147 sends the exact system/user text with
  no added developer, environment, or skill text, but exposes the core tools
  `apply_patch`, `request_user_input`, and `update_plan`, with
  `parallel_tool_calls=true`. High-level SDK configuration cannot remove these
  declarations. Any actual tool or harness item in a formal response fails the
  entire run; zero observed calls does not mean zero advertised tools.
- Runtime capture observed no optional developer, environment, or skills
  context in the model request.
- Provider-internal retry behavior is not observable as a fixed budget through
  the high-level SDK.

The transport uses a temporary auth-only `CODEX_HOME`, strips inherited
credential-shaped environment variables, disables configurable tools,
features, bundled skills, history, and memories, and runs in an empty read-only
directory. Authentication and account identity are never written to experiment
artifacts.

## Failure, restart, and freeze policy

The first formal launch requires a clean run directory. A bounded same-prompt
retry is allowed only for the preregistered non-semantic transport code
`sdk_call_failed`, with three runner-level attempts per
logical call. A tool/harness item, provenance mismatch, unrecoverable official
parser failure, normalization failure, or validator failure is terminal and
cannot be repaired by restarting. Provider-internal retries remain opaque and
are not counted as runner-level logical attempts.

An explicit `--resume` is allowed only after a non-semantic process
interruption in this same run identity. It verifies the run plan, benchmark
scope, official sources, implementation snapshot, SDK/CLI versions, transport
contract, prompts, and request hash. Only a contract-identical successful call
may be reused. A validated `response.json` caught in the atomic gap before its
`success.json` may be mechanically finalized and reused. Every existing or
half-written attempt consumes the original fixed budget; restart never grants
new attempts. There is no cross-run, cross-version, or global cache.

All 50 predictions, every intermediate call artifact, provenance, official
Phase-1/Phase-2 result, and validator audit must exist before the gold-free
tree is frozen and reverified. The released labels are first opened inside the
scorer after that point. The final report includes Step Exact, Step+Module, All
Correct, successful-call token usage, per-call SDK/queue/run/wall latency,
failed-attempt elapsed time, and cumulative recorded process wall time. Token
usage for failed attempts and opaque provider-internal retries is unavailable;
wall time for a hard-killed process is likewise unavailable and counted
explicitly. These results compare transports and models but do not select the
active Luna lineage.

## Commands

Prepare a clean official checkout (the source hashes are verified again by the
runner):

```bash
git clone https://github.com/ulab-uiuc/AgentDebug /path/to/AgentDebug-official
git -C /path/to/AgentDebug-official checkout 7740fe3a5c4822b2143cbde78ecfffeace0bb166
```

```bash
.venv/bin/python -m scripts.run_agent_judge_gaia_official_repo_gpt55_codex_sdk_paper50 --official-repo /path/to/AgentDebug-official
.venv/bin/python -m scripts.run_agent_judge_gaia_official_repo_gpt55_codex_sdk_paper50 --preflight-only
.venv/bin/python -m scripts.run_agent_judge_gaia_official_repo_gpt55_codex_sdk_paper50 --execute --official-repo /path/to/AgentDebug-official --max-concurrency 4 --max-transport-attempts 3
```

Only for the identical interrupted run:

```bash
.venv/bin/python -m scripts.run_agent_judge_gaia_official_repo_gpt55_codex_sdk_paper50 --execute --resume --official-repo /path/to/AgentDebug-official --max-concurrency 4 --max-transport-attempts 3
```

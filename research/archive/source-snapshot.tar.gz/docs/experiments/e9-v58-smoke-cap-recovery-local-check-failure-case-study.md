# E9 v58 smoke cap-recovery local check failure case study

## Failure

The first provider-free `check` exited before inspecting the interrupted
boundary with `KeyError: 'preregistration'`. No API key was loaded, no provider
was constructed, and the 24-entry source ledger and all three caches remained
unchanged.

## Attribution

`SOURCE_ARTIFACT_SHA256S` intentionally uses concise artifact labels such as
`preregistration`, while `_paths()` uses the unambiguous internal key
`source_preregistration`. The boundary loop incorrectly assumed those two
namespaces were identical. This is a recovery-harness lookup bug, unrelated to
the Critic cap or semantic pipeline.

## Correction

Use one explicit label-to-path-key mapping at the artifact verification
boundary. Keep every expected digest unchanged, rerun the provider-free check,
and do not freeze or invoke the provider unless the complete boundary passes.

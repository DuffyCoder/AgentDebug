# Luna GAIA v3.14 Earliest-Causal Challenger Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia-v3.14-earliest-causal-challenger`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.13-conservative-challenger`
- Frozen comparison baseline: `agentdebug.codex-agent-judge.luna-gaia-v3.4`
- Baseline Step Exact: `21/50`
- Dataset/cohort: frozen `gaia-paper-v1`, 50 cases
- Dataset manifest content SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Cohort content SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Prediction manifest content SHA-256: `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Acceptance condition: full GAIA-50 Step Exact `> 21/50`
- Smoke gate: none; after offline validation, run full GAIA-50 directly.

Step Exact is the only version-selection and completion metric. Module/type are
validated only for legal output and do not participate in acceptance.

## Parent result and audited failure mechanism

v3.13 completed 50/50 with 150 fresh sessions, no retry, no routing, no gold
leakage, and all schema/taxonomy/evidence/hash validators passing. It scored
Step Exact `20/50` and was rejected. Relative to frozen v3.4 it had 2 gains and
3 losses.

The fresh v3.4 anchor in v3.13 scored 18/50. The conservative challenger made
five overrides: three repaired its actual anchor, one was Step-wrong both before
and after, and one changed a correct gold Step-1 external tool failure to Step 2.
Thus the challenger supplied a net +2 over its actual anchor but did not overcome
anchor sampling drift.

The v3.13 post-score audit found a single two-case causal-ordering cluster:

1. a correct external-failure anchor was falsely overridden by an actual later
   reaction that would not necessarily occur if the anchor call succeeded; and
2. an incorrect reasonable-probe anchor was challenged with a salient Step-28
   System exception while the released Step-3 repeated-strategy boundary never
   entered the candidate set.

In both cases the common missing check is the same: the challenger does not ask
whether successful anchor repair changes the later path, and it does not select
the earliest later boundary that remains failure-causing under that repair.

## Single major change

Change only challenger causal ordering. Keep the v3.4 anchor stage, one-proposal
maximum, later-only restriction, exact-copy arbiter, default-anchor policy,
model, effort, case isolation, and all validators.

The challenger must now:

1. Evaluate anchor-only repair as a path intervention, not by holding the actual
   later reaction fixed.
2. Retain an eligible external System/tool failure anchor when successful repair
   could avert the later path, unless literal trace evidence proves the same later
   defect necessarily persists.
3. If the anchor is a reasonable probe or noncritical predecessor, scan strictly
   later Steps in chronological order and stop at the earliest Step that remains
   independently failure-causing under anchor-only repair.
4. Never skip an earlier qualifying repeated strategy, false state, or commitment
   for a later, more explicit System exception or stronger wording.

No candidate census, earlier challenger, multiple proposal, case router, entity
rule, trajectory ID, gold rationale, historical prediction, or scored artifact
is visible during inference.

## Falsifiable expectation and impact analysis

The frozen v3.13 result supplies a post-score, non-composable counterfactual:

- expected gain: retain the correct external-failure anchor (one Step gain);
- expected gain: recall the earlier Step-3 boundary instead of Step 28 (one Step
  gain);
- expected static result on the v3.13 frozen outputs: `22/50`.

This is a hypothesis only. v3.14 must generate all predictions anew and is
accepted solely on its own full GAIA-50 Step Exact.

Primary regression risks are the three v3.13 overrides that corrected the actual
fresh anchor. The earliest-causal requirement could choose an earlier weak defect
or over-protect an anchor. Negative tests therefore require:

- a path-dependent external-failure anchor to remain protected;
- a reasonable probe with an earlier independent later root to propose that
  earliest root;
- a later salient System exception not to displace an earlier qualifying root;
- existing valid later overrides to remain legal;
- the arbiter to exact-copy only anchor or the sole proposal.

The one-proposal topology continues to bound candidate flooding and Planning
sink risk. The expected selection shift is earlier only within an already
permitted later challenge, never earlier than the anchor.

## Execution and decision

After implementation, compilation, validator tests, prompt negative tests, and
runner plan validation, run the complete frozen GAIA-50 with no smoke gate.
Freeze all predictions and stage artifacts under gold-free validation before
scoring. Compute only Step Exact for acceptance and the four Step transition
counts against v3.4 for post-score analysis.

- If Step Exact is at most `21/50`, reject and freeze v3.14, audit every Step
  error, and preregister the next single mechanism.
- If Step Exact is at least `22/50`, verify 50/50 completion, legality, hashes,
  no routing, and no gold leakage; then complete the Goal.

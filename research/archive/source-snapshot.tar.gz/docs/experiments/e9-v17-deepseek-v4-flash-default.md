# E9-v17 DeepSeek V4 Flash Default Request Body

E9-v17 tests one user-requested transport change: call `deepseek-v4-flash`
with the provider's default generation behavior. The HTTP JSON body contains
only `model` and `messages`. It omits `thinking`, `temperature`, `max_tokens`,
and `response_format`. The prompt itself still requests one strict JSON object.

The cases, prompt text, frozen v13 predecessor, parsing, gold isolation, and
promotion gates are otherwise unchanged. E9-v16 consumed cumulative logical
completion 365, so this run may consume exactly one call from 365 to 366.

If and only if the response again has the same malformed-JSON pattern, the
next experiment may make one equivalent default-body call using
`deepseek-v4-pro`, from cumulative 366 to 367. No response repair is allowed.

# Luna GAIA v3.23 Mandatory State Scan Before Veto Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia-v3.23-mandatory-state-scan-before-veto`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.22-isolated-bidirectional-state-challenger`
- Semantic anchor parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Frozen incumbent Step Exact: `25/50`
- Original v3.4 baseline Step Exact: `21/50`
- Version acceptance: `Step Exact > 25/50`
- Goal completion: `Step Exact >= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Frozen v3.20 predictions SHA-256: `9df734d95a7c338a9b8ce66fb4d91e16d69961d272ddcc926f7d11f3ddc8add8`
- Frozen v3.22 predictions SHA-256: `3c7992b375e975d63dec90018445d2040e1725c4ab18d9958f93c577a20689bd`
- v3.22 Step audit SHA-256: `d69ff34214465db2f28ef357b51c37e13ba6a0402bf835e063cfa53d3c62f713`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the sole optimization and decision metric. Module/type/evidence
remain legality constraints only.

## Post-score diagnosis

v3.22 produced zero challenges in 50 cases. In each of the five preregistered
state-recall errors, the challenger first classified the anchor as a direct
critical root and then reported no state boundary. This is a search-topology
failure: the anchor veto ran before the independent state scan and made that
scan optional in practice.

The five-case cluster contains four High-confidence and one Medium-confidence
diagnosis. The frozen artifacts show no arbiter-selection failure because no
state candidate ever reached the arbiter.

## Single major change

Preserve the v3.20 anchor and v3.22 closed state-only proposal taxonomy. Replace
the pre-scan anchor veto with a mandatory candidate-first scan certificate.

Every challenger must:

1. enumerate in exact chronology every Step containing Memory or Reflection;
2. scan all enumerated Steps against adjacent feedback;
3. freeze at most one earliest qualifying typed state candidate, or explicit
   `none`;
4. only after that candidate is frozen, compare it with the anchor under the
   same direction, path-effect, and default-keep rules.

The search-summary prefix becomes:

```text
state_scan_steps=<exact comma-separated Steps or none>;
state_candidate_kind=<none|necessary_fact|entity_relation|outcome_claim>;
state_candidate_relation=<not_applicable|omitted|unsupported|contradicted>;
state_candidate_step=<none|Step>;
state_direction=<none|earlier|same|later>;
```

The validator derives the exact Memory/Reflection Step list from JudgeView and
requires an exact match. A no-challenge record may retain a non-none state
candidate when the anchor wins the later comparison; this separates candidate
recall from selection. A challenge proposal must exactly match the frozen
candidate Step and remain owned by Memory or Reflection.

No general candidate pool, non-state proposal, acquisition rule, case router,
entity/site rule, historical prediction, or gold information is added.

## Falsifiable prediction

- 50/50 challengers contain the exact validator-derived state Step list.
- At least one challenger freezes a non-none state candidate.
- At least one challenger emits a state proposal.
- The five audited state boundaries enter the state-candidate stage more often
  than in v3.22.
- Accepted state proposals yield positive net Step transitions against v3.20.
- Step Exact exceeds 25/50.

The hypothesis is falsified if all candidates remain none, if candidates are
recorded but never proposed despite passing path effect, if false state
candidates cause net regressions, or if Step Exact is `<= 25/50`.

## Gain and regression analysis

Expected gains are the five audited earlier Memory/Reflection boundaries and a
later result-contradicting Reflection hidden behind a provisional query
hypothesis. Risks are benign compression, locally false but noncritical state,
and candidate salience overriding a direct correct anchor.

Controls are unchanged: three closed non-clear pairs, exact state owner,
literal evidence, downstream consumption, one-candidate/one-proposal maximum,
direction-specific counterfactual, and independent default-keep arbiter. The
scan certificate changes recall observability, not proposal scope.

## Execution and acceptance protocol

1. Implement the scan-first prompt, validator, runner, and negative tests.
2. Verify v3.20 anchor semantic equivalence and exact scan-list validation.
3. Run offline validation only; no smoke gate.
4. Execute all 50 frozen cases with three fresh serial sessions per case and at
   most four cases concurrently.
5. Freeze predictions and all intermediates after 50/50 gold-free validation.
6. Then score and compute Step transitions against v3.4 and v3.20.
7. Accept only if Step Exact is `> 25/50`; complete the Goal only at `>= 30/50`
   with every legality and freeze check passing.
8. Otherwise reject immutably, audit every error, and continue from one new
   uniform mechanism.

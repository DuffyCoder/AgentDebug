# E9 v42 dry3 failure case study

## Outcome

v42 completed its frozen dry3 run with three valid raw diagnoses, but the
chronological census plus concise global Selector failed every semantic gate:

- Step Exact: 0/3 (gate requires 2/3);
- Step+Module Exact: 0/3 (gate requires 2/3);
- All Correct: 0/3 (gate requires 2/3);
- successful outputs: 3/3;
- failed outputs: 0/3;
- logical completions: exactly 2;
- HTTP attempts: exactly 2, with zero retries;
- provider tokens: 380,915 input, 23,264 output, 404,179 total.

The rejected promotion is bound by
`353bab3431cc4bd26b5977030f489a7c1bb32fbb970d8e8d2b6d80be7d27c3b7`.
v42 must not advance to full30 or held-out smoke.

## Case study

### C01: chronological local error displaced a valid boundary

The released root is step 30 `system/step_limit`, and the frozen anonymous
hypothesis contains that exact tuple. The v42 census instead emits step 9
`memory/hallucination` and step 16 `planning/inefficient_plan`. The Selector
adopts step 16 because returning from one countertop probe to cabinet 8 looks
like a weak search strategy.

This repeats the v32 failure. Every cabinet is a distinct unvisited state,
the action remains feasible, and no observation proves that cabinets cannot
contain the ladle. “A drawer might be better” is a hindsight improvement, not
a demonstrated taxonomy defect whose correction is sufficient for success.
The earliest-per-module instruction therefore preserves a speculative local
candidate and gives it too much causal force.

### C02: the correct hypothesis was present and rejected

The released root is step 1 `action/misalignment`, and the anonymous H01 item
contains that exact frozen tuple. The census adds step 3
`planning/constraint_ignorance` and step 4 `memory/over_simplification`. The
Selector chooses step 3, treating the initial dynamic GitHub search-page text
extraction as reasonable exploration.

The result is a selection-policy failure, not candidate recall failure. The
benchmark annotation treats the selected representation as the critical
action mismatch because it cannot supply the ordered, filtered issue set and
label-event history required by the plan. A concise generic causal prompt did
not preserve that contemporaneous capability evidence.

### C03: “earliest local error” is not the released critical boundary

The released root is step 13 `planning/inefficient_plan`. The census emits
only step 6 in that module, after several initial result pages, and the
Selector adopts it. The benchmark's released reasoning instead localizes a
later near-identical search/repetition boundary. The trajectory admits many
defensible pagination points; selecting the earliest locally questionable
continuation systematically moves before this released annotation.

This is both a recall and a selection failure. Collapsing each module to its
earliest local error cannot represent a later critical commitment when an
earlier inefficiency is real but not the benchmark's most important root.

## Attribution

There were no transport, JSON, taxonomy, evidence ownership, step mapping, or
length failures. The regression from v41's 1/3 to v42's 0/3 is semantic.

The v42 hypothesis is rejected for two reasons:

1. **Earliest-per-module is the wrong compression.** It replaces v41's
   strongest-only loss with the opposite loss. A critical root may be a
   terminal boundary, a later branch commitment, or an explicit task-closing
   error even when an earlier output is locally imperfect.
2. **A single generic global rule cannot reconstruct omitted alternatives.**
   The Selector receives one local error per module, so C03's later planning
   boundary is absent. Where the correct frozen hypothesis is present (C01
   and C02), the prompt still prefers a newly worded causal challenger.

Historical full30 evidence identifies a better candidate space. v40's
independent terminal-guard, first-defect, and owner lanes covered the released
step in 12/30 tuning cases, while its final Selector chose only 9 and one
additional gold-step tuple was lost solely to an explanation-length bound.
The next experiment should preserve those materially different causal lanes
rather than compressing by module.

## v43 falsifiable direction

v43 will replace the chronological module census with three independent,
fully structured LLM causal lanes:

1. `terminal_guard`: decide whether a real external boundary owns an
   otherwise coherent failure;
2. `first_defect`: find the earliest locally demonstrable important error;
3. `branch_commitment`: find the output that converts prior evidence or a
   recoverable detour into the unrecovered task-failing branch.

Each lane emits either null or a complete step, atomic taxonomy pair,
evidence source ID, and short causal basis. The frozen prior and all non-null
lanes are deduplicated and represented anonymously in the same schema. No
lane is called an incumbent, proposal, winner, score, confidence, weight,
vote, probability, or priority.

The independent raw Selector will compare local validity, recovery, causal
sufficiency, and the one-output counterfactual. In particular, an earlier
error does not win merely because it is earlier: if it is a recoverable detour
or correcting it still leaves an independently sufficient later commitment,
the later commitment may be the critical root. Conversely, a system boundary
survives when competing agent errors are only hindsight improvements over
valid novel coverage. The Selector may reject all supplied lanes and emit a
fresh diagnosis; its raw tuple remains the sole final semantics.

The hypothesis is accepted only if v43 reaches at least 2/3 on all dry gates
and then at least 12/30 Step Exact on full tuning. Any failure requires a new
case study before another provider call. No deterministic root selection,
semantic fallback, score, confidence, or answer repair is introduced.

# Experiment archive

Publication terminology follows the [method-family policy](../results/method-family-policy.md):
historical Codex agent/subagent execution belongs to the Codex SDK method family.
The original preregistrations and frozen result documents retain their as-run
wording and hashes; an old backend name is not a separate publication family.

This directory is the versioned research ledger. It contains preregistrations,
runtime reports, error audits, and rejected mechanism studies. These documents
explain how hypotheses were selected, but they are not the primary public
reproduction interface.

Use these entry points first:

- [Current frozen GAIA-50 leaderboard](../results/gaia50-leaderboard.md)
- [v3.83 reproduction guide](../../REPRODUCING.md)
- [v3.83 portable result bundle](../../artifacts/releases/gaia-v3p83/)
- [v3.81-v3.102 result ledger](gaia-current-goal-v3p81-v3p102-result-ledger-2026-08-30.md)

Rejected versions may supply post-score hypotheses but are not semantic
parents of later accepted versions. Frozen scored artifacts must not be edited
in place.

# GAIA v3.107 v3.83 Codex SDK bounded-retry preregistration

Date: 2026-08-31

Status: preregistered and unscored. This document does not claim a GAIA-50
inference result.

## Frozen identity and lineage

- Version:
  `agentdebug.codex-agent-judge.gaia-v3.107-v3p83-codex-sdk-bounded-retry-gpt55-medium`.
- Direct semantic parent: accepted v3.83,
  `agentdebug.codex-agent-judge.gaia-v3.83-clean-v3.20-model-only-gpt55-medium`,
  Step Exact `26/50`.
- v3.104 is an incomplete experimental transport run, not this version's
  semantic parent. No v3.104 prediction, case artifact, or partial result is
  read, resumed, repaired, copied, or merged into v3.107.
- The unchanged shared transport orchestration may be called as library code,
  but the v3.107 helper, stage adapter, runner identity, case-input root, and
  run directory are new and isolated.
- Semantic protocol: `gaia-v3.83-clean-v3.20-model-only-gpt55-medium`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Dataset identity SHA-256:
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort file SHA-256:
  `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Cohort identity SHA-256:
  `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction-manifest file SHA-256:
  `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Prediction-manifest identity SHA-256:
  `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`.
- Frozen v3.83 protocol source SHA-256:
  `a97908a78cec8df5fe9e4777d30aa9ecf498d1cdd1d692a42cc66976e9844531`.
- Frozen v3.83 wrapper-runner source SHA-256:
  `a1613a04ad21b3306c61cd3082753ff5890ad09ab3d939f4c292c15e1dac483d`.
- Shared three-stage runner source SHA-256:
  `a2e6e67de2175991d0231dfc3999f1d61b23f1404fea4100a05be2f536c2f9da`.
- Serial stage runner source SHA-256:
  `53ad4e60938bc2871da3c3a13165e987c4791a994b40b5a3adb29db02cd21660`.
- Model: `gpt-5.5`.
- Reasoning effort: `medium`.

## One falsifiable mechanism

The v3.104 runtime exposed transient third-party SDK failures while its
provider request and stream retry counts were frozen at zero. A later fresh
semantic attempt can produce a valid turn yet still omit a required stage
artifact, so spending the two-attempt semantic budget on transport faults is
not equivalent to recovering the same request or interrupted stream.

v3.107 changes only this harness mechanism:

- `model_providers.sophnet.request_max_retries = 2`;
- `model_providers.sophnet.stream_max_retries = 2`.

The [official Codex configuration reference](https://learn.chatgpt.com/docs/config-file/config-reference)
defines the first setting as the provider HTTP retry count and the second as
the SSE interruption retry count. In v3.107, both operate inside one fresh SDK
thread and turn. They do not increment the outer semantic-attempt number and
do not create an extra prompt, challenger, arbiter, or candidate decision.

The outer v3.83 bound remains exactly two fresh semantic attempts per stage.
Only when the entire first SDK turn fails to produce an artifact that passes
the frozen parent validator may the runner start semantic attempt 2 in a new
process and new ephemeral thread. The actual number of internal retries is not
exposed by the pinned SDK result, so v3.107 records the configured bounds but
does not claim an observed retry count.

This is a clean experiment from accepted v3.83. The observed v3.104 failure
pattern motivates the uniform mechanism, but no case identity, partial output,
historical prediction, or score enters inference.

## Frozen transport and isolation contract

- SDK package and bundled runtime: `openai-codex==0.147.0` and Codex CLI
  `0.147.0`.
- Additive requirements SHA-256:
  `f78c35e99b400eb802979d7756321dedcd09bc8c7c13756defccf737ddede9c5`.
- Frozen parent `uv.lock` SHA-256:
  `ac122fd9a87762dd20f491df918f8431907c5fe890dfcfc3a895e3e43f0569a2`.
- Provider: `sophnet`; fixed base URL `https://api.sophnet.com/v1`.
- Required native endpoint: `POST /v1/responses`; no Chat Completions,
  translation, fallback, or alternate provider is allowed.
- Each semantic attempt receives the generated v3.83 task byte-for-byte,
  starts a new helper process and ephemeral SDK thread, and uses deny-all
  approvals plus the frozen v3.83 full-access sandbox contract.
- The credential comes only from `SOPHNET_API_KEY`. Its value is excluded from
  model-run shell environments and from every CLI argument and artifact.
- Successful provenance stores token counters, duration, fresh thread/turn
  identifiers, retry-policy bounds, and a final-response hash, never final
  response text.
- Failed provenance stores only a stable layer/code and, for a third-party
  exception, a sanitized exception type. Raw SDK stderr and provider response
  bodies are discarded rather than persisted.

The exact source hashes for the new helper, stage adapter, runner, unchanged
shared orchestration, and strict JSON/redaction helper are generated into the
write-once runtime preregistration before a formal benchmark run.

## Mandatory capability preflight

Before opening or hashing either benchmark manifest, formal execution runs one
non-benchmark native Responses turn. It must prove the exact SDK version,
model, effort, endpoint family, fresh thread/turn identities, complete token
usage, secret-free provenance, and the two configured retry bounds.

Any failure aborts before GAIA-50 inference. v3.107 cannot fall back to Chat
Completions, another model, another provider, v3.104 partial artifacts, or a
different retry policy.

## Frozen GAIA-50 topology and validation

- Run all 50 cases with no smoke gate and no case router.
- Run three serial stages per accepted case: `packet-state-anchor`,
  `earliest-causal-challenger`, and `default-keep-arbiter`.
- Require `50 x 3 = 150` accepted fresh SDK sessions/threads.
- Maximum workers: `4`.
- Maximum fresh semantic attempts per stage: `2`.
- No label, gold rationale, metric, scored artifact, prior prediction, error
  report, or cross-case state is visible during inference.
- Later stages may receive upstream state only through frozen v3.83 artifacts.
- All frozen v3.83 schema, taxonomy, literal-evidence, order, checkpoint,
  challenger, arbiter, cohort, and manifest validators must pass.
- Exactly 50 merged predictions, with no missing, repaired, or stitched case,
  must be frozen and reverified before labels can be loaded.
- The transport run audit, safe failure classifications, credential-hygiene
  audit, and complete gold-free tree are part of the pre-score freeze.

## Decision rule

- Selection metric: Step Exact only.
- Accept v3.107 only if the complete legal GAIA-50 run has Step Exact
  `>26/50`.
- Complete the Goal only at Step Exact `>=30/50` with all legality and
  isolation checks passing.
- Step+Module, All Correct, module/type distributions, tokens, latency, and
  transport classifications are diagnostic only.
- A partial run, missing case, illegal artifact, failed preflight, credential
  leak, or post-freeze mutation is not a score.

## Preparation and formal invocation

Preparation is offline and does not make a provider request:

```bash
.venv/bin/python -m \
  scripts.run_agent_judge_gaia_v3_107_v3p83_codex_sdk_bounded_retry_gpt55_medium_paper50
```

After installing the separately pinned SDK dependency and injecting the
credential through the operator environment, formal execution is:

```bash
uv sync --frozen --extra dev
uv pip install --python .venv/bin/python -r requirements-v3p83-transports.txt
.venv/bin/python -m \
  scripts.run_agent_judge_gaia_v3_107_v3p83_codex_sdk_bounded_retry_gpt55_medium_paper50 \
  --execute --max-workers 4 --max-attempts 2
```

The credential value is intentionally absent from the repository and every
preregistration artifact.

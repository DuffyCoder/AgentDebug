# Luna v14 unified：tuning-v1 full-30 实验复盘

日期：2026-08-20

## 结论

`agentdebug.codex-agent-judge.luna-v14-unified-v1` 完成了完整、冻结的
`tuning-v1` 30 条实验，30/30 prediction 合法，所有 lineage、session、
implementation、prediction、secret 与评分边界 audit 均通过。官方结果为：

- Step Exact：**9/30（30.0%）**；
- Step+Module：**2/30（6.7%）**；
- All Correct：**1/25（4.0%）**；
- ALFWorld / GAIA / WebShop Step：**3/10 / 4/10 / 2/10**。

这是当前最好的合规 Luna `tuning-v1` 调优结果，但仍低于目标 12/30，不能晋升，
也不能表述为未知数据上的泛化准确率。

评分后逐例分析表明：

1. **候选召回是首要瓶颈。** 21 个 Step 错误中，18 个的 gold Step 没有出现在
   两个 locator candidate 中；只有 3 个是已经召回、但仲裁丢失。
2. **双候选的 Step oracle 是 12/30，仲裁为 9/12。** 只修三条已知仲裁错误的
   评分后反事实恰好是 12/30，但没有回归余量，不能直接当成下一轮可靠方案。
3. **候选严重塌缩到 Planning/Action。** 60 个候选槽中 Planning 33、Action 24，
   Memory、Reflection、System 各 1；而 gold 的 Memory/Reflection/System 共
   13/30。
4. **Step 与 owner 被错误地提前绑死。** 在 9 个 Step 正确样本中，Module 仅
   2/9 正确；有 gold type 的 8 条里 Type 仅 1/8 正确。v14 文案说仲裁后解析
   owner/type，实际 locator 选择 owner-bound atom 时已经冻结 owner，后续只剩
   type 可选。
5. **大多数错误是时间边界偏移。** 21 个 Step 错中 15 个偏晚、6 个偏早，
   中位 offset 为 `+1`，MAE 为 5.38；任一现有候选的 `±1` 覆盖 18/30，`±2`
   覆盖 23/30。这说明 locator 往往找到了正确失败链，却没有找到链上的官方
   critical boundary。

下一版不应只微调分类 prompt，也不应只加入三条评分后仲裁规则。更稳妥的方向是：

- 保留 evidence atom 的机械证据绑定；
- 增加统一的 state-fidelity locator，专门检查 Memory/Reflection 对前序事实与
  进展的保真度；
- 将候选从单点改成结构化 boundary bundle，显式比较 episode onset、成熟
  recommitment、相邻 observation 与 next interpretation；
- 用确定性重复计数和 epoch reset 代替模型自行判断“首次成熟”；
- 先冻结 Step/boundary，再从同一步的 owner atoms 中后置选择 Module，最后限制
  Type，避免 locator 的显眼 Plan/Action span 锁死 owner。

## 实验有效性与运行成本

本轮满足以下执行条件：

- 完整 frozen `tuning-v1`，30 条，环境分布 10/10/10；
- 固定 `gpt-5.6-luna`、reasoning effort `medium`；
- 30 个 accepted session 均为不同的 fresh ephemeral session，每个只诊断一条；
- 最大并发 4、单条最多 2 次、只重试失败 case；
- 共 32 次 session：28 条 attempt-1 成功，case 09 和 case 21 使用 attempt-2；
- 32 个全局 thread ID 唯一，30 个 accepted thread ID 唯一；
- model-visible tools 为 0，session tool call 为 0；
- 先完成 30 条 decision、parent validation、lineage/session/implementation/
  prediction/secret audit，再加载 gold 评分；
- 推理时不可见历史 prediction、proposal、case identity、gold 或评分文件；
- predictions、decision audit、frozen prompts、实现快照、metrics、per-example 和
  score artifact 均已持久化。

Token 使用：

| 项目 | 数量 |
|---|---:|
| input tokens | 2,348,681 |
| cached input tokens | 24,320 |
| output tokens | 38,833 |
| reasoning output tokens | 29,338 |
| accepted predictions | 30/30 |
| attempts | 32 |

相较 v13，v14 修复了 Code Mode host bootstrap 冲突，也用 evidence atom 消除了
自由复制长 quote 导致的大量 semantic-invalid output。本轮 30/30 合法，说明
运行时和证据完整性层已经不再是当前 Step 指标的 P0；剩余主问题是语义召回与
边界归属。

## 结果分解

### Step、Module、Type

Step exact cases 为：`02, 04, 07, 11, 12, 15, 20, 27, 30`。

其中只有 case 15 和 20 同时命中 Module，只有 case 15 All Correct。逐项看：

| Case | Gold owner | Pred owner | 说明 |
|---:|---|---|---|
| 02 | Reflection | Planning | 把固执的错误因果判断归成重复计划 |
| 04 | Memory | Action | 被 malformed action span 抢占 |
| 07 | Reflection | Planning | 把“pot 可替代 kettle”的进展误判归成约束计划 |
| 11 | Reflection | Planning | 把结果误读归成重复搜索 |
| 12 | Planning | Action | 把错误推理的最终表述归到 Action |
| 15 | Action | Action | owner 与 type 均正确 |
| 20 | Action | Action | owner 正确，type 从 misalignment 偏到 parameter error |
| 27 | Action | Planning | 把 plan 要求核验、action 却购买的冲突归给 plan |
| 30 | System | Planning | task/interface 冲突被同 step 的 Planning span 抢占 |

全量 owner 表面准确率是 15/30、type 是 7/25，但这两个数字具有误导性：21 个
Step 错例中有 13 个 owner 同名，主要来自在错误时间点重复预测 Planning；它们
不是正确 defect 的条件分类。真正有意义的是 Step 正确后的 2/9 owner 和 1/8
type。

### Candidate recall 与 arbitration

| 环境 | Top-2 Step recall | Final Step | Recall miss | Arbitration loss |
|---|---:|---:|---:|---:|
| ALFWorld | 4/10 | 3/10 | 6 | 1 |
| GAIA | 6/10 | 4/10 | 4 | 2 |
| WebShop | 2/10 | 2/10 | 8 | 0 |
| **总计** | **12/30** | **9/30** | **18** | **3** |

25/30 final decisions 选择了 `chronological` lane。三个已有 gold candidate 却
选错的 case 05、17、19，gold 全在 `local` lane。这里既有 chronological
命名/位置锚，也有 arbitration precedence 不正确：

- case 17：合法调用得到明确 429 的同一步外部边界，被更晚的重复搜索覆盖；
- case 19：S2 首次把未验证的 gold-plane 假设写进下一条 query，却被 S3 更显眼的
  unsupported conclusion 覆盖；
- case 05：S30 candidate 存在，但它只能表示为 Planning/repetition；输入没有
  typed `termination_reason=max_steps`，不能安全地产生 System/step_limit atom。

case 05 不能通过“30 步即 step limit”修复。当前 JudgeView 只有
`metadata_steps=30`、`canonical_turn_count=30`、`won=false`，没有 typed stop
reason 或 limit event。仅凭数值推断会把导出截断、普通未完成和真实环境上限混在
一起，也违反统一 System 证据边界。只有上游输入提供可审计的 typed termination
fact 时，才应生成 System/step_limit。

## 21 个 Step error 的逐例归因

缩写：C 为 chronological locator，L 为 local locator。这里的 gold 与错误分析
只在 prediction 冻结并完成全部 audit 后读取。

### ALFWorld

| Case | Gold | C / L candidates | Final | 错误类别 | 深层原因与通用修复 |
|---:|---|---|---|---|---|
| 01 | S3 Planning | S5 Action / S17 Planning | S17 | recall miss | S3 在尚未导航到 burner 2 时规划 examine，是 prerequisite/affordance 错误。模型被更显眼的 S5 plan-action mismatch 和 S17 constraint omission 吸引。需要 task/affordance locator，并把计划所依赖的当前可达状态作为结构关系检查。 |
| 03 | S1 Action | S2 Action / S18 Action | S2 | recall miss，疑似标注噪声 | 可见机械缺陷实际在 S2：额外引号后 observation 为 `Nothing happens`；S1 看起来成功。不能为一个无 rationale 的相邻标签强行把所有 Action 左移。应在报告中保留数据噪声，不编码个例规则。 |
| 05 | S30 System/step_limit | S16 Planning / S30 Planning | S16 | arbitration loss，但 gold owner 不可表达 | S30 已作为重复计划召回，System/step_limit 因缺 typed termination fact 不可生成。应修上游 execution provenance，而不是用轨迹长度当 label。 |
| 06 | S4 Planning | S5 Planning / S9 Planning | S5 | recall miss，`+1` | S4 首次从有效搜索转为无目标 `look`；locator 等 S5 收到后果才把它判成重复。boundary bundle 必须同时展示 decision、observation、next response，并允许把 symptom 回绑到前一决策。 |
| 08 | S5 Memory | S6 Planning / S20 Planning | S6 | recall miss，`+1` | S5 memory 忘记 S2 已执行 `look`，S6 只是消费错误状态的 plan。state-fidelity locator 应比较 memory 与完整历史 action/feedback，优先错误状态 owner。 |
| 09 | S4 Planning/impossible_action | S10 Planning / S12 Action | S12 | recall miss | 尚未找到或到达 desklamp 就规划 bowl-with-lamp 操作，必要对象/前提不成立。通用 affordance/prerequisite 检查可在重复成熟前召回。 |
| 10 | S4 Planning/inefficient_plan | S9 Planning / S14 Planning | S9 | recall miss | fridge 无 tomato 后，S4 首次投入低信息 cabinet brute force；模型直到多次重复才认为错误成熟。strategy epoch 应同时保留 onset 与 later maturity，不能把“首次成熟”简化成最早重复。 |

### GAIA

| Case | Gold | C / L candidates | Final | 错误类别 | 深层原因与通用修复 |
|---:|---|---|---|---|---|
| 13 | S1 Action/misalignment | S2 Action / S4 Action | S2 | recall miss，`+1` | S1 把动态 GitHub issues 搜索 URL 交给不适合的 extractor；S2 才出现参数格式问题。需要 tool/source capability 与 action target 的关系 atom，不能只检查 JSON 机械合法性。 |
| 14 | S3 Memory/over_simplification | S6 Planning / S7 Planning | S6 | recall miss | S3 memory 丢掉 PDF 提取损坏/不可用这一决定性事实，只保留“尝试过”。state-fidelity 应检查 material omission，而不只是显式矛盾。 |
| 16 | S6 Planning/inefficient_plan | S4 Planning / S28 Action | S4 | recall miss，`-2` | S2/S4/S6 三次相同站点提取；初次执行和一次确认应允许，S6 才是第三次成熟 recommitment。自然语言规则未能阻止模型把第二次 S4 判成熟，需代码按 tool/参数/observation hash 计数。 |
| 17 | S4 Reflection/outcome_misinterpretation | S8 Action / S4 System | S8 | arbitration loss | S4 的合法请求得到明确 429，同时同 step interpretation 把结果当成功；后续 S8 重复搜索不应覆盖独立 external failure。高精度 external boundary 应优于其后恢复尝试，除非已有更早 concrete agent defect。owner 仍需在 S4 后置解析为 Reflection，而非被 System atom锁死。 |
| 18 | S5 Planning/inefficient_plan | S7 Planning / S30 Action | S7 | recall miss，`+2` | 多轮无效 search/transcript 后，S5 又回到同类宽泛 community search；S7 只是更晚的间接 track-record route。failed-family-return 需要 operational channel/epoch 表示。 |
| 19 | S2 Planning/inefficient_plan | S3 Planning / S2 Planning | S3 | arbitration loss，`+1` | S2 在证据不足时把 gold-plane 假设固定到新 query，S3 unsupported conclusion 只是消费它。应增加 hypothesis-contamination/answer-conditioned-query basis，并明确 earlier unverified premise outranks downstream conclusion。此 case 在多轮历史实验中反复召回 S2 又反复丢失，是稳定 arbitration 缺陷。 |

### WebShop

| Case | Gold | C / L candidates | Final | 错误类别 | 深层原因与通用修复 |
|---:|---|---|---|---|---|
| 21 | S13 Planning/inefficient_plan | S4 Planning / S29 Planning | S4 | recall miss，`-9` | 第二个近似 query epoch 的分页停滞被混入全局 pagination epoch；模型过早选 S4。需要 query signature、result-set hash 与 epoch reset，而不是只看 `next` 操作。gold rationale 与具体 S13 action 也有轻微错位，不能硬编码 step。 |
| 22 | S6 Reflection/causal_misattribution | S7 Planning / S24 Memory | S7 | recall miss，`+1` | S6 错称上一动作是 Page1/Page2 导航并声称进展，实际上一动作是 refined search；S7 只是后续 plan。state-fidelity 应检查“上一动作/上一结果”的引用关系。 |
| 23 | S2 Memory/hallucination | S8 Action / S10 Action | S10 | recall miss | S2 未逐项检查便声称 50 个产品全部不满足，是 unsupported universal state claim。需要对 `none/all/no relevant results` 等全称结论要求逐项 observation 支撑。 |
| 24 | S21 Planning/inefficient_plan | S10 Planning / S30 Planning | S10 | recall miss，`-11` | 需要定位晚期 query epoch 的停滞；全局“首次分页重复”把边界提前到 S10。和 case 21 一样，应按 query/result epoch 而不是整个任务累计重复。gold rationale 与具体 S21 action存在一定映射噪声。 |
| 25 | S8 Planning/constraint_ignorance | S1 Planning / S12 Planning | S1 | recall miss，`-7` | S8 明知 dress-shirt/material 等要求仍点击 Henley，才是具体商品类别/约束违背；S1 的 query abstraction 尚未成熟为直接 root。task constraint 必须与具体 product/action 决策关联。 |
| 26 | S4 Planning | S6 Planning / S11 Action | S6 | recall miss，`+2` | 连续无关结果后 S4 继续分页而不 refine，是策略停滞 onset；S6 的 constraint omission 是后续更显眼文本。需要 onset/maturity bundle。 |
| 28 | S4 Memory/over_simplification | S2 Action / S3 Action | S2 | recall miss，`-2` | S4 memory 只保留初始/Page1 状态，遗漏最新 Page2 observation，随后错误回退。malformed action 只是包装表象；state-fidelity 需覆盖最新 observation omission。 |
| 29 | S2 Reflection/progress_misjudge | S4 Planning / S18 Reflection | S18 | recall miss，`+16` | Page1 已有可检查的 plausible Henley，S2 却断言没有相关结果并翻页。local locator 能在 S18 识别类似结果误读，却没有向最早同类 state claim 回溯。需要 state-claim family 的 earliest unsupported member。 |

## 当前架构的根本问题

### 1. Evidence atom 解决了完整性，没有解决召回

v14 的 atom ID 让 step/module/quote 绑定可验证，并把 30/30 输出恢复为合法；但
catalog 只是“哪些文字可由哪个 owner 引用”，不是“哪些 causal relation 值得
成为候选”。模型仍需在最多数百个 atom 中独立发现边界，结果 95% candidate
落在 Planning/Action。

### 2. Locator 与 owner 过早耦合

同一 step 往往同时含 Memory/Reflection、Plan、Action 和 observation。v14 locator
一旦选择 owner-bound atom，Step 和 Module 同时冻结；classification 只能在该
owner 的 type 列表中选择。于是模型用显眼 Action/Plan 找对 Step 后，无法再改为
Memory/Reflection/System。这直接解释 Step 正确后 7/9 owner 错。

### 3. “Earliest mature”被简化成 chronological sink

`chronological` lane 被选 25/30。模型把“更早”当成 causal predecessor，即使：

- 第二次调用仍是合理确认，并未成熟；
- 新 query/source 已打开新 epoch；
- earlier candidate 只是 generic inefficiency；
- later candidate 是更明确的 external boundary 或 state contradiction。

只在 prompt 里重复“chronology alone is insufficient”没有消除这个锚。

### 4. 单点候选无法表达时间归属

Memory/Reflection 错误需要 `previous observation → current interpretation`；
Planning/Action 错误需要 `current plan → current action → observation`；重复错误需要
`prior episode(s) → current recommitment → no-new-information`。单个 atom 只提供
一个文字片段，迫使模型用整条 timeline 自己重建关系，导致大量 `+1/-1` 或 epoch
错位。

### 5. 标注与输入存在不可忽略的边界噪声

21 个 error 中 7 个没有 gold rationale；ALF case 03 的可见失败更像 S2 而 gold
为 S1；WebShop cases 21/24 的 rationale 是重复 query，而映射 step 本身是 `next`；
case 05 的 step_limit 在输入里没有 typed termination。协议必须承认这些限制，
不能以 case-specific patch 追逐所有标签。

## v15 优化方向

### P0：增加分层召回，而不是第三个无结构泛化 locator

统一生成四类候选，每类使用同一协议、适用于全部 case：

1. **state-fidelity**：Memory/Reflection 是否与前序动作、observation、当前状态与
   任务进展一致；是否遗漏决定性新事实；是否无证据地产生 `none/all/success/
   complete` 等全称结论；
2. **task/affordance**：计划所需对象、位置、tool/source capability、task constraint
   是否在当前状态中成立；
3. **recurrence/strategy epoch**：按 canonical action/query/target/source 与
   observation hash 形成 episode；
4. **explicit System/terminal**：仅使用 typed、可观察、独立 external facts；绝不
   从 step 数字或普通失败推断 System。

每类最多保留少量候选，最后形成统一池。候选 ID 与展示顺序应中性，不能叫
chronological/local，也不能按时间或强弱排序暗示默认答案。

### P0：把单点 atom 升级为 boundary bundle

每个候选由 parent 机械携带：

- nominated decision/claim atom；
- 同一 episode 的 onset；
- 当前 maturity/recommitment；
- 前序 observation/action；
- 相邻 `S-1/S/S+1`，必要时 `±2` 的 owner atoms；
- recovery 或 new-epoch evidence。

模型选择 bundle 中真正的 critical boundary atom，Step 从它机械派生。评分后
上界显示 `±1` 已覆盖 18/30、`±2` 覆盖 23/30；但邻域必须按 causal relation
裁剪，不能把全量相邻 atom 无差别塞给 reviewer。

### P0：确定性 recurrence 和 epoch reset

- 初次执行与一次 evidence-motivated confirmation 不算 mature；
- 第三次 exact/equivalent operation 且两次先前 observation 均无新信息时，机械
  生成 maturity candidate；
- query、target、source、约束或 capability 真正变化时重置 epoch；
- 同时保留 onset 与 maturity，不由 locator 随意把第二次调用说成成熟；
- failed-family return 使用“同 information goal + 同 operational channel”，不能
  把 transcript、community discussion、direct page、database 混成一个 family。

### P0：Step/boundary 与 owner/type 解耦

建议 raw decision 的职责顺序为：

1. locators 选择 anchor/bundle；
2. boundary resolver 从受限 bundle 中选择 `boundary_text_id`，机械冻结 Step；
3. owner resolver 只可从该 Step 的 owner atoms 选择 `owner_atom_id`；
4. type 只可从该 owner atom 的 allowed types 选择。

最终 evidence quote 来自 owner atom，root cause/correction 来自冻结 boundary
predicate；classification 不能改变 Step。这样保留 v14 exact atom audit，又允许
同一步从 Plan/Action 表象回到 Memory/Reflection/System owner。

### P1：修正 arbitration precedence

两条可统一预注册、并有跨案例语义依据的规则：

- 后续结论或重复消费更早的未验证前提时，选择更早的 causal predecessor；
- 合法调用收到高精度、独立的 provider/environment error 时，它优于其后恢复或
  重复；只有更早 literal/interface/state defect 才能覆盖它。

case 19 与 case 17 分别是这两条的直接诊断例。case 05 不应作为第三条 gate，
因为其 typed step-limit evidence 缺失。

### 成功门槛与证伪条件

下一轮仍必须重新跑完整 frozen 30 条，不能用 v14 candidate oracle 或逐例反事实
代替正式结果。为了避免“恰好 12、无回归余量”，v15 的设计目标应是：

- candidate Step recall 至少 16/30，而不是仅从 12 保住 12；
- state-fidelity 至少产生非零 Memory/Reflection candidates，并显著超过 v14 的
  2/60；
- Step 已召回时的最终仲裁不低于 v14 的 75%；
- 30/30 legal，所有 exact atom、lineage、session、implementation、prediction 与
  gold-free audit 继续通过；
- 正式 Step Exact 至少 12/30 才可晋升。

若 candidate recall 提升而 final 不升，瓶颈转为 boundary arbitration；若 recall
仍不升，说明 bundle/state/epoch representation 没有真实补足语义覆盖；若 Step
提升但 owner 仍低，则验证 Step-owner 解耦需要独立加强。

## 已否定或暂不采用的方向

1. **只修 case 05/17/19 三个仲裁。** 评分后 oracle 恰好 12，没有任何回归余量；
   case 05 还缺合法 System evidence。
2. **只加第三个自由泛化 locator。** 当前问题不是候选数量本身，而是 95% 候选
   被 Planning/Action 占据；更多同质候选会扩大仲裁负担。
3. **一律左移一到两步。** 多数误差虽偏晚，但 6 个偏早，且 GAIA case 16、
   WebShop 21/24 需要向后移动；统一方向规则会修一类、破坏另一类。
4. **继续扩充自然语言 repetition 规则。** case 16 已证明“一次确认允许”写在
   prompt 中仍会被忽略；可机械计数的事实应由代码处理。
5. **从 `turn_count == 30` 推断 step limit。** 这会使用未被输入 provenance
   支持的 benchmark convention，并产生 System 假阳性。
6. **优先优化 type。** 当前目标是 Step Exact，且 Step 正确后 owner 只有 2/9；
   在 Step/owner 未稳定前，type prompt 微调不会解决主要损失。

## 权威产物

- 完整运行：
  `output/agenterrorbench-codex-gpt-5.6-luna-tuning-v1-agent-judge-luna-v14-unified-v1-case30/`
- 官方 metrics：`scored/metrics.json`
- 官方逐例结果：`scored/per_example.csv`
- 运行与审计摘要：`run-result.json`
- 冻结 predictions：`predictions.json`
- lineage audit：`lineage-audit.json`
- prediction audit：`prediction-audit.json`
- evidence-atom protocol：
  `agentdebug/diagnostics/agent_judge_luna_v14_unified.py`

本报告是同一已公开 `tuning-v1` cohort 上的评分后调优分析，不是 held-out、未知
数据或泛化能力报告；其中 candidate oracle、邻域覆盖和逐例修复均只用于定位
瓶颈，不能作为正式实验分数。

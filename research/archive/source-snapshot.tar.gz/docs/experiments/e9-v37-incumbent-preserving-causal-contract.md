# E9 v37 incumbent-preserving causal contract

## Change under test

v37 makes one attributable semantic-topology correction to v36. The final
Selector receives two explicitly untrusted LLM hypotheses: the fresh Candidate
proposal and the frozen v13 incumbent root. Both remain subordinate to the
complete trajectory. The Selector may accept either, synthesize another step,
or reject both and return a fresh diagnosis.

The prompt retains the original AgentDebug principles of module-local review,
backward causal tracing, earliest important error selection, and a one-error
counterfactual. It adds only two taxonomy-boundary clarifications:

1. An action may be misaligned even when it literally follows the plan if
   concrete interface or returned-result evidence shows that the selected
   operation or representation cannot expose an explicitly required fact.
   Speculation about a tool's capability is insufficient.
2. Novel search coverage is not yet an inefficient plan. Repeated search is
   eligible only at the first recommitment after contemporaneous evidence of
   no progress, exhausted coverage, or a substantially repeated ineffective
   policy.

## Semantic authority

The raw independent Selector output is still the sole final classifier. Code
only validates schema, taxonomy, step ownership, evidence-source identity, and
artifact lineage. It does not vote, rank, score, mutate, or fall back to either
hypothesis.

## Frozen execution topology

- v36 rejected dry3 anchor: cumulative 481 to 483, two calls
- v37 dry3: cumulative 483 to 485, at most two calls
- v37 full30 after an accepted dry3: cumulative 485 to 505, at most twenty
  new calls with the dry batch reused from cache
- held-out one-shot smoke after an accepted full30: cumulative 505 to 549, at
  most forty-four calls

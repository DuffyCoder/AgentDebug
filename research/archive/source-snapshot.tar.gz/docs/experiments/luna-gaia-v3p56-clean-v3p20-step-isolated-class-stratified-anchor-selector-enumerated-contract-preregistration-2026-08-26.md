# Luna GAIA v3.56 Enumerated Class-Selector Contract Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.56-clean-v3.20-step-isolated-class-stratified-anchor-selector-enumerated-contract`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: Luna v3.20, Step Exact `25/50`
- Original v3.4 baseline: Step Exact `21/50`
- Version acceptance: Step Exact `> 25/50`
- Goal completion: Step Exact `>= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact remains the sole optimization, comparison, acceptance, rejection,
and Goal-completion metric. Module/type/evidence are legality constraints only.

## Clean-parent and rejected-lineage boundary

v3.56 is a clean child of accepted v3.20. It does not read or reuse any v3.55
anchor, local record, matrix, selector, hidden state, prediction, or runtime
artifact. v3.55 is an incomplete, unscored rejected experiment: only `4`
anchors and `19` local records validated, no selector validated, and no final
prediction froze.

The same one unified class-stratified selector mechanism is reimplemented on
the clean v3.20 branch. v3.54's single proposal and duel remain absent. The
only correction relative to the unscored v3.55 preregistration is an executable
artifact contract: every allowed selector enum and both required relation
prefixes are written literally into the inference rules and JSON schema.

## Single major mechanism

Run a fresh prefix-bounded local taxonomy review for every Step, retain the
complete validated positive matrix, export at most one mature representative
for each of five generic boundary classes, and select exactly the fresh v3.20
anchor or one representative in one anchor-aware session. An override requires
literal anchor-veto evidence and a two-sided repair relation: anchor-only repair
must leave the representative independently failure-causing, while
representative-only repair must be capable of redirecting the failed path.

The frozen task explicitly enumerates:

- boundary classes: `state_truth`, `constraint_alignment`,
  `capability_commitment`, `post_feedback_recommitment`,
  `terminal_abandonment`;
- anchor classes: `critical_root`, `contributing_probe`,
  `normal_tool_failure`, `recovered_defect`, `noncritical_predecessor`,
  `faithful_propagation`, `downstream_symptom`, `uncertain`;
- decisions: `keep_anchor`, `select_representative`;
- the exact keep and select relation prefixes.

No Step admission, owner-source projection, taxonomy, anchor ledger/freeze,
candidate ranking rule, model, effort, or evidence validator is otherwise
changed.

## Expected gains and regression risks

The Step hypothesis remains the v3.54 post-score compression gap: gold already
survived in the local matrix for `10` errors discarded by single-proposal
compression, and two more proposal-present cases lost at the separate duel.
Keeping class representatives until one anchor-aware decision is intended to
recover a positive subset without the four false overrides observed in v3.54.

The incumbent-correct cases remain the primary regression set. Risks are
candidate flood, Planning salience, late-symptom preference, earliest-row bias,
and unsupported prose claiming independent criticality. Exact row-copy,
maximum-five class representatives, default keep, literal veto, contribution
witnesses, and the two-sided repair prefix are the uniform controls. The enum
correction itself has no expected Step gain; it only makes the selected
mechanism executable and falsifiable.

## Pre-registered falsifiers

- any local positive cannot become a legal exact-copy prediction; or
- local Step coverage is not exactly `717/717`; or
- a selector omits a positive row from its reviewed ledger, exports more than
  five or duplicate-class representatives, or selects a non-anchor/non-row
  prediction; or
- any selector emits an enum outside the now literal frozen lists; or
- direct selector gains are not strictly greater than selector losses; or
- final Step Exact is `<= 25/50`.

Mechanism diagnostics do not accept or reject the version independently.
Formal acceptance requires a legal frozen full-GAIA Step Exact `> 25/50`; Goal
completion requires `>= 30/50`.

## Execution and isolation

- 50 fresh v3.20 anchors + 717 fresh Step-local sessions + 50 fresh selectors
  = exactly `817` planned successful model sessions.
- Fresh one-case sessions, maximum concurrency `4`, maximum two attempts per
  stage, and no smoke gate.
- No rejected artifact, old prediction, case route, gold/label, metric, scored
  artifact, error report, case study, git history, or external resource is an
  inference input.
- All intermediate artifacts and final predictions must validate and freeze
  before scoring.

## Pre-inference implementation hashes

Frozen before the first v3.56 inference call:

- Protocol SHA-256: `dcc49a4bb3d1d1bb3b58496d60a5e882f4cf6eb50ed19b8eb2f7ba37b49382bb`
- Runner SHA-256: `ca98bc7d01e3631d4935e39fd1a5d9ca6745a6b14fddeca7dbd3775c569bc407`
- Registry SHA-256: `9473a179f440fd29df0f9d971a15153115d75480f09aff3902f046698e832046`
- Focused-test SHA-256: `178d428ded2f0dfe16d7c8b59a584c02c7804a8689933bf3396a277dfe099ff2`
- Focused v3.56 tests: `11 passed`, including direct replay of both frozen
  v3.55 invalid enum values and literal prompt coverage for every allowed enum
  and both relation prefixes.
- Cross-version v3.20/v3.52/v3.53/v3.54 tests: `23 passed` in isolated
  processes.
- Full-cohort dry-run: `50` cases, `717` legal Steps, exactly `817` planned
  successful sessions, concurrency capped at `4`.
- Static source scan: no rejected-version semantic import, case-specific
  Step/entity/source rule, inference-time score/label reader, or old-prediction
  input was found.

## Frozen execution and rejection outcome

The full GAIA-50 run completed and froze before scoring:

- 50/50 unique trajectories completed in cohort/manifest order;
- all `817/817` planned sessions completed on attempt 1; no retry or permanent
  failure occurred;
- schema, taxonomy, evidence ownership, Step range, exact-copy, and artifact
  validators passed for all 50 cases;
- the independent post-score access audit found no label, metric, scored
  artifact, prior prediction, error audit, git-history, or original-trace
  content read during inference;
- all four preregistered source hashes matched.

Frozen Step Exact is `22/50`. Relative to accepted v3.20 (`25/50`), the
transition is 19 both-correct, 3 v3.20-wrong/new-correct, 6
v3.20-correct/new-wrong, and 22 both-wrong, for net `-3`. The version is
therefore rejected and v3.20 remains the accepted incumbent.

The mechanism falsifier fired at the representative layer. The fresh anchor
was `21/50`; the full Step-local matrix contained gold Step in `36/50`, and
fresh-anchor union local coverage was `41/50`. The five-class maturity stage
retained gold as a representative in only `5/50`, reducing fresh-anchor union
representative coverage to `22/50`. The selector kept the anchor 48 times and
selected a representative twice, producing one direct gain, zero direct loss,
and one wrong-to-wrong change versus its own fresh anchor.

All 28 Step errors have frozen post-score facts and first-divergence diagnoses.
The primary distribution is 24 `anchor_error` and 4
`annotation_ambiguity`; downstream analysis contains 17 representative
maturity-gate losses and 7 Step-local recall losses. No scored artifact was
modified after freezing.

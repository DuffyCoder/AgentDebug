# E9 v32 dry3 failure case study

## Outcome

The frozen v32 dry3 run used one candidate call and one independent Selector
call with DeepSeek `deepseek-v4-flash` and the provider's default request body.
All three cases parsed successfully. Provider telemetry recorded 2 logical
completions, 2 HTTP attempts, and 0 retries.

The run failed the preregistered gate:

- Step Exact: 1/3 (required 2/3)
- Step+Module Exact: 1/3 (required 2/3)
- All Correct: 1/3 (required 2/3)
- valid predictions: 3/3

The failed promotion artifact is bound by
`e6e823261be996438be78f075fe4d3a46758de039b9c2a63dfee61639a02687c`.

## Case analysis

### C01: ALFworld, predicted step 16 instead of gold step 30

Gold is `30/system/step_limit`. The v32 candidate generator correctly kept
that root. It explicitly observed that step 30 opened a previously unvisited
cabinet and that neither the initial sink probe nor sequential cabinet search
was locally defective.

The Selector overrode the valid proposal with
`16/planning/inefficient_plan`. It interpreted the return from one countertop
probe to an unopened cabinet as a wasteful “reversion.” That conclusion is not
supported by contemporaneous capability evidence: cabinets remain admissible,
the selected cabinet was unvisited, and the trajectory never observes that a
ladle cannot be in a cabinet. A reflection calling the search inefficient does
not itself make subsequent novel coverage erroneous.

Root attribution: Selector terminal-boundary calibration failure. The prompt
contained a terminal-search guard, but competing prose about recognized
stagnation and first-defect selection let the model defeat that guard.

### C02: GAIA, exact

Candidate and Selector both chose `1/action/misalignment`, matching gold. The
generic URL text extractor was aimed at a dynamic GitHub issues-search page and
could not supply the required filtered, ordered issue collection. The later
answer used an unrelated open issue and was downstream.

### C03: WebShop, predicted step 2 instead of gold step 13

Gold is `13/planning/inefficient_plan`; candidate and Selector both chose
`2/planning/inefficient_plan`.

The prompt explicitly said that list-based product search can become
inefficient at the first plan that pages without opening product details. That
instruction created an early-root bias inconsistent with this benchmark case.
At step 2, a first pagination action is still ordinary acquisition. The
trajectory only establishes a mature ineffective policy after substantial
page coverage, a return to search, and renewed page traversal despite repeated
summaries that no relevant product was found. The official label localizes
that mature recommitment at step 13.

Root attribution: prompt-induced annotation-policy mismatch in both active
stages. v32 optimized for the earliest theoretically questionable commitment,
where AgentErrorBench in this case labels the first sufficiently evidenced
recommitment after repeated failure.

## v33 optimization direction

v33 remains fully LLM-semantic and adds no scores, confidence, weights,
deterministic findings, or semantic fallback. It changes only the causal
calibration instructions:

1. Novel admissible-state exploration remains valid even after one reflection
   calls progress slow or inefficient. A step-limit root must be retained
   unless the proposed local root repeats a known state/action, violates a
   literal constraint, uses an invalid action, or depends on an observed
   impossible prerequisite.
2. Pagination/list acquisition is not erroneous solely because detail fields
   are absent. Planning/inefficient_plan requires contemporaneous evidence of
   a mature ineffective policy: repeated coverage, explicit no-progress
   evidence, and a recommitment that fails to change strategy.
3. The Selector must directly rebut every condition of a valid system-boundary
   proposal before replacing it. A model-authored statement that search is
   “inefficient” is not external evidence.
4. Remove the v32 instruction that promotes list-only paging at its first
   occurrence. It was the direct cause of C03's early prediction.

No further LLM attempt is permitted until these changes, new regression tests,
the v32 artifact/usage anchor, a full test pass, and a new code bundle and
preregistration are complete.

# E9 v49 full30 Selector-cap preflight failure case study

## Closed attempt

- Experiment: `e9_v49_cross_module_consistency_selector_deepseek_v4_flash_default_body`
- Full30 preregistration content hash: `dd4d1619838a7dc4ce49aa0d8d3b1a80b23498fb5c14965b2da54a9d0f8e031e`
- Frozen budget: cumulative 570, at most 20 new logical completions, hard stop 590.
- Persisted prefix: 21/30 raw Selector predictions, all with `success` status. This is an incomplete prefix and is not a full30 score or promotion result.
- Provider use in this attempt: 15 logical completions, 15 HTTP attempts, zero retries; 2,635,854 input, 309,470 output, and 2,945,324 total tokens.
- Durable ledger shape: seven complete Critic/Selector pairs for batches 2--8, followed by the batch-9 Critic reservation and response. The accepted dry3 batch was reused from cache and is not charged again.
- Cumulative logical completions after the failed attempt: 585.

The batch-9 Critic completed successfully and its raw response, parsed response,
response sidecar, telemetry, and ledger reservation were persisted under request
hash `bc11e3d7f205027b6d4a64119aad3c2be776f49b883d0efb9fa07a8b751e1a7c`.
No batch-9 Selector ledger reservation or HTTP request was made.

## Exact failure boundary

Batch `B2d2ea021a2bf6ad7d0a3` contains:

- `Llama3.3-70B-Turbo_015_webshop_task_015`
- `Llama3.3-70B-Turbo_008_webshop_task_008`
- `GPT-4o_011_chat_b000_t00_e10-69d80a84`

The Critic response parsed successfully into candidate counts 5, 6, and 6.
Building the subsequent Selector messages also succeeded. Their exact serialized
message size was 802,251 characters. The workflow then compared that value with
the inherited static `MAXIMUM_REQUEST_CHARS = 800_000` limit and failed closed:

```text
BatchedCriticWorkflowError: v14 Selector request exceeds the frozen character cap
```

The overage was exactly 2,251 characters. The exception occurred in local
request construction, before the logical-completion ledger could reserve the
Selector call and before the provider transport ran. It is therefore neither a
DeepSeek failure nor malformed LLM output.

## Attribution

v49 broadened the candidate handoff in two intentional ways: it retained raw
Scout hypotheses and added a sixth `cross_module_consistency` Critic lane. The
static 800,000-character limit was inherited from the earlier four/five-lane
workflow and was not recalibrated against the largest v49 batch after raw
Critic output was available. Batch 9 combined three large judge views with 17
valid Critic hypotheses plus the frozen upstream candidates, pushing the
Selector request just beyond that historical bound.

The diagnostic hypothesis itself has not been falsified by this attempt. The
failure is an operational capacity mismatch in the local preflight gate. The
21 completed predictions must not be interpreted as a representative metric,
and the interrupted full30 attempt must not be resumed under changed code.

## Next falsifiable hypothesis: v50

The next attempt may occur only after this incomplete run is hash-bound, the
new code archive is frozen, tests pass, and a new dry3 preregistration is
written. v50 will make one operational change:

1. Introduce a Selector-specific request cap of 900,000 characters and use it
   only for the post-Critic Selector message preflight.

The Critic prompt, six causal lanes, Selector instructions, anonymous candidate
contents, strict evidence validation, and raw-LLM-only final semantic fields
will remain unchanged. There will still be no deterministic finding, fallback,
score, confidence, weight, vote, or semantic repair. Before an API call, all
frozen batch shapes will be checked locally against the new cap, including a
conservative maximum-candidate construction.

v50 starts from cumulative 585. It must first reproduce the accepted v49 dry3
gate using a fresh v50 stage cache (two logical completions, hard stop 587).
Only then may a newly preregistered full30 phase run (twenty logical
completions, hard stop 607). Any failed provider or benchmark attempt again
requires a completed case study and next hypothesis before another LLM call.

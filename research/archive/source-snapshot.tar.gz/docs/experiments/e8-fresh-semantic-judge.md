# E8: fresh benchmark-faithful semantic judge

Status before external calls: preregistration candidate.

## Frozen evidence and adaptive status

E8 is designed only from the frozen `tuning-v1` cohort. No `smoke-v1`
per-case artifact is inspected again during E8 development. A prior command
in this project did accidentally expose nested held-out metric rows, so the
eventual smoke result cannot be described as pristine human-blind. The gold
payload nevertheless remains isolated from every provider request, and this
hygiene incident must be disclosed in the final report.

The preceding E7 dry run used five logical completions and obtained:

- Step Exact `2/5`;
- Step+Module Exact `0/5`;
- All Correct `0/5`;
- hard failures `0/5`.

E7 therefore remains rejected by its frozen gate. Its five tuning outcomes
were used only to identify two prompt failure modes: premature error
localization and module ownership being classified after the step was frozen.
No E6 or E7 per-case root is an E8 provider input.

The cumulative logical-completion count before E8 is `312`. The user-authorized
cumulative ceiling is `380`.

## Falsifiable hypothesis

A single fresh LLM that reads the complete compact JudgeView, receives no
prior root or candidate ledger, and jointly decides
`(critical_step, module, error_type)` using error maturity and module ownership
will outperform the anchored E7 protocol.

The prompt distinguishes:

- an error locally demonstrated at the selected step from a merely
  suboptimal prefix exposed only by hindsight;
- accurate reflection from defective accumulated memory;
- a valid broad strategy followed by a semantically unsuitable concrete
  action;
- ordinary initial exploration from repetition that becomes demonstrably
  ineffective after feedback; and
- a real external boundary from an imagined shortcut that the trace never
  establishes.

The E8 LLM raw response is the sole semantic classifier. Deterministic code
may only enforce the five-field schema and taxonomy, map the selected step to
its event, validate a case-sensitive quote from the selected module's own
source span, perform at most one owner-source evidence-only repair with all
semantic fields frozen, verify lineage, and score after the unscored artifacts
are closed. The provider timeline replaces the benchmark-coupled trajectory
ID with `<anonymous>`; the real ID remains only in request/hash lineage.

There is no semantic retry, prior-root fallback, deterministic finding,
confidence, score, weight, vote, or rule-selected root.

## Frozen dry-5 selection

The dry subset is the same tuning-only diagnostic panel used by E7 and is
executed in PredictionManifest order:

1. `Qwen3-8B_024_id_24___chat_b013_t00_e01-5b8f974f`
2. `Llama3.3-70B-Turbo_015_memory_b001_t00_e06-71f77595`
3. `GPT-4o_011_memory_b001_t00_e03-21a3a421`
4. `GPT-4o_008_chat_b000_t00_e07-d50ae81f`
5. `GPT-4o_004_chat_b000_t00_e03-21a3a421`

The subset spans System, Action, Memory, Planning, and Reflection labels.
It is an adaptive tuning gate, not an unbiased performance estimate.

## Frozen dry gate

All conditions must hold:

- denominator `5`;
- five successful, strict-evidence-valid outputs and zero hard failures;
- Step Exact at least `3/5`;
- Step+Module Exact at least `3/5`;
- All Correct at least `2/5`;
- the Action control remains Step+Module exact;
- at least one Reflection/System case is Step exact;
- at least one Planning/Memory case is Step exact;
- every final root is reconstructed from the E8 raw response;
- any evidence repair changes no semantic field;
- logical-completion provenance equals five judges plus the mechanically
  eligible repairs.

If this gate fails, E8 is rejected and is not run on all 30 tuning cases.

## Frozen full-tuning gate

If dry-5 passes, run the unchanged E8 candidate on all 30 frozen
`tuning-v1` cases, reusing content-addressed dry caches. All conditions must
hold:

- Step Exact at least `12/30`;
- Step+Module Exact at least `3/30`;
- All Correct at least `3`;
- at least 29 successful predictions and at most one failed output;
- every successful root is evidence-valid and reconstructed from E8 raw;
- no deterministic fallback or semantic mutation.

Only a passing full-tuning run may be frozen for smoke.

## Held-out smoke protocol

Before smoke, freeze the E8 source bundle, prompt version, PredictionManifest,
provider configuration, paths, gate, and remaining call budget. Use a new
smoke cache namespace. Run all 30 smoke cases once; never run a partial smoke
cohort. Report the result whether it passes or fails.

The preregistration profile is itself hash-locked. `dry5` and `full30` require
the fixed `tuning-v1` cohort name and content hash; `smoke30` requires the
fixed `smoke-v1` name and content hash. Dry requires the five IDs above in
manifest order, while full and smoke require the complete 30-case manifest.
The held-out flag must agree with the profile and cannot be inferred from a
metric gate.

The core preregistration module, not only the CLI, requires the exact frozen
gate and GPT-4.1 provider configuration for each formal profile. It also
rebuilds every gold-free PredictionManifest entry from the frozen dataset
trace and public step mapping, including the canonical cohort selection
identity, before preregistration, immediately before calls, and at promotion.
Merely re-hashing an altered JudgeView cannot create an authorized input.

The promotion verifier reloads the preregistered dataset/cohort only after the
provider run, reconstructs every prompt/request/root/repair from the immutable
unscored chain, independently re-scores it, and requires exact equality with
the reported scored rows and metrics. Unknown or unimplemented gate fields
fail closed.

The primary success condition is Step Exact at least `12/30` (`40%`).
Step+Module, All Correct, evidence validity, and hard failures are secondary
diagnostic metrics.

## Provider and call-budget policy

- provider: OpenAI-compatible;
- endpoint: `https://api.sophnet.com/v1/chat/completions`;
- model: `gpt-4.1`;
- temperature: `0`;
- timeout: `600`;
- maximum output tokens: `8192`;
- maximum transport retries: `5`;
- retry backoff: `2`;
- workers: `1`;
- credential variable name: `API_KEY`.

One E8 judgment is issued per cache-miss case. A second logical completion is
allowed only for the mechanically eligible evidence-only repair.

Budget is allocated dynamically from a persistent logical-completion ledger:

1. dry-5 may use at most ten new logical completions;
2. before full tuning, reserve 30 completions for the base smoke judgments;
   therefore the full-tuning preregistration maximum is no greater than
   `350 - cumulative_before_full`;
3. full tuning requires at least 25 available completions because five dry
   judgments are cache hits; otherwise it does not start;
4. before smoke, the remaining budget must be at least 30; the smoke
   preregistration maximum is exactly `380 - cumulative_before_smoke`;
5. if an eligible repair would exceed a frozen stage budget, execution fails
   closed instead of issuing an unauthorized call or accepting invalid
   evidence.

The ledger is initialized by preregistration and binds the preregistration
hash, cumulative opening count, per-stage maximum, and authorized ceiling.
Immediately before each provider call, an exclusive file lock is acquired and
an immutable `(ordinal, stage, request_sha256)` reservation is durably written.
A reservation is never rolled back. If the process dies after reservation but
before the raw-response sidecar is written, a recovery attempt consumes a new
reservation; this conservatively avoids under-reporting in the unavoidable
non-idempotent provider window. Existing parsed, raw, or response-sidecar
artifacts are validated and recovered before any new reservation.

The three run-local ledgers are joined by a fixed, exclusive authorization
chain under
`output/agenterrorbench-gpt-4.1-e8-v3-authorization-chain`. Dry is the only
phase allowed to claim the `312` opening count and must reserve at least five
calls. Full can claim its phase only after an accepted dry promotion; smoke
can claim only after an accepted full promotion. Each successor recomputes its
opening count from the predecessor's durable ledger (never from telemetry),
requires the same code, prompt, and provider identity, and records the
predecessor promotion and claim hashes. Exclusive per-phase claim creation
prevents two output directories from consuming the same budget tranche.

Before full tuning is authorized, all five dry raw chains are reconstructed
from the exact same PredictionManifest, their request hashes must match the
current full-tuning requests, and their exact judge responses must remain
recoverable from the frozen shared-cache snapshot without a provider call.
Before held-out promotion, the multiset of every adopted judge/repair request
must exactly equal the multiset of durable reservations and every attempted
stage must be a cache miss. Thus neither a pre-existing cache entry nor an
entry injected after a crash can satisfy held-out promotion. This deliberately
means that a held-out run recovered from a response sidecar is reported but
cannot be promoted as a valid one-shot result.

Immediately before the first paid call, the verifier also re-hashes the entire
dataset directory and cohort manifest without parsing labels. On a resumed
run, it validates the same preregistration, ledger, output prefix, and raw
stage identities instead of incorrectly demanding that the directories remain
equal to their pre-run empty state. The prediction process reconstructs only
the gold-free manifest, unscored rows, predict-run metadata, ledger, and cache;
it neither parses the dataset nor opens predecessor scored predictions or
metrics. Those gold-derived artifacts are revalidated only by preregistration
or post-run promotion processes.

HTTP transport retries are recorded separately and do not count as logical
completions.

# GAIA v3.110 preregistration: decision-locked exact-copy closure

Status: preregistered and unscored before any v3.110 benchmark request.

## Frozen identity

- Dataset: frozen `gaia-paper-v1`, 50 cases; identity
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Semantic parent: frozen accepted
  `agentdebug.codex-agent-judge.gaia-v3.83-clean-v3.20-model-only-gpt55-medium`,
  Step Exact 26/50.
- Model: `gpt-5.5`, reasoning effort `medium`.
- Transport: direct stateless `POST https://api.sophnet.com/v1/responses`;
  no conversation or previous response ID.
- Geometry: 50 cases, serial anchor -> challenger -> arbiter within each case,
  four workers, at most five fresh semantic attempts per stage.
- No smoke gate, case routing, gold, labels, historical predictions, or failed
  model output is visible during inference.

Acceptance remains Step Exact >26/50 with 50/50 cases, 150/150 accepted stages,
all original v3.83 validators, secret hygiene, gold-free freeze, and post-freeze
reverification passing. Goal completion remains Step Exact >=30/50. Step Exact
is the only version-selection metric.

## Post-v3.109 evidence

v3.109 scheduled the complete cohort but closed only 46/50, so it was not
frozen or scored. Its four terminal failures were all output-legality defects:
two `invalid_embedded_prediction_fields`, one
`arbiter_selected_prediction_hash_mismatch`, and one
`no_challenge_must_not_propose`. All 185 recorded attempts preserved their
available Step-semantic locks. v3.109 artifacts are evidence for this
preregistration only and are not inputs to v3.110 inference.

## Single major change

Add one decision-preserving structural exact-copy closure to the v3.109
transport validator loop. It does not change the v3.83 prompt's critical-error
rules, candidate topology, challenger search, arbiter preference, or Step.

For an arbiter response, a provisional lock exists only when all outer
trajectory bindings, current-run anchor/challenger hashes, anchor Step,
decision, and challenger admission constraints are valid and the decision
uniquely identifies the current-run upstream prediction. The malformed selected
payload must then be either:

1. a singleton array whose member is the exact expected upstream prediction; or
2. a mapping with no extra fields, exact equality on trajectory ID, status,
   Step, module, type, and literal evidence, and at most one missing or changed
   non-selection field among trajectory SHA and the three explanation fields.

For the provisional path, the visible integer, `"N"`, or `"Step N"` frozen-Step
intent must equal the expected Step. Any disagreement in decision, Step,
module, type, evidence, status, outer hash, or more than one non-selection field
fails closed. The semantic lock contains the exact current-run upstream
prediction and its stable hash. A fresh request must return a complete envelope
with that prediction as one object, an exact hash, and an integer frozen Step.
The host never unwraps, fills, normalizes, or copies a model output field.

For an already locked `no_challenge`, the same mechanism may respond to
`no_challenge_must_not_propose` only by asking a fresh request to retain all
fixed fields and emit `anchor_veto_evidence_step`,
`anchor_veto_evidence_quote`, and `proposed_prediction` as present JSON nulls.

The allowlist also includes the downstream exact-copy validator codes
`arbiter_anchor_copy_mismatch` and `arbiter_challenger_copy_mismatch`; they are
repairable only under the same exact upstream decision lock. Unknown codes,
missing locks, lock drift, malformed outer bindings, and ambiguous selected
payloads terminate the case.

## Required audits

Every attempt records request/response hashes, resolved model, usage, latency,
HTTP attempts, materialized-envelope hash, validator code, cumulative feedback,
and semantic lock. Before scoring, the run verifier must recompute all locks and
feedback hashes from disk, prove every accepted artifact is an exact model
envelope, require 50/50 cases and 150/150 accepted stages, scan for the API key,
and freeze the entire gold-free tree. Labels may be loaded only after that
freeze succeeds.

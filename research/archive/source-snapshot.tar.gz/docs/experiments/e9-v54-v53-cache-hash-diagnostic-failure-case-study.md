# E9 v54 historical-cache hash diagnostic failure case study

## Failure and attribution

A read-only command successfully hashed the v53 run artifacts and case-study
files, but its final `find | xargs sha256sum` segment passed paths relative to
the cache directory while `sha256sum` still ran from the repository root.
Consequently, the six individual cache-file lookups failed. No file was
created, changed, or removed, and no provider call occurred.

## Correction

Use AgentDebug's existing deterministic `_directory_state` calculation on the
absolute cache path. Bind that single authoritative file-count/content digest
in the v54 historical anchor instead of reconstructing it with ad-hoc shell
path handling.

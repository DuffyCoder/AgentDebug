# Official-v3 AgentErrorBench transport recovery64 preregistration

This post-hoc, reporting-only recovery shard follows an external transport
failure in the unscored rest150 run.  It is not represented as the original
single-run preregistered result.

Before any new model call, the incomplete parent tree is frozen by SHA-256
`a22f72660082ad720c6359c6e4fce3be87205e0ced2823f8cf168689db95d5cd`
(49,621 files).  Selection uses only absence of a case-level `prediction.json`:
86 cases have predictions and the complementary 64 IDs have identity hash
`e00b9389cddae9fbe939edd998af96f2d64da99c3c142d28c3198c771bd3e7fc`.
No prediction value, label, metric, or scored artifact participates in the
selection.

Every selected case is rerun from the beginning of public Phase 1.  No parent
Phase-1 response is reused.  The public source, prompt topology, native
taxonomy bridge, GPT-5.5 medium model, Codex SDK 0.147 ChatGPT transport,
concurrency four, and maximum three same-prompt transport attempts are
unchanged.  The shard contains 64 cases, 1,920 Steps, exactly 7,552 successful
Phase-1 calls, and at least 64 public Phase-2 calls.  There is no outer
semantic resampling.

The shard remains gold-free and unscored.  Only after 64/64 predictions pass
the existing official-v3 validator and its complete tree freezes may a
separate deterministic composer merge the frozen original 86 and recovery 64
in the original rest150 order.  That composer must validate 150/150 before its
first gold read and must report the result as an 86+64 recovery composite.

# E9 v53 targeted-test contract failure case study

## Failed attempt

The first v53 targeted local run executed 157 tests across the candidate
judge, workflow, preregistration, and CLI suites. It completed with 155 passes
and two failures. No provider or external LLM call occurred.

## Attribution

Both failures are stale test-contract expectations introduced by the intended
v53 change:

1. The prompt test searched for the exact old phrase `Do not choose the final
   root`, while the new prompt says `Do not choose a final root in this call`.
   Both prohibit candidate-stage root selection; the mismatch is textual.
2. The preregistration test still expected the historical dry3 Step gate of
   2/3. The v52 semantic case study deliberately strengthened v53 dry3 to 3/3
   because both v51 and v52 already reached 2/3 while missing the same
   planning trajectory. The production gate correctly returned 3; the stale
   assertion incorrectly expected 2.

Neither failure concerns lane parsing, source ownership, taxonomy validation,
candidate limits, raw Selector authority, budget arithmetic, gold isolation,
or provider behavior.

## Correction and next check

Make the candidate prompt use the unambiguous exact sentence `Do not choose
the final root in this call`, and update the dry gate test to require 3/3 for
Step, Step+Module, and All Correct. Then rerun the same four targeted suites.
The hypothesis is that all 157 tests pass without weakening either production
contract. No LLM call is allowed until this local correction passes.

# E9-v16 DeepSeek V4 Flash Exact Retry

E9-v16 is one independent retry of the E9-v15 dry3 request. It keeps the
model, endpoint, temperature, non-thinking mode, prompt protocol, three-case
batch, frozen v13 predecessor, and all semantic gates unchanged. Only the
pipeline/experiment identity, cache namespace, code archive, authorization
chain, and output paths change so the rejected E9-v15 response cannot be a
cache hit.

The purpose is narrowly preregistered: determine whether DeepSeek V4 Flash
again emits an extra closing brace at every case boundary under the identical
effective prompt. No deterministic repair or parser relaxation is permitted.

E9-v15 consumed one logical completion from cumulative 363 to 364. This retry
may consume exactly one completion, from 364 to 365. A future full tuning run
would start at 365 and add ten new Critic calls; a fresh three-stage smoke run
would start at 375 and require 33 calls, reaching the implementation ceiling
of 408. The user's current ceiling of 380 authorizes this retry and tuning full,
but not smoke.

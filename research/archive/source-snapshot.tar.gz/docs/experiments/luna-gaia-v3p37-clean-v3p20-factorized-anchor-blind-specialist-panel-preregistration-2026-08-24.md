# Luna GAIA v3.37 Clean v3.20 Factorized Anchor-Blind Specialist Panel Preregistration

## Frozen identity and decision rule

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.37-clean-v3.20-factorized-anchor-blind-specialist-panel`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Single major change: one factorized candidate-recall panel with two
  anchor-blind, mutually exclusive specialist lanes and one bounded exact-copy
  selector over the clean anchor plus at most two frozen candidates.
- Accepted incumbent: Luna v3.20, Step Exact `25/50`.
- Version acceptance: Step Exact `>25/50`.
- Goal completion: Step Exact `>=30/50` plus all legality checks.
- Original frozen baseline: Luna v3.4, Step Exact `21/50`.
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases.
- Dataset manifest SHA-256:
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort semantic SHA-256:
  `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Cohort file SHA-256:
  `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Prediction-manifest file SHA-256:
  `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Model / reasoning effort: `gpt-5.6-luna` / `medium`.
- No smoke gate; complete GAIA-50 follows offline validation directly.

Step Exact is the only optimization, comparison, acceptance, rejection, and
completion metric. Module/type/evidence remain legality constraints only.

## Frozen v3.36 evidence and first divergence

Frozen v3.36 completed 50/50 with 150 attempts, zero retries, all legality
checks, and Step Exact `22/50`; it is rejected and immutable. Relative to v3.20
it had two gains and five losses, net `-3`. The clean anchor scored `21/50`.
The maturity challenger emitted exactly one proposal; it was one direct gain
with no direct regression. Forty-nine no-challenge decisions left 28 errors.

All errors are audited. First-divergence distribution:

- false candidate admission: 12;
- candidate recall failure: 7;
- annotation ambiguity: 4;
- early freeze failure: 3;
- late symptom preference: 1;
- missing recovery or veto: 1.

The v3.36 hypothesis failed because a single anchor-visible session had to
simultaneously prove owner, immediate predicate, maturity witness, causal
independence, and superiority over the anchor. The conjunction preserved one
high-confidence handoff gain but suppressed nearly all recall. Earlier
dual-anchor evidence also showed that replicas of the same prompt are highly
correlated. The next falsifiable intervention is therefore factorization by
evidence class before any anchor comparison, not another stronger conjunctive
gate and not another same-prompt replica.

## Single uniform mechanism

The v3.20 anchor prompt, packet-state ledger, Step freeze, model, and reasoning
effort remain unchanged. Two specialist lanes run together in one fresh,
anchor-blind session:

1. `state_handoff` lane: inspect every Step only for literal necessary-fact
   loss/distortion, unsupported retained entity/value/relation, false
   outcome/progress reading, or immediate plan-to-Action target loss that feeds
   the current or next decision. Emit at most the earliest qualifying complete
   prediction, otherwise `none`.
2. `strategy_capability` lane: inspect every Step only for intrinsic
   task-predicate incapability, explicit constraint/source mismatch, or the
   first Agent-owned post-feedback recommitment to the same normalized route.
   Raw tool failure cannot own a candidate; useful first probes and materially
   different routes are vetoed. Emit at most the earliest qualifying complete
   prediction, otherwise `none`.
3. The two lanes are mutually exclusive and cannot nominate the same Step.
   Neither sees the anchor, historical predictions, IDs, gold, or scores.
4. A fresh selector sees only the exact clean-v3.20 anchor bundle and the two
   frozen specialist outputs. It may select exactly one existing prediction:
   anchor, state candidate, or strategy candidate. It cannot invent, repair,
   merge, or splice a third prediction.
5. Literal chronology and causal ownership govern selection. A state candidate
   wins only when its concrete handoff defect feeds the later path. A strategy
   candidate wins only when the anchor is a probe/noncritical predecessor or a
   downstream symptom and the candidate is the first mature Agent commitment.
   Direct unrecovered execution impact or an explicit critical constraint
   protects the anchor. Uncertainty keeps the anchor.

This is a clean v3.20 branch. No v3.21-v3.36 semantic prompt, validator,
prediction, audit, score, case ID, entity, or result enters runtime. Structural
artifact/runner helpers may be reused only after the rejected semantic rule is
fully replaced.

## Falsifiable gains and regression risks

The factorization targets seven current candidate-recall errors plus false
anchor admissions where a later mature strategy boundary never entered the
single challenger. It predicts materially more specialist candidates than
v3.36 while bounding the panel to two. Candidate generation alone is not
success: the selector must convert coverage into Step gains.

Main regression risks:

- the state lane promotes harmless compression or an unused local
  inconsistency over an incumbent-correct root;
- the strategy lane promotes an initial/different probe or raw normal failure;
- the selector prefers a specialist because it is earlier, later, or more
  explicit rather than causally critical;
- two lanes create a small but still noisy candidate set.

Controls are concrete necessary-fact consumption, Agent ownership, first-probe
and normal-failure vetoes, post-feedback maturity, same-Step mutual exclusion,
maximum three total predictions including anchor, exact-copy selection, and
default keep.

The hypothesis is falsified if the panel exceeds two candidates, sees the
anchor, produces overlapping lanes, the selector invents a prediction, legality
fails, or complete Step Exact is `<=25/50`.

## Execution and freeze contract

1. Implement only the factorized anchor-blind panel, exact-copy selector,
   validators, runner registration, and negative tests over frozen v3.20.
2. Verify anchor text is identical to v3.20 modulo version identity and runtime
   sources contain no rejected prompt, gold, historical prediction, or routing.
3. Use three fresh serial sessions per case: v3.20 anchor, anchor-blind two-lane
   panel, bounded selector; at most four cases run concurrently.
4. Run no smoke gate. Execute all 50 after prepare-only validation.
5. Freeze and validate all hashes, order, schema, taxonomy, literal evidence,
   candidate bounds, anchor blindness, exact copies, no routing, and no
   prior/gold access before scoring.
6. Compute Step transitions relative to frozen v3.20 and v3.4.
7. Reject immutably at `<=25/50`; accept at `26-29/50`; complete only at
   `>=30/50` with every legality check passing.

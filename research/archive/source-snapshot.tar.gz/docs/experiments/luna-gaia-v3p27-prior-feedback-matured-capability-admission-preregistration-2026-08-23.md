# Luna GAIA v3.27 Prior-Feedback-Matured Capability Admission Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.27-prior-feedback-matured-capability-admission`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia.v3.26-same-step-consumer-witnessed-state-ledger`
- Semantic anchor parent: `agentdebug.codex-agent-judge.luna-gaia.v3.20-packet-state-closure`
- Frozen incumbent: v3.20, Step Exact `25/50`
- Original v3.4 baseline: Step Exact `21/50`
- Version acceptance: `Step Exact > 25/50`
- Goal completion: `Step Exact >= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Frozen v3.26 predictions SHA-256: `aae944220d5aa07dc9c5aec53fab90d34592879caec06c4449027b2e56f14f36`
- v3.26 Step-error audit SHA-256: `2a3068f2d9adbc3a54c95bb30cedacdbde6258cc685c93a9cb8b707ef0e73281`
- v3.26 cluster audit SHA-256: `dfce18c970b923547b614035d949540bbc0849a3e248a5d19258fd4769f57a95`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the only optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module/type/evidence remain legality constraints only.

## Post-score diagnosis motivating this version

v3.26 completed 50/50 at `19/50`; all legality/freeze checks passed. Its
consumer-witness mechanism produced 14 candidate rows but zero earlier
candidates. The complete 31-error audit identifies ten acquisition capability
false positives, nine High-confidence and one Medium-confidence, as the largest
actionable cluster.

These cases freeze an initial or still-informative external acquisition route
because it cannot directly prove a final video-frame, dynamic-UI, database, or
full-text predicate. Their released boundary occurs only after literal feedback
has exposed the limitation and Planning recommits to the same unavailable
assumption, or at a later independent false-success boundary.

v3.18 is not reused. Its `possible|observed` contribution rule vetoed 190/220
rows and scored `22/50`: hypothetical contribution remained a permanent
exemption and caused global later drift. The new contract is temporal and
narrow: protection ends as soon as prior feedback directly establishes the
exact limitation.

## Single major change

Add one validator-enforced capability-maturity prefix to every v3.20 anchor
ledger row:

```text
capability_maturity=<not_applicable|unobserved|observed>;
prior_limitation_step=<none|positive integer>;
```

Rules:

1. `not_applicable/none` covers rows whose Lane-B decision is not an
   interface/corpus capability claim. Existing state, parameter, System, and
   strategy rules remain unchanged.
2. `unobserved/none` means no feedback strictly before the current Step has
   directly shown that the exact chosen interface/corpus cannot expose the
   acquisition predicate or a necessary intermediate.
3. An `unobserved` interface/corpus capability claim is a binding Lane-B veto:
   use initial-probe or different-probe veto and continue chronological scan.
4. `observed/N` requires `N < current Step` and literal earlier feedback showing
   the same interface/corpus limitation. The current Step's own adjacent result
   does not count as prior evidence.
5. After `observed`, a Planning/Action recommitment to the same unavailable
   evidence path may be admitted under existing Lane-B rules; observation does
   not force admission if a different route or other veto applies.
6. The v3.26 state challenger, three closed state pairs, consumer witnesses,
   earliest candidate, one proposal, and default-keep arbiter remain unchanged.

No permanent possible-contribution exemption, case router, entity/site rule,
historical prediction, gold information, candidate pool, result splice, or
module/type optimization is added.

## Falsifiable prediction

- Every anchor row has a valid maturity prefix.
- `observed` rows name a strictly earlier Step; `unobserved` rows name none.
- No interface/corpus Lane-B candidate is admitted with `unobserved` maturity.
- At least one of the ten audited acquisition false positives moves later after
  an initial probe veto.
- Mature recommitments remain representable rather than permanently exempt.
- Gains exceed regressions relative to v3.20 and Step Exact exceeds `25/50`.

The hypothesis is falsified if the prefix does not fire, if anchors merely move
to arbitrary late symptoms, if mature recommitments are still exempt, if the
four direct early-capability counterexamples dominate regressions, or if Step
Exact is `<= 25/50`.

## Gain and regression analysis

Expected gain coverage is the ten-case acquisition false-positive cluster:
first static-page/video probes, first static-page/dynamic-UI discovery probes,
first alternate academic/document routes, and a recoverable mechanical URL
construction predecessor. Their average prediction-minus-gold delta is strongly
negative, so the mechanism intentionally makes selection later only after
feedback maturity.

Four incumbent-correct cases are direct counterexamples: their published gold
marks an early interface/corpus mismatch before repeated feedback. Those cases
may regress under a strict maturity rule. The preregistered expected ceiling is
therefore roughly ten gains minus four regressions; no case-specific exception
is allowed. State challenger false overrides are an additional risk, bounded by
the unchanged one-proposal and default-keep contracts.

Compared with v3.18, this rule does not label all possibly useful routes and
does not preserve their exemption after failure. Candidate flooding should fall;
late drift remains the central falsifier.

## Execution and acceptance protocol

1. Implement the versioned prompt, maturity-prefix validator, runner, and
   negative tests.
2. Run offline tests, prepare-only GAIA-50, and source scans; no smoke gate.
3. Execute all 50 frozen cases with three fresh sessions per case and at most
   four cases concurrently.
4. Freeze predictions and intermediates only after 50/50 gold-free validation.
5. Only then score all 50 and compute transitions against v3.4, v3.20, and
   v3.26.
6. Accept only if Step Exact is `> 25/50`; complete the Goal only at `>= 30/50`
   with every legality/freeze check passing.
7. Otherwise reject immutably, audit every Step error, and continue from one
   new uniform mechanism.

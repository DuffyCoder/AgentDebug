# GAIA v3.91 GPT-5.5 file-inspected predicate-handoff tournament preregistration

Date: 2026-08-29

## Frozen identity

- Version: `agentdebug.codex-agent-judge.gaia-v3.91-gpt55-file-inspected-predicate-handoff-tournament`.
- Direct semantic parent: accepted v3.83, Step Exact `26/50`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Dataset manifest identity SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort identity SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Cohort manifest file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Frozen v3.83 protocol SHA-256: `a97908a78cec8df5fe9e4777d30aa9ecf498d1cdd1d692a42cc66976e9844531`.
- Frozen v3.83 predictions SHA-256: `f74161b06c456461ccacdcf7c708157154e8e9810cb5dffa8ef09352698fca3d`.
- Model and reasoning effort: `gpt-5.5` / `medium` for both stages.

## Prior evidence

The semantic motivation is unchanged from v3.90: v3.87-v3.89 repaired zero
frozen v3.83 errors through their direct mechanisms, while historical v3.80 is
the only tested candidate mechanism with an anchor-plus-ledger Step oracle above
the Goal threshold (`31/50`). Its final selector was imprecise (`17/50`), so the
falsifiable question is whether GPT-5.5 can use that complete tournament more
precisely.

v3.90 attempted the clean GPT-5.5 port with a fully embedded owner-explicit
JudgeView. It completed and locally validated 49/50 cases, but one 804,287-byte
anchor prompt exceeded the current Codex GPT-5.5 endpoint's 272,000-token model
catalog limit. Three byte-identical attempts failed before emitting a response,
including one with the official `model_context_window` override. v3.90 is
runtime-incomplete and unscored; none of its predictions are inputs here.

## Single semantic change and uniform transport repair

The only semantic change from accepted v3.83 is still:

- retain its GPT-5.5 packet-state anchor and native chronological ledger;
- replace the one-proposal challenger/default-keep arbiter tail with one
  outcome-conditioned exact-predicate handoff tournament over every native
  ledger Step;
- select exactly one anchor-or-prefix winner and freeze an exact copy;
- permit only Step-invariant deterministic legality materialization.

To make that mechanism runnable uniformly, the exact lossless owner-explicit
JudgeView is staged in every stage directory instead of embedded in the initial
prompt. The model may inspect it only through a frozen helper with five bounded
commands: task metadata, five-Step timeline pages, exact Step, exact owner, and
exact feedback. Every stage must inspect task metadata and cover every timeline
Step. Post-inference audit rejects any other command, command chaining, parent
path read, web/MCP call, missing timeline page, or inconsistent runtime contract.
This transport is identical for all 50 cases and contains no case router.

## Falsifiable hypothesis and regression risk

The tournament should expose incumbent-error gold Steps already present in the
native prefix ledger, while GPT-5.5 may avoid v3.80's early-probe overpromotion.
The principal regression remains systematic early movement: an informative
acquisition failure may be called a mature handoff simply because later Steps
continue the same evidence gap. File inspection also introduces a new risk that
the model uses timeline previews without drilling into exact evidence; literal
owner validation and command audit are intended to falsify that failure.

The version is rejected if final Step Exact is `<=26/50`, if gains are offset by
early-probe regressions, if any of 50 cases is incomplete, or if any legality or
access audit fails. Candidate oracle and mechanism-direct transitions are
post-score diagnostics only.

## Acceptance and Goal completion

- Accept only if Step Exact is strictly greater than `26/50` and every legality check passes.
- Complete the Goal only if Step Exact is at least `30/50` and every legality check passes.
- Only Step Exact selects, accepts, rejects, or completes versions.
- No smoke gate is used; after offline validation run the complete GAIA-50 directly.

## Pre-inference freeze

- Protocol source SHA-256: `09762192392f0c922f35ad9f838f0ebf900e31c5b98f561ec2b0adfafa6c8657`.
- Runner source SHA-256: `22e2116d07c7c29c40c8c0a74d428555ab147dee18af601c41567a3bd25032bb`.
- Inspector source SHA-256: `556e8fe1e77186a55521f74734b05d35a33fe482a50d30b5bc21ce7ef02f7677`.
- Negative/identity test source SHA-256: `d1a851338d730b6e5c33bb5dc449be910fc38a1376f75e89337019ac02fbff3c`.
- Frozen tuning plan SHA-256: `adb883db5a307c55d16298336a922ffb9589b8afafa4bdfa10d6b0be5ee115b9`.
- Offline validation: compilation passed; 13 targeted and inherited tests
  passed; registry, direct-parent identity, long-case prompt externalization,
  inspector output bounds, command allowlist negatives, Step-invariant legality,
  and 50-case dry preparation passed.
- Static inference-source scan found no labels, metrics, scored artifacts,
  historical predictions, case/entity router, or post-score audit reader.


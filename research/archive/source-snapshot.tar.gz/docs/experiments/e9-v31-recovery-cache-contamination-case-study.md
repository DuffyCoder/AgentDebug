# E9-v31 recovery cache contamination case study

## Discovery

The v56 freeze suite completed 550 tests but failed two existing v31
preregistration tests. Both failures reported that the authoritative incomplete
v31 cache bytes had changed.

## Root cause

The one-call v31 recovery correctly used a separate run directory and a
separate recovery ledger, but incorrectly persisted the missing batch-11
response into v31's original Critic cache. That cache is an immutable part of
the interrupted-at-27-rows source attempt. Its topology changed from the bound
30 files (10 stage responses) to 33 files (11 responses), invalidating the
repository's incomplete-run anchor.

This is an artifact-isolation defect in the recovery implementation, not a v56
diagnostic failure. The recovered response and score are still available, but
the source crash scene must be restored before any new external call.

## Correction

1. Copy the complete 33-file cache to a new, explicitly named v31 recovery
   cache.
2. Move only the three batch-11 stage files (raw, response sidecar, parsed)
   out of the original cache, restoring its exact 30-file hash-locked state.
3. Preserve the moved files in a recovery backup; no response is deleted.
4. Update the v31 recovery utility so future offline finalization distinguishes
   immutable source cache from disjoint recovery cache.
5. Re-run the full suite before freezing v56.

The v56 reviewer continues to start from the frozen v30 incumbent and does not
consume v31 cache artifacts.

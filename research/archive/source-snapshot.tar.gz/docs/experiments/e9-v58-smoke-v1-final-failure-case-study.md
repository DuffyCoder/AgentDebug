# E9 v58 smoke-v1 final failure case study

## Audited result

The frozen v58 heldout smoke-v1 run completed through conservative recovery
v3. All raw stages and 30 unscored rows were validated before the first gold
access. The final ledger has 43 logical calls: 22 fresh Scout/Arbiter calls,
11 fresh v30 Critic calls, and 10 v58 Reviewer calls. Batch 3's three cases
were retained as invalid predictions because no complete valid incumbent table
existed; no Reviewer was called for that batch.

Final metrics:

- Step Exact: **8/30 (26.67%)**;
- Step+Module Exact: **3/30 (10.00%)**;
- All Correct: **3/27 (11.11%)**;
- successful predictions: 27/30;
- invalid predictions: 3/30, all `missing_valid_incumbent`.

The preregistered goal of Step Exact >= 12/30 was not achieved. Even granting
all three invalid rows impossible perfect credit would produce only 11/30, so
the missing-incumbent batch is not the sole explanation.

## Incumbent versus Reviewer

For the 27 cases with a valid fresh v30 incumbent, the v58 Reviewer emitted 27
`keep` verdicts and zero `replace` verdicts. Consequently:

- fresh v30 incumbent Step Exact: 8/30;
- final v58 Step Exact: 8/30;
- Reviewer gains: 0;
- Reviewer regressions: 0.

The tuning-v1 improvement from v30's 10/30 to v58's 12/30 did not generalize
as an active correction behavior. On smoke-v1, v58 reduced exactly to v30.

The fenced batch-3 Critic response was inspected only for failure attribution,
not scoring or repair. Removing its outer Markdown fence would expose two
valid case roots and one evidence-ownership failure. Of those roots, only C01's
step 30 matches gold; C02 and C03 remain step-wrong. Even such an inadmissible
post-hoc repair would raise Step Exact only to 9/30.

## Semantic error pattern

Among the 27 non-invalid predictions:

- 8 selected the exact gold step;
- 12 selected a later step;
- 7 selected an earlier step.

The direction differs by environment:

- GAIA: 7 later, 3 exact. The judge often selects a terminal action/format
  symptom rather than the earlier planning/reflection cause.
- WebShop: 5 earlier, 3 later, 2 exact. The judge often promotes an early
  generic planning criticism over the later annotated critical breakdown.
- ALFWorld: 3 exact, 2 earlier, 2 later, 3 invalid.

Module ownership remains weak. Only 3 of the 8 step-exact predictions also
matched the module. The system performs especially poorly on the benchmark's
six `inefficient_plan` cases (0/6 Step Exact), despite that category being a
major target of the v30 Critic prompt. Source-agent results also vary sharply:
Qwen3-8B traces score 6/13, GPT-4o traces 2/11, and Llama3.3-70B traces 0/6.

These patterns show that one global “earliest causally relevant error” rule is
under-calibrated across environments. It over-backtracks on WebShop and
under-backtracks on GAIA. The copy-review constraint cannot correct this when
the incumbent itself is wrong and the Reviewer defaults universally to KEEP.

## Optimization conclusion

The smoke-v1 labels are now exposed through scoring and this case study. They
must not be used to tune another challenger while continuing to describe
smoke-v1 as heldout. The development incumbent remains v58 because its
tuning-v1 Step Exact is 12/30; the heldout result rejects the claim that this
reaches 40% out of sample.

A clean next experiment must return to non-smoke development data and test a
falsifiable semantic change, such as environment-conditioned causal-depth
instructions or a genuinely independent open-ended final judge. It then needs
a new untouched evaluation cohort drawn from release trajectories unused by
tuning-v1 or smoke-v1. Re-running v58 variants against smoke-v1 can be done
only after explicitly reclassifying smoke-v1 as development data; its score
would no longer be an unbiased heldout result.

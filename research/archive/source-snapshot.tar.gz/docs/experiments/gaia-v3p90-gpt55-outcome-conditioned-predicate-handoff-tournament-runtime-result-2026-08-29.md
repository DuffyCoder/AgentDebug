# GAIA v3.90 runtime result

Date: 2026-08-29

## Decision

v3.90 is runtime-incomplete and cannot be scored or accepted. It is frozen as
an experimental/rejected run, not an accepted incumbent. v3.83 remains the
accepted semantic parent at Step Exact `26/50`.

## Frozen execution facts

- 49/50 cases completed both semantic stages and local validators.
- Case 17 failed before producing an anchor response.
- Anchor attempts 1 and 2 used the frozen v3.90 task and both returned the same
  Codex context-window error.
- Recovery attempt 3 used a byte-identical task (SHA-256
  `dd4788f60e61a381689677854d0f534ed507826e16d5c5636a1eb77884b79dc1`),
  the same `gpt-5.5` / `medium`, and only an explicit
  `model_context_window=1050000` CLI override. The Codex execution endpoint
  still returned the same context-window error.
- No merged predictions, gold-free freeze, or score was produced. Partial 49
  predictions are not used for version selection.

## Root cause and next uniform repair

The case-17 embedded owner-explicit task is 804,287 bytes, while the local
Codex model catalog exposes GPT-5.5 with a 272,000-token maximum even though
the OpenAI API model documentation lists a 1,050,000-token model window. The
CLI override cannot enlarge the current Codex endpoint's catalog limit.

The next version must remain a clean child of accepted v3.83 and preserve the
single predicate-handoff tournament mechanism, but uniformly transport the
same owner-explicit JudgeView through a staged, audited read-only inspector
instead of embedding the entire document in the initial prompt. This must be
applied to all 50 cases; case-specific truncation or routing is forbidden.


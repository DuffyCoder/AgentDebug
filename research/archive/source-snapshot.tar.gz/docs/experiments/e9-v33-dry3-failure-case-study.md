# E9 v33 dry3 failure case study

## Outcome

The frozen v33 dry3 run used one Candidate call and one independent Selector
call with DeepSeek `deepseek-v4-flash` and the provider's default request body.
All three cases parsed successfully. Provider telemetry recorded exactly 2
logical completions, 2 HTTP attempts, 0 retries, 382,242 input tokens, and
26,205 output tokens.

The run failed the preregistered gate:

- Step Exact: 1/3 (required 2/3)
- Step+Module Exact: 1/3 (required 2/3)
- All Correct: 1/3 (required 2/3)
- valid predictions: 3/3

The failed promotion artifact is bound by
`d630393a375c16bbee6e53e8699286a2be6810f858b3b0e711232c85a2ba0de0`.

## Case analysis

### C01: ALFworld, corrected to exact step 30

Gold is `30/system/step_limit`. Candidate and Selector both selected the exact
tuple. They treated the sink/countertop probes and sequential unvisited
cabinets as novel admissible coverage and found no repeated known state,
invalid action, ignored literal constraint, or observed impossible
prerequisite. This validates v33's system-boundary rebuttal. The v32 failure at
step 16 did not recur.

### C02: GAIA, regressed from exact step 1 to step 4

Gold is `1/action/misalignment`. The official annotation says the error is
using `url_text_extractor` on a GitHub issues-search URL. The Candidate reached
that exact result: the plan requires a filtered and ordered issue collection
plus a label-event timestamp, while a generic text extractor over a dynamic
collection page cannot expose that representation.

The Selector overrode it with `4/planning/constraint_ignorance`. It applied the
v33 caution that poor search results alone do not prove misalignment, but it
mistook an observable interface-capability mismatch for an ordinary poor
result. Step 4 is a real downstream error—the plan substitutes issue creation
date for label-addition date—but correcting step 1 changes the failed branch
before that downstream error occurs.

Root attribution: Selector capability-contract calibration failure. The
reasonable-probe exception is too broad. A result can be unknown while the
operation is still observably incapable from the declared interface and the
fact representation required by the plan.

### C03: WebShop, moved from step 2 to step 8 but gold is step 13

Gold is `13/planning/inefficient_plan`; Candidate and Selector chose
`8/planning/inefficient_plan`. v33 fixed the v32 first-pagination bias, but it
carried all no-progress evidence from the first search directly into the
reworded query at step 8. It therefore treated the query change itself as the
first mature ineffective recommitment.

The raw timeline gives a more precise maturity boundary. Step 8 starts a new
query epoch and returns to page 1. Steps 9 through 12 traverse new pages under
that query. At step 13, the current observation is page 5 of 50 total results,
the compact history says pages 1 through 6 have already been visited with no
relevant products, and the plan still chooses another page. This is the first
later plan where near-exhausted current-query coverage, explicit no progress,
and a continued list-only strategy are simultaneously visible.

There is also a benchmark-label inconsistency that must be recorded rather
than hidden. The official reasoning says the plan produced a search almost
identical to the initial one, but the actual near-identical search action is
at step 8 (and again at step 15), while step 13 is a pagination plan. The
frozen benchmark nevertheless defines step 13 as gold, so evaluation must
report exact agreement against step 13 while analysis separately flags this
annotation/timeline mismatch.

Root attribution: cross-query evidence leakage plus an AgentErrorBench
annotation-policy mismatch. v33 correctly delayed past initial pagination but
did not reset the maturity audit when a new query epoch began.

## v34 optimization direction

v34 remains entirely LLM-semantic. It adds no confidence, scores, weights,
votes, deterministic findings, semantic repair, or fallback labels. It changes
only Candidate and Selector instructions:

1. Separate poor outcomes from observable operation/representation mismatch.
   If a plan needs a structured filtered/ordered collection or event history,
   and the declared action interface can only extract static page text, the
   capability defect is observable at that action even before the result.
2. Treat a changed search query as a new evidence epoch. Prior-query
   pagination can motivate the change but cannot by itself make the new query
   action erroneous.
3. For a paged catalog, localize inefficient planning only when the current
   query's own displayed total, page coverage, and contemporaneous no-progress
   evidence show near-exhaustion and the plan still continues the same
   list-only strategy instead of making a meaningful strategy change.
4. Preserve v33's system-boundary rebuttal unchanged, because it fixed C01.

No further LLM attempt is permitted until these changes, regression tests, the
v33 artifact/usage anchor, a full test pass, and a new code bundle and
preregistration are complete.

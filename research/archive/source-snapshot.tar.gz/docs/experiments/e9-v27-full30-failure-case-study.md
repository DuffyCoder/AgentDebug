# E9 v27 full30 failure case study

## Outcome

v27 passed dry3 at 2/3, but its frozen full30 tuning run failed the promotion
gate:

- Step Exact: 9/30 (30.00%; gate requires 12/30)
- Step+Module Exact: 3/30 (10.00%; gate requires 2/30)
- All Correct: 3/25 (12.00%; gate requires 3/25)
- Successful outputs: 27/30 (gate requires at least 29)
- Failed outputs: 3/30 (gate permits at most 1)
- New logical completions: 10
- HTTP attempts: 10, with zero retries

The environment Step Exact breakdown was ALFWorld 3/10, GAIA 5/10, and
WebShop 1/10. Held-out smoke must not run from v27.

## Transport and format attribution

Ten of eleven batches were structurally valid. The remaining three-case GAIA
batch returned non-empty text beginning and ending like a completed response,
but each case omitted the closing brace of its nested `review` object. The
payload had seven opening braces and four closing braces. It was not a simple
trailing extra brace and contained no independently valid strict JSON suffix,
so the existing conservative repairs correctly rejected it as
`malformed_json`.

The failed payload still visibly contained final fields. In particular, its
third case selected step 2/action, which would have matched that case's
released Step label. Code must not salvage those semantics from malformed
JSON after the fact, but the observation shows that the nested output schema
costs at least one Step match. The next protocol should flatten the review
checkpoint fields into each case object, eliminating the three repeatedly
missed nested closes without changing or repairing semantic values.

## Semantic attribution

Relative to v25, v27 gained three exact steps and lost four:

- It gained two GAIA cases that v25 lost to empty final content, plus one
  WebShop case.
- It lost one ALFWorld case and two WebShop cases by postponing the root far
  into a repetitive trajectory, plus the structurally invalid GAIA case.

Among successful v27 rows, only 9 were exact while 15 were later than gold
and 3 were earlier. The new "critical later recommitment" rule over-corrected
the earlier-root bias: repeated malformed actions were pushed from step 5 to
28, and WebShop roots previously exact at steps 1 or 2 moved to steps 12 or
18. Official labels do not consistently select the most mature repetition.
The v25 local-error rule was the stronger base (10/30 despite two empty
outputs).

## v28 optimization direction

Before another model attempt:

1. Restore v25's earliest *actual* local-error selection, including its
   protection for reasonable first probes and its explicit terminal step-limit
   exception. Do not restore v26's upstream-owner audit.
2. Remove v27's environment-specific rule that prefers a later mature
   recommitment. A later event wins only when the earlier event was not yet
   erroneous, not merely because more evidence has accumulated.
3. Flatten `incumbent_verdict`, `earlier_candidate_step`,
   `later_recovery_step`, and `causal_basis` into the per-case JSON object.
   Keep the same LLM review, raw-only final tuple, strict exact fields, and no
   semantic fallback.
4. Retain Flash's default request body and the transport-only strict JSON
   suffix recovery. Never expose free-form reasoning.
5. Run v28 dry3, then full30 only after an accepted dry. A further failure
   again requires a case study before another attempt.

No v27 artifact may be mutated, structurally repaired, or rescored under the
v28 parser.

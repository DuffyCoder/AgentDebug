# E9 v28 dry3 failure case study

## Outcome

v28 removed the nested-review format defect but failed the semantic dry gate:

- Step Exact: 1/3 (33.33%; gate requires 2/3)
- Step+Module Exact: 1/3
- All Correct: 1/3
- Successful outputs: 3/3
- New logical completions: 1
- HTTP attempts: 1, with zero retries

No v28 full30 or held-out smoke run is permitted.

## Format result

All three flat case objects parsed without repair. The evidence IDs, atomic
taxonomy pairs, step ownership, raw-chain reconstruction, gold isolation, and
telemetry gates passed. This validates the flat-review change: the v27
missing-inner-brace failure mode is absent, and no deterministic semantic
repair or prior fallback was introduced.

## Semantic attribution

- GAIA remained correct at step 1/action.
- WebShop selected step 8/planning instead of released step 13/planning. This
  is closer to v25's local-error behavior than v27's step 20, but it is still
  not exact.
- ALFWorld selected step 16/planning instead of the released terminal
  step-30/system label. The model treated a brief move from cabinets to a
  countertop and then back to new cabinets as proof of a harmful repetitive
  plan. However, every late action still inspected a previously unvisited,
  admissible location. The prompt already says slow exhaustive exploration
  does not retroactively invalidate a plan, but that protection was too weak
  against the model's narrative of "recommitment."

The dry failure is prompt-level terminal-boundary drift, not output format,
transport, validation, or scoring.

## v29 optimization direction

Before another model attempt:

1. Retain the v28 flat output schema and v25 earliest-actual-error baseline.
2. Strengthen the terminal search guard: if the task fails only because of an
   enforced step limit and the late actions continue visiting new admissible
   states, coverage order alone is not planning/inefficient_plan. This remains
   true even if an earlier reflection called progress slow or briefly tried a
   different location. Select system/step_limit unless the candidate plan
   repeats a known state, emits an invalid action, ignores a literal task
   constraint, or has a directly observed impossible prerequisite.
3. Do not add a deterministic ALFWorld rule or inspect gold during prediction;
   the LLM must still emit the complete raw final tuple.
4. Keep Flash's default API request and exact one-call dry budget.

No v28 artifact may be mutated or rescored under the v29 parser.

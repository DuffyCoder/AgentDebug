# E9 v48 dry3 failure case study

## Closed attempt

- Experiment: `e9_v48_scout_broadened_handoff_selector_deepseek_v4_flash_default_body`
- Preregistration content hash: `c66b18cb82c7499b181673583c93769bf9a94d5653248e2c719da403a92d2b77`
- Predict-run content hash: `8574b0ad019864e4c92653cfe0b87a7b7a916620cecf2cc962ed66467c49b7a2`
- Unscored prediction file hash: `ff1c6d65956a78f14b281aced9f01d3c534d5b140ef55c3d0d8ebb162f3f7344`
- Promotion content hash: `5965fdc56d820a8f411d8084b56da70f34ce313ae0bf333154f23a92d27909f3`
- Provider use: two logical completions, two HTTP attempts, zero retries; 383,052 input, 30,478 output, and 413,530 total tokens.
- Output validity: 3/3 successful raw Selector outputs; semantic mutation count zero.
- Result: Step Exact 1/3, Step+Module Exact 1/3, All Correct 1/3. The preregistered 2/3 dry gate rejected the experiment.

The CLI's nonzero `verify-gate` result is the intended fail-closed signal for
an `accepted=false` promotion document, not an artifact-integrity failure.
Every non-semantic integrity, raw-final, cache-miss, telemetry, and budget
check passed. Only the three semantic minimum gates failed.

## Case analysis

### C01: correct boundary retained

Gold and prediction are both step 30 `system/step_limit`. The Selector rejects
unsupported early search preferences and preserves the real terminal boundary.
Scout broadening does not destabilize this case.

### C02: the correct early capability root was exposed twice but rejected

Gold is step 1 `action/misalignment`; v48 predicts step 3
`planning/constraint_ignorance`.

Both the frozen Arbiter prior and raw Scout independently supplied the exact
gold tuple at step 1. Their evidence identifies the initial
`url_text_extractor` call over a GitHub search-results page: that returned
representation cannot expose the required label-addition history and does not
establish the closed/Regression/numpy.polynomial constraints. The Selector
nevertheless called this a "valid initial search attempt" and chose the later
plan that committed to issue #9533.

Attribution: candidate recall is sufficient; final causal comparison is not.
The current `PERSISTENT_INFORMATION_ROOT` wording is still too easy to bypass
by relabeling a structurally incapable acquisition as harmless exploration.
The task required a historical field from the outset, and no later step ever
reacquired it. A capable step-1 acquisition would prevent the observed branch,
so the earliest locally valid root should win over the downstream commitment.

### C03: an invalid lane discarded the candidate case, then the Selector chose two steps late

Gold is step 13 `planning/inefficient_plan`; v48 predicts step 15
`planning/inefficient_plan`.

The Critic emitted useful hypotheses for steps 6, 9, and 30, but its
`state_summary_loss` lane paired a step-16 memory hypothesis with an evidence
source owned by a different step/module. The strict validator correctly
reported `invalid_evidence_source_ownership`. Because isolation is currently
case-local rather than lane-local, that one malformed lane removed every
Critic hypothesis for C03 from the Selector input. Scout supplied only step 1
and terminal step 30 alternatives.

The Selector still recognized a mature repeated-result epoch, but selected the
third query reset at step 15. It missed the decisive contemporaneous
contradiction at step 13: memory states that pages 1 through 6 were already
visited, the current observation is Page 5, yet planning says Page 6 is
unexplored and clicks next. That plan repeats known coverage and is exactly the
official step-13 planning failure. Step 15 is only a later continuation.

Attribution: this miss combines candidate transport loss with an underspecified
within-step state-consistency rule. The v48 repeated-epoch rule distinguishes
query starts from mature checkpoints, but it does not explicitly prioritize a
plan that contradicts its own same-step memory and the current page ledger.

## Next falsifiable hypothesis: v49

The next dry attempt may occur only after a new code archive and preregistration
are frozen. It will keep the raw LLM Selector as the sole source of final
semantic fields and make three bounded changes:

1. Add an independent `cross_module_consistency` Critic lane. It audits the
   same-step memory/reflection/plan/action dependency chain and emits the first
   plan or action that contradicts already stated coverage or state. When
   memory says pages 1--6 were visited but planning calls Page 6 unexplored,
   ownership stays with that planning output.
2. Apply `REQUIRED_FIELD_ACQUISITION` before downstream-commitment comparison.
   An initial operation is not harmless exploration when the same-step plan
   explicitly requires a field that the selected interface or returned
   representation cannot expose and the trajectory never reacquires it.
3. Isolate Critic validation per independent lane. A malformed lane remains
   rejected and contributes no hypothesis, while other strictly valid raw LLM
   lanes for that case remain available. This is validation/projection only:
   it does not synthesize, repair, score, rank, vote, or select semantics.

The Selector will also apply `WITHIN_STEP_STATE_CONTRADICTION` before the
general mature-epoch rule, selecting the first dependent plan that explicitly
contradicts its contemporaneous coverage ledger rather than a later reset.

The v49 dry success criterion remains the frozen 2/3 minimum for Step Exact,
Step+Module Exact, and All Correct, with 3/3 valid outputs and zero semantic
mutation. If it fails, another case study is required before any further LLM
call.

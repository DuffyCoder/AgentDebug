# GAIA v3.93 GPT-5.5 audited no-bwrap predicate-handoff tournament preregistration

Date: 2026-08-29

## Frozen identity

- Version: `agentdebug.codex-agent-judge.gaia-v3.93-gpt55-audited-no-bwrap-predicate-handoff-tournament`.
- Direct semantic parent: accepted v3.83, Step Exact `26/50`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Dataset manifest identity SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort identity SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Cohort manifest file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Frozen v3.83 protocol SHA-256: `a97908a78cec8df5fe9e4777d30aa9ecf498d1cdd1d692a42cc66976e9844531`.
- Frozen v3.83 predictions SHA-256: `f74161b06c456461ccacdcf7c708157154e8e9810cb5dffa8ef09352698fca3d`.
- Model and reasoning effort: `gpt-5.5` / `medium` for both stages.

## Prior evidence and first divergence

The semantic hypothesis remains the clean-v3.83 outcome-conditioned
predicate-handoff tournament. Historical v3.80 supplied a native-ledger Step
oracle of `31/50`, above the Goal threshold, but its selector was only `17/50`.
v3.90 could not embed the longest JudgeView within the local endpoint context
limit. v3.91 and v3.92 externalized the JudgeView, but the local `read-only`
Codex sandbox failed before every inspector command with a bwrap loopback
permission error. v3.92 emitted schema-valid output for `50/50` cases, yet its
pre-score access audit found zero successful inspector commands and missing task
and timeline coverage in all 100 stages. It was therefore frozen as an unscored
`runtime_or_validation_failure`.

A gold-free diagnostic using no benchmark files ran exactly one `pwd` command
under `danger-full-access`; the command completed with exit code zero and was
recorded in the JSONL event stream. This falsifies a general command-execution
failure and isolates the defect to the bwrap transport.

## One semantic mechanism and one transport correction

Relative to accepted v3.83, the only semantic mechanism is:

- preserve the GPT-5.5 packet-state anchor and native chronological ledger;
- replace the one-proposal challenger/default-keep arbiter with one
  outcome-conditioned exact-predicate handoff tournament over every native
  ledger Step;
- select exactly one anchor-or-prefix winner and freeze an exact copy.

The singleton and same-Step evidence contracts are Step-invariant legality
conditions: a one-row ledger has no alternative Step and must keep the anchor;
evidence materialization may repair only the owner payload at the already
selected Step.

The sole runtime correction from v3.92 is to execute the staged inspector with
the bwrap sandbox disabled. Each case remains in a fresh attempt working
directory. Before labels are read, the access audit must reject the complete
version if any model stage:

- executes a command outside the exact `task`, bounded `timeline`, exact `step`,
  exact `owner`, or exact `feedback` inspector allowlist;
- uses web, MCP, image generation, command chaining, parent-path reads, or any
  other tool;
- has a nonzero/missing command exit code;
- omits task inspection or complete timeline coverage;
- violates the truthful runtime contract.

Thus host access is technically broad only to bypass a broken local sandbox;
accepted semantic access remains narrower than the prior embedded prompt and is
fully falsifiable from the event log. No rejected prediction is reused.

## Impact analysis

Expected gains are limited to incumbent errors whose needed boundary already
appears in the native prefix ledger. The main Step regression risk is systematic
early movement: informative acquisition probes can be mistaken for mature
predicate handoffs when later Steps inherit the same missing evidence. Long
ledgers may also induce candidate flooding or shallow preview-based comparison.
Complete timeline inspection, exact owner evidence, strict non-singleton winner
constraints, and exact-copy freeze are the counterchecks.

Reject the version if Step Exact is `<=26/50`, if gains are offset by early
regressions, if any case or stage is incomplete, or if any legality/access audit
fails. Candidate oracle and per-case transitions are post-score diagnostics
only.

## Acceptance and Goal completion

- Accept only if Step Exact is strictly greater than `26/50` and every legality check passes.
- Complete the Goal only if Step Exact is at least `30/50` and every legality check passes.
- Only Step Exact selects, accepts, rejects, or completes versions.
- No smoke gate is used; after offline validation run the complete GAIA-50 directly.

## Pre-inference freeze

- Protocol source SHA-256: `e737a5ba5424d740457ec9f218cfa2344c8f311f1dc79ef39b8f75b4fa01b068`.
- Runner source SHA-256: `557a2a42cc80d441e8520f2416ff32978660442282c0b7245e5c25733fc06e87`.
- Inspector source SHA-256: `556e8fe1e77186a55521f74734b05d35a33fe482a50d30b5bc21ce7ef02f7677`.
- Negative/identity test source SHA-256: `768fe16b2efd87e44facfe93ee406f28e637d0ea4cfd1c008097902e57e133f3`.
- Offline validation: compilation passed; 23 targeted and inherited tests
  passed; direct-parent identity, exact sandbox-only command mutation, command
  completion/failure parsing, compatibility binding, inherited singleton and
  non-singleton contracts, registry, and 50-case dry preparation passed.
- Static inference-source scan found no labels, metrics, scored artifacts,
  historical predictions, trajectory/entity router, or post-score audit reader.


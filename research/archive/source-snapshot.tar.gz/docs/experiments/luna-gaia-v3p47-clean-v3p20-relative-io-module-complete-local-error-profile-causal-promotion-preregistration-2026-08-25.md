# Luna GAIA v3.47 preregistration

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.47-clean-v3.20-relative-io-module-complete-local-error-profile-causal-promotion`
- Direct semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: v3.20, Step Exact `25/50`
- Acceptance: Step Exact `>25/50`; Goal completion: Step Exact `>=30/50`
- Frozen `gaia-paper-v1` 50 cases; dataset SHA-256 `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`; cohort SHA-256 `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- `gpt-5.6-luna`, reasoning `medium`; no smoke gate; full GAIA-50 after offline validation.

Single major semantic mechanism relative to v3.20: one freshly executed clean
v3.20 anchor plus five mutually isolated, anchor-blind, module-complete local
error profiles, followed by one anchor-preserving causal promotion gate. The
profiles cover Memory, Reflection, Planning, Action, and System over every
Step. They record only literal local owner/type/evidence, adjacent facts, and
observable recovery; they cannot choose, rank, nominate, or predict a critical
Step and are not votes or candidates. Promotion compares every positive row,
defaults to exact-copying the anchor, and may emit at most one earlier-or-later
profile-grounded proposal only after symmetric anchor-only/candidate-only
repair tests and all probe/recovery/mechanical/propagation/symptom vetoes pass.

The paper comparison remains the semantic motivation. Its public Phase-1
topology produces high local recall: in the frozen post-score diagnostic, at
least one module marks the released gold Step positive in `35/50`, and its
union with frozen v3.20 exact is `43/50`. But the same inventory contains 457
positive Steps and 739 positive module verdicts, while public Phase 2 reaches
only `14/50`. Frozen v3.44 similarly has candidate oracle `29/50` and final
`13/50`. Thus local coverage must be separated from conservative promotion.
Frozen v3.39 supplies the positive precision control: three direct gains and
zero direct regressions relative to its fresh anchor, but insufficient recall
from one later-only proposal.

v3.46 did not complete or score. It validated 17 cases before case 20's Memory
profile exhausted two attempts without an artifact. Both frozen tasks printed
the correct existing input path `case-020-gaia-4d840b00`; the two inference
sessions transcribed it as `case-020-gaia-4d8400b00` and
`case-020-gaia-4d8400bb`, respectively, then stopped before semantic analysis.
This is a high-confidence `runtime_or_validation_failure`, not evidence for or
against the semantic mechanism.

v3.47 is a clean v3.20 reimplementation of that one mechanism, not a semantic
child of v3.46. Its transport-only correction is preregistered: every profile
and promotion attempt receives mechanically copied frozen inputs with fixed
basenames, and the inference process starts with that attempt directory as
cwd. Its task exposes only those relative basenames for input, output, and
compact validation. Input contents and hashes, profile rules, recovery rules,
promotion rules, default-anchor policy, model, effort, concurrency, retry
limit, and all scoring rules are unchanged. Relative I/O is applied uniformly
to every case/module and cannot inspect identity or affect Step semantics.

Expected gains and semantic regression risks remain the v3.46 preregistered
ones: fine-grained-recall, late-symptom, and early-freeze errors may improve;
surface local errors, reasonable probes, recovered defects, and downstream
symptoms may cause false overrides. The additional runtime falsifier is any
profile/promotion attempt that reads outside its fixed relative inputs or fails
to write the fixed artifact. Semantic falsifiers remain incomplete module/Step
coverage, nonliteral rows, profile-made predictions, a promoted Step absent
from the profile, missing repair/veto certificates, more than one promotion,
or an observable false-override cluster.

v3.21 through v3.46 remain immutable rejected/experimental lineage and are not
semantic parents. v3.47 does not import their protocol modules or inference
outputs. Inference may not read labels, scores, audits, prior predictions,
experiment documents, case studies, or git history. Diagnostic conditions do
not accept the version: only final legal GAIA-50 Step Exact `>25/50` accepts it,
and only `>=30/50` completes the Goal.

# E9 v26 dry3 failure case study

## Outcome

v26 produced three structurally valid raw LLM judgments, but failed every
semantic dry promotion threshold except the one-case minimum:

- Step Exact: 1/3 (33.33%; gate requires 2/3)
- Step+Module Exact: 1/3 (33.33%; gate requires 2/3)
- All Correct: 1/3 (33.33%; gate requires 2/3)
- Successful outputs: 3/3
- New logical completions: 1
- HTTP attempts: 1, with zero retries

The promotion gate rejected v26. No v26 full30 or held-out smoke run is
permitted.

## What v26 fixed

The provider returned a normal final response for all three cases. The strict
JSON parser accepted every row, no free-form reasoning was persisted, and the
raw-chain, lineage, gold-isolation, exact-budget, and telemetry checks all
passed. The optional strict-JSON suffix recovery was not needed in this call.
This rules out output formatting and transport recovery as the cause of the
dry failure.

## Failure attribution

The new final upstream-owner audit caused an over-correction toward early
agent-side explanations:

- ALFWorld: v24 and v25 selected the observable terminal system boundary at
  step 30, matching the released label. v26 replaced it with a speculative
  step-4 planning defect. The trajectory was still checking previously
  unvisited cabinets at the boundary, so the earlier plan did not satisfy the
  prompt's own requirement for a concrete repeated-stagnation defect.
- GAIA: v26 retained the valid step-1 action diagnosis, matching the released
  label. This is the control case showing that an observable incapable
  operation does not need an upstream rewrite.
- WebShop: v26 moved the selected planning step from v25's step 9 all the way
  to step 2, while the released label is step 13. Initial result paging was
  treated as causal merely because later paging failed. The first generic
  exploration choice was not yet a locally demonstrated critical error.

The error is therefore a prompt-level selection bias, not a validator or
scorer defect. “Upstream owner” and “earliest” were allowed to dominate the
benchmark's critical-local-event convention.

## v27 optimization direction

Before another model attempt:

1. Remove the v26 final upstream-owner audit. Module ownership remains part of
   the ordinary causal comparison, but it must not force an earlier step.
2. Keep an explicit terminal-boundary exception: when the agent is still
   making plausible progress through new states and no concrete local defect
   is observed, the enforced system step limit remains the critical event.
3. Treat initial WebShop query and result paging as exploration unless the
   text already violates an explicit constraint. For repetitive search,
   choose the later local planning event where prior observations make the
   unchanged strategy demonstrably wasteful; do not automatically choose the
   first page turn or the last symptom.
4. Retain Flash, the default API body, raw-only LLM semantics, strict evidence
   ownership, and the transport-only strict JSON suffix recovery.
5. Run a new frozen v27 dry3. Only an accepted dry may authorize full30, and
   only an accepted full30 may authorize the one-shot held-out smoke.

No v26 artifact may be mutated, reinterpreted under a new parser, or excluded
from cumulative logical-call accounting.

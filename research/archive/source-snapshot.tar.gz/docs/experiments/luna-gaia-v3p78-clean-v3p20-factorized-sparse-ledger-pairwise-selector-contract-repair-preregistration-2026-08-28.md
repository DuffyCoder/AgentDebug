# Luna GAIA v3.78 pre-registration

## Frozen identity

- Protocol: `agentdebug.codex-agent-judge.luna-gaia.v3.78-clean-v3.20-factorized-sparse-ledger-pairwise-selector-contract-repair`
- Semantic parent: accepted incumbent `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Incumbent Step Exact: `25/50`
- Original v3.4 baseline Step Exact: `21/50`
- Dataset: frozen `gaia-paper-v1`, 50 cases
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Acceptance: legal full-50 Step Exact `>25/50`
- Goal completion: legal full-50 Step Exact `>=30/50`
- Smoke gate: none

v3.78 is a clean direct semantic child of v3.20. It explicitly re-tests only
the single factorized sparse-ledger mechanism pre-registered for v3.77; no other
prompt, challenger, ledger, validator decision, candidate expansion, or selector
change from rejected versions is accumulated.

## Frozen v3.77 runtime evidence

v3.77 completed 47/50 cases and 141 successful semantic stages, then stopped
before freeze and before scoring. Gold was not read. All six response attempts
for the three failed cases contained an explicit model decision and selected
Step. Two cases had anchor Step 1 and therefore an empty strict-prefix domain,
but the model serialized later, out-of-domain rows. One case explicitly selected
a valid prefix and set `candidate_outweighs_anchor=true`, but used the opposite
redundant relation enum. The frozen runtime audit classifies these as two
`pairwise_row_domain` failures and one `redundant_relation_consistency` failure.

## One semantic mechanism plus runtime-only repair

The sole Step-selection mechanism relative to v3.20 remains:

> Factorize native sparse-ledger local facts from pairwise global selection.

The three inference prompts are byte-equivalent to v3.77 after version-name
normalization. The runtime-only repair applies these deterministic rules after
the model has explicitly selected a Step:

1. Drop pairwise rows outside the frozen strict-prefix ledger domain.
2. Deduplicate and reorder supplied in-domain rows to the frozen domain order.
3. Never invent a missing in-domain row; incompleteness still fails validation.
4. For `select_prefix`, canonicalize the selected row's redundant relation enum
   only when that exact row already has `candidate_outweighs_anchor=true`.
5. Never turn a false/absent outweigh boolean into true and never alter
   `selected_step`.

This is a legality/materialization repair, not a second Step-selection mechanism.
The raw and materialized selected Step must be identical or the run fails.

## Falsifiable hypothesis and risk

The semantic hypothesis remains that frozen anchor-blind local facts followed by
an independent pairwise selector can recover a positive subset of earlier native
ledger boundaries without the candidate flood and late-symptom preference of a
paper-style full inventory. Expected gains are incumbent-wrong cases with an
earlier unrecovered path-changing native-ledger Step. The principal semantic
regression remains false promotion of probes, normal failures, recovered defects,
or merely earlier surface flaws over incumbent-correct anchors.

The new runtime risk is that normalization could hide substantive missing
comparisons or invent a winner. The rules above directly prevent both: after
filtering, every expected prefix must still be present, and winner-relation
canonicalization is allowed only for the already explicit selected Step with an
already true outweigh boolean. Offline replay of all 54 frozen v3.77 raw selector
attempts passed 54/54 after repair with 54/54 selected Steps unchanged. All three
inference prompts were semantically identical after version normalization.

All gains, regressions, acceptance, and rejection are computed only against
frozen v3.20. v3.77 outputs are used only for post-run contract replay and never
as v3.78 inference inputs or prediction components.

## Frozen inputs and sources

- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort membership SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Semantic prediction-manifest SHA-256: `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`
- Protocol SHA-256: `40877df5625a9ea6237f49c168cc0abdc7426cde62fb921c1403e4b50b7094cf`
- Runner SHA-256: `97eb0ebb42705e724cc8b042eb3982c34a5eca397094c93606a0e790055c336b`
- Access auditor SHA-256: `cf4f6651cc0fe29434826908fff7b385d0a7f94a815b9b2d668a1cff0602fb2f`
- Registry SHA-256: `f2d022e93273244d9e83501b29e1fc43e74e61ec05de6bc8a1f30451c0bffbc4`
- Targeted tests SHA-256: `842a138f304c35d998da1215a5014c638d09be8d0dfc22168b2ad8233aed9260`
- Prepared case inputs: exactly 50 under `output/gaia-paper-v3p78-case-inputs`

These inference sources are frozen at execution. Any subsequent semantic source
change invalidates v3.78 and requires a newly versioned direct-incumbent
experiment.

## Offline verification and execution contract

- Python compilation and registry import passed.
- 27 targeted and adjacent regression tests passed.
- All 54 v3.77 selector attempts pass repaired validation with selected Step
  unchanged; false winner booleans are not promoted.
- All three normalized inference prompts are identical to the pre-registered
  v3.77 semantic mechanism.
- Run fresh v3.78 case directories only, without smoke or prior predictions.
- Require 50/50 cases, 150 successful semantic stages, all schema/taxonomy/
  evidence validators, passing owner-explicit read-only access/write audit, no
  routing, no prior predictions, and a complete gold-free freeze before scoring.
- Accept only above `25/50`; complete the Goal only at `>=30/50`. Otherwise reject
  v3.78 unchanged, perform the full first-divergence audit, and branch the next
  semantic version from the then-current accepted incumbent.

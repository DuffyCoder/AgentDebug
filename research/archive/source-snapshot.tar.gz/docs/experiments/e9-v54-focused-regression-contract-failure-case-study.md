# E9 v54 focused regression contract failure case study

## Result

The first focused v54 regression run passed 154 of 163 tests and failed nine.
No external provider was invoked.

## Attribution

- One prompt test still required the exact v53 phrase `materially equivalent
  query`; v54 expresses the same fallback category as a materially equivalent
  later recommitment and adds stronger contradiction-first language.
- The remaining failures are active experiment fixtures that still supplied
  v53's 640/642/662 phase offsets. V54 correctly starts after the completed
  v53 dry run at 642, so dry/full/smoke start at 642/644/664 and stop at
  644/664/708.
- The write-path fixture must also mock the newly mandatory immutable v53
  rejection anchor, just as it mocks older historical anchors.

These are stale test-contract failures, not evidence against the v54 semantic
hypothesis.

## Correction

Update only active v54 fixture budgets and identity assertions; preserve
historical v52/v53 recovery numbers in their dedicated audit tests. Add the
v53-anchor mock to isolated write fixtures, then rerun the same focused suite
before any model call.

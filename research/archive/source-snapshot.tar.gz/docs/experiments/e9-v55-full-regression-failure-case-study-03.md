# E9 v55 full-regression failure case study 03

## Failed attempt

The first full repository run produced 541 passes and 3 failures.  All three
were frozen-code import-closure checks for older v8/v14 experiments.

## Attribution

The new `batched_global_judge` was imported and re-exported from the shared
`agentdebug.diagnostics` package initializer.  Older frozen bundles include
that initializer, so this optional top-level convenience export changed their
transitive import graph.  The v55 implementation itself imports the module
directly and does not require the shared re-export.

This is an isolation regression, not a semantic, provider, or scoring error.

## Correction

Remove the v55 import and symbols from the shared package initializer.  Keep
v55 behind its explicit module path, leaving historical frozen bundle closure
unchanged.  Do not add v55 files to old experiment snapshots because that
would mutate their intended byte-level scope.

No external LLM request was made.

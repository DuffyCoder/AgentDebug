# Luna GAIA v3.62 clean-v3.20 full-local Step pairwise reducer preregistration

Date: 2026-08-27

## Frozen identity and acceptance

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.62-clean-v3.20-full-local-step-pairwise-reducer`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia.v3.20-packet-state-closure`
- Accepted incumbent: frozen Luna v3.20, Step Exact `25/50`
- Original frozen baseline: Luna v3.4, Step Exact `21/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Prediction manifest SHA-256: `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`
- Model / reasoning effort: `gpt-5.6-luna` / `medium`
- Version acceptance: legal frozen Step Exact `>25/50`
- Goal completion: legal frozen Step Exact `>=30/50`
- No smoke gate; all offline-valid predictions go directly to full GAIA-50.

Step Exact is the only optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module, type, and evidence remain schema, taxonomy, and
validator constraints only.

## Previous-version audit and first divergence

v3.61 completed all 50 cases and all 150 planned stages, but scored Step Exact
`20/50`; relative to the frozen v3.20 incumbent it was 2 gains and 7 losses,
net `-5`. Its own fresh anchor was `21/50`; the new census mechanism produced
zero direct gains, one direct loss, and one wrong-to-wrong move.

The mandatory 30-error audit reports 24 `anchor_error`, five low-confidence
`annotation_ambiguity`, and one `false_challenger_override`. The two principal
clusters are 15 early-anchor freezes whose later released Step was not
promoted, and eight late-anchor freezes whose earlier released Step was
classified probe/observation/clear. Although the complete census emitted a
boundary in 49 cases, only one wrong case's released Step was classified
`decision_boundary`; the remaining wrong-case released-Step verdicts were
`justified_probe` 9, `ordinary_observation` 8, `faithful_propagation` 5,
`locally_improvable` 3, `clear` 3, and unmapped 1. Complete enumeration did not
repair benchmark-boundary calibration.

The independent v3.61 access/write audit found zero gold, score, historical
prediction, error-audit, git-history, or raw-trajectory content reads, but it
found 59 top-level case directories rather than 50 and nine unexpected files.
v3.61 is therefore independently invalid and rejected. Its artifacts remain
frozen and are not modified or used by inference.

## Comparison evidence and single hypothesis

The accepted v3.20 and tied v3.39 share only 21 exact cases; their scoring-only
union is `29/50`. An ideal selector restricted to those two outputs can only
tie the paper AgentDebug main result and cannot complete the `30/50` Goal.

The paper topology obtains recall by Step×Module local analysis before global
selection. Local reproduction evidence confirms that the useful signal exists
before compression: v3.56's complete Step-isolated local matrix covered the
released Step in `36/50` and its fresh-anchor union oracle was `41/50`.
However, its five-class maturity representative layer retained the released
Step in only `5/50`; final Step Exact was `22/50`. v3.57--v3.59 similarly lost
released Steps through earliest-per-Module reservoirs or a shared global
anchor class. These rejected versions are evidence, never semantic parents.

The one v3.62 mechanism is:

`complete Step-isolated paper-local matrix -> full positive-Step pair table -> deterministic earliest pair winner`

1. Run a fresh prefix-bounded local taxonomy review for every observable Step.
   The local review sees no anchor, later Step, score, label, prior prediction,
   or critical-boundary task. It produces only literal taxonomy-valid local
   evidence inventory.
2. Preserve every positive local row. Group rows only by exact Step; do not
   choose a Module representative, boundary class, earliest Module positive,
   global proposal, vote, or salience score.
3. In one fresh full-trace semantic stage, produce one independently complete
   anchor-versus-Step assessment for every positive Step in chronological
   order. Each pair must decide only `anchor_wins` or `candidate_wins` and bind
   the selected local row, literal anchor evidence, probe/normal-failure/
   recovery/propagation status, and both repair effects. There is no shared
   anchor class whose value makes every pair ineligible.
4. `candidate_wins` is legal only if the Step owns a concrete benchmark-
   critical decision, the anchor is a reasonable/recovered/noncritical
   predecessor for this comparison, candidate-only repair can redirect the
   failed path, and anchor-only repair does not already remove the candidate's
   independent defect. Uncertainty exact-copies the anchor.
5. A deterministic validator-owned reducer sees no free prose ranking. If no
   pair has a legal `candidate_wins`, keep the anchor. Otherwise select the
   chronologically earliest winning Step and exact-copy the pair's selected
   frozen local row into the final prediction.

The Step-isolated projection and local-evidence schema are deliberately
retested because their full-matrix recall is the evidence under test. No
v3.56 class representative, selector prompt, selector result, candidate
prediction, score, case route, or per-case artifact is imported. The semantic
parent, anchor, ledger, checkpoint, final taxonomy, and default anchor remain
v3.20. Any shared code is restricted to generic projection, JSON transport,
and schema validation; all 717 local calls are fresh.

## Expected gains, regressions, and falsifiers

Expected gains are concentrated in the 15 v3.61 early-anchor errors and eight
late-anchor errors, especially cases where a taxonomy-valid local Step existed
but maturity compression called it propagation, probe, observation, or merely
improvable. Historical full-matrix anchor union `41/50` demonstrates a
Goal-capable candidate ceiling but is not a prediction and cannot accept this
version.

Regression risk is high: dense local positives exist in every case and expose
incumbent-correct anchors to surface errors, reasonable probes, normal tool
failures, recovered defects, faithful propagation, downstream symptoms, and
Planning salience. Direct counterexamples are the public local Phase-1 flood,
v3.44's free tournament, v3.54's four direct losses, and v3.56's representative
collapse. Isolation by Step, explicit pair-local anchor assessment, exact
literal bindings, default keep, and deterministic reduction are the uniform
controls. The mechanism can move earlier or later and may still create early
bias if several spurious pairs win; that is a preregistered failure, not a
post-score exception.

Falsifiers are:

- complete local Step coverage or exact row binding fails;
- candidate flood causes the pair stage to omit, duplicate, reorder, or jointly
  rank positive Steps;
- any candidate winner lacks literal anchor/candidate evidence and both repair
  relations;
- direct pair-reducer gains do not exceed direct losses;
- local-matrix-plus-anchor scoring-only oracle is below `30/50`;
- final Step Exact is `<=25/50`;
- any inference access, write path, hash, order, schema, taxonomy, evidence,
  exact-copy, case-routing, or gold-free audit fails.

## Planned execution

1. Implement the v3.62 protocol, strict pair-table validator, deterministic
   reducer, runner, registry entry, access/write guard, and negative tests.
2. Prove fresh v3.20 anchor semantic identity and prove v3.56 class-selector,
   representative, reservoir, historical artifact, and score paths are absent
   from inference.
3. Prepare all 50 cases. The fixed topology is 50 fresh v3.20 anchors, 717
   fresh Step-isolated local sessions, and 50 fresh full positive-Step pair
   sessions: exactly 817 planned successful stages, maximum four concurrent
   cases and at most two attempts per stage.
4. Complete offline tests and prepare-only validation without a smoke gate.
5. Run full GAIA-50, freeze predictions and all intermediate artifacts, and
   independently audit source hashes, command access, and the exact per-case
   write tree before scoring.
6. Score only after the gold-free freeze, compute Step transitions relative to
   v3.20 and v3.4, and audit every Step error by first divergence.

Pre-inference source hashes and offline results will be appended only after the
implementation and validation are frozen and before the first inference call.

## Pre-inference validation and frozen source hashes

- Focused v3.62 plus v3.20/v3.56 transport regression tests: `23 passed`.
- Prepare-only validation: 50 cases, 717 legal Step-local sessions, 50 fresh
  anchors, 50 full positive-Step pair sessions, exactly 817 planned successful
  stages, maximum concurrency four, and at most two attempts per stage.
- The v3.62 anchor task is byte-identical to v3.20 after normalizing only the
  version/module identity.
- Tests prove complete positive-Step pair coverage, exact row and literal
  evidence binding, required anchor-veto and repair relations, deterministic
  earliest-winner assembly, keep-anchor behavior, and rejection of coverage,
  reducer, role, and evidence drift.
- Generated local tasks contain no class-stratified representative, reservoir,
  global proposal, score, gold, prior prediction, or critical-Step nomination.
  The pair task explicitly forbids a shared anchor class and model-side global
  candidate ranking.
- Static inference-source scan found no label, metric, scored-artifact,
  historical-prediction, post-score-audit, case-ID/entity/source router, git
  history reader, or raw-trajectory content reader. Reads are limited to the
  exact staged manifests, v3.20 anchor bundle, local matrix, v3.62 protocol, and
  taxonomy. The runner executes each model inside its exact attempt directory
  and rejects unexpected nested writes before case completion.

Frozen pre-inference hashes:

- Protocol SHA-256: `e8ea816284e303264f13e1f4df3ac07f45b30bc860ea5549ac1570a6cedbd343`
- Runner SHA-256: `77a1dfd102a43180f9f05b5add4c6d6c27c9eae25ad2978840eeeaf26d5bb9e2`
- Registry SHA-256: `8c9c7bbe444467d2be4b3d906e16e65eeac1555b0258070ab39f8aea87963afe`
- Taxonomy SHA-256: `d7e4b878059bbecec0a8fd3f078c0aeb5755bf9e65bb938c897dd83685f28c5c`
- Focused-test SHA-256: `62b858bc79b72e9dd856bb10e4d522930770fd53b910103f0609120b987623c8`

## Frozen full-run outcome

v3.62 completed the full fixed topology before scoring: 50 fresh v3.20 anchor
sessions, all 717 Step-isolated local sessions, and 50 full local-Step pair
sessions (`817/817`, zero retries). The runner froze 50 predictions and passed
its gold-free schema, taxonomy, evidence, order, exact-copy, and aggregate
coverage validation.

The complete GAIA-50 result is Step Exact `18/50`. Relative to the frozen
accepted v3.20 incumbent it has 17 both-correct, 24 both-wrong, one gain, and
eight losses, for net `-7`. The fresh v3.20 anchor in this run was `17/50`;
the reducer produced one direct gain and zero direct loss relative to that
fresh anchor, ending at `18/50`.

The independent post-run access/write audit rejected legality despite valid
source hashes and the complete 817-stage command topology. It found 68
unexpected directories and 20 unexpected files outside the preregistered
write allowlist. No released gold, old prediction, scored artifact, or raw
trace outside the staged projection was read, but write-topology validity is
mandatory, so the run is illegal independently of its score.

Post-score first-divergence audit covers all 32 Step errors. The distribution
is 28 `anchor_error` and four `annotation_ambiguity`. The actionable errors
split into 19 `anchor_error__pairwise_gold_rejection` cases, where gold was a
local positive but its pair returned `anchor_wins`, and nine
`anchor_error__step_local_recall_gap` cases. Local positives covered the gold
Step in `29/50`, and fresh-anchor-or-local-positive oracle was `39/50`, but the
gold pair returned `candidate_wins` in only `2/50`; the pair gate therefore
discarded most of the useful recall by requiring whole-trajectory resolution
instead of benchmark-local failure ownership.

Decision: reject v3.62. It is frozen and must not be modified or used as a
semantic parent. Accepted incumbent and next semantic parent remain Luna
v3.20 at `25/50`.

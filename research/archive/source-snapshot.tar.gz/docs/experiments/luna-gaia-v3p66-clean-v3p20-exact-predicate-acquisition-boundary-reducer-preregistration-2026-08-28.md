# Luna GAIA v3.66 预注册：exact-predicate acquisition boundary reducer

状态：执行前冻结。本文只记录评分后分析得到的总体假设和执行契约；任何 case ID、
gold Step、历史逐例预测或错误报告都不会进入推理 prompt、case router 或 prediction
manifest。

## 冻结目标与继承

- 数据集：冻结 `gaia-paper-v1`，50/50。
- 原始基线：Luna v3.4 Step Exact `21/50`。
- accepted incumbent：Luna v3.20 Step Exact `25/50`。
- semantic parent：`agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`。
- 新版本：`agentdebug.codex-agent-judge.luna-gaia.v3.66-clean-v3.20-exact-predicate-acquisition-boundary-reducer`。
- 模型：`gpt-5.6-luna`。
- reasoning effort：`medium`。
- 接受条件：完整 GAIA-50、全部合法性验证通过且 Step Exact `>25/50`。
- Goal 完成条件：完整 GAIA-50、全部合法性验证通过且 Step Exact `>=30/50`。
- 不使用 smoke 门控；离线验证后直接运行完整 GAIA-50。
- Step Exact 是唯一版本选择指标；Module/type 只做 schema/taxonomy 合法性验证。

v3.21--v3.65 均不是本版本 semantic parent。它们的评分后审计只用于提出本次可证伪
假设；其 global proposal、challenger、arbiter、heterogeneous panel、complete census、
whole-trajectory replaceability gate、useful-intermediate categorical veto 以及其他协议
修改均不继承。

## 上一轮 first-divergence 事实

v3.65 完整运行的 Step Exact 为 `19/50`，相对冻结 v3.20 为 2 gains、8 losses；
错误审计的 first divergence 分布为 `anchor_error=22`、
`annotation_ambiguity=6`、`false_challenger_override=3`。其 fresh anchor 为 `19/50`，
max-one proposal 命中 `15/50`，anchor-plus-proposal oracle 仅 `23/50`，所以该接口在
候选阶段已经不可能达到本 Goal。

v3.65 未送入 duel 的稀疏 v3.20 ledger 覆盖 `29/50` gold，ledger 与该轮 global
proposal 的评分后 union 为 `33/50`；fresh-anchor 错误中有 10 例的 gold 已是 earlier
ledger row，主要被 initial/different-probe veto 排除。这些数字只用于选择机制，不
进入推理。v3.60 已反证“任何可复用中间线索都永久保护 probe”；v3.65 又反证“只有
零贡献 probe 才能成熟”。两端规则都过强。

## 唯一主要机制变化

保留 fresh v3.20 anchor、packet-state closure、稀疏 chronological ledger 和 checkpoint
语义不变；增加一个 `exact-predicate acquisition boundary reducer`。它最多提出一个
替代边界：一个被 initial/different-probe veto 的 pre-anchor ledger row，或一个 later
boundary。父进程确定性地保留 anchor 或 exact-copy 唯一候选，不允许候选投票、结果
拼接或第三个 Step。

一个 probe 即使产生 `partial_or_reusable` 中间结果，也只有在以下关系全部有 literal
证据时才能成熟：

1. 按当时参数和模态无法直接暴露当前 active subgoal 的精确谓词；
2. 实际 outcome 仍让该精确谓词 unresolved；
3. 部分贡献没有闭合该谓词，也没有把下一决策变成真正的新证据路线；
4. 只修复该 Step 的目标、参数、模态或 outcome handoff 会重定向该缺口；
5. 缺陷未恢复；
6. earlier 候选要求 anchor 只重复或传播同一缺口；later 候选要求 anchor 是真正有贡献、
   正常失败、已恢复或非关键前置，而 later Step 独立成为首个成熟 acquisition failure。

“精确谓词”是当前 subgoal 需要的最小事实/关系/标识符/约束，不是整道题的最终答案。
因此能直接提供必要 identifier 或 source lead 的发现 probe 仍应保留。直接 constraint、
false-state、incapable commitment 或合法 System root 的 anchor 受保护。

## 预期影响与回归风险

预期 gain 来自同一 failure mode：v3.20 ledger 已记录了早期 acquisition commitment，
但 ex-ante probe veto 没有在实际 outcome 后重新判断“能否取得精确谓词”，使 selector
偏向后来重复或传播该缺口的 anchor。机制整体可能让部分预测变早；later 分支只用于
anchor 确实是 contributing/normal/recovered predecessor 的相反方向纠偏。

主要回归风险：

- 把提供必要 lead 的合理搜索误判为“不能直接取得最终答案”，造成 early bias；
- 把普通 negative/empty tool result 误判为 Agent/System critical root；
- 把 later vivid symptom 误判为独立成熟边界；
- 为了覆盖早期 ledger row 产生候选洪泛；
- 把 anchor 的 direct constraint、state 或 capability root 错误降级。

约束措施是 active-subgoal predicate 定义、六项 gate、受保护 anchor class、最多一个
候选，以及 deterministic exact-copy selection。直接反例是：当前 probe 虽不能回答
最终任务，但能取得当前必要 identifier/source lead 并触发新路线；这种情况必须保留
anchor/拒绝 earlier candidate。

本修改不是 case-specific overfitting：推理规则不含 trajectory ID、实体、网站、来源
模型或固定 Step；同一关系同时适用于全部 50 例。GAIA-50 是 exposed tuning scope，
不据此声称未知数据泛化。

## 非语义运行层修改

v3.61、v3.64、v3.65 反复出现目录枚举和 attempt 外写入。v3.66 将两个模型阶段改为：

- 全部允许输入嵌入 prompt；
- `codex exec -s read-only`；
- JSON Schema 约束最终 response；
- 模型不写 artifact、不运行 validator；
- 父进程只在对应 attempt 内物化 response、anchor sidecar、deterministic selection 和 audit；
- 评分前独立审计所有 stdout tool events、runtime contract 和 case-tree 写拓扑。

这只改变 I/O 与合法性边界，不增加语义 Judge 规则。若任何模型阶段调用 shell/MCP/web、
出现非白名单目录/文件、缺失 runtime contract，或不是 100 个成功 stage，访问审计失败，
版本在评分前终止。

## 执行与判伪

每例两个 fresh serial session：

1. response-only unchanged-v3.20 anchor bundle；
2. response-only exact-predicate reducer；父进程随后确定性组装 selection。

计划成功 session 为 `100`，并发上限 `4`，每 stage 最多 `2` 次 attempt。全部 50 例、
merged artifacts、schema/taxonomy/evidence、packet-state sidecar、exact-copy binding、
gold-free access/write audit 冻结后才评分。

任一条件出现即判伪并拒绝：

- candidate/anchor union oracle `<30/50`；
- 相对 frozen v3.20 gains 不大于 regressions，或 final Step Exact `<=25/50`；
- partial-contribution 分支主要制造 incumbent-correct regressions；
- 直接约束/state/capability anchor 被系统性降级；
- 50/50、hash、顺序、schema、taxonomy、evidence、gold-free 或 read-only write-topology
  任一验证失败。

只有 Step Exact `>25/50` 才接受为新 incumbent；只有 `>=30/50` 才完成 Goal。

## 执行前冻结哈希

- protocol：`2284b867f00da06bc5b332404742eae4ff97a6f16fb6011a6a9008231d5a17c3`
- runner：`2eca8a9c1f4408f9ebf0537499e95390ba75c2eb2c56c62a65722251d5ac00a2`
- registry：`0abb158d6eb9994dd182e6f0579dbec7affca59fdd8af2a8bf3b496bd19b2e90`
- taxonomy：`d7e4b878059bbecec0a8fd3f078c0aeb5755bf9e65bb938c897dd83685f28c5c`
- tests：`7c5852d40aa3fb429a682d8b0770521a92e4a3ff3c71272142e35cf168582163`
- access auditor：`daa72813ef2f60121f50ed2679c23cfe8d196941b8173e4c60d1e3e552d894a9`
- semantic parent v3.20：`3e886325bf0a4b4d4a3e770071c0a36fe81dab2bebaf5015561ca828b6c2e4f9`
- GAIA-50 prediction manifest：`77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- GAIA-50 cohort：`31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`

离线验证：v3.66 与 v3.20 相关测试 `13 passed`；registry resolve、Python compile、
50-case dry plan、`100` planned sessions、模型与 effort、direct parent 均通过。


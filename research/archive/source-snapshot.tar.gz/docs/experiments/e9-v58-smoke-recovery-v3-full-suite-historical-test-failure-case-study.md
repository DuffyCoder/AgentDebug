# E9 v58 smoke recovery v3 historical-test full-suite failure case study

## Failure

The first v3 full suite finished with 555 passes and one failure. The failing
v2 regression test invoked the live v2 `check`, which requires the interrupted
ledger to remain at its original 24-call prefix. Recovery v2 had legitimately
advanced that ledger to 27 before its later missing-incumbent stop, so the live
check rejected the changed ledger hash.

No provider was constructed and no smoke artifact changed during pytest.

## Attribution

The v2 test encoded a transient recovery-start precondition as a permanent
repository invariant. Once a recovery advances a shared durable ledger, its
historical start boundary must be tested through the frozen v2
preregistration/code archive, not by replaying a live source-boundary check.
The v3 boundary test correctly targets the current 27-call prefix.

## Correction

Change the v2 regression to validate the write-once v2 preregistration fields,
request-size vector, request hashes, and frozen code-archive digest. Do not
invoke v2's live `check`. Then rerun the v2/v3 targeted tests and one complete
suite before freezing v3.

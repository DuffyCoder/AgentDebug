# Luna GAIA v3.13-conservative-challenger 预注册

日期：2026-08-22  
状态：实现与完整 GAIA-50 执行前冻结

## 冻结起点与唯一主要改动

- 语义父版本：`agentdebug.codex-agent-judge.luna-gaia-v3.4`。
- 冻结基线：`gaia-paper-v1` Step Exact `21/50`。
- 新版本：`agentdebug.codex-agent-judge.luna-gaia-v3.13-conservative-challenger`。
- 模型：`gpt-5.6-luna`。
- reasoning effort：`medium`。
- 唯一主要改动：把 v3.4 的首存活候选保留为独立 anchor；一个独立 challenger 最多提出一个**更晚**的替代 Step；一个独立 arbiter 默认保留 anchor，只有 challenger 用 literal trace evidence 证明 anchor 不是 critical root 且替代 Step 是独立、未恢复、outcome-material 的 critical root 时才能 override。

不引入完整 candidate census，不修改 taxonomy、owner evidence geometry、模型、effort、数据集、评分器或 Step Exact 定义。该版本不尝试修复 v3.4 的 late miss；它只检验 dominant early-selection failure 是否能在保留 incumbent 的前提下产生净收益。

## 输入冻结

- 数据集/队列：`gaia-paper-v1`，50 条，顺序不变。
- dataset manifest content SHA-256：`fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`。
- cohort content SHA-256：`193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`。
- cohort file SHA-256：`31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`。
- prediction manifest content SHA-256：`56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`。
- prediction manifest file SHA-256：`77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`。
- v3.4 protocol source SHA-256：`a7ecc53fdca63174e6577becebbc8ba7a81acad77d5fc64571cf12597b1311a6`。
- v3.4 frozen predictions SHA-256：`263b8439c0d3180efc24c04d51cdd2fc14f473a4e1c0d27541a44a23f2fa950d`。
- v3.4 `step-error-audit.json` SHA-256：`710ebfdd7621cfa4db2e17c0dbe5aa74a67b62f51899269b3245da5afaf3c0c0`。
- v3.4 `step-error-clusters.json` SHA-256：`cd29cc4401a05193bd162943a34d60a93b1c9f1a53a678bab19f1f5ae0ca90b0`。

评分后分析 artifact 只用于本预注册的机制选择；任何 case ID、gold Step、旧 prediction、metrics、错误报告或本文件都不得进入 inference prompt、router、manifest 或 stage input。

## 根因与可证伪假设

v3.4 的 29 个 Step miss 中有 19 个 early miss。first divergence 为：

- `false_candidate_admission` 13；
- `early_freeze_failure` 5；
- `candidate_recall_failure` 10；
- `annotation_ambiguity` 1。

v3.12-global 的完整 census 在 smoke30 上产生 446 个候选，却只有 17/30 gold-step recall，且 selector 形成 16 个 late miss；相对 v3.4 为 4 gains / 11 losses，净损失 7。因此本版本拒绝“提高候选数量”作为修正，改为 incumbent-preserving 的单 challenger。

主假设 H1：v3.4 early miss 中有一部分 anchor 可由完整时间线中的直接反证可靠识别为 reasonable probe 或 noncritical predecessor；只允许一个高证据 later challenger，并以 anchor 为默认，可获得正 Step 净收益。

保留性假设 H2：禁止候选池、禁止多个 challenger、禁止 earlier override、禁止仅因后续更显眼而 override，会显著减少 v3.12-global 的候选洪泛和晚选回归。

反驳条件：如果完整 GAIA-50 的 Step Exact 不高于 21/50，或 losses 不受严格 anchor-veto 证据解释，则拒绝 H1/当前门槛设计；不修改本版本的已评分产物。

## Challenger 与 arbiter 的统一规则

Challenger 必须先审计 anchor，而不是扫描并列出整条轨迹的所有错误。最多一个 later proposal，并必须同时提供：

1. anchor 的 literal evidence 与直接 falsifier；
2. anchor 属于 `reasonable_probe` 或 `noncritical_predecessor` 的证据；
3. 为什么只修 anchor 不能避免最终失败；
4. proposed Step 的 literal owner evidence；
5. 为什么只修 proposed Step 更可能改变失败结果；
6. anchor 与 proposal 的直接时间线比较。

以下情况不得 challenge：

- 只是觉得 later Step 更严重、更持久或措辞更强；
- anchor 的 exact defect 持续且未恢复；
- anchor 是明确 constraint violation、plan/Action target contradiction、unsupported state、terminal abandonment；
- exact video/URL 已识别后仍要求 static extractor 提供 frame、narration 或 timestamp evidence；
- 交互式 UI predicate 被直接交给不能观察 UI state 的接口；
- 证据不确定。

Arbiter 看到完整 trace、冻结 anchor 和最多一个 challenger。默认 `keep_anchor`；只有所有 challenge contract 均被 literal evidence 满足时才可 `accept_challenger`。最终 prediction 必须逐字段精确复制被选中的 anchor prediction 或 challenger prediction，防止 final Step drift 和第三种未注册候选。

## 预期 gains 与 regressions

优先预期覆盖的统一结构：

- acquisition probe 被 final-evidence capability 规则过早判死；
- 第一个 repeat/noncritical predecessor 抢占后续独立 false-success 或 System root；
- minor early defect 没有 outcome materiality，却因 chronological checkpoint 被冻结。

预期风险集中在 v3.4 已正确的：

- direct dynamic-video/static-extractor mismatch；
- 首次真正 same-strategy recommitment；
- 早期 explicit constraint/target violation。

主要防护是：later-only、one-challenger、literal anchor falsifier、counterfactual materiality、independent arbiter 和默认保留 anchor。预计选择分布整体只会有限变晚；若 override 数量大或集中在长轨迹，即视为候选洪泛/晚选机制复发。

历史反例已计入：v3.5.1 的直接 capability prompt 在 smoke30 相对 v3.4 为 2 gains / 3 losses；v3.12-global 为 4 gains / 11 losses。因此本版本不采用无锚点的全局搜索，也不直接清除一整类 Lane-B candidates。

## 实验与冻结顺序

1. 实现 anchor、challenger、arbiter 三阶段 artifact contract、runner 和 validator。
2. 运行静态检查、协议单测、validator 负例、gold-isolation、hash/order 和 runner plan 测试。
3. 不运行 smoke30 或任何开发门控。
4. 直接对完整 GAIA-50 运行 50 个隔离 case；每阶段均使用新的 Luna medium ephemeral session。
5. 先冻结并汇总 anchor、challenger、arbiter、predictions、attempt ledger 和全部 audits。
6. 在不加载 labels 的父进程中验证 50/50 完成、顺序、hash、taxonomy、literal evidence、selected-prediction identity、无 case routing、无 forbidden reads。
7. 只有上述验证全部通过后加载 gold 并评分一次。
8. 计算 Step Exact 和相对冻结 v3.4 的 `both correct`、`v3.4 wrong/new correct`、`v3.4 correct/new wrong`、`both wrong`。

## 唯一接受条件

- `Step Exact > 21/50`，即至少 `22/50`；
- 50/50 完成；
- 全部 schema、taxonomy、owner evidence、hash、顺序和 gold-free validator 通过；
- 无 case routing、gold 泄漏、单例替换或多版本拼接。

Step+Module、All Correct、module/type 分布和 challenger 数只用于合法性或机制解释，不参与接受、拒绝或 Goal 完成。

若 Step Exact `<= 21/50`，本版本被拒绝并冻结；随后生成本版本的 `step-error-audit.json`、`step-error-clusters.json`、gains/losses 根因分析和下一版本预注册。

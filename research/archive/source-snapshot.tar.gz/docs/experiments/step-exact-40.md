# Step Exact 40% experiment log

This log records experiments for the fixed AgentErrorBench cohort goal. Gold
labels are available only to the post-prediction evaluator. They are never sent
to an LLM judge.

## Frozen protocol

- Dataset SHA-256:
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Tuning cohort: `tuning-v1`, 30 trajectories, 10 per environment,
  SHA-256 `e21b1034470577688b68aad2a0e006facc658fed28bdb986fed039bc0347bd6f`
- Smoke cohort: `smoke-v1`, 30 trajectories, 10 per environment,
  SHA-256 `6dfbc06b27a64f80719787b0cd56736a26ae97a98ba7714daf6a571808d11fe0`
- Cohort overlap: zero.
- Selection uses only environment, trajectory ID, dataset manifest SHA-256,
  and a fixed cohort-specific salt.
- The one structurally ineligible release trajectory is recorded in both
  manifests as `conversion_integrity_failure` / `gold_step_unmapped`.
- Primary acceptance metric: two-stage Step Exact, at least 12/30 on
  `smoke-v1`. Invalid outputs remain in the denominator.
- Fixed judge: Sophnet OpenAI-compatible `gpt-4.1`, temperature 0.

The previous `output/*smoke*` directories contain one-trajectory connectivity
runs and are not part of this protocol.

## E0 — frozen current implementation

Hypothesis: the full lossless chunk-table prompt and large root-cause response
schema impose substantial reasoning and output-protocol overhead. This run
freezes the current implementation before any diagnostic prompt, projection,
parser, validator, or provider behavior is changed.

Configuration:

- Prompt version: `agentdebug-two-stage-v3-lossless-chunk-table`
- Provider: OpenAI-compatible
- Model: `gpt-4.1`
- Temperature: 0
- Max output tokens: 8192
- Workers: 1
- Max transient retries: 5

Results:

| Cohort | Step Exact | Step+Module | All Correct | Failed outputs |
|---|---:|---:|---:|---:|
| tuning-v1 | 1/30 (3.33%) | 0/30 (0.00%) | 0/25 (0.00%) | 10 |
| smoke-v1 | 4/30 (13.33%) | 2/30 (6.67%) | 1/27 (3.70%) | 9 |

Logical LLM completions and input estimates:

| Cohort | Phase 1 | Phase 2 | Logical completions | Estimated input |
|---|---:|---:|---:|---:|
| tuning-v1 | 30 | 30 | 60 | 9,718,108 `o200k_base` tokens |
| smoke-v1 | 30 | 29 | 59 | 8,251,573 `o200k_base` tokens |

There was also one 27-token provider-connectivity request before E0, so the
goal has issued 120 logical external requests through this point. The baseline
provider discarded response usage, finish reason, and retry telemetry. Thus the
input figures are tokenizer estimates and the exact HTTP-attempt/retry count is
not recoverable. No final baseline record has a transport failure.

Observed failure mechanism:

- Ten tuning and most smoke hard failures are downstream evidence-package
  failures rather than provider failures.
- Several otherwise parsed root classifications are invalidated solely because
  a requested cascading-effect event is not later than the selected root.
- The two phases resend the complete trace. Their combined baseline inputs are
  about 56 million characters for the two frozen cohorts.
- Full-release audit shows a strong action/format-error prediction bias and
  severe memory/system underprediction.

Artifacts:

- `output/agenterrorbench-gpt-4.1-tuning-v1-baseline/`
- `output/agenterrorbench-gpt-4.1-smoke-v1-baseline/`

## E1 — compact batched-specialist semantic judge

Falsifiable hypothesis: an explicit step timeline, official detailed taxonomy,
module-aware candidate generation, global counterfactual root selection, JSON
mode, and a minimal final classification schema will reduce output failures
below 5% and materially improve Step Exact without deterministic diagnosis.

Planned controlled changes:

1. Derive an auditable, compact JudgeView from CanonicalTrace.
2. Send each assistant decision once with its observable context, optional
   module spans, and linked tool calls/results.
3. Phase 1 generates semantic candidates across steps/modules in one bounded
   call; it does not select a root deterministically.
4. Phase 2 reads the complete compact timeline plus candidates and may override
   them using the counterfactual root-cause test.
5. The LLM returns only step, module, error type, evidence, and root reasoning.
   Code maps step to event ID and validates structure; it never scores or ranks
   semantic candidates.
6. Add JSON response mode and transport telemetry.

Implementation:

- JudgeView version:
  `canonical-judge-view-v2-aeb-incremental`
- Prompt version evolved through the recorded dry-run fixes and is now:
  `agentdebug-two-stage-v7-canonical-judge-view-v2-aeb-incremental-flow-attribution`
- Phase 1 is a step-complete, module-sparse scan:
  `steps[].errors[]`. Every step is represented exactly once, while only
  positive local-specialist verdicts are expanded.
- Phase 2 sees the complete compact timeline and the chronological sparse scan.
  It selects the root semantically and may override or supplement Phase 1.
- The output parser accepts only JSON integer steps and maps them to canonical
  assistant events. It does not coerce strings or repair classifications.
- Confidence, score, correction guidance, and cascading-effect fields were
  removed from the models, metrics, CSV, and reports.

Projection audit:

- All released cumulative inputs recognized without fallback:
  ALFWorld 2,900/2,900, GAIA 667/667, WebShop 1,246/1,246.
- Tuning Phase 1 prompt characters fell from 18,474,135 to about 5.9 million.
- Median fell from 254,160 to about 193,000 characters.
- Maximum fell from 6,084,955 to about 488,000 characters.

Dry run E1a used the three predeclared tuning trajectories. The provider made
five logical completions (two samples reached Phase 2), five HTTP attempts, and
zero retries. Provider usage was 135,089 input, 2,243 output, and 137,332 total
tokens.

All three predictions were strictly invalid because the prompt's illustrative
schema described integer fields with quoted strings. The underlying semantic
output was still informative: the GAIA case independently selected the exact
released `step 1 / action / misalignment` tuple, but returned `"1"` rather than
the JSON number `1`. No parser coercion or metric credit was applied.

E1b changed only the schema example and explicit instruction to require JSON
numbers. A one-trajectory WebShop format check then completed both phases with
two logical completions, two HTTP attempts, zero retries, and 38,658 provider
tokens. It was structurally successful but selected
`step 5 / planning / inefficient_plan` instead of the released
`step 7 / action / misalignment`.

The semantic discrepancy supports a falsifiable refinement: explicitly tracing
history→memory→reflection→plan→action, including unresolved prerequisites in an
ordered plan, should retain the correct action candidate; explicitly locating
the first repeated action after known unproductive feedback should improve the
ALFWorld memory-onset case. E1 v7 makes only that attribution clarification
before the complete tuning run.

Cumulative external usage through E1b is 127 logical completions for the goal.
The seven new E1 completions used 175,990 provider-reported tokens and had zero
transport retries.

### E1-v7 complete tuning result

The complete `tuning-v1` run used the v7 flow-attribution prompt described
above. It made 59 logical completions in 61 HTTP attempts, with two retries and
3,195,543 provider-reported tokens.

| Metric | Result |
|---|---:|
| Step Exact | 8/30 (26.67%) |
| Step+Module | 4/30 (13.33%) |
| All Correct | 3/25 (12.00%) |
| Failed outputs | 1/30 (3.33%) |

Step Exact by environment was ALFWorld 2/10, GAIA 3/10, and WebShop 3/10.
The run therefore materially improved the frozen tuning baseline, and reduced
hard failures below 5%, but did not yet demonstrate the 40% target.

The post-prediction tuning audit found that Phase 1 included the gold step in
10/30 cases, the gold step and module in 5/30, and the exact
step/module/error-type tuple in 2/30. The final root exactly matched one of the
Phase 1 candidates in 23/30 cases, showing that Phase 2 remained strongly
anchored to candidate generation. ALFWorld frequently missed relevant action
history and repeated-action patterns; GAIA frequently chose later symptoms;
and 45/58 WebShop Phase 1 positives were assigned to planning, while action
alignment errors were largely missed.

Artifact:

- `output/agenterrorbench-gpt-4.1-tuning-v1-e1-v7/`

Cumulative external usage through E1-v7 is 186 logical completions.

## E2 — fixed step-by-module verdict matrix

Falsifiable hypothesis: requiring a fixed five-lane verdict matrix for every
step and module, then making Phase 2 derive an independent provisional root
before applying recovery and prospective-causality gates, will improve
candidate recall and reduce Phase 1 anchoring without deterministic scoring.
The matrix makes memory, reflection, planning, action, and system checks
explicit at every step; code performs only strict schema validation and
flattening of positive semantic verdicts.

JudgeView v3 adds observable execution facts through a safe whitelist:
AgentErrorBench `benchmark.metadata.steps`, `won`, and `success`, plus canonical
turn count, final stop reason, and final error message. IDs, model names,
released critical-failure labels, step annotations, and reference reasoning are
not exposed. These facts are labeled as observable source metadata rather than
gold labels.

Before any E2 external run, the expected signals are:

1. Phase 1 gold-step and gold-step-plus-module recall should exceed the E1-v7
   rates of 10/30 and 5/30 on `tuning-v1`.
2. WebShop candidates should no longer be overwhelmingly assigned to planning
   when a concrete action violates an unresolved prerequisite.
3. Independent provisional selection and the recovery/prospective gates should
   reduce exact copying of incorrect Phase 1 candidates.
4. Strict-output failures should remain at or below E1-v7's 1/30.

If these signals do not improve on the fixed tuning cohort, the fixed matrix
and gating hypothesis is rejected; no deterministic semantic score or
confidence value will be introduced to rescue it.

### E2-v8 three-trajectory dry run

The first matrix dry run used the three predeclared tuning trajectories. It
made five logical completions in six HTTP attempts, with one retry and 149,071
provider-reported tokens. One Phase 1 output failed strict validation, so only
two trajectories reached Phase 2.

| Metric | Result |
|---|---:|
| Step Exact | 0/3 (0.00%) |
| Step+Module | 0/3 (0.00%) |
| All Correct | 0/3 (0.00%) |
| Failed outputs | 1/3 (33.33%) |

The two valid Phase 1 matrices contained no positive verdicts at all. The
invalid GAIA matrix contained two positives but used the undeclared detail
aliases `quote` and `explanation` instead of the required `evidence` and
`reasoning`. This is a falsifiable output-protocol failure: the required-output
example showed only neutral verdicts and an empty details array, so it taught
neither the positive-verdict linkage nor the exact detail keys.

E2-v9 changes only that structural example and its associated field warning.
The example now contains valid synthetic memory and action positives with
exactly `module`, `evidence`, and `reasoning`, and explicitly states that its
values are not trajectory defaults. Phase 1/Phase 2 decision rules, JudgeView,
taxonomy, parser, and evaluator are unchanged. The dry-run signal is therefore
strict: all three Phase 1 outputs must validate, and the two previously empty
matrices must contain evidence-grounded positives rather than copying the
example or remaining uniformly neutral.

Artifact:

- `output/agenterrorbench-gpt-4.1-tuning-v1-e2-matrix-dry3/`

Cumulative external usage through E2-v8 is 191 logical completions.

### E2-v9 schema dry run

E2-v9 made six logical completions in six HTTP attempts, with no retry and
162,482 provider-reported tokens. All three Phase 1 matrices and all three final
outputs passed strict parsing, but the diagnostic metric did not improve:
Step Exact, Step+Module, and All Correct were each 0/3.

The Phase 1 positives were:

- ALFWorld: none;
- GAIA: six, including the exact released
  `step 1 / action / misalignment` tuple;
- WebShop: three, including step 7 as planning/inefficient-plan but not the
  released action/misalignment tuple.

This rejects output formatting as the main remaining cause. Phase 2 still
selected ALFWorld step 3 reflection even though the reflection accurately
reported an uninformative observation; it overrode GAIA's exact local candidate
with step 4 planning; and it selected WebShop step 5 memory rather than the
later action that skipped the plan's unresolved verification.

E2-v10 therefore changes only Phase 2 candidate validity and ordering. Before
causal ranking, the judge must reject a proposed root unless the selected
behavior is itself a taxonomy-matching local error using evidence available at
that step. Accurate statements of failure or uncertainty cannot become
reflection errors because later behavior failed, while a terminal action may
be the root when it first violates an unresolved same-step prerequisite. The
matrix, schema, JudgeView, taxonomy, parser, and evaluator remain frozen.

Artifact:

- `output/agenterrorbench-gpt-4.1-tuning-v1-e2-v9-schema-dry3/`

Cumulative external usage through E2-v9 is 197 logical completions.

### E2-v10 local-validity dry run

E2-v10 made six logical completions in six HTTP attempts, with no retry and
163,101 provider-reported tokens. All outputs were structurally valid, but Step
Exact, Step+Module, and All Correct again remained 0/3.

- ALFWorld again selected step 3 reflection/outcome-misinterpretation despite
  that reflection accurately describing the uninformative result.
- GAIA again selected step 4 planning/constraint-ignorance, overriding the
  exact step 1 action candidate already present in Phase 1.
- WebShop moved from step 5 memory to step 4 planning, but still did not select
  the step 7 concrete action that skipped an unresolved prerequisite.

The local-validity warning therefore did not alter the persistent failure
mechanism. After two valid-output matrix dry runs at 0/3, E2's semantic
hypothesis is rejected. Adding more rules to the same long Phase 2 prompt would
not be an attributable architectural experiment.

The next experiment is M3: three isolated semantic calls over the same compact
timeline. A taxonomy-free causal scout proposes unranked divergence steps; an
independent root drafter sees neither those candidates nor their output; and a
fresh LLM arbiter reads the timeline plus both normalized analyses and makes
the only final classification. There is no voting, weighting, deterministic
fallback, confidence, or score.

Artifact:

- `output/agenterrorbench-gpt-4.1-tuning-v1-e2-v10-validity-dry3/`

Cumulative external usage through E2-v10 is 203 logical completions.

## E3 — independent scout, draft, and semantic arbiter

Falsifiable hypothesis: the E1/E2 failure is not missing taxonomy coverage but
single-path anchoring. Three isolated semantic judgments should improve causal
step localization: a taxonomy-free scout broadens plausible divergence steps,
an independent taxonomy-aware draft supplies a complete root without seeing
the scout, and a fresh arbiter makes the only final classification after
re-reading the timeline and both fallible analyses.

Implementation:

- Prompt protocol:
  `agentdebug-m3-v1-canonical-judge-view-v3-aeb-incremental-execution-facts-independent-adjudication`.
- Call 1 returns one to four unranked causal candidates with step, exact
  evidence, causal case, and recovery/counterfactual analysis. It does not
  classify module or error type.
- Call 2 receives only a fresh copy of the Canonical Trace and returns an
  independent minimal root classification.
- Call 3 receives a fresh trace plus normalized, strictly parsed scout and
  draft models. It may reject both and is the sole source of the final root.
- No call returns confidence or score. Code does not vote, weight, rank, repair,
  or select a semantic answer.
- Each call receives an isolated deep copy, so a custom scout cannot mutate the
  trace observed by the independent draft.
- Strict parsers only validate structure, taxonomy, step mapping, and bounded
  candidate count. Evidence validation applies only after the arbiter returns.
- Diagnostic reports use schema v5 and retain `scout`, `draft_root`,
  `root_cause`, and all three raw outputs.

Before the E3 external dry run, the gate is fixed as follows:

1. Exactly three predeclared tuning trajectories and normally nine logical
   completions.
2. Three valid final outputs, with no malformed JSON, illegal taxonomy, or
   truncation.
3. Final Step Exact at least 2/3 and Step+Module at least 2/3.
4. Scout candidate step recall against the released critical step at least 2/3.
5. GAIA must retain step 1/action, and at least one of the previous ALFWorld or
   WebShop misses must be corrected.

Failure of the semantic gates rejects E3 for a full tuning run. Passing them is
only a signal to request a larger external-call budget before the 30-trajectory
run; it is not smoke acceptance.

The pre-E3 cumulative external usage is 203 logical completions.

### E3 three-trajectory dry run

E3 made exactly nine logical completions in nine HTTP attempts, with no retry
and 228,389 provider-reported tokens. All three scout, draft, and arbiter
outputs were structurally valid, but final Step Exact, Step+Module, and All
Correct were each 0/3.

| Trajectory | Scout steps | Draft | Final |
|---|---|---|---|
| ALFWorld | 3, 4 | 3/reflection | 3/reflection |
| GAIA | 1, 4 | 1/action | 4/reflection |
| WebShop | 4 | 4/planning | 4/planning |

Only GAIA's scout included the released critical step, so scout step recall was
1/3 rather than the required 2/3. The independent GAIA draft localized step 1
and action but used parameter-error rather than misalignment; the arbiter then
overrode it with a late reflection diagnosis. ALFWorld repeated the inaccurate
step-3 reflection narrative, and WebShop never proposed the terminal
plan-to-action divergence.

E3 therefore fails every semantic dry-run gate despite perfect output
reliability and is rejected for full tuning.

Artifact:

- `output/agenterrorbench-gpt-4.1-tuning-v1-m3-v1-dry3/`

Cumulative external usage through E3 is 212 logical completions.

## E4 — whole-trace module specialists plus semantic arbiter

Falsifiable hypothesis: global judges repeatedly conflate valid local behavior
with a plausible failure narrative because all modules compete inside one
completion. Borrowing the official implementation's module-role isolation,
while batching each module over the whole compact timeline, should make the
memory specialist inspect ALFWorld history, the action specialist enforce
same-step plan/action ownership in GAIA and WebShop, and the reflection
specialist explicitly reject accurate failure descriptions.

E4 will make five independent specialist calls, one each for memory,
reflection, planning, action, and system. Each scans every step for only its
assigned module and returns zero to four unranked, taxonomy-valid findings.
A sixth LLM reads the full timeline and normalized findings, may reject or add
any candidate, and supplies the only final root. Deterministic code only
validates, maps, concatenates in declared module order for serialization, and
preserves evidence; it does not vote, weight, rank, score, or choose.

The three-trajectory dry run therefore costs normally 18 logical completions
and would bring cumulative usage to 230. Its predeclared success gate remains
strict: three valid outputs, final Step Exact and Step+Module at least 2/3, and
released-step inclusion in at least one specialist result for all three cases.
Otherwise E4 is rejected without a full tuning run.

### E4 three-trajectory dry run

E4 made exactly 18 logical completions in 18 HTTP attempts, with no retry and
449,411 provider-reported tokens. All specialist and arbiter outputs were
structurally valid, but final Step Exact, Step+Module, and All Correct were
again each 0/3.

| Trajectory | Specialist findings | Final |
|---|---|---|
| ALFWorld | planning at steps 3 and 15 only | 3/planning |
| GAIA | memory at step 2 only | 4/action |
| WebShop | memory 5, planning 5, action 7 | 5/memory |

Only WebShop had any specialist include its released step and module. The
action specialist correctly produced `step 7 / misalignment`, but the arbiter
preferred step-5 memory. ALFWorld's memory specialist returned no finding, and
GAIA's action specialist returned no finding. Specialist released-step
inclusion was therefore 1/3 rather than the required 3/3.

E4 fails both final-accuracy and local-recall gates and is rejected for a full
tuning run.

Artifact:

- `output/agenterrorbench-gpt-4.1-tuning-v1-e4-v1-dry3/`

Cumulative external usage through E4 is 230 logical completions.

## E5 — adversarial second-pass semantic critic

Falsifiable hypothesis: E4's local specialists sometimes contain the decisive
step, but the single arbiter remains anchored to a plausible specialist
narrative. A fresh semantic critic that must first construct and test the
strongest different-step challenger should reject locally valid exploration,
distinguish current information-action qualifiers from deferred work, trace
repetition through explicit recall, and prefer an early error only when its
effect remains continuously unrecovered.

E5 keeps E4's five whole-trace module specialists. A sixth LLM produces a
fallible `initial_root`; a seventh LLM receives fresh copies of the complete
JudgeView, normalized specialist analyses, and the initial claim, then produces
the sole final root. Deterministic code only performs strict parsing,
step-to-event mapping, report serialization, and evidence validation. It does
not create candidates, vote, rank, weight, score, or use confidence. The
initial root is retained only as an audit artifact and critic input.

The critic protocol requires:

1. constructing the strongest challenger, including steps all specialists
   omitted;
2. testing local taxonomy validity with evidence available at that step;
3. separating qualifiers of the immediate information subgoal from explicitly
   deferred output or verification work;
4. requiring an explicit history-to-recall omission before using a memory
   label for repetition;
5. checking unresolved same-step prerequisites at terminal or irreversible
   actions; and
6. preferring an earlier step only inside the winning continuous, unrecovered
   causal chain.

The initial claim and grouped analyses precede the fresh timeline in the prompt
so the original evidence is the critic's most recent input. The protocol
version is
`agentdebug-e5-v1-canonical-judge-view-v3-aeb-incremental-execution-facts-module-specialists-adversarial-critic`,
and diagnostic reports use schema v7 with distinct `initial_root` and
critic-selected `root_cause` fields.

### E5 local preflight

Before any E5 provider request, a local structural replay used only the
previous E4 dry run's raw semantic outputs to populate the unchanged JSON
contracts. It did not reuse those outputs as E5 predictions and did not contact
the provider. All three fixed dry trajectories passed Canonical integrity and
all five specialist outputs plus the initial arbiter output parsed into the E5
contracts. Building the seven current request payloads per trajectory produced:

- 3 preflight trajectories;
- 21 expected logical completions;
- 2,058,290 aggregate request characters under the replayed output shapes;
- zero occurrences of the forbidden gold field names checked by the payload
  audit.

The benchmark cache key now records the trajectory hash, adapter, JudgeView
version, diagnostic pipeline version, prompt protocol, transport policy,
cohort hash, model, temperature, endpoint, timeout, output limit, and retry
configuration as independent inputs. Unit tests prove that changing either the
JudgeView or pipeline version changes the cache key.

### E5a controlled critic-only replay

The complete E5 dry run requires 21 new completions and would cross the current
250-completion boundary. Before requesting a larger budget, E5a isolates the
new critic with only three completions. It treats the already frozen E4 dry3
specialist and arbiter outputs as fallible, read-only semantic inputs and calls
only the current E5 critic once per trajectory.

This is a controlled component experiment, not a complete E5 result and not an
acceptance result. Its interpretation is limited to whether the critic can
correct the three observed E4 arbitration errors while holding all earlier
semantic judgments fixed. It cannot establish the accuracy of newly generated
E5 specialists or arbiter outputs.

Frozen source identities:

- E4 dry3 `predictions.jsonl` SHA-256:
  `8a59e45a0d154e1c536eed9fb843a3b1fe132bb14d17d8216194d776e6836dc8`;
- E4 dry3 `metrics.json` SHA-256:
  `ee90b59b88c5d16c540090a200ba6178d9547717a3c4272ef261b6295c08d255`;
- canonical JSON SHA-256 of the whitelisted
  `trajectory_id + trajectory_sha256 + raw_judge_outputs` replay inputs:
  `425e779480073ebeae30025bef8ca17b5097800f70eae406f999d1d66f2eec45`.

The replay workflow is deliberately split:

1. `prepare` reads the source artifact and writes sanitized Canonical Trace,
   specialist analyses, and initial-root inputs with no gold or score fields;
2. `predict` reads only that sanitized artifact, calls the critic, and
   atomically persists raw, unscored outputs;
3. `score` starts after prediction persistence and separately loads the
   dataset labels.

Before the three E5a calls, the predeclared gate is:

- all three critic outputs must pass strict parsing and evidence validation;
- Step Exact must be at least 2/3;
- Step+Module Exact must be at least 2/3.

Passing the gate supports requesting enough budget for a complete E5 tuning
run. Failing it rejects the current critic prompt as the source of improvement;
the result must not be rescued by reinterpreting initial-root fields or by
mixing E4 and E5 methods in a formal metric.

#### E5a result

E5a made exactly three logical completions in three HTTP attempts, with no
retry. Provider telemetry reported 78,856 input tokens, 543 output tokens, and
79,399 total tokens. All three outputs parsed; one was evidence-valid and two
were retained as `success_needs_review`.

| Metric | Result |
|---|---:|
| Step Exact | 0/3 (0.00%) |
| Step+Module | 0/3 (0.00%) |
| All Correct | 0/3 (0.00%) |
| Failed outputs | 0/3 (0.00%) |

The critic affirmed the incorrect initial roots for the ALFWorld and WebShop
cases. For GAIA it replaced the initial root with a different, also incorrect
memory diagnosis. It therefore failed both predeclared accuracy gates and does
not justify a complete E5 run.

Post-prediction tuning analysis found a single common mechanism: the prompt
asked the critic to construct a challenger silently, but the five-field output
contract did not prove that this occurred. The final rationales repeated
factual premises from the initial claims even when the timeline directly
contradicted them. Specifically, the judgments failed to:

- distinguish a reasonable first probe from later repetition;
- compare a later memory summary against an omitted earlier action-result pair;
- recognize within-turn repair before the plan/action;
- compare information-tool scope with task membership and ordering qualifiers;
- distinguish a visible option from a selected or verified value; and
- apply full-recovery and same-step commitment vetoes.

Artifact:

- `output/agenterrorbench-gpt-4.1-tuning-v1-e5a-replay-critic-dry3/`

Cumulative external usage through E5a is 233 logical completions.

### E5b explicit adversarial-audit critic

Falsifiable hypothesis: the E5a critic ignored its silent challenger
instruction. Requiring one structured initial-claim audit, one materially
different challenger, an explicit causal comparison, and then a separate final
root in the same semantic completion will make the counteranalysis observable
without introducing scores, confidence, voting, or deterministic selection.

The E5b output contains:

- an `initial_audit` verdict with exact evidence and reasoning;
- a complete `challenger` root whose step/module/type tuple must differ from
  the initial claim;
- a categorical `comparison.winner` (`initial`, `challenger`, or `other`) with
  causal reasoning; and
- the usual five-field `final` root, which remains the only scored judgment.

Strict code checks only schema, taxonomy, step mapping, challenger difference,
and final evidence. It never chooses or repairs a root. The prompt adds
general, trajectory-derived gates for factual-premise falsification,
first-attempt validity, memory-omission triples, within-turn repair,
information-action scope, recovery, UI option semantics, and terminal
commitment prerequisites.

E5b reuses the same frozen gold-free replay inputs and needs one completion per
trajectory. Its predeclared gate remains three valid outputs with Step Exact
and Step+Module both at least 2/3. It costs three new logical completions and
would bring cumulative usage to 236.

#### E5b result

E5b made exactly three logical completions in three HTTP attempts, with no
retry. Provider telemetry reported 78,943 input tokens, 1,627 output tokens,
and 80,570 total tokens. All three responses contained the required initial
audit, materially different challenger, explicit comparison, and final root.
All three final roots were retained as `success_needs_review`; none had a hard
parser, transport, or evidence-validation failure.

| Metric | Result |
|---|---:|
| Step Exact | 0/3 (0.00%) |
| Step+Module | 0/3 (0.00%) |
| All Correct | 0/3 (0.00%) |
| Failed outputs | 0/3 (0.00%) |

The explicit audit did falsify the incorrect initial ALFWorld and WebShop
claims, but its replacements were also wrong. It chose an ALFWorld action
symptom at step 4 instead of the step-5 history-to-memory omission, retained a
later GAIA answer symptom at step 4 instead of the first retrieval action at
step 1, and chose WebShop's repeated search plan at step 5 instead of the
step-7 plan-to-action commitment violation. The experiment therefore fails
both predeclared accuracy gates.

This result rejects the hypothesis that merely making a same-completion
challenger observable is sufficient. The remaining common failure is
cross-module ownership: the judge notices plausible bad behavior but does not
systematically compare the information entering one module with the output
passed to the next module.

Artifact:

- `output/agenterrorbench-gpt-4.1-tuning-v1-e5b-explicit-audit-dry3/`

Cumulative external usage through E5b is 236 logical completions.

### E5c isolated cross-boundary ledger and selector

Falsifiable hypothesis: module-local scans and same-completion critics miss the
released root because the decisive defect is often an information handoff:
history to memory, task/plan to action, or observation to reflection/plan.
Separating an unanchored handoff-ledger completion from an independent
critical-root selector will surface those local defects before any global
causal narrative can anchor the answer.

Call 1 sees only the frozen Canonical JudgeView and taxonomy. It must construct
an auditable ledger for:

- repeated or equivalent decisions, including the earlier action/result,
  current memory coverage, and the dependent current plan/action;
- retrieval actions, comparing all task membership and ordering qualifiers
  with the effective tool arguments;
- terminal or irreversible actions, comparing unresolved same-step plan
  prerequisites with the committed action; and
- other observation-to-reflection, memory/reflection-to-plan, action-interface,
  and runtime handoff violations.

It returns semantic candidates but does not rank or select a root. An
unexpected tool or environment result alone is not an action error: action
ownership requires a mismatch already visible between the current task,
observation, interface, plan, and issued action.

Call 2 receives a fresh JudgeView and the normalized ledger, but none of E4's
specialist outputs, initial roots, E5a output, E5b output, or labels. It applies
the original repository's holistic critical-error criterion: choose the local
error whose correction changes the observed failure path, while treating
normal early exploration and accurate reports of failure as non-errors. The
LLM alone returns the final step/module/type. Code performs only strict
contract, taxonomy, step mapping, evidence, identity, and gold-isolation
validation; there is no score, confidence, vote, weight, or deterministic
semantic selection.

E5c reuses the same three frozen gold-free replay inputs. Its predeclared gate
is:

- exactly two logical completions per trajectory, normally six total;
- all three ledgers and selectors pass strict parsing and final evidence
  validation;
- ledger candidate recall includes the released step and module for at least
  2/3 trajectories;
- final Step Exact and Step+Module are each at least 2/3.

Failure of either final accuracy gate rejects E5c for a full tuning run.
Passing permits, but does not itself authorize, a larger frozen tuning run.
The six calls would bring cumulative usage to 242.

The initial E5c report, produced before the evidence validator had an explicit
version identity, appeared to pass every accuracy gate:

| Metric | Historical unversioned E5c result |
|---|---:|
| Step Exact | 2/3 (66.67%) |
| Step+Module Exact | 2/3 (66.67%) |
| All Correct | 2/3 (66.67%) |
| Ledger candidate Step+Module recall | 2/3 (66.67%) |
| Failed outputs | 0/3 (0.00%) |

GAIA moved from the late final-answer symptom to the released step-1 action
scope defect. WebShop moved from the repeated-search symptom to the released
step-7 action commitment defect. ALFWorld remained at step 3 / planning and
the ledger did not surface the released step-5 / memory omission, so this
experiment does not establish perfect coverage of history-to-memory defects.

All three ledgers and selectors parsed. The then-current validator produced one
plain success and two `success_needs_review` results. Provider telemetry was
exactly six logical completions, six HTTP attempts, zero retries, 159,465 input
tokens, 5,379 output tokens, and 164,844 total provider-reported tokens. All
six responses finished with `stop`.

The unscored prediction SHA-256 is
`7a2522ffabd21eb8fa6a2c200e272b6b5549af05f1dcda4f0a1e9472e5b0ff70`.
That 2/3 is now retained only as a historical result. It was derived with an
unversioned, review-permissive evidence policy and is not eligible for
promotion. In particular, the WebShop final quote joins plan and action text
that is not one contiguous normalized string leaf in the linked immutable
event payload. Treating this as review-only would credit a prediction whose
required evidence contract is false.

Evidence validation is now explicitly versioned as
`agentdebug.evidence-validation.v2.strict-normalized-single-leaf`. The version
is part of every new E5c stage request identity, parsed cache, raw envelope,
unscored prediction, predict-run metadata, replay method contract, and scorer
check. The current scorer rejects the old derived E5c prediction and run
metadata with an explicit `evidence_validation_version mismatch`; it does not
silently reinterpret their old status fields.

The six original raw response envelopes remain immutable. A gold-free offline
tool verified their byte hashes, rekeyed copies under the current validator
identity in a new cache, reparsed both stages, and rebuilt every unscored field.
It made zero provider calls and did not load labels. Only after the new
unscored artifact was persisted did the independent scorer load tuning gold.

| Metric | Strict immutable-raw revalidation |
|---|---:|
| Step Exact | 1/3 (33.33%) |
| Step+Module Exact | 1/3 (33.33%) |
| All Correct | 1/3 (33.33%) |
| Failed outputs | 1/3 (33.33%) |

- ALFWorld: evidence-valid, but step 3 / planning is wrong against released
  step 5 / memory.
- GAIA: evidence-valid and correct at step 1 / action.
- WebShop: semantic tuple remains step 7 / action, but its evidence package is
  strictly invalid and receives no metric credit.

Therefore E5c fails its predeclared all-valid and 2/3 accuracy gates. It is not
promoted to the full tuning cohort or the formal `two_stage` candidate.
Cumulative external usage remains 242 because strict revalidation was purely
offline.

Artifacts:

- `output/agenterrorbench-gpt-4.1-tuning-v1-e5c-handoff-dry3/`
- `output/agenterrorbench-gpt-4.1-tuning-v1-e5c-strict-revalidation-dry3/`

The strict gold-free unscored SHA-256 is
`32e5eee921717d6b2ad3bfc2c1d8d2bea5f16c255bed492b4c1a7dc62d1d3ccc`;
the immutable-source provenance SHA-256 is
`f43e9486a67edf3a04cd273f4accc074faf98971c8449c7205aae8270212f7c1`.
The historical unscored file remains byte-identical at
`7a2522ffabd21eb8fa6a2c200e272b6b5549af05f1dcda4f0a1e9472e5b0ff70`.

Cumulative external usage through E5c is 242 logical completions.

### E5d predeclared one-call evidence-format repair

Falsifiable hypothesis: the single strictly invalid E5c final output has a
parsed, mapped semantic tuple but quoted a non-contiguous plan-plus-action
passage. One constrained LLM formatting pass can return a short, contiguous
quote from the already selected step without changing semantic diagnosis.

This experiment is predeclared before any request:

- eligibility is gold-free and mechanical: the original selector output must
  parse, map to one step, have a valid taxonomy pair, and fail only current
  strict evidence validation;
- the repair receives the fresh JudgeView and the frozen
  `critical_step/module/error_type/root_cause`; it may return only an evidence
  quote and cannot change or reselect the semantic tuple;
- at most one format-repair completion is allowed for the one eligible dry
  trajectory; there is no retry, candidate comparison, score, confidence,
  vote, or deterministic semantic repair;
- the returned quote must pass the same
  `agentdebug.evidence-validation.v2.strict-normalized-single-leaf` validator;
  otherwise the original result remains `evidence_invalid`;
- the gate is all three final outputs evidence-valid and Step Exact plus
  Step+Module Exact at least 2/3 after the independent scorer reloads gold.

The call budget is predeclared as cumulative 242 to at most 243. No E5d API
request has been issued.

E5d was then executed exactly once. The provider returned no usable assistant
text: the first HTTP response to the
`response_format={"type":"json_object"}` request had a non-JSON provider
envelope. The raw-first cache persisted the failure before parsing, the
predictor did not retry the failed semantic stage, and offline finalization
kept the original WebShop result as `evidence_invalid`.

| Metric | E5d strict result |
|---|---:|
| Step Exact | 1/3 (33.33%) |
| Step+Module Exact | 1/3 (33.33%) |
| All Correct | 1/3 (33.33%) |
| Failed outputs | 1/3 (33.33%) |

Transport telemetry is one logical completion, one HTTP attempt, zero retries,
8,950 request input characters, and no provider-reported usage or finish
reason. This rejects E5d as executed, but it does not test the evidence-repair
hypothesis because no LLM semantic or formatting output reached the parser.
It instead exposes a transport-capability gap: an OpenAI-compatible gateway
can reject or mishandle JSON mode with a successful HTTP status and a non-JSON
body, while the current fallback recognizes only explicit JSON HTTP 400/404/422
errors.

Artifacts:

- `output/agenterrorbench-gpt-4.1-tuning-v1-e5d-evidence-repair-dry3/`
- repair attempts SHA-256
  `8a3d693f844668ade409a15db530880b4ff29f1573fb91646d5c3ff6c48006d8`
- final unscored predictions SHA-256
  `90a23f53b907b9216a490d5063f80f667f4378adc702e4c675d70fdcf9adf7d4`
- metrics SHA-256
  `fe6276d96570fe3bfaee4f255132da10c432bf66235c0579d0f96d6257309e49`

Cumulative external usage through E5d is 243 logical completions.

### E5d-v2 predeclared JSON-mode capability fallback

Falsifiable transport hypothesis: Sophnet's OpenAI-compatible endpoint does
not reliably return a JSON error envelope when
`response_format=json_object` is unavailable. Treating a non-JSON 2xx
response only during the initial, still-unknown JSON-mode capability probe as
an unsupported probe, then retrying once without `response_format`, will
deliver the same constrained evidence-repair output. This is a transport-only
change; it does not alter the repair prompt or semantic decision.

Before any E5d-v2 request:

- reuse the exact E5d repair manifest, entry, frozen semantic tuple, source
  rows, strict evidence validator, and prompt SHA-256
  `2a2c78a433d3b849eaba12dcbb62b8f7aa2384bf531e0dd9b40fe33f9853672d`;
- use a fresh output and cache directory, with a bumped transport-policy
  identity, so the persisted E5d failure is neither overwritten nor treated as
  a successful cache entry;
- prefer `response_format=json_object`; only a non-JSON provider envelope from
  that initial capability probe may switch the provider instance to strict
  JSON-prompt fallback and trigger one HTTP retry without `response_format`;
- after the switch, another non-JSON provider envelope is non-retryable.
  Ordinary rate-limit, timeout, network, and 5xx handling remains governed by
  the frozen provider retry policy;
- do not retry any parser, taxonomy, step, evidence, or semantic failure, and
  do not offer a `retry_failures` path;
- count the whole probe/fallback sequence as exactly one logical completion
  and report every actual HTTP attempt separately.

The promotion gate is unchanged: all three composite outputs must be
evidence-valid, with Step Exact and Step+Module Exact each at least 2/3.
E5d-v2 is capped at one additional logical completion, bringing cumulative
usage from 243 to at most 244. Passing this dry gate permits consideration of
full tuning but does not authorize it.

E5d-v2 passed the gate:

| Metric | E5d-v2 strict result |
|---|---:|
| Step Exact | 2/3 (66.67%) |
| Step+Module Exact | 2/3 (66.67%) |
| All Correct | 2/3 (66.67%) |
| Failed outputs | 0/3 (0.00%) |

The sole repair completion succeeded and changed only the evidence field of
the frozen WebShop step-7/action/misalignment root. Independent scoring
reconstructed the E5c selector raw and E5d-v2 repair raw, then obtained one
wrong ALFWorld row and correct GAIA plus WebShop rows.

The request completed on its first JSON-mode HTTP attempt, so the newly tested
fallback was not exercised by this live request. The recorded capability was
`response_format_json_object=supported` with fallback count zero. Telemetry was
one logical completion, one HTTP attempt, zero retries, 2,236 provider input
tokens, 99 provider output tokens, and 2,335 total tokens, with finish reason
`stop`. This indicates that E5d's earlier non-JSON response was transient
rather than evidence that the endpoint consistently lacks JSON mode.

Artifact:

- `output/agenterrorbench-gpt-4.1-tuning-v1-e5d-v2-json-fallback-dry3/`
- repair attempts SHA-256
  `d587d02a84b4947abcae8b4b5fc3e5f9d9f2a55b0fe4d86ccf9d2608b0ae3ad9`
- final unscored predictions SHA-256
  `9a0d6a07a9ca756c5e612c0515d3eca77c655271cfd37642761cce74b20f3780`
- metrics SHA-256
  `12071ffea02488baf71525b1044e8d0800216bc888d6393a66f76abe7e75c9ff`

Cumulative external usage through E5d-v2 is 244 logical completions.

### E6 predeclared full-tuning production run

E5d-v2 passed its dry-three gate, so the production candidate is frozen as a
single gold-free pipeline:

```text
JudgeView
  -> E5c failure ledger
  -> E5c independent semantic selector
  -> conditional E5d evidence-only repair
  -> strict evidence validation
  -> persisted raw-chain reconstruction
  -> independent scoring after gold is loaded
```

The selector remains the only semantic classifier. Evidence repair is
mechanically eligible only when the mapped selector root has exactly one
strict error, `evidence_quote_not_found`; it may change only the evidence
quote. It cannot change the critical step/event, module, error type, or root
cause. No confidence, score, vote, deterministic finding, or semantic fallback
participates in the final classification.

Before any E6 provider request, a prepare-only command froze all 30 tuning-v1
JudgeViews in a gold-free prediction manifest. A write-once preregistration
then froze the manifest identity, exact trajectory and case-input identities,
20 production-code file hashes, prompt/pipeline/validator/transport versions,
public provider configuration, fresh output/cache paths, acceptance gates, and
the maximum paid-call envelope. The credential value is not present; only the
environment-variable name `API_KEY` is recorded.

The first E6 preregistration was then superseded before any provider request.
A completion audit found that its runtime path was correct, but the final
acceptance helper trusted caller-supplied aggregate metrics and was not exposed
as a CLI command. It could not independently bind the frozen smoke baseline,
raw prediction chain, scored predictions, metrics, report, or final file
hashes. No semantic prompt or classifier was changed.

E6-v2 adds only fail-closed experiment controls:

- a preregistration verifier runs in both the parent CLI and credentialed
  worker before any uncached completion;
- a formal run defaults to a 90-completion guard, rejects old output/cache
  state unless explicitly resuming the same hash-locked interrupted run, and
  records the preregistration identity;
- `artifact-manifest.json` binds the raw upstream artifacts and final
  predictions, CSV, metrics, and report by file SHA-256;
- `verify-final-smoke` reparses ledger, selector, and repair raw outputs,
  rebuilds all 30 scored rows, recomputes metrics and the report, checks the
  fixed configuration and gold isolation, and writes a self-hashed acceptance
  artifact;
- Step+Module non-regression is bound to the frozen baseline metrics file SHA
  `520749a1012b4187b455773ad5e8541216fd75e5588479af49132a0bacdafdd4`,
  whose aggregate baseline is 2/30.

E6-v2 frozen identities:

- prediction manifest file SHA-256:
  `0c719f41255eb20f53ad233f18dd3fadf64c5b8f9f2df8980951279e1967f7b4`;
- prediction manifest content SHA-256:
  `651acd1fa0dff6eae945406ad9cbe9f6c527cdff67b45874e0fac23576f785ad`;
- code-bundle SHA-256:
  `ac7cf0386510baf808db47388aa4f280cecae490d46f09372d15f82f806b39e0`;
- preregistration self-hash:
  `11b5f9fe8af3fab34d7a0089e978d55ba2f1a3a968e4c9907d701c116bef35f2`;
- preregistration file SHA-256:
  `ef9422b24b0ffa9deb76c4c609cac72ef1fea16c13cb91648551dd62f0e55cd2`.

All file, content, code-bundle, and preregistration self-hashes were
independently recomputed successfully. The complete local suite passes
246 tests.

The E6 call rule is one ledger completion per trajectory, one selector
completion only after a parseable ledger, and one repair completion only for a
mechanically eligible selector. Therefore the run uses at most 90 new logical
completions. A run-local guard stops before an uncached completion would exceed
that bound; cache hits do not consume the budget. Starting from cumulative
usage 244, the preregistered hard cumulative stop is 334.

Promotion requires all of the following on the fixed 30-row tuning cohort:

- Step Exact at least 12/30;
- Step+Module Exact at least 12/30;
- zero final `evidence_invalid` rows;
- at most one other hard failure;
- every eligible repair attempted, zero semantic mutation, and complete
  provider telemetry coverage;
- successful gold-isolation and raw-chain reconstruction checks.

The prepared artifacts are in
`output/agenterrorbench-gpt-4.1-tuning-v1-e6-v2-production-full30/`. The
superseded, unexecuted first preregistration remains in its original directory
for audit history. No E6 or E6-v2 provider request has been issued. Execution
requires explicit authorization to raise the cumulative logical-completion
ceiling beyond 250.

After that authorization, the frozen E6-v2 command is:

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. \
python3 -m agentdebug.benchmark.cli run \
  --dataset data/AgentErrorBench \
  --cohort-manifest benchmarks/cohorts/tuning-v1.json \
  --prepared-prediction-manifest \
    output/agenterrorbench-gpt-4.1-tuning-v1-e6-v2-production-full30/prediction-manifest.json \
  --preregistration \
    output/agenterrorbench-gpt-4.1-tuning-v1-e6-v2-production-full30/preregistration.json \
  --output-dir \
    output/agenterrorbench-gpt-4.1-tuning-v1-e6-v2-production-full30 \
  --cache-dir \
    output/agenterrorbench-gpt-4.1-tuning-v1-e6-v2-production-full30/cache \
  --methods two_stage \
  --judge-provider openai-compatible \
  --judge-base-url https://api.sophnet.com/v1/chat/completions \
  --judge-api-key-env API_KEY \
  --judge-model gpt-4.1 \
  --judge-temperature 0 \
  --judge-timeout 600 \
  --judge-max-output-tokens 8192 \
  --judge-max-retries 5 \
  --judge-retry-backoff 2 \
  --workers 1 \
  --max-logical-completions 90
```

The CLI and credentialed worker both recompute the preregistration before the
first uncached completion. Any changed code, manifest, prompt identity,
provider setting, output/cache path, or budget makes the command fail closed.

### Superseded E5 seven-call gate

Before E5a–E5c, the predeclared gate for the earlier seven-call E5 design was:

- all three reports must complete without parser, transport, or evidence
  validation failure;
- final Step Exact must be at least 2/3;
- final Step+Module Exact must be at least 2/3.

Failure of either accuracy gate rejected E5 for a complete tuning run. That
design was not run because its dry trio required 21 logical completions and
would have brought the then-current cumulative usage to 251. The unversioned
E5c report initially appeared to supersede this gate, but strict immutable-raw
revalidation later rejected E5c for promotion.

## Budget boundary

Cumulative usage is 244. E5d-v2 passed its dry gate, and the full 30-row E6-v2
production implementation, gold-free manifest, code bundle, promotion gates,
and `30 + S + R <= 90` logical-completion envelope are now frozen. The run
cannot remain below the current 250-call authorization ceiling. No E6
full-tuning or smoke request has been issued; both remain unauthorized until
the user explicitly raises the ceiling.

## Held-out inspection hygiene record

During the 2026-07-27 continuation, a command intended to print only aggregate
baseline fields accidentally serialized the complete nested `metrics` object.
That object can contain per-trajectory smoke error rows. This happened after
the E5c semantic design and E5d evidence-only hypothesis, prompt, eligibility
rule, dry-three inputs, and request budget had already been frozen. No prompt,
semantic rule, cohort membership, or prediction has been changed using those
rows.

From this point onward:

- no smoke prediction or per-trajectory metric artifact may be opened during
  development;
- E5d remains the already-predeclared evidence-only experiment and cannot
  change any semantic tuple;
- any later semantic experiment, if E5d is not promotable, must be designed in
  a clean-context worker using tuning-v1 only; and
- the exact production code, prompt hashes, and acceptance command must be
  frozen before the one final smoke run.

The final report must disclose this incident. A passing final run can show
fixed-cohort consistency and payload-level gold isolation, but it must not be
described as a pristine human-blind held-out evaluation.

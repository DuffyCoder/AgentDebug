# E9 v54 workflow patch-context failure case study

## Failure and attribution

The first combined workflow patch expected a local `profiles = {...}` block,
but the actual budget function returns profile objects through a different
source layout. `apply_patch` rejected the complete patch atomically; no
workflow edit from that attempt was applied and no provider call occurred.

## Correction

Read the exact top-level identities, failure-boundary text, and budget function
and patch each separately. Preserve v54's historical start at 642 and the
phase-exact budgets of 2, 20, and 44 logical completions.

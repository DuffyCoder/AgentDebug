# E9-v56 conservative incumbent review dry3 failure case study

## Result

v56 used one DeepSeek Flash completion (cumulative 646 -> 647). All three case
outputs parsed successfully, but Step Exact was 1/3, below the frozen 2/3 dry
gate. Full30 was not run.

## Per-case behavior

1. ALFWorld step-limit case: v30's gold-correct step 30 system/step-limit was
   kept. v56 remained correct.
2. GAIA GitHub issue case: v30's gold-correct step 1 action/misalignment was
   replaced with step 4 planning/constraint-ignorance. The reviewer selected a
   later unsupported final answer even though the incumbent identified the
   first tool/action mismatch that made the requested fact structurally
   unobtainable. This replacement caused the regression.
3. WebShop paging case: v30's incorrect step 8 planning/inefficient-plan was
   kept; gold is step 13. The result remained incorrect.

## Root cause

The natural-language "preserve unless materially better" burden was too soft.
The reviewer interpreted a mature downstream error as more specific and
overrode a correct first-defect incumbent. The prompt therefore reproduced the
same later-symptom attraction that v30's first-defect audit was designed to
avoid.

The failure is not formatting-related: 3/3 responses were valid. It is a
semantic arbitration failure. The reviewer needs an explicit temporal boundary
that operationalizes conservative review rather than merely describing it.

## Next experiment

The next candidate still branches from frozen v30. It may learn from this dry
failure but must not use v56 predictions as its semantic input.

Use an **earlier-only replacement contract**:

- `keep` must reproduce the incumbent root;
- `replace` is permitted only with a strictly earlier critical step;
- a later or same-step alternative can never replace v30;
- an earlier imperfection still must be locally observable, causally
  contributing, and unrecovered.

This protects both gold-correct v30 dry incumbents. It also targets the only
known v30/v31 union gains, which are all earlier than v30, while retaining the
causal-evidence burden needed to reject generic early imperfections. Final
semantics remain the new LLM's raw output; code may reject contract violations
but must never copy or overwrite v30 semantics deterministically.

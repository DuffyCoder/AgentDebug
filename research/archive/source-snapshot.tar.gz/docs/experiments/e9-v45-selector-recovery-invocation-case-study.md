# E9 v45 Selector recovery invocation case study

## Outcome

The first local `freeze-code` invocation exited before argument handling with
`ModuleNotFoundError: agentdebug`. No archive, preregistration, completion
ledger, provider client, HTTP request, or benchmark prediction was created.

## Attribution

The recovery utility was invoked as `python3 scripts/recover_e9_v45_selector.py`.
In that execution form Python places `scripts/`, rather than the repository
root, at the front of `sys.path`. The utility imported `agentdebug` before
establishing the repository root, so startup failed. This is a command-entry
packaging error and provides no evidence about the v45 semantic hypothesis or
DeepSeek provider.

## Correction and next check

The script now derives its repository root from `__file__` and adds that root
to `sys.path` before importing AgentDebug. The correction changes only local
entry-point loading; it cannot alter the reconstructed prompt, request hash,
candidate response, or final LLM judgment. The full local test suite must pass
again before freezing the changed script. No LLM call may occur until then.

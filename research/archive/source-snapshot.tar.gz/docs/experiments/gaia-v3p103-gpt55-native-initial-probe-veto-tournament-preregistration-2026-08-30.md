# GAIA v3.103 GPT-5.5 native initial-probe-veto tournament preregistration

Date: 2026-08-30

## Frozen scope

- Direct semantic parent: accepted v3.83, Step Exact `26/50`.
- Rejected v3.90--v3.102 versions are not semantic parents and their full
  prompts/protocols are not cumulatively inherited.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Dataset SHA-256:
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort SHA-256:
  `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Model/reasoning effort: `gpt-5.5` / `medium`.
- No smoke gate; run the full GAIA-50 directly.
- Freeze and pass gold-free access plus every schema/taxonomy/evidence/order
  validator before labels are loaded.
- Accept only at Step Exact `>26/50`; Goal completes only at `>=30/50`.

## Single major mechanism

From clean v3.83, replace its challenger/arbiter with one outcome-conditioned
predicate-handoff tournament over the native v3.83 ledger, subject to exactly
one hard semantic constraint:

> A native ledger row whose `lane_c` is exactly `veto_initial_probe` must be
> reviewed but must have `boundary_verdict=false` and cannot win.

The constraint is uniform. It does not apply to `veto_different_probe`, to
unvetoed rows, to an entity/site/source model, or to a trajectory identity. It
contains no label, historical prediction, or fixed Step. The runner's three
fresh attempts and audited staged transport are Step-invariant execution and
legality machinery, not additional selection rules.

## Falsifiable impact registration

Post-score v3.102 analysis found that native initial-probe-veto overrides
contained two gains and nine losses. On frozen v3.102 selections, restoring
only this veto yields descriptive Step Exact `28/50`. This motivates the
mechanism but does not determine v3.103 outputs: v3.103 will execute fresh
gold-free anchors and tournaments for all 50 cases.

Expected benefit: reduce false prefix overrides of reasonable initial probes.
Expected regressions: lose cases where the released benchmark treats the
initial probe's observed unresolved outcome as the critical boundary. The
hypothesis is rejected if the legal full run scores `<=26/50`, even if it
matches the descriptive counterfactual on some cases.

## Pre-inference hashes

- Protocol:
  `a90e476519f8dd6911584674a379533d2197bf79dac595ba1027573c2fed8643`.
- Runner:
  `59aea742b98e6a8aad54d4ba23a39d6a77db9e7944fe2c8eb7e4f7e14caf1f03`.
- Inspector:
  `605b1473ff18fe0c7ddadf8f47074e23c689f4328137be297c86c75141a97160`.
- Test:
  `5f64cf9238fbc2aa751b95176142a75c295011b05708213abab8549596cc2199`.
- Registry:
  `190898569d1df219373c9d70e76735e206499a76b52f57de4bc2d03ddb68cae3`.

Offline verification before freeze: compilation passed; 50-case dry
preparation preserved the frozen cohort/model/effort and exactly three attempts;
the four v3.103 tests, four v3.102 tests, and five v3.101 tests passed in
isolated processes. This version is frozen before inference.


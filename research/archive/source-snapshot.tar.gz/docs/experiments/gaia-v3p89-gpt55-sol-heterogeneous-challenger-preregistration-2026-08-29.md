# GAIA v3.89 GPT-5.5/Sol heterogeneous challenger preregistration

Date: 2026-08-29

## Frozen identity

- Version: `agentdebug.codex-agent-judge.gaia-v3.89-gpt55-sol-heterogeneous-challenger`.
- Direct semantic parent: accepted v3.83, Step Exact `26/50`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Dataset manifest identity SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort identity SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Cohort manifest file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Frozen v3.83 protocol SHA-256: `a97908a78cec8df5fe9e4777d30aa9ecf498d1cdd1d692a42cc66976e9844531`.
- Frozen v3.83 runner SHA-256: `a1613a04ad21b3306c61cd3082753ff5890ad09ab3d939f4c292c15e1dac483d`.
- Frozen v3.83 predictions SHA-256: `f74161b06c456461ccacdcf7c708157154e8e9810cb5dffa8ef09352698fca3d`.

## Prior falsification evidence

Rejected v3.87 and v3.88 tested progressively more explicit same-model causal
representations. v3.87 scored `18/50`; its 13 proposals contained one exact
Step and repaired no frozen v3.83 error. v3.88 scored `22/50`; its four sparse
graph proposals contained zero exact Steps and direct accepted overrides caused
zero gains, two losses, and one wrong-to-wrong move. The graph mechanism again
repaired none of v3.83's 24 errors.

The shared failure is candidate-source dependence: the same GPT-5.5 judge that
made the anchor decision rarely proposes a benchmark-correct alternative, even
when required to narrate or graph the complete causal path. Adding more
same-model prompt structure has increased complexity without improving frozen
incumbent-error recall.

## Single major change

Keep the complete v3.83 protocol semantics and change only the model executing
the fresh challenger stage:

- packet-state anchor: `gpt-5.5` / `medium`;
- exact v3.83 earliest-causal challenger: `gpt-5.6-sol` / `medium`;
- exact v3.83 default-keep arbiter: `gpt-5.5` / `medium`.

After version and truthful model metadata are normalized, the anchor,
challenger, and arbiter tasks are byte-identical to v3.83. Candidate schema,
one-proposal maximum, direction restriction, anchor falsifier, validator,
exact-copy selection, case order, concurrency, and retry policy are unchanged.
No v3.86-v3.88 prompt, graph, ledger, prediction, or scored artifact is an
inference input or semantic parent.

## Falsifiable hypothesis and risk

A heterogeneous challenger may supply complementary candidate evidence and
recall a gold Step omitted by the GPT-5.5 anchor without changing the accepted
anchor's own decision rule. The existing conservative GPT-5.5 arbiter should
reject unsupported alternatives.

The mechanism is falsified if final Step Exact is `<=26/50`, if the Sol
challenger does not improve proposal recall on incumbent errors, if accepted
challenger regressions offset gains, or if any legality check fails. Main risks
are increased proposal volume, Sol runtime failures, and rhetorically diverse
but noncritical candidates bypassing the arbiter.

Post-score proposal recall and direct override precision are diagnostic only.
They do not select the version.

## Acceptance and Goal completion

- Accept only if Step Exact is strictly greater than `26/50` and every legality check passes.
- Complete the Goal only if Step Exact is at least `30/50` and every legality check passes.
- Only Step Exact selects, accepts, rejects, or completes versions.
- No smoke gate is used; after offline validation run the complete GAIA-50 directly.

## Pre-inference freeze

- Protocol source SHA-256: `2b2420d23f36bc364e357d16a259eb4af9352ebbb8c55e80f2b1031ed569e0d4`.
- Runner source SHA-256: `fcc9210c04f9574a23b3ba94f3c722aeb4919516fc60fa93115d4e32906f019e`.
- Negative/identity test source SHA-256: `d9072b1cb4604e7c3b660d92cefdd3c24ab4a1f5acabd2b1f3e40c918abc80c2`.
- Frozen tuning plan SHA-256: `20b6c07ab23f87331110a1eb949ef28a3afba51f044f84dfa1e3174d0bbd930e`.
- Offline validation: 21 targeted and inherited tests passed; compilation,
  registry, direct-parent identity, exact task normalization, stage-specific
  command routing, truthful audit provenance, and 50-case dry preparation passed.
- Static inference-source scan found no label, metric, scored artifact,
  historical prediction, rejected mechanism import, case/entity router, or
  post-score audit reader.

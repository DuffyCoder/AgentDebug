# E9-v23 Dry3 Failure Case Study

## Attempt and formal result

E9-v23 used one default-body `deepseek-v4-flash` logical completion from
cumulative 371 to 372.  The provider returned HTTP success,
`finish_reason=stop`, 647 output tokens, and no retry.  However,
`choices[0].message.content` was the empty string, so all three cases failed
closed as `empty_response`/`invalid_json` and scored zero.

This is not the previously observed extra-brace defect.  The raw cache and
response sidecar both bind the exact empty final content.  No semantic result
can be recovered from it.

## Root attribution

DeepSeek's current official V4 documentation states that thinking mode is
enabled by default and that thinking output is returned in
`message.reasoning_content`, separately from the final `message.content`.
The v23 telemetry is consistent with a response that spent tokens in thinking
but emitted no final answer.  The current adapter intentionally reads only
final content and does not substitute private reasoning for the requested
JSON.  Because the raw HTTP payload was not persisted, the presence of
`reasoning_content` is an evidence-based inference, not a recovered response.

## Bounded optimization hypothesis

E9-v24 keeps the user's requested default request body and does not add a
`thinking` option.  It keeps the v23 semantic prompt unchanged, but explicitly
instructs the model that after internal reasoning it must place the strict JSON
object in the final `message.content` field and that an empty final content is
invalid.  The adapter remains deliberately conservative: it does not store or
use `reasoning_content`, and an empty final content continues to fail closed
without an automatic retry.

The next dry3 costs one logical completion from 372 to 373.  Full30 would end
at 383 and remains outside the current authorization ceiling of 380.

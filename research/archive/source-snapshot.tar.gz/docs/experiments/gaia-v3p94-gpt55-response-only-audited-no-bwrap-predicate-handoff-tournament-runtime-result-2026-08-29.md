# GAIA v3.94 runtime result

Date: 2026-08-29

v3.94 is **runtime-incomplete and unscored**. Its full-run invocation began,
but the first four completed anchor stages all failed deterministically before
reducer inference with `response-only contract marker changed unexpectedly`.
The response-only injection recognized the anchor prompt marker only; the
reducer prompt uses a distinct `BOUNDED TOURNAMENT` marker. Continuing the
remaining cases would have repeated the same deterministic task-construction
failure, so the process was stopped and all existing artifacts were preserved.

The first divergence is `runtime_or_validation_failure`. The minimal uniform
correction is to inject the identical response-only contract through one stable
anchor marker and one stable reducer marker, with an offline test that builds
both actual tasks. No Judge decision rule, prediction, label, or score was read
or changed.


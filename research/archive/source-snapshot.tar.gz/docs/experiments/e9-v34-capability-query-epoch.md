# E9 v34: capability contract and query epochs

## Scope

v34 keeps the v33 two-call architecture: the Candidate supplies an untrusted
proposal and the independent Selector's raw response is the sole source of the
final semantic diagnosis. No deterministic finding, score, confidence,
weight, vote, semantic mutation, or fallback is introduced.

## Failure-driven calibration

The rejected v33 dry3 run remained at 1/3. It fixed the ALFWorld system
boundary but exposed two narrower problems:

- The Selector treated a static page-text extractor over a dynamic collection
  as a reasonable probe, even though the plan required collection filtering,
  ordering, and label-event history that the selected representation could
  not expose.
- Both active stages carried no-progress evidence from an old product query
  into a new page-one query epoch and therefore localized the query reset
  itself instead of the later mature paging loop.

v34 adds two qualitative LLM judgment distinctions:

1. A poor result does not prove capability mismatch, but the declared
   operation contract plus selected representation can. A static text view of
   a dynamic collection cannot establish required collection ordering,
   filtering, or historical events.
2. A changed query that returns a new page-one result set resets paging
   maturity. The new query becomes inefficient only at the first later plan
   where its own displayed total, populated-page coverage, explicit
   no-progress evidence, and unchanged list-only continuation jointly show a
   mature loop.

The v33 system-boundary rebuttal is preserved.

## Frozen topology

- dry3: cumulative 444 to 446, exactly Candidate + Selector.
- full30: cumulative 446 to 466, exactly 20 new tuning misses after dry reuse.
- smoke30: cumulative 466 to 510, exactly 44 fresh four-stage misses.

Every failed LLM/benchmark attempt still requires a completed case study
before another attempt.

# Luna GAIA v3.16 Bounded Bidirectional Challenger Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia-v3.16-bounded-bidirectional-challenger`
- Semantic parent: accepted
  `agentdebug.codex-agent-judge.luna-gaia-v3.14-earliest-causal-challenger`
- Rejected comparison: v3.15 packet-handoff closure, Step Exact `20/50`
- Current incumbent: v3.14, frozen GAIA-50 Step Exact `24/50`
- Original comparison baseline: v3.4, frozen GAIA-50 Step Exact `21/50`
- Dataset/cohort: frozen `gaia-paper-v1`, 50 cases
- Dataset manifest content SHA-256:
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort file SHA-256:
  `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Cohort content SHA-256:
  `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Prediction manifest file SHA-256:
  `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Prediction manifest content SHA-256:
  `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Goal completion condition: full GAIA-50 Step Exact `>= 30/50`
- Version acceptance condition: full GAIA-50 Step Exact `> 24/50`, with every
  legality and freeze check passing
- Smoke gate: none

Step Exact is the only optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module, type, and evidence remain legality constraints.

## Audited reason for this version

The accepted v3.14 has 26 Step errors. Its largest directly actionable cluster
contains eight fine-grained boundary misses whose gold boundary is strictly
earlier than the frozen anchor. Because v3.14's challenger is later-only, those
misses are structurally unrecoverable once the anchor freezes.

v3.15 tested the smallest inline-anchor closure for those same result-to-state
and target-to-Action handoffs. On the full frozen run it repaired only one of
the eight target errors, left six unchanged, made one later, and regressed eight
incumbent-correct cases. It also admitted successful scalar-string calls as
early parameter errors without literal tool rejection. Therefore the hypothesis
that more anchor prose can reliably close these boundaries is falsified.

The remaining common defect is stage topology: a fresh challenger can compare
the complete timeline against a frozen anchor, but its validator and prompt
forbid it from proposing the strictly earlier handoff boundary.

## Single major change

Keep the v3.14 anchor exactly unchanged. Change only the challenger search
domain from later-only to bounded bidirectional, while retaining at most one
proposal and a default-keep exact-copy arbiter.

The challenger performs these searches in order:

1. Earlier handoff search. It may propose the earliest strictly earlier Step
   only when the anchor is a downstream restatement or symptom and the earlier
   Step contains a literal task-material result-to-state or target-to-Action
   mismatch.
2. If no earlier proposal passes, run the unchanged v3.14 earliest-causal later
   search. At most one proposal may exist across both directions.

An earlier proposal must satisfy all three gates:

- necessity: the lost or contradicted fact, target, predicate, or route is
  necessary for a still-open task condition;
- literal boundary: the mismatch is directly visible in the task and adjacent
  packets at the proposed Step;
- path effect: repairing the proposed handoff can change the retained state or
  subsequent action path, while repairing only the anchor symptom cannot repair
  the earlier defect.

Successful execution of an accepted string/scalar parameter, harmless summary
compression, a first useful acquisition probe, a materially different evidence
route, a normal tool failure, or a merely improvable action cannot qualify as
an earlier challenge. The arbiter must keep the anchor under uncertainty and
may select only the exact anchor or exact single proposal.

No case identifier, entity-specific rule, source-model rule, gold rationale,
historical prediction, score, or candidate census is visible during inference.

## Falsifiable impact analysis

Expected repair surface: up to eight v3.14 errors in the common fine-grained
candidate-recall cluster. These are all later-than-gold anchors and therefore
share the newly opened search direction. A result materially below six net
repairs will not itself complete the Goal, but any score above 24 may become the
next incumbent if all legality checks pass.

Primary regression surface: incumbent-correct early capability, table,
parameter, and explicit-state roots could be displaced by an attractive but
noncritical predecessor. The one-proposal bound, earlier-first materiality
gates, successful-execution veto, and default-keep arbiter are the negative
controls. The expected direction is earlier only for accepted earlier
challenges; the unchanged v3.14 later path may still move an anchor later.

Candidate flooding is a direct falsifier: the mechanism fails if it produces
multiple candidates, broad speculative earlier overrides, or a regression rate
that exceeds its repaired target cases. This is a cluster-level hypothesis on
the exposed GAIA-50 tuning scope, not a claim about unknown-data generalization.

## Offline validation and execution decision

Before the full run, require:

- compilation and workflow registration;
- prompt tests proving the v3.14 anchor text is unchanged;
- prompt tests proving the challenger has an earlier-first, single-proposal
  contract and preserves the v3.14 later fallback;
- validator tests accepting legal earlier and later challenges, rejecting an
  equal-Step proposal, rejecting incompatible classifications/directions, and
  enforcing literal owned evidence plus exact-copy arbitration;
- runner plan validation for 50 cases, 150 planned sessions,
  `gpt-5.6-luna`, medium effort, and no smoke gate;
- source-input scans showing no labels, scores, historical predictions, case
  routing, or post-score audit artifacts are exposed.

Then run the complete GAIA-50 directly. Freeze predictions and every intermediate
artifact under gold-free validation before scoring.

- If Step Exact is at most `24/50`, reject and freeze v3.16.
- If Step Exact is `25..29/50`, accept it as the next incumbent only after all
  checks, audit every Step error, and continue versioned iteration.
- If Step Exact is at least `30/50`, run the final acceptance audit and complete
  the Goal.

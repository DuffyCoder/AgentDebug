# Luna GAIA v3.73 预注册：exact-predicate reducer，access auditor filename 修正

状态：执行前冻结。

## 冻结实验合同

- semantic parent：accepted Luna v3.20，Step Exact `25/50`。
- 版本：`agentdebug.codex-agent-judge.luna-gaia.v3.73-clean-v3.20-exact-predicate-acquisition-boundary-reducer-auditor-corrected`。
- 数据集：冻结 `gaia-paper-v1` 50 例。
- 模型/effort：`gpt-5.6-luna` / `medium`。
- v3.4 基线：Step Exact `21/50`。
- 接受：合法完整 GAIA-50 Step Exact `>25/50`。
- Goal 完成：合法完整 GAIA-50 Step Exact `>=30/50`。
- 无 smoke 门控；直接完整 GAIA-50。

唯一主要语义机制仍是从 v3.20 clean branch 单独移植的 `exact-predicate acquisition
boundary reducer`。v3.20 anchor、owner-explicit input、evidence materialization、candidate
binding veto 和 deterministic selector 均与 v3.72 相同。不继承 rejected lineage 的其他
机制；semantic parent 始终是 v3.20，推理不读取历史逐例预测。

## v3.72 first divergence 与唯一 auditor 修正

v3.72 的 50/50 cases 和 100/100 stages 全部完成，所有 per-stage schema/evidence validator
通过；6 次 invalid Agent evidence exact-copy 和 1 次 unbound candidate veto 均有
materialization record。评分前 access audit 的 topology、tool-free、read-only、case routing、
hash consistency、unexpected files/directories 均通过，但 auditor 的 required-files 集合仍
硬编码旧名 `compact-inference-document.json`，因而把 101 个实际存在且逐 stage 通过
inference-document validator 的 `owner-explicit-inference-document.json` 误报为缺失。
评分未开始、gold 未读取；v3.72 仍按冻结纪律拒绝。

v3.73 只修正 access auditor 的这一文件名映射：每个旧 required path 必须有同目录的
owner-explicit document，且除这些 stale-name 项外不得有任何其他 missing/unexpected/
tool/runtime/topology 失败，才可通过。protocol prompt、模型 response、normalizer、validator、
selector 和所有 Step 语义均不改变；仍重新运行完整 50，绝不复用 v3.72 预测。

## gains、regressions 与判伪

Step gain/回归仍完全由 exact-predicate reducer 决定。auditor 修正不改变 predicted Step；
风险是错误地掩盖真实缺失文件，因此通过条件要求旧名与 owner 文件逐目录一一映射，并保留
所有其他审计失败。直接反例是 frozen v3.72 topology 不能在该窄映射后通过，或任何非旧名
missing 项被消除。

若相对 frozen v3.20 gains 不大于 losses、final Step Exact `<=25/50`，或 50/50、schema、
taxonomy、evidence、hash、gold-free、tool-free、write-topology 任一验证失败，则拒绝。
只有合法 `>=30/50` 才完成 Goal。

## 执行前冻结哈希与离线验证

- protocol：`b70d58c50bbc3c3a61ab5bd09e000fb32a9dc316ea721d762b22b6b7b5c126a0`
- runner：`420d25f3a6d08178a024ad92d4e017ad101d89e1255ca038047fc49fa2641c2c`
- access auditor：`d761427fee7b4b734eb50a994d0815c5949ea886d4b1bce3f229bcb4f271a63f`
- registry：`6c4b89000c648f893b9b64f490c8e4a447891d4b010144b8885f12d943688cfd`
- tests：`926f304624a0a76036f7637b9c90a8d9996c9d466ec28b185f9d1f1d9be5f9ae`
- taxonomy：`d7e4b878059bbecec0a8fd3f078c0aeb5755bf9e65bb938c897dd83685f28c5c`
- semantic parent v3.20：`3e886325bf0a4b4d4a3e770071c0a36fe81dab2bebaf5015561ca828b6c2e4f9`
- prediction manifest：`77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- cohort：`31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`

离线验证：v3.73--v3.66 及 v3.20 相关测试 `49 passed`；compile、registry、真实 executor
protocol-interface inventory、50-case dry plan、100 sessions、direct parent 与 v3.72 prompt
semantic parity 全部通过。修正后的 auditor 对 frozen v3.72 run 验证 101 个逐目录映射后
通过，且 missing=0、其他审计失败仍为 0。

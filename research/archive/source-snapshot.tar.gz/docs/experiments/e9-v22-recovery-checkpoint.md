# E9-v22 Flash Recovery-Checkpoint Critic

E9-v22 is the bounded follow-up to the rejected v21 dry3 case study.  It
retains the v21 format contract verbatim: the model selects an owner-bound
evidence source ID, code projects the exact source preview, raw responses stay
immutable, and only the already observed single unmatched final object-close
may be removed for structural parsing.

The semantic delta is limited to recovery ordering.  Each case's review must
name an earlier material candidate step or null and a later recovery step or
null.  A recovery must occur after the candidate and must reconnect to all
unmet task constraints.  A constraint-preserving rewritten acquisition query
starts a new episode even if many keywords overlap.  Conversely, changing
tools or choosing another item is not recovery when the required collection,
order, filter, or history fact remains unacquired.

The operation-ownership rule also recognizes a visible representation
mismatch: a generic page-text extraction operation aimed at a dynamic
search/index collection cannot be assumed to enumerate, order, or expose
historical changes for the collection.  When the task requires those facts
and the action relies on that representation to supply them, the action can be
`action/misalignment` even as a first probe.

The dry3 budget is 370 to 371.  Full30 is 371 to 381 and therefore fails
closed under the current user-authorized ceiling of 380.  A future held-out
fresh run would begin only after the accepted full phase and use 33 logical
completions from 381 to the implementation ceiling 414.

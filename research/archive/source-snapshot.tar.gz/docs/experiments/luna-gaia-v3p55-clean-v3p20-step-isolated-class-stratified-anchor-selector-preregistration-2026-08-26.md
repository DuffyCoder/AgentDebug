# Luna GAIA v3.55 Class-Stratified Anchor Selector Preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.55-clean-v3.20-step-isolated-class-stratified-anchor-selector`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: Luna v3.20, Step Exact `25/50`
- Original v3.4 baseline: Step Exact `21/50`
- Version acceptance: Step Exact `> 25/50`
- Goal completion: Step Exact `>= 30/50`
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort semantic SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Cohort file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none

Step Exact is the sole optimization, comparison, acceptance, rejection, and
Goal-completion metric. Module/type/evidence remain legality constraints only.

## Parent and rejected-lineage boundary

v3.55 is a clean child of accepted v3.20. No v3.54 prediction, local record,
matrix, proposal, duel, hidden state, scored artifact, case route, or per-case
result is an inference input. v3.54 is rejected at `18/50` and is not the
semantic parent.

The only explicitly retested evidence contract is a fresh Step-isolated,
prefix-bounded local census with promotion-safe System owner sources. v3.54's
anchor-blind single-proposal compressor and separate default-keep duel are
removed. This is a clean transplant of one unified challenger mechanism, not
inheritance of a rejected protocol stack.

## Frozen v3.54 falsifier and selected cluster

The frozen v3.54 audit found:

- fresh anchor `21/50`;
- gold Step local-positive coverage `31/50`;
- fresh-anchor plus any local-positive oracle `36/50`;
- fresh-anchor plus single-proposal oracle only `24/50`;
- final `18/50`, with duel gains/losses `1/4`.

Among the `32` final errors, `10` are high-recall/global-compression gaps, `2`
have the gold proposal present but lose at the duel, `4` are false overrides of
a gold anchor, `11` are Step-local recall gaps, and `5` are annotation
ambiguities. v3.55 targets only the common downstream compression/selection
mechanism. It does not relax local admission.

## Single major mechanism

Add one class-stratified, anchor-aware critical-boundary selector to otherwise
unchanged v3.20 semantics:

1. run one fresh prefix-bounded taxonomy-only local review for every legal
   Step and freeze every validator-bound positive row;
2. deterministically retain the complete positive matrix until the final
   selector; do not create a single lossy proposal first;
3. in one anchor-aware session, review every positive row and export at most one
   representative for each generic boundary class: state truth, constraint
   alignment, capability commitment, post-feedback recommitment, and terminal
   abandonment;
4. within each class choose the earliest mature causal boundary, not the most
   emphatic or persistent symptom;
5. select exactly the fresh v3.20 anchor or one exact-copy representative;
6. override the anchor only when a structured two-sided relation states both
   that anchor-only repair leaves the representative independently
   failure-causing and representative-only repair can materially redirect the
   failed path. A reasonable initial probe, recovered defect, normal tool
   failure, faithful propagation, mechanical predecessor, or downstream symptom
   cannot satisfy this relation by assertion alone.

This replaces both v3.54 downstream stages with one frozen artifact contract.
It changes no v3.20 anchor admission, ledger, Step freeze, owner binding,
taxonomy, model, effort, or evidence validator.

## Expected gains and regression risks

Expected Step gains are concentrated in the `10` cases where gold already
survived as a local row but single-proposal compression discarded it, plus the
`2` proposal-present selection gaps. The mechanism is intended to prevent the
five observed `none` compressions with nonempty matrices and reduce late-symptom
preference by comparing bounded class representatives chronologically.

The principal regression set is the incumbent-correct cohort. v3.54 displaced
four gold anchors after classifying them as recovered, normal-tool,
noncritical-predecessor, or contributing-probe boundaries. The two-sided repair
contract is intended to make those overrides falsifiable. Direct counter-risks
are candidate flood from matrices containing up to dozens of positives,
Planning salience, earliest-row bias, and prose that claims independent
criticality without literal support. The validator therefore binds every
representative to one frozen positive row and every final to the anchor or one
representative, but semantic calibration remains an experimental risk.

Simple deterministic chronology rules are explicitly rejected: on the frozen
post-score matrix, always taking the earliest positive, latest positive, nearest
positive, earliest post-anchor positive, or latest pre-anchor positive yielded
only `11`, `11`, `17`, `11`, and `14` Step hits respectively. No such rule is
encoded in v3.55.

## Pre-registered falsifiers

- any local positive cannot be promoted as the identical Step/module/type/
  evidence tuple under the standard prediction validator; or
- local Step coverage is not exactly `717/717`; or
- gold Step local-positive coverage is `< 31/50`; or
- fresh anchor plus any local-positive oracle is `< 30/50`; or
- anchor plus class representatives has oracle `< 30/50`; or
- the selector emits more than five representatives, omits a positive row from
  its reviewed-row ledger, or selects anything other than the anchor or an exact
  representative copy; or
- direct selector gains are not strictly greater than direct selector losses;
  or
- final Step Exact is `<= 25/50`.

Diagnostics cannot accept a version. Formal acceptance requires a legal frozen
full-GAIA Step Exact `> 25/50`; Goal completion requires `>= 30/50`.

## Execution and isolation

- 50 fresh v3.20 anchors + 717 Step-local sessions + 50 class-stratified final
  selectors = exactly `817` planned successful model sessions.
- Fresh one-case sessions, chronological local Steps, maximum concurrency `4`,
  maximum two attempts per stage.
- No smoke gate, old prediction, rejected artifact, case routing, gold/labels,
  metrics, scored artifact, error report, case study, git history, or external
  resource is available to inference.
- All local records, matrices, class representatives, selected predictions,
  hashes, order, taxonomy, literal evidence, reviewed-row coverage, and
  exact-copy relations must freeze and validate before scoring.

## Pre-inference implementation hashes

Frozen before the first v3.55 inference call:

- Protocol SHA-256: `8df1174b619e5ae9df1f4035cacf030d149372332409665fb908a6e89f6950fd`
- Runner SHA-256: `05edd7647f49c4e566006d728d1e89c12bac95370b3a33a27a3732fb93f3f688`
- Registry SHA-256: `c2aabc6028e4f463684548636e2d667c54e2b721d10b51c1393785ab498c18f5`
- Focused-test SHA-256: `5f5f3a705179ae23f2460457d37dc21d91f39d25f9e454169f19ff33d5f330dc`
- Focused v3.55 tests: `10 passed`, covering exact v3.20 anchor semantics,
  inherited promotion-safe System sources, full local-matrix coverage,
  representative class/row uniqueness, exact-copy binding, default keep,
  literal veto, and the two-sided repair relation.
- Cross-version v3.20/v3.52/v3.53/v3.54 tests: `23 passed` in isolated
  processes; no frozen predecessor was modified.
- Full-cohort dry-run: `50` cases, `717` legal Steps, exactly `817` planned
  successful model sessions, concurrency capped at `4`.
- Static source scan: no rejected-version semantic import, case-specific
  Step/entity/source rule, inference-time score/label reader, or old-prediction
  input was found. The removed v3.54 single-proposal and duel stages are absent
  from the v3.55 inference protocol and runner.

## Frozen runtime outcome

- The full run began, but v3.55 did not reach a legal prediction or scoring
  boundary: `4` anchors and `19` Step-local records validated, while `0`
  class-selector artifacts validated and `0/50` final predictions froze.
- The first two selector sessions independently failed
  `invalid_class_selector_anchor_classification`, emitting `null` and
  `anchor`. The task schema said only “one allowed anchor class” without
  enumerating the frozen values; both child processes stopped updating after
  the validator rejection.
- The exact process group was terminated after the repeated failure was
  confirmed read-only. Exit code was `143`; all intermediate artifacts are
  preserved under the frozen v3.55 run directory. No score was computed.
- v3.55 is rejected as `incomplete_unscored_runtime_validation_failure`.
  A new clean v3.20 child may retest the same single mechanism only after
  explicitly enumerating all selector contract values in the inference task.

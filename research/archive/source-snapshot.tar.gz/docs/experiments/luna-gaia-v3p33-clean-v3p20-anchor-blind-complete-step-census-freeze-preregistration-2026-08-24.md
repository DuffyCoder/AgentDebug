# Luna GAIA v3.33 Clean v3.20 Anchor-Blind Complete-Step-Census Freeze Preregistration

## Frozen identity and decision rule

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.33-clean-v3.20-anchor-blind-complete-step-census-freeze`
- Semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Single major change: generate and freeze at most one complete-timeline census
  candidate in a fresh session that cannot read the v3.20 anchor, then compare
  the two frozen candidates in a separate bounded stage.
- Accepted incumbent: Luna v3.20, Step Exact `25/50`.
- Version acceptance: Step Exact `>25/50`.
- Goal completion: Step Exact `>=30/50` plus every legality check.
- Original frozen baseline: Luna v3.4, Step Exact `21/50`.
- Dataset: frozen `gaia-paper-v1`, exactly 50 cases.
- Dataset manifest SHA-256:
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort semantic SHA-256:
  `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Cohort file SHA-256:
  `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Prediction-manifest file SHA-256:
  `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Model / reasoning effort: `gpt-5.6-luna` / `medium`.
- No smoke gate; after offline validation run the complete GAIA-50 directly.

Step Exact is the only optimization, comparison, acceptance, rejection, and
completion metric. Module, type, and literal evidence remain output-legality
constraints only.

## Post-score evidence and first divergence

Frozen v3.32 completed all 50 cases legally and scored `21/50`, so it is
rejected. Relative to v3.20 it produced two gains and six losses, net `-4`.
Its complete 29-error audit found:

- false candidate admission: 11;
- candidate recall failure: 8;
- annotation ambiguity: 5;
- early freeze failure: 4;
- challenger recall failure: 1.

The v3.32 complete census emitted a candidate on 48/50 cases, yet selected the
visible anchor itself on 44. It emitted only one formal challenge, which
directly changed a wrong anchor into released gold without a direct override
regression. In another error, the frozen artifact explicitly classified the
anchor as a reasonable probe and recalled the released gold as its unique
critical census candidate, but the anchor-aware comparison suppressed that
candidate before proposal. The first divergence there is the combined
candidate-generation/comparison stage, not Step enumeration or the final
arbiter.

This supports one falsifiable explanation: exposing the incumbent anchor while
generating the census candidate creates an anchor-salience short circuit. It
does not support accumulating v3.32's combined prompt or any other rejected
lineage change.

## Single uniform mechanism

The v3.20 packet-state anchor prompt, ledger, Step freeze, model, and final
default-keep exact-copy arbiter remain unchanged. The one new mechanism is a
hard artifact boundary between independent candidate generation and comparison:

1. Run the unchanged v3.20 anchor in one fresh session.
2. In a different fresh session, provide only the frozen JudgeView/cohort and
   this version's census protocol. Do not provide the anchor prediction,
   anchor ledger, anchor checkpoint, historical prediction, or any scored data.
3. Inspect every Canonical Step exactly once and give one closed verdict:
   `clear`, `reasonable_probe`, `normal_failure`,
   `recovered_or_mechanical`, `faithful_propagation`,
   `noncritical_local_error`, or `critical_candidate`.
4. Freeze at most one full legal prediction whose Step is the sole
   `critical_candidate`; otherwise freeze `none`. Candidate generation cannot
   express direction or compare against the hidden anchor.
5. Only after both artifacts are frozen, a new comparator reads the exact
   v3.20 anchor bundle and exact census artifact. It may emit at most one
   proposal, and any proposal must be a field-for-field exact copy of the
   census prediction. It cannot add, repair, or replace a candidate.
6. The comparator challenges only when literal chronology and two repair
   counterfactuals establish that the anchor is a reasonable probe,
   noncritical predecessor, or downstream symptom and the independent census
   boundary remains critical. Uncertainty keeps the anchor.
7. The final arbiter may select only the exact anchor or exact formal proposal
   and defaults to the anchor.

This is a clean v3.20 branch. It does not inherit v3.32's anchor-aware census
prompt or combined candidate/comparator contract, nor any v3.21-v3.31 prompt,
challenger, ledger, validator, dual-anchor, or state-scan mechanism. The
complete-census verdict vocabulary is deliberately reintroduced only inside
the new anchor-blind candidate artifact and is the mechanism under test.

## Falsifiable gain and regression analysis

Expected gain mechanism: removing anchor visibility should increase genuine
candidate disagreement and preserve candidates that the combined v3.32 stage
prematurely rationalized away. The post-score target classes are census
comparison short circuit, candidate recall, early freeze, and early false
admission. Case identities remain only in post-score audits and are absent from
prompts, code, validators, manifests, and routing.

Regression risks:

- an independent full-timeline scan can prefer late explicit symptoms;
- without anchor context it can promote a local but noncritical Planning error;
- candidate disagreement can increase and make the comparator overrule correct
  incumbent anchors;
- the census can become a disguised candidate pool;
- fresh v3.20 anchor sampling can still regress incumbent-correct cases even
  when the new mechanism is neutral.

Controls are exact one-row-per-Step coverage, a closed verdict set, one frozen
candidate maximum, literal local evidence, recovery/probe/normal-failure and
faithful-propagation vetoes, an exact-copy candidate contract, a separately
hash-bound comparator, two repair counterfactuals, and a default-keep arbiter.
The hypothesis is falsified if the census is not anchor-blind, if it floods
candidates, if the comparator creates a third prediction, or if the complete
legal run scores `<=25/50`.

## Execution and freeze contract

1. Implement the versioned anchor-blind census artifact, comparator, arbiter
   binding, aggregate validator, runner, registration, and negative tests.
2. Verify the anchor task is semantically identical to v3.20 modulo version
   identity, the census task contains no anchor path/hash/Step, and all
   candidate/comparator exact-copy and hash bindings pass offline.
3. Use four fresh serial sessions per case: v3.20 anchor, anchor-blind census
   freeze, frozen-candidate comparator, and default-keep arbiter; at most four
   cases run concurrently.
4. Run no smoke gate. Execute all 50 cases after prepare-only validation.
5. Freeze anchors, ledgers, checkpoints, census artifacts, comparators,
   arbiters, predictions, audits, and hashes after 50/50 completion. Validate
   schema, taxonomy, evidence, order, Step range, complete census, anchor
   blindness, exact copies, no routing, and no prior-prediction access before
   reading labels.
6. Score all 50 and compute Step transitions relative to frozen v3.20 and v3.4.
7. Reject immutably at `<=25/50`; accept as the new incumbent at `26-29/50`;
   complete the Goal only at `>=30/50` after every legality check passes.

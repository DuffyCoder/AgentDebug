# E9 v39 dry3 failure case study

## Outcome

The frozen v39 dry3 run used one Candidate completion and one independent
Selector completion with DeepSeek `deepseek-v4-flash`, temperature zero, and
the default request body. Provider telemetry recorded exactly 2 logical
completions, 2 HTTP attempts, 0 retries, and 405,354 total tokens.

The preregistered gate rejected the run:

- Step Exact: 1/3 (required 2/3);
- Step+Module Exact: 1/3 (required 2/3);
- All Correct: 1/3 (required 2/3);
- successful outputs: 2/3;
- failed outputs: 1/3, code `invalid_text`.

The rejected promotion artifact is self-bound by
`500ea179ca697c25b1a7946ce65f83e8336fd1a2c01c20691d9ca9ef4f532f87`.
Full30 must not run from v39.

## Format attribution

The Selector response was one strict JSON object with all three complete case
objects and provider `finish_reason=stop`. C02's `causal_basis` was 1,027
characters, three characters above the frozen 1,024-character explanatory
limit. The parser therefore correctly rejected that case, but the generic
`invalid_text` message said the field must be non-empty and concealed that the
actual failure was length.

The C02 raw final tuple was otherwise complete and valid:

- step 1;
- `action/misalignment`;
- an evidence source owned by step 1 action;
- a grounded root cause;
- a causal ledger containing outcome, owner chain, four rebuttals, and the
  one-error counterfactual.

That tuple exactly matches the released tuning label. A read-only
counterfactual parse with a limit above 1,027 would make the dry semantic
result 2/3 on Step, Step+Module, and All Correct. This counterfactual is only
failure attribution; the frozen v39 artifact remains rejected and must never
be mutated or rescored.

Primary root cause: artificial explanatory-field boundary, not malformed JSON
or missing semantics. The new ledger contract predictably requires slightly
more text than the old comparison contract, but the schema retained its old
1,024-character cap.

## Semantic case study

### C01 ALFWorld: exact

Candidate and Selector selected `30/system/step_limit`, exactly matching gold.
The causal ledger treated each cabinet as distinct novel coverage, rebutted
the step-4 hindsight-only inefficiency hypothesis, and retained the real
terminal boundary. This preserves the intended terminal guard.

### C02 GAIA: raw exact but validation failure

Candidate and Selector selected `1/action/misalignment`, exactly matching
gold. They identified that extracting a dynamic GitHub issue-search page
cannot enumerate and order the required closed labeled issue collection or
expose label-change history. The later use of an open issue's creation date
was correctly treated as a downstream symptom. The only failure was the
three-character explanatory overflow described above.

### C03 WebShop: predicted step 8, gold step 13

Candidate and Selector selected `8/planning/inefficient_plan`; gold is
`13/planning/inefficient_plan`. v39 correctly rejected the incumbent step-1
capability hypothesis and selected the right module and error type, but it
carried the no-progress evidence from the initial query directly into the
first near-identical re-query. The benchmark annotation waits until step 13,
after the repeated query epoch has itself paged through additional results
and the plan recommits again.

This remains a search-maturity calibration miss. It should not be patched in
the same experiment as the proven format boundary: changing both would make
the causal effect of the validation fix unidentifiable.

## Contract-compliance audit

The new v39 reasoning topology was exercised, not ignored:

- all Candidate bases used the prescribed FAILURE/FIRST/ALTERNATE/OWNER/
  RECOVERY/COUNTERFACTUAL ledger;
- both valid Selector bases and the rejected C02 raw basis used OUTCOME,
  OWNER_CHAIN, four explicit REBUTTALS, and COUNTERFACTUAL;
- C01 and C02 preserved different terminal-versus-owner outcomes rather than
  applying one universal early or late rule;
- all three verdicts were `accept_proposed`, so proposal anchoring remains a
  concern for full30, but the explicit rebuttals were trace-grounded.

## v40 optimization direction

Before another provider call:

1. Preserve v39's prompts and all semantic instructions byte-for-byte except
   the stated explanatory length contract.
2. Raise Candidate and Selector `causal_basis` validation from 1,024 to 1,280
   characters and ask the model to stay within 1,200. This leaves 80
   characters of transport/model variance while remaining bounded.
3. Improve the parser error message so an oversized field reports its actual
   maximum instead of claiming it is empty.
4. Change no step rule, taxonomy rule, evidence projection, candidate order,
   model configuration, or deterministic behavior. The raw Selector remains
   the sole semantic authority.
5. Freeze a new v40 code bundle and run the same dry3 from a fresh cache. Run
   full30 only if all dry gates pass. If v40 fails, complete another case
   study before any further provider call.

No v39 artifact may be mutated or rescored under v40.

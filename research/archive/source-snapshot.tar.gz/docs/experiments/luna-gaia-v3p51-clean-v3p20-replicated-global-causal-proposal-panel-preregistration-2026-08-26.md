# Luna GAIA v3.51 预注册：replicated global causal proposal panel

日期：2026-08-26

## 冻结身份

- version：`agentdebug.codex-agent-judge.luna-gaia.v3.51-clean-v3.20-replicated-global-causal-proposal-panel`
- semantic parent：`agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- accepted incumbent：Luna v3.20，Step Exact `25/50`
- original baseline：Luna v3.4，Step Exact `21/50`
- 数据集：冻结 `gaia-paper-v1` 50 例
- 模型：`gpt-5.6-luna`
- reasoning effort：`medium`
- 版本接受条件：完整、合法 GAIA-50 的 Step Exact `> 25/50`
- Goal 完成条件：完整、合法 GAIA-50 的 Step Exact `>= 30/50`
- smoke gate：无；离线验证后直接完整 GAIA-50

冻结输入：

- cohort manifest SHA-256：`31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`
- prediction manifest SHA-256：`77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`
- v3.20 parent source SHA-256：`3e886325bf0a4b4d4a3e770071c0a36fe81dab2bebaf5015561ca828b6c2e4f9`

## 唯一主要机制变化

相对 v3.20 只增加一个机制：`replicated anchor-blind global causal proposal panel`。

每例使用五个 fresh、隔离 session：

1. 原样执行 v3.20 packet-state anchor；
2. 三个相互不可见、看不到 anchor 的 global causal proposal replica；
3. 一个 anchor-preserving exact-copy selector，在 anchor 与至多三个 proposal
   之间选择。

三个 proposal replica 使用同一统一 critical-boundary contract，各自完整审查
全部 Step 与 Memory/Reflection/Planning/Action/System，但每个只能输出一个完整
prediction 或 `none`。它们不生成 local-error inventory、不投票、不共享状态，
也不读取其他 replica。replication 的作用只是在常数上界候选池内提高 full-boundary
recall。

selector 不按多数、位置、模块、措辞强度或 proposal provenance 排序。默认保留
anchor；只有 literal evidence 证明 anchor 是 normal tool failure、已恢复缺陷、
机械/非关键 predecessor、faithful propagation 或 downstream symptom，并且选中的
proposal 在 anchor-only repair 后仍独立 critical，才允许 override。最终结果必须是
anchor 或某个 proposal prediction 的 exact copy。

## 根因依据与可证伪预测

v3.49 的 max-one global proposal 在完整 GAIA-50 上命中 16 个 gold Step；对其 fresh
anchor 产生 6 direct gains、2 direct losses，证明这种完整 global boundary proposal
比 local-error census 更接近有效机制。但单 proposal 的 anchor-plus-proposal oracle
只有 `27/50`，最终仍是 `25/50`。

v3.50 的五 Module inventory 产生 703 条 local-error rows，却只覆盖 20 个 gold
Step，global proposal 只命中 11 个；duel 造成 0 direct gains、6 direct losses，
最终 `15/50`。因此本版本明确删除 inventory、local-positive、module vote 和自由
compression，不从 v3.50 继承任何推理语义。

评分后历史诊断中，v3.20、v3.39 typed proposal 与 v3.49 global proposal 的 union
是 `31/50`；这只用于提出“少量独立 complete-boundary proposals 有互补召回”的
假设，不进入 prompt、router、manifest 或逐例选择。

预注册 falsifiers：

- fresh anchor + replicated proposals 的评分后 candidate oracle `< 30/50`；或
- 三个 replica 没有提高 v3.49 的 gold proposal recall；或
- selector 对 fresh anchor 的 direct gains 不严格多于 direct losses；或
- final Step Exact `<= 25/50`。

任一成立即拒绝 v3.51，已评分产物不修改，incumbent 仍为 v3.20。

## 预期 gains 与 regressions

预期 gain 机制：不同 full-boundary replicas 对 state truth、constraint alignment、
capability commitment、post-feedback recommitment 与 terminal abandonment 的独立
取样可能覆盖 v3.49 max-one proposal 漏掉的 boundary，而不引入 v3.50 的 703-row
候选洪泛。

主要 regression 风险：多个 proposal 增加了 persuasive downstream symptom、
reasonable probe 与 locally real but noncritical defect 的暴露率；selector 可能重演
v3.44 的 late-selection 和 v3.50 的 false override。为此候选最多三个，禁止 vote，
并把 anchor causal-removal literal witness 设为 override 的 validator-bound 必要条件。

## 隔离与继承纪律

- semantic parent 只有 v3.20；v3.21--v3.50 均不是 parent。
- v3.49 仅提供被重新检验的“完整 anchor-blind max-one global proposal”机制假设；
  不读取其预测、prompt artifact、scored output 或 case ID。
- 不继承 v3.50 inventory、compression、duel artifact 或 validator 状态。
- 推理阶段禁止 labels、metrics、scored artifacts、旧预测、错误报告、gold rationale、
  case routing 与 git history。
- 所有 case 的五个 stage 完成并通过 gold-free schema/taxonomy/evidence/hash/order
  audit 后才允许评分。
- Step Exact 是唯一接受、拒绝与 Goal 完成指标。

## 推理前实现冻结

完整 GAIA-50 推理开始前，离线验证结果为：相关 v3.51 与 v3.20 测试
`10 passed`；50 例 dry-run 解析出 50 个 case、每例五个隔离 stage、计划 250
个 session；模型、effort、parent、接受条件和 Goal 条件均与本预注册一致；静态扫描
未发现 rejected protocol import、trajectory-ID router 或 gold/scored artifact read。

- v3.51 protocol SHA-256：`771161a50201dd6471ce2abf25e7d7b23a1df2d48efbfe5d163134a6f54401c6`
- v3.51 runner SHA-256：`6a20f2552631d86c3e3506bc4888fc9a8ad958243fa7bddd577633655426d444`
- workflow registry SHA-256：`96b9207cd2e22385ebdd3d2201f7efc5492aff9caf26fad4fb3cc068d8ab23e6`
- v3.51 tests SHA-256：`befafc6fe971d7dec02d6f6cc351f4f0a92ca3f5ca9b327072bf438e0b9c307d`

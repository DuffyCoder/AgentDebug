# GAIA v3.108 direct Responses validator-closure preregistration

Date: 2026-08-31

Status: preregistered and unscored. This document authorizes no network call
and claims no GAIA-50 result.

## Frozen identity and lineage

- Version: `agentdebug.codex-agent-judge.gaia-v3.108-v3p83-sophnet-responses-validator-closure-gpt55-medium`.
- Semantic parent: accepted v3.83,
  `agentdebug.codex-agent-judge.gaia-v3.83-clean-v3.20-model-only-gpt55-medium`,
  Step Exact `26/50`.
- v3.106 is transport-failure evidence only. It is not the semantic parent,
  and no v3.106 prediction or frozen run artifact is inherited.
- Semantic protocol: frozen v3.83 packet-state anchor, earliest-causal
  challenger, and default-keep arbiter.
- Dataset: frozen `gaia-paper-v1`, 50 cases; dataset identity
  `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort identity:
  `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction-manifest identity:
  `56aa8a2994ae793545b6620c665a945375e48cd6c05a4b9b1afc1f4f2885a3e5`.
- Model: `gpt-5.5`; reasoning effort: `medium`.

## One falsifiable mechanism

The sole change is a transport-level, bounded same-stage validator closure.
Every stage begins with the same complete v3.83 task, gold-free projected
JudgeView, upstream artifact inputs, direct Responses JSON-object mode, and
stateless request contract used by v3.106. If that first artifact passes the
unchanged v3.83 validator, no closure prompt is used.

If the parent validator rejects the artifact, v3.108 may issue at most two
additional fresh stateless requests. A correction sees only:

1. the original stage input;
2. an allow-listed validator error code and fixed protocol guidance;
3. a narrow Step-semantic lock extracted from the rejected same-stage draft;
   and
4. only for `invalid_evidence_ownership`, deterministic validator-owned source
   blocks from that locked Step in the current gold-free JudgeView.

The failed model response itself is never replayed. Gold, labels, scores, old
experiment predictions, error reports, case routing, cross-case state, and
provider response bodies are unavailable. Every correction must return a
complete replacement envelope. The host uses the unchanged materializer and
does not coerce, copy, synthesize, normalize, or repair any model field.

## Frozen semantic locks

- Anchor: lock the one integer shared by `step_candidates.selected_step`,
  `step_freeze.predicted_step`, and
  `anchor_predictions[0].predicted_step`. Because the frozen protocol selects
  Step before owner/type/evidence, an ownership correction may re-run only the
  same-Step OWNER -> TYPE -> EVIDENCE phase.
- Challenger: lock `challenge_status` and, for a challenge, the proposed Step.
- Arbiter: lock the decision, selected Step, and stable hash of the exact
  selected upstream prediction.

Any later response that changes an existing lock is rejected even if the
ordinary parent validator would otherwise pass. A missing or unparseable first
artifact has no lock; the next request is a complete-envelope resample. The
first later parseable identity becomes immutable for the remainder of that
stage.

## Fail-closed feedback allowlist

Only the five terminal failure codes observed in the completed v3.106
transport run may trigger a correction:

- `missing_stage_artifact`, in any stage: request the complete exact envelope;
- `arbiter_frozen_step_mismatch`, in the arbiter: preserve the locked decision
  and exact selected prediction, and emit `frozen_step` as the equal JSON
  integer; and
- `arbiter_selected_prediction_hash_mismatch`, in the arbiter: preserve the
  locked exact selected prediction and recompute only its stable hash while
  also satisfying the integer freeze invariant;
- `invalid_evidence_ownership`, in the anchor: preserve the locked Step and
  re-run only same-Step owner/type/literal-evidence selection against the
  deterministic source map;
- `cohort_order_mismatch`, in the one-case anchor: preserve the locked Step and
  exact-copy the current manifest/JudgeView trajectory identity into the
  ledger, checkpoint, and sole prediction without punctuation normalization.

An unknown code, a code used in the wrong stage, a lock-required repair with
no lock, or any lock drift stops that case fail-closed. Raw validator exception
text is not sent to the model.

Before the ordinary gold-free tree freeze, a v3.108-local verifier must match
every disk attempt one-to-one with `execution-summary.json`, require consecutive
attempts with exactly one final acceptance, replay the cumulative five-code
feedback and semantic lock from materialized artifacts, and validate all
stateless/no-mutation/no-replay flags. Each parsed model envelope and the
artifacts materialized from it carry an order-preserving JSON hash; any value or
order mismatch fails closed. This verifier is installed and restored only by
the v3.108 wrapper and does not modify the shared v3.106 runtime.

## Frozen transport and topology

- Endpoint: `POST https://api.sophnet.com/v1/responses`; no Chat Completions
  fallback.
- Base direct Responses contract:
  `agentdebug.v3p83-sophnet-direct-responses.v2`, including its narrowly
  audited identical duplicate `type` provider-envelope compatibility rule.
- Closure contract:
  `agentdebug.v3p83-direct-responses-validator-closure.v1`.
- `store=false`, `stream=false`, no tools, no conversation, no
  `previous_response_id`, redirects disabled.
- API key source: `SOPHNET_API_KEY` environment variable only; never command
  line, prompt, artifact, stdout, stderr, or audit content.
- HTTP attempts per one logical completion: at most 3 byte-identical transport
  attempts under the existing policy.
- Semantic requests per stage: initial + at most 2 corrections, total at most
  3. The bound must be exactly 3 at the runner entry; explicit values 1, 2, or
  4 are rejected before preregistration. Each request is a fresh stateless POST.
- Cases: 50; accepted serial stages: exactly 150; workers: at most 4; no smoke
  gate and no case router.

Before benchmark input is opened, a non-benchmark preflight must return exactly
`{"v3p108_validator_closure_ok":true}` from resolved model `gpt-5.5`. Failure
aborts without fallback.

## Acceptance and completion

All 50 predictions and all 150 accepted stage artifacts must pass the original
v3.83 validators, transport audit, credential scan, gold-free freeze, and
post-freeze verification before scoring.

- Selection metric: Step Exact only.
- Accept v3.108 only if Step Exact is strictly greater than `26/50`.
- Complete the Goal only if Step Exact is at least `30/50`.
- Module/type metrics, tokens, latency, and closure counts are diagnostic only.

## Commands

Preparation and offline preregistration (no network):

```bash
.venv/bin/python -m \
  scripts.run_agent_judge_gaia_v3_108_v3p83_sophnet_responses_validator_closure_gpt55_medium_paper50
```

Formal run, only after offline tests and operator-provided environment secret:

```bash
.venv/bin/python -m \
  scripts.run_agent_judge_gaia_v3_108_v3p83_sophnet_responses_validator_closure_gpt55_medium_paper50 \
  --execute --max-workers 4 --max-attempts 3
```

The credential value is intentionally absent from this file and configuration.

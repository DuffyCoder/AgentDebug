# GAIA v3.91 runtime result

Date: 2026-08-29

## Decision

v3.91 is rejected as runtime/validation incomplete and is not scored. It
completed 37/50 cases; 13 cases failed both permitted attempts. No partial
predictions are used for Step comparison. Accepted v3.83 remains `26/50`.

## What the run established

- Uniform staged file inspection eliminated v3.90's context failure. The former
  failing long case 17 completed, as did the unusually slow case 2.
- 37 cases completed both model stages and all local semantic validators.
- The 13 failures form three high-confidence contract clusters:
  - `invalid_step_candidate_evidence`: 6;
  - `incomplete_predicate_handoff_tournament`: 6;
  - `predicate_handoff_invalid_winner_role`: 1.
- All 13 are singleton-ledger cases whose only possible final Step is the anchor
  Step. The six anchor failures copied `benchmark.metadata.steps=1` as ledger
  evidence, which is not a contiguous assistant/feedback packet substring. The
  seven tournament failures either honestly returned no semantic row on retry
  or kept the singleton anchor with a normal/noncritical role that the inherited
  override-oriented validator forbids.

## Next minimal correction

Keep the exact v3.83 parent, GPT-5.5/medium, file transport, and predicate-handoff
tournament. Add only Step-invariant legality/degeneracy handling:

1. Materialize a candidate ledger's selected-row evidence from an exact
   contiguous same-Step assistant/feedback packet source, never from metadata or
   whitespace-normalized previews.
2. Treat a singleton ledger as a vacuous keep-anchor tournament: it has no
   strict prefix and therefore cannot change Step. Permit an empty semantic row
   set, or an honest noncritical anchor row, while freezing the exact anchor
   prediction. Retain the strict complete-row and winner-role constraints for
   every non-singleton tournament and every strict-prefix override.

This repair cannot change the selected Step on the 13 affected cases; it only
makes structurally forced keep-anchor outputs legal. It is uniform and contains
no trajectory ID, entity, source-model, or gold-based rule.

## Frozen artifacts

- Execution summary SHA-256: `069a5c621a2787377dbee610d26b8e7b54a55001b2c7b28d0a2ec0f970052ab5`.
- Runtime failure audit SHA-256: `bc29c174b0ac6e2d6bfa05536ec6477d26cad0271d8427cf15e453f3ab96fab7`.
- Audit builder SHA-256: `08defc08255a91e9640ec460901aba7b10f5cd7354dc098aca0d94bc7a3bcdb9`.


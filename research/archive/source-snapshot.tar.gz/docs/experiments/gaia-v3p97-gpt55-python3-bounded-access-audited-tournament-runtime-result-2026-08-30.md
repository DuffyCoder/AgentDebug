# GAIA v3.97 GPT-5.5 Python-3 bounded-access tournament runtime result

Date: 2026-08-30

## Decision

v3.97 completed all 50 cases and 100 semantic stages, but failed the mandatory
gold-free inference-access audit before scoring. It is frozen, unscored, and
rejected as a runnable experiment. No label, gold rationale, scored artifact, or
incumbent per-case prediction was read to make this decision.

## Frozen runtime facts

- Semantic parent: accepted v3.83 (`26/50`).
- Model/reasoning effort: `gpt-5.5` / `medium` in both stages.
- Completion: `50/50` cases, `100/100` stages, `100` attempts, zero failed cases.
- Invalid commands: `0`.
- Runtime-contract failures: `0`.
- Successful command counts: task `94`, timeline `210`, owner `645`, feedback `256`.
- Strict transport wrappers: all `1,205` successful commands had depth one.
- Validator-proven zero-command singleton reducer keeps: cases 3, 20, 21, 23, 43.
- Failed or incomplete commands: `9`.
- Reducer stages missing the incorrectly required complete original timeline: `31`.
- Access audit SHA-256: `934d3d0f895d7c5974333d826f221dbc03b8f5efcaa8b2210799ae4e02f412cf`.
- Predictions SHA-256: `cc8715133301cdb7f652f2aa5f5442aebb399a50ab315939b5a46d6eb6d61f5c`.
- Execution summary SHA-256: `cab39993321a5e9acaff1bf9e6ff45ee491a5973a08d675e0da30a2de270a052`.

## First divergence and root cause

The earliest failure is `runtime_or_validation_failure`, before any semantic
score comparison:

1. The inherited access audit required the reducer to cover all original trace
   Steps. The reducer's actual semantic domain is the complete native-ledger
   candidate set supplied by the fresh anchor, so 31 otherwise completed
   reducer stages were rejected for omitting irrelevant noncandidate suffixes.
2. Cases 3, 37, and 43 requested `timeline 1 5` on traces shorter than five
   Steps. The inspector rejected rather than safely clamping a bounded final
   page, producing three exit-code-1 events.
3. Cases 11, 28, and 46 exposed very large system feedback through the
   unchunked `feedback N` command. Both anchor and reducer calls for those Steps
   remained `in_progress`, yielding six incomplete events.

These are observable transport/audit defects. They do not establish whether the
tournament Step choices would gain or regress relative to v3.83 because scoring
was correctly not reached.

## Minimal next correction

Create v3.98 directly from accepted v3.83 with the same single tournament
mechanism. Anchor access must still read task plus the complete original
timeline. Reducer access must read task plus every native-ledger candidate Step;
noncandidate original Steps are optional. The inspector must clamp only a valid
bounded final page and expose large feedback through bounded exact previews and
explicit exact chunks. All other failed, incomplete, invalid, mutating, or
nonallowlisted commands remain fatal.

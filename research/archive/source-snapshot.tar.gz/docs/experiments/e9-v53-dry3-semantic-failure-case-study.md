# E9 v53 dry3 semantic failure case study

## Closed attempt

- Experiment: `e9_v53_dual_timescale_planning_deepseek_v4_flash_default_body`.
- Model: `deepseek-v4-flash`, default request body, temperature 0, one
  worker.
- Preregistration content hash:
  `e54fd10cfa7d2cd45626a5e0fb07618968538652739ee3aad21315d099651c82`.
- Predict-run content hash:
  `48d0c11e5d235a577576464a1733efda674440a3c687e633c4997e9d2bbc22d5`.
- Promotion content hash:
  `e98c937194a85750cb59030b61a8fe817a607ec2bb5b985fc8f2a49a049e0f10`.
- Result: 3/3 valid raw Selector predictions, Step Exact 2/3,
  Step+Module Exact 2/3, and All Correct 2/3. The promotion was rejected on
  all three semantic minima; all structural, raw-final, gold-isolation,
  telemetry, and exact-budget checks passed.
- Provider use: two logical completions, two HTTP attempts, zero retries;
  383,972 input, 33,857 output, and 417,829 total tokens.
- The completed audit ordinal is 642.

The full30 phase is not authorized because the deliberately strengthened
dry3 gate required 3/3 on every semantic metric.

## Case-level result

The ALFWorld case was exactly diagnosed at step 30 as
`system/step_limit`. The GAIA case was exactly diagnosed at step 1 as
`action/misalignment`.

The only miss was
`GPT-4o_008_chat_b000_t00_e07-d50ae81f`:

- released root: step 13, `planning/inefficient_plan`;
- v53 candidate planning steps: 2 and 8;
- v53 final: step 2, `planning/inefficient_plan`.

The predicted module and type were correct, but the released step was absent
from every candidate, so the unchanged Selector could not choose it.

## Why the dual-timescale lane failed

The new `planning_decisive_commitment` lane interpreted the beginning of a
second, materially equivalent search epoch at step 8 as the decisive later
commitment. That is a defensible causal diagnosis, but it does not match the
benchmark's local annotation at step 13.

Step 13 contains a stronger locally demonstrable defect than the prompt made
salient. Its same-step context says pages 1 through 6 have already been
visited and no relevant product was found. Its plan nevertheless states that
page 6 has not yet been explored and clicks `next`, continuing known failed
coverage from page 5. This is not merely a later repetition: the plan's state
premise literally contradicts its retained execution summary.

V53 asked for a later decisive recommitment, so the model selected the epoch
boundary at step 8 rather than scanning later planning outputs for the
strongest explicit state contradiction. The Selector then applied its
unchanged likely-first-cascade policy and selected step 2, which was already
recognized as no-progress pagination. Both stages behaved consistently with
their prompts; candidate temporal compression remained the primary failure.

## Rejected explanations

- Transport or formatting: both responses ended with `stop`, parsed as strict
  JSON, and required no retry or semantic repair.
- Invalid final evidence: all three raw Selector outputs reconstructed and
  validated.
- Missing later trace context: step 13 and its complete summary, reflection,
  plan, and action were present in the anonymous judge view.
- A Selector-only fix: insufficient for this case because no supplied
  hypothesis had step 13.
- Merely choosing the numerically latest planning error: unjustified and
  likely to restore v51's observed late-step bias.

## Next falsifiable hypothesis: v54 contradiction-first planning census

V54 will retain six LLM-only lanes and the raw Selector as the sole final
classifier. It will replace `planning_decisive_commitment` with
`planning_state_contradiction`:

1. independently scan every planning output after the earliest planning
   defect;
2. prefer a plan whose asserted state or progress premise is explicitly
   contradicted by the same-step observation, compact history, retained
   memory, or reflection;
3. next prefer a plan that reopens coverage explicitly recorded as exhausted;
4. only if neither exists, use a materially equivalent later recommitment;
5. do not select an epoch boundary merely because it is the first later
   query, and do not duplicate `planning_first_defect`.

The Selector will receive an explicit local-evidence tie-break: when an exact
same-step contradiction candidate and an earlier generic inefficiency are
both causally plausible, prefer the concrete contradiction that directly
licenses the failing action. This remains an LLM judgment, not a code-side
score, weight, vote, or fallback.

V54 must run on the same three fixed dry trajectories and again achieve 3/3
Step Exact, Step+Module Exact, and All Correct with zero invalid rows before a
full30 attempt. For the failed WebShop case, the candidate pass must expose
step 13 planning; this post-score diagnostic is not revealed to the provider.

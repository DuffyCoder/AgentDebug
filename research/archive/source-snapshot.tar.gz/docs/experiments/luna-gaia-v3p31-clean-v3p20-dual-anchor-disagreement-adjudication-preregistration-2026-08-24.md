# Luna GAIA v3.31 preregistration

## Frozen identity

- Version: `agentdebug.codex-agent-judge.luna-gaia.v3.31-clean-v3.20-dual-anchor-disagreement-adjudication`
- Direct semantic parent: `agentdebug.codex-agent-judge.luna-gaia-v3.20-packet-state-closure`
- Accepted incumbent: v3.20, Step Exact `25/50`
- Original frozen baseline: v3.4, Step Exact `21/50`
- Dataset: frozen `gaia-paper-v1`, 50 cases
- Dataset manifest SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`
- Cohort SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`
- Model: `gpt-5.6-luna`
- Reasoning effort: `medium`
- Smoke gate: none
- Acceptance: complete/legal GAIA-50 and Step Exact `> 25/50`
- Goal completion: complete/legal GAIA-50 and Step Exact `>= 30/50`

## Post-score evidence motivating the single change

The clean v3.30 run used the v3.20 packet-state anchor unchanged but disagreed
with frozen v3.20 on 17/50 Steps. The fresh anchor scored 20/50: relative to
the incumbent it lost six correct cases and gained one. The v3.30 bounded
challenger then had zero net effect relative to that run's anchor and never
emitted an earlier proposal. This falsifies the proposed bidirectional repair
and isolates anchor-stage sampling instability as the next testable mechanism.

## Single major change

Run the unchanged v3.20 packet-state anchor twice in two independent fresh
sessions. Before the unchanged v3.20 challenger and arbiter:

1. if both anchors select the same Step, freeze the primary anchor bundle;
2. if they disagree, one fresh symmetric adjudicator compares only the two
   exact predictions, their ledgers/checkpoints, and the literal trace;
3. the adjudicator may select only an exact primary or replica prediction and
   defaults to primary under unresolved evidence;
4. the selected anchor bundle then enters the unchanged v3.20 challenger and
   default-keep arbiter.

No v3.21-v3.30 prompt, challenger, ledger rule, validator rule, or prediction
is inherited. In particular, v3.30's bounded bidirectional challenger is
absent. This version changes only anchor replication plus disagreement
adjudication; packet-state admission, downstream challenger semantics, and
final default-keep arbitration remain v3.20.

## Falsifiable hypothesis

An independently replicated v3.20 anchor will expose unstable Step boundaries,
and a literal-evidence comparison limited to those two candidates will recover
more incumbent-quality boundaries than it displaces. The mechanism is
falsified if it does not produce positive Step Exact net gain over frozen v3.20.

## Expected gains and regressions

Expected gain class: cases where one fresh v3.20 anchor admits the benchmark-
critical boundary while the other exhibits false admission, candidate recall,
or early/late freeze instability. The observed v3.30 transition audit contains
six incumbent-correct losses of this form and one reverse-direction gain.

Regression risks:

- the adjudicator may select the wrong member when exactly one anchor is right;
- comparing two candidates may favor a later, more salient symptom;
- replicated generation may agree on the same systematic false positive and
  cannot help when neither anchor recalls the critical Step;
- disagreement frequency can increase decision variance even with a primary-
  default rule.

Controls: agreement cannot trigger an override; disagreement cannot create a
third Step; selected predictions must be exact copies; both anchor ledgers and
checkpoints are hash-bound and validator-audited. The post-score impact audit,
not any inference prompt, contains case-level gain/regression identities.

## Execution and freeze contract

- Five fresh serial stages per case: primary anchor, replica anchor,
  disagreement adjudicator, unchanged v3.20 challenger, unchanged v3.20
  arbiter; four cases maximum concurrency.
- Planned stage calls: 250, with at most one safe retry per stage.
- No labels, gold rationales, metrics, scored artifacts, historical
  predictions, error audits, experiment documents, or git history are visible
  to inference.
- Freeze all primary/replica anchor predictions, ledgers, checkpoints,
  reconciliation records, selected anchor bundles, challengers, arbiters,
  predictions, audits, and hashes before scoring.
- Run the full GAIA-50 directly after offline validation. Do not run smoke30.
- Compare gains and regressions only to frozen v3.20. Reject at `<=25/50`;
  accept as the new incumbent at `26-29/50`; complete the Goal only at
  `>=30/50` after every legality and isolation check passes.

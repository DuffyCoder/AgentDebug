# Luna v12 tuning-v1 目标完成审计

日期：2026-08-20

## 结论

当前没有一轮实验同时满足用户规定的全部停止条件，原始优化目标不能标记为
完成。

需要严格区分两轮完整实验：

1. `agentdebug.codex-agent-judge.luna-v12` 的 routed run 有真实、可重算的
   Step Exact 13/30，但读取同 case 的 Luna v3 prediction，并按该上一轮答案
   选择“十字段原样复制”或“强制换 step”两种策略。这违反固定边界“不得根据
   上一轮答案选择不同策略”，也是用户后来明确否定的 v12 机制。
2. `agentdebug.codex-agent-judge.luna-v12-standalone-v1` 不读取 prior prediction，
   30/30 输出合法，但 Step Exact 只有 7/30，未达到 12/30。

13/30 和 proposal-free 不能从两轮实验中拼接为一次达标结果。

## 六项停止条件审计

| 停止条件 | Routed v12 | Proposal-free standalone v12 | 最终判定 |
|---|---|---|---|
| 完整冻结 tuning-v1 30 条 | 30 条，三环境各 10 | 30 条，三环境各 10 | 两轮均通过 |
| 30/30 合法、validator/audit 通过 | 通过 | 通过 | 两轮均通过结构验证 |
| 官方 Step Exact ≥12/30 | 13/30 | 7/30 | 只有不合规 routed run 通过 |
| 推理严格 gold-free 且不按上一轮答案分流 | 无直接 label read，但使用 v3 prior-answer routing | 未发现 label/prior prediction read | Routed run 不通过固定边界；standalone 有执行隔离审计缺口 |
| 协议、提示、预测、audit、metrics、per-example、记录持久化 | 基本完整 | 基本完整 | 通过，但 routed run 的实现依赖闭包未完整 snapshot |
| 明确为 tuning-v1 调优结果 | 明确 | report 明确 release cohort 口径 | 通过 |

由于停止条件必须同时成立，最终结论为 **NO-GO**。

## Routed v12：分数与产物是真的

权威目录：

`output/agenterrorbench-codex-gpt-5.6-luna-tuning-v1-agent-judge-luna-v12-case30/`

独立只读核验结果：

- `tuning-plan.json` 固定 `tuning-v1`、30 条、ALFWorld/GAIA/WebShop 各 10，
  30 个独立 session、并发 4、每 case 最多 2 次。
- `execution-summary.json` 有 30 条完整记录，index 1--30，trajectory ID 唯一，
  全部 attempt 1、return code 0、prediction/audit present、parent validation
  passed。
- 30 份 preregistration、agent task、Codex JSONL、case-local prediction 和
  case-local audit 均存在。
- 当前官方 validator 对 merged prediction 重新运行通过，输出与持久化
  `prediction-audit.json` 逐字段相同。
- `predictions.json` SHA-256：
  `047e05870160bbcebbb18c5b01a02725727d582ae60710d50b2acbe85b5f52d4`。
- `scored/metrics.json` SHA-256：
  `ab63a7e521c60957d2117a507e7331cce92e17a0521189bce90457b73e8b5cda`。
- `scored/per_example.csv` SHA-256：
  `5c9cc50a0a5441476127145cd196d3bd37e0b63303bb1a600576cfc079f60245`。
- 协议源码 SHA-256：
  `a6410da9b8fc9b11b665dfb6cd029509d9ac35738dabc68ffcb8bb7fa467ac03`。
- 官方结果可从 per-example 独立重算为 Step 13/30、Step+Module 6/30、
  All Correct 5/25、failed 0；环境 Step 为 3/10、6/10、4/10。
- `scoring-summary.json` return code 为 0，scored artifact manifest 中的 hash
  当前匹配。

因此不能把问题描述为分数造假、文件损坏或普通 validator 失败。否决原因是
实验协议本身不符合更新后的固定边界。

## Routed v12：决定性协议违规

`agentdebug/diagnostics/agent_judge_luna_v12.py` 的冻结提示和 validator 明确：

- 每个 session 读取一个同 case Luna v3 proposal；
- 如果旧预测不是 `planning/inefficient_plan`，新输出必须十字段逐项复制；
- 如果旧预测是该 sink，必须选择不同 `predicted_step`；
- validator 读取并校验 incumbent proposal，并记录 forced replacement。

实际 `tuning-plan.json` 把完整 Luna v3 predictions 列为 proposal source，30 个
child 各看到一行；`prediction-audit.json` 记录：

- `incumbent_protocol = agentdebug.codex-agent-judge.luna-v3`；
- 17 条 immutable proposal；
- 13 条 forced sink replacement。

逐例检查与该路由完全一致：17 条非 sink 与 v3 逐字段相同，13 条 sink 全部
换 step。这直接违反：

> 所有 case 必须使用相同、预先冻结的流程；不得根据上一轮答案选择不同策略。

它没有把 label JSON 直接放进 prompt，但是否读取了 raw gold 不是唯一条件。
用户已经明确把这种 same-case prior-answer routing 视为 golden 泄露风险，故不能
用狭义“未直接读取 label”替代协议合规性。

## Proposal-free standalone：合规方向但分数不足

权威目录：

`output/agenterrorbench-codex-gpt-5.6-luna-tuning-v1-agent-judge-luna-v12-standalone-v1-case30/`

该运行的 `tuning-plan.json` 和 `run-result.json` 明确：

- `incumbent_or_prior_predictions_visible = false`；
- `proposal_files_created = false`；
- 30 个 fresh ephemeral one-case sessions；
- gpt-5.6-luna / medium；
- 最大并发 4、每 case 最多 2 次、仅重试失败 case；
- 30/30 predictions 和严格 merged audit 通过。

当前 validator 独立重跑与持久化 audit 完全一致，audit 记录
`proposal_free = true` 和 `incumbent_routing_used = false`。但官方结果是：

- Step Exact 7/30；
- Step+Module 3/30；
- All Correct 2/25；
- failed 0。

所以 standalone 解决了 prior-answer routing，却没有达到数值停止条件。

## Routed 提升的来源与可保留信号

把 v3、routed v12 和 standalone v12 的 frozen per-example 结果逐例对齐后，
routed v12 的 13/30 可以精确分解为：

| 子集 | v3 | Routed v12 | Standalone v12 |
|---|---:|---:|---:|
| v3 的 17 个非 sink case | 8/17 | 8/17（逐字段复制） | 5/17 |
| v3 的 13 个 sink case | 0/13 | 5/13（强制换 step） | 2/13 |
| 全部 tuning-v1 | 8/30 | 13/30 | 7/30 |

Routed 的五个新增 Step 命中是 case 7、16、19、22、27；另外八个 replacement
仍然错误。它没有出现 correct→wrong，原因不是 selector 稳定，而是旧预测经
评分后已经知道这 13 条全是错的，再只在这个 0/13 子集强制换答案。13 条上的
绝对 step 偏差总和还从 v3 的 56 上升到 routed 的 63；这说明该机制增加了
候选多样性，却没有形成可靠的整体边界校准。

Standalone 对照进一步证明这一点：它只保住 v3 八个 Step exact 中的五个，
又只在 13 个 sink 中命中两个，而且与 routed 的五个新增命中只重合 case 7。
因此不能把 routed prompt 本身解释成可独立复现 13/30 的统一 judge。

仍可保留的、gold-free 方法信号是“为每条轨迹主动生成一个不同 step 的反事实
候选”，而不是复用旧预测或强制替换最终答案。若以后恢复优化，一个合规拓扑
应对所有 case 无条件执行相同流程：

1. 从当前 JudgeView 现场生成 primary causal hypothesis；
2. 从同一 JudgeView 生成 evidence-qualified、不同 step 的 challenger，若无
   合法候选则允许为空；
3. fresh selector 同时比较两者，并允许保留 primary；
4. step 冻结后再解析 module/type。

Challenger 只能由通用证据门支持：直接字面违约或 plan/action contract breach、
达到门槛的 recurrence、以及没有更强本地根因时的 terminal System。Selector
应优先选择“门槛首次成熟”的 owner event，不能按旧答案是否属于某个标签、
case ID、环境名或历史得分分流。这个设计方向只是基于已暴露 tuning-v1 的
复盘假设，不是已经验证的准确率提升。

## Gold-free 与执行隔离审计的剩余缺口

两轮日志中都没有发现直接读取 labels、scored metrics、per-example、DeepSeek
v58 artifact、git history 或另一 case prediction 的证据。Routed v12 的附加
`session-read-audit.json` 扫描了 30 个 log、217 条命令，相关计数均为零。

但“严格可证明”仍有以下工程缺口：

1. 运行使用 `danger-full-access`；read allowlist 是提示与事后日志审计，不是
   kernel/container 强制挂载边界。
2. 通用 validator 的 `forbidden_read_occurred = false` 是固定字段，本身不读取
   session JSONL，不能单独证明无越界读取。
3. Routed run 有 4 个 session、standalone 有 6 个 session 读取了 task allowlist
   未显式列出的共享诊断源码。这些文件是 gold-free 代码，不是 label 泄漏，
   但说明“严格只读 allowlist”声明不完全成立。
4. Standalone 有 3 个 child 把手工调用的 local audit 写入 sibling 历史 output
   路径；parent 随后在正确路径重验，prediction 未被改变，但 filesystem/output
   boundary 没有强制。
5. Standalone runner 没有对所有未评分 attempt 目录要求为空；本轮日志显示
   prediction 都由当前 session 新增，实际没有 stale reuse，但实现不是完全
   fail-closed。
6. 产物可证明请求配置为 Luna/medium，却没有独立 provider-resolved-model
   provenance；routed run 也只 snapshot 直接 v12 source，未保存完整 imported
   implementation closure。

这些缺口不是 routed v12 的主要否决原因——prior-answer routing 已足以否决——
但下一次可晋升实验必须一起修正，不能继续把常量 audit 字段当成真实执行审计。

## 当前状态

- 原目标保持未完成；不调用 `update_goal(complete)`。
- Routed v12 的 13/30 保留为历史、协议不合规的调优结果，不得作为当前目标
  incumbent。
- Proposal-free standalone v12 保留为合规方向的完整对照，但其 7/30 不达标。
- 按用户“v10 后暂停优化”的指令，本次只做只读完成审计，没有启动新的 Luna
  session、候选协议或评分实验。

若以后恢复优化，新 runner 至少应做到：不读取任何旧 prediction/proposal；
统一 one-case flow；强制或可证明的 read isolation；冻结完整实现闭包；持久化
实际 command/model/concurrency provenance；拒绝非空新 run 目录；全 30 成功和
严格 audit 后才加载 gold。

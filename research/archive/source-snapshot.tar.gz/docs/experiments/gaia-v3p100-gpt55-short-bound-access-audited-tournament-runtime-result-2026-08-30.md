# GAIA v3.100 GPT-5.5 short-bound access tournament runtime result

Date: 2026-08-30

v3.100 completed `50/50` cases and `100/100` semantic stages but failed the
mandatory access gate before scoring. It is frozen and unscored; no gold was
read. Short paths fixed all six v3.99 path-abbreviation failures. Remaining
failures were two reducer calls using unadvertised `action 1` instead of
`owner 1 action`, plus reducers 33 and 41 returning after task-only access with
no candidate timeline coverage. Runtime contracts otherwise passed and there
were no case failures.

First divergence is `runtime_or_validation_failure`. The minimal correction is
not to weaken coverage: validate access inside each stage before materializing
its semantic response, reject noncompliant attempts gold-free, and allow the
existing fresh retry. Add explicit owner-command guidance. Step ranking remains
unchanged.

# GAIA v3.94 GPT-5.5 literal-response-only audited no-bwrap tournament preregistration

Date: 2026-08-29

## Frozen identity

- Version: `agentdebug.codex-agent-judge.gaia-v3.94-gpt55-response-only-audited-no-bwrap-predicate-handoff-tournament`.
- Direct semantic parent: accepted v3.83, Step Exact `26/50`.
- Dataset: frozen `gaia-paper-v1`, 50 cases.
- Dataset manifest identity SHA-256: `fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11`.
- Cohort identity SHA-256: `193dea48f9f9cd672215a8bdf4c82ab771836cb3fffe8768468facd5c6870240`.
- Prediction manifest file SHA-256: `77815b429514b136d715c5914eee912637a2e942979dd23f7d614aa33ee508cc`.
- Cohort manifest file SHA-256: `31140b667a479431abf5e0e274752cb9a486ec5f4a9d80b471b617e586b48126`.
- Frozen v3.83 protocol SHA-256: `a97908a78cec8df5fe9e4777d30aa9ecf498d1cdd1d692a42cc66976e9844531`.
- Frozen v3.83 predictions SHA-256: `f74161b06c456461ccacdcf7c708157154e8e9810cb5dffa8ef09352698fca3d`.
- Model and reasoning effort: `gpt-5.5` / `medium` for both stages.

## Prior evidence and first divergence

The semantic hypothesis remains the clean-v3.83 outcome-conditioned
predicate-handoff tournament. v3.93 established that no-bwrap transport can
read the staged JudgeView and complete `50/50` cases, but its pre-score access
audit rejected the run. Across 100 successful semantic stages, 40 commands were
outside the exact allowlist: 31 real ledger/checkpoint file writes and nine
chained inspector calls. Seven command events lacked a completed exit-zero
record and 27 stages lacked independently auditable task plus full timeline
coverage. Labels were never read and v3.93 was unscored.

The first divergence is `runtime_or_validation_failure`. The semantic protocol
used “write ledger/checkpoint” to describe internal decision ordering. Once
bwrap was disabled, the model often interpreted that wording literally as
filesystem I/O, and sometimes used `&&` to reduce inspector calls.

## One semantic mechanism and Step-invariant transport clarification

Relative to accepted v3.83, the only semantic mechanism is unchanged:

- preserve the GPT-5.5 packet-state anchor and native chronological ledger;
- replace the one-proposal challenger/default-keep arbiter with one
  outcome-conditioned exact-predicate handoff tournament over every native
  ledger Step;
- select exactly one anchor-or-prefix winner and freeze an exact copy.

The only change from the v3.93 attempt is a uniform response-only clarification:

- semantic “write/freeze” means construct/fix fields in the one final JSON;
- only the parent runtime persists artifacts;
- prohibit file creation/modification/deletion, general Python, heredocs,
  redirects, pipes, command substitution and command chaining;
- require exactly one listed inspector subcommand per tool call;
- require a completed exit-zero event before another command or final response;
- require independent task inspection and complete timeline coverage.

The wording replacement affects transport behavior only and cannot directly
change a selected Step. Singleton forced-keep and same-Step evidence repair
remain Step-invariant legality conditions. v3.93 predictions are not reused.

## Impact analysis

The transport clarification is expected to repair the 35 invalid-command
stages and 27 coverage failures without changing Judge semantics. Its direct
Step gain/regression capacity is zero; it only makes the tournament eligible to
be measured. Once measurable, the semantic mechanism's primary risk remains an
early shift caused by treating informative acquisition probes as mature
predicate handoffs. Candidate flooding and shallow preview comparison remain
secondary risks.

Reject the version if Step Exact is `<=26/50`, if any of 50 cases is incomplete,
or if any schema, taxonomy, evidence, exact-command, exit-code, task/timeline,
case-routing, or gold-free audit fails.

## Acceptance and Goal completion

- Accept only if Step Exact is strictly greater than `26/50` and every legality check passes.
- Complete the Goal only if Step Exact is at least `30/50` and every legality check passes.
- Only Step Exact selects, accepts, rejects, or completes versions.
- No smoke gate is used; after offline validation run the complete GAIA-50 directly.

## Pre-inference freeze

- Protocol source SHA-256: `940e09961887dad0f8ee2173f014595aad28a3f72de7d61e91edc1c24d6eb9fd`.
- Runner source SHA-256: `b61c9488833977561754c8247eaed9853b2429ddceadf5ae34d6347193540d70`.
- Inspector source SHA-256: `556e8fe1e77186a55521f74734b05d35a33fe482a50d30b5bc21ce7ef02f7677`.
- Negative/identity test source SHA-256: `751d846409ce7653925f398a00ff85d0d91c12c51648dbfec0840286930fc128`.
- Offline validation: compilation passed; 28 targeted and inherited tests
  passed; direct-parent identity, semantic-write wording removal,
  response-only/no-file-write contract, one-command requirement, no-bwrap
  preservation, compatibility binding, registry, and 50-case dry preparation
  passed.
- Static inference-source scan found no labels, metrics, scored artifacts,
  historical predictions, trajectory/entity router, or post-score audit reader.


# Configuration

The public method is AgentDebug: GPT-5.5 / medium, three fresh stages per case,
up to four concurrent cases and two attempts per stage. Its fixed settings
live in `agentdebug.method`; the public CLI has no method or protocol selector.

`moltbot/` contains optional source-collection settings. Files under
`experiments/` and the historical reproduction registry retain audit identities;
they are not alternative supported defaults.

Use [Getting started](../docs/getting-started.md) for diagnosis and
[Reproduction](../REPRODUCING.md) for the supported result. Historical
configuration mappings are available through the [research archive](../research/README.md).

Do not put credentials in configuration files. Keep machine-specific paths and
private manifests out of committed configuration. Frozen identities must not
be rewritten to disguise a change in the method.

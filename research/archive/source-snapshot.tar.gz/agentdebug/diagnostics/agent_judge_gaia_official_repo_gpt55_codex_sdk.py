"""Validation identity for the public AgentDebug topology over Codex SDK.

This protocol preserves prompt construction, raw-trajectory parsing,
Phase-1/Phase-2 public topology, parsing, and normalization from the public
detector snapshot.  It changes model/transport and removes the older local
GPT-4.1 runner's non-public outer Phase-2 semantic retries and amendments, so
its result is not a controlled model-only comparison with that 14/50 run.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge import _validate_agent_judge_predictions_with_owner_sources
from .agent_judge_gaia_official_repo_gpt41 import (
    STRUCTURAL_ABSENCE_EVIDENCE,
    official_owner_sources,
)


VERSION = "agentdebug.codex-agent-judge.gaia-official-repo-gpt55-codex-sdk-v1"
MODEL = "gpt-5.5"
REASONING_EFFORT = "medium"
SDK_VERSION = "0.147.0"

# Codex SDK turns do not expose a temperature control.  ``None`` means that no
# temperature value is sent; it must never be reported as the public GPT-4.1
# reproduction's temperature=0 setting.
TEMPERATURE: None = None

OFFICIAL_REPOSITORY_COMMIT = "7740fe3a5c4822b2143cbde78ecfffeace0bb166"
OFFICIAL_SOURCE_SHA256 = {
    "fine_grained_analysis.py": (
        "b640537ba4ba3232d9def59ad6d5c7bc1e3bcb2ddc9f07f25e6081586a2712fd"
    ),
    "critical_error_detection.py": (
        "7791fc671eef2b8a1296131ce7a9ef68bbcaa63d518b1e17ab5bc08b9dcecb4c"
    ),
    "error_definitions.py": (
        "415ced442e998133d23526d05064eef908a8e4df50519d7355af12e838d9d9bb"
    ),
}


def build_protocol_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Describe the externally executed frozen public-repository protocol."""

    return f"""Public AgentDebug detector topology over Codex SDK.

Protocol: {VERSION}
Model: {MODEL}
Reasoning effort: {REASONING_EFFORT}
Codex SDK: {SDK_VERSION}
Temperature: unsupported and not sent
Prediction manifest: {Path(prediction_manifest_path).expanduser().resolve()}
Cohort manifest: {Path(cohort_manifest_path).expanduser().resolve()}
Predictions: {Path(predictions_path).expanduser().resolve()}

The dedicated runner imports the frozen public detector snapshot.  Phase 1
uses one fresh ephemeral SDK thread for every independent source step/module
call, preserving the public Step-1 and WebShop skips and conditional System
checks.  Phase 2 uses a fresh ephemeral SDK thread for every public global
critical-error call and preserves the public retry rule.  The public system
and user prompts are passed separately through SDK base instructions and turn
input.  No output schema is supplied because the old Chat Completions
json_object response format has no lossless Codex SDK mapping.  This is an
agentic-transport approximation: SDK 0.147 advertises apply_patch,
request_user_input, and update_plan with parallel tool calls enabled even
though every formal result must contain zero actual tool or harness items.  No
gold, labels, metrics, scored artifacts, prior prediction, or cross-case
semantic state is available before the complete prediction tree is frozen and
audited.
"""


def validate_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    """Apply the same strict legal-output policy as the GPT-4.1 reproduction."""

    base = _validate_agent_judge_predictions_with_owner_sources(
        Path(prediction_manifest_path).expanduser().resolve(),
        Path(cohort_manifest_path).expanduser().resolve(),
        Path(predictions_path).expanduser().resolve(),
        owner_source_resolver=official_owner_sources,
    )
    return {
        **base,
        "agent_judge_version": VERSION,
        "model": MODEL,
        "reasoning_effort": REASONING_EFFORT,
        "temperature": TEMPERATURE,
        "temperature_supported": False,
        "stage": "official-repository-step-module-phase1-then-joint-phase2",
        "joint_step_module_type_decision": True,
        "phase1_candidate_bound": False,
        "prior_final_prediction_visible": False,
        "segmented_nested_owner_sources": True,
        "official_structural_absence_source": STRUCTURAL_ABSENCE_EVIDENCE,
        "official_repository_commit": OFFICIAL_REPOSITORY_COMMIT,
        "official_source_sha256": OFFICIAL_SOURCE_SHA256,
        "transport": "codex-python-sdk-chatgpt-auth",
        "transport_comparison_class": "agentic-transport-approximation",
        "direct_api_equivalence_claimed": False,
        "sdk_version": SDK_VERSION,
        "fresh_ephemeral_thread_per_llm_call": True,
        "model_visible_core_tools": [
            "apply_patch",
            "request_user_input",
            "update_plan",
        ],
        "parallel_tool_calls_visible": True,
        "actual_tool_or_harness_item_policy": "fail_entire_run",
        "output_schema_supplied": False,
        "json_object_transport_equivalence_claimed": False,
    }


build_task = build_protocol_task


__all__ = [
    "MODEL",
    "OFFICIAL_REPOSITORY_COMMIT",
    "OFFICIAL_SOURCE_SHA256",
    "REASONING_EFFORT",
    "SDK_VERSION",
    "STRUCTURAL_ABSENCE_EVIDENCE",
    "TEMPERATURE",
    "VERSION",
    "build_protocol_task",
    "build_task",
    "official_owner_sources",
    "validate_predictions",
]

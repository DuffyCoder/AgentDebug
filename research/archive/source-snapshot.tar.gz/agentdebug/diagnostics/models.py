"""Public data contracts for the semantic LLM judge pipeline."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field, is_dataclass
from enum import Enum
from typing import Any, Mapping, Optional, Protocol, runtime_checkable

from agentdebug.trace.models import CanonicalTrace, IntegrityReport

from .redaction import redact
from .taxonomy import AgentModule, ErrorType


def _jsonable(value: Any) -> Any:
    if isinstance(value, Enum):
        return value.value
    if is_dataclass(value):
        return {key: _jsonable(item) for key, item in asdict(value).items()}
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(item) for item in value]
    return value


@dataclass
class JsonModel:
    def to_dict(self) -> dict[str, Any]:
        return redact(_jsonable(self))

    def to_json(self, *, indent: Optional[int] = 2) -> str:
        return json.dumps(
            self.to_dict(),
            ensure_ascii=False,
            indent=indent,
            sort_keys=False,
        )


class DiagnosticStatus(str, Enum):
    VALID = "valid"
    NEEDS_REVIEW = "needs_review"
    INVALID = "invalid"
    BLOCKED_BY_INTEGRITY = "blocked_by_integrity"


class ValidationLevel(str, Enum):
    REVIEW = "review"
    ERROR = "error"


@dataclass
class ModuleFinding(JsonModel):
    step: int
    event_id: str
    module: AgentModule
    error_type: ErrorType
    evidence_event_ids: list[str]
    evidence_quote: str
    reasoning: str


@dataclass
class ModuleSpecialistResult(JsonModel):
    module: AgentModule
    findings: list[ModuleFinding] = field(default_factory=list)


@dataclass
class RootCauseJudgment(JsonModel):
    critical_event_id: str
    critical_step: int
    module: AgentModule
    error_type: ErrorType
    root_cause: str
    evidence_quote: str
    evidence_event_ids: list[str]


@dataclass
class ValidationIssue(JsonModel):
    code: str
    level: ValidationLevel
    stage: str
    message: str
    entity_ids: list[str] = field(default_factory=list)


@dataclass
class EvidenceValidation(JsonModel):
    valid: bool
    needs_review: bool
    issues: list[ValidationIssue] = field(default_factory=list)


@dataclass
class JudgeFailure(JsonModel):
    stage: str
    code: str
    message: str


@dataclass
class ModuleSpecialistRequest:
    """Complete trace and one fixed module passed to its specialist."""

    trace: CanonicalTrace
    module: AgentModule


@dataclass
class ModuleArbiterRequest:
    """Complete trace plus the five parsed module-specialist analyses."""

    trace: CanonicalTrace
    module_analyses: list[ModuleSpecialistResult]


@dataclass
class CriticRequest:
    """Fresh trace, specialist analyses, and the initial arbiter judgment."""

    trace: CanonicalTrace
    module_analyses: list[ModuleSpecialistResult]
    initial_root: RootCauseJudgment


@runtime_checkable
class SemanticJudge(Protocol):
    def analyze_module(self, request: ModuleSpecialistRequest) -> Any:
        """Return one module specialist's findings."""

    def arbitrate_root_cause(self, request: ModuleArbiterRequest) -> Any:
        """Return the initial semantic root-cause judgment."""

    def critique_root_cause(self, request: CriticRequest) -> Any:
        """Return the critic's final semantic root-cause judgment."""


@dataclass
class DiagnosticReport(JsonModel):
    schema_version: int
    trace_id: str
    status: DiagnosticStatus
    integrity: IntegrityReport
    module_analyses: list[ModuleSpecialistResult] = field(
        default_factory=list
    )
    initial_root: Optional[RootCauseJudgment] = None
    root_cause: Optional[RootCauseJudgment] = None
    evidence_validation: Optional[EvidenceValidation] = None
    judge_failures: list[JudgeFailure] = field(default_factory=list)
    raw_judge_outputs: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

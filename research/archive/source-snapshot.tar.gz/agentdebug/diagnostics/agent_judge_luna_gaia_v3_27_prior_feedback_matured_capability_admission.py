"""Luna GAIA v3.27: prior-feedback-matured capability admission."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import (
    agent_judge_luna_gaia_v3_26_same_step_consumer_witnessed_state_ledger as parent,
)
from .agent_judge_luna_gaia_v3_4 import STEP_CANDIDATE_LEDGER_FILENAME


AGENT_JUDGE_LUNA_GAIA_V3_27_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.27-"
    "prior-feedback-matured-capability-admission"
)
AGENT_JUDGE_LUNA_GAIA_V3_27_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_26_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_27_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_26_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_27_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_26_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases used by the shared three-stage runner.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_27_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_27_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_27_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_27_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = parent.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = parent.CHALLENGERS_FILENAME
ARBITER_FILENAME = parent.ARBITER_FILENAME
ARBITERS_FILENAME = parent.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = parent.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = parent.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME


_MATURITY_PREFIX = re.compile(
    r"^state_scope=(?:memory_reflection|none); "
    r"state_fidelity=(?:faithful|dropped_necessary_fact|unsupported_fact|outcome_misread|not_applicable); "
    r"capability_maturity=(not_applicable|unobserved|observed); "
    r"prior_limitation_step=(none|[1-9]\d*); "
)

_CAPABILITY_MATURITY_GATE = """\
PRIOR-FEEDBACK CAPABILITY MATURITY — BINDING BEFORE LANE-B ADMISSION

For every inspected Step, immediately after the required state_scope and
state_fidelity prefix, append exactly:

`capability_maturity=<not_applicable|unobserved|observed>; prior_limitation_step=<none|positive integer>; `

This contract applies only to an interface/corpus capability claim: a claim
that the selected tool, interface, static/dynamic modality, or corpus cannot
expose the acquisition predicate or a necessary intermediate.

- Use `not_applicable/none` when Lane B is not making an interface/corpus
  capability claim. Existing state, parameter, System, source-constraint,
  strategy, and terminal rules remain unchanged.
- Use `unobserved/none` when no literal tool/environment feedback strictly
  before this Step has directly exposed the exact chosen interface/corpus
  limitation. This is a binding Lane-B veto. Use `veto_initial_probe` for a
  first reasonable route or `veto_different_probe` for a materially different
  or refined route, then continue the chronological scan.
- Use `observed/N` only when Step N is strictly earlier than the inspected Step
  and literal feedback at N directly demonstrates the same interface/corpus
  limitation. The current Step's adjacent result is not prior feedback.
- After `observed/N`, a Planning/Action recommitment to the same unavailable
  evidence path may be a Lane-B candidate under the existing rules. Observation
  does not force admission when a different-route or other veto still applies.

Tool availability alone is never an observed limitation. Inability to prove
the final answer does not mature a capability claim when the route can still
return a necessary identifier, source, page, text, transcript lead, numerical
input, or immediate-subgoal clue. Do not make hypothetical contribution a
permanent exemption after direct feedback has exposed the limitation.

"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_26_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_27_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_26_same_step_consumer_witnessed_state_ledger",
            "agent_judge_luna_gaia_v3_27_prior_feedback_matured_capability_admission",
        )
        .replace(
            "same-Step consumer-witnessed state ledger",
            "same-Step consumer-witnessed state ledger with prior-feedback capability maturity",
        )
    )


def build_anchor_task(*paths: str | Path) -> str:
    task = _rewrite_identity(parent.build_anchor_task(*paths))
    marker = "Tool availability is not capability.  If a tool description/corpus cannot\n"
    if task.count(marker) != 1:
        raise RuntimeError("v3.26 Lane-B capability boundary changed unexpectedly")
    task = task.replace(marker, _CAPABILITY_MATURITY_GATE + marker, 1)
    task = task.replace(
        'state_fidelity=faithful; compact literal step assessment',
        "state_fidelity=faithful; capability_maturity=unobserved; "
        "prior_limitation_step=none; compact literal step assessment",
    )
    task = task.replace(
        'state_fidelity=unsupported_fact; compact reason this is the first surviving candidate',
        "state_fidelity=unsupported_fact; capability_maturity=not_applicable; "
        "prior_limitation_step=none; compact reason this is the first surviving candidate",
    )
    return task


def build_challenger_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_challenger_task(*paths))


def build_arbiter_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_arbiter_task(*paths))


def build_agent_judge_luna_gaia_v3_27_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / STEP_CANDIDATE_LEDGER_FILENAME,
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def _validate_capability_maturity_ledgers(path: str | Path) -> dict[str, Any]:
    ledger_path, raw = shared._load_artifact(path, role="capability-maturity ledger")
    ledgers = raw if isinstance(raw, list) else [raw]
    if not ledgers or any(not isinstance(item, dict) for item in ledgers):
        shared._fail("invalid_capability_maturity_ledger", "ledger records unavailable")

    counts: Counter[str] = Counter()
    row_count = unobserved_veto_count = observed_count = 0
    for ledger_index, ledger in enumerate(ledgers):
        rows = ledger.get("rows")
        if not isinstance(rows, list) or not rows:
            shared._fail(
                "invalid_capability_maturity_rows",
                f"ledger[{ledger_index}] rows unavailable",
            )
        for row_index, row in enumerate(rows):
            location = f"ledger[{ledger_index}].rows[{row_index}]"
            basis = row.get("decision_basis") if isinstance(row, dict) else None
            match = _MATURITY_PREFIX.match(basis or "")
            if match is None:
                shared._fail("missing_capability_maturity_prefix", location)
            maturity, prior_text = match.groups()
            current_step = row.get("step")
            if (
                isinstance(current_step, bool)
                or not isinstance(current_step, int)
                or current_step < 1
            ):
                shared._fail("invalid_capability_maturity_current_step", location)

            if maturity in {"not_applicable", "unobserved"}:
                if prior_text != "none":
                    shared._fail("unexpected_prior_limitation_step", location)
            else:
                if prior_text == "none" or int(prior_text) >= current_step:
                    shared._fail("invalid_prior_limitation_step", location)
                observed_count += 1

            if maturity == "unobserved":
                if row.get("lane_b") not in {
                    "veto_initial_probe",
                    "veto_different_probe",
                }:
                    shared._fail("unobserved_capability_lacks_lane_b_veto", location)
                unobserved_veto_count += 1

            counts[maturity] += 1
            row_count += 1

    return {
        "required": True,
        "valid": True,
        "path": str(ledger_path),
        "ledger_count": len(ledgers),
        "row_count": row_count,
        "maturity_counts": dict(sorted(counts.items())),
        "unobserved_lane_b_veto_count": unobserved_veto_count,
        "observed_prior_limitation_count": observed_count,
        "strictly_earlier_prior_limitation_enforced": True,
    }


def _retag_audit(audit: dict[str, Any]) -> dict[str, Any]:
    updated = dict(audit)
    updated["agent_judge_version"] = AGENT_JUDGE_LUNA_GAIA_V3_27_VERSION
    updated["model"] = AGENT_JUDGE_LUNA_GAIA_V3_27_MODEL
    updated["reasoning_effort"] = AGENT_JUDGE_LUNA_GAIA_V3_27_REASONING_EFFORT
    return updated


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    audit = _retag_audit(parent.validate_anchor_predictions(*paths))
    ledger = Path(paths[2]).expanduser().resolve().parent / STEP_CANDIDATE_LEDGER_FILENAME
    audit["prior_feedback_capability_maturity"] = (
        _validate_capability_maturity_ledgers(ledger)
    )
    return audit


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    audit = _retag_audit(parent.validate_challenger(*paths))
    audit["prior_feedback_capability_maturity"] = (
        _validate_capability_maturity_ledgers(paths[3])
    )
    return audit


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    audit = _retag_audit(parent.validate_arbiter(*paths))
    audit["prior_feedback_capability_maturity"] = (
        _validate_capability_maturity_ledgers(paths[3])
    )
    return audit


def validate_agent_judge_luna_gaia_v3_27_predictions(
    *paths: str | Path,
) -> dict[str, Any]:
    audit = _retag_audit(parent.validate_agent_judge_luna_gaia_v3_26_predictions(*paths))
    predictions = Path(paths[2]).expanduser().resolve()
    audit["schema_version"] = AGENT_JUDGE_LUNA_GAIA_V3_27_AUDIT_SCHEMA_VERSION
    audit["selection_policy"] = (
        "v3_20_packet_state_anchor_prior_feedback_matured_capability_admission_"
        "same_step_consumer_witnessed_state_challenger_default_keep_arbiter"
    )
    audit["prior_feedback_capability_maturity"] = (
        _validate_capability_maturity_ledgers(
            predictions.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME
        )
    )
    return audit


def _write_audit(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_27_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        validate_agent_judge_luna_gaia_v3_27_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_27_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_27_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_27_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_27_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())


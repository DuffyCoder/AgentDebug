"""Validation policy for the serial step, module, and error-type GAIA judge."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge import _validate_agent_judge_predictions_with_owner_sources
from .agent_judge_gaia_official_repo_gpt41_candidate_v3 import candidate_owner_sources
from .judge_view import JudgeView
from .taxonomy import AgentModule, ErrorType


VERSION = "agentdebug.llm-judge.gaia-official-repo-gpt4.1-serial-v4"
MODEL = "gpt-4.1"
TEMPERATURE = 0.0
REASONING_EFFORT = "not_applicable"


def _think_sources(view: JudgeView, predicted_step: int) -> tuple[str, ...]:
    step = view.steps[predicted_step - 1]
    values = [
        step.assistant_raw_output[span.content_start_char : span.content_end_char].strip()
        for span in step.module_spans
        if span.tag == "think"
    ]
    return tuple(value for value in values if value)


def serial_owner_sources(
    view: JudgeView,
    predicted_step: int,
    module: AgentModule,
    error_type: ErrorType,
) -> tuple[str, ...]:
    """Allow an unstructured GAIA think span to own reflection when appropriate."""

    sources = candidate_owner_sources(view, predicted_step, module, error_type)
    if sources or module != AgentModule.REFLECTION or predicted_step == 1:
        return sources
    return _think_sources(view, predicted_step)


def build_protocol_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    return f"""Serial GAIA diagnostic judge.

Protocol: {VERSION}
Model: {MODEL}
Temperature: {TEMPERATURE}
Prediction manifest: {Path(prediction_manifest_path).expanduser().resolve()}
Cohort manifest: {Path(cohort_manifest_path).expanduser().resolve()}
Predictions: {Path(predictions_path).expanduser().resolve()}

A step locator freezes one legal step from the complete canonical trajectory.
A fresh module judge receives that result and freezes an owner at the selected
step. A fresh error-type judge receives both prior results and selects only a
taxonomy type valid for the frozen module.
"""


def validate_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    base = _validate_agent_judge_predictions_with_owner_sources(
        Path(prediction_manifest_path).expanduser().resolve(),
        Path(cohort_manifest_path).expanduser().resolve(),
        Path(predictions_path).expanduser().resolve(),
        owner_source_resolver=serial_owner_sources,
    )
    return {
        **base,
        "agent_judge_version": VERSION,
        "model": MODEL,
        "reasoning_effort": REASONING_EFFORT,
        "temperature": TEMPERATURE,
        "stage": "serial-step-then-module-then-error-type",
        "step_independent_of_phase1_candidates": True,
        "strict_stage_handoff": True,
        "conceptual_reflection_from_gaia_think": True,
        "external_llm_api": True,
    }


build_task = build_protocol_task

"""Luna GAIA v3.32: clean v3.20 with a complete-Step-census challenger."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger as transport
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent


AGENT_JUDGE_LUNA_GAIA_V3_32_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.32-clean-v3.20-"
    "complete-step-census-challenger"
)
AGENT_JUDGE_LUNA_GAIA_V3_32_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_32_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_32_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases used by the shared three-stage runner.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_32_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_32_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_32_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_32_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = transport.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = transport.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = transport.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = transport.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = transport.CHALLENGERS_FILENAME
ARBITER_FILENAME = transport.ARBITER_FILENAME
ARBITERS_FILENAME = transport.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = transport.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = transport.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = transport.PREDICTION_AUDIT_FILENAME


_CENSUS_PREFIX = re.compile(
    r"^step_census=([^;]+); "
    r"census_candidate_step=(none|[1-9]\d*); "
    r"census_direction=(none|earlier|same|later); "
)
_CENSUS_ENTRY = re.compile(r"^([1-9]\d*):([a-z_]+)$")
_CENSUS_VERDICTS = frozenset(
    {
        "clear",
        "reasonable_probe",
        "normal_failure",
        "recovered_or_mechanical",
        "faithful_propagation",
        "noncritical_local_error",
        "critical_candidate",
    }
)


_COMPLETE_STEP_CENSUS_RULES = """\
COMPLETE-STEP CENSUS BEFORE ANCHOR CLASSIFICATION — ONE CANDIDATE MAXIMUM

The frozen v3.20 packet-state prediction is the incumbent anchor. Do not
change, repair, or re-run it. Complete the census below before deciding whether
the anchor is critical. The anchor remains the default under uncertainty.

PHASE 1 — EXACT COMPLETE TIMELINE CENSUS

Inspect every Canonical Step exactly once in chronological order, including
Steps before, at, and after the anchor. Do not stop when the anchor looks
plausible. Assign exactly one closed verdict to every Step:

- `clear`: no concrete task-material local error is observable.
- `reasonable_probe`: an initial or materially different information-gathering
  attempt can expose a needed fact, source, identifier, page, or lead.
- `normal_failure`: the chosen action was reasonable and only the tool/site
  outcome failed; an error message alone is not an Agent error.
- `recovered_or_mechanical`: a local defect is completely repaired or is only
  a noncritical mechanical predecessor to the later strategy/state decision.
- `faithful_propagation`: the Step merely carries forward an unresolved earlier
  state or evidence deficit without creating an independent error.
- `noncritical_local_error`: a real but merely improvable defect does not own
  the trajectory's critical benchmark boundary.
- `critical_candidate`: this is the single Step that best owns the observable
  matured critical boundary after full-timeline comparison.

Freeze at most one `critical_candidate`; every other Step must receive a veto
verdict above. A critical candidate requires all of:

1. literal local evidence of a specific error in its owning module;
2. a still-unresolved task condition materially affected by that error;
3. a repair counterfactual showing why correcting this Step can change the
   subsequent path or final answer;
4. comparison against earlier probes/mechanical predecessors and later
   propagation/symptoms so the candidate matches the matured critical boundary.

Do not pick a Step merely because it is earliest, latest, most severe, most
explicit, or easiest to quote. A repeated strategy becomes mature only after
literal prior feedback rules out the normalized route and the new Step adds no
material target, corpus, interface, or extraction change. A static interface
is a hard capability error only when visible evidence establishes that it
cannot expose the required predicate; otherwise it may be an informative
probe. Successful execution vetoes a claimed parameter-format error unless
literal feedback rejects or misparses the field. When evidence cannot
distinguish critical ownership, freeze no candidate.

Begin search_summary exactly with every Step/verdict pair in order:

`step_census=1:<verdict>,2:<verdict>,...; census_candidate_step=<none|Step>; census_direction=<none|earlier|same|later>; `

The certificate must contain every observable Step exactly once, with no extra
Step. Exactly one row must be `critical_candidate` when candidate_step is a
Step; zero rows must use it when candidate_step is none. Direction is relative
to the frozen anchor.

PHASE 2 — COMPARE THE CENSUS CANDIDATE WITH THE ANCHOR

- If no candidate exists, emit no_challenge.
- If the candidate equals the anchor, emit no_challenge: the anchor already
  owns the census boundary.
- For an earlier candidate, challenge only when the anchor is a downstream
  symptom and repairing only the anchor cannot remove the earlier defect.
- For a later candidate, challenge only when the anchor is a reasonable probe
  or noncritical predecessor and the later candidate remains independently
  failure-causing after anchor-only repair.
- If the distinct candidate loses this comparison, emit no_challenge but keep
  its Step and direction in the census certificate.

A challenge proposal must exactly use the frozen census_candidate_step and
literal evidence owned by that Step. Emit at most one proposal. Use
anchor_only_repair_counterfactual, proposal_only_repair_counterfactual, and
direct_timeline_comparison to compare the anchor, the candidate, and every
intervening plausible boundary. Do not invent a candidate pool, case rule, or
third prediction. When uncertain, no_challenge.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_32_VERSION,
        )
        .replace(
            transport.AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_32_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_32_clean_v3p20_complete_step_census_challenger",
        )
        .replace(
            "agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger",
            "agent_judge_luna_gaia_v3_32_clean_v3p20_complete_step_census_challenger",
        )
    )


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_anchor_task(*paths))


def build_challenger_task(*paths: str | Path) -> str:
    task = transport.build_challenger_task(*paths)
    if task.count(transport._BOUNDED_BIDIRECTIONAL_RULES) != 1:
        raise RuntimeError("bounded challenger rule marker changed unexpectedly")
    task = task.replace(
        transport._BOUNDED_BIDIRECTIONAL_RULES,
        _COMPLETE_STEP_CENSUS_RULES,
        1,
    )
    task = task.replace(
        '"which direction was searched and why one proposal exists or none qualifies"',
        '"step_census=1:clear,...; census_candidate_step=none; '
        'census_direction=none; literal complete-census comparison"',
    )
    return _rewrite_identity(task)


def _validate_census_records(path: str | Path, cases: Sequence[Any]) -> dict[str, Any]:
    challenger_path, raw = shared._load_artifact(path, role="complete-Step census")
    records = raw if isinstance(raw, list) else [raw]
    if len(records) != len(cases) or any(not isinstance(item, dict) for item in records):
        shared._fail("invalid_step_census_record_count", "case/record count differs")

    verdict_counts: Counter[str] = Counter()
    direction_counts: Counter[str] = Counter()
    candidate_count = 0
    challenge_count = 0
    for index, (record, case) in enumerate(zip(records, cases, strict=True)):
        location = f"step_census[{index}]"
        match = _CENSUS_PREFIX.match(str(record.get("search_summary") or ""))
        if match is None:
            shared._fail("missing_complete_step_census_prefix", location)
        census_text, candidate_text, direction = match.groups()
        entries: list[tuple[int, str]] = []
        for entry_text in census_text.split(","):
            entry_match = _CENSUS_ENTRY.match(entry_text)
            if entry_match is None:
                shared._fail("invalid_step_census_entry", f"{location}:{entry_text}")
            step_text, verdict = entry_match.groups()
            if verdict not in _CENSUS_VERDICTS:
                shared._fail("invalid_step_census_verdict", f"{location}:{verdict}")
            entries.append((int(step_text), verdict))
            verdict_counts[verdict] += 1
        expected_steps = [step.step for step in case.judge_view.steps]
        if [step for step, _ in entries] != expected_steps:
            shared._fail("step_census_step_list_mismatch", location)

        critical_steps = [step for step, verdict in entries if verdict == "critical_candidate"]
        candidate_step = None if candidate_text == "none" else int(candidate_text)
        if candidate_step is None:
            if critical_steps or direction != "none":
                shared._fail("invalid_empty_census_candidate", location)
        else:
            if critical_steps != [candidate_step]:
                shared._fail("census_candidate_binding_mismatch", location)
            anchor_step = record.get("anchor_step")
            expected_direction = (
                "earlier"
                if candidate_step < anchor_step
                else "later"
                if candidate_step > anchor_step
                else "same"
            )
            if direction != expected_direction:
                shared._fail("census_candidate_direction_mismatch", location)
            candidate_count += 1

        if record.get("challenge_status") == "challenge":
            proposal = record.get("proposed_prediction")
            if (
                candidate_step is None
                or direction not in {"earlier", "later"}
                or not isinstance(proposal, dict)
                or proposal.get("predicted_step") != candidate_step
            ):
                shared._fail("proposal_differs_from_census_candidate", location)
            challenge_count += 1
        direction_counts[direction] += 1
    return {
        "required": True,
        "valid": True,
        "path": str(challenger_path),
        "record_count": len(records),
        "exact_complete_step_enumeration": True,
        "one_candidate_maximum": True,
        "candidate_count": candidate_count,
        "challenge_count": challenge_count,
        "verdict_counts": dict(sorted(verdict_counts.items())),
        "direction_counts": dict(sorted(direction_counts.items())),
    }


def _retag(audit: dict[str, Any]) -> dict[str, Any]:
    result = dict(audit)
    result["agent_judge_version"] = AGENT_JUDGE_LUNA_GAIA_V3_32_VERSION
    result["model"] = AGENT_JUDGE_LUNA_GAIA_V3_32_MODEL
    result["reasoning_effort"] = AGENT_JUDGE_LUNA_GAIA_V3_32_REASONING_EFFORT
    return result


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths))


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    audit = _retag(transport.validate_challenger(*paths))
    _, _, case = shared._single_case_paths(paths[0], paths[1])
    audit["schema_version"] = "agentdebug.complete-step-census-challenger-audit.v1"
    audit["complete_step_census"] = _validate_census_records(paths[5], [case])
    return audit


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    audit = _retag(transport.validate_arbiter(*paths))
    _, _, case = shared._single_case_paths(paths[0], paths[1])
    audit["schema_version"] = "agentdebug.complete-step-census-arbiter-audit.v1"
    audit["complete_step_census"] = _validate_census_records(paths[5], [case])
    return audit


def build_arbiter_task(*paths: str | Path) -> str:
    validate_challenger(*paths[:6])
    task = transport.build_arbiter_task(*paths)
    if task.count(transport._BOUNDED_BIDIRECTIONAL_RULES) != 1:
        raise RuntimeError("bounded arbiter rule marker changed unexpectedly")
    task = task.replace(
        transport._BOUNDED_BIDIRECTIONAL_RULES,
        _COMPLETE_STEP_CENSUS_RULES,
        1,
    )
    return _rewrite_identity(task)


def build_agent_judge_luna_gaia_v3_32_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def validate_agent_judge_luna_gaia_v3_32_predictions(
    *paths: str | Path,
) -> dict[str, Any]:
    audit = _retag(transport.validate_agent_judge_luna_gaia_v3_16_predictions(*paths))
    _, _, cases = shared._load_cases(paths[0], paths[1])
    predictions = Path(paths[2]).expanduser().resolve()
    audit["schema_version"] = AGENT_JUDGE_LUNA_GAIA_V3_32_AUDIT_SCHEMA_VERSION
    audit["selection_policy"] = (
        "clean_v3_20_packet_state_anchor_complete_step_census_before_anchor_"
        "classification_one_bidirectional_challenger_default_keep_exact_copy_arbiter"
    )
    audit["direct_semantic_parent"] = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION
    audit["rejected_lineage_inherited"] = False
    audit["anchor_semantics_unchanged_from_v3_20"] = True
    audit["packet_state_closure"] = parent._validate_packet_state_ledgers(
        predictions.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME
    )
    audit["complete_step_census"] = _validate_census_records(
        predictions.parent / CHALLENGERS_FILENAME,
        cases,
    )
    return audit


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_32_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_32_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_32_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_32_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_32_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_32_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

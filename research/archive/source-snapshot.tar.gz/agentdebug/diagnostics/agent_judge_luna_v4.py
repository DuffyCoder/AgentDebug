"""Luna Agent Judge v4: chronological scan with breakpoint backtrace.

V4 freezes Luna v3's standalone decision order and adds one narrow review:
before finalizing a provisional breakpoint, trace the identical error
proposition backward to its first directly mature introduction.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_v2_4 import (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION,
    _v2_4_owner_source_resolver,
)
from .agent_judge_luna_v3 import (
    AGENT_JUDGE_LUNA_V3_MODEL,
    AGENT_JUDGE_LUNA_V3_VERSION,
    build_agent_judge_luna_v3_task,
)


AGENT_JUDGE_LUNA_V4_VERSION = "agentdebug.codex-agent-judge.luna-v4"
AGENT_JUDGE_LUNA_V4_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_V4_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_V4_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)

_BASE_HEADER = f"Run the frozen Codex Agent Judge protocol {AGENT_JUDGE_LUNA_V3_VERSION}."
_LUNA_HEADER = (
    "Run the frozen Codex Agent Judge protocol "
    f"{AGENT_JUDGE_LUNA_V4_VERSION}."
)
_BASE_MODEL = f"- model: {AGENT_JUDGE_LUNA_V3_MODEL}"
_LUNA_MODEL = f"- model: {AGENT_JUDGE_LUNA_V4_MODEL}"
_BASE_ALLOWLIST = "agentdebug/diagnostics/agent_judge_luna_v3.py"
_LUNA_ALLOWLIST = "agentdebug/diagnostics/agent_judge_luna_v4.py"
_BASE_VALIDATOR_IMPORT = "agentdebug.diagnostics.agent_judge_luna_v3"
_LUNA_VALIDATOR_IMPORT = "agentdebug.diagnostics.agent_judge_luna_v4"
_BASE_VALIDATOR_ENTRY = "validate_and_write_agent_judge_luna_v3_audit"
_LUNA_VALIDATOR_ENTRY = "validate_and_write_agent_judge_luna_v4_audit"
_OWNER_MARKER = "\n3. SAME-STEP OWNER AFTER STEP FREEZE\n"

_BREAKPOINT_BACKTRACE = """
MANDATORY PROVISIONAL-BREAKPOINT BACKTRACE

After finding a provisional step S, pause before owner/type selection.  Write
the defect as one precise proposition (for example: repeats an exhausted PDF
extractor, treats one gender count as sufficient, asserts an unsupported color,
or emits a quoted command).  Search S-1 and then every earlier assistant step
for the SAME proposition or the decision that first introduced it.

Move the breakpoint backward when the earlier source already satisfies all
three tests:
1. directness — then-available task text, interface, observation, or feedback
   directly demonstrates the error without hindsight;
2. identity — the provisional defect is a copy, execution, consequence, or
   restatement of this same earlier proposition;
3. materiality — the earlier output begins the wrong branch, failed
   interaction, or unsupported conclusion rather than being harmless wording.

Apply this recursively until no earlier step passes all three tests.  Common
backtrace obligations are:
- when a later reflection says information is sufficient/insufficient, inspect
  the first reflection immediately after the decisive tool result;
- when a later plan repeats a source, query, page, object, or location, inspect
  the first recommitment after disconfirming feedback, not the later explicit
  admission that progress is poor;
- when an action is malformed, unavailable, or mechanically misparameterized,
  inspect the first concrete invocation with that exact interface defect;
- when a final answer is unsupported, inspect the first earlier memory,
  reflection, or planning assertion that supplies the unsupported content.

This is a SAME-DEFECT backtrace, not a general bias toward low step numbers.
Do not move backward to an unrelated imperfection, a merely broad strategy, or
a probe that was reasonable before new feedback.  If new decisive evidence
first arrives between the earlier step and S, keep S.  In causal_summary, state
the observation/feedback that made the frozen step mature and why the nearest
earlier same-branch step was or was not already defective.
"""


def build_agent_judge_luna_v4_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build Luna v3 plus the frozen same-defect breakpoint backtrace."""

    task = build_agent_judge_luna_v3_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    replacements = {
        _BASE_HEADER: _LUNA_HEADER,
        _BASE_MODEL: _LUNA_MODEL,
        _BASE_ALLOWLIST: _LUNA_ALLOWLIST,
        _BASE_VALIDATOR_IMPORT: _LUNA_VALIDATOR_IMPORT,
        _BASE_VALIDATOR_ENTRY: _LUNA_VALIDATOR_ENTRY,
        _OWNER_MARKER: f"\n{_BREAKPOINT_BACKTRACE.strip()}\n{_OWNER_MARKER}",
    }
    for old, new in replacements.items():
        if task.count(old) != 1:
            raise RuntimeError(
                "Agent Judge Luna v3 task changed at a frozen v4 marker"
            )
        task = task.replace(old, new, 1)
    return task


def validate_agent_judge_luna_v4_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_v2_4_owner_source_resolver,
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_V4_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_V4_VERSION,
        "model": AGENT_JUDGE_LUNA_V4_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V4_REASONING_EFFORT,
    }


def validate_and_write_agent_judge_luna_v4_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_v4_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


__all__ = [
    "AGENT_JUDGE_LUNA_V4_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_V4_MODEL",
    "AGENT_JUDGE_LUNA_V4_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_V4_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "build_agent_judge_luna_v4_task",
    "validate_agent_judge_luna_v4_predictions",
    "validate_and_write_agent_judge_luna_v4_audit",
]

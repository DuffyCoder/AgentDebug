"""GAIA strict-v8.2 interface hardening for full-cohort execution."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge_gaia_official_repo_gpt41_strict_v8_1 import (
    MODEL,
    REASONING_EFFORT,
    TEMPERATURE,
    validate_predictions as _validate_v8_1_predictions,
)


VERSION = "agentdebug.llm-judge.gaia-official-repo-gpt4.1-strict-v8.2"


def build_protocol_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    return f"""Frozen strict-v8.2 GAIA diagnostic judge.

Protocol: {VERSION}
Model: {MODEL}
Expected provider-resolved model: gpt-4.1-2025-04-14
Temperature: {TEMPERATURE}
Prediction manifest: {Path(prediction_manifest_path).expanduser().resolve()}
Cohort manifest: {Path(cohort_manifest_path).expanduser().resolve()}
Predictions: {Path(predictions_path).expanduser().resolve()}

Version 8.2 retains strict-v8 semantic topology and v8.1 JSON normalization.
It additionally discards structurally invalid recommitment slots and derives a
literal quote from the selected module's frozen observable output when the model
fails to copy one.  These operations cannot change a selected step, module, or
error type.  Historical predictions and gold labels remain inference-invisible.
"""


def validate_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    base = _validate_v8_1_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    return {
        **base,
        "agent_judge_version": VERSION,
        "interface_hardening": "strict-v8.2-structural-slot-and-quote-normalization",
        "invalid_recommitment_slots_discarded": True,
        "nonliteral_module_quote_parent_derived": True,
        "selected_step_module_type_unchanged_by_normalization": True,
    }


build_task = build_protocol_task

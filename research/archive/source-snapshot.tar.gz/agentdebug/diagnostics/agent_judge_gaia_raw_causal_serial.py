"""Label-free raw-trajectory Step, Module, and Type agents for GAIA."""

from __future__ import annotations

import shlex
from pathlib import Path
from typing import Any, Mapping

from . import agent_judge_gaia_causal_serial as causal
from . import agent_judge_luna_v3_serial as serial


VERSION = "agentdebug.codex-agent-judge.gaia-raw-causal-serial-v1"
MODEL = "gpt-5.5"
REASONING_EFFORT = "xhigh"
STEP_DECISIONS_FILENAME = serial.STEP_DECISIONS_FILENAME
MODULE_DECISIONS_FILENAME = serial.MODULE_DECISIONS_FILENAME
STEP_AUDIT_FILENAME = serial.STEP_AUDIT_FILENAME
MODULE_AUDIT_FILENAME = serial.MODULE_AUDIT_FILENAME


def _upgrade(value: Mapping[str, Any], *, stage: str) -> dict[str, Any]:
    return {
        **value,
        "agent_judge_version": VERSION,
        "model": MODEL,
        "reasoning_effort": REASONING_EFFORT,
        "stage": stage,
        "phase1_visible": False,
        "prior_final_prediction_visible": False,
        "raw_complete_trajectory_visible": True,
    }


def validate_step_predictions(*args: str | Path) -> dict[str, Any]:
    return _upgrade(
        serial.validate_agent_judge_luna_v3_serial_step_predictions(*args),
        stage="raw-causal-step",
    )


def validate_module_predictions(*args: str | Path) -> dict[str, Any]:
    return _upgrade(
        causal.validate_module_predictions(*args),
        stage="selected-step-owner",
    )


def validate_predictions(*args: str | Path) -> dict[str, Any]:
    return _upgrade(
        causal.validate_predictions(*args),
        stage="late-bound-type",
    )


def _write_audit(path: str | Path, value: Mapping[str, Any]) -> dict[str, Any]:
    return causal._write_audit(path, value)


def validate_and_write_step_audit(*args: str | Path) -> dict[str, Any]:
    return _write_audit(args[-1], validate_step_predictions(*args[:-1]))


def validate_and_write_module_audit(*args: str | Path) -> dict[str, Any]:
    return _write_audit(args[-1], validate_module_predictions(*args[:-1]))


def validate_and_write_prediction_audit(*args: str | Path) -> dict[str, Any]:
    return _write_audit(args[-1], validate_predictions(*args[:-1]))


def _validator_command(function: str, *arguments: Path) -> str:
    rendered = ", ".join(repr(str(item)) for item in arguments)
    code = (
        "import json; from agentdebug.diagnostics."
        "agent_judge_gaia_raw_causal_serial import "
        f"{function} as run; print(json.dumps(run({rendered}), "
        "ensure_ascii=False, indent=2))"
    )
    return "PYTHONPATH=. python3 -c " + shlex.quote(code)


def _runtime(task: str) -> str:
    return (
        task.replace(serial.AGENT_JUDGE_LUNA_V3_SERIAL_VERSION, VERSION)
        .replace(causal.VERSION, VERSION)
        .replace("model: gpt-5.6-luna", f"model: {MODEL}")
        .replace("model: gpt-5.6-sol", f"model: {MODEL}")
        .replace("model=gpt-5.6-luna", f"model={MODEL}")
        .replace("model=gpt-5.6-sol", f"model={MODEL}")
        .replace("reasoning_effort: medium", f"reasoning_effort: {REASONING_EFFORT}")
        .replace("reasoning_effort: high", f"reasoning_effort: {REASONING_EFFORT}")
        .replace("reasoning_effort=medium", f"reasoning_effort={REASONING_EFFORT}")
        .replace("reasoning_effort=high", f"reasoning_effort={REASONING_EFFORT}")
    )


_RAW_STEP_POLICY = """
LABEL-FREE COMPLETE-TRAJECTORY CAUSAL BOUNDARY

No Phase-1 finding, module label, error-type label, candidate proposal, or old
final prediction exists in this run. Derive Step only from the complete raw
Agent Output and its following Environment Response in the manifest.

Privately build a chronological ledger for every step with: (a) newly asserted
state, (b) unresolved task requirement, (c) normalized acquisition strategy
as source/corpus + modality + target/query, (d) what feedback established,
(e) whether the strategy is an initial probe, materially new probe, first
unsupported recommitment, later repeat, or recovered route. Do not output this
ledger and do not stop the scan at the first locally criticizable sentence.

The selected Step is the earliest MATURE material boundary, judged with full
retrospective evidence:

1. A concrete false state or feedback interpretation matures immediately when
   it drives the branch. A merely incomplete summary does not mature unless a
   salient observed fact needed by the next decision is actually lost.
2. Exploration is normal. The first reasonable probe and a genuinely different
   source/modality/target/query are not inefficient merely because they fail.
3. An inefficient acquisition strategy matures at the first recommitment after
   direct uninformative/contrary feedback, or at the first commitment whose
   corpus/modality cannot supply the requested evidence. Choose that onset, not
   the last repeated query, terminal pagination, or later malformed action.
4. Wording-only query changes do not reset a strategy; a new discriminating
   constraint, source, modality, or target does. Recovery counts only if the
   agent uses the recovered information to return to a viable route.
5. Explicit constraint violations are not automatically stronger than an
   earlier acquisition, memory, or interpretation root. Conversely, do not
   invent an early inefficient-plan claim when the trajectory shows a normal
   probe and a later concrete boundary.
6. Trace backward from the released failure and apply the counterfactual:
   correcting this exact step must redirect the material failed branch. Reject
   weak premises that do not change downstream behavior and reject later
   independently sufficient symptoms when the branch was already determined.
7. An external execution failure is eligible at the action's own step only
   when literal adjacent feedback proves an independent exception for an
   otherwise well-formed request. Normal empty results, access denial content,
   raw bytes, or agent-caused arguments are not external failures.

Your artifact remains Step-only. Never name or emit module or error type.
"""


def build_step_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
) -> str:
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    output = Path(step_decisions_path).expanduser().resolve()
    audit = output.parent / STEP_AUDIT_FILENAME
    task = _runtime(
        serial.build_agent_judge_luna_v3_serial_step_task(
            prediction, cohort, output
        )
    )
    old = serial._validator_command(
        "validate_and_write_agent_judge_luna_v3_serial_step_audit",
        prediction, cohort, output, audit,
    )
    new = _validator_command(
        "validate_and_write_step_audit", prediction, cohort, output, audit
    )
    task = task.replace(
        "\nSTRICT OUTPUT CONTRACT\n",
        _RAW_STEP_POLICY + "\nSTRICT OUTPUT CONTRACT\n",
        1,
    )
    return task.replace(old, new)


_OWNER_POLICY = """
SELECTED-STEP INFORMATION-FLOW OWNERSHIP

Classify only the frozen step. Read the complete selected Agent Output, the
prior state, and following feedback. A visible local flaw is not enough: the
owner is the block that first introduces the particular defect for which Step
was frozen.

- Memory requires a concrete false, invented, omitted, or unretrieved prior
  state consumed at this step. Accurate but incomplete prose is not Memory.
- Reflection requires an explicit false evaluation of feedback, outcome,
  progress, or cause. Merely stating an observation is not Reflection.
- Planning owns a new bad source/modality/query/target, unsupported strategy,
  repeated acquisition commitment, ignored requirement, or abandonment when
  upstream state/evaluation is sound.
- Action owns only deviation from an otherwise adequate current plan, invalid
  operation/syntax, or a mechanically malformed/misfilled argument. A faithful
  execution of a bad query/strategy remains Planning even when nested Action
  text contains the tool call.
- System requires a literal provenance-backed independent execution boundary;
  later agent confusion never converts an agent-caused failure into System.

Planning evidence is the outer deliberative residual after nested Action spans
are removed. Do not select the owner with the easiest quote. Never revise Step.
"""


def build_module_task(*args: str | Path) -> str:
    prediction, cohort, step, output = map(
        lambda x: Path(x).expanduser().resolve(), args
    )
    audit = output.parent / MODULE_AUDIT_FILENAME
    task = _runtime(causal.build_module_task(prediction, cohort, step, output))
    old = causal._validator_command(
        "validate_and_write_module_audit", prediction, cohort, step, output, audit
    )
    new = _validator_command(
        "validate_and_write_module_audit", prediction, cohort, step, output, audit
    )
    task = task.replace(
        "\nSTRICT OUTPUT CONTRACT\n",
        _OWNER_POLICY + "\nSTRICT OUTPUT CONTRACT\n",
        1,
    )
    return task.replace(old, new)


def build_type_task(*args: str | Path) -> str:
    prediction, cohort, step, module, output = map(
        lambda x: Path(x).expanduser().resolve(), args
    )
    audit = output.parent / "prediction-audit.json"
    task = _runtime(
        causal.build_type_task(prediction, cohort, step, module, output)
    )
    old = causal._validator_command(
        "validate_and_write_prediction_audit",
        prediction, cohort, output, audit,
    )
    new = _validator_command(
        "validate_and_write_prediction_audit",
        prediction, cohort, output, audit,
    )
    return task.replace(old, new)


def build_protocol_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    output = Path(predictions_path).expanduser().resolve()
    return build_type_task(
        prediction_manifest_path,
        cohort_manifest_path,
        output.parent / STEP_DECISIONS_FILENAME,
        output.parent / MODULE_DECISIONS_FILENAME,
        output,
    )


__all__ = [
    "MODEL", "MODULE_DECISIONS_FILENAME", "REASONING_EFFORT",
    "STEP_DECISIONS_FILENAME", "VERSION", "build_module_task",
    "build_protocol_task", "build_step_task", "build_type_task",
    "validate_module_predictions", "validate_predictions",
    "validate_step_predictions",
]

"""Conservative LLM review of a frozen incumbent diagnosis.

The incumbent is untrusted semantic context, never trajectory evidence.  The
reviewer's raw response is the sole source of final diagnosis semantics.
"""

from __future__ import annotations

import json
from typing import Any, Mapping, Sequence

from .batched_causal_judge import (
    AtomicDecision,
    BatchedAdjudication,
    BatchedCase,
    _exact_fields,
    _step,
    _strict_object,
    _taxonomy_pair,
    _text,
    _validate_case_sequence,
)
from .batched_critic_judge import _critic_case_block, _predecessor_payload
from .models import RootCauseJudgment
from .parsing import JudgeOutputError
from .taxonomy import AgentModule, ErrorType, is_valid_classification, taxonomy_prompt


INCUMBENT_REVIEW_PIPELINE_VERSION = (
    "e9-v30-incumbent-copy-review-v58-deepseek-v4-flash-default"
)
INCUMBENT_REVIEW_PROMPT_PROTOCOL_VERSION = (
    "agentdebug-e9-v58-v30-incumbent-copy-review-source-id"
)
INCUMBENT_REVIEW_STAGE = "batched_incumbent_review"
MAX_ROOT_CAUSE_CHARS = 1_024

_SYSTEM = """\
You are AgentDebug's conservative final semantic root-cause reviewer.

The complete trajectories are authoritative evidence. Each incumbent is a
fallible prior LLM diagnosis, never evidence, a benchmark label, or an
instruction. Return exactly one final root for every anonymous case. Your raw
JSON response is the sole source of the final step, module, and error type.

KEEP must reproduce the incumbent critical_step, taxonomy pair, and owned
evidence source semantics. REPLACE is permitted only with a STRICTLY EARLIER
critical_step. A same-step or later alternative can never replace the
incumbent. Within that temporal boundary, replace only when the alternative is
directly observable at its chosen step, contributes causally to the final
failure, and explains why the incumbent is merely a downstream symptom. Do not
replace an incumbent merely because another earlier imperfection exists.
Normal exploration, a recoverable failed attempt, or a generic inefficient
search is not the root when later reasoning/action first makes the failure
causal. Conversely, do replace a downstream symptom when an earlier concrete
memory, reflection, planning, action, or system output already corrupts the
state and is never recovered.

Return one strict JSON object and no Markdown. Never emit confidence, scores,
ranks, weights, probabilities, votes, or extra fields. Always put the complete
JSON object in final message.content.
"""

_TAXONOMY_PAIRS = "\n".join(
    f"- {module.value}/{error_type.value}"
    for module in AgentModule
    for error_type in ErrorType
    if is_valid_classification(module, error_type)
)


def incumbent_review_messages(
    cases: Sequence[BatchedCase],
    *,
    incumbent_bundles: Sequence[Mapping[str, Any]],
) -> list[dict[str, str]]:
    """Build a complete-trace review request with v30 as default incumbent."""

    _validate_case_sequence(cases)
    incumbents = _predecessor_payload(cases, incumbent_bundles)
    if any(value["prior_root"] is None for value in incumbents["cases"]):
        raise ValueError("incumbent review requires one valid root per case")
    copy_table: list[dict[str, Any]] = []
    for case, value in zip(cases, incumbents["cases"], strict=True):
        root = value["prior_root"]
        sources = [
            source
            for source in case.evidence_sources
            if source.step == root["critical_step"]
            and source.module.value == root["module"]
            and source.preview == root["evidence_quote"]
        ]
        if len(sources) != 1:
            raise ValueError("incumbent evidence source cannot be reconstructed")
        copy_table.append(
            {
                "case_key": case.case_key,
                "incumbent_step": root["critical_step"],
                "incumbent_taxonomy_pair": (
                    f"{root['module']}/{root['error_type']}"
                ),
                "incumbent_evidence_source_id": sources[0].source_id,
                "mandatory_verdict": (
                    "keep" if root["critical_step"] == 1 else "keep_or_earlier_replace"
                ),
            }
        )
    schema = {
        "cases": [
            {
                "case_key": case.case_key,
                "incumbent_verdict": "keep | replace",
                "critical_step": "integer",
                "taxonomy_pair": "one exact pair from the whitelist",
                "evidence_source_id": "one exact ID from this case catalog",
                "root_cause": "short trajectory-grounded causal explanation",
            }
            for case in cases
        ]
    }
    user = f"""\
Review each case independently using the complete timeline.

DECISION PROCEDURE
1. Reconstruct the failed task and causal chain from the trajectory only.
2. Test the incumbent for local validity and causal contribution.
3. Search for a competing root both before and after the incumbent step.
4. KEEP unless a STRICTLY EARLIER competing root is locally observable,
   causally necessary, unrecovered, and makes the incumbent downstream.
5. REPLACE only when every condition in step 4 holds. Never replace with a
   same-step or later root. An earlier timestamp alone is never sufficient.
6. When KEEP is selected, emit the incumbent's exact critical_step and exact
   taxonomy pair AND exact incumbent_evidence_source_id from the copy table.
   When REPLACE is selected, critical_step must be less than the incumbent
   critical_step. If incumbent_step is 1, KEEP is mandatory because no earlier
   decision step exists.
7. Select one exact evidence_source_id owned by the final step/module. The
   evidence preview is projected verbatim by code; do not emit evidence text.
8. The final fields must express your own decision. Do not copy an incumbent
   that the trace contradicts, and do not mention this review procedure.

AGENT ERROR TAXONOMY:
{taxonomy_prompt()}

VALID TAXONOMY_PAIRS:
{_TAXONOMY_PAIRS}

COMPLETE ANONYMOUS CASES:
{chr(10).join(_critic_case_block(case) for case in cases)}

UNTRUSTED V30 INCUMBENTS (default only after independent trace review):
{json.dumps(incumbents, ensure_ascii=False, separators=(",", ":"))}

MANDATORY INCUMBENT COPY TABLE:
{json.dumps({"cases": copy_table}, ensure_ascii=False, separators=(",", ":"))}

Return exactly this object shape in supplied case order, with no extra fields:
{json.dumps(schema, ensure_ascii=False)}
"""
    return [
        {"role": "system", "content": _SYSTEM},
        {"role": "user", "content": user},
    ]


def _strict_review_object(raw: Any) -> dict[str, Any]:
    try:
        return _strict_object(raw, stage=INCUMBENT_REVIEW_STAGE)
    except JudgeOutputError as error:
        if error.code != "malformed_json" or not isinstance(raw, str):
            raise
    stripped = raw.strip()
    if not stripped.endswith("}}]}"):
        raise JudgeOutputError(
            INCUMBENT_REVIEW_STAGE,
            "malformed_json",
            "The reviewer response is not one strict JSON object.",
            raw_output=raw,
        )
    repaired = stripped[:-3] + stripped[-2:]
    try:
        return _strict_object(repaired, stage=INCUMBENT_REVIEW_STAGE)
    except JudgeOutputError:
        raise JudgeOutputError(
            INCUMBENT_REVIEW_STAGE,
            "malformed_json",
            "The reviewer response is not one strict JSON object.",
            raw_output=raw,
        ) from None


def _parse_case(
    value: Any,
    *,
    case: BatchedCase,
    index: int,
    raw: Any,
) -> BatchedAdjudication:
    stage = INCUMBENT_REVIEW_STAGE
    location = f"{stage}.cases[{index}]"
    if not isinstance(value, Mapping):
        raise JudgeOutputError(
            stage, "invalid_case", f"{location} must be an object.", raw_output=raw
        )
    record = _exact_fields(
        value,
        {
            "case_key",
            "incumbent_verdict",
            "critical_step",
            "taxonomy_pair",
            "evidence_source_id",
            "root_cause",
        },
        stage=stage,
        location=location,
        raw=raw,
    )
    if record["case_key"] != case.case_key:
        raise JudgeOutputError(
            stage,
            "invalid_case_key",
            f"{location}.case_key is invalid.",
            raw_output=raw,
        )
    verdict = record["incumbent_verdict"]
    if verdict not in {"keep", "replace"}:
        raise JudgeOutputError(
            stage,
            "invalid_incumbent_verdict",
            f"{location}.incumbent_verdict is invalid.",
            raw_output=raw,
        )
    step = _step(
        record["critical_step"],
        case=case,
        stage=stage,
        location=f"{location}.critical_step",
        raw=raw,
    )
    _pair, module, error_type = _taxonomy_pair(
        record["taxonomy_pair"],
        stage=stage,
        location=f"{location}.taxonomy_pair",
        raw=raw,
    )
    source_id = _text(
        record["evidence_source_id"],
        stage=stage,
        location=f"{location}.evidence_source_id",
        raw=raw,
        max_chars=128,
    )
    matching = [source for source in case.evidence_sources if source.source_id == source_id]
    if len(matching) != 1:
        raise JudgeOutputError(
            stage,
            "invalid_evidence_source_id",
            f"{location}.evidence_source_id is not in this case catalog.",
            raw_output=raw,
        )
    source = matching[0]
    if source.step != step.step or source.module != module:
        raise JudgeOutputError(
            stage,
            "invalid_evidence_source_ownership",
            f"{location}.evidence_source_id is not owned by the selected step/module.",
            raw_output=raw,
        )
    root_cause = _text(
        record["root_cause"],
        stage=stage,
        location=f"{location}.root_cause",
        raw=raw,
        max_chars=MAX_ROOT_CAUSE_CHARS,
    )
    decision = AtomicDecision(
        critical_step=step.step,
        module=module,
        error_type=error_type,
        evidence_quote=source.preview,
        root_cause=root_cause,
        evidence_source_id=source.source_id,
    )
    root = RootCauseJudgment(
        critical_event_id=step.assistant_event_id,
        critical_step=step.step,
        module=module,
        error_type=error_type,
        root_cause=root_cause,
        evidence_quote=source.preview,
        evidence_event_ids=list(source.event_ids),
    )
    return BatchedAdjudication(
        case_key=case.case_key,
        audit={"incumbent_verdict": verdict},
        decision=decision,
        root=root,
    )


def parse_incumbent_review(
    raw: Any,
    *,
    cases: Sequence[BatchedCase],
) -> list[BatchedAdjudication]:
    """Parse final semantics solely from the reviewer's raw response."""

    _validate_case_sequence(cases)
    payload = _exact_fields(
        _strict_review_object(raw),
        {"cases"},
        stage=INCUMBENT_REVIEW_STAGE,
        location=INCUMBENT_REVIEW_STAGE,
        raw=raw,
    )
    values = payload["cases"]
    if not isinstance(values, list) or len(values) != len(cases):
        raise JudgeOutputError(
            INCUMBENT_REVIEW_STAGE,
            "invalid_case_count",
            "Reviewer case count is invalid.",
            raw_output=raw,
        )
    return [
        _parse_case(value, case=case, index=index, raw=raw)
        for index, (value, case) in enumerate(zip(values, cases, strict=True))
    ]


def parse_incumbent_review_isolated(
    raw: Any,
    *,
    cases: Sequence[BatchedCase],
) -> tuple[list[BatchedAdjudication | None], list[JudgeOutputError | None]]:
    """Keep case-local format failures isolated after envelope validation."""

    _validate_case_sequence(cases)
    payload = _exact_fields(
        _strict_review_object(raw),
        {"cases"},
        stage=INCUMBENT_REVIEW_STAGE,
        location=INCUMBENT_REVIEW_STAGE,
        raw=raw,
    )
    values = payload["cases"]
    if not isinstance(values, list) or len(values) != len(cases):
        raise JudgeOutputError(
            INCUMBENT_REVIEW_STAGE,
            "invalid_case_count",
            "Reviewer case count is invalid.",
            raw_output=raw,
        )
    adjudications: list[BatchedAdjudication | None] = []
    failures: list[JudgeOutputError | None] = []
    for index, (value, case) in enumerate(zip(values, cases, strict=True)):
        try:
            adjudications.append(
                _parse_case(value, case=case, index=index, raw=raw)
            )
        except JudgeOutputError as error:
            adjudications.append(None)
            failures.append(error)
        else:
            failures.append(None)
    return adjudications, failures


__all__ = [
    "INCUMBENT_REVIEW_PIPELINE_VERSION",
    "INCUMBENT_REVIEW_PROMPT_PROTOCOL_VERSION",
    "INCUMBENT_REVIEW_STAGE",
    "incumbent_review_messages",
    "parse_incumbent_review",
    "parse_incumbent_review_isolated",
]

"""Five isolated module specialists → arbiter → adversarial critic."""

from __future__ import annotations

import json
import os
import shlex
from pathlib import Path
from typing import Any, Mapping, Sequence

from .agent_judge import AgentJudgeValidationError, _assert_safe_path, _file_sha256, _load_json
from .agent_judge_sol_gaia_two_stage import (
    AGENT_JUDGE_SOL_GAIA_TWO_STAGE_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_SOL_GAIA_TWO_STAGE_MODEL,
    AGENT_JUDGE_SOL_GAIA_TWO_STAGE_REASONING_EFFORT,
    AGENT_JUDGE_SOL_GAIA_TWO_STAGE_VERSION,
    CANDIDATE_PROPOSALS_FILENAME,
    build_sol_gaia_two_stage_task,
    validate_sol_gaia_candidate_proposals,
    validate_sol_gaia_two_stage_predictions,
)
from .taxonomy import AgentModule, ErrorType, TAXONOMY, taxonomy_prompt


AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_VERSION = (
    "agentdebug.codex-agent-judge.sol-gaia-specialist-critic-v1"
)
AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_MODEL = (
    AGENT_JUDGE_SOL_GAIA_TWO_STAGE_MODEL
)
AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_REASONING_EFFORT = (
    AGENT_JUDGE_SOL_GAIA_TWO_STAGE_REASONING_EFFORT
)
AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_SOL_GAIA_TWO_STAGE_AUDIT_SCHEMA_VERSION
)
INITIAL_ROOT_FILENAME = "initial-root.json"
SPECIALIST_MODULES = tuple(AgentModule)


def specialist_filename(module: AgentModule | str) -> str:
    value = AgentModule(module)
    return f"specialist-{value.value}.json"


def _fail(code: str, message: str) -> None:
    raise AgentJudgeValidationError(code, message)


def _write_audit(path: str | Path, value: Mapping[str, Any]) -> dict[str, Any]:
    target = Path(path).expanduser().resolve()
    _assert_safe_path(target, role="audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    temporary.replace(target)
    return dict(value)


def validate_sol_gaia_specialist_proposals(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposals_path: str | Path,
    module: AgentModule | str,
) -> dict[str, Any]:
    selected = AgentModule(module)
    audit = validate_sol_gaia_candidate_proposals(
        prediction_manifest_path,
        cohort_manifest_path,
        proposals_path,
        allow_empty=True,
    )
    rows = _load_json(Path(proposals_path).resolve(), role="specialist proposals")
    for index, row in enumerate(rows):
        candidates = row["candidates"]
        if len(candidates) > 6:
            _fail("specialist_candidate_overflow", f"case {index} has over 6 findings")
        if any(card["module"] != selected.value for card in candidates):
            _fail("specialist_module_escape", f"case {index} contains another module")
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_VERSION,
        "stage": f"specialist-{selected.value}",
        "assigned_module": selected.value,
        "specialist_candidate_limit": 6,
    }


def validate_and_write_sol_gaia_specialist_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposals_path: str | Path,
    audit_path: str | Path,
    module: AgentModule | str,
) -> dict[str, Any]:
    return _write_audit(
        audit_path,
        validate_sol_gaia_specialist_proposals(
            prediction_manifest_path,
            cohort_manifest_path,
            proposals_path,
            module,
        ),
    )


def merge_sol_gaia_specialist_proposals(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    specialist_paths: Sequence[str | Path],
    output_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    """Mechanically join five independently validated module artifacts."""

    if len(specialist_paths) != len(SPECIALIST_MODULES):
        _fail("specialist_set_incomplete", "exactly five specialist paths required")
    loaded = []
    source_hashes: dict[str, str] = {}
    for module, value in zip(SPECIALIST_MODULES, specialist_paths, strict=True):
        path = Path(value).expanduser().resolve()
        validate_sol_gaia_specialist_proposals(
            prediction_manifest_path, cohort_manifest_path, path, module
        )
        loaded.append(_load_json(path, role=f"{module.value} specialist"))
        source_hashes[module.value] = _file_sha256(path)
    row_count = len(loaded[0])
    if any(len(rows) != row_count for rows in loaded):
        _fail("specialist_cardinality_mismatch", "specialist row counts differ")
    merged = []
    for index in range(row_count):
        identities = {
            (
                rows[index]["trajectory_id"],
                rows[index]["trajectory_sha256"],
                rows[index]["status"],
            )
            for rows in loaded
        }
        if len(identities) != 1:
            _fail("specialist_identity_mismatch", f"case {index} identities differ")
        trajectory_id, trajectory_sha256, status = identities.pop()
        candidates = [
            card for rows in loaded for card in rows[index]["candidates"]
        ]
        candidates.sort(
            key=lambda card: (
                card["step"],
                list(AgentModule).index(AgentModule(card["module"])),
                list(ErrorType).index(ErrorType(card["error_type"])),
            )
        )
        if not candidates:
            _fail("empty_merged_candidate_set", f"case {index} has no specialist finding")
        merged.append(
            {
                "trajectory_id": trajectory_id,
                "trajectory_sha256": trajectory_sha256,
                "status": status,
                "candidates": candidates,
            }
        )
    output = Path(output_path).expanduser().resolve()
    _assert_safe_path(output, role="merged candidate output", is_output=True)
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(f"{output.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(merged, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    temporary.replace(output)
    audit = validate_sol_gaia_candidate_proposals(
        prediction_manifest_path, cohort_manifest_path, output
    )
    return _write_audit(
        audit_path,
        {
            **audit,
            "agent_judge_version": AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_VERSION,
            "stage": "specialist-merge",
            "source_specialist_sha256": source_hashes,
            "merge_is_mechanical_and_unranked": True,
        },
    )


def _validator_command(function: str, *arguments: str) -> str:
    code = (
        "import json; from agentdebug.diagnostics.agent_judge_sol_gaia_specialist_critic "
        f"import {function} as run; print(json.dumps(run("
        + ", ".join(repr(value) for value in arguments)
        + "), ensure_ascii=False, indent=2))"
    )
    return "PYTHONPATH=. python3 -c " + shlex.quote(code)


def build_sol_gaia_specialist_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposals_path: str | Path,
    module: AgentModule | str,
) -> str:
    selected = AgentModule(module)
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    output = Path(proposals_path).expanduser().resolve()
    audit = output.parent / "specialist-audit.json"
    for role, path, is_output in (
        ("prediction manifest", prediction, False),
        ("cohort manifest", cohort, False),
        ("specialist output", output, True),
        ("specialist audit", audit, True),
    ):
        _assert_safe_path(path, role=role, is_output=is_output)
    module_taxonomy = "\n".join(
        f"- {error_type.value}: {definition}"
        for error_type, definition in TAXONOMY[selected].items()
    )
    schema = {
        "trajectory_id": "exact opaque join token",
        "trajectory_sha256": "exact manifest SHA-256",
        "status": "success",
        "candidates": [
            {
                "step": "positive integer",
                "module": selected.value,
                "error_type": "one assigned-module type",
                "evidence_quote": "exact assigned-owner source substring",
                "local_defect": "locally demonstrated NEW defect",
                "causal_relevance": "prospective propagation and recovery facts",
                "recovery": "none | partial | complete",
            }
        ],
    }
    command = _validator_command(
        "validate_and_write_sol_gaia_specialist_audit",
        str(prediction),
        str(cohort),
        str(output),
        str(audit),
        selected.value,
    )
    return f"""\
Run {AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_VERSION}: isolated {selected.value.upper()} specialist.

Model={AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_MODEL}; reasoning_effort={AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_REASONING_EFFORT}. Network, API, gold, labels, scores, prior predictions, and other specialist outputs are forbidden.
Read only {prediction}, {cohort}, this protocol source, v2.4 evidence rules, and taxonomy.py. Treat trajectory_id as an opaque join token, never semantic evidence.

Silently inspect every printed step, but judge ONLY `{selected.value}`. Return
zero to six sparse, unranked local NEW defects for this module. Do not choose a
global root. A finding must be directly established by the assigned module's
own source using information available at that step. Ordinary uncertainty,
reasonable exploration, an unsuccessful first probe, accurate failure report,
and downstream repetition alone are not findings.

Memory requires a concrete dropped, unretrieved, or fabricated historical
fact that a decision uses. Reflection requires an actual direct-result,
progress, or causal interpretation error. Planning requires its own defective
strategy, prerequisite, target, or constraint handling. Action requires a
concrete deviation, unavailable/malformed call, bad parameter, or unsupported
final emission introduced there. System requires provenance-backed final
execution_facts defeating an otherwise reasonable attempt.

Record causal relevance and later recovery, but later evidence cannot create a
hindsight local defect. Evidence must satisfy v2.4 literal owner-source rules.
Sort mechanically by step then error_type; order is not priority.

ASSIGNED TAXONOMY: {selected.value}
{module_taxonomy}

Write one JSON array to {output} matching exactly:
{json.dumps(schema, ensure_ascii=False, indent=2)}
`candidates` may be empty. No other module, winner, rank, confidence, gold
field, or extra key is allowed.

Then run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Fix only the current artifact until validation exits zero and writes {audit}.
"""


def validate_sol_gaia_specialist_root_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_sol_gaia_two_stage_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_VERSION,
        "model": AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_MODEL,
        "reasoning_effort": AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_REASONING_EFFORT,
    }


def validate_and_write_sol_gaia_specialist_root_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        audit_path,
        validate_sol_gaia_specialist_root_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
    )


def build_sol_gaia_specialist_arbiter_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    task = build_sol_gaia_two_stage_task(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return (
        task.replace(
            AGENT_JUDGE_SOL_GAIA_TWO_STAGE_VERSION,
            AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_VERSION,
        )
        .replace(
            "agent_judge_sol_gaia_two_stage",
            "agent_judge_sol_gaia_specialist_critic",
        )
        .replace(
            "validate_and_write_sol_gaia_two_stage_audit",
            "validate_and_write_sol_gaia_specialist_root_audit",
        )
        .replace("stage 2: FRESH ROOT ARBITER", "stage 2: FRESH INITIAL ROOT ARBITER")
    )


def validate_sol_gaia_specialist_critic_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    final_path = Path(predictions_path).expanduser().resolve()
    initial_path = final_path.parent / INITIAL_ROOT_FILENAME
    initial = validate_sol_gaia_specialist_root_predictions(
        prediction_manifest_path, cohort_manifest_path, initial_path
    )
    final = validate_sol_gaia_specialist_root_predictions(
        prediction_manifest_path, cohort_manifest_path, final_path
    )
    return {
        **final,
        "stage": "adversarial-critic",
        "initial_root_sha256": _file_sha256(initial_path),
        "initial_root_valid": True,
        "critic_final_exact_frozen_candidate": True,
        "candidate_count": initial["candidate_count"],
    }


def validate_and_write_sol_gaia_specialist_critic_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        audit_path,
        validate_sol_gaia_specialist_critic_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
    )


def build_sol_gaia_specialist_critic_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    output = Path(predictions_path).expanduser().resolve()
    candidates = output.parent / CANDIDATE_PROPOSALS_FILENAME
    initial = output.parent / INITIAL_ROOT_FILENAME
    audit = output.parent / "prediction-audit.json"
    for role, path, is_output in (
        ("prediction manifest", prediction, False),
        ("cohort manifest", cohort, False),
        ("candidate proposals", candidates, False),
        ("initial root", initial, False),
        ("critic output", output, True),
        ("critic audit", audit, True),
    ):
        _assert_safe_path(path, role=role, is_output=is_output)
    command = _validator_command(
        "validate_and_write_sol_gaia_specialist_critic_audit",
        str(prediction), str(cohort), str(output), str(audit)
    )
    schema = {
        "trajectory_id": "exact opaque join token",
        "trajectory_sha256": "exact manifest SHA-256",
        "status": "success",
        "predicted_step": "selected proposal step",
        "predicted_module": "selected proposal module",
        "predicted_error_type": "selected proposal type",
        "evidence_quote": "selected proposal evidence copied exactly",
        "root_cause": "critic's concise causal explanation",
        "causal_summary": "counterfactual, cascade, recovery conclusion",
        "rejected_adjacent_owner": "strongest alternative and rejection",
    }
    return f"""\
Run {AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_VERSION}: FRESH ADVERSARIAL FINAL CRITIC.

Model={AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_MODEL}; reasoning_effort={AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_REASONING_EFFORT}. Network/API/gold/scoring access forbidden. Read only {prediction}, {cohort}, {candidates}, {initial}, this protocol, v2.4 evidence rules, and taxonomy.py. trajectory_id is an opaque join token.

Independently reconstruct the complete JudgeView. Treat the initial root and
all module-specialist cards as fallible hypotheses, never votes or evidence.
Silently build the strongest challenger at a materially different step (or a
different owner for a one-step trace) before deciding whether to affirm.

Apply in order:
1. Falsify local taxonomy and ownership using contemporaneous evidence.
2. Reject an upstream Memory candidate unless it names a concrete false/missing
   historical fact and a later decision actually depends on that exact defect.
   General incompleteness or a nicer summary is not a root.
3. Reject a later parameter, repeated call, false-progress statement, or final
   answer when it merely executes or exposes an earlier unrecovered candidate.
   Conversely, reject an early broad query or first plausible probe that did
   not yet commit the trajectory to failure.
4. Compare recovery and smallest single correction. Full recovery requires
   reacquiring AND using the useful state. Choose the earliest decisive
   divergence inside the winning continuous unrecovered chain, not the earliest
   text and not the most vivid terminal symptom.
5. At the same step, preserve the new-defect owner: result interpretation is
   Reflection; strategy is Planning; adequate plan followed by deviation or
   bad concrete parameter is Action; provenance-backed external failure of a
   reasonable attempt is System.

Select exactly one frozen candidate tuple. You may affirm or replace the
initial root, but may not invent or edit step/module/type/evidence. Write one
ten-field JSON array to {output} matching:
{json.dumps(schema, ensure_ascii=False, indent=2)}
No extra fields. Then run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Fix only the current output until validation exits zero and writes {audit}.
"""


__all__ = [
    "AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_MODEL",
    "AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_REASONING_EFFORT",
    "AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_VERSION",
    "INITIAL_ROOT_FILENAME",
    "SPECIALIST_MODULES",
    "build_sol_gaia_specialist_arbiter_task",
    "build_sol_gaia_specialist_critic_task",
    "build_sol_gaia_specialist_task",
    "merge_sol_gaia_specialist_proposals",
    "specialist_filename",
    "validate_and_write_sol_gaia_specialist_audit",
    "validate_and_write_sol_gaia_specialist_critic_audit",
    "validate_and_write_sol_gaia_specialist_root_audit",
    "validate_sol_gaia_specialist_critic_predictions",
    "validate_sol_gaia_specialist_proposals",
    "validate_sol_gaia_specialist_root_predictions",
]

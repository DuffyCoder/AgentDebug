"""Luna GAIA v3.5.1: v3.5 with a recoverable step-only ledger."""

from __future__ import annotations

import copy
import json
import os
from pathlib import Path
from typing import Any, Sequence

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
)
from .agent_judge_luna_gaia_v3 import (
    STEP_FREEZE_FIELDS,
    STEP_FREEZE_FILENAME,
    _file_sha256,
)
from .agent_judge_luna_gaia_v3_1 import (
    validate_agent_judge_luna_gaia_v3_1_predictions,
)
from .agent_judge_luna_gaia_v3_4 import (
    STEP_CANDIDATE_LEDGER_FIELDS,
    STEP_CANDIDATE_LEDGER_FILENAME,
    STEP_CANDIDATE_LANES,
    STEP_CANDIDATE_ROW_FIELDS,
    STEP_CANDIDATE_STATUSES,
    _validate_step_candidate_ledger_document,
)
from .agent_judge_luna_gaia_v3_5 import (
    AGENT_JUDGE_LUNA_GAIA_V3_5_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_LUNA_GAIA_V3_5_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_5_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_5_VERSION,
    build_agent_judge_luna_gaia_v3_5_task,
)


AGENT_JUDGE_LUNA_GAIA_V3_5_1_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.5.1"
)
AGENT_JUDGE_LUNA_GAIA_V3_5_1_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_5_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_5_1_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_5_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_5_1_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_5_AUDIT_SCHEMA_VERSION
)


_OLD_LEDGER_EVIDENCE_RULE = """\
Do not use a veto status as a new semantic exception.  All rows before the
selected step must have no `candidate` status and `surviving_lane: null`.  The
last row must contain at least one `candidate`; `surviving_lane` must be the
first candidate in the exact order lane_a, lane_b, system, lane_c.  Stop there:
do not add later rows.  `evidence_quote` is null on earlier rows and is one
literal substring from the selected step packet on the last row.
"""

_STEP_ONLY_LEDGER_EVIDENCE_RULE = """\
Do not use a veto status as a new semantic exception.  All rows before the
selected step must have no `candidate` status and `surviving_lane: null`.  The
last row must contain at least one `candidate`; `surviving_lane` must be the
first candidate in the exact order lane_a, lane_b, system, lane_c.  Stop there:
do not add later rows.  `evidence_quote` must be null on every row.  This is a
step-only ledger: select literal owner evidence only after the step checkpoint,
in the final prediction phase already required below.
"""

_OLD_LEDGER_CONTRACT_SELECTED_QUOTE = (
    '      "evidence_quote": "literal substring from selected step packet",'
)
_STEP_ONLY_LEDGER_CONTRACT_SELECTED_QUOTE = '      "evidence_quote": null,'

_OLD_LEDGER_CONTRACT_SUMMARY = """\
The example illustrates shape only; derive row count, statuses, lane, quote,
and selected step solely from the one JudgeView.  Rows must be consecutive,
must stop at selected_step, and must obey the status and lane-order rules
above.  Write this file once and never edit it.  Then derive and write the
two-field step checkpoint from its last row before considering owner/type.
"""

_STEP_ONLY_LEDGER_CONTRACT_SUMMARY = """\
The example illustrates shape only; derive row count, statuses, lane, and
selected step solely from the one JudgeView.  Keep every ledger evidence_quote
null.  Rows must be consecutive, must stop at selected_step, and must obey the
status and lane-order rules above.  Write this file once and never edit it.
Then derive and write the two-field step checkpoint from its last row before
considering owner/type/evidence.
"""

_IDENTITY_COPY_RULE = """\
IDENTITY COPY RULE

The prediction field `trajectory_sha256` is only the value of
`entries[0].trajectory_sha256` inside the prediction manifest.  The separately
listed prediction-manifest file SHA-256 is an input-integrity digest, is not a
trajectory identity, and must never be copied into `trajectory_sha256`.  Copy
the entry value exactly; do not infer it or hash any ID or file.

"""


def _replace_once(task: str, old: str, new: str, *, label: str) -> str:
    if task.count(old) != 1:
        raise RuntimeError(f"Luna GAIA v3.5 {label} changed unexpectedly")
    return task.replace(old, new, 1)


def build_agent_judge_luna_gaia_v3_5_1_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build v3.5 with only the audited execution-layer repair."""

    task = build_agent_judge_luna_gaia_v3_5_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    task = task.replace(
        AGENT_JUDGE_LUNA_GAIA_V3_5_VERSION,
        AGENT_JUDGE_LUNA_GAIA_V3_5_1_VERSION,
    )
    task = task.replace(
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_5.py",
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_5_1.py",
    )
    task = task.replace(
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_5 import "
        "validate_and_write_agent_judge_luna_gaia_v3_5_audit as run",
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_5_1 import "
        "validate_and_write_agent_judge_luna_gaia_v3_5_1_audit as run",
    )
    task = _replace_once(
        task,
        _OLD_LEDGER_EVIDENCE_RULE,
        _STEP_ONLY_LEDGER_EVIDENCE_RULE,
        label="ledger evidence rule",
    )
    task = _replace_once(
        task,
        _OLD_LEDGER_CONTRACT_SELECTED_QUOTE,
        _STEP_ONLY_LEDGER_CONTRACT_SELECTED_QUOTE,
        label="ledger selected quote",
    )
    task = _replace_once(
        task,
        _OLD_LEDGER_CONTRACT_SUMMARY,
        _STEP_ONLY_LEDGER_CONTRACT_SUMMARY,
        label="ledger contract summary",
    )
    task = _replace_once(
        task,
        "STRICT TEN-FIELD CONTRACT\n",
        _IDENTITY_COPY_RULE + "STRICT TEN-FIELD CONTRACT\n",
        label="identity boundary",
    )

    validation_prefix = (
        "PYTHONPATH=. python3 -c 'import json; from "
        "agentdebug.diagnostics.agent_judge_luna_gaia_v3_5_1 import "
        "validate_and_write_agent_judge_luna_gaia_v3_5_1_audit as run; "
        "print(json.dumps(run("
    )
    validation_lines = [
        index
        for index, line in enumerate(task.splitlines())
        if line.startswith(validation_prefix)
    ]
    if len(validation_lines) != 1:
        raise RuntimeError("Luna GAIA v3.5 validation command changed unexpectedly")

    manifest = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    prediction = Path(predictions_path).expanduser().resolve()
    audit = prediction.parent / "prediction-audit.json"
    shell_quote = "'\"'\"'"
    arguments = ", ".join(
        f"{shell_quote}{path}{shell_quote}"
        for path in (manifest, cohort, prediction, audit)
    )
    compact_command = (
        "PYTHONPATH=. python3 -c 'from "
        "agentdebug.diagnostics.agent_judge_luna_gaia_v3_5_1 import "
        "run_agent_judge_luna_gaia_v3_5_1_compact_validation as run; "
        f"raise SystemExit(run({arguments}))'"
    )
    lines = task.splitlines()
    lines[validation_lines[0]] = compact_command
    task = "\n".join(lines) + ("\n" if task.endswith("\n") else "")
    task = _replace_once(
        task,
        "On failure inspect only the validator error and allowlisted current "
        "artifacts,\ncorrect the prediction, and rerun.",
        "On failure inspect only the compact validator code/message and "
        "allowlisted\ncurrent artifacts.  Correct only what that code identifies; "
        "never guess a\ndifferent hash or edit the immutable ledger/checkpoint.  "
        "Then rerun.",
        label="validation failure instruction",
    )
    return task


def _validate_step_only_ledger_document(
    value: Any,
    *,
    trajectory_id: str,
    step_count: int,
    predicted_step: int,
    selected_packet_sources: Sequence[str],
) -> None:
    """Validate v3.5.1 while deferring literal evidence until final output."""

    if not isinstance(value, dict):
        raise AgentJudgeValidationError(
            "invalid_step_candidate_ledger_schema",
            "step ledger must be an object",
        )
    rows = value.get("rows")
    if not isinstance(rows, list) or any(
        not isinstance(row, dict) or row.get("evidence_quote") is not None
        for row in rows
    ):
        raise AgentJudgeValidationError(
            "non_null_step_candidate_evidence",
            "step-only ledger evidence_quote must remain null on every row",
        )

    nonempty_source = next(
        (source for source in selected_packet_sources if source),
        None,
    )
    if nonempty_source is None:
        raise AgentJudgeValidationError(
            "missing_selected_step_packet_text",
            "selected step packet has no text for downstream evidence audit",
        )
    compatibility_value = copy.deepcopy(value)
    compatibility_value["rows"][-1]["evidence_quote"] = nonempty_source[:1]
    _validate_step_candidate_ledger_document(
        compatibility_value,
        trajectory_id=trajectory_id,
        step_count=step_count,
        predicted_step=predicted_step,
        selected_packet_sources=selected_packet_sources,
    )


def _validate_step_only_ledger(
    prediction_manifest_path: str | Path,
    predictions_path: Path,
) -> dict[str, Any]:
    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    _assert_safe_path(manifest_path, role="prediction manifest")
    from agentdebug.benchmark.prediction_manifest import (  # noqa: PLC0415
        PredictionManifestError,
        load_prediction_manifest,
    )

    try:
        _, cases = load_prediction_manifest(manifest_path)
    except PredictionManifestError as error:
        raise AgentJudgeValidationError(
            "invalid_prediction_manifest",
            str(error),
        ) from error
    if len(cases) != 1:
        raise AgentJudgeValidationError(
            "invalid_step_candidate_ledger_scope",
            "step ledger validation requires exactly one manifest case",
        )

    try:
        predictions = json.loads(predictions_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise AgentJudgeValidationError(
            "invalid_predictions_json",
            "predictions are unavailable for step ledger validation",
        ) from error
    if not isinstance(predictions, list) or len(predictions) != 1:
        raise AgentJudgeValidationError(
            "invalid_step_candidate_ledger_scope",
            "step ledger validation requires exactly one prediction",
        )

    ledger_path = predictions_path.parent / STEP_CANDIDATE_LEDGER_FILENAME
    _assert_safe_path(ledger_path, role="step candidate ledger")
    try:
        ledger = json.loads(ledger_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise AgentJudgeValidationError(
            "missing_or_invalid_step_candidate_ledger",
            "single-case prediction requires a valid step-candidates.json",
        ) from error

    case = cases[0]
    prediction = predictions[0]
    selected_step = prediction.get("predicted_step")
    if isinstance(selected_step, bool) or not isinstance(selected_step, int):
        raise AgentJudgeValidationError(
            "step_candidate_ledger_step_mismatch",
            "prediction step is unavailable for ledger validation",
        )
    step = case.judge_view.steps[selected_step - 1]
    packet_sources = [step.assistant_raw_output]
    packet_sources.extend(item.text for item in step.adjacent_feedback)
    _validate_step_only_ledger_document(
        ledger,
        trajectory_id=case.trajectory_id,
        step_count=len(case.judge_view.steps),
        predicted_step=selected_step,
        selected_packet_sources=packet_sources,
    )
    return {
        "required": True,
        "valid": True,
        "path": str(ledger_path.resolve()),
        "sha256": _file_sha256(ledger_path),
        "row_count": len(ledger["rows"]),
        "selected_step": ledger["selected_step"],
        "surviving_lane": ledger["rows"][-1]["surviving_lane"],
        "evidence_deferred_to_final_prediction": True,
    }


def validate_agent_judge_luna_gaia_v3_5_1_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    prediction_path = Path(predictions_path).expanduser().resolve()
    audit = validate_agent_judge_luna_gaia_v3_1_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction_path,
    )
    ledger = (
        _validate_step_only_ledger(prediction_manifest_path, prediction_path)
        if audit["case_count"] == 1
        else {
            "required": False,
            "valid": None,
            "reason": "merged full-cohort validation follows validated shards",
        }
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_5_1_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_5_1_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_5_1_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_5_1_REASONING_EFFORT,
        "selection_policy": (
            "lane_ordered_chronology_validated_step_only_candidate_ledger_"
            "limited_recovery_veto_external_exception_packet_fence_"
            "positive_immediate_subgoal_capability_gate"
        ),
        "step_candidate_ledger": ledger,
        "positive_capability_admission_gate": (
            "any_necessary_evidence_for_current_immediate_subgoal"
        ),
        "step_ledger_evidence_policy": "deferred_to_final_prediction",
    }


def validate_and_write_agent_judge_luna_gaia_v3_5_1_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_5_1_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


def run_agent_judge_luna_gaia_v3_5_1_compact_validation(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> int:
    """Run local validation with a terminal error that cannot be truncated."""

    try:
        audit = validate_and_write_agent_judge_luna_gaia_v3_5_1_audit(
            prediction_manifest_path,
            cohort_manifest_path,
            predictions_path,
            audit_path,
        )
    except AgentJudgeValidationError as error:
        print(
            json.dumps(
                {
                    "valid": False,
                    "error_code": error.code,
                    "error_message": str(error),
                },
                ensure_ascii=False,
            )
        )
        return 1
    except Exception as error:  # pragma: no cover - last-resort observability
        print(
            json.dumps(
                {
                    "valid": False,
                    "error_code": "unexpected_validation_error",
                    "error_message": f"{type(error).__name__}: {error}",
                },
                ensure_ascii=False,
            )
        )
        return 2
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    return 0


__all__ = [
    "AGENT_JUDGE_LUNA_GAIA_V3_5_1_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_GAIA_V3_5_1_MODEL",
    "AGENT_JUDGE_LUNA_GAIA_V3_5_1_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_GAIA_V3_5_1_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "STEP_CANDIDATE_LEDGER_FIELDS",
    "STEP_CANDIDATE_LEDGER_FILENAME",
    "STEP_CANDIDATE_LANES",
    "STEP_CANDIDATE_ROW_FIELDS",
    "STEP_CANDIDATE_STATUSES",
    "STEP_FREEZE_FIELDS",
    "STEP_FREEZE_FILENAME",
    "build_agent_judge_luna_gaia_v3_5_1_task",
    "run_agent_judge_luna_gaia_v3_5_1_compact_validation",
    "validate_agent_judge_luna_gaia_v3_5_1_predictions",
    "validate_and_write_agent_judge_luna_gaia_v3_5_1_audit",
]

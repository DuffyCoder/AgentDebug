"""Luna GAIA v3.22: isolated bidirectional Memory/Reflection challenger."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger as bidirectional
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from .agent_judge_luna_gaia_v3_4 import STEP_CANDIDATE_LEDGER_FILENAME


AGENT_JUDGE_LUNA_GAIA_V3_22_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.22-isolated-bidirectional-state-challenger"
)
AGENT_JUDGE_LUNA_GAIA_V3_22_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_22_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_22_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases used by the shared paper-50 runner.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_22_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_22_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_22_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_22_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = parent.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = parent.CHALLENGERS_FILENAME
ARBITER_FILENAME = parent.ARBITER_FILENAME
ARBITERS_FILENAME = parent.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = parent.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = parent.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
CHALLENGER_FIELDS = parent.CHALLENGER_FIELDS
ARBITER_FIELDS = parent.ARBITER_FIELDS


_STATE_SUMMARY_PREFIX = re.compile(
    r"^state_claim_kind=(none|necessary_fact|entity_relation|outcome_claim); "
    r"state_relation=(not_applicable|omitted|unsupported|contradicted); "
    r"state_direction=(none|earlier|later); "
)
_CHALLENGE_PAIRS = {
    "necessary_fact": "omitted",
    "entity_relation": "unsupported",
    "outcome_claim": "contradicted",
}

_STATE_CHALLENGER_RULES = """\
ISOLATED BIDIRECTIONAL STATE-ONLY SINGLE-CHALLENGER RULE

The frozen packet-state prediction is the incumbent anchor. Do not change,
repair, or re-run it. Inspect the complete chronology independently of the
anchor ledger's candidate set, but emit at most ONE proposal and only for a
literal Memory/Reflection state boundary.

Begin search_summary exactly:

`state_claim_kind=<none|necessary_fact|entity_relation|outcome_claim>; state_relation=<not_applicable|omitted|unsupported|contradicted>; state_direction=<none|earlier|later>; `

Use `none/not_applicable/none` when no proposal passes. A challenge must use
exactly one of these closed pairs:

1. `necessary_fact/omitted`: adjacent feedback contains a concrete title,
   value, constraint, source fact, provenance link, or discriminating result
   necessary for the unresolved subgoal or next decision, while the Step's
   Memory/Reflection loses or materially distorts it.
2. `entity_relation/unsupported`: Memory/Reflection asserts a concrete task-
   answer entity/value/credential/relation unsupported by visible evidence and
   the later plan consumes that exact assertion.
3. `outcome_claim/contradicted`: Memory/Reflection claims success, failure,
   progress, or a constraint that the literal adjacent result contradicts.

Every proposal must be owned by Memory or Reflection, quote literal evidence,
feed the current/next plan, and have a path effect: repairing that exact state
can change the later path. Harmless compression, details still available to the
next decision, wording polish, non-consumed speculation, and locally false but
causally irrelevant text are not proposals.

An explicitly provisional explanation of why retrieval was irrelevant or
failed is a query hypothesis, not an unsupported answer relation. Do not
challenge it merely because it is unproved. It is excluded unless literal
feedback contradicts an outcome claim separately.

SEARCH ORDER AND ANCHOR VETO

- First decide whether the anchor itself is a direct critical root. If so,
  no_challenge even when another state defect exists.
- For a strictly earlier proposal, scan Step 1 through anchor-1 and stop at the
  earliest qualifying state boundary. Classify the anchor downstream_symptom
  and show why anchor-only repair leaves that earlier defect intact.
- Only if no earlier boundary passes and literal evidence classifies the anchor
  as a reasonable probe or noncritical predecessor, scan anchor+1 onward and
  stop at the earliest independently failure-causing state boundary.
- direct_timeline_comparison must compare the anchor, every intervening
  plausible state boundary, and the proposal. Under uncertainty use
  no_challenge.

The proposal is not a general candidate search. Planning, Action, System,
mechanical-parameter, acquisition-capability, repeated-strategy, source, and
terminal-answer errors cannot be proposed by this challenger unless the
proposed owner is independently a qualifying Memory/Reflection state claim.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_22_VERSION,
        )
        .replace(
            bidirectional.AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_22_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_22_isolated_bidirectional_state_challenger",
        )
        .replace(
            "agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger",
            "agent_judge_luna_gaia_v3_22_isolated_bidirectional_state_challenger",
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py",
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_22_isolated_bidirectional_state_challenger.py",
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger.py",
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_22_isolated_bidirectional_state_challenger.py",
        )
    )


def build_anchor_task(*paths: str | Path) -> str:
    """Preserve v3.20 anchor semantics; rewrite only versioned identity/path."""

    return _rewrite_identity(parent.build_anchor_task(*paths))


def build_challenger_task(*paths: str | Path) -> str:
    task = bidirectional.build_challenger_task(*paths)
    task = task.replace(bidirectional._BOUNDED_BIDIRECTIONAL_RULES, _STATE_CHALLENGER_RULES)
    task = task.replace(
        '"search_summary": "which direction was searched and why one proposal exists or none qualifies"',
        '"search_summary": "state_claim_kind=...; state_relation=...; state_direction=...; literal scan summary"',
    )
    return _rewrite_identity(task)


def _validate_state_challengers(path: str | Path) -> dict[str, Any]:
    challenger_path, raw = shared._load_artifact(path, role="state challenger")
    records = raw if isinstance(raw, list) else [raw]
    if not records or any(not isinstance(record, dict) for record in records):
        shared._fail("invalid_state_challenger_records", "records unavailable")

    pair_counts: Counter[str] = Counter()
    direction_counts: Counter[str] = Counter()
    challenge_count = 0
    for index, record in enumerate(records):
        location = f"state_challenger[{index}]"
        match = _STATE_SUMMARY_PREFIX.match(str(record.get("search_summary") or ""))
        if match is None:
            shared._fail("missing_state_challenger_prefix", location)
        kind, relation, direction = match.groups()
        status = record.get("challenge_status")
        proposal = record.get("proposed_prediction")
        if status == "no_challenge":
            if (kind, relation, direction) != ("none", "not_applicable", "none"):
                shared._fail("invalid_no_state_challenge_pair", location)
        elif status == "challenge":
            if kind not in _CHALLENGE_PAIRS or relation != _CHALLENGE_PAIRS[kind]:
                shared._fail("invalid_state_challenge_pair", location)
            if not isinstance(proposal, dict) or proposal.get("predicted_module") not in {
                "memory",
                "reflection",
            }:
                shared._fail("state_challenge_requires_state_owner", location)
            anchor_step = record.get("anchor_step")
            proposal_step = proposal.get("predicted_step")
            expected_direction = (
                "earlier" if proposal_step < anchor_step else "later"
            )
            if direction != expected_direction:
                shared._fail("state_challenge_direction_mismatch", location)
            challenge_count += 1
        else:
            shared._fail("invalid_state_challenge_status", location)
        pair_counts[f"{kind}:{relation}"] += 1
        direction_counts[direction] += 1
    return {
        "required": True,
        "valid": True,
        "path": str(challenger_path),
        "record_count": len(records),
        "challenge_count": challenge_count,
        "claim_relation_counts": dict(sorted(pair_counts.items())),
        "direction_counts": dict(sorted(direction_counts.items())),
        "state_owner_only": True,
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    audit = parent.validate_anchor_predictions(*paths)
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_22_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_22_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_22_REASONING_EFFORT,
        "anchor_semantics": "v3.20_packet_state_closure",
    }


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    audit = bidirectional.validate_challenger(*paths)
    state = _validate_state_challengers(paths[5])
    return {
        **audit,
        "schema_version": "agentdebug.isolated-state-challenger-audit.v1",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_22_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_22_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_22_REASONING_EFFORT,
        "isolated_state_challenger": state,
    }


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    audit = bidirectional.validate_arbiter(*paths)
    state = _validate_state_challengers(paths[5])
    return {
        **audit,
        "schema_version": "agentdebug.isolated-state-arbiter-audit.v1",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_22_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_22_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_22_REASONING_EFFORT,
        "isolated_state_challenger": state,
    }


def build_arbiter_task(*paths: str | Path) -> str:
    validate_challenger(*paths[:6])
    task = bidirectional.build_arbiter_task(*paths)
    task = task.replace(bidirectional._BOUNDED_BIDIRECTIONAL_RULES, _STATE_CHALLENGER_RULES)
    return _rewrite_identity(task)


def build_agent_judge_luna_gaia_v3_22_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / STEP_CANDIDATE_LEDGER_FILENAME,
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def validate_agent_judge_luna_gaia_v3_22_predictions(*paths: str | Path) -> dict[str, Any]:
    audit = bidirectional.validate_agent_judge_luna_gaia_v3_16_predictions(*paths)
    predictions = Path(paths[2]).expanduser().resolve()
    packet_state = parent._validate_packet_state_ledgers(
        predictions.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME
    )
    state_challenger = _validate_state_challengers(
        predictions.parent / CHALLENGERS_FILENAME
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_22_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_22_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_22_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_22_REASONING_EFFORT,
        "selection_policy": (
            "v3_20_packet_state_anchor_one_isolated_bidirectional_state_"
            "challenger_default_keep_exact_copy_arbiter"
        ),
        "anchor_semantics_unchanged_from_v3_20": True,
        "packet_state_closure": packet_state,
        "isolated_state_challenger": state_challenger,
    }


def _write_audit(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_22_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        validate_agent_judge_luna_gaia_v3_22_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


# Compatibility names used by the shared paper-50 runner.
build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_22_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_22_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_22_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_22_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "AGENT_JUDGE_LUNA_GAIA_V3_22_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_GAIA_V3_22_MODEL",
    "AGENT_JUDGE_LUNA_GAIA_V3_22_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_GAIA_V3_22_VERSION",
    "ANCHOR_CHECKPOINT_AGGREGATE_FILENAME",
    "ANCHOR_LEDGER_AGGREGATE_FILENAME",
    "ANCHOR_PREDICTIONS_FILENAME",
    "ARBITER_FILENAME",
    "ARBITERS_FILENAME",
    "CHALLENGER_FILENAME",
    "CHALLENGERS_FILENAME",
    "build_agent_judge_luna_gaia_v3_22_task",
    "build_anchor_task",
    "build_arbiter_task",
    "build_challenger_task",
    "validate_agent_judge_luna_gaia_v3_22_predictions",
    "validate_anchor_predictions",
    "validate_and_write_agent_judge_luna_gaia_v3_22_audit",
    "validate_and_write_anchor_audit",
    "validate_and_write_arbiter_audit",
    "validate_and_write_challenger_audit",
    "validate_arbiter",
    "validate_challenger",
]

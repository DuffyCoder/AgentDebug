"""Luna GAIA v3.11: v3.4 plus same-step plan/Action target binding."""

from __future__ import annotations

import argparse
import json
import os
import shlex
from pathlib import Path
from typing import Any, Sequence

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
)
from .agent_judge_luna_gaia_v3 import STEP_FREEZE_FIELDS, STEP_FREEZE_FILENAME
from .agent_judge_luna_gaia_v3_4 import (
    AGENT_JUDGE_LUNA_GAIA_V3_4_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_LUNA_GAIA_V3_4_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_4_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_4_VERSION,
    STEP_CANDIDATE_LEDGER_FIELDS,
    STEP_CANDIDATE_LEDGER_FILENAME,
    STEP_CANDIDATE_LANES,
    STEP_CANDIDATE_ROW_FIELDS,
    STEP_CANDIDATE_STATUSES,
    build_agent_judge_luna_gaia_v3_4_task,
    validate_agent_judge_luna_gaia_v3_4_predictions,
)


AGENT_JUDGE_LUNA_GAIA_V3_11_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.11"
)
AGENT_JUDGE_LUNA_GAIA_V3_11_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_4_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_11_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_4_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_11_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_4_AUDIT_SCHEMA_VERSION
)


_SAME_STEP_TARGET_BINDING_RULE = """\
SAME-STEP ANNOUNCED-TARGET / ACTION-TARGET BINDING

Apply this rule only to Lane B's same-step Planning/Action alignment check. It
changes no capability judgment, fact audit, source or output constraint,
prerequisite, Action argument validation, recovery veto, System packet fence,
Lane-C strategy epoch, owner, or taxonomy rule.

When the current Planning text explicitly and unambiguously names the next
information target, compare that target with the direct object selected by the
same-step Action. Admit a Planning candidate when all are literal:

1. the plan names a concrete next information target;
2. the Action instead retrieves or queries a different artifact or entity;
3. that selected object was already identified for its current role; and
4. neither the plan nor trace states that inspecting the selected object's
   contents is needed to obtain the named target.

A new tool, host, URL, or syntactically valid Action does not by itself make
the targets aligned. Conversely, keep Lane B clear under this rule when the
plan explicitly assigns inspection, confirmation, or discovery of the named
target to the selected object, or when the target/object relation is
ambiguous. Do not invent an implicit target to activate this rule.

Record the literal announced target, Action object, and the statement (or
absence) linking that object to the target in `decision_basis`.

"""


def _replace_validation_command_with_cli(
    task: str,
    *,
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    lines = task.splitlines()
    indexes = [
        index
        for index, line in enumerate(lines)
        if line.startswith("PYTHONPATH=. python3 -c ")
        and "validate_and_write_agent_judge_luna_gaia_v3_11_audit" in line
    ]
    if len(indexes) != 1:
        raise RuntimeError("Luna GAIA v3.4 validation command changed unexpectedly")
    prediction = Path(predictions_path).expanduser().resolve()
    paths = (
        Path(prediction_manifest_path).expanduser().resolve(),
        Path(cohort_manifest_path).expanduser().resolve(),
        prediction,
        prediction.parent / "prediction-audit.json",
    )
    arguments = " ".join(shlex.quote(str(path)) for path in paths)
    lines[indexes[0]] = (
        "PYTHONPATH=. python3 -m "
        "agentdebug.diagnostics.agent_judge_luna_gaia_v3_11 "
        f"--compact-validate {arguments}"
    )
    return "\n".join(lines) + ("\n" if task.endswith("\n") else "")


def build_agent_judge_luna_gaia_v3_11_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build v3.4 with target binding and a shell-safe validator CLI."""

    task = build_agent_judge_luna_gaia_v3_4_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    task = task.replace(
        AGENT_JUDGE_LUNA_GAIA_V3_4_VERSION,
        AGENT_JUDGE_LUNA_GAIA_V3_11_VERSION,
    )
    task = task.replace(
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_4.py",
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_11.py",
    )
    task = task.replace(
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_4 import "
        "validate_and_write_agent_judge_luna_gaia_v3_4_audit as run",
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_11 import "
        "validate_and_write_agent_judge_luna_gaia_v3_11_audit as run",
    )
    lane_c = "LANE C — STRATEGY EPOCHS AND TERMINAL ABANDONMENT\n"
    if task.count(lane_c) != 1:
        raise RuntimeError("Luna GAIA v3.4 lane-C boundary changed unexpectedly")
    task = task.replace(lane_c, _SAME_STEP_TARGET_BINDING_RULE + lane_c, 1)
    task = _replace_validation_command_with_cli(
        task,
        prediction_manifest_path=prediction_manifest_path,
        cohort_manifest_path=cohort_manifest_path,
        predictions_path=predictions_path,
    )
    old_failure = (
        "On failure inspect only the validator error and allowlisted current "
        "artifacts,\ncorrect the prediction, and rerun."
    )
    new_failure = (
        "On failure inspect only the compact validator code/message and "
        "allowlisted\ncurrent artifacts, correct only that reported defect, "
        "and rerun."
    )
    if task.count(old_failure) != 1:
        raise RuntimeError("Luna GAIA v3.4 validator failure text changed")
    return task.replace(old_failure, new_failure, 1)


def validate_agent_judge_luna_gaia_v3_11_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_4_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_11_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_11_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_11_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_11_REASONING_EFFORT,
        "selection_policy": (
            "lane_ordered_chronology_validated_step_candidate_ledger_"
            "limited_recovery_veto_external_exception_packet_fence_"
            "same_step_announced_action_target_binding"
        ),
        "same_step_target_binding": (
            "explicit_announced_information_target_to_action_direct_object"
        ),
    }


def validate_and_write_agent_judge_luna_gaia_v3_11_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_11_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


def run_agent_judge_luna_gaia_v3_11_compact_validation(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> int:
    try:
        audit = validate_and_write_agent_judge_luna_gaia_v3_11_audit(
            prediction_manifest_path,
            cohort_manifest_path,
            predictions_path,
            audit_path,
        )
    except AgentJudgeValidationError as error:
        print(
            json.dumps(
                {
                    "valid": False,
                    "error_code": error.code,
                    "error_message": str(error),
                },
                ensure_ascii=False,
            )
        )
        return 1
    except Exception as error:  # pragma: no cover
        print(
            json.dumps(
                {
                    "valid": False,
                    "error_code": "unexpected_validation_error",
                    "error_message": f"{type(error).__name__}: {error}",
                },
                ensure_ascii=False,
            )
        )
        return 2
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("paths", nargs=4)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("--compact-validate is required")
    return run_agent_judge_luna_gaia_v3_11_compact_validation(*args.paths)


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "AGENT_JUDGE_LUNA_GAIA_V3_11_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_GAIA_V3_11_MODEL",
    "AGENT_JUDGE_LUNA_GAIA_V3_11_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_GAIA_V3_11_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "STEP_CANDIDATE_LEDGER_FIELDS",
    "STEP_CANDIDATE_LEDGER_FILENAME",
    "STEP_CANDIDATE_LANES",
    "STEP_CANDIDATE_ROW_FIELDS",
    "STEP_CANDIDATE_STATUSES",
    "STEP_FREEZE_FIELDS",
    "STEP_FREEZE_FILENAME",
    "build_agent_judge_luna_gaia_v3_11_task",
    "main",
    "run_agent_judge_luna_gaia_v3_11_compact_validation",
    "validate_agent_judge_luna_gaia_v3_11_predictions",
    "validate_and_write_agent_judge_luna_gaia_v3_11_audit",
]

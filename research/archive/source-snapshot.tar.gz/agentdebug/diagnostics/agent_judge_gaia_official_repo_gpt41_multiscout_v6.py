"""Validation policy for the pre-frozen multi-scout GAIA judge."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge import _validate_agent_judge_predictions_with_owner_sources
from .agent_judge_gaia_official_repo_gpt41_serial_v4 import serial_owner_sources


VERSION = "agentdebug.llm-judge.gaia-official-repo-gpt4.1-multiscout-v6"
MODEL = "gpt-4.1"
TEMPERATURE = 0.0
REASONING_EFFORT = "not_applicable"


def build_protocol_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    return f"""Pre-frozen multi-scout GAIA diagnostic judge.

Protocol: {VERSION}
Model: {MODEL}
Temperature: {TEMPERATURE}
Prediction manifest: {Path(prediction_manifest_path).expanduser().resolve()}
Cohort manifest: {Path(cohort_manifest_path).expanduser().resolve()}
Predictions: {Path(predictions_path).expanduser().resolve()}

Four independent scouts may nominate one state-integrity, initial-acquisition,
failed-strategy-recommitment, or external/completion boundary each. Their
rationales are hidden from a fresh reviewer. Opaque, hash-ordered candidates must
all receive three-gate and pairwise review before a step is frozen. Module and
error type are judged from neutral literal handoffs. A causally guarded first
provider failure may be deterministically constrained to
system/tool_execution_error.
"""


def validate_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    base = _validate_agent_judge_predictions_with_owner_sources(
        Path(prediction_manifest_path).expanduser().resolve(),
        Path(cohort_manifest_path).expanduser().resolve(),
        Path(predictions_path).expanduser().resolve(),
        owner_source_resolver=serial_owner_sources,
    )
    return {
        **base,
        "agent_judge_version": VERSION,
        "model": MODEL,
        "reasoning_effort": REASONING_EFFORT,
        "temperature": TEMPERATURE,
        "stage": "four-independent-scouts-then-exhaustive-boundary-review",
        "all_candidates_reviewed": True,
        "all_candidate_pairs_compared": True,
        "opaque_hash_ordered_candidate_ids": True,
        "neutral_module_and_type_handoffs": True,
        "hard_system_owner_policy": "causally-guarded-first-provider-failure",
        "strict_intermediate_lineage_audit": True,
        "implementation_frozen_before_inference": True,
        "external_llm_api": True,
    }


build_task = build_protocol_task

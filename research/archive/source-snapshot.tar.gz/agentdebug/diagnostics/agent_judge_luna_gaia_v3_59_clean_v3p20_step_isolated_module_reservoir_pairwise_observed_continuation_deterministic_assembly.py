"""Luna GAIA v3.59: clean-v3.20 pairwise semantics with deterministic assembly."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions
from .taxonomy import AgentModule, ErrorType, is_valid_classification, taxonomy_prompt


AGENT_JUDGE_LUNA_GAIA_V3_59_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.59-clean-v3.20-"
    "step-isolated-module-reservoir-pairwise-observed-continuation-deterministic-assembly"
)
AGENT_JUDGE_LUNA_GAIA_V3_59_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_59_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_59_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
STEP_PROJECTION_FILENAME = "step-local-projection.json"
STEP_LOCAL_FILENAME = "step-local-evidence.json"
STEP_LOCAL_AUDIT_FILENAME = "step-local-evidence-audit.json"
STEP_LOCAL_RECORDS_FILENAME = "step-local-evidence-records.json"
LOCAL_MATRIX_FILENAME = "step-local-evidence-matrix.json"
LOCAL_MATRICES_FILENAME = "step-local-evidence-matrices.json"
PAIRWISE_ASSESSMENT_FILENAME = "pairwise-observed-continuation-assessment.json"
PAIRWISE_ASSESSMENTS_FILENAME = "pairwise-observed-continuation-assessments.json"
PAIRWISE_ASSESSMENT_AUDIT_FILENAME = "pairwise-observed-continuation-assessment-audit.json"
MODULE_SELECTOR_FILENAME = "module-reservoir-pairwise-reducer.json"
MODULE_SELECTORS_FILENAME = "module-reservoir-pairwise-reducers.json"
MODULE_SELECTOR_AUDIT_FILENAME = "module-reservoir-pairwise-reducer-audit.json"

MODULES = tuple(module.value for module in AgentModule)
STEP_LOCAL_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "step",
    "projection_sha256",
    "module_reviews",
)
LOCAL_REVIEW_FIELDS = (
    "module",
    "owner_present",
    "error_detected",
    "error_type",
    "evidence_quote",
    "local_reasoning",
)
MATRIX_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "reviewed_steps",
    "step_record_sha256s",
    "positive_row_count",
    "positive_rows",
)
POSITIVE_ROW_FIELDS = (
    "row_id",
    "step",
    "module",
    "error_type",
    "evidence_quote",
    "local_reasoning",
    "step_record_sha256",
)
LOCAL_RECORD_SET_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "step_records",
)
MODULE_SELECTOR_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "anchor_prediction_sha256",
    "anchor_ledger_sha256",
    "anchor_checkpoint_sha256",
    "local_matrix_sha256",
    "reviewed_steps",
    "positive_row_count",
    "reviewed_row_ids",
    "representatives",
    "candidate_assessments",
    "decision",
    "selected_representative_index",
    "anchor_step",
    "frozen_step",
    "selected_prediction_sha256",
    "selected_prediction",
    "anchor_classification",
    "anchor_assessment",
    "chronology_comparison",
    "decision_basis",
    "rejected_alternatives_basis",
    "selection_falsifier",
)
REPRESENTATIVE_FIELDS = (
    "module",
    "row_id",
    "step",
    "prediction",
    "module_chronology_basis",
    "repair_effect",
)
ASSESSMENT_FIELDS = (
    "module",
    "row_id",
    "step",
    "classification",
    "anchor_pair_classification",
    "pre_candidate_observation",
    "observed_continuation_anchor_closure",
    "anchor_only_repair_effect",
    "representative_only_repair_effect",
    "winner",
    "winner_relation",
    "pairwise_falsifier",
)
RAW_ASSESSMENT_FIELDS = ASSESSMENT_FIELDS[3:]
PAIRWISE_ASSESSMENT_RECORD_FIELDS = (
    "anchor_classification",
    "anchor_assessment",
    "candidate_assessments",
    "chronology_comparison",
    "decision_basis",
    "rejected_alternatives_basis",
    "selection_falsifier",
)
MODULE_SELECTOR_DECISIONS = frozenset(
    {"keep_anchor", "select_module_representative"}
)
ANCHOR_CLASSES = frozenset(
    {
        "critical_root",
        "contributing_probe",
        "normal_tool_failure",
        "recovered_defect",
        "noncritical_predecessor",
        "faithful_propagation",
        "downstream_symptom",
        "uncertain",
    }
)
PAIRWISE_WINNERS = frozenset({"anchor", "representative"})
ANCHOR_VETO_CLASSES = frozenset(
    {
        "contributing_probe",
        "normal_tool_failure",
        "recovered_defect",
        "noncritical_predecessor",
        "faithful_propagation",
        "downstream_symptom",
    }
)


_LOCAL_RULES = """\
STEP-ISOLATED PAPER-LOCAL ERROR DETECTION — EVIDENCE ONLY

Judge only the projected current Step. The projection contains the observable
input/history available at that Step, the current owner outputs, and adjacent
feedback. Later Steps, an incumbent anchor, global candidates, scores, and gold
are unavailable.

For each of Memory, Reflection, Planning, Action, and System, answer only the
local taxonomy question: does this module's current output contain a concrete
error matching one defined type? A local positive is evidence inventory, not a
critical-Step nomination. Do not test recovery, irreversible failure,
candidate-only repair, anchor-only repair, chronology rank, propagation, or
whether another Step is more important. Those are global-stage questions.

Memory is checked against observable prior facts in current_input. Reflection
is checked against current input, current Memory, and adjacent outcome.
Planning is checked against current input and current Memory/Reflection. Action
is checked against the current plan, available tool/interface, and concrete
parameters or terminal answer. System is positive only for an observable
external execution/runtime/model/step-limit failure despite an otherwise valid
attempt; an ordinary empty or negative result is not a System error. For
System, quote only a normalized string from `owner_sources.system`; wrapper
text elsewhere in the projection is not eligible evidence.

For a positive, copy a literal owner quote and choose exactly one valid taxonomy
type. For an absent owner or a negative verdict, use no_error and null evidence.
Do not infer from trajectory identity, source model, entity, site, or benchmark
history.
"""

_MODULE_SELECTOR_RULES = """\
PAIRWISE OBSERVED-CONTINUATION CRITICAL-BOUNDARY REDUCTION

The clean v3.20 anchor and complete frozen positive-row matrix are immutable.
Review every positive row. Positive rows are evidence inventory, never votes.
Do not choose majority module, Planning by default, repetition, strongest prose,
or the most vivid symptom.

Candidate admission and all mechanical output fields are deterministic. For
each of Memory, Reflection, Planning, Action, and System that has any positive
row, the program binds exactly the earliest positive row of that module in
canonical Module order, at most five. You emit only one semantic assessment
for each listed representative in that exact order. Do not copy trajectory
identity, hashes, row identity, predictions, decisions, or selected outputs.

Use only these exact enum values:
- `classification`, `anchor_pair_classification`, and
  `anchor_classification`: `critical_root`, `contributing_probe`,
  `normal_tool_failure`, `recovered_defect`, `noncritical_predecessor`,
  `faithful_propagation`, `downstream_symptom`, or `uncertain`;
- `winner`: `anchor` or `representative`.

Treat the anchor and each representative as an isolated pair. Do not compare a
representative with any other representative while filling its assessment.
The target is the benchmark's observable first critical-error boundary, not
the earliest hindsight story that could be imagined to improve the trajectory.
Chronology and local-positive status alone never decide.

A task-relevant initial or materially different probe remains a contributing
probe when successful use could expose an identifier, source, text, or other
necessary immediate lead. Do not call it `critical_root` merely because the
route cannot by itself prove the final task predicate. A concrete malformed
parameter or violated task constraint is still eligible when it prevents
informative progress and is not repaired.

For a representative later than the anchor, close the anchor as a non-error on
the *observed continuation*: keep the actual action and feedback; do not replace
it with a better source, tool, query, or route. Decide whether the
representative remains locally invalid. A later row is not faithful propagation
or a downstream symptom merely because a hypothetical repair of the anchor
could erase all later Steps. It loses only when literal evidence shows that the
same defect was fully recovered, merely executes an already-invalid instruction,
or lacks an independent path effect.

For a representative earlier than the anchor, require literal local ownership
and show that representative-only repair materially changes the failed path;
do not prefer it merely for being earlier. An externally owned System
tool-execution failure is eligible when a valid indispensable attempt literally
fails and becomes the first observable blocking boundary. External ownership
or the phrase `normal tool failure` alone is not a veto. Ordinary empty or
negative results were already excluded by the local stage.

Each pair must record the observation available before the representative,
the anchor's pair classification, observed-continuation anchor closure, both
one-sided repair effects, one winner, the decisive relation, and a falsifier.
The representative wins only when it is `critical_root`, the anchor is one of
the enumerated noncritical veto classes, and the literal two-sided relation is
decisive. `uncertain` and ties keep the anchor.

The final choice is mechanical and is not part of your output. If no pair has
an eligible representative win,
keep the anchor. Otherwise select the chronologically earliest eligible winning
representative, breaking a same-Step tie by canonical Module order. The global
anchor classification must equal the anchor classification in every pair. The
program constructs every representative prediction, identity/hash binding,
decision, selected exact copy, and final record after your semantic artifact
passes validation.

Never invent a row, prediction, Step, repair outcome, or third alternative.
Never read scores, gold labels, old predictions, error reports, experiment
documents, source-identity priors, or external resources.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_59_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_59_clean_v3p20_step_isolated_module_reservoir_pairwise_observed_continuation_deterministic_assembly",
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py",
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_59_clean_v3p20_step_isolated_module_reservoir_pairwise_observed_continuation_deterministic_assembly.py",
        )
        .replace(
            "- agentdebug/diagnostics/agent_judge_luna_gaia_v3_59_clean_v3p20_step_isolated_module_reservoir_pairwise_observed_continuation_deterministic_assembly.py",
            "- agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py",
        )
    )


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_59_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_59_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_59_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": (
            "one clean-v3.20 step-isolated observed-continuation pairwise "
            "mechanism whose immutable bindings and reducer output are "
            "deterministically assembled from semantic-only assessments"
        ),
    }


def _boundary(
    *, manifest: Path, cohort: Path, reads: Sequence[Path], output: Path
) -> str:
    read_lines = "\n".join(f"- {path}" for path in reads) or "- none"
    return f"""\
IMMUTABLE EXECUTION CONFIGURATION
- model: {AGENT_JUDGE_LUNA_GAIA_V3_59_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_59_REASONING_EFFORT}
- one isolated case; fresh session; no cross-case state or prior predictions
- external LLM/API/network calls: forbidden
- scoring or gold-label access: forbidden

INPUT/OUTPUT BOUNDARY
- prediction manifest: {manifest}
- prediction manifest file sha256: {shared._file_sha256(manifest)}
- cohort manifest: {cohort}
- cohort manifest file sha256: {shared._file_sha256(cohort)}
- permitted frozen stage inputs:
{read_lines}
- write the sole stage artifact only to: {output}

Read only those exact inputs plus `agentdebug/diagnostics/taxonomy.py`. Do not
inspect directories or infer from trajectory/source-model/environment names. Never
read labels, metrics, scored artifacts, experiment documents, proposal files
other than the permitted current input, old predictions, cached replies, case
studies, git history, or external resources.
"""


def build_anchor_task(*paths: str | Path) -> str:
    """Use exactly v3.20 anchor semantics, with identity retagged."""

    return _rewrite_identity(parent.build_anchor_task(*paths))


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths), policy="unchanged_v3_20_anchor")


def build_step_projection_document(case: Any, step_number: int) -> dict[str, Any]:
    """Return a deterministic prefix-bounded input for one local Step call."""

    if step_number < 1 or step_number > len(case.judge_view.steps):
        shared._fail("invalid_step_local_projection_step", str(step_number))
    step = case.judge_view.steps[step_number - 1]
    sources: dict[str, list[str]] = {module: [] for module in MODULES}
    for span in step.module_spans:
        value = step.assistant_raw_output[
            span.content_start_char : span.content_end_char
        ].strip()
        if span.module in sources and value:
            sources[span.module].append(value)
    # Promotion safety is structural: local System evidence and final
    # prediction evidence use the exact same normalized owner-source resolver.
    sources[AgentModule.SYSTEM.value] = list(
        shared._luna_gaia_v2_owner_source_resolver(
            case.judge_view,
            step_number,
            AgentModule.SYSTEM,
            ErrorType.TOOL_EXECUTION_ERROR,
        )
    )
    task = case.judge_view.task
    return {
        "schema_version": "agentdebug.step-isolated-paper-local-projection.v1",
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "step": step_number,
        "task": task.display_text if task is not None else "",
        "current_input": [item.text for item in step.current_input],
        "assistant_raw_output": step.assistant_raw_output,
        "owner_sources": sources,
        "later_steps_visible": False,
    }


def _validate_step_projection(raw: Any, *, location: str) -> dict[str, Any]:
    expected = (
        "schema_version",
        "trajectory_id",
        "trajectory_sha256",
        "step",
        "task",
        "current_input",
        "assistant_raw_output",
        "owner_sources",
        "later_steps_visible",
    )
    if not isinstance(raw, dict) or tuple(raw) != expected:
        shared._fail("invalid_step_local_projection_schema", location)
    if raw["schema_version"] != "agentdebug.step-isolated-paper-local-projection.v1":
        shared._fail("invalid_step_local_projection_version", location)
    if (
        isinstance(raw["step"], bool)
        or not isinstance(raw["step"], int)
        or raw["step"] < 1
    ):
        shared._fail("invalid_step_local_projection_step", location)
    if raw["later_steps_visible"] is not False:
        shared._fail("step_local_projection_exposes_later_steps", location)
    if not isinstance(raw["owner_sources"], dict) or tuple(raw["owner_sources"]) != MODULES:
        shared._fail("invalid_step_local_projection_owner_sources", location)
    for module, values in raw["owner_sources"].items():
        if not isinstance(values, list) or not all(
            isinstance(value, str) and value.strip() for value in values
        ):
            shared._fail("invalid_step_local_projection_owner_sources", f"{location}.{module}")
    return raw


def _validate_step_local_record(
    raw: Any, *, projection: dict[str, Any], location: str
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != STEP_LOCAL_FIELDS:
        shared._fail("invalid_step_local_evidence_schema", location)
    if (
        raw["trajectory_id"] != projection["trajectory_id"]
        or raw["trajectory_sha256"] != projection["trajectory_sha256"]
        or raw["step"] != projection["step"]
        or raw["projection_sha256"] != shared._stable_sha256(projection)
    ):
        shared._fail("step_local_evidence_identity_mismatch", location)
    reviews = raw["module_reviews"]
    if not isinstance(reviews, list) or len(reviews) != len(MODULES):
        shared._fail("invalid_step_local_review_count", location)
    if [review.get("module") for review in reviews if isinstance(review, dict)] != list(MODULES):
        shared._fail("invalid_step_local_module_order", location)
    for index, review in enumerate(reviews):
        row_location = f"{location}.module_reviews[{index}]"
        if not isinstance(review, dict) or tuple(review) != LOCAL_REVIEW_FIELDS:
            shared._fail("invalid_step_local_review_schema", row_location)
        try:
            module = AgentModule(review["module"])
        except ValueError:
            shared._fail("invalid_step_local_module", row_location)
        sources = projection["owner_sources"][module.value]
        owner_present = bool(sources)
        if review["owner_present"] is not owner_present:
            shared._fail("step_local_owner_presence_mismatch", row_location)
        if not isinstance(review["error_detected"], bool):
            shared._fail("invalid_step_local_error_flag", row_location)
        shared._nonempty_text(
            review["local_reasoning"],
            location=f"{row_location}.local_reasoning",
            maximum=2000,
        )
        if not owner_present or not review["error_detected"]:
            if review["error_type"] != "no_error" or review["evidence_quote"] is not None:
                shared._fail("invalid_step_local_negative_fields", row_location)
            continue
        if projection["step"] == 1 and module in {
            AgentModule.MEMORY,
            AgentModule.REFLECTION,
        }:
            shared._fail("invalid_step_one_memory_reflection_positive", row_location)
        try:
            error_type = ErrorType(review["error_type"])
        except ValueError:
            shared._fail("invalid_step_local_error_type", row_location)
        if not is_valid_classification(module, error_type):
            shared._fail("invalid_step_local_error_type", row_location)
        shared._nonempty_text(
            review["evidence_quote"],
            location=f"{row_location}.evidence_quote",
            maximum=1800,
        )
        if not any(review["evidence_quote"] in source for source in sources):
            shared._fail("invalid_step_local_evidence_quote", row_location)
    return raw


def validate_step_local(
    projection_path: str | Path, local_path: str | Path
) -> dict[str, Any]:
    projection_file, projection_raw = shared._load_artifact(
        projection_path, role="step local projection"
    )
    projection = _validate_step_projection(projection_raw, location="projection")
    local_file, local_raw = shared._load_artifact(
        local_path, role="step local evidence"
    )
    local = _validate_step_local_record(
        local_raw, projection=projection, location="step_local"
    )
    return _retag(
        {
            "schema_version": "agentdebug.step-isolated-paper-local-audit.v1",
            "stage": "step_isolated_paper_local_evidence",
            "gold_free_validation": True,
            "case_count": 1,
            "step": projection["step"],
            "later_steps_visible": False,
            "anchor_visible": False,
            "module_count": len(MODULES),
            "positive_count": sum(
                review["error_detected"] for review in local["module_reviews"]
            ),
            "input_sha256": {"projection": shared._file_sha256(projection_file)},
            "output_sha256": {STEP_LOCAL_FILENAME: shared._file_sha256(local_file)},
        },
        policy="step_isolated_paper_local_evidence_only",
    )


def build_step_local_task(
    projection_path: str | Path, local_path: str | Path
) -> str:
    projection_file, projection_raw = shared._load_artifact(
        projection_path, role="step local projection"
    )
    projection = _validate_step_projection(projection_raw, location="projection")
    output = Path(local_path).expanduser().resolve()
    shared._assert_safe_path(output, role="step local evidence output", is_output=True)
    audit = output.parent / STEP_LOCAL_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_59_clean_v3p20_step_isolated_module_reservoir_pairwise_observed_continuation_deterministic_assembly",
            "--compact-validate",
            "local",
            projection_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    schema = {
        "trajectory_id": projection["trajectory_id"],
        "trajectory_sha256": projection["trajectory_sha256"],
        "step": projection["step"],
        "projection_sha256": shared._stable_sha256(projection),
        "module_reviews": [
            {
                "module": module,
                "owner_present": bool(projection["owner_sources"][module]),
                "error_detected": "true or false",
                "error_type": "valid assigned-module type or no_error",
                "evidence_quote": "literal owner quote or null",
                "local_reasoning": "taxonomy-local reasoning only",
            }
            for module in MODULES
        ],
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_59_VERSION} local evidence stage for Step {projection['step']}.

IMMUTABLE EXECUTION CONFIGURATION
- model: {AGENT_JUDGE_LUNA_GAIA_V3_59_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_59_REASONING_EFFORT}
- one fresh session; one prefix-bounded Step; no later Step or anchor
- external LLM/API/network calls and scoring/gold access: forbidden

Read only:
- {projection_file}
- this v3.59 protocol source
- `agentdebug/diagnostics/taxonomy.py`
Write only: {output}

Do not inspect directories, experiment documents, labels, metrics, scored
artifacts, old predictions, error reports, case studies, git history, source
identity, or external resources.

{_LOCAL_RULES}

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON object with fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def build_local_matrix_document(
    *, case: Any, local_records: Sequence[dict[str, Any]]
) -> dict[str, Any]:
    if [record["step"] for record in local_records] != list(
        range(1, len(case.judge_view.steps) + 1)
    ):
        shared._fail("incomplete_step_local_matrix_coverage", case.trajectory_id)
    positives: list[dict[str, Any]] = []
    hashes = [shared._stable_sha256(record) for record in local_records]
    for record, record_hash in zip(local_records, hashes, strict=True):
        for review in record["module_reviews"]:
            if not review["error_detected"]:
                continue
            positives.append(
                {
                    "row_id": f"P{len(positives) + 1:03d}",
                    "step": record["step"],
                    "module": review["module"],
                    "error_type": review["error_type"],
                    "evidence_quote": review["evidence_quote"],
                    "local_reasoning": review["local_reasoning"],
                    "step_record_sha256": record_hash,
                }
            )
    return {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "reviewed_steps": list(range(1, len(case.judge_view.steps) + 1)),
        "step_record_sha256s": hashes,
        "positive_row_count": len(positives),
        "positive_rows": positives,
    }


def build_local_record_set_document(
    *, case: Any, local_records: Sequence[dict[str, Any]]
) -> dict[str, Any]:
    if [record["step"] for record in local_records] != list(
        range(1, len(case.judge_view.steps) + 1)
    ):
        shared._fail("incomplete_step_local_record_set", case.trajectory_id)
    return {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "step_records": list(local_records),
    }


def _validate_local_record_set(
    raw: Any, *, case: Any, matrix: dict[str, Any], location: str
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != LOCAL_RECORD_SET_FIELDS:
        shared._fail("invalid_step_local_record_set_schema", location)
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
        or not isinstance(raw["step_records"], list)
        or len(raw["step_records"]) != len(case.judge_view.steps)
    ):
        shared._fail("step_local_record_set_identity_or_count_mismatch", location)
    records: list[dict[str, Any]] = []
    for step_number, record in enumerate(raw["step_records"], start=1):
        projection = build_step_projection_document(case, step_number)
        records.append(
            _validate_step_local_record(
                record,
                projection=projection,
                location=f"{location}.step_records[{step_number - 1}]",
            )
        )
    rebuilt = build_local_matrix_document(case=case, local_records=records)
    if rebuilt != matrix:
        shared._fail("step_local_matrix_not_deterministic_from_records", location)
    return raw


def _validate_local_matrix_record(
    raw: Any, *, case: Any, location: str
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != MATRIX_FIELDS:
        shared._fail("invalid_step_local_matrix_schema", location)
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
        or raw["reviewed_steps"] != list(range(1, len(case.judge_view.steps) + 1))
    ):
        shared._fail("step_local_matrix_identity_or_coverage_mismatch", location)
    hashes = raw["step_record_sha256s"]
    if not isinstance(hashes, list) or len(hashes) != len(case.judge_view.steps) or not all(
        isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value)
        for value in hashes
    ):
        shared._fail("invalid_step_local_matrix_hashes", location)
    positives = raw["positive_rows"]
    if (
        isinstance(raw["positive_row_count"], bool)
        or not isinstance(raw["positive_row_count"], int)
        or not isinstance(positives, list)
        or raw["positive_row_count"] != len(positives)
    ):
        shared._fail("invalid_step_local_matrix_positive_count", location)
    for index, row in enumerate(positives):
        row_location = f"{location}.positive_rows[{index}]"
        if not isinstance(row, dict) or tuple(row) != POSITIVE_ROW_FIELDS:
            shared._fail("invalid_step_local_positive_schema", row_location)
        if row["row_id"] != f"P{index + 1:03d}":
            shared._fail("invalid_step_local_positive_id", row_location)
        if (
            isinstance(row["step"], bool)
            or not isinstance(row["step"], int)
            or row["step"] < 1
            or row["step"] > len(case.judge_view.steps)
        ):
            shared._fail("invalid_step_local_positive_step", row_location)
        prediction = {
            "trajectory_id": case.trajectory_id,
            "trajectory_sha256": case.trajectory_sha256,
            "status": "success",
            "predicted_step": row["step"],
            "predicted_module": row["module"],
            "predicted_error_type": row["error_type"],
            "evidence_quote": row["evidence_quote"],
            "root_cause": row["local_reasoning"],
            "causal_summary": row["local_reasoning"],
            "rejected_adjacent_owner": "Local evidence row; global ownership not yet selected.",
        }
        shared._validate_prediction_record(
            prediction, case=case, location=f"{row_location}.projection"
        )
        if row["step_record_sha256"] != hashes[row["step"] - 1]:
            shared._fail("step_local_positive_hash_mismatch", row_location)
    return raw


def validate_local_matrix(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    matrix_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    matrix_file, matrix_raw = shared._load_artifact(
        matrix_path, role="step local evidence matrix"
    )
    matrix = _validate_local_matrix_record(
        matrix_raw, case=case, location="local_matrix"
    )
    return _retag(
        {
            "schema_version": "agentdebug.step-isolated-local-matrix-audit.v1",
            "stage": "deterministic_step_local_evidence_matrix",
            "gold_free_validation": True,
            "case_count": 1,
            "step_count": len(case.judge_view.steps),
            "complete_step_coverage": True,
            "positive_row_count": matrix["positive_row_count"],
            "input_sha256": {
                "prediction_manifest": shared._file_sha256(manifest),
                "cohort": shared._file_sha256(cohort),
            },
            "output_sha256": {LOCAL_MATRIX_FILENAME: shared._file_sha256(matrix_file)},
        },
        policy="deterministic_step_isolated_local_evidence_matrix",
    )


def _validate_optional_literal(
    *, case: Any, step: Any, quote: Any, location: str
) -> None:
    if step is None and quote is None:
        return
    if isinstance(step, bool) or not isinstance(step, int):
        shared._fail("invalid_duel_literal_step", location)
    if step < 1 or step > len(case.judge_view.steps):
        shared._fail("invalid_duel_literal_step", location)
    shared._nonempty_text(quote, location=f"{location}.quote", maximum=1800)
    if not any(quote in source for source in shared._packet_sources(case, step)):
        shared._fail("invalid_duel_literal_quote", location)


def _load_anchor_bundle(
    manifest: Path,
    cohort: Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> tuple[Path, Path, Path, dict[str, Any], dict[str, Any], dict[str, Any]]:
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    anchor, ledger, checkpoint = shared._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    parent._validate_packet_state_ledgers(ledger_file)
    return anchor_file, ledger_file, checkpoint_file, anchor, ledger, checkpoint


def _expected_module_rows(matrix: dict[str, Any]) -> list[dict[str, Any]]:
    """Return the deterministic earliest positive row for every represented module."""

    result: list[dict[str, Any]] = []
    for module in MODULES:
        row = next(
            (
                candidate
                for candidate in matrix["positive_rows"]
                if candidate["module"] == module
            ),
            None,
        )
        if row is not None:
            result.append(row)
    return result


def _validate_pairwise_assessment_record(
    raw: Any,
    *,
    expected_rows: Sequence[dict[str, Any]],
    location: str,
) -> dict[str, Any]:
    """Validate only model-authored semantic fields; all bindings are external."""

    if not isinstance(raw, dict) or tuple(raw) != PAIRWISE_ASSESSMENT_RECORD_FIELDS:
        shared._fail("invalid_pairwise_assessment_record_schema", location)
    anchor_class = raw["anchor_classification"]
    if anchor_class not in ANCHOR_CLASSES:
        shared._fail("invalid_pairwise_anchor_classification", location)
    assessments = raw["candidate_assessments"]
    if not isinstance(assessments, list) or len(assessments) != len(expected_rows):
        shared._fail("invalid_pairwise_assessment_count", location)
    for index, assessment in enumerate(assessments):
        assessment_location = f"{location}.candidate_assessments[{index}]"
        if not isinstance(assessment, dict) or tuple(assessment) != RAW_ASSESSMENT_FIELDS:
            shared._fail("invalid_pairwise_assessment_schema", assessment_location)
        if assessment["classification"] not in ANCHOR_CLASSES:
            shared._fail("invalid_module_candidate_classification", assessment_location)
        if assessment["anchor_pair_classification"] not in ANCHOR_CLASSES:
            shared._fail("invalid_pairwise_anchor_classification", assessment_location)
        if assessment["anchor_pair_classification"] != anchor_class:
            shared._fail("pairwise_anchor_classification_drift", assessment_location)
        if assessment["winner"] not in PAIRWISE_WINNERS:
            shared._fail("invalid_pairwise_winner", assessment_location)
        for field in (
            "pre_candidate_observation",
            "observed_continuation_anchor_closure",
            "anchor_only_repair_effect",
            "representative_only_repair_effect",
            "winner_relation",
            "pairwise_falsifier",
        ):
            shared._nonempty_text(
                assessment[field],
                location=f"{assessment_location}.{field}",
                maximum=3200,
            )
        if assessment["winner"] == "representative" and not (
            assessment["classification"] == "critical_root"
            and anchor_class in ANCHOR_VETO_CLASSES
        ):
            shared._fail("ineligible_pairwise_representative_win", assessment_location)
    for field in (
        "anchor_assessment",
        "chronology_comparison",
        "decision_basis",
        "rejected_alternatives_basis",
        "selection_falsifier",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3400)
    if not raw["anchor_assessment"].startswith(f"anchor_status={anchor_class}; "):
        shared._fail("missing_module_selector_anchor_assessment_prefix", location)
    return raw


def _deterministic_representative_prediction(
    *, case: Any, row: dict[str, Any]
) -> dict[str, Any]:
    prediction = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        "predicted_step": row["step"],
        "predicted_module": row["module"],
        "predicted_error_type": row["error_type"],
        "evidence_quote": row["evidence_quote"],
        "root_cause": (
            f"The frozen Step-local {row['module']} review identifies this literal "
            f"taxonomy defect: {row['local_reasoning']}"
        ),
        "causal_summary": (
            "This deterministic representative is promoted only if its isolated "
            "observed-continuation pair assessment establishes the critical boundary."
        ),
        "rejected_adjacent_owner": (
            "Adjacent owners are not substituted for this frozen local-positive row."
        ),
    }
    shared._validate_prediction_record(
        prediction, case=case, location="deterministic_representative_prediction"
    )
    return prediction


def build_module_selector_document(
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    matrix: dict[str, Any],
    semantic_assessment: dict[str, Any],
) -> dict[str, Any]:
    """Deterministically bind semantics to rows and reduce to one exact copy."""

    expected_rows = _expected_module_rows(matrix)
    semantic = _validate_pairwise_assessment_record(
        semantic_assessment,
        expected_rows=expected_rows,
        location="pairwise_assessment",
    )
    representatives: list[dict[str, Any]] = []
    full_assessments: list[dict[str, Any]] = []
    eligible_indexes: list[int] = []
    for index, (row, assessment) in enumerate(
        zip(expected_rows, semantic["candidate_assessments"], strict=True)
    ):
        representatives.append(
            {
                "module": row["module"],
                "row_id": row["row_id"],
                "step": row["step"],
                "prediction": _deterministic_representative_prediction(case=case, row=row),
                "module_chronology_basis": (
                    f"{row['row_id']} is deterministically the earliest positive "
                    f"{row['module']} row in the frozen matrix."
                ),
                "repair_effect": assessment["representative_only_repair_effect"],
            }
        )
        full_assessments.append(
            {
                "module": row["module"],
                "row_id": row["row_id"],
                "step": row["step"],
                **assessment,
            }
        )
        if assessment["winner"] == "representative":
            eligible_indexes.append(index)
    selected_index = min(
        eligible_indexes,
        key=lambda index: (
            representatives[index]["step"],
            MODULES.index(representatives[index]["module"]),
        ),
        default=None,
    )
    if selected_index is None:
        decision = "keep_anchor"
        selected_representative_index = None
        selected_prediction = anchor
    else:
        decision = "select_module_representative"
        selected_representative_index = selected_index + 1
        selected_prediction = representatives[selected_index]["prediction"]
    result = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "local_matrix_sha256": shared._stable_sha256(matrix),
        "reviewed_steps": matrix["reviewed_steps"],
        "positive_row_count": matrix["positive_row_count"],
        "reviewed_row_ids": [row["row_id"] for row in matrix["positive_rows"]],
        "representatives": representatives,
        "candidate_assessments": full_assessments,
        "decision": decision,
        "selected_representative_index": selected_representative_index,
        "anchor_step": anchor["predicted_step"],
        "frozen_step": selected_prediction["predicted_step"],
        "selected_prediction_sha256": shared._stable_sha256(selected_prediction),
        "selected_prediction": selected_prediction,
        "anchor_classification": semantic["anchor_classification"],
        "anchor_assessment": semantic["anchor_assessment"],
        "chronology_comparison": semantic["chronology_comparison"],
        "decision_basis": semantic["decision_basis"],
        "rejected_alternatives_basis": semantic["rejected_alternatives_basis"],
        "selection_falsifier": semantic["selection_falsifier"],
    }
    return _validate_module_selector_record(
        result,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        matrix=matrix,
        location="deterministic_module_selector",
    )


def _validate_module_selector_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    matrix: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != MODULE_SELECTOR_FIELDS:
        shared._fail("invalid_module_reservoir_selector_schema", location)
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
    ):
        shared._fail("module_reservoir_selector_identity_mismatch", location)
    bindings = {
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "local_matrix_sha256": shared._stable_sha256(matrix),
    }
    if any(raw[key] != value for key, value in bindings.items()):
        shared._fail("module_reservoir_selector_hash_mismatch", location)
    if (
        raw["reviewed_steps"] != matrix["reviewed_steps"]
        or raw["positive_row_count"] != matrix["positive_row_count"]
        or raw["reviewed_row_ids"]
        != [row["row_id"] for row in matrix["positive_rows"]]
    ):
        shared._fail("incomplete_module_selector_matrix_coverage", location)
    if raw["anchor_step"] != anchor["predicted_step"]:
        shared._fail("module_selector_anchor_step_mismatch", location)
    if raw["decision"] not in MODULE_SELECTOR_DECISIONS:
        shared._fail("invalid_module_selector_decision", location)
    if raw["anchor_classification"] not in ANCHOR_CLASSES:
        shared._fail("invalid_module_selector_anchor_classification", location)

    representatives = raw["representatives"]
    expected_rows = _expected_module_rows(matrix)
    if not isinstance(representatives, list) or len(representatives) != len(
        expected_rows
    ):
        shared._fail("invalid_module_representative_count", location)
    matrix_rows = {row["row_id"]: row for row in matrix["positive_rows"]}
    validated_representatives: list[dict[str, Any]] = []
    for index, (representative, expected_row) in enumerate(
        zip(representatives, expected_rows, strict=True)
    ):
        rep_location = f"{location}.representatives[{index}]"
        if (
            not isinstance(representative, dict)
            or tuple(representative) != REPRESENTATIVE_FIELDS
        ):
            shared._fail("invalid_module_representative_schema", rep_location)
        module = representative["module"]
        row_id = representative["row_id"]
        if (
            module != expected_row["module"]
            or row_id != expected_row["row_id"]
            or matrix_rows.get(row_id) != expected_row
        ):
            shared._fail("module_reservoir_not_earliest_positive", rep_location)
        row = matrix_rows[row_id]
        prediction = shared._validate_prediction_record(
            representative["prediction"],
            case=case,
            location=f"{rep_location}.prediction",
        )
        if (
            representative["step"] != row["step"]
            or prediction["predicted_step"] != row["step"]
            or prediction["predicted_module"] != row["module"]
            or prediction["predicted_error_type"] != row["error_type"]
            or prediction["evidence_quote"] != row["evidence_quote"]
        ):
            shared._fail("module_representative_row_copy_mismatch", rep_location)
        for field in ("module_chronology_basis", "repair_effect"):
            shared._nonempty_text(
                representative[field],
                location=f"{rep_location}.{field}",
                maximum=3200,
            )
        validated_representatives.append(representative)

    assessments = raw["candidate_assessments"]
    if not isinstance(assessments, list) or len(assessments) != len(
        validated_representatives
    ):
        shared._fail("invalid_module_candidate_assessment_count", location)
    eligible_winner_indexes: list[int] = []
    for index, (assessment, representative) in enumerate(
        zip(assessments, validated_representatives, strict=True)
    ):
        assessment_location = f"{location}.candidate_assessments[{index}]"
        if not isinstance(assessment, dict) or tuple(assessment) != ASSESSMENT_FIELDS:
            shared._fail("invalid_module_candidate_assessment_schema", assessment_location)
        if any(
            assessment[field] != representative[field]
            for field in ("module", "row_id", "step")
        ):
            shared._fail("module_candidate_assessment_identity_mismatch", assessment_location)
        if assessment["classification"] not in ANCHOR_CLASSES:
            shared._fail("invalid_module_candidate_classification", assessment_location)
        if assessment["anchor_pair_classification"] not in ANCHOR_CLASSES:
            shared._fail("invalid_pairwise_anchor_classification", assessment_location)
        if assessment["anchor_pair_classification"] != raw["anchor_classification"]:
            shared._fail("pairwise_anchor_classification_drift", assessment_location)
        if assessment["winner"] not in PAIRWISE_WINNERS:
            shared._fail("invalid_pairwise_winner", assessment_location)
        for field in (
            "pre_candidate_observation",
            "observed_continuation_anchor_closure",
            "anchor_only_repair_effect",
            "representative_only_repair_effect",
            "winner_relation",
            "pairwise_falsifier",
        ):
            shared._nonempty_text(
                assessment[field],
                location=f"{assessment_location}.{field}",
                maximum=3200,
            )
        if assessment["winner"] == "representative":
            if not (
                assessment["classification"] == "critical_root"
                and assessment["anchor_pair_classification"] in ANCHOR_VETO_CLASSES
            ):
                shared._fail(
                    "ineligible_pairwise_representative_win", assessment_location
                )
            eligible_winner_indexes.append(index)

    for field in (
        "anchor_assessment",
        "chronology_comparison",
        "decision_basis",
        "rejected_alternatives_basis",
        "selection_falsifier",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3400)
    anchor_prefix = f"anchor_status={raw['anchor_classification']}; "
    if not raw["anchor_assessment"].startswith(anchor_prefix):
        shared._fail("missing_module_selector_anchor_assessment_prefix", location)
    selected = shared._validate_prediction_record(
        raw["selected_prediction"], case=case, location=f"{location}.selected"
    )
    if raw["selected_prediction_sha256"] != shared._stable_sha256(selected):
        shared._fail("module_selector_selected_hash_mismatch", location)
    if raw["frozen_step"] != selected["predicted_step"]:
        shared._fail("module_selector_frozen_step_mismatch", location)

    expected_index = min(
        eligible_winner_indexes,
        key=lambda index: (
            validated_representatives[index]["step"],
            MODULES.index(validated_representatives[index]["module"]),
        ),
        default=None,
    )
    if expected_index is None:
        if raw["decision"] != "keep_anchor":
            shared._fail("pairwise_reducer_decision_mismatch", location)
        if selected != anchor or raw["selected_representative_index"] is not None:
            shared._fail("module_selector_keep_anchor_copy_mismatch", location)
    else:
        expected_selected_index = expected_index + 1
        if (
            raw["decision"] != "select_module_representative"
            or raw["selected_representative_index"] != expected_selected_index
        ):
            shared._fail("pairwise_reducer_decision_mismatch", location)
        representative = validated_representatives[expected_index]
        if selected != representative["prediction"]:
            shared._fail("module_selector_representative_copy_mismatch", location)
    return raw


def validate_module_selector(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    matrix_path: str | Path,
    module_selector_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger, checkpoint = bundle[3:]
    matrix_file, matrix_raw = shared._load_artifact(
        matrix_path, role="step local evidence matrix"
    )
    matrix = _validate_local_matrix_record(
        matrix_raw, case=case, location="local_matrix"
    )
    selector_file, selector_raw = shared._load_artifact(
        module_selector_path, role="module-reservoir pairwise reducer"
    )
    selector = shared._one_record(
        selector_raw, role="module-reservoir pairwise reducer"
    )
    _validate_module_selector_record(
        selector,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        matrix=matrix,
        location="module_selector[0]",
    )
    return _retag(
        {
            "schema_version": "agentdebug.module-reservoir-pairwise-reducer-audit.v1",
            "stage": "module_reservoir_pairwise_observed_continuation_deterministic_assembly",
            "gold_free_validation": True,
            "case_count": 1,
            "decision": selector["decision"],
            "representative_count": len(selector["representatives"]),
            "selected_prediction_exact_copy": True,
            "all_positive_rows_reviewed": True,
            "deterministic_earliest_positive_per_module": True,
            "validator_enforced_pairwise_observed_continuation": True,
            "deterministic_pairwise_reducer": True,
            "maximum_representatives": len(MODULES),
            "input_sha256": {
                "anchor": shared._file_sha256(anchor_file),
                "ledger": shared._file_sha256(ledger_file),
                "checkpoint": shared._file_sha256(checkpoint_file),
                "local_matrix": shared._file_sha256(matrix_file),
            },
            "output_sha256": {
                MODULE_SELECTOR_FILENAME: shared._file_sha256(selector_file)
            },
        },
        policy="module_reservoir_pairwise_observed_continuation_exact_copy_reducer",
    )


def validate_pairwise_assessment(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    matrix_path: str | Path,
    assessment_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    matrix_file, matrix_raw = shared._load_artifact(
        matrix_path, role="step local evidence matrix"
    )
    matrix = _validate_local_matrix_record(
        matrix_raw, case=case, location="local_matrix"
    )
    assessment_file, assessment_raw = shared._load_artifact(
        assessment_path, role="pairwise observed-continuation assessment"
    )
    assessment = shared._one_record(
        assessment_raw, role="pairwise observed-continuation assessment"
    )
    _validate_pairwise_assessment_record(
        assessment,
        expected_rows=_expected_module_rows(matrix),
        location="pairwise_assessment[0]",
    )
    return _retag(
        {
            "schema_version": "agentdebug.pairwise-observed-continuation-assessment-audit.v1",
            "stage": "pairwise_observed_continuation_semantic_assessment",
            "gold_free_validation": True,
            "case_count": 1,
            "assessment_count": len(assessment["candidate_assessments"]),
            "model_authored_identity_or_hash_fields": False,
            "deterministic_assembly_required": True,
            "input_sha256": {
                "anchor": shared._file_sha256(anchor_file),
                "ledger": shared._file_sha256(ledger_file),
                "checkpoint": shared._file_sha256(checkpoint_file),
                "local_matrix": shared._file_sha256(matrix_file),
            },
            "output_sha256": {
                PAIRWISE_ASSESSMENT_FILENAME: shared._file_sha256(assessment_file)
            },
        },
        policy="semantic_only_pairwise_observed_continuation_assessment",
    )


def build_pairwise_assessment_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    matrix_path: str | Path,
    assessment_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor = bundle[3]
    matrix_file, matrix_raw = shared._load_artifact(
        matrix_path, role="step local evidence matrix"
    )
    matrix = _validate_local_matrix_record(
        matrix_raw, case=case, location="local_matrix"
    )
    expected_rows = _expected_module_rows(matrix)
    output = Path(assessment_path).expanduser().resolve()
    shared._assert_safe_path(
        output, role="pairwise semantic assessment output", is_output=True
    )
    audit = output.parent / PAIRWISE_ASSESSMENT_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_59_clean_v3p20_step_isolated_module_reservoir_pairwise_observed_continuation_deterministic_assembly",
            "--compact-validate",
            "pairwise-assessment",
            manifest,
            cohort,
            anchor_file,
            ledger_file,
            checkpoint_file,
            matrix_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    assessment_schema = {
        "classification": "exactly one of critical_root | contributing_probe | normal_tool_failure | recovered_defect | noncritical_predecessor | faithful_propagation | downstream_symptom | uncertain",
        "anchor_pair_classification": "the exact global anchor class, identical in every pair",
        "pre_candidate_observation": "literal state observable immediately before this representative",
        "observed_continuation_anchor_closure": "close anchor as non-error while preserving actual action and feedback; state whether this row remains invalid",
        "anchor_only_repair_effect": "one-sided effect of repairing only the anchor without inventing a better route",
        "representative_only_repair_effect": "one-sided effect of repairing only this representative",
        "winner": "exactly anchor or representative",
        "winner_relation": "literal two-sided relation that decides this isolated pair",
        "pairwise_falsifier": "specific observation that would reverse this pair winner",
    }
    schema = {
        "anchor_classification": "exactly one of critical_root | contributing_probe | normal_tool_failure | recovered_defect | noncritical_predecessor | faithful_propagation | downstream_symptom | uncertain",
        "anchor_assessment": "anchor_status=<class>; evidence-grounded assessment and repair effect",
        "candidate_assessments": [assessment_schema],
        "chronology_comparison": "anchor and all representatives in literal chronology",
        "decision_basis": "semantic basis the deterministic reducer should apply",
        "rejected_alternatives_basis": "why each losing side loses in its isolated pair",
        "selection_falsifier": "strongest concrete argument against these pair outcomes",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_59_VERSION} semantic-only pairwise assessment.

{_boundary(manifest=manifest, cohort=cohort, reads=(anchor_file, ledger_file, checkpoint_file, matrix_file), output=output)}

{_MODULE_SELECTOR_RULES}

The immutable anchor Step is {anchor['predicted_step']}. The matrix contains
{matrix['positive_row_count']} positive rows. The program has bound these
representatives in exact assessment order:
{[row['module'] + ':' + row['row_id'] + '@' + str(row['step']) for row in expected_rows]}.
Write exactly {len(expected_rows)} semantic assessments in that order. Do not
emit module, row_id, Step, trajectory identity, hashes, representatives,
predictions, decision, selected index, or selected output. An empty matrix
requires an empty candidate_assessments array; the program will keep anchor.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _validate_aggregate(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(prediction_manifest_path, cohort_manifest_path)
    root = Path(predictions_path).expanduser().resolve().parent
    names = (
        ANCHOR_PREDICTIONS_FILENAME,
        ANCHOR_LEDGER_AGGREGATE_FILENAME,
        ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        STEP_LOCAL_RECORDS_FILENAME,
        LOCAL_MATRICES_FILENAME,
        PAIRWISE_ASSESSMENTS_FILENAME,
        MODULE_SELECTORS_FILENAME,
    )
    loaded = {
        name: shared._load_artifact(root / name, role=f"merged {name}")[1]
        for name in names
    }
    if any(
        not isinstance(value, list) or len(value) != len(cases)
        for value in loaded.values()
    ):
        shared._fail("invalid_module_selector_aggregate_count", "all artifacts need all cases")
    finals = shared._load_artifact(predictions_path, role="merged predictions")[1]
    if not isinstance(finals, list) or len(finals) != len(cases):
        shared._fail("invalid_module_selector_prediction_count", "predictions need all cases")
    decisions: Counter[str] = Counter()
    anchor_classes: Counter[str] = Counter()
    representative_counts: Counter[int] = Counter()
    representative_modules: Counter[str] = Counter()
    candidate_classes: Counter[str] = Counter()
    pairwise_winners: Counter[str] = Counter()
    positive_counts: Counter[int] = Counter()
    for index, case in enumerate(cases):
        location = f"module_selector_merged[{index}]"
        anchor = loaded[ANCHOR_PREDICTIONS_FILENAME][index]
        ledger = loaded[ANCHOR_LEDGER_AGGREGATE_FILENAME][index]
        checkpoint = loaded[ANCHOR_CHECKPOINT_AGGREGATE_FILENAME][index]
        local_record_set = loaded[STEP_LOCAL_RECORDS_FILENAME][index]
        matrix = loaded[LOCAL_MATRICES_FILENAME][index]
        semantic_assessment = loaded[PAIRWISE_ASSESSMENTS_FILENAME][index]
        selector = loaded[MODULE_SELECTORS_FILENAME][index]
        shared._validate_prediction_record(anchor, case=case, location=f"{location}.anchor")
        if (
            ledger.get("trajectory_id") != case.trajectory_id
            or ledger.get("selected_step") != anchor["predicted_step"]
            or checkpoint.get("trajectory_id") != case.trajectory_id
            or checkpoint.get("predicted_step") != anchor["predicted_step"]
        ):
            shared._fail("module_selector_anchor_sidecar_mismatch", location)
        _validate_local_matrix_record(
            matrix, case=case, location=f"{location}.local_matrix"
        )
        _validate_local_record_set(
            local_record_set,
            case=case,
            matrix=matrix,
            location=f"{location}.local_records",
        )
        _validate_pairwise_assessment_record(
            semantic_assessment,
            expected_rows=_expected_module_rows(matrix),
            location=f"{location}.semantic_assessment",
        )
        _validate_module_selector_record(
            selector,
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            matrix=matrix,
            location=f"{location}.selector",
        )
        expected_selector = build_module_selector_document(
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            matrix=matrix,
            semantic_assessment=semantic_assessment,
        )
        if selector != expected_selector:
            shared._fail("non_deterministic_module_selector_assembly", location)
        final = shared._validate_prediction_record(
            finals[index], case=case, location=f"{location}.final"
        )
        if final != selector["selected_prediction"]:
            shared._fail("module_selector_final_copy_mismatch", location)
        decisions[selector["decision"]] += 1
        anchor_classes[selector["anchor_classification"]] += 1
        representative_counts[len(selector["representatives"])] += 1
        for representative in selector["representatives"]:
            representative_modules[representative["module"]] += 1
        for assessment in selector["candidate_assessments"]:
            candidate_classes[assessment["classification"]] += 1
            pairwise_winners[assessment["winner"]] += 1
        positive_counts[matrix["positive_row_count"]] += 1
    return {
        "required": True,
        "valid": True,
        "step_isolated_local_evidence": True,
        "local_step_coverage_complete": True,
        "deterministic_earliest_positive_per_module_reservoir": True,
        "validator_enforced_pairwise_observed_continuation": True,
        "deterministic_pairwise_reducer": True,
        "semantic_only_model_output": True,
        "deterministic_identity_hash_prediction_assembly": True,
        "maximum_module_representatives": len(MODULES),
        "default_anchor_policy": True,
        "all_selected_predictions_exact_copies": True,
        "selector_decision_counts": dict(sorted(decisions.items())),
        "anchor_classification_counts": dict(sorted(anchor_classes.items())),
        "representative_count_distribution": {
            str(key): value for key, value in sorted(representative_counts.items())
        },
        "representative_module_counts": dict(
            sorted(representative_modules.items())
        ),
        "candidate_classification_counts": dict(sorted(candidate_classes.items())),
        "pairwise_winner_counts": dict(sorted(pairwise_winners.items())),
        "local_positive_count_distribution": {
            str(key): value for key, value in sorted(positive_counts.items())
        },
        "packet_state_closure": parent._validate_packet_state_ledgers(
            root / ANCHOR_LEDGER_AGGREGATE_FILENAME
        ),
    }


def validate_agent_judge_luna_gaia_v3_59_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    mechanism = _validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_59_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_59_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_59_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_59_REASONING_EFFORT,
        "selection_policy": "clean_v3_20_step_isolated_pairwise_observed_continuation_semantic_only_deterministic_assembly",
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": (
            "one clean-v3.20 step-isolated observed-continuation pairwise "
            "mechanism whose immutable bindings and reducer output are "
            "deterministically assembled from semantic-only assessments"
        ),
        "anchor_semantics_unchanged_from_v3_20": True,
        "all_selected_predictions_exact_copies": True,
        "step_isolated_module_reservoir_pairwise_reducer": mechanism,
    }


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_step_local_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_step_local(*paths[:-1]), paths[-1])


def validate_and_write_local_matrix_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_local_matrix(*paths[:-1]), paths[-1])


def validate_and_write_module_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_module_selector(*paths[:-1]), paths[-1])


def validate_and_write_pairwise_assessment_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_pairwise_assessment(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_59_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_59_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_luna_gaia_v3_59_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_pairwise_assessment_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / LOCAL_MATRIX_FILENAME,
        prediction.parent / PAIRWISE_ASSESSMENT_FILENAME,
    )


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "local" and len(paths) == 3:
            audit = validate_and_write_step_local_audit(*paths)
        elif stage == "matrix" and len(paths) == 4:
            audit = validate_and_write_local_matrix_audit(*paths)
        elif stage == "pairwise-assessment" and len(paths) == 8:
            audit = validate_and_write_pairwise_assessment_audit(*paths)
        elif stage == "module-selector" and len(paths) == 8:
            audit = validate_and_write_module_selector_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_59_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except (shared.AgentJudgeValidationError, json.JSONDecodeError, OSError) as error:
        code = getattr(error, "code", type(error).__name__)
        print(json.dumps({"ok": False, "code": code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument(
        "stage",
        choices=(
            "anchor",
            "local",
            "matrix",
            "pairwise-assessment",
            "module-selector",
            "prediction",
        ),
    )
    parser.add_argument("paths", nargs="+")
    args = parser.parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

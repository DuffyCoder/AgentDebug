"""GAIA strict-v8 with distribution-safe JSON-interface normalization."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge_gaia_official_repo_gpt41_strict_v8 import (
    MODEL,
    REASONING_EFFORT,
    TEMPERATURE,
    validate_predictions as _validate_strict_v8_predictions,
)


VERSION = "agentdebug.llm-judge.gaia-official-repo-gpt4.1-strict-v8.1"


def build_protocol_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    return f"""Frozen strict-v8.1 GAIA diagnostic judge.

Protocol: {VERSION}
Model: {MODEL}
Expected provider-resolved model: gpt-4.1-2025-04-14
Temperature: {TEMPERATURE}
Prediction manifest: {Path(prediction_manifest_path).expanduser().resolve()}
Cohort manifest: {Path(cohort_manifest_path).expanduser().resolve()}
Predictions: {Path(predictions_path).expanduser().resolve()}

The semantic topology, candidate construction, assessor, selector, module, and
type policies are frozen strict-v8.  Version 8.1 adds only uniform JSON-interface
hardening: unknown response fields are discarded before strict validation,
incomplete alternate-owner pairs are normalized to null, single-role owner
metadata is mechanically derived, and repair never replays the rejected response.
No historical prediction or gold label is visible during inference.
"""


def validate_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    base = _validate_strict_v8_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    return {
        **base,
        "agent_judge_version": VERSION,
        "interface_hardening": "strict-v8.1-uniform-json-normalization",
        "unknown_response_fields_discarded_before_validation": True,
        "incomplete_alternate_owner_pairs_normalized_to_null": True,
        "single_role_owner_metadata_parent_derived": True,
        "repair_replays_rejected_response": False,
        "semantic_topology_unchanged_from_strict_v8": True,
    }


build_task = build_protocol_task

"""Luna GAIA v3.23: mandatory state scan before anchor veto."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger as bidirectional
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as anchor_parent
from . import agent_judge_luna_gaia_v3_22_isolated_bidirectional_state_challenger as parent
from .agent_judge_luna_gaia_v3_4 import STEP_CANDIDATE_LEDGER_FILENAME


AGENT_JUDGE_LUNA_GAIA_V3_23_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.23-mandatory-state-scan-before-veto"
)
AGENT_JUDGE_LUNA_GAIA_V3_23_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_22_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_23_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_22_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_23_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_22_AUDIT_SCHEMA_VERSION
)

AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_23_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_23_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_23_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_23_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = parent.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = parent.CHALLENGERS_FILENAME
ARBITER_FILENAME = parent.ARBITER_FILENAME
ARBITERS_FILENAME = parent.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = parent.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = parent.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
CHALLENGER_FIELDS = parent.CHALLENGER_FIELDS
ARBITER_FIELDS = parent.ARBITER_FIELDS


_SCAN_PREFIX = re.compile(
    r"^state_scan_steps=(none|[1-9]\d*(?:,[1-9]\d*)*); "
    r"state_candidate_kind=(none|necessary_fact|entity_relation|outcome_claim); "
    r"state_candidate_relation=(not_applicable|omitted|unsupported|contradicted); "
    r"state_candidate_step=(none|[1-9]\d*); "
    r"state_direction=(none|earlier|same|later); "
)
_CANDIDATE_PAIRS = {
    "necessary_fact": "omitted",
    "entity_relation": "unsupported",
    "outcome_claim": "contradicted",
}

_MANDATORY_SCAN_RULES = """\
MANDATORY STATE SCAN BEFORE VETO — ONE STATE CANDIDATE, ONE PROPOSAL MAXIMUM

The frozen packet-state prediction is the incumbent anchor. Do not change,
repair, or re-run it. Your state scan is independent of the anchor ledger.

PHASE 1 — ENUMERATE AND SCAN BEFORE CLASSIFYING THE ANCHOR

List every Step containing a Memory or Reflection span, in exact chronological
order. You MUST inspect every listed Step against its adjacent feedback before
deciding whether the anchor is critical. Do not stop when the anchor looks
plausible. Freeze at most one state candidate: the EARLIEST Step passing one of
the closed pairs below, or explicit none.

Begin search_summary exactly:

`state_scan_steps=<exact comma-separated state Steps or none>; state_candidate_kind=<none|necessary_fact|entity_relation|outcome_claim>; state_candidate_relation=<not_applicable|omitted|unsupported|contradicted>; state_candidate_step=<none|Step>; state_direction=<none|earlier|same|later>; `

Candidate pairs:

1. `necessary_fact/omitted`: adjacent feedback contains a concrete title,
   value, constraint, source fact, provenance link, or discriminating result
   necessary for the unresolved subgoal or next decision, while the Step's
   Memory/Reflection loses or materially distorts it.
2. `entity_relation/unsupported`: Memory/Reflection asserts a concrete task-
   answer entity/value/credential/relation unsupported by visible evidence and
   the later plan consumes that exact assertion.
3. `outcome_claim/contradicted`: Memory/Reflection claims success, failure,
   progress, or a constraint that literal adjacent feedback contradicts.

Use `none/not_applicable/none/none` only after every enumerated Step is clear.
Harmless compression, details still available to the next decision, wording
polish, non-consumed speculation, and locally false but causally irrelevant
text are clear. An explicitly provisional explanation of irrelevant retrieval
is a query hypothesis, not an unsupported answer relation.

PHASE 2 — COMPARE THE FROZEN STATE CANDIDATE WITH THE ANCHOR

- If candidate Step equals anchor, no_challenge: the anchor already owns it.
- If candidate is earlier, challenge only when repairing that state can change
  the later path and repairing only the anchor leaves the earlier state defect.
  Classify the anchor downstream_symptom.
- If candidate is later, challenge only when the anchor is a reasonable probe
  or noncritical predecessor and the candidate remains independently failure-
  causing after anchor-only repair.
- If the candidate loses this comparison, emit no_challenge but KEEP its typed
  kind, relation, Step, and direction in the search_summary certificate.
- If no state candidate exists, emit no_challenge with the none certificate.

A challenge proposal must exactly use the frozen state_candidate_step, be owned
by Memory or Reflection, quote literal evidence, feed the current/next plan,
and be the only proposal. direct_timeline_comparison must compare the anchor,
the candidate, and every intervening plausible state boundary. The independent
arbiter still defaults to the anchor.

This is not a general candidate scan. Planning, Action, System, mechanical-
parameter, acquisition-capability, repeated-strategy, source, and terminal-
answer errors cannot be proposed unless the proposal independently owns one of
the three qualifying Memory/Reflection state claims.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_22_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_23_VERSION,
        )
        .replace(
            bidirectional.AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_23_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_22_isolated_bidirectional_state_challenger",
            "agent_judge_luna_gaia_v3_23_mandatory_state_scan_before_veto",
        )
        .replace(
            "agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger",
            "agent_judge_luna_gaia_v3_23_mandatory_state_scan_before_veto",
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_22_isolated_bidirectional_state_challenger.py",
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_23_mandatory_state_scan_before_veto.py",
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger.py",
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_23_mandatory_state_scan_before_veto.py",
        )
    )


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_anchor_task(*paths))


def build_challenger_task(*paths: str | Path) -> str:
    task = parent.build_challenger_task(*paths)
    task = task.replace(parent._STATE_CHALLENGER_RULES, _MANDATORY_SCAN_RULES)
    task = task.replace(
        '"search_summary": "state_claim_kind=...; state_relation=...; state_direction=...; literal scan summary"',
        '"search_summary": "state_scan_steps=...; state_candidate_kind=...; state_candidate_relation=...; state_candidate_step=...; state_direction=...; literal scan and comparison summary"',
    )
    return _rewrite_identity(task)


def _state_steps(case: Any) -> list[int]:
    return [
        step.step
        for step in case.judge_view.steps
        if any(span.module in {"memory", "reflection"} for span in step.module_spans)
    ]


def _validate_scan_records(path: str | Path, cases: Sequence[Any]) -> dict[str, Any]:
    challenger_path, raw = shared._load_artifact(path, role="mandatory state scan")
    records = raw if isinstance(raw, list) else [raw]
    if len(records) != len(cases) or any(not isinstance(item, dict) for item in records):
        shared._fail("invalid_state_scan_record_count", "case/record count differs")

    pair_counts: Counter[str] = Counter()
    direction_counts: Counter[str] = Counter()
    candidate_count = 0
    challenge_count = 0
    for index, (record, case) in enumerate(zip(records, cases, strict=True)):
        location = f"state_scan[{index}]"
        match = _SCAN_PREFIX.match(str(record.get("search_summary") or ""))
        if match is None:
            shared._fail("missing_mandatory_state_scan_prefix", location)
        scan_text, kind, relation, candidate_text, direction = match.groups()
        expected_steps = _state_steps(case)
        parsed_steps = [] if scan_text == "none" else [int(x) for x in scan_text.split(",")]
        if parsed_steps != expected_steps:
            shared._fail("state_scan_step_list_mismatch", location)

        candidate_step = None if candidate_text == "none" else int(candidate_text)
        if candidate_step is None:
            if (kind, relation, direction) != ("none", "not_applicable", "none"):
                shared._fail("invalid_empty_state_candidate", location)
        else:
            if kind not in _CANDIDATE_PAIRS or relation != _CANDIDATE_PAIRS[kind]:
                shared._fail("invalid_typed_state_candidate", location)
            if candidate_step not in expected_steps:
                shared._fail("state_candidate_not_state_step", location)
            anchor_step = record.get("anchor_step")
            expected_direction = (
                "earlier"
                if candidate_step < anchor_step
                else "later"
                if candidate_step > anchor_step
                else "same"
            )
            if direction != expected_direction:
                shared._fail("state_candidate_direction_mismatch", location)
            candidate_count += 1

        status = record.get("challenge_status")
        proposal = record.get("proposed_prediction")
        if status == "challenge":
            if candidate_step is None or direction not in {"earlier", "later"}:
                shared._fail("challenge_requires_distinct_state_candidate", location)
            if (
                not isinstance(proposal, dict)
                or proposal.get("predicted_step") != candidate_step
                or proposal.get("predicted_module") not in {"memory", "reflection"}
            ):
                shared._fail("proposal_differs_from_state_candidate", location)
            challenge_count += 1
        elif status != "no_challenge":
            shared._fail("invalid_state_scan_challenge_status", location)

        pair_counts[f"{kind}:{relation}"] += 1
        direction_counts[direction] += 1
    return {
        "required": True,
        "valid": True,
        "path": str(challenger_path),
        "record_count": len(records),
        "exact_state_step_enumeration": True,
        "state_candidate_count": candidate_count,
        "challenge_count": challenge_count,
        "candidate_pair_counts": dict(sorted(pair_counts.items())),
        "direction_counts": dict(sorted(direction_counts.items())),
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    audit = anchor_parent.validate_anchor_predictions(*paths)
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_23_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_23_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_23_REASONING_EFFORT,
        "anchor_semantics": "v3.20_packet_state_closure",
    }


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    audit = bidirectional.validate_challenger(*paths)
    _, _, case = shared._single_case_paths(paths[0], paths[1])
    scan = _validate_scan_records(paths[5], [case])
    return {
        **audit,
        "schema_version": "agentdebug.mandatory-state-scan-challenger-audit.v1",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_23_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_23_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_23_REASONING_EFFORT,
        "mandatory_state_scan_before_veto": scan,
    }


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    audit = bidirectional.validate_arbiter(*paths)
    _, _, case = shared._single_case_paths(paths[0], paths[1])
    scan = _validate_scan_records(paths[5], [case])
    return {
        **audit,
        "schema_version": "agentdebug.mandatory-state-scan-arbiter-audit.v1",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_23_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_23_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_23_REASONING_EFFORT,
        "mandatory_state_scan_before_veto": scan,
    }


def build_arbiter_task(*paths: str | Path) -> str:
    validate_challenger(*paths[:6])
    task = bidirectional.build_arbiter_task(*paths)
    task = task.replace(bidirectional._BOUNDED_BIDIRECTIONAL_RULES, _MANDATORY_SCAN_RULES)
    return _rewrite_identity(task)


def build_agent_judge_luna_gaia_v3_23_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / STEP_CANDIDATE_LEDGER_FILENAME,
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def validate_agent_judge_luna_gaia_v3_23_predictions(*paths: str | Path) -> dict[str, Any]:
    audit = bidirectional.validate_agent_judge_luna_gaia_v3_16_predictions(*paths)
    _, _, cases = shared._load_cases(paths[0], paths[1])
    predictions = Path(paths[2]).expanduser().resolve()
    packet_state = anchor_parent._validate_packet_state_ledgers(
        predictions.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME
    )
    scan = _validate_scan_records(predictions.parent / CHALLENGERS_FILENAME, cases)
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_23_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_23_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_23_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_23_REASONING_EFFORT,
        "selection_policy": (
            "v3_20_packet_state_anchor_mandatory_state_scan_before_veto_"
            "one_bidirectional_challenger_default_keep_exact_copy_arbiter"
        ),
        "anchor_semantics_unchanged_from_v3_20": True,
        "packet_state_closure": packet_state,
        "mandatory_state_scan_before_veto": scan,
    }


def _write_audit(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_23_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        validate_agent_judge_luna_gaia_v3_23_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_23_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_23_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_23_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_23_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

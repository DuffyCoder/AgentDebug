"""Four-stage schema-separated GPT-4.1 GAIA evidence-atom judge.

Atom-v13-backtrace keeps atom-v12's owner-neutral locator catalog, then
derives a bounded predecessor pool in trusted parent code.  A fresh
backtrace response freezes the earliest sufficient local root before the
ownership and taxonomy stages run.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Mapping, Sequence

from agentdebug.benchmark.prediction_manifest import stable_sha256

from . import agent_judge_gaia_official_repo_gpt41_atom_v11 as v11
from . import agent_judge_gaia_official_repo_gpt41_atom_v12 as v12
from .agent_judge import AgentJudgeValidationError


VERSION = "agentdebug.llm-judge.gaia-official-repo-gpt4.1-atom-v13-backtrace"
MODEL = v12.MODEL
RESOLVED_MODEL = v12.RESOLVED_MODEL
TEMPERATURE = v12.TEMPERATURE
REASONING_EFFORT = v12.REASONING_EFFORT
AUDIT_SCHEMA_VERSION = "agentdebug.gpt41-gaia-atom-v13-backtrace-audit.v1"
CATALOG_SCHEMA_VERSION = v12.CATALOG_SCHEMA_VERSION

BACKTRACE_RADIUS = 4
BACKTRACE_POOL_ALGORITHM = (
    "selected-relation-radius4-recurrence-member-union-v1"
)
BACKTRACE_POOL_SCHEMA_VERSION = (
    "agentdebug.gpt41-gaia-atom-v13-backtrace-pool.v1"
)
BACKTRACE_CONTEXT_MAX_ITEMS = 12

LOCATOR_DECISION_FILENAME = "locator-decision.json"
BACKTRACE_DECISION_FILENAME = "backtrace-decision.json"
MODULE_DECISION_FILENAME = v12.MODULE_DECISION_FILENAME
TYPE_DECISION_FILENAME = v12.TYPE_DECISION_FILENAME

# Locator is byte-identical to atom-v12 boundary by design.
LOCATOR_SYSTEM_PROMPT = v12.BOUNDARY_SYSTEM_PROMPT
BACKTRACE_SYSTEM_PROMPT = (
    "You are the backtrace stage of a causal diagnostic judge. A parent-derived "
    "bounded step-card pool is frozen. Review every card and select the earliest "
    "locally sufficient root or predecessor from the supplied pool. Return one "
    "JSON object containing only the explicitly allowed fields."
)
MODULE_SYSTEM_PROMPT = v12.MODULE_SYSTEM_PROMPT
TYPE_SYSTEM_PROMPT = v12.TYPE_SYSTEM_PROMPT

_BACKTRACE_FIELDS = frozenset(
    {
        "reviews",
        "selected_card_id",
        "selected_local_atom_id",
        "defect_predicate",
        "counterfactual_correction",
        "selection_reason",
        "rejected_alternative",
    }
)
_CARD_REVIEW_FIELDS = frozenset(
    {
        "card_id",
        "agent_owned_material_defect",
        "counterfactual_redirects_failure",
        "boundary_status",
        "analysis",
    }
)
_MATERIAL_VALUES = frozenset({"yes", "no", "unclear"})
_CAUSAL_ROLES = frozenset(
    {"root_or_predecessor", "uncertain", "downstream_symptom"}
)
_STAGE_FIELDS: dict[str, tuple[str, ...]] = {
    "locator": tuple(sorted(v11._BOUNDARY_FIELDS)),
    "backtrace": tuple(sorted(_BACKTRACE_FIELDS)),
    "module": tuple(sorted(v11._MODULE_FIELDS)),
    "type": tuple(sorted(v11._TYPE_FIELDS)),
}
_STAGE_EXAMPLES: dict[str, dict[str, Any]] = {
    "locator": dict(v12._STAGE_EXAMPLES["boundary"]),
    "backtrace": {
        "reviews": [
            {
                "card_id": "COPY_EACH_LEGAL_SC_ID_EXACTLY_ONCE",
                "agent_owned_material_defect": "REPLACE_WITH_yes_no_OR_unclear",
                "counterfactual_redirects_failure": "REPLACE_WITH_yes_no_OR_unclear",
                "boundary_status": "REPLACE_WITH_root_or_predecessor_downstream_symptom_OR_uncertain",
                "analysis": "WRITE_ONE_CARD_SPECIFIC_CAUSAL_TEST",
            }
        ],
        "selected_card_id": "COPY_THE_EARLIEST_SUFFICIENT_SC_ID",
        "selected_local_atom_id": "COPY_ONE_LA_ID_FROM_THE_SELECTED_CARD",
        "defect_predicate": "WRITE_ONE_FALSIFIABLE_LOCAL_DEFECT",
        "counterfactual_correction": "WRITE_THE_SMALLEST_LOCAL_CORRECTION",
        "selection_reason": "WRITE_WHY_THIS_IS_THE_EARLIEST_SUFFICIENT_ROOT",
        "rejected_alternative": "WRITE_WHY_A_LATER_SYMPTOM_IS_NOT_ROOT",
    },
    "module": dict(v12._STAGE_EXAMPLES["module"]),
    "type": dict(v12._STAGE_EXAMPLES["type"]),
}
_STEP_CARD_RE = re.compile(r"SC-[0-9]{4}")
_REPAIR_ERROR_GUIDANCE: dict[str, str] = {
    "invalid_stage_fields": "Return exactly the allowed fields and no others.",
    "invalid_stage_text": "Fill every required explanation with non-empty decision text.",
    "unreplaced_prompt_placeholder": "Replace every example placeholder with a real decision.",
    "duplicatebacktracejsonkeyerror": "Return one object with no duplicate JSON keys.",
    "duplicatejsonkeyerror": "Return one object with no duplicate JSON keys.",
    "jsondecodeerror": "Return one syntactically valid JSON object.",
    "valueerror": "Return one syntactically valid JSON object.",
    "unknown_backtrace_identity": "Select only a supplied card and a local atom from that card.",
    "invalid_owner_atom": "Select only a supplied legal owner atom.",
    "invalid_type_option": "Select only a supplied legal type ID.",
    "non_exhaustive_backtrace_reviews": "Review every supplied card exactly once.",
    "duplicate_backtrace_review": "Review every supplied card exactly once.",
    "invalid_backtrace_review_status": "Use only the supplied tri-state review values.",
    "invalid_backtrace_review_role": "Use only the supplied boundary-status values.",
    "inconsistent_backtrace_review": "Use root_or_predecessor exactly with yes/yes.",
    "selected_backtrace_not_root": "The selected card review must be yes/yes/root_or_predecessor.",
    "later_backtrace_root_selected": "Select the earliest reviewed root_or_predecessor card.",
}

_BACKTRACE_AUDIT_FIELDS = frozenset(
    {
        "schema_version",
        "stage",
        "protocol",
        "catalog_sha256",
        "locator_defect_freeze_sha256",
        "pool_sha256",
        "backtrace_pool",
        "reviews",
        "selected_card_id",
        "selected_local_atom_id",
        "selected_step",
        "derived_locus",
        "derived_evidence_scope",
        "derived_evidence_quote",
        "compatible_owner_atom_ids",
        "defect_predicate",
        "counterfactual_correction",
        "selection_reason",
        "rejected_alternative",
        "defect_freeze_sha256",
        "semantic_identity",
        "model_reported_step_or_quote",
        "parent_derived_backtrace_pool",
        "locator_audit_frozen_before_pool_derivation",
    }
)
_MODULE_AUDIT_FIELDS = frozenset(
    set(v11._MODULE_AUDIT_FIELDS)
    | {"locator_defect_freeze_sha256", "pool_sha256"}
)
_TYPE_AUDIT_FIELDS = frozenset(
    set(v11._TYPE_AUDIT_FIELDS)
    | {"locator_defect_freeze_sha256", "pool_sha256"}
)


def _fail(code: str, message: str) -> None:
    raise AgentJudgeValidationError(code, message)


def _required_text(value: Any, location: str) -> str:
    return v11._required_text(value, location)


def _exact_fields(
    value: Any, expected: frozenset[str], location: str
) -> Mapping[str, Any]:
    return v11._exact_fields(value, expected, location)


def _reject_placeholders(value: Any, *, location: str) -> None:
    """Reject copied examples recursively, including nested card reviews."""

    if isinstance(value, Mapping):
        for key, child in value.items():
            _reject_placeholders(child, location=f"{location}.{key}")
    elif isinstance(value, (list, tuple)):
        for index, child in enumerate(value):
            _reject_placeholders(child, location=f"{location}[{index}]")
    elif isinstance(value, str) and value.strip().casefold().startswith(
        ("copy_", "write_", "replace_")
    ):
        _fail(
            "unreplaced_prompt_placeholder",
            f"{location} copied a shape-example placeholder",
        )


def _assert_schema_separated_task(
    task: Mapping[str, Any], *, stage_name: str
) -> None:
    if not isinstance(task, Mapping) or set(task) != {
        "system_prompt",
        "user_prompt",
    }:
        _fail("invalid_stage_task", f"{stage_name} task envelope is invalid")
    for field in ("system_prompt", "user_prompt"):
        if not isinstance(task[field], str) or not task[field].strip():
            _fail("invalid_stage_task", f"{stage_name} {field} is empty")
    expected_prompt = {
        "locator": LOCATOR_SYSTEM_PROMPT,
        "backtrace": BACKTRACE_SYSTEM_PROMPT,
        "module": MODULE_SYSTEM_PROMPT,
        "type": TYPE_SYSTEM_PROMPT,
    }.get(stage_name.removesuffix(" repair"))
    if expected_prompt is None or task["system_prompt"] != expected_prompt:
        _fail("invalid_stage_task", f"{stage_name} system prompt changed")
    prompt = str(task["user_prompt"])
    forbidden = (
        '"$schema"',
        '"properties"',
        '"required"',
        '"additionalProperties"',
        '"type":',
        "draft/2020-12/schema",
    )
    if any(marker in prompt for marker in forbidden):
        _fail(
            "schema_exposed_to_model",
            f"{stage_name} model task contains JSON Schema metadata",
        )


def _exact_example(stage_name: str) -> str:
    return json.dumps(_STAGE_EXAMPLES[stage_name], ensure_ascii=False, indent=2)


def _field_instruction(stage_name: str) -> str:
    fields = ", ".join(_STAGE_FIELDS[stage_name])
    return (
        f"Allowed top-level fields, exactly once each and no others: {fields}.\n"
        "The object below is a shape example. Replace every placeholder with "
        "supplied legal IDs or your own decision text. Do not output a schema or "
        "schema metadata.\n"
        f"{_exact_example(stage_name)}"
    )


def build_atom_v13_backtrace_catalog(case: Any) -> dict[str, Any]:
    return v12.build_atom_v12_catalog(case)


def locator_output_schema() -> dict[str, Any]:
    return v12.boundary_output_schema()


def backtrace_output_schema() -> dict[str, Any]:
    review = {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_CARD_REVIEW_FIELDS),
        "properties": {
            "card_id": {"type": "string", "pattern": r"^SC-[0-9]{4}$"},
            "agent_owned_material_defect": {"enum": sorted(_MATERIAL_VALUES)},
            "counterfactual_redirects_failure": {
                "enum": sorted(_MATERIAL_VALUES)
            },
            "boundary_status": {"enum": sorted(_CAUSAL_ROLES)},
            "analysis": {"type": "string", "minLength": 1},
        },
    }
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_BACKTRACE_FIELDS),
        "properties": {
            "reviews": {"type": "array", "minItems": 1, "items": review},
            "selected_card_id": {
                "type": "string",
                "pattern": r"^SC-[0-9]{4}$",
            },
            "selected_local_atom_id": {
                "type": "string",
                "pattern": r"^LA-[0-9]{4}$",
            },
            **{
                field: {"type": "string", "minLength": 1}
                for field in (
                    "defect_predicate",
                    "counterfactual_correction",
                    "selection_reason",
                    "rejected_alternative",
                )
            },
        },
    }


def module_output_schema() -> dict[str, Any]:
    return v12.module_output_schema()


def type_output_schema() -> dict[str, Any]:
    return v12.type_output_schema()


def build_locator_task(case: Any, catalog: Mapping[str, Any]) -> dict[str, str]:
    """Return the atom-v12 boundary task byte-for-byte."""

    value = v12.build_boundary_task(case, catalog)
    if value["system_prompt"] != LOCATOR_SYSTEM_PROMPT:
        _fail("locator_prompt_drift", "locator system prompt differs from atom-v12")
    return value


def _from_v12_locator(audit: Mapping[str, Any]) -> dict[str, Any]:
    if (
        not isinstance(audit, Mapping)
        or set(audit) != v11._BOUNDARY_AUDIT_FIELDS
        or audit.get("protocol") != v12.VERSION
        or audit.get("schema_version") != v12.AUDIT_SCHEMA_VERSION
        or audit.get("stage") != "boundary"
    ):
        _fail("invalid_v12_locator_base", "atom-v12 locator audit is invalid")
    value = dict(audit)
    value.update(
        {"protocol": VERSION, "schema_version": AUDIT_SCHEMA_VERSION, "stage": "locator"}
    )
    return value


def _to_v11_locator(audit: Mapping[str, Any]) -> dict[str, Any]:
    if (
        not isinstance(audit, Mapping)
        or set(audit) != v11._BOUNDARY_AUDIT_FIELDS
        or audit.get("protocol") != VERSION
        or audit.get("schema_version") != AUDIT_SCHEMA_VERSION
        or audit.get("stage") != "locator"
    ):
        _fail("invalid_locator_audit", "locator audit lineage is invalid")
    value = dict(audit)
    value.update(
        {"protocol": v11.VERSION, "schema_version": v11.AUDIT_SCHEMA_VERSION, "stage": "boundary"}
    )
    return value


def _check_locator_audit(
    catalog: Mapping[str, Any], locator_audit: Mapping[str, Any]
) -> None:
    v11._check_catalog(catalog)
    v11._check_boundary_audit(catalog, _to_v11_locator(locator_audit))


def validate_locator_decision(
    case: Any,
    catalog: Mapping[str, Any],
    raw: Any,
    *,
    expected_semantic_identity: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    _reject_placeholders(raw, location="locator")
    return _from_v12_locator(
        v12.validate_boundary_decision(
            case,
            catalog,
            raw,
            expected_semantic_identity=expected_semantic_identity,
        )
    )


def extract_locator_semantic_identity(
    raw: Any, catalog: Mapping[str, Any] | None = None
) -> dict[str, str] | None:
    return v12.extract_boundary_semantic_identity(raw, catalog)


def _pool_body(
    catalog: Mapping[str, Any], locator_audit: Mapping[str, Any]
) -> dict[str, Any]:
    _check_locator_audit(catalog, locator_audit)
    atoms = v11._by_id(catalog, "local_atoms", "local_atom_id")
    relations = v11._by_id(catalog, "boundary_relations", "relation_id")
    selected_relation = relations[str(locator_audit["selected_relation_id"])]
    locator_step = int(locator_audit["selected_step"])

    selected_member_steps = {
        int(atoms[atom_id]["step"])
        for atom_id in selected_relation["member_local_atom_ids"]
        if atoms[atom_id]["selectable"] is True
    }
    radius_steps = set(range(max(1, locator_step - BACKTRACE_RADIUS), locator_step + 1))
    recurrence_member_steps = {
        int(atoms[atom_id]["step"])
        for relation in catalog["boundary_relations"]
        if relation["relation_kind"] == "deterministic_recurrence_episode"
        for atom_id in relation["member_local_atom_ids"]
        if atoms[atom_id]["selectable"] is True
    }
    included_steps = sorted(
        selected_member_steps | radius_steps | recurrence_member_steps
    )
    selected_reference_ids = set(selected_relation["reference_local_atom_ids"])
    recurrence_references_by_step: dict[int, set[str]] = {}
    for relation in catalog["boundary_relations"]:
        if relation["relation_kind"] != "deterministic_recurrence_episode":
            continue
        member_steps = {
            int(atoms[atom_id]["step"])
            for atom_id in relation["member_local_atom_ids"]
            if atoms[atom_id]["selectable"] is True
        }
        for step in member_steps:
            recurrence_references_by_step.setdefault(step, set()).update(
                str(item) for item in relation["reference_local_atom_ids"]
            )
    cards: list[dict[str, Any]] = []
    for step in included_steps:
        step_atoms = [
            {
                "local_atom_id": str(atom["local_atom_id"]),
                "evidence_quote": str(atom["quote"]),
            }
            for atom in catalog["local_atoms"]
            if int(atom["step"]) == step
            and atom["selectable"] is True
            and bool(atom["compatible_owner_atom_ids"])
        ]
        step_atoms.sort(key=lambda item: item["local_atom_id"])
        if step_atoms:
            explicit_reference_ids = set(recurrence_references_by_step.get(step, set()))
            if step in selected_member_steps:
                explicit_reference_ids.update(selected_reference_ids)
            prior_context_ids = {
                str(atom["local_atom_id"])
                for atom in catalog["local_atoms"]
                if int(atom["step"]) == step - 1
                and atom["selectable"] is False
                and str(atom["quote"]).strip()
            }
            context_ids = sorted(explicit_reference_ids) + sorted(
                prior_context_ids - explicit_reference_ids
            )
            deduplicated_context: dict[tuple[int, str], str] = {}
            for atom_id in context_ids:
                atom = atoms.get(atom_id)
                if atom is None or not str(atom["quote"]).strip():
                    continue
                deduplicated_context.setdefault(
                    (int(atom["step"]), str(atom["quote"])), atom_id
                )
            context_evidence = [
                {
                    "context_id": f"CX-{step:04d}-{index:02d}",
                    "sequence_position": context_key[0],
                    "evidence_quote": context_key[1],
                }
                for index, context_key in enumerate(
                    sorted(deduplicated_context)[:BACKTRACE_CONTEXT_MAX_ITEMS], 1
                )
            ]
            cards.append(
                {
                    "card_id": f"SC-{step:04d}",
                    "step": step,
                    "local_atoms": step_atoms,
                    "context_evidence": context_evidence,
                }
            )
    if not cards:
        _fail("empty_backtrace_pool", "backtrace pool has no selectable cards")
    selected_atom_id = str(locator_audit["selected_local_atom_id"])
    if not any(
        atom["local_atom_id"] == selected_atom_id
        for card in cards
        for atom in card["local_atoms"]
    ):
        _fail("locator_atom_missing_from_pool", "locator atom is absent from pool")
    return {
        "schema_version": BACKTRACE_POOL_SCHEMA_VERSION,
        "algorithm": BACKTRACE_POOL_ALGORITHM,
        "radius": BACKTRACE_RADIUS,
        "catalog_sha256": catalog["catalog_sha256"],
        "locator_defect_freeze_sha256": locator_audit["defect_freeze_sha256"],
        "locator_selected_step": locator_step,
        "candidate_step_cards": cards,
    }


def build_backtrace_pool(
    case: Any,
    catalog: Mapping[str, Any],
    locator_audit: Mapping[str, Any],
) -> dict[str, Any]:
    v11._check_case_catalog(case, catalog)
    body = _pool_body(catalog, locator_audit)
    return {**body, "pool_sha256": stable_sha256(body)}


def _check_pool(
    case: Any,
    catalog: Mapping[str, Any],
    locator_audit: Mapping[str, Any],
    pool: Mapping[str, Any],
) -> None:
    expected = build_backtrace_pool(case, catalog, locator_audit)
    if not isinstance(pool, Mapping) or dict(pool) != expected:
        _fail("invalid_backtrace_pool", "backtrace pool differs from parent rebuild")


def _public_backtrace_cards(case: Any, pool: Mapping[str, Any]) -> list[dict[str, Any]]:
    return [
        {
            "card_id": card["card_id"],
            "sequence_position": card["step"],
            "local_atoms": [
                {
                    "local_atom_id": atom["local_atom_id"],
                    "evidence_preview": v11._redact(
                        case,
                        atom["evidence_quote"],
                        limit=v11._FRAGMENT_MAX_CHARS + 256,
                    ),
                }
                for atom in card["local_atoms"]
            ],
            "prior_context": [
                {
                    "context_id": item["context_id"],
                    "sequence_position": item["sequence_position"],
                    "evidence_preview": v11._redact(
                        case,
                        item["evidence_quote"],
                        limit=v11._FRAGMENT_MAX_CHARS + 256,
                    ),
                }
                for item in card["context_evidence"]
            ],
        }
        for card in pool["candidate_step_cards"]
    ]


def build_backtrace_task(
    case: Any,
    catalog: Mapping[str, Any],
    locator_audit: Mapping[str, Any],
) -> dict[str, str]:
    pool = build_backtrace_pool(case, catalog, locator_audit)
    task = case.judge_view.task
    task_text = (task.user_request or task.display_text) if task is not None else ""
    value = {
        "system_prompt": BACKTRACE_SYSTEM_PROMPT,
        "user_prompt": (
            f"TASK\n{v11._redact(case, task_text, limit=max(4000, len(task_text) + 1))}\n\n"
            "OWNER-NEUTRAL BACKTRACE STEP CARDS\n"
            f"{json.dumps(_public_backtrace_cards(case, pool), ensure_ascii=False, indent=2)}\n\n"
            "Review every supplied card_id exactly once; review order does not "
            "matter. For each card apply both counterfactual tests, using unclear when "
            "the evidence does not resolve a test. Mark boundary_status "
            "root_or_predecessor only for yes/yes; otherwise use downstream_symptom or "
            "uncertain. Then select the earliest yes/yes/root_or_predecessor card and "
            "one local_atom_id from that selected card. Apply all five gates: (1) the "
            "defect must be agent behavior whose smallest correction redirects failure; "
            "(2) a tentative hypothesis followed by immediate verification is not yet a "
            "mature defect; (3) state omission is a root only when the omitted fact is in "
            "supplied prior evidence; (4) a schema-valid action followed by a bad provider "
            "result is not automatically a parameter defect; (5) a later summary, "
            "repetition, or symptom loses to the earliest sufficient emitter. Prior "
            "context is evidence only and is never selectable. Do not output a numeric "
            "step, relation, locator hypothesis, source label, module, owner, or error "
            "type.\n\n"
            + _field_instruction("backtrace")
        ),
    }
    _assert_schema_separated_task(value, stage_name="backtrace")
    return value


def extract_backtrace_semantic_identity(
    raw: Any,
    catalog: Mapping[str, Any] | None = None,
    locator_audit: Mapping[str, Any] | None = None,
) -> dict[str, str] | None:
    if not isinstance(raw, Mapping):
        return None
    card_id = raw.get("selected_card_id")
    atom_id = raw.get("selected_local_atom_id")
    if not isinstance(card_id, str) or _STEP_CARD_RE.fullmatch(card_id) is None:
        return None
    if not isinstance(atom_id, str) or v11._ID_PATTERNS["local"].fullmatch(atom_id) is None:
        return None
    identity = {"selected_card_id": card_id, "selected_local_atom_id": atom_id}
    if catalog is not None and locator_audit is not None:
        try:
            pool = _pool_body(catalog, locator_audit)
        except (AgentJudgeValidationError, KeyError, TypeError, ValueError):
            return None
        cards = {item["card_id"]: item for item in pool["candidate_step_cards"]}
        card = cards.get(card_id)
        if card is None or atom_id not in {
            item["local_atom_id"] for item in card["local_atoms"]
        }:
            return None
    return identity


def _canonical_reviews(
    raw_reviews: Any, cards: Mapping[str, Mapping[str, Any]]
) -> list[dict[str, Any]]:
    if not isinstance(raw_reviews, list):
        _fail("invalid_backtrace_reviews", "reviews must be an array")
    values: dict[str, dict[str, Any]] = {}
    for index, raw in enumerate(raw_reviews):
        review = _exact_fields(raw, _CARD_REVIEW_FIELDS, f"reviews[{index}]")
        card_id = review.get("card_id")
        if not isinstance(card_id, str) or _STEP_CARD_RE.fullmatch(card_id) is None:
            _fail("invalid_backtrace_review_card", "review card ID is not canonical")
        if card_id in values:
            _fail("duplicate_backtrace_review", "each card must be reviewed once")
        card = cards.get(card_id)
        if card is None:
            _fail("unknown_backtrace_review_card", "review card is outside the pool")
        material = review.get("agent_owned_material_defect")
        prevents = review.get("counterfactual_redirects_failure")
        role = review.get("boundary_status")
        if material not in _MATERIAL_VALUES or prevents not in _MATERIAL_VALUES:
            _fail("invalid_backtrace_review_status", "review tri-state status is invalid")
        if role not in _CAUSAL_ROLES:
            _fail("invalid_backtrace_review_role", "review causal role is invalid")
        if (role == "root_or_predecessor") != (
            (material, prevents) == ("yes", "yes")
        ):
            _fail(
                "inconsistent_backtrace_review",
                "yes/yes and root_or_predecessor must appear together",
            )
        values[card_id] = {
            "card_id": card_id,
            "agent_owned_material_defect": material,
            "counterfactual_redirects_failure": prevents,
            "boundary_status": role,
            "analysis": _required_text(
                review.get("analysis"), "analysis"
            ),
        }
    if set(values) != set(cards):
        _fail(
            "non_exhaustive_backtrace_reviews",
            "card reviews must cover every frozen card exactly once",
        )
    return [values[card_id] for card_id in sorted(values)]


def validate_backtrace_decision(
    case: Any,
    catalog: Mapping[str, Any],
    locator_audit: Mapping[str, Any],
    raw: Any,
    *,
    expected_semantic_identity: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    v11._check_case_catalog(case, catalog)
    _check_locator_audit(catalog, locator_audit)
    _reject_placeholders(raw, location="backtrace")
    value = _exact_fields(raw, _BACKTRACE_FIELDS, "backtrace decision")
    identity = extract_backtrace_semantic_identity(value, catalog, locator_audit)
    if identity is None:
        _fail("unknown_backtrace_identity", "selected card or local atom is outside the pool")
    if expected_semantic_identity is not None and dict(expected_semantic_identity) != identity:
        _fail("backtrace_semantic_resample", "repair changed a lockable card/atom identity")
    pool = build_backtrace_pool(case, catalog, locator_audit)
    cards = {item["card_id"]: item for item in pool["candidate_step_cards"]}
    reviews = _canonical_reviews(value["reviews"], cards)
    selected_review = next(
        item for item in reviews if item["card_id"] == identity["selected_card_id"]
    )
    if (
        selected_review["agent_owned_material_defect"],
        selected_review["counterfactual_redirects_failure"],
        selected_review["boundary_status"],
    ) != ("yes", "yes", "root_or_predecessor"):
        _fail("selected_backtrace_not_root", "selected review must be yes/yes/root_or_predecessor")
    qualifying = [
        cards[item["card_id"]]
        for item in reviews
        if (
            item["agent_owned_material_defect"],
            item["counterfactual_redirects_failure"],
            item["boundary_status"],
        ) == ("yes", "yes", "root_or_predecessor")
    ]
    earliest = min(qualifying, key=lambda item: (int(item["step"]), item["card_id"]))
    if identity["selected_card_id"] != earliest["card_id"]:
        _fail("later_backtrace_root_selected", "selected card is not the earliest sufficient reviewed root")
    selected_card = cards[identity["selected_card_id"]]
    atom = v11._by_id(catalog, "local_atoms", "local_atom_id")[identity["selected_local_atom_id"]]
    owner_ids = sorted(str(item) for item in atom["compatible_owner_atom_ids"])
    if not owner_ids:
        _fail("backtrace_atom_has_no_owner", "selected backtrace atom has no owner")
    freeze = {
        "locator_defect_freeze_sha256": locator_audit["defect_freeze_sha256"],
        "pool_sha256": pool["pool_sha256"],
        "selected_card_id": identity["selected_card_id"],
        "selected_local_atom_id": identity["selected_local_atom_id"],
        "selected_step": int(selected_card["step"]),
        "derived_locus": "backtrace_step_card_local_atom",
        "derived_evidence_scope": [
            item["local_atom_id"] for item in selected_card["local_atoms"]
        ],
        "derived_evidence_quote": atom["quote"],
        "defect_predicate": _required_text(value["defect_predicate"], "defect_predicate"),
        "counterfactual_correction": _required_text(
            value["counterfactual_correction"], "counterfactual_correction"
        ),
    }
    return {
        "schema_version": AUDIT_SCHEMA_VERSION,
        "stage": "backtrace",
        "protocol": VERSION,
        "catalog_sha256": catalog["catalog_sha256"],
        "locator_defect_freeze_sha256": locator_audit["defect_freeze_sha256"],
        "pool_sha256": pool["pool_sha256"],
        "backtrace_pool": pool,
        "reviews": reviews,
        **freeze,
        "compatible_owner_atom_ids": owner_ids,
        "selection_reason": _required_text(value["selection_reason"], "selection_reason"),
        "rejected_alternative": _required_text(
            value["rejected_alternative"], "rejected_alternative"
        ),
        "defect_freeze_sha256": stable_sha256(freeze),
        "semantic_identity": identity,
        "model_reported_step_or_quote": False,
        "parent_derived_backtrace_pool": True,
        "locator_audit_frozen_before_pool_derivation": True,
    }


def _expected_pool(
    catalog: Mapping[str, Any], locator_audit: Mapping[str, Any]
) -> dict[str, Any]:
    body = _pool_body(catalog, locator_audit)
    return {**body, "pool_sha256": stable_sha256(body)}


def _check_backtrace_audit_core(
    catalog: Mapping[str, Any],
    locator_audit: Mapping[str, Any],
    backtrace_audit: Mapping[str, Any],
) -> None:
    _check_locator_audit(catalog, locator_audit)
    if (
        not isinstance(backtrace_audit, Mapping)
        or set(backtrace_audit) != _BACKTRACE_AUDIT_FIELDS
        or backtrace_audit.get("schema_version") != AUDIT_SCHEMA_VERSION
        or backtrace_audit.get("stage") != "backtrace"
        or backtrace_audit.get("protocol") != VERSION
        or backtrace_audit.get("catalog_sha256") != catalog["catalog_sha256"]
        or backtrace_audit.get("locator_defect_freeze_sha256")
        != locator_audit["defect_freeze_sha256"]
        or backtrace_audit.get("model_reported_step_or_quote") is not False
        or backtrace_audit.get("parent_derived_backtrace_pool") is not True
        or backtrace_audit.get("locator_audit_frozen_before_pool_derivation")
        is not True
    ):
        _fail("invalid_backtrace_audit", "backtrace audit lineage is invalid")
    pool = _expected_pool(catalog, locator_audit)
    if (
        backtrace_audit.get("backtrace_pool") != pool
        or backtrace_audit.get("pool_sha256") != pool["pool_sha256"]
    ):
        _fail("invalid_backtrace_pool_binding", "backtrace pool/hash was tampered")
    cards = {item["card_id"]: item for item in pool["candidate_step_cards"]}
    reviews = _canonical_reviews(backtrace_audit.get("reviews"), cards)
    if reviews != backtrace_audit.get("reviews"):
        _fail("noncanonical_backtrace_reviews", "backtrace reviews are not canonical")
    identity = {
        "selected_card_id": backtrace_audit.get("selected_card_id"),
        "selected_local_atom_id": backtrace_audit.get("selected_local_atom_id"),
    }
    if backtrace_audit.get("semantic_identity") != identity:
        _fail("invalid_backtrace_audit", "backtrace semantic identity was tampered")
    card = cards.get(str(identity["selected_card_id"]))
    if card is None or identity["selected_local_atom_id"] not in {
        item["local_atom_id"] for item in card["local_atoms"]
    }:
        _fail("invalid_backtrace_audit", "selected atom no longer belongs to its card")
    selected_review = next(
        item for item in reviews if item["card_id"] == identity["selected_card_id"]
    )
    if (
        selected_review["agent_owned_material_defect"],
        selected_review["counterfactual_redirects_failure"],
        selected_review["boundary_status"],
    ) != ("yes", "yes", "root_or_predecessor"):
        _fail("invalid_backtrace_audit", "selected audit review is not a root")
    qualifying = [
        cards[item["card_id"]]
        for item in reviews
        if (
            item["agent_owned_material_defect"],
            item["counterfactual_redirects_failure"],
            item["boundary_status"],
        ) == ("yes", "yes", "root_or_predecessor")
    ]
    earliest = min(qualifying, key=lambda item: (int(item["step"]), item["card_id"]))
    if earliest["card_id"] != identity["selected_card_id"]:
        _fail("invalid_backtrace_audit", "audit did not freeze the earliest reviewed root")
    atom = v11._by_id(catalog, "local_atoms", "local_atom_id").get(
        str(identity["selected_local_atom_id"])
    )
    if atom is None:
        _fail("invalid_backtrace_audit", "selected local atom no longer resolves")
    expected_owners = sorted(str(item) for item in atom["compatible_owner_atom_ids"])
    expected_projection = {
        "selected_step": int(card["step"]),
        "derived_locus": "backtrace_step_card_local_atom",
        "derived_evidence_scope": [
            item["local_atom_id"] for item in card["local_atoms"]
        ],
        "derived_evidence_quote": atom["quote"],
        "compatible_owner_atom_ids": expected_owners,
    }
    if any(backtrace_audit.get(key) != value for key, value in expected_projection.items()):
        _fail("invalid_backtrace_audit", "backtrace parent projection was tampered")
    freeze = {
        "locator_defect_freeze_sha256": locator_audit["defect_freeze_sha256"],
        "pool_sha256": pool["pool_sha256"],
        "selected_card_id": identity["selected_card_id"],
        "selected_local_atom_id": identity["selected_local_atom_id"],
        "selected_step": int(card["step"]),
        "derived_locus": "backtrace_step_card_local_atom",
        "derived_evidence_scope": expected_projection["derived_evidence_scope"],
        "derived_evidence_quote": atom["quote"],
        "defect_predicate": backtrace_audit.get("defect_predicate"),
        "counterfactual_correction": backtrace_audit.get(
            "counterfactual_correction"
        ),
    }
    if backtrace_audit.get("defect_freeze_sha256") != stable_sha256(freeze):
        _fail("invalid_backtrace_defect_freeze", "backtrace defect freeze was tampered")
    for field in (
        "defect_predicate",
        "counterfactual_correction",
        "selection_reason",
        "rejected_alternative",
    ):
        _required_text(backtrace_audit.get(field), f"backtrace audit {field}")


def _check_backtrace_audit(
    case: Any,
    catalog: Mapping[str, Any],
    locator_audit: Mapping[str, Any],
    backtrace_audit: Mapping[str, Any],
) -> None:
    v11._check_case_catalog(case, catalog)
    _check_backtrace_audit_core(catalog, locator_audit, backtrace_audit)


def _owner_options(
    catalog: Mapping[str, Any], backtrace_audit: Mapping[str, Any]
) -> list[Mapping[str, Any]]:
    owners = v11._by_id(catalog, "owner_atoms", "owner_atom_id")
    try:
        options = [owners[str(item)] for item in backtrace_audit["compatible_owner_atom_ids"]]
    except (KeyError, TypeError):
        _fail("invalid_backtrace_owner_options", "backtrace owner options do not resolve")
    systems = [item for item in options if item["module"] == "system"]
    return systems if systems else options


def build_module_task(
    case: Any,
    catalog: Mapping[str, Any],
    locator_audit: Mapping[str, Any],
    backtrace_audit: Mapping[str, Any],
) -> dict[str, str]:
    _check_backtrace_audit(case, catalog, locator_audit, backtrace_audit)
    public = [
        {
            "owner_atom_id": item["owner_atom_id"],
            "module": item["module"],
            "evidence_preview": v11._redact(
                case, item["quote"], limit=v11._FRAGMENT_MAX_CHARS + 256
            ),
        }
        for item in _owner_options(catalog, backtrace_audit)
    ]
    frozen = {
        "defect_predicate": backtrace_audit["defect_predicate"],
        "counterfactual_correction": backtrace_audit["counterfactual_correction"],
    }
    value = {
        "system_prompt": MODULE_SYSTEM_PROMPT,
        "user_prompt": (
            f"FROZEN BACKTRACE DEFECT\n{json.dumps(frozen, ensure_ascii=False, indent=2)}\n\n"
            f"LEGAL SAME-STEP OWNER ATOMS\n{json.dumps(public, ensure_ascii=False, indent=2)}\n\n"
            "The backtrace step, exact evidence, predicate, and correction are frozen. "
            "Select the supplied owner atom that first realizes that defect. Memory "
            "recalls existing state; reflection interprets a preceding result; planning "
            "commits to a strategy; action emits the concrete call or answer. Do not "
            "output or rewrite step, evidence, predicate, correction, or error type.\n\n"
            + _field_instruction("module")
        ),
    }
    _assert_schema_separated_task(value, stage_name="module")
    return value


def extract_module_semantic_identity(
    raw: Any,
    catalog: Mapping[str, Any] | None = None,
    locator_audit: Mapping[str, Any] | None = None,
    backtrace_audit: Mapping[str, Any] | None = None,
) -> dict[str, str] | None:
    if not isinstance(raw, Mapping):
        return None
    owner_id = raw.get("selected_owner_atom_id")
    if not isinstance(owner_id, str) or v11._ID_PATTERNS["owner"].fullmatch(owner_id) is None:
        return None
    identity = {"selected_owner_atom_id": owner_id}
    if catalog is not None and locator_audit is not None and backtrace_audit is not None:
        try:
            _check_backtrace_audit_core(catalog, locator_audit, backtrace_audit)
            legal = {item["owner_atom_id"] for item in _owner_options(catalog, backtrace_audit)}
        except (AgentJudgeValidationError, KeyError, TypeError, ValueError):
            return None
        if owner_id not in legal:
            return None
    return identity


def validate_module_decision(
    case: Any,
    catalog: Mapping[str, Any],
    locator_audit: Mapping[str, Any],
    backtrace_audit: Mapping[str, Any],
    raw: Any,
    *,
    expected_semantic_identity: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    _check_backtrace_audit(case, catalog, locator_audit, backtrace_audit)
    _reject_placeholders(raw, location="module")
    value = _exact_fields(raw, v11._MODULE_FIELDS, "module decision")
    identity = extract_module_semantic_identity(
        value, catalog, locator_audit, backtrace_audit
    )
    if identity is None:
        _fail("invalid_owner_atom", "selected owner atom is outside frozen options")
    if expected_semantic_identity is not None and dict(expected_semantic_identity) != identity:
        _fail("module_semantic_resample", "repair changed a lockable owner identity")
    options = {item["owner_atom_id"]: item for item in _owner_options(catalog, backtrace_audit)}
    owner = options[identity["selected_owner_atom_id"]]
    return {
        "schema_version": AUDIT_SCHEMA_VERSION,
        "stage": "module",
        "protocol": VERSION,
        "catalog_sha256": catalog["catalog_sha256"],
        "locator_defect_freeze_sha256": locator_audit["defect_freeze_sha256"],
        "pool_sha256": backtrace_audit["pool_sha256"],
        "defect_freeze_sha256": backtrace_audit["defect_freeze_sha256"],
        "selected_owner_atom_id": owner["owner_atom_id"],
        "selected_step": int(owner["step"]),
        "selected_module": owner["module"],
        "derived_owner_evidence_quote": owner["quote"],
        "allowed_error_types": list(owner["allowed_error_types"]),
        "ownership_reason": _required_text(value["ownership_reason"], "ownership_reason"),
        "rejected_owner_option": _required_text(
            value["rejected_owner_option"], "rejected_owner_option"
        ),
        "semantic_identity": identity,
        "step_matches_frozen_boundary": int(owner["step"])
        == int(backtrace_audit["selected_step"]),
        "model_rewrote_frozen_predicate": False,
    }


def _check_module_audit(
    catalog: Mapping[str, Any],
    locator_audit: Mapping[str, Any],
    backtrace_audit: Mapping[str, Any],
    module_audit: Mapping[str, Any],
) -> None:
    _check_backtrace_audit_core(catalog, locator_audit, backtrace_audit)
    if (
        not isinstance(module_audit, Mapping)
        or set(module_audit) != _MODULE_AUDIT_FIELDS
        or module_audit.get("schema_version") != AUDIT_SCHEMA_VERSION
        or module_audit.get("stage") != "module"
        or module_audit.get("protocol") != VERSION
        or module_audit.get("catalog_sha256") != catalog["catalog_sha256"]
        or module_audit.get("locator_defect_freeze_sha256")
        != locator_audit["defect_freeze_sha256"]
        or module_audit.get("pool_sha256") != backtrace_audit["pool_sha256"]
        or module_audit.get("defect_freeze_sha256")
        != backtrace_audit["defect_freeze_sha256"]
        or module_audit.get("step_matches_frozen_boundary") is not True
        or module_audit.get("model_rewrote_frozen_predicate") is not False
    ):
        _fail("invalid_module_audit", "module audit lineage/binding is invalid")
    owners = {item["owner_atom_id"]: item for item in _owner_options(catalog, backtrace_audit)}
    owner = owners.get(str(module_audit.get("selected_owner_atom_id")))
    if owner is None:
        _fail("invalid_module_audit", "module owner no longer resolves")
    expected = {
        "selected_step": int(owner["step"]),
        "selected_module": owner["module"],
        "derived_owner_evidence_quote": owner["quote"],
        "allowed_error_types": list(owner["allowed_error_types"]),
        "semantic_identity": {"selected_owner_atom_id": owner["owner_atom_id"]},
    }
    if any(module_audit.get(key) != value for key, value in expected.items()):
        _fail("invalid_module_audit", "module projection was tampered")
    _required_text(module_audit.get("ownership_reason"), "module audit ownership_reason")
    _required_text(module_audit.get("rejected_owner_option"), "module audit rejected_owner_option")


def _type_options(module_audit: Mapping[str, Any]) -> list[dict[str, str]]:
    return v11._type_options(module_audit)


def build_type_task(
    case: Any,
    catalog: Mapping[str, Any],
    locator_audit: Mapping[str, Any],
    backtrace_audit: Mapping[str, Any],
    module_audit: Mapping[str, Any],
) -> dict[str, str]:
    v11._check_case_catalog(case, catalog)
    _check_module_audit(catalog, locator_audit, backtrace_audit, module_audit)
    frozen = {
        "defect_predicate": backtrace_audit["defect_predicate"],
        "counterfactual_correction": backtrace_audit["counterfactual_correction"],
        "module": module_audit["selected_module"],
        "owner_evidence_preview": v11._redact(
            case,
            module_audit["derived_owner_evidence_quote"],
            limit=v11._FRAGMENT_MAX_CHARS + 256,
        ),
    }
    value = {
        "system_prompt": TYPE_SYSTEM_PROMPT,
        "user_prompt": (
            f"FROZEN BACKTRACE DEFECT AND OWNER\n{json.dumps(frozen, ensure_ascii=False, indent=2)}\n\n"
            f"LEGAL TYPES\n{json.dumps(_type_options(module_audit), ensure_ascii=False, indent=2)}\n\n"
            "Select one supplied type ID whose distinguishing condition is directly "
            "supported by the frozen defect and owner evidence. Do not output or "
            "rewrite step, evidence, predicate, correction, module, or owner.\n\n"
            + _field_instruction("type")
        ),
    }
    _assert_schema_separated_task(value, stage_name="type")
    return value


def extract_type_semantic_identity(
    raw: Any, module_audit: Mapping[str, Any] | None = None
) -> dict[str, str] | None:
    return v11.extract_type_semantic_identity(raw, module_audit)


def validate_type_decision(
    case: Any,
    catalog: Mapping[str, Any],
    locator_audit: Mapping[str, Any],
    backtrace_audit: Mapping[str, Any],
    module_audit: Mapping[str, Any],
    raw: Any,
    *,
    expected_semantic_identity: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    v11._check_case_catalog(case, catalog)
    _check_module_audit(catalog, locator_audit, backtrace_audit, module_audit)
    _reject_placeholders(raw, location="type")
    value = _exact_fields(raw, v11._TYPE_FIELDS, "type decision")
    identity = extract_type_semantic_identity(value, module_audit)
    if identity is None:
        _fail("invalid_type_option", "selected type ID is outside frozen options")
    if expected_semantic_identity is not None and dict(expected_semantic_identity) != identity:
        _fail("type_semantic_resample", "repair changed a lockable type identity")
    options = {item["type_id"]: item for item in _type_options(module_audit)}
    selected = options.get(identity["selected_type_id"])
    if selected is None:
        _fail("invalid_type_option", "type stage selected a non-option ID")
    freeze = {
        "defect_freeze_sha256": backtrace_audit["defect_freeze_sha256"],
        "selected_owner_atom_id": module_audit["selected_owner_atom_id"],
        "selected_type_id": selected["type_id"],
        "selected_error_type": selected["error_type"],
    }
    return {
        "schema_version": AUDIT_SCHEMA_VERSION,
        "stage": "type",
        "protocol": VERSION,
        "catalog_sha256": catalog["catalog_sha256"],
        "locator_defect_freeze_sha256": locator_audit["defect_freeze_sha256"],
        "pool_sha256": backtrace_audit["pool_sha256"],
        **freeze,
        "type_reason": _required_text(value["type_reason"], "type_reason"),
        "rejected_type_option": _required_text(
            value["rejected_type_option"], "rejected_type_option"
        ),
        "type_freeze_sha256": stable_sha256(freeze),
        "semantic_identity": identity,
        "model_rewrote_frozen_predicate_or_owner": False,
    }


def _check_type_audit(
    catalog: Mapping[str, Any],
    locator_audit: Mapping[str, Any],
    backtrace_audit: Mapping[str, Any],
    module_audit: Mapping[str, Any],
    type_audit: Mapping[str, Any],
) -> None:
    _check_module_audit(catalog, locator_audit, backtrace_audit, module_audit)
    if (
        not isinstance(type_audit, Mapping)
        or set(type_audit) != _TYPE_AUDIT_FIELDS
        or type_audit.get("schema_version") != AUDIT_SCHEMA_VERSION
        or type_audit.get("stage") != "type"
        or type_audit.get("protocol") != VERSION
        or type_audit.get("catalog_sha256") != catalog["catalog_sha256"]
        or type_audit.get("locator_defect_freeze_sha256")
        != locator_audit["defect_freeze_sha256"]
        or type_audit.get("pool_sha256") != backtrace_audit["pool_sha256"]
        or type_audit.get("defect_freeze_sha256")
        != backtrace_audit["defect_freeze_sha256"]
        or type_audit.get("selected_owner_atom_id")
        != module_audit["selected_owner_atom_id"]
        or type_audit.get("model_rewrote_frozen_predicate_or_owner") is not False
    ):
        _fail("invalid_type_audit", "type audit lineage/binding is invalid")
    freeze = {
        "defect_freeze_sha256": backtrace_audit["defect_freeze_sha256"],
        "selected_owner_atom_id": module_audit["selected_owner_atom_id"],
        "selected_type_id": type_audit.get("selected_type_id"),
        "selected_error_type": type_audit.get("selected_error_type"),
    }
    if type_audit.get("type_freeze_sha256") != stable_sha256(freeze):
        _fail("invalid_type_audit", "type freeze hash was tampered")
    options = {item["type_id"]: item["error_type"] for item in _type_options(module_audit)}
    if options.get(str(type_audit.get("selected_type_id"))) != type_audit.get(
        "selected_error_type"
    ):
        _fail("invalid_type_audit", "type ID/error projection was tampered")
    if type_audit.get("semantic_identity") != {
        "selected_type_id": type_audit.get("selected_type_id")
    }:
        _fail("invalid_type_audit", "type semantic identity was tampered")
    _required_text(type_audit.get("type_reason"), "type audit type_reason")
    _required_text(type_audit.get("rejected_type_option"), "type audit rejected_type_option")


def _make_backtrace_raw(
    pool: Mapping[str, Any],
    *,
    selected_card_id: str,
    selected_local_atom_id: str,
    hard_system: bool = False,
) -> dict[str, Any]:
    cards = {item["card_id"]: item for item in pool["candidate_step_cards"]}
    selected_card = cards[selected_card_id]
    reviews: list[dict[str, str]] = []
    for card in pool["candidate_step_cards"]:
        selected = card["card_id"] == selected_card_id
        reviews.append(
            {
                "card_id": card["card_id"],
                "agent_owned_material_defect": "yes" if selected else "no",
                "counterfactual_redirects_failure": "yes" if selected else "no",
                "boundary_status": (
                    "root_or_predecessor"
                    if selected
                    else (
                        "uncertain" if int(card["step"]) < int(selected_card["step"])
                        else "downstream_symptom"
                    )
                ),
                "analysis": (
                    "This card supplies the frozen local root."
                    if selected
                    else "This card does not pass both causal root tests."
                ),
            }
        )
    return {
        "reviews": reviews,
        "selected_card_id": selected_card_id,
        "selected_local_atom_id": selected_local_atom_id,
        "defect_predicate": (
            "A well-formed external operation independently failed at the guarded provider boundary."
            if hard_system
            else "This local decision violates a necessary task condition."
        ),
        "counterfactual_correction": (
            "Restore the provider operation without changing the valid call."
            if hard_system
            else "Preserve that condition before continuing."
        ),
        "selection_reason": "This is the earliest supplied card that passes both causal tests.",
        "rejected_alternative": "Later cards are consequences rather than the local root.",
    }


def deterministic_locator_decision(
    catalog: Mapping[str, Any],
) -> dict[str, str] | None:
    return v12.deterministic_boundary_decision(catalog)


def deterministic_backtrace_decision(
    catalog: Mapping[str, Any], locator_audit: Mapping[str, Any]
) -> dict[str, Any] | None:
    pool = _expected_pool(catalog, locator_audit)
    hard_system = catalog["hard_system_root_policy"].get("applied") is True
    if hard_system:
        atom_id = str(locator_audit["selected_local_atom_id"])
        card = next(
            item
            for item in pool["candidate_step_cards"]
            if atom_id in {atom["local_atom_id"] for atom in item["local_atoms"]}
        )
        return _make_backtrace_raw(
            pool,
            selected_card_id=card["card_id"],
            selected_local_atom_id=atom_id,
            hard_system=True,
        )
    candidates = [
        (card["card_id"], atom["local_atom_id"])
        for card in pool["candidate_step_cards"]
        for atom in card["local_atoms"]
    ]
    if len(candidates) != 1:
        return None
    return _make_backtrace_raw(
        pool,
        selected_card_id=candidates[0][0],
        selected_local_atom_id=candidates[0][1],
    )


def deterministic_module_decision(
    catalog: Mapping[str, Any],
    locator_audit: Mapping[str, Any],
    backtrace_audit: Mapping[str, Any],
) -> dict[str, str] | None:
    _check_backtrace_audit_core(catalog, locator_audit, backtrace_audit)
    options = _owner_options(catalog, backtrace_audit)
    if len(options) != 1:
        return None
    return {
        "selected_owner_atom_id": options[0]["owner_atom_id"],
        "ownership_reason": "The frozen backtrace defect admits exactly one legal owner atom.",
        "rejected_owner_option": "No alternative owner option is legally available.",
    }


def deterministic_type_decision(
    module_audit: Mapping[str, Any],
) -> dict[str, str] | None:
    options = _type_options(module_audit)
    if len(options) != 1:
        return None
    return {
        "selected_type_id": options[0]["type_id"],
        "type_reason": "The frozen owner admits exactly one legal taxonomy type.",
        "rejected_type_option": "No alternative type option is legally available.",
    }


def runtime_conformance_locator_decision(
    catalog: Mapping[str, Any],
) -> dict[str, str]:
    deterministic = deterministic_locator_decision(catalog)
    if deterministic is not None:
        return deterministic
    return v12.runtime_conformance_boundary_decision(catalog)


def runtime_locator_decision(
    case: Any, catalog: Mapping[str, Any]
) -> dict[str, str]:
    deterministic = deterministic_locator_decision(catalog)
    if deterministic is not None:
        v11._check_case_catalog(case, catalog)
        return deterministic
    return v12.runtime_boundary_decision(case, catalog)


def runtime_conformance_backtrace_decision(
    catalog: Mapping[str, Any], locator_audit: Mapping[str, Any]
) -> dict[str, Any]:
    deterministic = deterministic_backtrace_decision(catalog, locator_audit)
    if deterministic is not None:
        return deterministic
    pool = _expected_pool(catalog, locator_audit)
    card = pool["candidate_step_cards"][0]
    return _make_backtrace_raw(
        pool,
        selected_card_id=card["card_id"],
        selected_local_atom_id=card["local_atoms"][0]["local_atom_id"],
    )


def runtime_backtrace_decision(
    case: Any,
    catalog: Mapping[str, Any],
    locator_audit: Mapping[str, Any],
) -> dict[str, Any]:
    v11._check_case_catalog(case, catalog)
    return runtime_conformance_backtrace_decision(catalog, locator_audit)


def runtime_conformance_module_decision(
    catalog: Mapping[str, Any],
    locator_audit: Mapping[str, Any],
    backtrace_audit: Mapping[str, Any],
) -> dict[str, str]:
    _check_backtrace_audit_core(catalog, locator_audit, backtrace_audit)
    deterministic = deterministic_module_decision(
        catalog, locator_audit, backtrace_audit
    )
    if deterministic is not None:
        return deterministic
    owner = _owner_options(catalog, backtrace_audit)[0]
    return {
        "selected_owner_atom_id": owner["owner_atom_id"],
        "ownership_reason": "This owner atom directly realizes the frozen backtrace defect.",
        "rejected_owner_option": "No adjacent owner has stronger direct evidence.",
    }


def runtime_module_decision(
    case: Any,
    catalog: Mapping[str, Any],
    locator_audit: Mapping[str, Any],
    backtrace_audit: Mapping[str, Any],
) -> dict[str, str]:
    v11._check_case_catalog(case, catalog)
    return runtime_conformance_module_decision(
        catalog, locator_audit, backtrace_audit
    )


def runtime_conformance_type_decision(
    module_audit: Mapping[str, Any],
) -> dict[str, str]:
    deterministic = deterministic_type_decision(module_audit)
    if deterministic is not None:
        return deterministic
    selected = _type_options(module_audit)[0]
    return {
        "selected_type_id": selected["type_id"],
        "type_reason": "This definition matches the frozen defect and owner evidence.",
        "rejected_type_option": "The alternative lacks its distinguishing condition.",
    }


def runtime_type_decision(
    case: Any,
    catalog: Mapping[str, Any],
    locator_audit: Mapping[str, Any],
    backtrace_audit: Mapping[str, Any],
    module_audit: Mapping[str, Any],
) -> dict[str, str]:
    v11._check_case_catalog(case, catalog)
    _check_module_audit(catalog, locator_audit, backtrace_audit, module_audit)
    return runtime_conformance_type_decision(module_audit)


def _repair_error_guidance(failure: Mapping[str, Any]) -> tuple[str, str]:
    """Project an untrusted failure to a protocol-owned, model-safe diagnostic."""

    raw_code = failure.get("error_code")
    normalized = str(raw_code).strip().casefold() if raw_code is not None else ""
    if normalized in _REPAIR_ERROR_GUIDANCE:
        return normalized, _REPAIR_ERROR_GUIDANCE[normalized]
    return (
        "unclassified_validation_failure",
        "Rebuild one JSON object using exactly the allowed fields and supplied IDs.",
    )


def build_repair_task(
    *,
    stage_name: str,
    original_task: Mapping[str, Any],
    failure: Mapping[str, Any],
    locked_semantic_identity: Mapping[str, Any] | None,
    semantic_resample: bool,
) -> dict[str, str]:
    """Build attempt two without replaying raw output or local JSON Schema."""

    if stage_name not in _STAGE_FIELDS:
        _fail("invalid_repair_stage", "repair stage is unknown")
    _assert_schema_separated_task(original_task, stage_name=stage_name)
    if (locked_semantic_identity is None) != bool(semantic_resample):
        _fail(
            "invalid_repair_identity_policy",
            "semantic_resample must be true exactly when no identity is locked",
        )
    if locked_semantic_identity is None:
        identity_policy = (
            "No legal identity was recoverable. Select one legal supplied identity; "
            "this is the sole permitted semantic resample."
        )
    else:
        identity_policy = (
            "The following semantic identity is frozen. Copy these ID values exactly; "
            "only repair structure, reviews, or explanatory text:\n"
            + json.dumps(
                dict(locked_semantic_identity),
                ensure_ascii=False,
                sort_keys=True,
            )
        )
    safe_error_code, safe_error_guidance = _repair_error_guidance(failure)
    value = {
        "system_prompt": str(original_task["system_prompt"]),
        "user_prompt": (
            f"{original_task['user_prompt']}\n\n"
            "<PRE_REGISTERED_NARROW_REPAIR>\n"
            "This is semantic attempt 2 of 2. The failed response is retained only "
            "in the parent audit and is intentionally not replayed here.\n"
            f"Stage: {stage_name}\n"
            f"Allowed fields: {', '.join(_STAGE_FIELDS[stage_name])}\n"
            f"Validator error code: {safe_error_code}\n"
            f"Protocol repair guidance: {safe_error_guidance}\n"
            f"Identity policy: {identity_policy}\n"
            "Return one corrected JSON object only. Do not output schema metadata.\n"
            f"Concrete shape example:\n{_exact_example(stage_name)}\n"
            "</PRE_REGISTERED_NARROW_REPAIR>"
        ),
    }
    _assert_schema_separated_task(value, stage_name=f"{stage_name} repair")
    return value


def derive_prediction(
    case: Any,
    catalog: Mapping[str, Any],
    locator_audit: Mapping[str, Any],
    backtrace_audit: Mapping[str, Any],
    module_audit: Mapping[str, Any],
    type_audit: Mapping[str, Any],
) -> dict[str, Any]:
    v11._check_case_catalog(case, catalog)
    _check_type_audit(
        catalog,
        locator_audit,
        backtrace_audit,
        module_audit,
        type_audit,
    )
    prediction = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        "predicted_step": int(backtrace_audit["selected_step"]),
        "predicted_module": module_audit["selected_module"],
        "predicted_error_type": type_audit["selected_error_type"],
        "evidence_quote": module_audit["derived_owner_evidence_quote"],
        "root_cause": backtrace_audit["defect_predicate"],
        "causal_summary": backtrace_audit["counterfactual_correction"],
        "rejected_adjacent_owner": module_audit["rejected_owner_option"],
    }
    owner = v11._resolve_prediction_owner_atom(catalog, prediction)
    if owner["owner_atom_id"] != module_audit["selected_owner_atom_id"]:
        _fail("invalid_final_atom_binding", "final prediction changed the frozen owner")
    return prediction


def validate_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = v11.validate_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    return {
        **audit,
        "agent_judge_version": VERSION,
        "model": MODEL,
        "resolved_model": RESOLVED_MODEL,
        "reasoning_effort": REASONING_EFFORT,
        "temperature": TEMPERATURE,
        "four_serial_stage_freezes": True,
        "locator_task_byte_identical_to_atom_v12": True,
        "parent_derived_backtrace_pool": True,
        "backtrace_pool_algorithm": BACKTRACE_POOL_ALGORITHM,
        "backtrace_radius": BACKTRACE_RADIUS,
        "backtrace_radius_selection_basis": (
            "atom-v12 hard-8 post-score tuning diagnosis"
        ),
        "unknown_data_generalization_claim": False,
        "backtrace_reviews_exhaustive": True,
        "module_type_bound_to_backtrace_defect": True,
        "schema_separated_model_prompts": True,
        "repair_response_replay": False,
        "repair_schema_exposure": False,
    }


build_protocol_task = build_locator_task
build_task = build_locator_task


__all__ = [
    "AUDIT_SCHEMA_VERSION",
    "BACKTRACE_CONTEXT_MAX_ITEMS",
    "BACKTRACE_DECISION_FILENAME",
    "BACKTRACE_POOL_ALGORITHM",
    "BACKTRACE_POOL_SCHEMA_VERSION",
    "BACKTRACE_RADIUS",
    "BACKTRACE_SYSTEM_PROMPT",
    "CATALOG_SCHEMA_VERSION",
    "LOCATOR_DECISION_FILENAME",
    "LOCATOR_SYSTEM_PROMPT",
    "MODEL",
    "MODULE_DECISION_FILENAME",
    "MODULE_SYSTEM_PROMPT",
    "REASONING_EFFORT",
    "RESOLVED_MODEL",
    "TEMPERATURE",
    "TYPE_DECISION_FILENAME",
    "TYPE_SYSTEM_PROMPT",
    "VERSION",
    "backtrace_output_schema",
    "build_atom_v13_backtrace_catalog",
    "build_backtrace_pool",
    "build_backtrace_task",
    "build_locator_task",
    "build_module_task",
    "build_protocol_task",
    "build_repair_task",
    "build_task",
    "build_type_task",
    "derive_prediction",
    "deterministic_backtrace_decision",
    "deterministic_locator_decision",
    "deterministic_module_decision",
    "deterministic_type_decision",
    "extract_backtrace_semantic_identity",
    "extract_locator_semantic_identity",
    "extract_module_semantic_identity",
    "extract_type_semantic_identity",
    "locator_output_schema",
    "module_output_schema",
    "runtime_backtrace_decision",
    "runtime_conformance_backtrace_decision",
    "runtime_conformance_locator_decision",
    "runtime_conformance_module_decision",
    "runtime_conformance_type_decision",
    "runtime_locator_decision",
    "runtime_module_decision",
    "runtime_type_decision",
    "type_output_schema",
    "validate_backtrace_decision",
    "validate_locator_decision",
    "validate_module_decision",
    "validate_predictions",
    "validate_type_decision",
]

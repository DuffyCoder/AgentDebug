"""Evidence-only validation for LLM judgments.

This module deliberately does not infer errors or choose a root cause.  It only
checks that the judge's taxonomy values and evidence references are compatible
with the immutable Canonical Trace.
"""

from __future__ import annotations

import re
from typing import Any, Iterator

from agentdebug.trace.models import CanonicalEvent, CanonicalTrace

from .judge_view import JudgeView
from .models import (
    EvidenceValidation,
    RootCauseJudgment,
    ValidationIssue,
    ValidationLevel,
)
from .taxonomy import is_valid_classification


EVIDENCE_VALIDATION_VERSION = (
    "agentdebug.evidence-validation.v2.strict-normalized-single-leaf"
)
"""Identity of the evidence semantics implemented by this module.

Version 2 is intentionally fail-closed.  After whitespace/case normalization,
one non-empty judge quote must remain a contiguous substring of one observable
string leaf in the linked immutable event payload.  A quote assembled across
separate leaves, module spans, or events is not accepted.  Validation failures
are errors rather than review-only annotations.

Replay artifacts must bind this value explicitly.  Changing these semantics
without changing the version would make historical metric artifacts
ambiguous.
"""


def _normalized_text(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip().casefold()


def _string_leaves(value: Any) -> Iterator[str]:
    """Yield observable source strings without JSON escaping or punctuation."""

    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for item in value.values():
            yield from _string_leaves(item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            yield from _string_leaves(item)


def _event_strings(event: CanonicalEvent) -> tuple[str, ...]:
    """Return exact text leaves from one immutable canonical event payload."""

    return tuple(_string_leaves(event.raw))


def _judge_view_event_strings(
    view: JudgeView,
) -> dict[str, tuple[str, ...]]:
    """Recover the same single-leaf evidence contract from a JudgeView.

    The provider process receives only this gold-free projection.  Values stay
    separated by canonical event so a quote cannot be assembled across
    observations, tool arguments, results, or assistant output blocks.
    """

    values: dict[str, list[str]] = {}

    def add(event_id: str, *items: Any) -> None:
        if not event_id:
            return
        destination = values.setdefault(event_id, [])
        for item in items:
            for text in _string_leaves(item):
                if text and text not in destination:
                    destination.append(text)

    for step in view.steps:
        for observation in step.current_input:
            add(observation.event_id, observation.text)
        assistant_values: list[str] = []
        if step.text_blocks:
            assistant_values.extend(
                step.assistant_raw_output[
                    block.start_char : block.end_char
                ]
                for block in step.text_blocks
            )
        else:
            assistant_values.append(step.assistant_raw_output)
        add(
            step.assistant_event_id,
            *assistant_values,
            step.stop_reason,
            step.error_message,
        )
        for call in step.tool_calls:
            add(
                call.event_id,
                call.name,
                call.arguments,
                call.partial_arguments,
            )
            for result in call.results:
                add(
                    result.event_id,
                    result.name,
                    result.output,
                    result.details,
                )
        for observation in step.adjacent_feedback:
            add(observation.event_id, observation.text)
    return {
        event_id: tuple(strings)
        for event_id, strings in values.items()
    }


def validate_evidence(
    trace: CanonicalTrace | JudgeView,
    root: RootCauseJudgment,
    stage: str = "arbiter",
) -> EvidenceValidation:
    """Validate only the final root without changing the LLM judgment."""

    if not isinstance(stage, str) or not stage.strip():
        raise ValueError("evidence-validation stage must be a non-empty string")

    issues: list[ValidationIssue] = []
    if isinstance(trace, CanonicalTrace):
        event_strings = {
            event.event_id: _event_strings(event)
            for event in trace.events
        }
    elif isinstance(trace, JudgeView):
        event_strings = _judge_view_event_strings(trace)
    else:
        raise TypeError(
            "evidence validation requires CanonicalTrace or JudgeView"
        )

    def add(
        code: str,
        level: ValidationLevel,
        stage: str,
        message: str,
        *entity_ids: str,
    ) -> None:
        issues.append(
            ValidationIssue(
                code=code,
                level=level,
                stage=stage,
                message=message,
                entity_ids=[item for item in entity_ids if item],
            )
        )

    try:
        valid_classification = is_valid_classification(
            root.module,
            root.error_type,
        )
    except (KeyError, TypeError):
        valid_classification = False
    if not valid_classification:
        add(
            "invalid_taxonomy_pair",
            ValidationLevel.ERROR,
            stage,
            "The root module/error_type pair is not in AgentErrorTaxonomy.",
            root.critical_event_id,
        )
    if root.critical_event_id not in event_strings:
        add(
            "unknown_critical_event",
            ValidationLevel.ERROR,
            stage,
            "The critical_event_id does not exist in the Canonical Trace.",
            root.critical_event_id,
        )

    missing_root_evidence = [
        event_id
        for event_id in root.evidence_event_ids
        if event_id not in event_strings
    ]
    if missing_root_evidence:
        add(
            "unknown_evidence_event",
            ValidationLevel.ERROR,
            stage,
            "One or more root-cause evidence event IDs do not exist.",
            *missing_root_evidence,
        )
    elif root.evidence_quote:
        quote = _normalized_text(root.evidence_quote)
        supporting_strings = (
            _normalized_text(text)
            for event_id in root.evidence_event_ids
            for text in event_strings[event_id]
        )
        if not any(quote in text for text in supporting_strings):
            add(
                "evidence_quote_not_found",
                ValidationLevel.ERROR,
                stage,
                (
                    "The root evidence quote is not an exact normalized "
                    "substring of the observable events associated with the "
                    "selected step."
                ),
                *root.evidence_event_ids,
            )

    has_errors = any(issue.level == ValidationLevel.ERROR for issue in issues)
    needs_review = any(
        issue.level == ValidationLevel.REVIEW for issue in issues
    )
    return EvidenceValidation(
        valid=not has_errors,
        needs_review=needs_review,
        issues=issues,
    )


__all__ = ["EVIDENCE_VALIDATION_VERSION", "validate_evidence"]

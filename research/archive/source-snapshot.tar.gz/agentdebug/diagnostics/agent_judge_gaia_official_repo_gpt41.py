"""Strict validation for the official-repository GPT-4.1 GAIA judge run."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge import _validate_agent_judge_predictions_with_owner_sources
from .agent_judge_sol_gaia_forced_census import segmented_owner_sources
from .taxonomy import AgentModule, ErrorType


VERSION = "agentdebug.llm-judge.gaia-official-repo-gpt4.1-v1"
MODEL = "gpt-4.1"
TEMPERATURE = 0.0
REASONING_EFFORT = "not_applicable"
STRUCTURAL_ABSENCE_EVIDENCE = "No content found for this module"


def official_owner_sources(
    view: Any,
    predicted_step: int,
    module: AgentModule,
    error_type: ErrorType,
) -> tuple[str, ...]:
    """Expose the public detector's literal empty-module serialization.

    The public Phase-1 implementation serializes a missing module as the
    literal text below and can classify that absence as an error.  Preserve
    strict substring validation by making that deterministic serialization an
    explicit source only when the trajectory has no source for the selected
    owner.  This does not infer or alter step/module/type semantics.
    """

    sources = segmented_owner_sources(view, predicted_step, module, error_type)
    if sources or module == AgentModule.SYSTEM:
        return sources
    return (STRUCTURAL_ABSENCE_EVIDENCE,)


def build_protocol_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Describe the externally executed, frozen official-repository protocol."""

    return f"""Official-repository GAIA critical-error detector.

Protocol: {VERSION}
Model: {MODEL}
Temperature: {TEMPERATURE}
Prediction manifest: {Path(prediction_manifest_path).expanduser().resolve()}
Cohort manifest: {Path(cohort_manifest_path).expanduser().resolve()}
Predictions: {Path(predictions_path).expanduser().resolve()}

Execution is performed by the dedicated Sophnet/OpenAI-compatible runner. Phase 1
uses one independent Chat Completions request for every source step/module pair,
including the public repository's Step-1 Memory/Reflection skip and conditional
System checks. Phase 2 uses one independent global critical-error request per
trajectory and the public repository's retry rule. No gold, prior prediction, or
cross-case semantic state is available before predictions are frozen and audited.
"""


def validate_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    base = _validate_agent_judge_predictions_with_owner_sources(
        Path(prediction_manifest_path).expanduser().resolve(),
        Path(cohort_manifest_path).expanduser().resolve(),
        Path(predictions_path).expanduser().resolve(),
        owner_source_resolver=official_owner_sources,
    )
    return {
        **base,
        "agent_judge_version": VERSION,
        "model": MODEL,
        "reasoning_effort": REASONING_EFFORT,
        "temperature": TEMPERATURE,
        "stage": "official-repository-step-module-phase1-then-joint-phase2",
        "joint_step_module_type_decision": True,
        "phase1_candidate_bound": False,
        "prior_final_prediction_visible": False,
        "segmented_nested_owner_sources": True,
        "official_structural_absence_source": STRUCTURAL_ABSENCE_EVIDENCE,
        "external_llm_api": True,
    }


build_task = build_protocol_task

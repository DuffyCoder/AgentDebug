"""Luna GAIA v3.78: v3.77 semantics with Step-invariant contract repair."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .agent_judge_luna_gaia_v3_77_clean_v3p20_factorized_sparse_ledger_pairwise_selector import *  # noqa: F403
from . import (
    agent_judge_luna_gaia_v3_77_clean_v3p20_factorized_sparse_ledger_pairwise_selector as template,
)


shared = template.shared
parent = template.parent
legality = template.legality

AGENT_JUDGE_LUNA_GAIA_V3_78_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.78-clean-v3.20-"
    "factorized-sparse-ledger-pairwise-selector-contract-repair"
)
AGENT_JUDGE_LUNA_GAIA_V3_78_MODEL = template.AGENT_JUDGE_LUNA_GAIA_V3_77_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_78_REASONING_EFFORT = (
    template.AGENT_JUDGE_LUNA_GAIA_V3_77_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_78_AUDIT_SCHEMA_VERSION = (
    template.AGENT_JUDGE_LUNA_GAIA_V3_77_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases required by the frozen aggregation runner.
AGENT_JUDGE_LUNA_GAIA_V3_77_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_78_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_77_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_78_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_77_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_78_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_78_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_78_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_78_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_78_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_78_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_78_REASONING_EFFORT
)


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_78_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_78_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_78_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": (
            "factorize native sparse-ledger local facts from pairwise global selection"
        ),
        "runtime_contract_repair_only_from_v3p77": True,
        "pairwise_domain_normalization_step_invariant": True,
        "redundant_winner_relation_normalization_step_invariant": True,
        "legality_scaffolding_only_migrated": True,
        "step_semantics_unchanged_by_legality_materialization": True,
    }


def build_anchor_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> str:
    return template.build_anchor_file_task(
        prediction_manifest_path, cohort_manifest_path
    ).replace(template.AGENT_JUDGE_LUNA_GAIA_V3_77_VERSION, AGENT_JUDGE_LUNA_GAIA_V3_78_VERSION)


def build_local_inventory_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> str:
    return template.build_local_inventory_task(
        prediction_manifest_path,
        cohort_manifest_path,
        anchor_path,
        ledger_path,
        checkpoint_path,
    ).replace(template.AGENT_JUDGE_LUNA_GAIA_V3_77_VERSION, AGENT_JUDGE_LUNA_GAIA_V3_78_VERSION)


def build_pairwise_selector_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    inventory_path: str | Path,
) -> str:
    return template.build_pairwise_selector_task(
        prediction_manifest_path,
        cohort_manifest_path,
        anchor_path,
        ledger_path,
        checkpoint_path,
        inventory_path,
    ).replace(template.AGENT_JUDGE_LUNA_GAIA_V3_77_VERSION, AGENT_JUDGE_LUNA_GAIA_V3_78_VERSION)


def normalize_selector_response(
    response: Any,
    *,
    anchor: dict[str, Any],
    ledger: dict[str, Any] | None = None,
    case: Any,
) -> Any:
    """Canonicalize redundant rows without changing the explicit selected Step."""

    raw_step = response.get("selected_step") if isinstance(response, dict) else None
    value = template.normalize_selector_response(response, anchor=anchor, case=case)
    if not isinstance(value, dict):
        return value
    candidates = (
        [
            int(row["step"])
            for row in ledger["rows"]
            if int(row["step"]) < int(anchor["predicted_step"])
        ]
        if ledger is not None
        else list(range(1, int(anchor["predicted_step"])))
    )
    raw_pairs = value.get("pairwise_comparisons")
    if isinstance(raw_pairs, list):
        first_allowed: dict[int, dict[str, Any]] = {}
        for row in raw_pairs:
            if not isinstance(row, dict):
                continue
            step = row.get("candidate_step")
            if step in candidates and step not in first_allowed:
                first_allowed[int(step)] = json.loads(json.dumps(row))
        ordered = [first_allowed[step] for step in candidates if step in first_allowed]
        value["pairwise_comparisons"] = ordered
        if value.get("decision") == "select_prefix":
            selected_step = value.get("selected_step")
            selected_rows = [
                row for row in ordered if row.get("candidate_step") == selected_step
            ]
            if (
                len(selected_rows) == 1
                and selected_rows[0].get("candidate_outweighs_anchor") is True
            ):
                selected_rows[0]["earliest_boundary_relation"] = (
                    "candidate_earlier_critical_boundary"
                )
    if value.get("selected_step") != raw_step:
        raise RuntimeError("v3.78 contract repair changed model-selected Step")
    return value


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        template.validate_anchor_predictions(*paths),
        policy="unchanged_v3_20_anchor_owner_explicit_response_only",
    )


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_local_inventory(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        template.validate_local_inventory(*paths),
        policy="anchor_blind_factorized_native_sparse_ledger_local_facts",
    )


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_local_inventory(*paths[:-1]), paths[-1])


def validate_selector_assessment(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        template.validate_selector_assessment(*paths),
        policy="factorized_native_sparse_ledger_pairwise_global_selection",
    )


def validate_and_write_selector_assessment_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_selector_assessment(*paths[:-1]), paths[-1])


def validate_selector(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        template.validate_selector(*paths),
        policy="deterministic_factorized_sparse_pairwise_selection_copy",
    )


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_selector(*paths[:-1]), paths[-1])


def validate_agent_judge_luna_gaia_v3_78_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    return _retag(
        template.validate_agent_judge_luna_gaia_v3_77_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        policy=(
            "factorized_native_sparse_ledger_local_facts_then_pairwise_selector_"
            "with_step_invariant_contract_repair"
        ),
    )


def validate_and_write_agent_judge_luna_gaia_v3_78_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(
        validate_agent_judge_luna_gaia_v3_78_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_luna_gaia_v3_78_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_pairwise_selector_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,  # noqa: F405
        prediction.parent / PANELS_FILENAME,  # noqa: F405
    )


validate_and_write_agent_judge_luna_gaia_v3_77_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_78_audit
)
validate_and_write_agent_judge_luna_gaia_v3_67_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_78_audit
)
validate_and_write_agent_judge_luna_gaia_v3_37_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_78_audit
)
build_agent_judge_luna_gaia_v3_77_task = build_agent_judge_luna_gaia_v3_78_task
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_luna_gaia_v3_78_task


def __getattr__(name: str) -> Any:
    """Expose unchanged v3.77 schema helpers as an exact semantic retest."""

    return getattr(template, name)

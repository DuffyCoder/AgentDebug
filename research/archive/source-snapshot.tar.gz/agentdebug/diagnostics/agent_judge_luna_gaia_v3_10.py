"""Luna GAIA v3.10: v3.4 plus literal-PDF capability separation."""

from __future__ import annotations

import argparse
import json
import os
import shlex
from pathlib import Path
from typing import Any, Sequence

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
)
from .agent_judge_luna_gaia_v3 import STEP_FREEZE_FIELDS, STEP_FREEZE_FILENAME
from .agent_judge_luna_gaia_v3_4 import (
    AGENT_JUDGE_LUNA_GAIA_V3_4_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_LUNA_GAIA_V3_4_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_4_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_4_VERSION,
    STEP_CANDIDATE_LEDGER_FIELDS,
    STEP_CANDIDATE_LEDGER_FILENAME,
    STEP_CANDIDATE_LANES,
    STEP_CANDIDATE_ROW_FIELDS,
    STEP_CANDIDATE_STATUSES,
    build_agent_judge_luna_gaia_v3_4_task,
    validate_agent_judge_luna_gaia_v3_4_predictions,
)


AGENT_JUDGE_LUNA_GAIA_V3_10_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.10"
)
AGENT_JUDGE_LUNA_GAIA_V3_10_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_4_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_10_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_4_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_10_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_4_AUDIT_SCHEMA_VERSION
)


_LITERAL_PDF_CAPABILITY_RULE = """\
LITERAL PDF CAPABILITY / OUTCOME RULE

Apply this rule only when the current plan explicitly supplies a URL whose
visible path ends in `.pdf` to `url_text_extractor` for retrieval of text from
that PDF. In exactly that condition, Lane-B Planning `impossible_action` is
clear: a successful invocation of the documented interface can expose the
assigned static PDF text. A normal result containing raw or unreadable PDF
bytes is an outcome and cannot retroactively make the current plan incapable.
Audit any later Memory/Reflection claim about what the result contained at the
later claim's own chronological step.

If every condition above is not literal, apply v3.4 semantics unchanged. Do
not infer an analogous positive or negative capability rule from this one.
Record the explicit `.pdf` assignment separately from its observed outcome in
the ledger row's `decision_basis`.

"""


def _replace_validation_command_with_cli(
    task: str,
    *,
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    lines = task.splitlines()
    indexes = [
        index
        for index, line in enumerate(lines)
        if line.startswith("PYTHONPATH=. python3 -c ")
        and "validate_and_write_agent_judge_luna_gaia_v3_10_audit" in line
    ]
    if len(indexes) != 1:
        raise RuntimeError("Luna GAIA v3.4 validation command changed unexpectedly")
    prediction = Path(predictions_path).expanduser().resolve()
    paths = (
        Path(prediction_manifest_path).expanduser().resolve(),
        Path(cohort_manifest_path).expanduser().resolve(),
        prediction,
        prediction.parent / "prediction-audit.json",
    )
    arguments = " ".join(shlex.quote(str(path)) for path in paths)
    lines[indexes[0]] = (
        "PYTHONPATH=. python3 -m "
        "agentdebug.diagnostics.agent_judge_luna_gaia_v3_10 "
        f"--compact-validate {arguments}"
    )
    return "\n".join(lines) + ("\n" if task.endswith("\n") else "")


def build_agent_judge_luna_gaia_v3_10_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build v3.4 with one literal-PDF rule and a shell-safe validator CLI."""

    task = build_agent_judge_luna_gaia_v3_4_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    task = task.replace(
        AGENT_JUDGE_LUNA_GAIA_V3_4_VERSION,
        AGENT_JUDGE_LUNA_GAIA_V3_10_VERSION,
    )
    task = task.replace(
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_4.py",
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_10.py",
    )
    task = task.replace(
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_4 import "
        "validate_and_write_agent_judge_luna_gaia_v3_4_audit as run",
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_10 import "
        "validate_and_write_agent_judge_luna_gaia_v3_10_audit as run",
    )
    lane_c = "LANE C — STRATEGY EPOCHS AND TERMINAL ABANDONMENT\n"
    if task.count(lane_c) != 1:
        raise RuntimeError("Luna GAIA v3.4 lane-C boundary changed unexpectedly")
    task = task.replace(lane_c, _LITERAL_PDF_CAPABILITY_RULE + lane_c, 1)
    task = _replace_validation_command_with_cli(
        task,
        prediction_manifest_path=prediction_manifest_path,
        cohort_manifest_path=cohort_manifest_path,
        predictions_path=predictions_path,
    )
    old_failure = (
        "On failure inspect only the validator error and allowlisted current "
        "artifacts,\ncorrect the prediction, and rerun."
    )
    new_failure = (
        "On failure inspect only the compact validator code/message and "
        "allowlisted\ncurrent artifacts, correct only that reported defect, "
        "and rerun."
    )
    if task.count(old_failure) != 1:
        raise RuntimeError("Luna GAIA v3.4 validator failure text changed")
    return task.replace(old_failure, new_failure, 1)


def validate_agent_judge_luna_gaia_v3_10_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_4_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_10_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_10_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_10_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_10_REASONING_EFFORT,
        "selection_policy": (
            "lane_ordered_chronology_validated_step_candidate_ledger_"
            "limited_recovery_veto_external_exception_packet_fence_"
            "literal_pdf_capability_outcome_rule"
        ),
        "literal_pdf_capability_rule": (
            "visible_dot_pdf_url_to_url_text_extractor_only"
        ),
    }


def validate_and_write_agent_judge_luna_gaia_v3_10_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_10_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


def run_agent_judge_luna_gaia_v3_10_compact_validation(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> int:
    try:
        audit = validate_and_write_agent_judge_luna_gaia_v3_10_audit(
            prediction_manifest_path,
            cohort_manifest_path,
            predictions_path,
            audit_path,
        )
    except AgentJudgeValidationError as error:
        print(
            json.dumps(
                {
                    "valid": False,
                    "error_code": error.code,
                    "error_message": str(error),
                },
                ensure_ascii=False,
            )
        )
        return 1
    except Exception as error:  # pragma: no cover
        print(
            json.dumps(
                {
                    "valid": False,
                    "error_code": "unexpected_validation_error",
                    "error_message": f"{type(error).__name__}: {error}",
                },
                ensure_ascii=False,
            )
        )
        return 2
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("paths", nargs=4)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("--compact-validate is required")
    return run_agent_judge_luna_gaia_v3_10_compact_validation(*args.paths)


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "AGENT_JUDGE_LUNA_GAIA_V3_10_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_GAIA_V3_10_MODEL",
    "AGENT_JUDGE_LUNA_GAIA_V3_10_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_GAIA_V3_10_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "STEP_CANDIDATE_LEDGER_FIELDS",
    "STEP_CANDIDATE_LEDGER_FILENAME",
    "STEP_CANDIDATE_LANES",
    "STEP_CANDIDATE_ROW_FIELDS",
    "STEP_CANDIDATE_STATUSES",
    "STEP_FREEZE_FIELDS",
    "STEP_FREEZE_FILENAME",
    "build_agent_judge_luna_gaia_v3_10_task",
    "main",
    "run_agent_judge_luna_gaia_v3_10_compact_validation",
    "validate_agent_judge_luna_gaia_v3_10_predictions",
    "validate_and_write_agent_judge_luna_gaia_v3_10_audit",
]

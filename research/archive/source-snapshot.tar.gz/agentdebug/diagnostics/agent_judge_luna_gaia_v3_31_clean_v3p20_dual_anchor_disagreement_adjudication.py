"""Luna GAIA v3.31: clean v3.20 with dual-anchor adjudication."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from .taxonomy import taxonomy_prompt


AGENT_JUDGE_LUNA_GAIA_V3_31_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.31-clean-v3.20-"
    "dual-anchor-disagreement-adjudication"
)
AGENT_JUDGE_LUNA_GAIA_V3_31_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_31_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_31_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_31_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_31_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_31_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_31_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = parent.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = parent.CHALLENGERS_FILENAME
ARBITER_FILENAME = parent.ARBITER_FILENAME
ARBITERS_FILENAME = parent.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = parent.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = parent.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME

PRIMARY_ANCHOR_PREDICTIONS_FILENAME = "primary-anchor-predictions.json"
PRIMARY_ANCHOR_LEDGERS_FILENAME = "primary-anchor-step-candidates.json"
PRIMARY_ANCHOR_CHECKPOINTS_FILENAME = "primary-anchor-step-freezes.json"
REPLICA_ANCHOR_PREDICTIONS_FILENAME = "replica-anchor-predictions.json"
REPLICA_ANCHOR_LEDGERS_FILENAME = "replica-anchor-step-candidates.json"
REPLICA_ANCHOR_CHECKPOINTS_FILENAME = "replica-anchor-step-freezes.json"
RECONCILIATION_FILENAME = "anchor-reconciliation.json"
RECONCILIATIONS_FILENAME = "anchor-reconciliations.json"
RECONCILIATION_AUDIT_FILENAME = "anchor-reconciliation-audit.json"

RECONCILIATION_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "primary_prediction_sha256",
    "primary_ledger_sha256",
    "primary_checkpoint_sha256",
    "replica_prediction_sha256",
    "replica_ledger_sha256",
    "replica_checkpoint_sha256",
    "primary_step",
    "replica_step",
    "comparison",
    "decision",
    "frozen_step",
    "selected_prediction_sha256",
    "selected_prediction",
    "primary_boundary_assessment",
    "replica_boundary_assessment",
    "decision_basis",
    "rejected_alternative_basis",
)
RECONCILIATION_COMPARISONS = frozenset({"agreement", "disagreement"})
RECONCILIATION_DECISIONS = frozenset({"keep_primary", "select_replica"})


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_31_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_31_clean_v3p20_dual_anchor_disagreement_adjudication",
        )
    )


def build_primary_anchor_task(*paths: str | Path) -> str:
    return (
        f"Run {AGENT_JUDGE_LUNA_GAIA_V3_31_VERSION} primary anchor. This is one "
        "unchanged v3.20 packet-state anchor; no replica or historical prediction "
        "is visible in this fresh session.\n\n"
        + _rewrite_identity(parent.build_anchor_task(*paths))
    )


def build_replica_anchor_task(*paths: str | Path) -> str:
    return (
        f"Run {AGENT_JUDGE_LUNA_GAIA_V3_31_VERSION} replica anchor. Independently "
        "execute the unchanged v3.20 packet-state anchor. No primary anchor or "
        "historical prediction is visible in this fresh session.\n\n"
        + _rewrite_identity(parent.build_anchor_task(*paths))
    )


def build_anchor_task(*paths: str | Path) -> str:
    return build_primary_anchor_task(*paths)


def build_challenger_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_challenger_task(*paths))


def build_arbiter_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_arbiter_task(*paths))


def _retag(audit: dict[str, Any]) -> dict[str, Any]:
    result = dict(audit)
    result["agent_judge_version"] = AGENT_JUDGE_LUNA_GAIA_V3_31_VERSION
    result["model"] = AGENT_JUDGE_LUNA_GAIA_V3_31_MODEL
    result["reasoning_effort"] = AGENT_JUDGE_LUNA_GAIA_V3_31_REASONING_EFFORT
    return result


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths))


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_challenger(*paths))


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_arbiter(*paths))


def _load_anchor_bundle(
    manifest: Path,
    cohort: Path,
    prediction_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> tuple[Path, Path, Path, dict[str, Any], dict[str, Any], dict[str, Any]]:
    prediction_file = Path(prediction_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    anchor, ledger, checkpoint = shared._validate_anchor_bundle(
        manifest, cohort, prediction_file, ledger_file, checkpoint_file
    )
    parent._validate_packet_state_ledgers(ledger_file)
    return prediction_file, ledger_file, checkpoint_file, anchor, ledger, checkpoint


def _validate_reconciliation_record(
    raw: Any,
    *,
    case: Any,
    primary: dict[str, Any],
    primary_ledger: dict[str, Any],
    primary_checkpoint: dict[str, Any],
    replica: dict[str, Any],
    replica_ledger: dict[str, Any],
    replica_checkpoint: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != RECONCILIATION_FIELDS:
        shared._fail("invalid_reconciliation_schema", f"{location} fields/order differ")
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
    ):
        shared._fail("reconciliation_identity_mismatch", location)
    bindings = {
        "primary_prediction_sha256": shared._stable_sha256(primary),
        "primary_ledger_sha256": shared._stable_sha256(primary_ledger),
        "primary_checkpoint_sha256": shared._stable_sha256(primary_checkpoint),
        "replica_prediction_sha256": shared._stable_sha256(replica),
        "replica_ledger_sha256": shared._stable_sha256(replica_ledger),
        "replica_checkpoint_sha256": shared._stable_sha256(replica_checkpoint),
    }
    if any(raw[key] != value for key, value in bindings.items()):
        shared._fail("reconciliation_hash_mismatch", location)
    if raw["primary_step"] != primary["predicted_step"]:
        shared._fail("reconciliation_primary_step_mismatch", location)
    if raw["replica_step"] != replica["predicted_step"]:
        shared._fail("reconciliation_replica_step_mismatch", location)
    expected_comparison = (
        "agreement"
        if primary["predicted_step"] == replica["predicted_step"]
        else "disagreement"
    )
    if (
        raw["comparison"] not in RECONCILIATION_COMPARISONS
        or raw["comparison"] != expected_comparison
    ):
        shared._fail("invalid_reconciliation_comparison", location)
    if raw["decision"] not in RECONCILIATION_DECISIONS:
        shared._fail("invalid_reconciliation_decision", location)
    if expected_comparison == "agreement" and raw["decision"] != "keep_primary":
        shared._fail("agreement_must_keep_primary", location)
    for field in (
        "primary_boundary_assessment",
        "replica_boundary_assessment",
        "decision_basis",
        "rejected_alternative_basis",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=2400)
    selected = shared._validate_prediction_record(
        raw["selected_prediction"], case=case, location=f"{location}.selected"
    )
    expected = primary if raw["decision"] == "keep_primary" else replica
    if selected != expected:
        shared._fail("reconciliation_prediction_copy_mismatch", location)
    if raw["selected_prediction_sha256"] != shared._stable_sha256(selected):
        shared._fail("reconciliation_selected_hash_mismatch", location)
    if raw["frozen_step"] != selected["predicted_step"]:
        shared._fail("reconciliation_frozen_step_mismatch", location)
    return raw


def validate_reconciliation(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    primary_prediction_path: str | Path,
    primary_ledger_path: str | Path,
    primary_checkpoint_path: str | Path,
    replica_prediction_path: str | Path,
    replica_ledger_path: str | Path,
    replica_checkpoint_path: str | Path,
    reconciliation_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    primary_bundle = _load_anchor_bundle(
        manifest,
        cohort,
        primary_prediction_path,
        primary_ledger_path,
        primary_checkpoint_path,
    )
    replica_bundle = _load_anchor_bundle(
        manifest,
        cohort,
        replica_prediction_path,
        replica_ledger_path,
        replica_checkpoint_path,
    )
    primary_file, primary_ledger_file, primary_checkpoint_file = primary_bundle[:3]
    primary, primary_ledger, primary_checkpoint = primary_bundle[3:]
    replica_file, replica_ledger_file, replica_checkpoint_file = replica_bundle[:3]
    replica, replica_ledger, replica_checkpoint = replica_bundle[3:]
    reconciliation_file, raw = shared._load_artifact(
        reconciliation_path, role="anchor reconciliation"
    )
    record = shared._one_record(raw, role="anchor reconciliation")
    _validate_reconciliation_record(
        record,
        case=case,
        primary=primary,
        primary_ledger=primary_ledger,
        primary_checkpoint=primary_checkpoint,
        replica=replica,
        replica_ledger=replica_ledger,
        replica_checkpoint=replica_checkpoint,
        location="anchor_reconciliation[0]",
    )
    return {
        "schema_version": "agentdebug.dual-anchor-reconciliation-audit.v1",
        "stage": "anchor_reconciliation",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_31_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_31_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_31_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": 1,
        "comparison": record["comparison"],
        "decision": record["decision"],
        "selected_prediction_exact_copy": True,
        "third_prediction_forbidden": True,
        "input_sha256": {
            "primary_prediction": shared._file_sha256(primary_file),
            "primary_ledger": shared._file_sha256(primary_ledger_file),
            "primary_checkpoint": shared._file_sha256(primary_checkpoint_file),
            "replica_prediction": shared._file_sha256(replica_file),
            "replica_ledger": shared._file_sha256(replica_ledger_file),
            "replica_checkpoint": shared._file_sha256(replica_checkpoint_file),
        },
        "output_sha256": {
            RECONCILIATION_FILENAME: shared._file_sha256(reconciliation_file)
        },
    }


def _boundary(
    *, manifest: Path, cohort: Path, reads: Sequence[Path], output: Path
) -> str:
    read_lines = "\n".join(f"- {path}" for path in reads)
    return f"""\
IMMUTABLE EXECUTION CONFIGURATION
- model: {AGENT_JUDGE_LUNA_GAIA_V3_31_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_31_REASONING_EFFORT}
- one isolated case; fresh session; no cross-case state or prior predictions
- external LLM/API/network calls: forbidden
- scoring or gold-label access: forbidden

INPUT/OUTPUT BOUNDARY
- prediction manifest: {manifest}
- prediction manifest file sha256: {shared._file_sha256(manifest)}
- cohort manifest: {cohort}
- cohort manifest file sha256: {shared._file_sha256(cohort)}
- permitted frozen stage inputs:
{read_lines}
- write the sole stage artifact only to: {output}

Read only those exact inputs plus this v3.31 protocol source, the v3.20
protocol source, and `agentdebug/diagnostics/taxonomy.py`. Do not inspect
directories or infer from trajectory/source-model/environment names. Never
read labels, metrics, scored artifacts, promotion files, experiment documents,
old predictions, cached replies, case studies, git history, or external resources.
"""


_RECONCILIATION_RULES = """\
DUAL-ANCHOR DISAGREEMENT ADJUDICATION — THE ONLY NEW MECHANISM

Both candidates were produced independently by the same v3.20 packet-state
anchor. You may select only one exact frozen candidate; never invent or repair
a third Step or prediction. When the Steps agree, keep_primary mechanically.

When the Steps disagree, compare their literal boundaries symmetrically:

1. Reconstruct the complete chronology around both Steps.
2. Apply the unchanged v3.20 packet-state admission and veto semantics to both.
3. Reject a candidate if it is only a reasonable initial probe, a normal tool
   failure, a recovered/local defect, a noncritical predecessor, faithful
   propagation, or a downstream symptom.
4. Prefer a candidate only when literal evidence shows that repairing that Step
   changes the failure path and the competing Step is noncritical or downstream.
5. Do not prefer earlier position, later position, stronger wording,
   persistence, Planning ownership, or more detailed rationale by itself.
6. If evidence remains unresolved, keep_primary.

Your selected_prediction must be a field-for-field exact copy of the chosen
anchor. The adjudicator is forbidden to add a candidate or consult any prior run.
"""


def build_reconciliation_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    primary_prediction_path: str | Path,
    primary_ledger_path: str | Path,
    primary_checkpoint_path: str | Path,
    replica_prediction_path: str | Path,
    replica_ledger_path: str | Path,
    replica_checkpoint_path: str | Path,
    reconciliation_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    primary_bundle = _load_anchor_bundle(
        manifest,
        cohort,
        primary_prediction_path,
        primary_ledger_path,
        primary_checkpoint_path,
    )
    replica_bundle = _load_anchor_bundle(
        manifest,
        cohort,
        replica_prediction_path,
        replica_ledger_path,
        replica_checkpoint_path,
    )
    primary_file, primary_ledger_file, primary_checkpoint_file = primary_bundle[:3]
    primary, primary_ledger, primary_checkpoint = primary_bundle[3:]
    replica_file, replica_ledger_file, replica_checkpoint_file = replica_bundle[:3]
    replica, replica_ledger, replica_checkpoint = replica_bundle[3:]
    output = Path(reconciliation_path).expanduser().resolve()
    shared._assert_safe_path(output, role="reconciliation output", is_output=True)
    audit = output.parent / RECONCILIATION_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_31_clean_v3p20_dual_anchor_disagreement_adjudication",
            "--compact-validate",
            "reconciliation",
            manifest,
            cohort,
            primary_file,
            primary_ledger_file,
            primary_checkpoint_file,
            replica_file,
            replica_ledger_file,
            replica_checkpoint_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "primary_prediction_sha256": shared._stable_sha256(primary),
        "primary_ledger_sha256": shared._stable_sha256(primary_ledger),
        "primary_checkpoint_sha256": shared._stable_sha256(primary_checkpoint),
        "replica_prediction_sha256": shared._stable_sha256(replica),
        "replica_ledger_sha256": shared._stable_sha256(replica_ledger),
        "replica_checkpoint_sha256": shared._stable_sha256(replica_checkpoint),
        "primary_step": primary["predicted_step"],
        "replica_step": replica["predicted_step"],
        "comparison": "agreement or disagreement",
        "decision": "keep_primary or select_replica",
        "frozen_step": "selected prediction Step",
        "selected_prediction_sha256": "stable JSON hash of exact selected prediction",
        "selected_prediction": "exact unchanged primary or replica prediction object",
        "primary_boundary_assessment": "literal critical-boundary assessment",
        "replica_boundary_assessment": "literal critical-boundary assessment",
        "decision_basis": "symmetric comparison or mechanical agreement decision",
        "rejected_alternative_basis": "why the other exact anchor loses",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_31_VERSION} stage 3/5: anchor adjudicator.

{_boundary(manifest=manifest, cohort=cohort, reads=(primary_file, primary_ledger_file, primary_checkpoint_file, replica_file, replica_ledger_file, replica_checkpoint_file), output=output)}

{_RECONCILIATION_RULES}

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

Compute every content hash as stable sorted compact JSON. After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _validate_dual_aggregate(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(prediction_manifest_path, cohort_manifest_path)
    root = Path(predictions_path).expanduser().resolve().parent
    filenames = (
        PRIMARY_ANCHOR_PREDICTIONS_FILENAME,
        PRIMARY_ANCHOR_LEDGERS_FILENAME,
        PRIMARY_ANCHOR_CHECKPOINTS_FILENAME,
        REPLICA_ANCHOR_PREDICTIONS_FILENAME,
        REPLICA_ANCHOR_LEDGERS_FILENAME,
        REPLICA_ANCHOR_CHECKPOINTS_FILENAME,
        RECONCILIATIONS_FILENAME,
        ANCHOR_PREDICTIONS_FILENAME,
        ANCHOR_LEDGER_AGGREGATE_FILENAME,
        ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
    )
    loaded = {
        name: shared._load_artifact(root / name, role=f"merged {name}")[1]
        for name in filenames
    }
    if any(
        not isinstance(value, list) or len(value) != len(cases)
        for value in loaded.values()
    ):
        shared._fail("invalid_dual_anchor_aggregate_count", "all dual artifacts need all cases")
    comparisons: Counter[str] = Counter()
    decisions: Counter[str] = Counter()
    for index, case in enumerate(cases):
        primary = loaded[PRIMARY_ANCHOR_PREDICTIONS_FILENAME][index]
        primary_ledger = loaded[PRIMARY_ANCHOR_LEDGERS_FILENAME][index]
        primary_checkpoint = loaded[PRIMARY_ANCHOR_CHECKPOINTS_FILENAME][index]
        replica = loaded[REPLICA_ANCHOR_PREDICTIONS_FILENAME][index]
        replica_ledger = loaded[REPLICA_ANCHOR_LEDGERS_FILENAME][index]
        replica_checkpoint = loaded[REPLICA_ANCHOR_CHECKPOINTS_FILENAME][index]
        reconciliation = loaded[RECONCILIATIONS_FILENAME][index]
        selected = loaded[ANCHOR_PREDICTIONS_FILENAME][index]
        selected_ledger = loaded[ANCHOR_LEDGER_AGGREGATE_FILENAME][index]
        selected_checkpoint = loaded[ANCHOR_CHECKPOINT_AGGREGATE_FILENAME][index]
        location = f"dual_merged[{index}]"
        shared._validate_prediction_record(primary, case=case, location=f"{location}.primary")
        shared._validate_prediction_record(replica, case=case, location=f"{location}.replica")
        for name, prediction, ledger, checkpoint in (
            ("primary", primary, primary_ledger, primary_checkpoint),
            ("replica", replica, replica_ledger, replica_checkpoint),
        ):
            if (
                ledger.get("trajectory_id") != case.trajectory_id
                or ledger.get("selected_step") != prediction["predicted_step"]
                or checkpoint.get("trajectory_id") != case.trajectory_id
                or checkpoint.get("predicted_step") != prediction["predicted_step"]
            ):
                shared._fail("dual_anchor_sidecar_mismatch", f"{location}.{name}")
        _validate_reconciliation_record(
            reconciliation,
            case=case,
            primary=primary,
            primary_ledger=primary_ledger,
            primary_checkpoint=primary_checkpoint,
            replica=replica,
            replica_ledger=replica_ledger,
            replica_checkpoint=replica_checkpoint,
            location=f"{location}.reconciliation",
        )
        use_primary = reconciliation["decision"] == "keep_primary"
        expected_prediction = primary if use_primary else replica
        expected_ledger = primary_ledger if use_primary else replica_ledger
        expected_checkpoint = primary_checkpoint if use_primary else replica_checkpoint
        if (
            selected != expected_prediction
            or selected_ledger != expected_ledger
            or selected_checkpoint != expected_checkpoint
        ):
            shared._fail("reconciled_anchor_bundle_copy_mismatch", location)
        comparisons[reconciliation["comparison"]] += 1
        decisions[reconciliation["decision"]] += 1
    primary_state = parent._validate_packet_state_ledgers(
        root / PRIMARY_ANCHOR_LEDGERS_FILENAME
    )
    replica_state = parent._validate_packet_state_ledgers(
        root / REPLICA_ANCHOR_LEDGERS_FILENAME
    )
    return {
        "required": True,
        "valid": True,
        "primary_packet_state_closure": primary_state,
        "replica_packet_state_closure": replica_state,
        "comparison_counts": dict(sorted(comparisons.items())),
        "decision_counts": dict(sorted(decisions.items())),
        "all_selected_anchor_bundles_exact_copies": True,
        "third_prediction_forbidden": True,
    }


def validate_agent_judge_luna_gaia_v3_31_predictions(
    *paths: str | Path,
) -> dict[str, Any]:
    audit = _retag(parent.validate_agent_judge_luna_gaia_v3_20_predictions(*paths))
    audit["schema_version"] = AGENT_JUDGE_LUNA_GAIA_V3_31_AUDIT_SCHEMA_VERSION
    audit["selection_policy"] = (
        "two_independent_v3_20_packet_state_anchors_agreement_primary_"
        "disagreement_literal_adjudication_then_unchanged_v3_20_challenger_arbiter"
    )
    audit["direct_semantic_parent"] = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION
    audit["rejected_lineage_inherited"] = False
    audit["dual_anchor_adjudication"] = _validate_dual_aggregate(*paths)
    audit["downstream_v3_20_challenger_arbiter_unchanged"] = True
    return audit


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_reconciliation_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_reconciliation(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_31_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_31_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_luna_gaia_v3_31_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_31_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_31_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_31_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "reconciliation" and len(paths) == 10:
            audit = validate_and_write_reconciliation_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_31_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument(
        "stage", choices=("anchor", "reconciliation", "challenger", "arbiter", "prediction")
    )
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

"""Validation policy for candidate-constrained canonical GAIA judging."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge import _validate_agent_judge_predictions_with_owner_sources
from .agent_judge_gaia_official_repo_gpt41_canonical_v2 import observation_text
from .agent_judge_sol_gaia_forced_census import segmented_owner_sources
from .judge_view import JudgeView
from .taxonomy import AgentModule, ErrorType


VERSION = "agentdebug.llm-judge.gaia-official-repo-gpt4.1-candidate-v3"
MODEL = "gpt-4.1"
TEMPERATURE = 0.0
REASONING_EFFORT = "not_applicable"


def candidate_owner_sources(
    view: JudgeView,
    predicted_step: int,
    module: AgentModule,
    error_type: ErrorType,
) -> tuple[str, ...]:
    """Resolve literal owner evidence without inferred runaway system output."""

    if module != AgentModule.SYSTEM:
        return segmented_owner_sources(view, predicted_step, module, error_type)
    step = view.steps[predicted_step - 1]
    sources: list[str] = []
    for feedback in step.adjacent_feedback:
        text = observation_text(feedback)
        if text:
            sources.append(text)
    for call in step.tool_calls:
        sources.extend(result.output for result in call.results if result.output.strip())
    sources.extend(
        value.strip()
        for value in (step.error_message, step.stop_reason)
        if value and value.strip()
    )
    return tuple(dict.fromkeys(sources))


def build_protocol_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    return f"""Candidate-constrained canonical GAIA diagnostic judge.

Protocol: {VERSION}
Model: {MODEL}
Temperature: {TEMPERATURE}
Prediction manifest: {Path(prediction_manifest_path).expanduser().resolve()}
Cohort manifest: {Path(cohort_manifest_path).expanduser().resolve()}
Predictions: {Path(predictions_path).expanduser().resolve()}

Phase 1 uses canonical module spans and actual observations. Phase 2 may select
only a serialized positive Phase 1 candidate and does not discount steps 1-3.
System candidates require an observable tool result, error, or stop boundary.
"""


def validate_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    base = _validate_agent_judge_predictions_with_owner_sources(
        Path(prediction_manifest_path).expanduser().resolve(),
        Path(cohort_manifest_path).expanduser().resolve(),
        Path(predictions_path).expanduser().resolve(),
        owner_source_resolver=candidate_owner_sources,
    )
    return {
        **base,
        "agent_judge_version": VERSION,
        "model": MODEL,
        "reasoning_effort": REASONING_EFFORT,
        "temperature": TEMPERATURE,
        "stage": "canonical-phase1-then-positive-candidate-constrained-phase2",
        "candidate_constrained_phase2": True,
        "early_step_discount_removed": True,
        "observable_only_system_candidates": True,
        "external_llm_api": True,
    }


build_task = build_protocol_task

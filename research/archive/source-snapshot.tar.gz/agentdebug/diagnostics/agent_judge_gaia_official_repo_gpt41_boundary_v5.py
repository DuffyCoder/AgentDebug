"""Validation policy for boundary-reviewed serial GAIA judging."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge import _validate_agent_judge_predictions_with_owner_sources
from .agent_judge_gaia_official_repo_gpt41_serial_v4 import serial_owner_sources


VERSION = "agentdebug.llm-judge.gaia-official-repo-gpt4.1-boundary-v5"
MODEL = "gpt-4.1"
TEMPERATURE = 0.0
REASONING_EFFORT = "not_applicable"


def build_protocol_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    return f"""Boundary-reviewed serial GAIA diagnostic judge.

Protocol: {VERSION}
Model: {MODEL}
Temperature: {TEMPERATURE}
Prediction manifest: {Path(prediction_manifest_path).expanduser().resolve()}
Cohort manifest: {Path(cohort_manifest_path).expanduser().resolve()}
Predictions: {Path(predictions_path).expanduser().resolve()}

A step scout freezes three distinct boundary candidates without selecting a
winner. A fresh reviewer may select only one of them. Module and error-type
judges run serially afterward. A first, well-formed, independent provider
failure has hard system ownership only after causal guards exclude a known
failure retry or a mature earlier memory/reflection owner.
"""


def validate_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    base = _validate_agent_judge_predictions_with_owner_sources(
        Path(prediction_manifest_path).expanduser().resolve(),
        Path(cohort_manifest_path).expanduser().resolve(),
        Path(predictions_path).expanduser().resolve(),
        owner_source_resolver=serial_owner_sources,
    )
    return {
        **base,
        "agent_judge_version": VERSION,
        "model": MODEL,
        "reasoning_effort": REASONING_EFFORT,
        "temperature": TEMPERATURE,
        "stage": "top3-step-proposal-then-boundary-review-then-module-then-type",
        "boundary_reviewer_constrained_to_frozen_candidates": True,
        "hard_system_owner_policy": "causally-guarded-first-provider-failure",
        "reflection_type_policy_refined": True,
        "strict_intermediate_lineage_audit": True,
        "module_literal_claim_handoff": True,
        "reflection_preceding_observation_handoff": True,
        "external_llm_api": True,
    }


build_task = build_protocol_task

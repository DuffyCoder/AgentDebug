"""Luna GAIA v3.39: clean v3.20 with one bounded typed later challenger."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_14_earliest_causal_challenger as incumbent_challenger
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent


AGENT_JUDGE_LUNA_GAIA_V3_39_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.39-clean-v3.20-"
    "bounded-typed-boundary-challenger"
)
AGENT_JUDGE_LUNA_GAIA_V3_39_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_39_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_39_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases used by the shared paper-50 runner.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_39_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_39_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_39_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_39_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = parent.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = parent.CHALLENGERS_FILENAME
ARBITER_FILENAME = parent.ARBITER_FILENAME
ARBITERS_FILENAME = parent.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = parent.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = parent.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
CHALLENGER_FIELDS = parent.CHALLENGER_FIELDS
ARBITER_FIELDS = parent.ARBITER_FIELDS


_TYPED_PREFIX = re.compile(
    r"^typed_boundary=(none|state_truth|post_feedback_maturity|alignment); "
    r"boundary_step=(none|[1-9]\d*); "
    r"maturity_witness_step=(none|[1-9]\d*); "
)


_BOUNDED_TYPED_BOUNDARY_RULES = """\
BOUNDED TYPED-BOUNDARY LATER CHALLENGER — ONE PROPOSAL MAXIMUM

The frozen clean-v3.20 prediction is the incumbent anchor. Keep its ledger and
checkpoint frozen. Search only for literal evidence that this specific anchor
is a reasonable probe or noncritical predecessor and that one strictly later
typed boundary is independently failure-causing. Emit at most ONE proposal;
never enumerate or retain a candidate pool. The anchor is the default under
uncertainty.

ANCHOR FALSIFICATION GATE

A later search is permitted only when the observed anchor action can still
contribute a necessary identifier, source, page, text, route, or information
lead to its immediate unresolved subgoal, or when literal chronology shows
that repairing the anchor alone cannot avert the later failure. A normal tool
or site failure, a low-probability but informative first probe, and a
productive change to a specialized resource are not critical errors. Keep an
anchor that already owns an unrecovered direct plan/Action contradiction,
explicit constraint violation, task-material unsupported state, or proven
execution impact.

TYPED LATER SEARCH

Only after the anchor falsification gate passes, scan Step anchor+1 onward in
strict chronology. For each Step, test these three boundary types and stop at
the earliest mature one across all types:

1. `state_truth`: the Step's Memory/Reflection drops or distorts a concrete
   adjacent-feedback fact necessary to the next decision, retains an
   unsupported task-material entity/value/relation, or literally contradicts
   the observed outcome/progress. The false state must feed the current or
   next decision, and local repair must change the later path.
2. `post_feedback_maturity`: after literal prior failure or zero task
   contribution, the Agent recommits to the same unresolved immediate
   predicate and the same evidence modality or extraction family without a
   new evidence dimension. An identical URL is unnecessary. A different
   source is materially different only when it can expose a different kind of
   evidence for that predicate. The owner is the post-feedback Agent Step, not
   the raw failure result.
3. `alignment`: the Step owns a direct plan-to-Action target/tool mismatch or
   a literal explicit user/source/constraint contradiction whose exact local
   repair can change the path.

VETOES AND CHRONOLOGY

Reject an initial or materially different probe, productive specialized-route
change, normal failure result, recovered defect, mechanical/local defect,
faithful propagation, and downstream symptom. Do not select a later boundary
because it is more severe, persistent, explicit, or strongly worded. The
proposal must be the earliest later Step for which type, maturity witness,
ownership, and independent repair all close. If any required fact is
uncertain, emit no_challenge.

Begin search_summary exactly:
`typed_boundary=<none|state_truth|post_feedback_maturity|alignment>; boundary_step=<none|Step>; maturity_witness_step=<none|Step>; `

For no_challenge, all three values must be `none`. For a challenge,
boundary_step must equal the proposed Step. state_truth and alignment use the
proposed Step as their maturity witness. post_feedback_maturity names the
strictly earlier Step whose literal result matured the repeated predicate and
evidence family. The rest of search_summary must state the immediate predicate,
the literal witness, why every intervening Step fails, and why all vetoes fail.

Use anchor_only_repair_counterfactual and proposal_only_repair_counterfactual
as separate interventions. direct_timeline_comparison must compare the anchor,
every intervening plausible boundary, and the proposal. The proposal must be a
complete legal prediction owned by its Step/module. When uncertain,
no_challenge.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_39_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_39_clean_v3p20_bounded_typed_boundary_challenger",
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py",
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_39_clean_v3p20_bounded_typed_boundary_challenger.py",
        )
    )


def _rewrite_challenger_mechanism(task: str) -> str:
    marker = incumbent_challenger._EARLIEST_CAUSAL_RULES
    if task.count(marker) != 1:
        raise RuntimeError("v3.20 challenger-rule marker changed unexpectedly")
    return task.replace(marker, _BOUNDED_TYPED_BOUNDARY_RULES, 1)


def build_anchor_task(*paths: str | Path) -> str:
    """Use exactly the v3.20 anchor semantics, with only identity retagged."""

    return _rewrite_identity(parent.build_anchor_task(*paths))


def build_challenger_task(*paths: str | Path) -> str:
    return _rewrite_identity(
        _rewrite_challenger_mechanism(parent.build_challenger_task(*paths))
    )


def build_arbiter_task(*paths: str | Path) -> str:
    """Use exactly the v3.20 default-keep exact-copy arbiter semantics."""

    return _rewrite_identity(parent.build_arbiter_task(*paths))


def build_agent_judge_luna_gaia_v3_39_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_39_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_39_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_39_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one bounded typed-boundary later challenger",
    }


def _validate_typed_boundary_challengers(path: str | Path) -> dict[str, Any]:
    challenger_path, raw = shared._load_artifact(
        path, role="bounded typed-boundary challenger"
    )
    rows = raw if isinstance(raw, list) else [raw]
    if not rows or any(not isinstance(row, dict) for row in rows):
        shared._fail("invalid_typed_boundary_challengers", "records unavailable")

    boundary_counts: Counter[str] = Counter()
    for index, row in enumerate(rows):
        location = f"challenger[{index}]"
        match = _TYPED_PREFIX.match(row.get("search_summary") or "")
        if match is None:
            shared._fail("missing_typed_boundary_prefix", location)
        boundary, step_text, witness_text = match.groups()
        boundary_step = None if step_text == "none" else int(step_text)
        witness_step = None if witness_text == "none" else int(witness_text)
        challenged = row.get("challenge_status") == "challenge"
        proposal = row.get("proposed_prediction")
        proposal_step = (
            proposal.get("predicted_step") if isinstance(proposal, dict) else None
        )

        if not challenged:
            if boundary != "none" or boundary_step is not None or witness_step is not None:
                shared._fail("nonempty_typed_boundary_without_challenge", location)
        else:
            if (
                boundary == "none"
                or boundary_step != proposal_step
                or witness_step is None
            ):
                shared._fail("incomplete_typed_boundary_for_challenge", location)
            if boundary in {"state_truth", "alignment"} and witness_step != proposal_step:
                shared._fail("same_step_typed_boundary_witness_mismatch", location)
            if boundary == "post_feedback_maturity" and witness_step >= proposal_step:
                shared._fail("post_feedback_witness_not_prior", location)
        boundary_counts[boundary] += 1

    return {
        "required": True,
        "valid": True,
        "path": str(challenger_path),
        "record_count": len(rows),
        "boundary_counts": dict(sorted(boundary_counts.items())),
        "maximum_proposals_per_case": 1,
        "strictly_later_only": True,
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths), policy="unchanged_v3_20_anchor")


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    audit = _retag(
        parent.validate_challenger(*paths),
        policy="bounded_typed_boundary_later_challenger",
    )
    audit["typed_boundary_contract"] = _validate_typed_boundary_challengers(paths[-1])
    return audit


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        parent.validate_arbiter(*paths),
        policy="unchanged_v3_20_default_keep_exact_copy_arbiter",
    )


def validate_agent_judge_luna_gaia_v3_39_predictions(
    *paths: str | Path,
) -> dict[str, Any]:
    audit = _retag(
        parent.validate_agent_judge_luna_gaia_v3_20_predictions(*paths),
        policy=(
            "clean_v3_20_anchor_one_bounded_typed_boundary_later_challenger_"
            "unchanged_default_keep_exact_copy_arbiter"
        ),
    )
    predictions = Path(paths[2]).expanduser().resolve()
    audit["schema_version"] = AGENT_JUDGE_LUNA_GAIA_V3_39_AUDIT_SCHEMA_VERSION
    audit["anchor_semantics_unchanged_from_v3_20"] = True
    audit["arbiter_semantics_unchanged_from_v3_20"] = True
    audit["typed_boundary_contract"] = _validate_typed_boundary_challengers(
        predictions.parent / CHALLENGERS_FILENAME
    )
    return audit


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return parent._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_39_audit(
    *paths: str | Path,
) -> dict[str, Any]:
    return _write(validate_agent_judge_luna_gaia_v3_39_predictions(*paths[:-1]), paths[-1])


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_39_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_39_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_39_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_39_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    args = parser.parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

"""Luna GAIA v3.43: clean v3.20 with one direction-factorized tournament."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions
from .taxonomy import taxonomy_prompt


AGENT_JUDGE_LUNA_GAIA_V3_43_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.43-clean-v3.20-"
    "direction-factorized-anchor-aware-challenger-tournament"
)
AGENT_JUDGE_LUNA_GAIA_V3_43_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_43_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_43_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases for the shared three-stage execution runner.
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_43_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_43_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_43_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_43_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_43_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_43_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_43_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
PANEL_FILENAME = "direction-challenger-panel.json"
PANELS_FILENAME = "direction-challenger-panels.json"
PANEL_AUDIT_FILENAME = "direction-challenger-panel-audit.json"
SELECTOR_FILENAME = "direction-tournament-selector.json"
SELECTORS_FILENAME = "direction-tournament-selectors.json"
SELECTOR_AUDIT_FILENAME = "direction-tournament-selector-audit.json"

DIRECTIONS = ("earlier", "later")
STATUSES = frozenset({"candidate", "none"})
CLASSIFICATIONS = frozenset(
    {
        "protected_direct_error",
        "reasonable_probe",
        "recovered_defect",
        "noncritical_predecessor",
        "downstream_symptom",
        "ambiguous",
    }
)
PANEL_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "anchor_prediction_sha256",
    "anchor_ledger_sha256",
    "anchor_checkpoint_sha256",
    "anchor_step",
    *(
        field
        for direction in DIRECTIONS
        for field in (
            f"{direction}_status",
            f"{direction}_step",
            f"{direction}_prediction",
            f"{direction}_anchor_classification",
            f"{direction}_search_summary",
            f"{direction}_candidate_certificate",
            f"{direction}_anchor_counterfactual",
            f"{direction}_falsifier",
        )
    ),
    "cross_direction_comparison",
)
SELECTOR_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "anchor_prediction_sha256",
    "anchor_ledger_sha256",
    "anchor_checkpoint_sha256",
    "panel_sha256",
    "anchor_step",
    "earlier_step",
    "later_step",
    "decision",
    "frozen_step",
    "selected_prediction_sha256",
    "selected_prediction",
    "anchor_assessment",
    "earlier_assessment",
    "later_assessment",
    "decision_basis",
    "rejected_alternative_basis",
)
SELECTOR_DECISIONS = frozenset({"keep_anchor", "select_earlier", "select_later"})


_PANEL_RULES = """\
DIRECTION-FACTORIZED ANCHOR-AWARE CHALLENGER — TWO STRICT LANES

The clean v3.20 anchor bundle is immutable. Inspect every Canonical Step in
chronology. Do not repair or rerun the anchor. Freeze at most ONE complete legal
prediction in each strict direction; never select a winner in this stage.

ANCHOR CLASSIFICATION

Independently in each lane classify the anchor as exactly one of:
protected_direct_error, reasonable_probe, recovered_defect,
noncritical_predecessor, downstream_symptom, or ambiguous. Direct unrecovered
execution impact, a literal explicit constraint contradiction, a consumed false
state, or a direct target/tool mismatch protects an anchor. A first or different
probe capable of contributing a necessary identifier/page/text/source/lead,
normal failure, successful/tolerated parameter representation, complete
recovery, faithful propagation, and terminal restatement do not.

STRICT-EARLIER LANE

Scan every Step strictly before anchor_step. Freeze the earliest independently
mature task-material Agent-owned boundary only when the anchor is a downstream
symptom/noncritical consequence and repairing the earlier boundary changes the
path while anchor-only repair leaves it. Require literal owner, immediate
predicate, evidence, and local repair. Reject reasonable probes, normal tool
outcomes, recovered/mechanical defects, faithful propagation, harmless state
compression, and position alone.

STRICT-LATER LANE

Scan every Step strictly after anchor_step. Freeze the earliest independently
mature task-material Agent-owned boundary only when the anchor is a reasonable
probe, recovered defect, noncritical predecessor, or otherwise fails the direct
impact test. The later boundary must remain after treating the observed anchor
probe/outcome as valid. Raw tool failure cannot own it. Repetition requires a
strictly prior literal negative/zero-contribution witness and no genuinely new
evidence dimension. Reject terminal symptoms and stronger wording alone.

CERTIFICATES

Each search_summary begins exactly `direction=<earlier|later>; anchor_step=<Step>;
candidate_step=<none|Step>; ` and certifies full directional coverage. Each
candidate_certificate names literal owner/predicate/evidence/repair, or explains
why none qualifies. Each anchor_counterfactual states whether anchor-only repair
removes the candidate. Each falsifier states the strongest concrete
counterargument. cross_direction_comparison checks independence and chronology
without choosing a winner. Never access labels, scores, prior predictions, case
reports, entity routers, fixed Steps, or external resources.
"""


_SELECTOR_RULES = """\
BOUNDED DIRECTION TOURNAMENT — CLEAN ANCHOR PLUS STRICT EARLIER/LATER

Select exactly one existing complete prediction: the clean v3.20 anchor or one
present direction candidate. Never invent, repair, merge, splice, majority-vote,
or change fields. Candidate absence is binding. Uncertainty keeps anchor.

1. Protect an anchor with direct unrecovered execution impact, literal explicit
   constraint contradiction, consumed false state, or direct target/tool mismatch.
2. Earlier wins only if it is an independently mature causal owner and the anchor
   is its downstream symptom/noncritical consequence; position alone never wins.
3. Later wins only if the anchor is a reasonable probe, recovered defect, normal
   failure, or noncritical predecessor, and the later Agent commitment remains
   critical on the observed continuation.
4. Require literal anchor-only repair counterfactuals. Keep anchor if repairing it
   removes the candidate or if candidate independence is not proven.
5. Reject initial/different probes, normal failures, recovery, mechanical defects,
   faithful propagation, harmless compression, downstream/terminal symptoms, and
   severity or persistence alone.

selected_prediction must be a field-for-field exact copy of the chosen input.
Assess every available alternative and state why each rejected boundary loses.
"""


def _rewrite_identity(task: str) -> str:
    return task.replace(
        parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        AGENT_JUDGE_LUNA_GAIA_V3_43_VERSION,
    ).replace(
        "agent_judge_luna_gaia_v3_20_packet_state_closure",
        "agent_judge_luna_gaia_v3_43_clean_v3p20_direction_factorized_anchor_aware_challenger_tournament",
    )


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_anchor_task(*paths))


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    audit = dict(parent.validate_anchor_predictions(*paths))
    audit.update(
        agent_judge_version=AGENT_JUDGE_LUNA_GAIA_V3_43_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_43_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_43_REASONING_EFFORT,
    )
    return audit


def _boundary(*, manifest: Path, cohort: Path, reads: Sequence[Path], output: Path) -> str:
    read_lines = "\n".join(f"- {path}" for path in reads) or "- none"
    return f"""\
IMMUTABLE EXECUTION CONFIGURATION
- model: {AGENT_JUDGE_LUNA_GAIA_V3_43_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_43_REASONING_EFFORT}
- one isolated case; fresh session; no cross-case state or prior predictions
- external LLM/API/network calls: forbidden
- scoring or label access: forbidden

INPUT/OUTPUT BOUNDARY
- prediction manifest: {manifest}
- prediction manifest file sha256: {shared._file_sha256(manifest)}
- cohort manifest: {cohort}
- cohort manifest file sha256: {shared._file_sha256(cohort)}
- permitted frozen stage inputs:
{read_lines}
- write the sole stage artifact only to: {output}

Read only those inputs plus this protocol source, the v3.20 protocol source,
and taxonomy.py. Do not inspect directories, names, labels, metrics, scored
artifacts, promotion files, experiments, old predictions, cached replies, case
studies, git history, or external resources.
"""


def _load_anchor_bundle(
    manifest: Path,
    cohort: Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> tuple[Path, Path, Path, dict[str, Any], dict[str, Any], dict[str, Any]]:
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    anchor, ledger, checkpoint = shared._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    parent._validate_packet_state_ledgers(ledger_file)
    return anchor_file, ledger_file, checkpoint_file, anchor, ledger, checkpoint


def _validate_panel_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != PANEL_FIELDS:
        shared._fail("invalid_direction_panel_schema", location)
    if raw["trajectory_id"] != case.trajectory_id or raw["trajectory_sha256"] != case.trajectory_sha256:
        shared._fail("direction_panel_identity_mismatch", location)
    bindings = {
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "anchor_step": anchor["predicted_step"],
    }
    if any(raw[key] != value for key, value in bindings.items()):
        shared._fail("direction_panel_anchor_binding_mismatch", location)
    anchor_step = anchor["predicted_step"]
    for direction in DIRECTIONS:
        status = raw[f"{direction}_status"]
        step = raw[f"{direction}_step"]
        prediction = raw[f"{direction}_prediction"]
        classification = raw[f"{direction}_anchor_classification"]
        summary = raw[f"{direction}_search_summary"]
        if status not in STATUSES or classification not in CLASSIFICATIONS:
            shared._fail("invalid_direction_panel_status", f"{location}.{direction}")
        prefix = (
            f"direction={direction}; anchor_step={anchor_step}; "
            f"candidate_step={step if status == 'candidate' else 'none'}; "
        )
        if not isinstance(summary, str) or not summary.startswith(prefix):
            shared._fail("invalid_direction_panel_summary", f"{location}.{direction}")
        for suffix in ("candidate_certificate", "anchor_counterfactual", "falsifier"):
            shared._nonempty_text(
                raw[f"{direction}_{suffix}"],
                location=f"{location}.{direction}_{suffix}",
                maximum=2800,
            )
        if status == "none":
            if step is not None or prediction is not None:
                shared._fail("nonempty_direction_none_lane", f"{location}.{direction}")
        else:
            if isinstance(step, bool) or not isinstance(step, int):
                shared._fail("invalid_direction_candidate_step", f"{location}.{direction}")
            if direction == "earlier" and step >= anchor_step:
                shared._fail("direction_candidate_not_strictly_earlier", location)
            if direction == "later" and step <= anchor_step:
                shared._fail("direction_candidate_not_strictly_later", location)
            validated = shared._validate_prediction_record(
                prediction, case=case, location=f"{location}.{direction}_prediction"
            )
            if validated["predicted_step"] != step:
                shared._fail("direction_candidate_step_mismatch", f"{location}.{direction}")
    shared._nonempty_text(
        raw["cross_direction_comparison"], location=f"{location}.cross", maximum=2800
    )
    return raw


def validate_panel(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    panel_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(manifest, cohort, anchor_path, ledger_path, checkpoint_path)
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger, checkpoint = bundle[3:]
    panel_file, raw = shared._load_artifact(panel_path, role="direction panel")
    panel = shared._one_record(raw, role="direction panel")
    _validate_panel_record(
        panel,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        location="direction_panel[0]",
    )
    return {
        "schema_version": "agentdebug.direction-panel-audit.v1",
        "stage": "anchor_aware_direction_factorized_panel",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_43_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_43_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_43_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": 1,
        "anchor_visible": True,
        "maximum_candidates": 2,
        "strict_direction_enforced": True,
        "direction_status": {d: panel[f"{d}_status"] for d in DIRECTIONS},
        "input_sha256": {
            "anchor": shared._file_sha256(anchor_file),
            "ledger": shared._file_sha256(ledger_file),
            "checkpoint": shared._file_sha256(checkpoint_file),
        },
        "output_sha256": {PANEL_FILENAME: shared._file_sha256(panel_file)},
    }


def build_panel_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    panel_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(manifest, cohort, anchor_path, ledger_path, checkpoint_path)
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger, checkpoint = bundle[3:]
    output = Path(panel_path).expanduser().resolve()
    shared._assert_safe_path(output, role="direction panel output", is_output=True)
    audit = output.parent / PANEL_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_43_clean_v3p20_direction_factorized_anchor_aware_challenger_tournament",
            "--compact-validate", "panel", manifest, cohort, anchor_file, ledger_file,
            checkpoint_file, output, audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    schema: dict[str, Any] = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "anchor_step": anchor["predicted_step"],
    }
    for direction in DIRECTIONS:
        schema.update(
            {
                f"{direction}_status": "candidate or none",
                f"{direction}_step": "strict-direction integer Step or null",
                f"{direction}_prediction": "complete legal prediction object or null",
                f"{direction}_anchor_classification": "one allowed anchor class",
                f"{direction}_search_summary": (
                    f"direction={direction}; anchor_step={anchor['predicted_step']}; "
                    "candidate_step=<none|Step>; coverage certificate"
                ),
                f"{direction}_candidate_certificate": "literal owner/predicate/evidence/repair or none basis",
                f"{direction}_anchor_counterfactual": "literal anchor-only repair result",
                f"{direction}_falsifier": "strongest concrete counterargument",
            }
        )
    schema["cross_direction_comparison"] = "independence and chronology without winner selection"
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_43_VERSION} stage 2/3: direction panel.

{_boundary(manifest=manifest, cohort=cohort, reads=(anchor_file, ledger_file, checkpoint_file), output=output)}

{_PANEL_RULES}

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

Every non-null prediction must use standard complete prediction fields in exact
order and quote literal evidence owned by its Step/module. After writing, run:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _validate_selector_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    panel: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != SELECTOR_FIELDS:
        shared._fail("invalid_direction_selector_schema", location)
    if raw["trajectory_id"] != case.trajectory_id or raw["trajectory_sha256"] != case.trajectory_sha256:
        shared._fail("direction_selector_identity_mismatch", location)
    bindings = {
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "panel_sha256": shared._stable_sha256(panel),
        "anchor_step": anchor["predicted_step"],
        "earlier_step": panel["earlier_step"],
        "later_step": panel["later_step"],
    }
    if any(raw[key] != value for key, value in bindings.items()):
        shared._fail("direction_selector_binding_mismatch", location)
    decision = raw["decision"]
    if decision not in SELECTOR_DECISIONS:
        shared._fail("invalid_direction_selector_decision", location)
    options = {
        "keep_anchor": anchor,
        "select_earlier": panel["earlier_prediction"],
        "select_later": panel["later_prediction"],
    }
    expected = options[decision]
    if expected is None:
        shared._fail("direction_selector_selected_absent", location)
    selected = shared._validate_prediction_record(
        raw["selected_prediction"], case=case, location=f"{location}.selected"
    )
    if selected != expected:
        shared._fail("direction_selector_copy_mismatch", location)
    if raw["selected_prediction_sha256"] != shared._stable_sha256(selected):
        shared._fail("direction_selector_selected_hash_mismatch", location)
    if raw["frozen_step"] != selected["predicted_step"]:
        shared._fail("direction_selector_frozen_step_mismatch", location)
    for field in (
        "anchor_assessment",
        "earlier_assessment",
        "later_assessment",
        "decision_basis",
        "rejected_alternative_basis",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=2800)
    return raw


def validate_selector(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    panel_path: str | Path,
    selector_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(manifest, cohort, anchor_path, ledger_path, checkpoint_path)
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger, checkpoint = bundle[3:]
    panel_file, panel_raw = shared._load_artifact(panel_path, role="direction panel")
    panel = shared._one_record(panel_raw, role="direction panel")
    _validate_panel_record(
        panel,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        location="direction_panel[0]",
    )
    selector_file, selector_raw = shared._load_artifact(selector_path, role="direction selector")
    selector = shared._one_record(selector_raw, role="direction selector")
    _validate_selector_record(
        selector,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        panel=panel,
        location="direction_selector[0]",
    )
    return {
        "schema_version": "agentdebug.direction-selector-audit.v1",
        "stage": "bounded_direction_exact_copy_tournament",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_43_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_43_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_43_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": 1,
        "decision": selector["decision"],
        "selected_prediction_exact_copy": True,
        "candidate_count_maximum": 3,
        "input_sha256": {
            "anchor": shared._file_sha256(anchor_file),
            "ledger": shared._file_sha256(ledger_file),
            "checkpoint": shared._file_sha256(checkpoint_file),
            "panel": shared._file_sha256(panel_file),
        },
        "output_sha256": {SELECTOR_FILENAME: shared._file_sha256(selector_file)},
    }


def build_selector_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    panel_path: str | Path,
    selector_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(manifest, cohort, anchor_path, ledger_path, checkpoint_path)
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger, checkpoint = bundle[3:]
    panel_file, panel_raw = shared._load_artifact(panel_path, role="direction panel")
    panel = shared._one_record(panel_raw, role="direction panel")
    _validate_panel_record(
        panel,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        location="direction_panel[0]",
    )
    output = Path(selector_path).expanduser().resolve()
    shared._assert_safe_path(output, role="direction selector output", is_output=True)
    audit = output.parent / SELECTOR_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_43_clean_v3p20_direction_factorized_anchor_aware_challenger_tournament",
            "--compact-validate", "selector", manifest, cohort, anchor_file, ledger_file,
            checkpoint_file, panel_file, output, audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    schema: dict[str, Any] = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "panel_sha256": shared._stable_sha256(panel),
        "anchor_step": anchor["predicted_step"],
        "earlier_step": panel["earlier_step"],
        "later_step": panel["later_step"],
        "decision": "keep_anchor or select_earlier or select_later",
        "frozen_step": "selected prediction Step",
        "selected_prediction_sha256": "stable JSON hash of exact selected prediction",
        "selected_prediction": "exact unchanged chosen prediction object",
        "anchor_assessment": "literal causal-boundary assessment",
        "earlier_assessment": "literal assessment or absent-candidate note",
        "later_assessment": "literal assessment or absent-candidate note",
        "decision_basis": "why the chosen exact boundary wins",
        "rejected_alternative_basis": "why every present alternative loses",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_43_VERSION} stage 3/3: direction tournament.

{_boundary(manifest=manifest, cohort=cohort, reads=(anchor_file, ledger_file, checkpoint_file, panel_file), output=output)}

{_SELECTOR_RULES}

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

Compute hashes as stable sorted compact JSON. After writing, run:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _validate_aggregate(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(prediction_manifest_path, cohort_manifest_path)
    root = Path(predictions_path).expanduser().resolve().parent
    names = (
        ANCHOR_PREDICTIONS_FILENAME,
        ANCHOR_LEDGER_AGGREGATE_FILENAME,
        ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        PANELS_FILENAME,
        SELECTORS_FILENAME,
    )
    loaded = {
        name: shared._load_artifact(root / name, role=f"merged {name}")[1]
        for name in names
    }
    if any(not isinstance(value, list) or len(value) != len(cases) for value in loaded.values()):
        shared._fail("invalid_direction_aggregate_count", "all artifacts need all cases")
    finals = shared._load_artifact(predictions_path, role="merged predictions")[1]
    if not isinstance(finals, list) or len(finals) != len(cases):
        shared._fail("invalid_direction_prediction_count", "predictions need all cases")
    direction_counts = {direction: Counter() for direction in DIRECTIONS}
    decisions: Counter[str] = Counter()
    for index, case in enumerate(cases):
        anchor = loaded[ANCHOR_PREDICTIONS_FILENAME][index]
        ledger = loaded[ANCHOR_LEDGER_AGGREGATE_FILENAME][index]
        checkpoint = loaded[ANCHOR_CHECKPOINT_AGGREGATE_FILENAME][index]
        panel = loaded[PANELS_FILENAME][index]
        selector = loaded[SELECTORS_FILENAME][index]
        location = f"direction_merged[{index}]"
        shared._validate_prediction_record(anchor, case=case, location=f"{location}.anchor")
        if (
            ledger.get("trajectory_id") != case.trajectory_id
            or ledger.get("selected_step") != anchor["predicted_step"]
            or checkpoint.get("trajectory_id") != case.trajectory_id
            or checkpoint.get("predicted_step") != anchor["predicted_step"]
        ):
            shared._fail("direction_anchor_sidecar_mismatch", location)
        _validate_panel_record(
            panel,
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            location=f"{location}.panel",
        )
        _validate_selector_record(
            selector,
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            panel=panel,
            location=f"{location}.selector",
        )
        final = shared._validate_prediction_record(
            finals[index], case=case, location=f"{location}.final"
        )
        if final != selector["selected_prediction"]:
            shared._fail("direction_final_copy_mismatch", location)
        for direction in DIRECTIONS:
            direction_counts[direction][panel[f"{direction}_status"]] += 1
        decisions[selector["decision"]] += 1
    return {
        "required": True,
        "valid": True,
        "anchor_aware_panel": True,
        "anchor_blind_panel": False,
        "maximum_specialist_candidates": 2,
        "maximum_total_predictions": 3,
        "strict_direction_enforced": True,
        "all_selected_predictions_exact_copies": True,
        "direction_status_counts": {
            direction: dict(sorted(counts.items()))
            for direction, counts in direction_counts.items()
        },
        "selector_decision_counts": dict(sorted(decisions.items())),
        "packet_state_closure": parent._validate_packet_state_ledgers(
            root / ANCHOR_LEDGER_AGGREGATE_FILENAME
        ),
    }


def validate_agent_judge_luna_gaia_v3_43_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    panel = _validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_43_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_43_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_43_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_43_REASONING_EFFORT,
        "selection_policy": "clean_v3_20_anchor_direction_factorized_exact_copy_tournament",
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one direction-factorized anchor-aware exact-copy tournament",
        "anchor_semantics_unchanged_from_v3_20": True,
        "all_selected_predictions_exact_copies": True,
        "factorized_specialist_panel": panel,
    }


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_panel(*paths[:-1]), paths[-1])


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_selector(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_43_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_43_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


validate_and_write_agent_judge_luna_gaia_v3_37_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_43_audit
)


def build_agent_judge_luna_gaia_v3_43_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_selector_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / PANEL_FILENAME,
        prediction.parent / SELECTOR_FILENAME,
    )


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_43_task
validate_agent_judge_luna_gaia_v3_13_predictions = validate_agent_judge_luna_gaia_v3_43_predictions
validate_and_write_agent_judge_luna_gaia_v3_13_audit = validate_and_write_agent_judge_luna_gaia_v3_43_audit


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "panel" and len(paths) == 7:
            audit = validate_and_write_panel_audit(*paths)
        elif stage == "selector" and len(paths) == 8:
            audit = validate_and_write_selector_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_43_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "panel", "selector", "prediction"))
    parser.add_argument("paths", nargs="+")
    args = parser.parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

"""Sol/Luna GAIA serial v2 with validator-owned Type evidence sources."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from . import agent_judge_luna_v3_serial as serial_v1
from . import agent_judge_luna_v3_serial_v2 as serial_v2
from . import agent_judge_sol_luna_gaia_serial as v1


AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_V2_VERSION = (
    "agentdebug.codex-agent-judge.sol-luna-gaia-serial-v2"
)
AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_V2_MODEL = v1.AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_MODEL
AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_V2_REASONING_EFFORT = (
    v1.AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_REASONING_EFFORT
)

STEP_DECISIONS_FILENAME = v1.STEP_DECISIONS_FILENAME
MODULE_DECISIONS_FILENAME = v1.MODULE_DECISIONS_FILENAME


def build_sol_luna_v2_module_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
) -> str:
    task = serial_v2.build_agent_judge_luna_v3_serial_v2_module_task(
        prediction_manifest_path,
        cohort_manifest_path,
        step_decisions_path,
        module_decisions_path,
    )
    task = task.replace(
        serial_v2.AGENT_JUDGE_LUNA_V3_SERIAL_V2_VERSION,
        AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_V2_VERSION,
    ).replace(
        "agentdebug.diagnostics.agent_judge_luna_v3_serial_v2 import "
        "validate_and_write_agent_judge_luna_v3_serial_v2_module_audit",
        "agentdebug.diagnostics.agent_judge_sol_luna_gaia_serial_v2 import "
        "validate_and_write_sol_luna_v2_serial_module_audit",
    )
    return task.replace(
        "\nSTRICT OUTPUT CONTRACT\n",
        f"\n{v1._MODULE_ADDITION}\nSTRICT OUTPUT CONTRACT\n",
        1,
    )


def build_sol_luna_v2_type_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
    predictions_path: str | Path,
) -> str:
    task = serial_v2.build_agent_judge_luna_v3_serial_v2_type_task(
        prediction_manifest_path,
        cohort_manifest_path,
        step_decisions_path,
        module_decisions_path,
        predictions_path,
    )
    task = task.replace(
        serial_v2.AGENT_JUDGE_LUNA_V3_SERIAL_V2_VERSION,
        AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_V2_VERSION,
    ).replace(
        "agentdebug.diagnostics.agent_judge_luna_v3_serial_v2 import "
        "validate_and_write_agent_judge_luna_v3_serial_v2_audit",
        "agentdebug.diagnostics.agent_judge_sol_luna_gaia_serial_v2 import "
        "validate_and_write_sol_luna_v2_serial_audit",
    )
    return task.replace(
        "\nLEGAL ERROR TYPES FOR THE FROZEN MODULE\n",
        f"\n{v1._TYPE_ADDITION}\nLEGAL ERROR TYPES FOR THE FROZEN MODULE\n",
        1,
    )


def build_sol_luna_v2_serial_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    output = Path(predictions_path).expanduser().resolve()
    return build_sol_luna_v2_type_task(
        prediction_manifest_path,
        cohort_manifest_path,
        output.parent / STEP_DECISIONS_FILENAME,
        output.parent / MODULE_DECISIONS_FILENAME,
        output,
    )


def validate_sol_luna_v2_serial_step_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
) -> dict[str, Any]:
    audit = serial_v2.validate_agent_judge_luna_v3_serial_v2_step_predictions(
        prediction_manifest_path, cohort_manifest_path, step_decisions_path
    )
    return _upgrade(audit)


def validate_sol_luna_v2_serial_module_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
) -> dict[str, Any]:
    audit = serial_v2.validate_agent_judge_luna_v3_serial_v2_module_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        step_decisions_path,
        module_decisions_path,
    )
    return _upgrade(audit)


def validate_sol_luna_v2_serial_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = serial_v2.validate_agent_judge_luna_v3_serial_v2_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return {
        **_upgrade(audit),
        "serial_stage_count": 4,
        "candidate_type_late_bound": True,
        "step_candidate_labels_hidden": True,
        "upstream_v1_decisions_reused_before_gold_access": True,
        "type_stage_replayed_for_every_case": True,
    }


def _upgrade(audit: dict[str, Any]) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_V2_VERSION,
        "model": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_V2_MODEL,
        "reasoning_effort": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_V2_REASONING_EFFORT,
        "deterministic_owner_sources_exposed_to_type_agent": True,
    }


def validate_and_write_sol_luna_v2_serial_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return serial_v1._write_audit(
        audit_path,
        validate_sol_luna_v2_serial_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
    )


def validate_and_write_sol_luna_v2_serial_module_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return serial_v1._write_audit(
        audit_path,
        validate_sol_luna_v2_serial_module_predictions(
            prediction_manifest_path,
            cohort_manifest_path,
            step_decisions_path,
            module_decisions_path,
        ),
    )


__all__ = [
    "AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_V2_MODEL",
    "AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_V2_REASONING_EFFORT",
    "AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_V2_VERSION",
    "MODULE_DECISIONS_FILENAME",
    "STEP_DECISIONS_FILENAME",
    "build_sol_luna_v2_module_task",
    "build_sol_luna_v2_serial_task",
    "build_sol_luna_v2_type_task",
    "validate_and_write_sol_luna_v2_serial_audit",
    "validate_and_write_sol_luna_v2_serial_module_audit",
    "validate_sol_luna_v2_serial_module_predictions",
    "validate_sol_luna_v2_serial_predictions",
    "validate_sol_luna_v2_serial_step_predictions",
]

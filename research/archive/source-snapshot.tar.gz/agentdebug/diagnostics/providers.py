"""HTTP LLM judge implementations.

Provider credentials are accepted in memory and never serialized into a
diagnostic or benchmark report.
"""

from __future__ import annotations

import json
import os
import socket
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from collections.abc import Callable
from typing import Any

from .models import CriticRequest, ModuleArbiterRequest, ModuleSpecialistRequest
from .prompts import arbiter_messages, critic_messages, specialist_messages


class JudgeTransportError(RuntimeError):
    """A provider failure whose message is safe to include in a report."""

    def __init__(
        self,
        code: str,
        message: str,
        *,
        status_code: int | None = None,
        retry_after: float | None = None,
    ) -> None:
        self.code = code
        self.safe_message = message
        self.status_code = status_code
        self.retry_after = retry_after
        super().__init__(message)


class _ProviderTelemetry:
    """Thread-safe, aggregate-only provider telemetry.

    The accumulator intentionally retains neither credentials nor request or
    response bodies.  ``request_input_chars`` counts message-content
    characters sent on every actual HTTP attempt, including retries.  This
    makes it useful as a conservative input-token estimate when a failed
    provider response does not include usage metadata.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._logical_completion_count = 0
        self._http_attempt_count = 0
        self._retry_count = 0
        self._request_input_chars = 0
        self._provider_usage_response_count = 0
        self._provider_usage_token_totals: Counter[str] = Counter()
        self._finish_reason_counts: Counter[str] = Counter()

    def record_logical_completion(self) -> None:
        with self._lock:
            self._logical_completion_count += 1

    def record_http_attempt(
        self,
        *,
        input_chars: int,
        is_retry: bool,
    ) -> None:
        with self._lock:
            self._http_attempt_count += 1
            self._request_input_chars += input_chars
            if is_retry:
                self._retry_count += 1

    def record_provider_response(
        self,
        *,
        usage: Any,
        finish_reason: Any,
    ) -> None:
        normalized_usage = _normalized_usage_tokens(usage)
        normalized_finish_reason = (
            finish_reason.strip()
            if isinstance(finish_reason, str) and finish_reason.strip()
            else None
        )
        with self._lock:
            if isinstance(usage, dict):
                self._provider_usage_response_count += 1
                self._provider_usage_token_totals.update(normalized_usage)
            if normalized_finish_reason is not None:
                self._finish_reason_counts[normalized_finish_reason] += 1

    def snapshot(self) -> dict[str, Any]:
        """Return a JSON-safe copy containing aggregate counters only."""

        with self._lock:
            return {
                "logical_completion_count": self._logical_completion_count,
                "http_attempt_count": self._http_attempt_count,
                "retry_count": self._retry_count,
                "request_input_chars": self._request_input_chars,
                "provider_usage_response_count": (
                    self._provider_usage_response_count
                ),
                "provider_usage_token_totals": {
                    key: self._provider_usage_token_totals.get(key, 0)
                    for key in ("input_tokens", "output_tokens", "total_tokens")
                },
                "finish_reason_counts": dict(
                    sorted(self._finish_reason_counts.items())
                ),
            }


def _nonnegative_int(value: Any) -> int | None:
    # bool is an int subclass but never represents a token count.
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        return None
    return value


def _first_token_count(usage: dict[str, Any], *keys: str) -> int | None:
    for key in keys:
        value = _nonnegative_int(usage.get(key))
        if value is not None:
            return value
    return None


def _normalized_usage_tokens(usage: Any) -> dict[str, int]:
    """Normalize common OpenAI and Gemini token-usage field names."""

    if not isinstance(usage, dict):
        return {}
    aliases = {
        "input_tokens": ("input_tokens", "prompt_tokens", "promptTokenCount"),
        "output_tokens": (
            "output_tokens",
            "completion_tokens",
            "candidatesTokenCount",
        ),
        "total_tokens": ("total_tokens", "totalTokenCount"),
    }
    normalized: dict[str, int] = {}
    for destination, source_keys in aliases.items():
        value = _first_token_count(usage, *source_keys)
        if value is not None:
            normalized[destination] = value
    return normalized


def _request_input_chars(messages: list[dict[str, str]]) -> int:
    """Count prompt characters without retaining any prompt content."""

    return sum(
        len(content)
        for message in messages
        if isinstance(message, dict)
        and isinstance((content := message.get("content")), str)
    )


def _provider_error(error: urllib.error.HTTPError) -> JudgeTransportError:
    """Convert an HTTP error into a stable, non-sensitive failure."""

    provider_code = ""
    provider_message = ""
    retry_after: float | None = None
    try:
        retry_after = float(error.headers.get("Retry-After"))
    except (AttributeError, TypeError, ValueError):
        pass
    try:
        error_payload = json.loads(error.read().decode("utf-8"))
        if isinstance(error_payload, dict):
            error_object = error_payload.get("error", {})
            if isinstance(error_object, dict):
                provider_code = str(
                    error_object.get("code")
                    or error_object.get("type")
                    or error_object.get("status")
                    or ""
                )
                provider_message = str(error_object.get("message") or "")
            # Sophnet's Gemini and OpenAI-compatible gateways put some
            # validation errors in a top-level ``message`` rather than the
            # usual ``error.message`` object.
            provider_code = provider_code or str(
                error_payload.get("code")
                or error_payload.get("status")
                or ""
            )
            provider_message = provider_message or str(
                error_payload.get("message") or ""
            )
    except (UnicodeDecodeError, json.JSONDecodeError, AttributeError):
        pass

    normalized_code = provider_code.casefold()
    normalized_message = provider_message.casefold()
    combined = f"{normalized_code} {normalized_message}"
    context_failure = (
        (
            "context" in combined
            and any(
                marker in combined
                for marker in ("length", "window", "token", "maximum", "exceed")
            )
        )
        or "too many tokens" in combined
        or (
            "maximum" in combined
            and "tokens" in combined
            and "messages resulted in" in combined
        )
    )
    response_format_failure = (
        error.code in {400, 404, 422}
        and "response_format" in combined
        and any(
            marker in combined
            for marker in (
                "not support",
                "unsupported",
                "unknown",
                "unrecognized",
                "invalid parameter",
                "extra inputs",
            )
        )
    )
    if error.code == 429:
        code = "rate_limit"
        message = "The judge endpoint rate-limited the request."
    elif context_failure:
        code = "context_length_exceeded"
        message = "The judge request exceeds the model context window."
    elif response_format_failure:
        code = "unsupported_response_format"
        message = (
            "The judge endpoint does not support response_format=json_object."
        )
    elif 500 <= error.code < 600:
        code = "server_error"
        message = f"The judge endpoint returned transient HTTP {error.code}."
    else:
        code = "http_error"
        message = f"The judge endpoint returned HTTP {error.code}."
    return JudgeTransportError(
        code,
        message,
        status_code=error.code,
        retry_after=retry_after,
    )


def _post_json(
    *,
    endpoint: str,
    api_key: str,
    body: dict[str, Any],
    timeout: float,
    on_attempt: Callable[[], None] | None = None,
) -> Any:
    request = urllib.request.Request(
        endpoint,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        method="POST",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
    )
    if on_attempt is not None:
        on_attempt()
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload_bytes = response.read()
    except urllib.error.HTTPError as error:
        raise _provider_error(error) from None
    except urllib.error.URLError as error:
        reason = error.reason
        code = "timeout" if isinstance(reason, TimeoutError) else "network_error"
        raise JudgeTransportError(
            code,
            "The judge request timed out."
            if code == "timeout"
            else "The judge endpoint could not be reached.",
        ) from None
    except (TimeoutError, socket.timeout):
        raise JudgeTransportError(
            "timeout",
            "The judge request timed out.",
        ) from None

    try:
        return json.loads(payload_bytes.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise JudgeTransportError(
            "invalid_provider_response",
            "The judge endpoint returned a non-JSON response.",
        ) from None


def _with_retries(
    operation: Callable[[bool], str],
    *,
    max_retries: int,
    retry_backoff: float,
) -> str:
    for attempt in range(max_retries + 1):
        try:
            return operation(attempt > 0)
        except JudgeTransportError as error:
            retryable = error.code in {
                "rate_limit",
                "timeout",
                "network_error",
                "server_error",
                "unsupported_response_format",
            }
            if not retryable or attempt >= max_retries:
                raise
            delay = (
                error.retry_after
                if error.retry_after is not None
                else retry_backoff * (2**attempt)
            )
            if delay > 0:
                time.sleep(delay)
    raise AssertionError("unreachable judge retry state")


def _api_key(api_key_env: str) -> str:
    if not api_key_env or "=" in api_key_env:
        raise ValueError("judge API key environment-variable name is invalid")
    api_key = os.environ.get(api_key_env)
    if not api_key:
        raise ValueError(
            f"judge API key environment variable {api_key_env!r} is not set"
        )
    return api_key


def _validate_common(
    *,
    endpoint: str,
    model: str,
    temperature: float,
    timeout: float,
    max_output_tokens: int,
    max_retries: int,
    retry_backoff: float,
) -> None:
    if not model.strip():
        raise ValueError("judge model must not be empty")
    if timeout <= 0:
        raise ValueError("judge timeout must be positive")
    if max_output_tokens < 1:
        raise ValueError("judge max_output_tokens must be positive")
    if not 0.0 <= temperature <= 2.0:
        raise ValueError("judge temperature must be between 0 and 2")
    if max_retries < 0:
        raise ValueError("judge max_retries must not be negative")
    if retry_backoff < 0:
        raise ValueError("judge retry_backoff must not be negative")
    parsed = urllib.parse.urlparse(endpoint)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("judge URL must be an absolute HTTP(S) URL")


def resolve_judge_endpoint(
    *,
    provider: str,
    base_url: str,
    model: str,
) -> str:
    """Resolve a public endpoint without loading an API credential."""

    normalized = base_url.rstrip("/")
    if provider == "openai-compatible":
        return (
            normalized
            if normalized.endswith("/chat/completions")
            else f"{normalized}/chat/completions"
        )
    if provider == "gemini-generate-content":
        if normalized.endswith(":generateContent"):
            return normalized
        if "/models/" in urllib.parse.urlparse(normalized).path:
            return f"{normalized}:generateContent"
        escaped_model = urllib.parse.quote(model, safe="-._")
        return f"{normalized}/models/{escaped_model}:generateContent"
    raise ValueError(f"unsupported judge provider: {provider!r}")


def _strict_json_object_suffix(value: Any) -> str | None:
    """Return only a complete JSON-object suffix from reasoning content.

    This is a transport-format recovery, not semantic parsing.  Free-form
    reasoning is never returned or persisted, and an embedded/example object
    followed by more text is not accepted.
    """

    if not isinstance(value, str) or not value.strip():
        return None
    stripped = value.strip()
    for offset in range(len(stripped) - 1, -1, -1):
        if stripped[offset] != "{":
            continue
        candidate = stripped[offset:]
        try:
            parsed = json.loads(candidate)
        except (TypeError, ValueError):
            continue
        if isinstance(parsed, dict):
            return candidate
    return None


class OpenAICompatibleJudge:
    """Module-specialist judge backed by a ``/chat/completions`` endpoint."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key_env: str,
        model: str,
        temperature: float = 0.0,
        timeout: float = 120.0,
        max_output_tokens: int = 8192,
        max_retries: int = 0,
        retry_backoff: float = 2.0,
        thinking_mode: str | None = None,
        request_body_mode: str | None = None,
    ) -> None:
        self.endpoint = resolve_judge_endpoint(
            provider="openai-compatible",
            base_url=base_url,
            model=model,
        )
        _validate_common(
            endpoint=self.endpoint,
            model=model,
            temperature=temperature,
            timeout=timeout,
            max_output_tokens=max_output_tokens,
            max_retries=max_retries,
            retry_backoff=retry_backoff,
        )
        self._api_key = _api_key(api_key_env)
        self.model = model
        self.temperature = float(temperature)
        self.timeout = float(timeout)
        self.max_output_tokens = int(max_output_tokens)
        self.max_retries = int(max_retries)
        self.retry_backoff = float(retry_backoff)
        if thinking_mode not in {None, "enabled", "disabled"}:
            raise ValueError(
                "thinking_mode must be 'enabled', 'disabled', or None"
            )
        self.thinking_mode = thinking_mode
        if request_body_mode not in {None, "default"}:
            raise ValueError(
                "request_body_mode must be 'default' or None"
            )
        if request_body_mode == "default" and thinking_mode is not None:
            raise ValueError(
                "default request_body_mode cannot set thinking_mode"
            )
        self.request_body_mode = request_body_mode
        self._telemetry = _ProviderTelemetry()
        self._capability_lock = threading.Lock()
        self._response_format_capability = (
            "not_requested" if request_body_mode == "default" else "unknown"
        )
        self._response_format_fallback_count = 0
        self._reasoning_content_json_suffix_fallback_count = 0

    def _json_response_format_request(self) -> tuple[bool, bool]:
        """Return whether to request JSON mode and whether this is a probe.

        The second flag is captured atomically with the capability state so a
        non-JSON HTTP 2xx envelope can trigger fallback only for a request
        that was actually sent while the capability was unknown.
        """

        with self._capability_lock:
            return (
                self._response_format_capability != "unsupported",
                self._response_format_capability == "unknown",
            )

    def _record_json_response_format_supported(self) -> None:
        with self._capability_lock:
            if self._response_format_capability == "unknown":
                self._response_format_capability = "supported"

    def _record_json_response_format_unsupported(
        self,
        *,
        require_unknown: bool = False,
    ) -> bool:
        with self._capability_lock:
            if (
                require_unknown
                and self._response_format_capability != "unknown"
            ):
                return False
            if self._response_format_capability == "unsupported":
                return True
            self._response_format_capability = "unsupported"
            self._response_format_fallback_count += 1
            return True

    def _complete_once(
        self,
        messages: list[dict[str, str]],
        *,
        input_chars: int,
        is_retry: bool,
    ) -> str:
        body: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
        }
        if self.request_body_mode != "default":
            body["temperature"] = self.temperature
            body["max_tokens"] = self.max_output_tokens
            if self.thinking_mode is not None:
                body["thinking"] = {"type": self.thinking_mode}
        use_response_format, probing_response_format = (
            (False, False)
            if self.request_body_mode == "default"
            else self._json_response_format_request()
        )
        if use_response_format:
            body["response_format"] = {"type": "json_object"}
        try:
            payload = _post_json(
                endpoint=self.endpoint,
                api_key=self._api_key,
                body=body,
                timeout=self.timeout,
                on_attempt=lambda: self._telemetry.record_http_attempt(
                    input_chars=input_chars,
                    is_retry=is_retry,
                ),
            )
        except JudgeTransportError as error:
            if (
                use_response_format
                and error.code == "unsupported_response_format"
            ):
                self._record_json_response_format_unsupported()
                raise
            if (
                probing_response_format
                and error.code == "invalid_provider_response"
                and self._record_json_response_format_unsupported(
                    require_unknown=True
                )
            ):
                raise JudgeTransportError(
                    "unsupported_response_format",
                    "The judge endpoint returned a non-JSON response while "
                    "probing response_format=json_object.",
                ) from None
            raise
        try:
            choice = payload["choices"][0]
        except (KeyError, IndexError, TypeError):
            raise JudgeTransportError(
                "invalid_provider_response",
                "The judge endpoint response has no assistant message content.",
            ) from None
        finish_reason = (
            choice.get("finish_reason") if isinstance(choice, dict) else None
        )
        self._telemetry.record_provider_response(
            usage=payload.get("usage") if isinstance(payload, dict) else None,
            finish_reason=finish_reason,
        )
        if (
            isinstance(finish_reason, str)
            and finish_reason.strip().casefold() == "length"
        ):
            raise JudgeTransportError(
                "output_truncated",
                "The judge response was truncated at the output-token limit.",
            )
        try:
            message = choice["message"]
            content = message["content"]
        except (KeyError, TypeError):
            raise JudgeTransportError(
                "invalid_provider_response",
                "The judge endpoint response has no assistant message content.",
            ) from None
        if not isinstance(content, str):
            raise JudgeTransportError(
                "invalid_provider_response",
                "The judge endpoint assistant content is not text.",
            )
        if not content.strip() and isinstance(message, dict):
            recovered = _strict_json_object_suffix(
                message.get("reasoning_content")
            )
            if recovered is not None:
                content = recovered
                with self._capability_lock:
                    self._reasoning_content_json_suffix_fallback_count += 1
        if use_response_format:
            self._record_json_response_format_supported()
        return content

    def complete(self, messages: list[dict[str, str]]) -> str:
        """Return one completion, retrying only transient transport failures."""

        input_chars = _request_input_chars(messages)
        self._telemetry.record_logical_completion()
        return _with_retries(
            lambda is_retry: self._complete_once(
                messages,
                input_chars=input_chars,
                is_retry=is_retry,
            ),
            max_retries=self.max_retries,
            retry_backoff=self.retry_backoff,
        )

    def telemetry_snapshot(self) -> dict[str, Any]:
        """Return aggregate transport telemetry safe for reports."""

        return self._telemetry.snapshot()

    def capability_snapshot(self) -> dict[str, Any]:
        """Report JSON-mode detection without retaining payload content."""

        with self._capability_lock:
            value: dict[str, Any] = {
                "response_format_json_object": (
                    self._response_format_capability
                ),
                "response_format_fallback_count": (
                    self._response_format_fallback_count
                ),
                "fallback_output_contract": "strict_json_prompt",
            }
            if self.thinking_mode is not None:
                value["thinking_mode"] = self.thinking_mode
            if self.request_body_mode is not None:
                value["request_body_mode"] = self.request_body_mode
            if self._reasoning_content_json_suffix_fallback_count:
                value["reasoning_content_json_suffix_fallback_count"] = (
                    self._reasoning_content_json_suffix_fallback_count
                )
            return value

    def analyze_module(self, request: ModuleSpecialistRequest) -> str:
        return self.complete(specialist_messages(request))

    def arbitrate_root_cause(self, request: ModuleArbiterRequest) -> str:
        return self.complete(arbiter_messages(request))

    def critique_root_cause(self, request: CriticRequest) -> str:
        return self.complete(critic_messages(request))


class GeminiGenerateContentJudge:
    """Module-specialist judge backed by a Gemini endpoint."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key_env: str,
        model: str,
        temperature: float = 0.0,
        timeout: float = 120.0,
        max_output_tokens: int = 8192,
        max_retries: int = 0,
        retry_backoff: float = 2.0,
    ) -> None:
        self.endpoint = resolve_judge_endpoint(
            provider="gemini-generate-content",
            base_url=base_url,
            model=model,
        )
        _validate_common(
            endpoint=self.endpoint,
            model=model,
            temperature=temperature,
            timeout=timeout,
            max_output_tokens=max_output_tokens,
            max_retries=max_retries,
            retry_backoff=retry_backoff,
        )
        self._api_key = _api_key(api_key_env)
        self.model = model
        self.temperature = float(temperature)
        self.timeout = float(timeout)
        self.max_output_tokens = int(max_output_tokens)
        self.max_retries = int(max_retries)
        self.retry_backoff = float(retry_backoff)
        self._telemetry = _ProviderTelemetry()

    @staticmethod
    def _request_body(
        messages: list[dict[str, str]],
        *,
        temperature: float,
        max_output_tokens: int,
    ) -> dict[str, Any]:
        system_parts: list[dict[str, str]] = []
        contents: list[dict[str, Any]] = []
        for message in messages:
            role = message.get("role")
            content = message.get("content")
            if not isinstance(content, str):
                raise TypeError("judge message content must be text")
            if role == "system":
                system_parts.append({"text": content})
                continue
            gemini_role = "model" if role in {"assistant", "model"} else "user"
            contents.append(
                {
                    "role": gemini_role,
                    "parts": [{"text": content}],
                }
            )
        if not contents:
            raise ValueError("Gemini judge request has no non-system content")
        body: dict[str, Any] = {
            "contents": contents,
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_output_tokens,
                "responseMimeType": "application/json",
            },
        }
        if system_parts:
            body["systemInstruction"] = {"parts": system_parts}
        return body

    def _complete_once(
        self,
        messages: list[dict[str, str]],
        *,
        input_chars: int,
        is_retry: bool,
    ) -> str:
        body = self._request_body(
            messages,
            temperature=self.temperature,
            max_output_tokens=self.max_output_tokens,
        )
        payload = _post_json(
            endpoint=self.endpoint,
            api_key=self._api_key,
            body=body,
            timeout=self.timeout,
            on_attempt=lambda: self._telemetry.record_http_attempt(
                input_chars=input_chars,
                is_retry=is_retry,
            ),
        )
        try:
            candidates = payload["candidates"]
            candidate = candidates[0]
            parts = candidate["content"]["parts"]
            text_parts = [
                part["text"]
                for part in parts
                if isinstance(part, dict) and isinstance(part.get("text"), str)
            ]
        except (KeyError, IndexError, TypeError):
            candidate = None
            text_parts = []
        finish_reason = (
            candidate.get("finishReason")
            if isinstance(candidate, dict)
            else None
        )
        self._telemetry.record_provider_response(
            usage=(
                payload.get("usageMetadata")
                if isinstance(payload, dict)
                else None
            ),
            finish_reason=finish_reason,
        )
        if (
            isinstance(finish_reason, str)
            and finish_reason.strip().casefold() in {"max_tokens", "length"}
        ):
            raise JudgeTransportError(
                "output_truncated",
                "The Gemini judge response was truncated at the "
                "output-token limit.",
            )
        if not text_parts:
            raise JudgeTransportError(
                "invalid_provider_response",
                "The Gemini judge response has no candidate text.",
            )
        return "".join(text_parts)

    def complete(self, messages: list[dict[str, str]]) -> str:
        """Return one Gemini completion with transient-failure retries."""

        input_chars = _request_input_chars(messages)
        self._telemetry.record_logical_completion()
        return _with_retries(
            lambda is_retry: self._complete_once(
                messages,
                input_chars=input_chars,
                is_retry=is_retry,
            ),
            max_retries=self.max_retries,
            retry_backoff=self.retry_backoff,
        )

    def telemetry_snapshot(self) -> dict[str, Any]:
        """Return aggregate transport telemetry safe for reports."""

        return self._telemetry.snapshot()

    def capability_snapshot(self) -> dict[str, Any]:
        """Report the JSON response mode configured for Gemini."""

        return {
            "response_mime_type_application_json": "configured",
            "response_format_fallback_count": 0,
            "fallback_output_contract": "strict_json_prompt",
        }

    def analyze_module(self, request: ModuleSpecialistRequest) -> str:
        return self.complete(specialist_messages(request))

    def arbitrate_root_cause(self, request: ModuleArbiterRequest) -> str:
        return self.complete(arbiter_messages(request))

    def critique_root_cause(self, request: CriticRequest) -> str:
        return self.complete(critic_messages(request))

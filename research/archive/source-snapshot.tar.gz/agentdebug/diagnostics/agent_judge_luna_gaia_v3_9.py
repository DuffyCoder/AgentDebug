"""Luna GAIA v3.9: v3.4 plus static-document capability/outcome separation."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
)
from .agent_judge_luna_gaia_v3 import STEP_FREEZE_FIELDS, STEP_FREEZE_FILENAME
from .agent_judge_luna_gaia_v3_4 import (
    AGENT_JUDGE_LUNA_GAIA_V3_4_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_LUNA_GAIA_V3_4_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_4_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_4_VERSION,
    STEP_CANDIDATE_LEDGER_FIELDS,
    STEP_CANDIDATE_LEDGER_FILENAME,
    STEP_CANDIDATE_LANES,
    STEP_CANDIDATE_ROW_FIELDS,
    STEP_CANDIDATE_STATUSES,
    build_agent_judge_luna_gaia_v3_4_task,
    validate_agent_judge_luna_gaia_v3_4_predictions,
)


AGENT_JUDGE_LUNA_GAIA_V3_9_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.9"
)
AGENT_JUDGE_LUNA_GAIA_V3_9_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_4_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_9_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_4_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_9_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_4_AUDIT_SCHEMA_VERSION
)


_STATIC_DOCUMENT_CAPABILITY_GATE = """\
STATIC-DOCUMENT CAPABILITY / OUTCOME SEPARATION

Apply this rule only inside Lane B when considering Planning
`impossible_action`. It changes no Lane-A fact audit, source or output
constraint, prerequisite check, Action validation, System packet ordering,
recovery veto, Lane-C strategy decision, same-step owner, or taxonomy rule.

When the current plan assigns retrieval of text from a specific static
document or PDF URL to the documented URL text extractor, the plan is ex-ante
capable. A successful invocation of that interface can expose the assigned
static text. A normal result containing raw PDF bytes, unreadable document
bytes, empty extracted text, or other unhelpful content is an outcome; it
cannot retroactively make that current plan `impossible_action`. Keep the row's
Lane B clear and audit any later Memory/Reflection claim about what the result
contained in Lane A at the step where that claim is made.

This is deliberately narrow. Do not extend it to:

- dynamic video/audio, frames, narration, captions, or timestamp ordering;
- interactive database/UI state, flags, filters, timelines, or hidden events;
- general web discovery, snippets, mirrors, targets, or citations;
- a specialized corpus asked for another database's records;
- a computation whose required task-specific input is absent;
- a malformed Action, hard source constraint, or literal external exception.

Do not infer static-document capability merely because a URL exists. The plan
must explicitly assign static document/PDF text retrieval to the URL text
extractor. Record that ex-ante assignment, separately from the observed
outcome, in the row's `decision_basis`.

"""


def build_agent_judge_luna_gaia_v3_9_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build v3.4 with one narrow static-document capability rule."""

    task = build_agent_judge_luna_gaia_v3_4_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    task = task.replace(
        AGENT_JUDGE_LUNA_GAIA_V3_4_VERSION,
        AGENT_JUDGE_LUNA_GAIA_V3_9_VERSION,
    )
    task = task.replace(
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_4.py",
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_9.py",
    )
    task = task.replace(
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_4 import "
        "validate_and_write_agent_judge_luna_gaia_v3_4_audit as run",
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_9 import "
        "validate_and_write_agent_judge_luna_gaia_v3_9_audit as run",
    )
    lane_c = "LANE C — STRATEGY EPOCHS AND TERMINAL ABANDONMENT\n"
    if task.count(lane_c) != 1:
        raise RuntimeError("Luna GAIA v3.4 lane-C boundary changed unexpectedly")
    return task.replace(lane_c, _STATIC_DOCUMENT_CAPABILITY_GATE + lane_c, 1)


def validate_agent_judge_luna_gaia_v3_9_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_4_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_9_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_9_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_9_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_9_REASONING_EFFORT,
        "selection_policy": (
            "lane_ordered_chronology_validated_step_candidate_ledger_"
            "limited_recovery_veto_external_exception_packet_fence_"
            "static_document_capability_outcome_separation"
        ),
        "static_document_capability_gate": (
            "url_text_extractor_static_document_ex_ante_capability"
        ),
    }


def validate_and_write_agent_judge_luna_gaia_v3_9_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_9_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


__all__ = [
    "AGENT_JUDGE_LUNA_GAIA_V3_9_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_GAIA_V3_9_MODEL",
    "AGENT_JUDGE_LUNA_GAIA_V3_9_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_GAIA_V3_9_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "STEP_CANDIDATE_LEDGER_FIELDS",
    "STEP_CANDIDATE_LEDGER_FILENAME",
    "STEP_CANDIDATE_LANES",
    "STEP_CANDIDATE_ROW_FIELDS",
    "STEP_CANDIDATE_STATUSES",
    "STEP_FREEZE_FIELDS",
    "STEP_FREEZE_FILENAME",
    "build_agent_judge_luna_gaia_v3_9_task",
    "validate_agent_judge_luna_gaia_v3_9_predictions",
    "validate_and_write_agent_judge_luna_gaia_v3_9_audit",
]

"""GAIA v3.96: clean-v3.83 tournament with normalized access auditing."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge_gaia_v3_95_gpt55_dual_stage_response_only_audited_tournament import *  # noqa: F403
from . import agent_judge_gaia_v3_83_clean_v3p20_model_only_gpt55_medium as incumbent
from . import (
    agent_judge_gaia_v3_95_gpt55_dual_stage_response_only_audited_tournament as template,
)


AGENT_JUDGE_GAIA_V3_96_VERSION = (
    "agentdebug.codex-agent-judge.gaia-v3.96-gpt55-normalized-access-audited-"
    "predicate-handoff-tournament"
)
AGENT_JUDGE_GAIA_V3_96_MODEL = incumbent.AGENT_JUDGE_GAIA_V3_83_MODEL
AGENT_JUDGE_GAIA_V3_96_REASONING_EFFORT = incumbent.AGENT_JUDGE_GAIA_V3_83_REASONING_EFFORT
AGENT_JUDGE_GAIA_V3_96_AUDIT_SCHEMA_VERSION = incumbent.AGENT_JUDGE_GAIA_V3_83_AUDIT_SCHEMA_VERSION
SEMANTIC_PARENT = incumbent.AGENT_JUDGE_GAIA_V3_83_VERSION

# Compatibility names used by the inherited, already-validated tournament stack.
AGENT_JUDGE_GAIA_V3_95_VERSION = AGENT_JUDGE_GAIA_V3_96_VERSION
AGENT_JUDGE_GAIA_V3_95_MODEL = AGENT_JUDGE_GAIA_V3_96_MODEL
AGENT_JUDGE_GAIA_V3_95_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_96_REASONING_EFFORT
AGENT_JUDGE_GAIA_V3_93_VERSION = AGENT_JUDGE_GAIA_V3_96_VERSION
AGENT_JUDGE_GAIA_V3_93_MODEL = AGENT_JUDGE_GAIA_V3_96_MODEL
AGENT_JUDGE_GAIA_V3_93_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_96_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION = AGENT_JUDGE_GAIA_V3_96_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_80_MODEL = AGENT_JUDGE_GAIA_V3_96_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_80_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_96_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_79_VERSION = AGENT_JUDGE_GAIA_V3_96_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_79_MODEL = AGENT_JUDGE_GAIA_V3_96_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_79_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_96_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION = AGENT_JUDGE_GAIA_V3_96_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL = AGENT_JUDGE_GAIA_V3_96_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_96_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_GAIA_V3_96_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_GAIA_V3_96_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_96_REASONING_EFFORT


def _normalized_command_task(task: str) -> str:
    value = task.replace(template.AGENT_JUDGE_GAIA_V3_95_VERSION, AGENT_JUDGE_GAIA_V3_96_VERSION)
    old = (
        "- Each tool call must be exactly ONE of the listed `python inspect_case.py ...`\n"
        "  commands wrapped by `/bin/bash -lc`. Never combine inspector subcommands."
    )
    new = (
        "- Submit exactly ONE listed `python inspect_case.py ...` command as the tool-call\n"
        "  command text. Do NOT type `/bin/bash -lc`; the runtime may record its own strict\n"
        "  shell wrapper. Never combine inspector subcommands."
    )
    if value.count(old) != 1:
        raise RuntimeError("normalized access command-contract marker changed unexpectedly")
    return value.replace(old, new, 1)


def build_anchor_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> str:
    return _normalized_command_task(
        template.build_anchor_file_task(prediction_manifest_path, cohort_manifest_path)
    )


def build_reducer_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> str:
    return _normalized_command_task(
        template.build_reducer_file_task(
            prediction_manifest_path,
            cohort_manifest_path,
            anchor_path,
            ledger_path,
            checkpoint_path,
        )
    )


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_GAIA_V3_96_VERSION,
        "model": AGENT_JUDGE_GAIA_V3_96_MODEL,
        "reasoning_effort": AGENT_JUDGE_GAIA_V3_96_REASONING_EFFORT,
        "selection_policy": policy,
        "semantic_parent": SEMANTIC_PARENT,
        "direct_semantic_parent": SEMANTIC_PARENT,
        "rejected_lineage_inherited": False,
        "explicit_mechanism_sources_only": [
            "v3.80 predicate-handoff tournament",
            "v3.92 Step-invariant legality contract",
        ],
        "single_major_change": (
            "replace accepted v3.83 challenger/arbiter with one outcome-conditioned "
            "predicate-handoff tournament over every native v3.83 ledger Step"
        ),
        "normalized_shell_wrapper_access_audit": True,
        "singleton_structural_keep_access_exemption": True,
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(template.validate_anchor_predictions(*paths), policy="v3p83_anchor_normalized_access")


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])  # noqa: F405


def validate_panel(*paths: str | Path) -> dict[str, Any]:
    return _retag(template.validate_panel(*paths), policy="normalized_access_singleton_safe_tournament")


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_panel(*paths[:-1]), paths[-1])  # noqa: F405


def validate_selector(*paths: str | Path) -> dict[str, Any]:
    return _retag(template.validate_selector(*paths), policy="normalized_access_exact_selection_copy")


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_selector(*paths[:-1]), paths[-1])  # noqa: F405


def validate_agent_judge_gaia_v3_96_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    return _retag(
        template.validate_agent_judge_gaia_v3_95_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        policy="normalized_access_audited_predicate_handoff_tournament",
    )


def validate_and_write_agent_judge_gaia_v3_96_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(  # noqa: F405
        validate_agent_judge_gaia_v3_96_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_gaia_v3_96_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_reducer_file_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,  # noqa: F405
    )


validate_and_write_agent_judge_luna_gaia_v3_37_audit = validate_and_write_agent_judge_gaia_v3_96_audit
validate_and_write_agent_judge_luna_gaia_v3_67_audit = validate_and_write_agent_judge_gaia_v3_96_audit
validate_and_write_agent_judge_luna_gaia_v3_79_audit = validate_and_write_agent_judge_gaia_v3_96_audit
validate_and_write_agent_judge_luna_gaia_v3_80_audit = validate_and_write_agent_judge_gaia_v3_96_audit
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_gaia_v3_96_task
build_agent_judge_luna_gaia_v3_79_task = build_agent_judge_gaia_v3_96_task
build_agent_judge_luna_gaia_v3_80_task = build_agent_judge_gaia_v3_96_task


def __getattr__(name: str) -> Any:
    return getattr(template, name)

"""GAIA causal serial judge using frozen label-hidden census dossiers.

The Step agent sees every trajectory step plus a mechanically compressed,
module/type-hidden projection of the gold-free forced census.  Step remains
unconstrained by that projection.  Fresh Module and Type agents accept the
earlier frozen decisions and use segmented owner sources.
"""

from __future__ import annotations

import json
import shlex
from pathlib import Path
from typing import Any, Mapping

from agentdebug.benchmark.prediction_manifest import load_prediction_manifest

from . import agent_judge_luna_v3_serial as serial
from .agent_judge import (
    GOLD_ISOLATION_READ_DENYLIST,
    _assert_gold_free,
    _assert_safe_path,
    _file_sha256,
    _load_json,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_sol_gaia_forced_census import (
    CANDIDATE_PROPOSALS_FILENAME,
    segmented_owner_sources,
    validate_forced_candidates,
)
from .taxonomy import AgentModule, ErrorType, TAXONOMY


VERSION = "agentdebug.codex-agent-judge.gaia-causal-serial-v1"
STEP_MODEL = "gpt-5.6-luna"
STEP_REASONING_EFFORT = "medium"
DOWNSTREAM_MODEL = "gpt-5.6-sol"
DOWNSTREAM_REASONING_EFFORT = "high"

STEP_DOSSIERS_FILENAME = "step-dossiers.json"
STEP_DECISIONS_FILENAME = serial.STEP_DECISIONS_FILENAME
MODULE_DECISIONS_FILENAME = serial.MODULE_DECISIONS_FILENAME
STEP_AUDIT_FILENAME = serial.STEP_AUDIT_FILENAME
MODULE_AUDIT_FILENAME = serial.MODULE_AUDIT_FILENAME

_DOSSIER_FIELDS = {
    "trajectory_id", "trajectory_sha256", "status", "steps"
}
_STEP_FIELDS = {
    "step", "hypothesis_count", "unrecovered_count", "findings"
}
_FINDING_FIELDS = {
    "evidence_quote", "local_defect", "causal_relevance", "recovery"
}


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    temporary.replace(path)


def _project_dossiers(
    proposal_rows: list[Mapping[str, Any]], cases: list[Any]
) -> list[dict[str, Any]]:
    projected: list[dict[str, Any]] = []
    recovery_rank = {"none": 0, "partial": 1, "complete": 2}
    for row, case in zip(proposal_rows, cases, strict=True):
        by_step: dict[int, list[Mapping[str, Any]]] = {
            step: [] for step in range(1, len(case.judge_view.steps) + 1)
        }
        for card in row["candidates"]:
            by_step[int(card["step"])].append(card)
        steps: list[dict[str, Any]] = []
        for step, cards in by_step.items():
            ordered = sorted(
                enumerate(cards),
                key=lambda item: (
                    recovery_rank[item[1]["recovery"]], item[0]
                ),
            )
            findings: list[dict[str, str]] = []
            seen: set[tuple[str, str, str, str]] = set()
            for _, card in ordered:
                finding = {
                    "evidence_quote": str(card["evidence_quote"]),
                    "local_defect": str(card["local_defect"]),
                    "causal_relevance": str(card["causal_relevance"]),
                    "recovery": str(card["recovery"]),
                }
                key = tuple(finding[field] for field in sorted(_FINDING_FIELDS))
                if key in seen:
                    continue
                seen.add(key)
                findings.append(finding)
                if len(findings) == 3:
                    break
            steps.append(
                {
                    "step": step,
                    "hypothesis_count": len(cards),
                    "unrecovered_count": sum(
                        card["recovery"] == "none" for card in cards
                    ),
                    "findings": findings,
                }
            )
        projected.append(
            {
                "trajectory_id": row["trajectory_id"],
                "trajectory_sha256": row["trajectory_sha256"],
                "status": "success",
                "steps": steps,
            }
        )
    return projected


def validate_step_dossiers(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposals_path: str | Path,
    dossiers_path: str | Path,
) -> dict[str, Any]:
    proposals = Path(proposals_path).expanduser().resolve()
    dossiers = Path(dossiers_path).expanduser().resolve()
    candidate_audit = validate_forced_candidates(
        prediction_manifest_path, cohort_manifest_path, proposals
    )
    _, cases = load_prediction_manifest(
        Path(prediction_manifest_path).expanduser().resolve()
    )
    raw_proposals = _load_json(proposals, role="forced candidates")
    raw_dossiers = _load_json(dossiers, role="step dossiers")
    _assert_gold_free(raw_dossiers, location="step dossiers")
    expected = _project_dossiers(raw_proposals, cases)
    if raw_dossiers != expected:
        serial._fail(
            "step_dossier_projection_mismatch",
            "step dossiers are not the deterministic label-hidden projection",
        )
    for index, (row, case) in enumerate(zip(raw_dossiers, cases, strict=True)):
        if not isinstance(row, Mapping) or set(row) != _DOSSIER_FIELDS:
            serial._fail("invalid_step_dossier", f"invalid dossier row {index}")
        if [item.get("step") for item in row["steps"]] != list(
            range(1, len(case.judge_view.steps) + 1)
        ):
            serial._fail("incomplete_step_dossier", f"invalid step coverage {index}")
        for item in row["steps"]:
            if not isinstance(item, Mapping) or set(item) != _STEP_FIELDS:
                serial._fail("invalid_step_dossier", f"invalid step item {index}")
            if any(
                not isinstance(finding, Mapping)
                or set(finding) != _FINDING_FIELDS
                for finding in item["findings"]
            ):
                serial._fail("invalid_step_dossier", f"invalid finding {index}")
    return {
        "agent_judge_version": VERSION,
        "stage": "deterministic-step-dossier",
        "gold_free_validation": True,
        "case_count": candidate_audit["case_count"],
        "candidate_count": candidate_audit["candidate_count"],
        "all_steps_represented": True,
        "module_and_type_labels_removed": True,
        "max_findings_per_step": 3,
        "input_sha256": {proposals.name: _file_sha256(proposals)},
        "output_sha256": {dossiers.name: _file_sha256(dossiers)},
    }


def write_step_dossiers(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposals_path: str | Path,
    dossiers_path: str | Path,
) -> dict[str, Any]:
    proposals = Path(proposals_path).expanduser().resolve()
    dossiers = Path(dossiers_path).expanduser().resolve()
    validate_forced_candidates(
        prediction_manifest_path, cohort_manifest_path, proposals
    )
    _, cases = load_prediction_manifest(
        Path(prediction_manifest_path).expanduser().resolve()
    )
    rows = _load_json(proposals, role="forced candidates")
    _write_json(dossiers, _project_dossiers(rows, cases))
    return validate_step_dossiers(
        prediction_manifest_path,
        cohort_manifest_path,
        proposals,
        dossiers,
    )


def _upgrade(audit: dict[str, Any], *, stage: str) -> dict[str, Any]:
    model = STEP_MODEL if stage == "step" else DOWNSTREAM_MODEL
    effort = (
        STEP_REASONING_EFFORT
        if stage == "step"
        else DOWNSTREAM_REASONING_EFFORT
    )
    return {
        **audit,
        "agent_judge_version": VERSION,
        "model": model,
        "reasoning_effort": effort,
        "frozen_forced_census_predictions_visible": False,
    }


def validate_step_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
) -> dict[str, Any]:
    step_path = Path(step_decisions_path).expanduser().resolve()
    dossier = step_path.parent / STEP_DOSSIERS_FILENAME
    proposals = step_path.parent / CANDIDATE_PROPOSALS_FILENAME
    dossier_audit = validate_step_dossiers(
        prediction_manifest_path, cohort_manifest_path, proposals, dossier
    )
    base = serial.validate_agent_judge_luna_v3_serial_step_predictions(
        prediction_manifest_path, cohort_manifest_path, step_path
    )
    return _upgrade(
        {
            **base,
            "all_steps_eligible": True,
            "dossier_sha256": dossier_audit["output_sha256"],
        },
        stage="step",
    )


def _module_source_map(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
) -> dict[str, list[str]]:
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    step_path = Path(step_decisions_path).expanduser().resolve()
    cases, records = serial._validate_step_records(prediction, cohort, step_path)
    if len(cases) != 1:
        serial._fail("invalid_stage_count", "Module Agent requires one case")
    step = int(records[0]["predicted_step"])
    return {
        module.value: list(
            dict.fromkeys(
                source
                for error_type in TAXONOMY[module]
                for source in segmented_owner_sources(
                    cases[0].judge_view, step, module, error_type
                )
            )
        )
        for module in AgentModule
    }


def validate_module_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
) -> dict[str, Any]:
    base = serial.validate_agent_judge_luna_v3_serial_module_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        step_decisions_path,
        module_decisions_path,
    )
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    step_path = Path(step_decisions_path).expanduser().resolve()
    module_path = Path(module_decisions_path).expanduser().resolve()
    cases, records = serial._validate_module_records(
        prediction, cohort, step_path, module_path
    )
    for index, (case, record) in enumerate(zip(cases, records, strict=True)):
        module = AgentModule(record["predicted_module"])
        step = int(record["predicted_step"])
        if not any(
            segmented_owner_sources(case.judge_view, step, module, error_type)
            for error_type in TAXONOMY[module]
        ):
            serial._fail(
                "module_has_no_evidence_source",
                f"selected owner has no source at index {index}",
            )
    return _upgrade(
        {**base, "all_modules_have_segmented_owner_source": True},
        stage="module",
    )


def validate_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    output = Path(predictions_path).expanduser().resolve()
    step_path = output.parent / STEP_DECISIONS_FILENAME
    module_path = output.parent / MODULE_DECISIONS_FILENAME
    _, module_records = serial._validate_module_records(
        prediction, cohort, step_path, module_path
    )
    base = _validate_agent_judge_predictions_with_owner_sources(
        prediction,
        cohort,
        output,
        owner_source_resolver=segmented_owner_sources,
    )
    finals = _load_json(output, role="predictions")
    for index, (module_record, final) in enumerate(
        zip(module_records, finals, strict=True)
    ):
        if final["predicted_step"] != module_record["predicted_step"]:
            serial._fail("serial_step_revision", f"revised step {index}")
        if final["predicted_module"] != module_record["predicted_module"]:
            serial._fail("serial_module_revision", f"revised module {index}")
    return _upgrade(
        {
            **base,
            "serial_stage_count": 3,
            "serial_step_frozen": True,
            "serial_module_frozen": True,
            "segmented_nested_owner_sources": True,
            "output_sha256": {
                "predictions.json": _file_sha256(output),
                STEP_DECISIONS_FILENAME: _file_sha256(step_path),
                MODULE_DECISIONS_FILENAME: _file_sha256(module_path),
            },
        },
        stage="type",
    )


def _write_audit(path: str | Path, value: Mapping[str, Any]) -> dict[str, Any]:
    return serial._write_audit(path, value)


def validate_and_write_step_audit(*args: str | Path) -> dict[str, Any]:
    return _write_audit(args[-1], validate_step_predictions(*args[:-1]))


def validate_and_write_module_audit(*args: str | Path) -> dict[str, Any]:
    return _write_audit(args[-1], validate_module_predictions(*args[:-1]))


def validate_and_write_prediction_audit(*args: str | Path) -> dict[str, Any]:
    return _write_audit(args[-1], validate_predictions(*args[:-1]))


def _validator_command(function: str, *arguments: Path) -> str:
    rendered = ", ".join(repr(str(item)) for item in arguments)
    code = (
        "import json; from agentdebug.diagnostics.agent_judge_gaia_causal_serial "
        f"import {function} as run; print(json.dumps(run({rendered}), "
        "ensure_ascii=False, indent=2))"
    )
    return "PYTHONPATH=. python3 -c " + shlex.quote(code)


def _replace_runtime(task: str, *, step: bool) -> str:
    model = STEP_MODEL if step else DOWNSTREAM_MODEL
    effort = STEP_REASONING_EFFORT if step else DOWNSTREAM_REASONING_EFFORT
    return (
        task.replace(serial.AGENT_JUDGE_LUNA_V3_SERIAL_VERSION, VERSION)
        .replace("model: gpt-5.6-luna", f"model: {model}")
        .replace("model=gpt-5.6-luna", f"model={model}")
        .replace("reasoning_effort: medium", f"reasoning_effort: {effort}")
        .replace("reasoning_effort=medium", f"reasoning_effort={effort}")
    )


def build_step_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
) -> str:
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    output = Path(step_decisions_path).expanduser().resolve()
    dossier = output.parent / STEP_DOSSIERS_FILENAME
    proposals = output.parent / CANDIDATE_PROPOSALS_FILENAME
    audit = output.parent / STEP_AUDIT_FILENAME
    validate_step_dossiers(prediction, cohort, proposals, dossier)
    task = _replace_runtime(
        serial.build_agent_judge_luna_v3_serial_step_task(
            prediction, cohort, output
        ),
        step=True,
    )
    old_command = serial._validator_command(
        "validate_and_write_agent_judge_luna_v3_serial_step_audit",
        prediction, cohort, output, audit,
    )
    new_command = _validator_command(
        "validate_and_write_step_audit",
        prediction, cohort, output, audit,
    )
    addition = f"""
FROZEN LABEL-HIDDEN STEP DOSSIER
- read: {dossier}
- sha256: {_file_sha256(dossier)}

The dossier is a deterministic compression of independent local anomaly
hypotheses. Module and error-type labels are removed. It is advisory evidence,
not a candidate restriction and not a vote: every step 1..N remains eligible,
including steps with zero findings. High counts often mean merely verbose or
nested source blocks.

RETROSPECTIVE CAUSAL-BOUNDARY POLICY
Judge each decision using the complete released trajectory, including what its
branch later produced. The target is the earliest pivotal step whose different
choice would have avoided the material failed branch, not the most vivid local
mistake and not the final independently sufficient error.

- A search refinement may look locally reasonable yet still be the critical
  inefficient decision when the full trajectory shows it initiated or renewed
  an unproductive route while a more task-specific acquisition route existed.
- Later restoration of a forgotten fact does not erase the earlier root when
  the costly branch was already caused. Recovery defeats the earlier step only
  when the restored state was actually used to return to a viable route.
- Repetition chains: choose the first renewed commitment that the full history
  demonstrates was strategically unproductive. Do not wait for the last repeat.
- Do not jump earlier than the first material commitment merely because a weak
  premise can be criticized. A speculative imperfection loses to the first
  trace-demonstrated branch decision.
- Explicit constraint violations are not automatically stronger than subtle
  acquisition or memory roots. Compare counterfactual prevention, not salience.

Your output remains Step-only; never emit module or type.
"""
    task = task.replace(
        "\nGOLD-ISOLATION READ DENYLIST\n",
        f"\n- {dossier}\n\nGOLD-ISOLATION READ DENYLIST\n",
        1,
    )
    task = task.replace("\nSTRICT OUTPUT CONTRACT\n", addition + "\nSTRICT OUTPUT CONTRACT\n", 1)
    return task.replace(old_command, new_command)


def build_module_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
) -> str:
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    step_path = Path(step_decisions_path).expanduser().resolve()
    output = Path(module_decisions_path).expanduser().resolve()
    audit = output.parent / MODULE_AUDIT_FILENAME
    sources = _module_source_map(prediction, cohort, step_path)
    task = _replace_runtime(
        serial.build_agent_judge_luna_v3_serial_module_task(
            prediction, cohort, step_path, output
        ),
        step=False,
    )
    old_command = serial._validator_command(
        "validate_and_write_agent_judge_luna_v3_serial_module_audit",
        prediction, cohort, step_path, output, audit,
    )
    new_command = _validator_command(
        "validate_and_write_module_audit",
        prediction, cohort, step_path, output, audit,
    )
    addition = f"""
SEGMENTED VALIDATOR-ELIGIBLE OWNER SOURCES
{json.dumps(sources, ensure_ascii=False, indent=2)}

Choose semantic information-flow ownership, not the owner with the easiest
quote. Outer reasoning residual is preserved after nested owner spans are
subtracted. If Memory supplies false/omitted state used downstream, Memory
owns; if state is sound but feedback interpretation becomes false, Reflection
owns; if those are sound and strategy becomes defective, Planning owns; a
faithful Action does not steal ownership from its plan. System requires a
provenance-backed independent execution boundary.
"""
    task = task.replace("\nSTRICT OUTPUT CONTRACT\n", addition + "\nSTRICT OUTPUT CONTRACT\n", 1)
    return task.replace(old_command, new_command)


def _type_source_map(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
) -> dict[str, list[str]]:
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    step_path = Path(step_decisions_path).expanduser().resolve()
    module_path = Path(module_decisions_path).expanduser().resolve()
    cases, records = serial._validate_module_records(
        prediction, cohort, step_path, module_path
    )
    record = records[0]
    module = AgentModule(record["predicted_module"])
    step = int(record["predicted_step"])
    return {
        error_type.value: list(
            segmented_owner_sources(
                cases[0].judge_view, step, module, error_type
            )
        )
        for error_type in TAXONOMY[module]
    }


def build_type_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    step_path = Path(step_decisions_path).expanduser().resolve()
    module_path = Path(module_decisions_path).expanduser().resolve()
    output = Path(predictions_path).expanduser().resolve()
    audit = output.parent / "prediction-audit.json"
    sources = _type_source_map(
        prediction, cohort, step_path, module_path
    )
    task = _replace_runtime(
        serial.build_agent_judge_luna_v3_serial_type_task(
            prediction, cohort, step_path, module_path, output
        ),
        step=False,
    )
    old_command = serial._validator_command(
        "validate_and_write_agent_judge_luna_v3_serial_audit",
        prediction, cohort, output, audit,
    )
    new_command = _validator_command(
        "validate_and_write_prediction_audit",
        prediction, cohort, output, audit,
    )
    addition = f"""
SEGMENTED VALIDATOR-OWNED EVIDENCE SOURCES BY LEGAL TYPE
{json.dumps(sources, ensure_ascii=False, indent=2)}

Contrast every legal type at the frozen owner. For Planning, feasible but
wasteful/repetitive/poor acquisition is `inefficient_plan`; use
`impossible_action` only when the available interface truly cannot execute the
operation, and `constraint_ignorance` only for a concrete disregarded task
constraint. For Reflection, distinguish false result meaning
(`outcome_misinterpretation`) from false completion/progress status
(`progress_misjudge`). Taxonomy fit may never revise Step or Module.
"""
    task = task.replace(
        "\nLEGAL ERROR TYPES FOR THE FROZEN MODULE\n",
        addition + "\nLEGAL ERROR TYPES FOR THE FROZEN MODULE\n",
        1,
    )
    return task.replace(old_command, new_command)


def build_protocol_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    output = Path(predictions_path).expanduser().resolve()
    return build_type_task(
        prediction_manifest_path,
        cohort_manifest_path,
        output.parent / STEP_DECISIONS_FILENAME,
        output.parent / MODULE_DECISIONS_FILENAME,
        output,
    )


__all__ = [
    "CANDIDATE_PROPOSALS_FILENAME", "DOWNSTREAM_MODEL",
    "DOWNSTREAM_REASONING_EFFORT", "MODULE_DECISIONS_FILENAME",
    "STEP_DECISIONS_FILENAME", "STEP_DOSSIERS_FILENAME", "STEP_MODEL",
    "STEP_REASONING_EFFORT", "VERSION", "build_module_task",
    "build_protocol_task", "build_step_task", "build_type_task",
    "validate_module_predictions", "validate_predictions",
    "validate_step_dossiers", "validate_step_predictions",
    "write_step_dossiers",
]

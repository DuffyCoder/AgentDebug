"""Luna GAIA v3.52: clean v3.20 plus module-factorized local-census proposals."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions
from .taxonomy import AgentModule, ErrorType, is_valid_classification, taxonomy_prompt


AGENT_JUDGE_LUNA_GAIA_V3_52_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.52-clean-v3.20-"
    "module-factorized-local-census-proposal-panel"
)
AGENT_JUDGE_LUNA_GAIA_V3_52_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_52_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_52_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases for the shared cohort orchestration shell.
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_52_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_52_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_52_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_52_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_52_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_52_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_52_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
PROPOSAL_FILENAME = "module-local-census-proposal.json"
PROPOSAL_AUDIT_FILENAME = "module-local-census-proposal-audit.json"
PANEL_FILENAME = "module-factorized-local-census-proposal-panel.json"
PANELS_FILENAME = "module-factorized-local-census-proposal-panels.json"
SELECTOR_FILENAME = "anchor-preserving-module-proposal-selector.json"
SELECTORS_FILENAME = "anchor-preserving-module-proposal-selectors.json"
SELECTOR_AUDIT_FILENAME = "anchor-preserving-module-proposal-selector-audit.json"

SPECIALIST_MODULES = (
    AgentModule.MEMORY.value,
    AgentModule.REFLECTION.value,
    AgentModule.PLANNING.value,
    AgentModule.ACTION.value,
)
REPLICA_COUNT = len(SPECIALIST_MODULES)
MODULES = tuple(module.value for module in AgentModule)
LOCAL_REVIEW_FIELDS = (
    "step",
    "error_detected",
    "error_type",
    "evidence_quote",
    "local_reasoning",
)
PROPOSAL_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "replica_index",
    "assigned_module",
    "reviewed_steps",
    "local_reviews",
    "owner_local_error_count",
    "proposal_status",
    "proposal_step",
    "boundary_class",
    "proposal_prediction",
    "probe_assessment",
    "recovery_assessment",
    "predecessor_assessment",
    "chronology_comparison",
    "critical_boundary_basis",
    "selection_falsifier",
)
PROPOSAL_STATUSES = frozenset({"candidate", "none"})
BOUNDARY_CLASSES = frozenset(
    {
        "none",
        "state_truth",
        "constraint_alignment",
        "capability_commitment",
        "post_feedback_recommitment",
        "terminal_abandonment",
    }
)
PANEL_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "proposal_count",
    "proposal_hashes",
    "proposals",
    "unique_candidate_steps",
)
SELECTOR_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "anchor_prediction_sha256",
    "anchor_ledger_sha256",
    "anchor_checkpoint_sha256",
    "panel_sha256",
    "anchor_step",
    "proposal_steps",
    "decision",
    "selected_proposal_index",
    "anchor_classification",
    "proposal_classifications",
    "anchor_veto_evidence_step",
    "anchor_veto_evidence_quote",
    "proposal_independent_evidence_step",
    "proposal_independent_evidence_quote",
    "frozen_step",
    "selected_prediction_sha256",
    "selected_prediction",
    "anchor_assessment",
    "proposal_assessments",
    "consensus_assessment",
    "anchor_only_repair_assessment",
    "proposal_independent_criticality_assessment",
    "timeline_comparison",
    "decision_basis",
    "rejected_alternatives_basis",
    "selection_falsifier",
)
SELECTOR_DECISIONS = frozenset({"keep_anchor", "select_proposal"})
ANCHOR_CLASSES = frozenset(
    {
        "critical_root",
        "normal_tool_failure",
        "recovered_defect",
        "mechanical_predecessor",
        "noncritical_predecessor",
        "faithful_propagation",
        "downstream_symptom",
        "uncertain",
    }
)
OVERRIDE_ANCHOR_CLASSES = ANCHOR_CLASSES - {"critical_root", "uncertain"}
PROPOSAL_CLASSES = frozenset(
    {
        "absent",
        "critical_root",
        "reasonable_probe",
        "normal_tool_failure",
        "recovered_defect",
        "mechanical_predecessor",
        "faithful_propagation",
        "downstream_symptom",
        "uncertain",
    }
)
PROBE_PREFIX = re.compile(
    r"^proposal_probe_status=(reasonable|material_error|not_applicable);"
)


_PROPOSAL_RULES = """\
ISOLATED MODULE-FACTORIZED LOCAL CENSUS AND CRITICAL COMPRESSION

The incumbent anchor and the other specialists are intentionally unavailable.
Do not infer or reconstruct them. You own exactly one assigned module.

Pass A — local census. Review the assigned module at every Canonical Step in
chronological order and emit exactly one local verdict per Step. Judge local
correctness from the information observable at that Step; do not suppress a
real local error merely because it may later recover or may not be the global
root. An absent/correct owner is `no_error`. A positive row needs a legal type,
literal same-Step owner quote, and concrete local reasoning. This pass is an
evidence inventory, not a candidate list or vote.

Pass B — within-module critical compression. Re-read the complete chronology,
including later feedback and recovery, and consider every positive row. Export
at most one complete prediction, bound to one positive local row, or `none`.
Select the first observable assigned-module error that materially changes the
failed path under the benchmark critical-boundary convention; do not prefer
Planning, position, persistence, severity, repeated prose, or terminal
visibility.

A reasonable probe has a literal target and route matched to an immediate
uncertainty and can expose a needed identifier, fact, source, page, text, or
route. Do not project the final proof predicate backward onto an intermediate
discovery action. Reject normal negative/empty results, fully recovered
defects, mechanical repairs, faithful propagation, noncritical predecessors,
locally improvable behavior, and downstream symptoms. Repetition is mature
only after the same immediate predicate and evidence family observably failed
and the new Step adds no meaningful target refinement or different probe.

For every plausible winner apply candidate-only repair and earlier-alternative
repair tests. The candidate repair must materially change the failed path;
repairing an earlier owning boundary must not already remove this candidate's
independent criticality. Emit `none` when no positive local row survives. Never
access gold, labels, old predictions, case reports, or source identity priors.
"""


_SELECTOR_RULES = """\
ANCHOR-PRESERVING MODULE-PROPOSAL SELECTOR — EXACT COPY, NO VOTE

The anchor and four isolated module-proposal artifacts are immutable. Select exactly
the anchor or one proposal prediction. Never invent a Step, merge fields,
repair a prediction, or rank by source identity. Agreement/support count is
only a reason to inspect evidence; it is not a vote and cannot prove
criticality. Under unresolved evidence keep the anchor.

Protect an unrecovered constraint violation, target/Action mismatch,
task-material false state, intrinsically incapable commitment, eligible
execution impact, or earliest failure-causing commitment. Reject a proposal
that is a reasonable probe, normal negative result, recovered defect,
mechanical predecessor, faithful propagation, local improvement, later
repetition, or downstream symptom.

The anchor cannot be overridden merely because it is early, exploratory,
unhelpful, or less vivid. `reasonable_probe` and hypothetical contribution are
not override classes. To select a proposal, literal evidence must place the
anchor in one validator-allowed causal-removal class: normal tool failure,
recovered defect, mechanical/noncritical predecessor, faithful propagation, or
downstream symptom. Also quote literal evidence owned by the selected proposal
and explain why it remains independently critical after anchor-only repair.

For a recovered anchor, the veto quote must show the actual recovery. For a
normal tool failure, it must show a normal failure plus adaptation rather than
an external execution defect that owns the path. For a predecessor, it must
show why repairing the anchor alone leaves the later failure. For propagation
or symptom, it must identify the earlier owning boundary. A qualitative label
without this literal causal-removal proof cannot override.

Begin `anchor_assessment` exactly with `anchor_status=<class>; `. Begin each
proposal assessment exactly with `replica_<n>_status=<class>; `. The replica
number only binds an assigned module and is not a quality prior. Do not stop
after finding one persuasive proposal: compare all distinct Steps, chronology,
recovery, contribution, and repair counterfactuals. Exact-copy keep anchor when
the best alternative does not strictly dominate.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_52_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_52_clean_v3p20_module_factorized_local_census_proposal_panel",
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py",
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_52_clean_v3p20_module_factorized_local_census_proposal_panel.py",
        )
    )


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_52_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_52_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_52_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one module-factorized local-census proposal panel",
    }


def _boundary(
    *, manifest: Path, cohort: Path, reads: Sequence[Path], output: Path
) -> str:
    read_lines = "\n".join(f"- {path}" for path in reads) or "- none"
    return f"""\
IMMUTABLE EXECUTION CONFIGURATION
- model: {AGENT_JUDGE_LUNA_GAIA_V3_52_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_52_REASONING_EFFORT}
- one isolated case; fresh session; no cross-case state or prior predictions
- external LLM/API/network calls: forbidden
- scoring or gold-label access: forbidden

INPUT/OUTPUT BOUNDARY
- prediction manifest: {manifest}
- prediction manifest file sha256: {shared._file_sha256(manifest)}
- cohort manifest: {cohort}
- cohort manifest file sha256: {shared._file_sha256(cohort)}
- permitted frozen stage inputs:
{read_lines}
- write the sole stage artifact only to: {output}

Read only those exact inputs plus this v3.52 protocol source, the v3.20
protocol source, and `agentdebug/diagnostics/taxonomy.py`. Do not inspect
directories or infer from trajectory/source-model/environment names. Never
read labels, metrics, scored artifacts, experiment documents, old predictions,
cached replies, case studies, git history, or external resources.
"""


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_anchor_task(*paths))


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths), policy="unchanged_v3_20_anchor")


def _validate_optional_literal(
    *, case: Any, step: Any, quote: Any, location: str
) -> None:
    if step is None and quote is None:
        return
    if isinstance(step, bool) or not isinstance(step, int):
        shared._fail("invalid_selector_literal_step", location)
    if step < 1 or step > len(case.judge_view.steps):
        shared._fail("invalid_selector_literal_step", location)
    shared._nonempty_text(quote, location=f"{location}.quote", maximum=1800)
    if not any(quote in source for source in shared._packet_sources(case, step)):
        shared._fail("invalid_selector_literal_quote", location)


def _validate_proposal_record(
    raw: Any, *, case: Any, replica_index: int, location: str
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != PROPOSAL_FIELDS:
        shared._fail("invalid_replicated_proposal_schema", location)
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
        or raw["replica_index"] != replica_index
        or raw["assigned_module"] != SPECIALIST_MODULES[replica_index - 1]
    ):
        shared._fail("replicated_proposal_identity_mismatch", location)
    if raw["reviewed_steps"] != list(range(1, len(case.judge_view.steps) + 1)):
        shared._fail("incomplete_replicated_proposal_step_coverage", location)
    assigned_module = AgentModule(raw["assigned_module"])
    reviews = raw["local_reviews"]
    if not isinstance(reviews, list) or len(reviews) != len(case.judge_view.steps):
        shared._fail("incomplete_module_local_census", location)
    positive_steps: list[int] = []
    positive_quotes: dict[int, list[str]] = {}
    for step, review in enumerate(reviews, start=1):
        review_location = f"{location}.local_reviews[{step - 1}]"
        if not isinstance(review, dict) or tuple(review) != LOCAL_REVIEW_FIELDS:
            shared._fail("invalid_module_local_review_schema", review_location)
        if review["step"] != step:
            shared._fail("invalid_module_local_review_step", review_location)
        shared._nonempty_text(
            review["local_reasoning"],
            location=f"{review_location}.local_reasoning",
            maximum=2600,
        )
        if review["error_detected"] is False:
            if review["error_type"] != "no_error" or review["evidence_quote"] is not None:
                shared._fail("invalid_negative_module_local_review", review_location)
            continue
        if review["error_detected"] is not True:
            shared._fail("invalid_module_local_error_flag", review_location)
        try:
            error_type = ErrorType(review["error_type"])
        except ValueError:
            shared._fail("invalid_module_local_error_type", review_location)
        if not is_valid_classification(assigned_module, error_type):
            shared._fail("invalid_module_local_error_type", review_location)
        quote = review["evidence_quote"]
        shared._nonempty_text(
            quote, location=f"{review_location}.evidence_quote", maximum=2400
        )
        owner_sources = shared._luna_gaia_v2_owner_source_resolver(
            case.judge_view, step, assigned_module, error_type
        )
        if not owner_sources or not any(quote in source for source in owner_sources):
            shared._fail("invalid_module_local_owner_evidence", review_location)
        positive_steps.append(step)
        positive_quotes.setdefault(step, []).append(quote)
    count = raw["owner_local_error_count"]
    if (
        isinstance(count, bool)
        or not isinstance(count, int)
        or count != len(positive_steps)
    ):
        shared._fail("invalid_replicated_proposal_local_error_count", location)
    if raw["proposal_status"] not in PROPOSAL_STATUSES:
        shared._fail("invalid_replicated_proposal_status", location)
    if raw["boundary_class"] not in BOUNDARY_CLASSES:
        shared._fail("invalid_replicated_proposal_boundary_class", location)
    for field in (
        "probe_assessment",
        "recovery_assessment",
        "predecessor_assessment",
        "chronology_comparison",
        "critical_boundary_basis",
        "selection_falsifier",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3400)
    if raw["proposal_status"] == "none":
        if (
            raw["proposal_step"] is not None
            or raw["proposal_prediction"] is not None
            or raw["boundary_class"] != "none"
        ):
            shared._fail("nonempty_replicated_none_proposal", location)
        expected_probe = "not_applicable"
    else:
        if raw["boundary_class"] == "none" or count < 1:
            shared._fail("empty_replicated_candidate_basis", location)
        prediction = shared._validate_prediction_record(
            raw["proposal_prediction"], case=case, location=f"{location}.prediction"
        )
        if (
            raw["proposal_step"] != prediction["predicted_step"]
            or prediction["predicted_step"] not in positive_steps
            or prediction["predicted_module"] != raw["assigned_module"]
            or prediction["evidence_quote"]
            not in positive_quotes[prediction["predicted_step"]]
        ):
            shared._fail("replicated_proposal_step_mismatch", location)
        expected_probe = "material_error"
    match = PROBE_PREFIX.match(raw["probe_assessment"])
    if match is None or (
        expected_probe is not None and match.group(1) != expected_probe
    ):
        shared._fail("missing_replicated_proposal_probe_prefix", location)
    return raw


def validate_proposal(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    replica_index: int,
    proposal_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    proposal_file, raw = shared._load_artifact(proposal_path, role="replicated proposal")
    proposal = shared._one_record(raw, role="replicated proposal")
    _validate_proposal_record(
        proposal, case=case, replica_index=replica_index, location="proposal[0]"
    )
    return _retag(
        {
            "schema_version": "agentdebug.module-local-census-proposal-audit.v1",
            "stage": "anchor_blind_module_local_census_proposal",
            "replica_index": replica_index,
            "assigned_module": proposal["assigned_module"],
            "gold_free_validation": True,
            "case_count": 1,
            "anchor_visible": False,
            "other_specialists_visible": False,
            "complete_step_coverage": True,
            "assigned_module_coverage": True,
            "local_review_count": len(proposal["local_reviews"]),
            "positive_local_error_count": proposal["owner_local_error_count"],
            "maximum_candidates": 1,
            "proposal_status": proposal["proposal_status"],
            "boundary_class": proposal["boundary_class"],
            "input_sha256": {
                "prediction_manifest": shared._file_sha256(manifest),
                "cohort": shared._file_sha256(cohort),
            },
            "output_sha256": {PROPOSAL_FILENAME: shared._file_sha256(proposal_file)},
        },
        policy="isolated_anchor_blind_module_local_census_proposal",
    )


def build_proposal_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    replica_index: int,
    proposal_path: str | Path,
) -> str:
    if replica_index < 1 or replica_index > REPLICA_COUNT:
        raise ValueError("specialist index out of range")
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    output = Path(proposal_path).expanduser().resolve()
    shared._assert_safe_path(output, role="replicated proposal output", is_output=True)
    audit = output.parent / PROPOSAL_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_52_clean_v3p20_module_factorized_local_census_proposal_panel",
            "--compact-validate",
            "proposal",
            manifest,
            cohort,
            replica_index,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    assigned_module = SPECIALIST_MODULES[replica_index - 1]
    prediction_schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        "predicted_step": "selected Step",
        "predicted_module": assigned_module,
        "predicted_error_type": f"valid {assigned_module} taxonomy type",
        "evidence_quote": "literal evidence owned by selected Step/module",
        "root_cause": "specific local root cause",
        "causal_summary": "why this boundary materially changes the failed path",
        "rejected_adjacent_owner": "strongest adjacent alternative and why rejected",
    }
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "replica_index": replica_index,
        "assigned_module": assigned_module,
        "reviewed_steps": list(range(1, len(case.judge_view.steps) + 1)),
        "local_reviews": [
            {
                "step": step,
                "error_detected": "boolean",
                "error_type": f"valid {assigned_module} type or no_error",
                "evidence_quote": "literal assigned-owner substring or null",
                "local_reasoning": "Step-local judgment without global ranking",
            }
            for step in range(1, len(case.judge_view.steps) + 1)
        ],
        "owner_local_error_count": "exact count of positive local reviews",
        "proposal_status": "candidate or none",
        "proposal_step": "integer Step or null",
        "boundary_class": "one allowed boundary class",
        "proposal_prediction": prediction_schema,
        "probe_assessment": "proposal_probe_status=<reasonable|material_error|not_applicable>; evidence",
        "recovery_assessment": "explicit recovery/normal-failure/propagation/symptom veto audit",
        "predecessor_assessment": "candidate-only and earlier-alternative repair comparison",
        "chronology_comparison": "candidate versus every plausible earlier/later boundary",
        "critical_boundary_basis": "why this is the single benchmark-critical boundary",
        "selection_falsifier": "strongest concrete argument against this selection",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_52_VERSION} module specialist {replica_index}/{REPLICA_COUNT}.

{_boundary(manifest=manifest, cohort=cohort, reads=(), output=output)}

{_PROPOSAL_RULES}

Your assigned module is `{assigned_module}`. Review only that owner in Pass A;
the proposal, if any, must exact-bind one positive `{assigned_module}` row.
You cannot see the anchor or any other specialist.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

For `none`, set proposal_step and proposal_prediction to null and boundary_class
to `none`; local_reviews must still cover every Step. After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def build_proposal_panel(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_paths: Sequence[str | Path],
    panel_path: str | Path,
) -> dict[str, Any]:
    _, _, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    if len(proposal_paths) != REPLICA_COUNT:
        raise ValueError("proposal panel needs exactly four module specialists")
    proposals: list[dict[str, Any]] = []
    proposal_hashes: list[str] = []
    for replica_index, path in enumerate(proposal_paths, start=1):
        _, raw = shared._load_artifact(path, role=f"proposal replica {replica_index}")
        proposal = shared._one_record(raw, role=f"proposal replica {replica_index}")
        _validate_proposal_record(
            proposal,
            case=case,
            replica_index=replica_index,
            location=f"panel.proposals[{replica_index - 1}]",
        )
        proposals.append(proposal)
        proposal_hashes.append(shared._stable_sha256(proposal))
    unique_steps = sorted(
        {
            int(proposal["proposal_step"])
            for proposal in proposals
            if proposal["proposal_status"] == "candidate"
        }
    )
    panel = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "proposal_count": REPLICA_COUNT,
        "proposal_hashes": proposal_hashes,
        "proposals": proposals,
        "unique_candidate_steps": unique_steps,
    }
    output = Path(panel_path).expanduser().resolve()
    shared._assert_safe_path(output, role="replicated proposal panel output", is_output=True)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps([panel], ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return panel


def _load_anchor_bundle(
    manifest: Path,
    cohort: Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> tuple[Path, Path, Path, dict[str, Any], dict[str, Any], dict[str, Any]]:
    _, _, case = shared._single_case_paths(manifest, cohort)
    anchor_file, anchor_raw = shared._load_artifact(anchor_path, role="anchor")
    anchor = shared._one_record(anchor_raw, role="anchor")
    shared._validate_prediction_record(anchor, case=case, location="anchor[0]")
    ledger_file, ledger = shared._load_artifact(ledger_path, role="anchor ledger")
    checkpoint_file, checkpoint = shared._load_artifact(
        checkpoint_path, role="anchor checkpoint"
    )
    if (
        ledger.get("trajectory_id") != case.trajectory_id
        or ledger.get("selected_step") != anchor["predicted_step"]
        or checkpoint.get("trajectory_id") != case.trajectory_id
        or checkpoint.get("predicted_step") != anchor["predicted_step"]
    ):
        shared._fail("replicated_panel_anchor_sidecar_mismatch", case.trajectory_id)
    return anchor_file, ledger_file, checkpoint_file, anchor, ledger, checkpoint


def _validate_panel_record(raw: Any, *, case: Any, location: str) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != PANEL_FIELDS:
        shared._fail("invalid_replicated_proposal_panel_schema", location)
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
        or raw["proposal_count"] != REPLICA_COUNT
    ):
        shared._fail("replicated_proposal_panel_identity_mismatch", location)
    proposals = raw["proposals"]
    hashes = raw["proposal_hashes"]
    if (
        not isinstance(proposals, list)
        or len(proposals) != REPLICA_COUNT
        or not isinstance(hashes, list)
        or len(hashes) != REPLICA_COUNT
    ):
        shared._fail("invalid_replicated_proposal_panel_count", location)
    for replica_index, proposal in enumerate(proposals, start=1):
        _validate_proposal_record(
            proposal,
            case=case,
            replica_index=replica_index,
            location=f"{location}.proposals[{replica_index - 1}]",
        )
        if hashes[replica_index - 1] != shared._stable_sha256(proposal):
            shared._fail("replicated_proposal_panel_hash_mismatch", location)
    expected_steps = sorted(
        {
            int(proposal["proposal_step"])
            for proposal in proposals
            if proposal["proposal_status"] == "candidate"
        }
    )
    if raw["unique_candidate_steps"] != expected_steps:
        shared._fail("replicated_proposal_panel_step_mismatch", location)
    return raw


def _validate_selector_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    panel: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != SELECTOR_FIELDS:
        shared._fail("invalid_replicated_proposal_selector_schema", location)
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
    ):
        shared._fail("replicated_proposal_selector_identity_mismatch", location)
    bindings = {
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "panel_sha256": shared._stable_sha256(panel),
    }
    if any(raw[key] != value for key, value in bindings.items()):
        shared._fail("replicated_proposal_selector_hash_mismatch", location)
    proposal_steps = [proposal["proposal_step"] for proposal in panel["proposals"]]
    if raw["anchor_step"] != anchor["predicted_step"] or raw["proposal_steps"] != proposal_steps:
        shared._fail("replicated_proposal_selector_step_binding_mismatch", location)
    if raw["decision"] not in SELECTOR_DECISIONS:
        shared._fail("invalid_replicated_proposal_selector_decision", location)
    if raw["anchor_classification"] not in ANCHOR_CLASSES:
        shared._fail("invalid_replicated_anchor_classification", location)
    classifications = raw["proposal_classifications"]
    assessments = raw["proposal_assessments"]
    if (
        not isinstance(classifications, list)
        or len(classifications) != REPLICA_COUNT
        or any(value not in PROPOSAL_CLASSES for value in classifications)
        or not isinstance(assessments, list)
        or len(assessments) != REPLICA_COUNT
    ):
        shared._fail("invalid_replicated_proposal_classifications", location)
    for replica_index, (proposal, classification, assessment) in enumerate(
        zip(panel["proposals"], classifications, assessments), start=1
    ):
        expected_absent = proposal["proposal_status"] == "none"
        if expected_absent != (classification == "absent"):
            shared._fail("replicated_proposal_absence_mismatch", location)
        shared._nonempty_text(
            assessment,
            location=f"{location}.proposal_assessments[{replica_index - 1}]",
            maximum=2600,
        )
        if not assessment.startswith(f"replica_{replica_index}_status={classification}; "):
            shared._fail("missing_replicated_proposal_assessment_prefix", location)
    for field in (
        "anchor_assessment",
        "consensus_assessment",
        "anchor_only_repair_assessment",
        "proposal_independent_criticality_assessment",
        "timeline_comparison",
        "decision_basis",
        "rejected_alternatives_basis",
        "selection_falsifier",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3800)
    if not raw["anchor_assessment"].startswith(
        f"anchor_status={raw['anchor_classification']}; "
    ):
        shared._fail("missing_replicated_anchor_assessment_prefix", location)
    selected = shared._validate_prediction_record(
        raw["selected_prediction"], case=case, location=f"{location}.selected"
    )
    if (
        raw["selected_prediction_sha256"] != shared._stable_sha256(selected)
        or raw["frozen_step"] != selected["predicted_step"]
    ):
        shared._fail("replicated_selector_selected_hash_or_step_mismatch", location)
    literal_fields = (
        "anchor_veto_evidence_step",
        "anchor_veto_evidence_quote",
        "proposal_independent_evidence_step",
        "proposal_independent_evidence_quote",
    )
    if raw["decision"] == "keep_anchor":
        if raw["selected_proposal_index"] is not None or selected != anchor:
            shared._fail("replicated_selector_keep_copy_mismatch", location)
        if any(raw[field] is not None for field in literal_fields):
            shared._fail("replicated_selector_inactive_literal", location)
    else:
        selected_index = raw["selected_proposal_index"]
        if (
            isinstance(selected_index, bool)
            or not isinstance(selected_index, int)
            or selected_index < 1
            or selected_index > REPLICA_COUNT
        ):
            shared._fail("invalid_replicated_selected_proposal_index", location)
        proposal = panel["proposals"][selected_index - 1]
        if (
            proposal["proposal_status"] != "candidate"
            or selected != proposal["proposal_prediction"]
            or classifications[selected_index - 1] != "critical_root"
        ):
            shared._fail("replicated_selector_proposal_copy_mismatch", location)
        if raw["anchor_classification"] not in OVERRIDE_ANCHOR_CLASSES:
            shared._fail("replicated_selector_lacks_anchor_veto", location)
        _validate_optional_literal(
            case=case,
            step=raw["anchor_veto_evidence_step"],
            quote=raw["anchor_veto_evidence_quote"],
            location=f"{location}.anchor_veto",
        )
        _validate_optional_literal(
            case=case,
            step=raw["proposal_independent_evidence_step"],
            quote=raw["proposal_independent_evidence_quote"],
            location=f"{location}.proposal_independent",
        )
        if (
            raw["anchor_veto_evidence_step"] is None
            or raw["proposal_independent_evidence_step"] is None
        ):
            shared._fail("replicated_selector_missing_override_literals", location)
        if (
            raw["proposal_independent_evidence_step"]
            != proposal["proposal_prediction"]["predicted_step"]
            or raw["proposal_independent_evidence_quote"]
            != proposal["proposal_prediction"]["evidence_quote"]
        ):
            shared._fail("replicated_selector_proposal_literal_not_exact", location)
    return raw


def validate_selector(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    panel_path: str | Path,
    selector_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger, checkpoint = bundle[3:]
    panel_file, panel_raw = shared._load_artifact(panel_path, role="proposal panel")
    panel = shared._one_record(panel_raw, role="proposal panel")
    _validate_panel_record(panel, case=case, location="panel[0]")
    selector_file, selector_raw = shared._load_artifact(
        selector_path, role="replicated proposal selector"
    )
    selector = shared._one_record(selector_raw, role="replicated proposal selector")
    _validate_selector_record(
        selector,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        panel=panel,
        location="selector[0]",
    )
    return _retag(
        {
            "schema_version": "agentdebug.module-factorized-proposal-selector-audit.v1",
            "stage": "anchor_preserving_module_factorized_proposal_selector",
            "gold_free_validation": True,
            "case_count": 1,
            "decision": selector["decision"],
            "selected_prediction_exact_copy": True,
            "maximum_proposals": REPLICA_COUNT,
            "maximum_total_predictions": REPLICA_COUNT + 1,
            "vote_selection_forbidden": True,
            "anchor_causal_removal_literal_binding": True,
            "input_sha256": {
                "anchor": shared._file_sha256(anchor_file),
                "ledger": shared._file_sha256(ledger_file),
                "checkpoint": shared._file_sha256(checkpoint_file),
                "proposal_panel": shared._file_sha256(panel_file),
            },
            "output_sha256": {SELECTOR_FILENAME: shared._file_sha256(selector_file)},
        },
        policy="anchor_preserving_module_factorized_proposal_exact_copy_selector",
    )


def build_selector_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    panel_path: str | Path,
    selector_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger, checkpoint = bundle[3:]
    panel_file, panel_raw = shared._load_artifact(panel_path, role="proposal panel")
    panel = shared._one_record(panel_raw, role="proposal panel")
    _validate_panel_record(panel, case=case, location="panel[0]")
    output = Path(selector_path).expanduser().resolve()
    shared._assert_safe_path(output, role="replicated proposal selector output", is_output=True)
    audit = output.parent / SELECTOR_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_52_clean_v3p20_module_factorized_local_census_proposal_panel",
            "--compact-validate",
            "selector",
            manifest,
            cohort,
            anchor_file,
            ledger_file,
            checkpoint_file,
            panel_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    proposal_steps = [proposal["proposal_step"] for proposal in panel["proposals"]]
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "panel_sha256": shared._stable_sha256(panel),
        "anchor_step": anchor["predicted_step"],
        "proposal_steps": proposal_steps,
        "decision": "keep_anchor or select_proposal",
        "selected_proposal_index": f"1..{REPLICA_COUNT} or null",
        "anchor_classification": "one allowed anchor class",
        "proposal_classifications": ["one allowed class per module specialist"] * REPLICA_COUNT,
        "anchor_veto_evidence_step": "literal veto Step or null",
        "anchor_veto_evidence_quote": "literal veto quote or null",
        "proposal_independent_evidence_step": "selected proposal Step or null",
        "proposal_independent_evidence_quote": "exact selected proposal evidence or null",
        "frozen_step": "selected prediction Step",
        "selected_prediction_sha256": "stable hash of exact selected prediction",
        "selected_prediction": "exact anchor or one proposal prediction",
        "anchor_assessment": "anchor_status=<class>; assessment",
        "proposal_assessments": [
            f"replica_{index}_status=<class>; assessment"
            for index in range(1, REPLICA_COUNT + 1)
        ],
        "consensus_assessment": "agreement is evidence triage, never a vote",
        "anchor_only_repair_assessment": "whether repairing anchor removes later failure",
        "proposal_independent_criticality_assessment": "whether selected proposal remains critical",
        "timeline_comparison": "all distinct boundaries in chronology",
        "decision_basis": "why exact selected boundary wins",
        "rejected_alternatives_basis": "why every other boundary loses",
        "selection_falsifier": "strongest concrete argument against decision",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_52_VERSION} final selector.

{_boundary(manifest=manifest, cohort=cohort, reads=(anchor_file, ledger_file, checkpoint_file, panel_file), output=output)}

{_SELECTOR_RULES}

The immutable anchor Step is {anchor['predicted_step']}. Module proposal Steps
are {proposal_steps}. For keep_anchor, exact-copy the anchor, set
selected_proposal_index and all four literal fields to null. For
select_proposal, exact-copy the selected module prediction and satisfy both
literal bindings.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

Compute content hashes from sorted compact UTF-8 JSON. After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _validate_aggregate(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(prediction_manifest_path, cohort_manifest_path)
    root = Path(predictions_path).expanduser().resolve().parent
    names = (
        ANCHOR_PREDICTIONS_FILENAME,
        ANCHOR_LEDGER_AGGREGATE_FILENAME,
        ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        PANELS_FILENAME,
        SELECTORS_FILENAME,
    )
    loaded = {
        name: shared._load_artifact(root / name, role=f"merged {name}")[1]
        for name in names
    }
    if any(
        not isinstance(value, list) or len(value) != len(cases)
        for value in loaded.values()
    ):
        shared._fail("invalid_replicated_panel_aggregate_count", "all artifacts need all cases")
    finals = shared._load_artifact(predictions_path, role="merged predictions")[1]
    if not isinstance(finals, list) or len(finals) != len(cases):
        shared._fail("invalid_replicated_panel_prediction_count", "predictions need all cases")
    proposal_statuses: Counter[str] = Counter()
    local_positive_counts: Counter[int] = Counter()
    assigned_modules: Counter[str] = Counter()
    unique_candidate_counts: Counter[int] = Counter()
    decisions: Counter[str] = Counter()
    anchor_classes: Counter[str] = Counter()
    for index, case in enumerate(cases):
        location = f"replicated_panel_merged[{index}]"
        anchor = loaded[ANCHOR_PREDICTIONS_FILENAME][index]
        ledger = loaded[ANCHOR_LEDGER_AGGREGATE_FILENAME][index]
        checkpoint = loaded[ANCHOR_CHECKPOINT_AGGREGATE_FILENAME][index]
        panel = loaded[PANELS_FILENAME][index]
        selector = loaded[SELECTORS_FILENAME][index]
        shared._validate_prediction_record(anchor, case=case, location=f"{location}.anchor")
        if (
            ledger.get("trajectory_id") != case.trajectory_id
            or ledger.get("selected_step") != anchor["predicted_step"]
            or checkpoint.get("trajectory_id") != case.trajectory_id
            or checkpoint.get("predicted_step") != anchor["predicted_step"]
        ):
            shared._fail("replicated_panel_anchor_sidecar_mismatch", location)
        _validate_panel_record(panel, case=case, location=f"{location}.panel")
        _validate_selector_record(
            selector,
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            panel=panel,
            location=f"{location}.selector",
        )
        final = shared._validate_prediction_record(
            finals[index], case=case, location=f"{location}.final"
        )
        if final != selector["selected_prediction"]:
            shared._fail("replicated_panel_final_copy_mismatch", location)
        for proposal in panel["proposals"]:
            proposal_statuses[proposal["proposal_status"]] += 1
            local_positive_counts[proposal["owner_local_error_count"]] += 1
            assigned_modules[proposal["assigned_module"]] += 1
        unique_candidate_counts[len(panel["unique_candidate_steps"])] += 1
        decisions[selector["decision"]] += 1
        anchor_classes[selector["anchor_classification"]] += 1
    return {
        "required": True,
        "valid": True,
        "anchor_blind_replicas": True,
        "replicas_mutually_isolated": True,
        "complete_step_and_module_coverage": True,
        "proposal_replica_count": REPLICA_COUNT,
        "specialist_modules": list(SPECIALIST_MODULES),
        "maximum_candidates_per_replica": 1,
        "maximum_total_predictions": REPLICA_COUNT + 1,
        "vote_selection_forbidden": True,
        "default_anchor_policy": True,
        "anchor_causal_removal_literal_binding": True,
        "all_selected_predictions_exact_copies": True,
        "proposal_status_counts": dict(sorted(proposal_statuses.items())),
        "assigned_module_counts": dict(sorted(assigned_modules.items())),
        "local_positive_count_distribution": {
            str(key): value for key, value in sorted(local_positive_counts.items())
        },
        "unique_candidate_count_distribution": {
            str(key): value for key, value in sorted(unique_candidate_counts.items())
        },
        "selector_decision_counts": dict(sorted(decisions.items())),
        "anchor_classification_counts": dict(sorted(anchor_classes.items())),
        "packet_state_closure": parent._validate_packet_state_ledgers(
            root / ANCHOR_LEDGER_AGGREGATE_FILENAME
        ),
    }


def validate_agent_judge_luna_gaia_v3_52_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    panel = _validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_52_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_52_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_52_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_52_REASONING_EFFORT,
        "selection_policy": "clean_v3_20_module_factorized_local_census_proposal_panel",
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one module-factorized local-census proposal panel",
        "anchor_semantics_unchanged_from_v3_20": True,
        "all_selected_predictions_exact_copies": True,
        "factorized_specialist_panel": panel,
    }


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_proposal_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    replica_index: int,
    proposal_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_proposal(
            prediction_manifest_path,
            cohort_manifest_path,
            replica_index,
            proposal_path,
        ),
        audit_path,
    )


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_selector(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_52_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_52_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_luna_gaia_v3_52_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_selector_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / PANEL_FILENAME,
        prediction.parent / SELECTOR_FILENAME,
    )


# Shared orchestration compatibility aliases.
validate_and_write_agent_judge_luna_gaia_v3_37_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_52_audit
)
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_luna_gaia_v3_52_task
build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_52_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_52_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_52_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "proposal" and len(paths) == 5:
            audit = validate_and_write_proposal_audit(
                paths[0], paths[1], int(paths[2]), paths[3], paths[4]
            )
        elif stage == "selector" and len(paths) == 8:
            audit = validate_and_write_selector_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_52_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except (shared.AgentJudgeValidationError, json.JSONDecodeError, OSError, ValueError) as error:
        code = getattr(error, "code", type(error).__name__)
        print(json.dumps({"ok": False, "code": code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "proposal", "selector", "prediction"))
    parser.add_argument("paths", nargs="+")
    args = parser.parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

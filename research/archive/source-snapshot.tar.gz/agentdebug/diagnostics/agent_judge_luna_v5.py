"""Luna Agent Judge v5: module-lane recall and categorical arbitration.

The protocol is a single-session, single-case extension of Luna v3.  It does
not consume historical predictions or reviewer proposals.  It improves recall
of non-Planning owners and calibrates the first mature breakpoint with a fixed
set of gold-free categorical checks.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_v2_4 import (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION,
    _v2_4_owner_source_resolver,
)
from .agent_judge_luna_v3 import (
    AGENT_JUDGE_LUNA_V3_MODEL,
    AGENT_JUDGE_LUNA_V3_VERSION,
    build_agent_judge_luna_v3_task,
)


AGENT_JUDGE_LUNA_V5_VERSION = "agentdebug.codex-agent-judge.luna-v5"
AGENT_JUDGE_LUNA_V5_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_V5_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_V5_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)

_BASE_HEADER = f"Run the frozen Codex Agent Judge protocol {AGENT_JUDGE_LUNA_V3_VERSION}."
_LUNA_HEADER = (
    "Run the frozen Codex Agent Judge protocol "
    f"{AGENT_JUDGE_LUNA_V5_VERSION}."
)
_BASE_MODEL = f"- model: {AGENT_JUDGE_LUNA_V3_MODEL}"
_LUNA_MODEL = f"- model: {AGENT_JUDGE_LUNA_V5_MODEL}"
_BASE_ALLOWLIST = "agentdebug/diagnostics/agent_judge_luna_v3.py"
_LUNA_ALLOWLIST = "agentdebug/diagnostics/agent_judge_luna_v5.py"
_BASE_VALIDATOR_IMPORT = "agentdebug.diagnostics.agent_judge_luna_v3"
_LUNA_VALIDATOR_IMPORT = "agentdebug.diagnostics.agent_judge_luna_v5"
_BASE_VALIDATOR_ENTRY = "validate_and_write_agent_judge_luna_v3_audit"
_LUNA_VALIDATOR_ENTRY = "validate_and_write_agent_judge_luna_v5_audit"
_FIRST_MATURE_MARKER = "\n2. FIRST MATURE CAUSAL ERROR\n"

_LANE_AND_CATEGORY_AUDIT = """
MANDATORY MODULE-LANE CANDIDATE SHEET

The chronological scan must populate these six internal lanes before any step
is frozen.  Each lane is independent, may be empty, and contains at most the
specified directly evidenced candidate; lanes are recall devices, not votes.

1. MEMORY_LOCAL: earliest Memory output that invents, omits, loses, or
   over-compresses already visible task-relevant state and is used downstream.
2. REFLECTION_LOCAL: earliest Reflection output that clearly misreads direct
   feedback, outcome, progress, or cause and is used downstream.
3. PLANNING_FIRST: earliest Planning output with a directly shown ignored
   constraint, impossible prerequisite, or first known-no-progress repeat.
4. PLANNING_CONTRADICTION: the first distinct Plan whose factual premise is
   explicitly contradicted by its current observation, compact history,
   Memory, or Reflection—for example, it calls covered state unexplored.
5. ACTION_LOCAL: earliest Action output with a concrete plan deviation,
   unavailable operation, unparsable form, or mechanically malformed argument.
6. SYSTEM_BOUNDARY: the final provenance-backed external limit/fault, only if
   it independently blocks otherwise coherent progress.

Do not fill a lane with a merely weak hypothesis.  For every non-empty lane,
record internally: step, literal proposition, evidence available then,
downstream dependent decision, and whether exact task-relevant state was truly
recovered.  Compare all non-empty lanes only after completing the sheet.

MANDATORY CATEGORICAL ADMISSION AUDIT

Apply every check below to the lane candidates before selecting the first
mature causal error.  These checks are not ordered preferences; each describes
when a candidate is or is not locally valid and causally material.

REQUIRED-FIELD ACQUISITION
An operation is already erroneous when the same-step plan explicitly requires
a discriminator, ordering, filtered membership, history date, or state change
that the chosen interface/representation cannot expose.  Preserve this early
Action/misalignment root if no later step reacquires the missing field.  Do not
apply this to ordinary irrelevant search results or unknown open-world content.

WITHIN-STEP STATE CONTRADICTION
When a Plan calls a page, target, location, prerequisite, or field unexplored
or unsatisfied while current retained state says it was covered or satisfied,
the first causally used contradiction is a mature Planning error.  It can beat
an earlier generic continuation whose local defect was not yet demonstrated.
Correct Memory followed by a contradicting Plan assigns ownership to Planning.

LOSSY STATE SUMMARY
A Memory or Reflection summary owns when it omits or distorts a visible
task-relevant fact, uncertainty, completed coverage, or constraint; a dependent
decision uses that loss; and later behavior never restores the missing state.
Select the first causally used loss, not a later clearer restatement.  Harmless
compression and unconsumed imperfections are not errors.

CONTRADICTED ASSUMPTION
When observations already contradict a location, identity, capability, or
causal assumption and Reflection retains that assumption, the first such
Reflection is mature.  Require an actual contradiction, not lack of confirmation
from one reasonable probe.

PLAN-ACTION HANDOFF
When a Plan explicitly requires checking, filtering, ordering, acquiring
evidence, or reaching a prerequisite before committing, buying, answering, or
changing state, but Action commits without it, select Action/misalignment.
Do not apply when verification was completed earlier or reserved for a later
phase.  Faithful execution of a defective plan remains Planning.

FIRST KNOWN-NO-PROGRESS REPEAT
Once contemporaneous state records equivalent repeated coverage or explicit
no progress, select the first dependent Reflection or Plan that still treats
that same query/page/location/reset as useful novel coverage.  Do not require
byte-identical observations and do not wait for several more repetitions.
A genuinely new query, location, receptacle, or unvisited target remains novel
exploration even when another target failed.

NOVEL-SEARCH BOUNDARY
If a real step limit is enforced and all earlier challengers merely propose a
different feasible unvisited target, location, query, or branch without direct
evidence it would improve progress, select System/step_limit.  The existence of
other choices or finite budget alone does not make novel exploration
inefficient.  A concrete known-state repeat, contradiction, impossible
prerequisite, or explicit constraint violation can defeat the System candidate.

ACTION SUBTYPE
Use Action/misalignment when the concrete operation or representation cannot
implement the information/state requirement explicitly stated by the current
adequate Plan.  Use parameter_error only when the operation is capable but a
specific argument is missing, malformed, wrong-typed, or invalid.  Use
format_error only when interface syntax truly cannot parse; visual quotes in a
human-readable tagged action are not automatically literal command characters.

CONSERVATIVE EARLIEST SELECTION
Among candidates surviving both local validity and cascade relevance, choose
the earliest.  An earlier local imperfection loses if later behavior fully
recovers its task-relevant effect, no dependent decision uses it, or it was
reasonable exploration at that time.  A later candidate never wins merely by
being vivid or close to failure, but can win when it is the first explicit
contradiction or first post-feedback no-progress recommitment.
"""


def build_agent_judge_luna_v5_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build Luna v3 plus fixed module-lane and categorical audits."""

    task = build_agent_judge_luna_v3_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    replacements = {
        _BASE_HEADER: _LUNA_HEADER,
        _BASE_MODEL: _LUNA_MODEL,
        _BASE_ALLOWLIST: _LUNA_ALLOWLIST,
        _BASE_VALIDATOR_IMPORT: _LUNA_VALIDATOR_IMPORT,
        _BASE_VALIDATOR_ENTRY: _LUNA_VALIDATOR_ENTRY,
        _FIRST_MATURE_MARKER: (
            f"\n{_LANE_AND_CATEGORY_AUDIT.strip()}\n{_FIRST_MATURE_MARKER}"
        ),
    }
    for old, new in replacements.items():
        if task.count(old) != 1:
            raise RuntimeError(
                "Agent Judge Luna v3 task changed at a frozen v5 marker"
            )
        task = task.replace(old, new, 1)
    return task


def validate_agent_judge_luna_v5_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_v2_4_owner_source_resolver,
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_V5_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_V5_VERSION,
        "model": AGENT_JUDGE_LUNA_V5_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V5_REASONING_EFFORT,
    }


def validate_and_write_agent_judge_luna_v5_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_v5_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


__all__ = [
    "AGENT_JUDGE_LUNA_V5_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_V5_MODEL",
    "AGENT_JUDGE_LUNA_V5_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_V5_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "build_agent_judge_luna_v5_task",
    "validate_agent_judge_luna_v5_predictions",
    "validate_and_write_agent_judge_luna_v5_audit",
]

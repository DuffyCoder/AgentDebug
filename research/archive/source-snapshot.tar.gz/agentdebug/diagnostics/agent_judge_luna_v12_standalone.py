"""Standalone, proposal-free form of Luna v12 local-boundary semantics."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_luna_v3 import (
    AGENT_JUDGE_LUNA_V3_VERSION,
    build_agent_judge_luna_v3_task,
)
from .agent_judge_luna_v3_serial_v2 import _nested_owner_source_resolver
from .agent_judge_v2_4 import AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION


AGENT_JUDGE_LUNA_V12_STANDALONE_VERSION = (
    "agentdebug.codex-agent-judge.luna-v12-standalone-v1"
)
AGENT_JUDGE_LUNA_V12_STANDALONE_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_V12_STANDALONE_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_V12_STANDALONE_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)

_BASE_HEADER = f"Run the frozen Codex Agent Judge protocol {AGENT_JUDGE_LUNA_V3_VERSION}."
_NEW_HEADER = (
    "Run the frozen Codex Agent Judge protocol "
    f"{AGENT_JUDGE_LUNA_V12_STANDALONE_VERSION}."
)
_BASE_ALLOWLIST = "agentdebug/diagnostics/agent_judge_luna_v3.py"
_NEW_ALLOWLIST = (
    "agentdebug/diagnostics/agent_judge_luna_v12_standalone.py\n"
    "- agentdebug/diagnostics/agent_judge_luna_v3_serial_v2.py "
    "(nested-span evidence policy only)"
)
_BASE_VALIDATOR_IMPORT = "agentdebug.diagnostics.agent_judge_luna_v3"
_NEW_VALIDATOR_IMPORT = (
    "agentdebug.diagnostics.agent_judge_luna_v12_standalone"
)
_BASE_VALIDATOR_ENTRY = "validate_and_write_agent_judge_luna_v3_audit"
_NEW_VALIDATOR_ENTRY = (
    "validate_and_write_agent_judge_luna_v12_standalone_audit"
)

_STANDALONE_POLICY = """\
STANDALONE SINGLE-LOCAL-FAILURE ADJUDICATION

There is no incumbent, prior prediction, reviewer proposal, or default label.
Diagnose this trajectory from the complete JudgeView alone.  The benchmark
requests one critical failure annotation: choose the single output whose own
words or concrete operation most clearly instantiate a taxonomy error using
information available at that step and materially explain the recorded task
failure.  Local definition strength outranks generic chronology, visibility,
or a vague claim that another strategy might have been better.

1. RECONSTRUCT THE TRAJECTORY

Build a chronological ledger of literal task requirements, observations,
admissible actions/tools, attempts, outcomes, strategy changes, recovery, and
terminal execution facts.  A weak result, finite budget, normal failed probe,
or hindsight-preferred target is not by itself an error.

2. BUILD ALL MODULE CANDIDATES

Separately list every locally defensible Memory, Reflection, Planning, Action,
and final System candidate.  Admit a candidate only when its own source text
or operation satisfies a taxonomy definition at that time.  For each one,
record the contemporaneous contradiction and how correcting it would redirect
the dependent failure path.  Do not allow quote convenience or XML tag names
to decide ownership.

3. REFLECTION ASSERTIONS

Prefer the exact Reflection that falsely reports success, progress, failure,
causation, or task equivalence when the latest observation or a literal task
requirement disproves it.  Treat accepting a substitute object/attribute as
progress as a mature error.  Also admit a Reflection that says a different
approach is required while its guidance recommits to the same failed approach.
Attribute the false assessment itself to Reflection, not its following plan.

4. MEMORY AND INFORMATION FLOW

Memory owns a newly invented state, a material loss of already observed
requirements/state, or failure to retrieve a concrete available fact when a
later block consumes that defect.  Harmless compression and an unused imperfect
statement are not roots.  If accurate Memory is followed by a false Reflection,
Reflection owns; if both are accurate and Plan makes the bad choice, Planning
owns.

5. PLAN/ACTION CONTRACT

Compare same-step Plan and Action literally.  If an adequate plan says an
attribute, fact, prerequisite, or state must be verified before commit but the
Action buys, answers, or mutates state without verification, select that
Action/misalignment step.  Also select Action for unparseable syntax, an
unavailable operation, or a mechanically wrong argument.  A faithful action
never steals ownership from a defective plan.

6. IMPOSSIBLE OR CONTRADICTED PLAN

Prefer the plan that requires an object, capability, location, or state not
obtained and not currently available, or that literally conflicts with the
task/current admissible state.  A concrete impossible prerequisite or ignored
constraint outranks generic inefficiency.

7. REPETITION MATURITY AND RECOVERY EPOCHS

Do not label initial acquisition plus one distinct confirmation as repetition.
For repeated searches/navigation/operations, compare normalized intent,
returned evidence, and the plan's claimed refinement.  A genuinely new target
class, source, constraint, useful candidate, restored fact, or successful
equivalent operation begins a new epoch and vetoes the earlier generic search
complaint.  Within one epoch, select the clearest plan whose own text
acknowledges poor/repeated results yet recommits to an almost identical and
informationally incapable operation.  Do not automatically pick the first or
last member of a repetition chain.

8. TERMINAL SYSTEM

Select final-step System only when provenance-backed step/tool/model/environment
limits independently stop an otherwise coherent sequence of feasible,
distinct, observation-responsive actions.  Another unvisited target or a
hindsight-better strategy does not defeat System.  Reject System when an
explicit contradiction, false Reflection, impossible plan, plan/action breach,
or known repeated coverage already dominates the failure.

9. FINAL COMPETITION AND FREEZE

Compare the strongest candidates by: (a) literal taxonomy fit in the selected
output itself, (b) direct contemporaneous contradiction, and (c) causal
materiality to the recorded failure.  Inspect predecessor and successor to
avoid an off-by-one owner or step.  Freeze the winning step first, then select
its actual owner and one legal type.  Planning/inefficient_plan is admissible
only with a literal self-defeating recommitment, not generic slow progress.

For evidence, use one exact contiguous, case-sensitive substring of the
selected leaf module span at the frozen step.  If concrete module tags are
nested inside an outer `<think>` wrapper, the inner memory/reflection/plan/action
span owns its text; the outer wrapper does not authorize quoting an adjacent
module.  With no recognized spans, use the step's assistant raw output under
the selected owner policy.  System uses an accepted execution_facts line.

Never infer from case ID, source model, environment name, label distributions,
other predictions, or gold.  Return only the strict ten-field record with no
confidence, score, rank, vote, proposal verdict, or extra field.
"""


def build_agent_judge_luna_v12_standalone_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    task = build_agent_judge_luna_v3_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    replacements = {
        _BASE_HEADER: _NEW_HEADER,
        _BASE_ALLOWLIST: _NEW_ALLOWLIST,
        _BASE_VALIDATOR_IMPORT: _NEW_VALIDATOR_IMPORT,
        _BASE_VALIDATOR_ENTRY: _NEW_VALIDATOR_ENTRY,
    }
    for old, new in replacements.items():
        if task.count(old) != 1:
            raise RuntimeError(
                "Luna v3 task changed at a frozen standalone-v12 marker"
            )
        task = task.replace(old, new, 1)
    start_marker = "THE ONLY DECISION ORDER\n"
    end_marker = "AGENT ERROR TAXONOMY\n"
    start = task.find(start_marker)
    end = task.find(end_marker)
    if start < 0 or end <= start:
        raise RuntimeError("Luna v3 decision-policy markers changed")
    return task[:start] + _STANDALONE_POLICY + "\n\n" + task[end:]


def validate_agent_judge_luna_v12_standalone_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_nested_owner_source_resolver,
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_V12_STANDALONE_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_V12_STANDALONE_VERSION,
        "model": AGENT_JUDGE_LUNA_V12_STANDALONE_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V12_STANDALONE_REASONING_EFFORT,
        "proposal_free": True,
        "incumbent_routing_used": False,
        "nested_module_spans_supported": True,
    }


def validate_and_write_agent_judge_luna_v12_standalone_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_v12_standalone_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


__all__ = [
    "AGENT_JUDGE_LUNA_V12_STANDALONE_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_V12_STANDALONE_MODEL",
    "AGENT_JUDGE_LUNA_V12_STANDALONE_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_V12_STANDALONE_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "build_agent_judge_luna_v12_standalone_task",
    "validate_agent_judge_luna_v12_standalone_predictions",
    "validate_and_write_agent_judge_luna_v12_standalone_audit",
]

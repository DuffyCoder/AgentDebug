"""GAIA v3.103: clean-v3.83 predicate tournament with native initial-probe veto."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .agent_judge_gaia_v3_102_gpt55_three_attempt_access_validated_tournament import *  # noqa: F403
from . import agent_judge_gaia_v3_83_clean_v3p20_model_only_gpt55_medium as incumbent
from . import (
    agent_judge_gaia_v3_102_gpt55_three_attempt_access_validated_tournament as template,
)


AGENT_JUDGE_GAIA_V3_103_VERSION = (
    "agentdebug.codex-agent-judge.gaia-v3.103-gpt55-native-initial-probe-"
    "veto-predicate-handoff-tournament"
)
AGENT_JUDGE_GAIA_V3_103_MODEL = incumbent.AGENT_JUDGE_GAIA_V3_83_MODEL
AGENT_JUDGE_GAIA_V3_103_REASONING_EFFORT = incumbent.AGENT_JUDGE_GAIA_V3_83_REASONING_EFFORT
AGENT_JUDGE_GAIA_V3_103_AUDIT_SCHEMA_VERSION = incumbent.AGENT_JUDGE_GAIA_V3_83_AUDIT_SCHEMA_VERSION
SEMANTIC_PARENT = incumbent.AGENT_JUDGE_GAIA_V3_83_VERSION
SINGLE_MAJOR_CHANGE = (
    "replace accepted v3.83 challenger/arbiter with one outcome-conditioned "
    "predicate-handoff tournament in which native lane_c=veto_initial_probe "
    "has hard final precedence"
)

for _suffix in ("102", "101", "100", "99", "98", "97", "96", "95", "93"):
    globals()[f"AGENT_JUDGE_GAIA_V3_{_suffix}_VERSION"] = AGENT_JUDGE_GAIA_V3_103_VERSION
    globals()[f"AGENT_JUDGE_GAIA_V3_{_suffix}_MODEL"] = AGENT_JUDGE_GAIA_V3_103_MODEL
    globals()[f"AGENT_JUDGE_GAIA_V3_{_suffix}_REASONING_EFFORT"] = AGENT_JUDGE_GAIA_V3_103_REASONING_EFFORT
for _suffix in ("80", "79", "67", "37"):
    globals()[f"AGENT_JUDGE_LUNA_GAIA_V3_{_suffix}_VERSION"] = AGENT_JUDGE_GAIA_V3_103_VERSION
    globals()[f"AGENT_JUDGE_LUNA_GAIA_V3_{_suffix}_MODEL"] = AGENT_JUDGE_GAIA_V3_103_MODEL
    globals()[f"AGENT_JUDGE_LUNA_GAIA_V3_{_suffix}_REASONING_EFFORT"] = AGENT_JUDGE_GAIA_V3_103_REASONING_EFFORT


def _retag_task(task: str) -> str:
    return task.replace(template.AGENT_JUDGE_GAIA_V3_102_VERSION, AGENT_JUDGE_GAIA_V3_103_VERSION)


def _one(path: str | Path, *, role: str) -> dict[str, Any]:
    raw = shared._load_artifact(path, role=role)[1]  # noqa: F405
    if isinstance(raw, dict):
        return raw
    return shared._one_record(raw, role=role)  # noqa: F405


def _initial_probe_veto_steps(ledger: dict[str, Any]) -> list[int]:
    return [
        int(row["step"])
        for row in ledger.get("rows", [])
        if row.get("lane_c") == "veto_initial_probe"
        and isinstance(row.get("step"), int)
    ]


def build_anchor_file_task(
    prediction_manifest_path: str | Path, cohort_manifest_path: str | Path
) -> str:
    return _retag_task(
        template.build_anchor_file_task(prediction_manifest_path, cohort_manifest_path)
    )


def build_reducer_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> str:
    ledger = _one(ledger_path, role="native v3.83 anchor ledger")
    veto_steps = _initial_probe_veto_steps(ledger)
    task = _retag_task(
        template.build_reducer_file_task(
            prediction_manifest_path,
            cohort_manifest_path,
            anchor_path,
            ledger_path,
            checkpoint_path,
        )
    )
    marker = "BENCHMARK CRITICAL-BOUNDARY RULE\n"
    contract = (
        "NATIVE INITIAL-PROBE VETO — HARD FINAL PRECEDENCE\n"
        f"- Native ledger Steps with lane_c=veto_initial_probe: {json.dumps(veto_steps)}.\n"
        "- Review those Steps normally, but boundary_verdict MUST be false for each.\n"
        "- Such a Step cannot be the winner even if its observed outcome is unresolved.\n"
        "- This hard veto does not apply to veto_different_probe or an unvetoed row.\n\n"
    )
    if task.count(marker) != 1:
        raise RuntimeError("v3.103 critical-boundary marker changed unexpectedly")
    return task.replace(marker, contract + marker, 1)


def _assert_initial_probe_veto(
    ledger_path: str | Path, assessment_path: str | Path
) -> list[int]:
    ledger = _one(ledger_path, role="native v3.83 anchor ledger")
    assessment = _one(assessment_path, role="predicate-handoff tournament assessment")
    veto_steps = _initial_probe_veto_steps(ledger)
    for row in assessment.get("rows", []):
        if row.get("step") in veto_steps and row.get("boundary_verdict") is not False:
            shared._fail(  # noqa: F405
                "native_initial_probe_veto_overridden", "assessment.rows"
            )
    if assessment.get("selected_step") in veto_steps:
        shared._fail(  # noqa: F405
            "native_initial_probe_veto_selected", "assessment.selected_step"
        )
    return veto_steps


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_GAIA_V3_103_VERSION,
        "model": AGENT_JUDGE_GAIA_V3_103_MODEL,
        "reasoning_effort": AGENT_JUDGE_GAIA_V3_103_REASONING_EFFORT,
        "selection_policy": policy,
        "semantic_parent": SEMANTIC_PARENT,
        "direct_semantic_parent": SEMANTIC_PARENT,
        "rejected_lineage_inherited": False,
        "explicit_retested_mechanism": "native_initial_probe_veto_precedence",
        "single_major_change": SINGLE_MAJOR_CHANGE,
        "native_initial_probe_veto_hard_precedence": True,
        "maximum_fresh_attempts_per_stage": 3,
        "stage_local_access_validation_before_materialization": True,
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        template.validate_anchor_predictions(*paths),
        policy="v3p83_anchor_initial_probe_veto_input",
    )


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])  # noqa: F405


def validate_panel(*paths: str | Path) -> dict[str, Any]:
    audit = template.validate_panel(*paths)
    veto_steps = _assert_initial_probe_veto(paths[3], paths[5])
    return _retag(
        {**audit, "native_initial_probe_veto_steps": veto_steps},
        policy="native_initial_probe_veto_predicate_handoff_tournament",
    )


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_panel(*paths[:-1]), paths[-1])  # noqa: F405


def validate_selector(*paths: str | Path) -> dict[str, Any]:
    audit = template.validate_selector(*paths)
    veto_steps = _assert_initial_probe_veto(paths[3], paths[5])
    return _retag(
        {**audit, "native_initial_probe_veto_steps": veto_steps},
        policy="native_initial_probe_veto_exact_selection_copy",
    )


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_selector(*paths[:-1]), paths[-1])  # noqa: F405


def _validate_aggregate_initial_probe_veto(predictions_path: str | Path) -> int:
    root = Path(predictions_path).expanduser().resolve().parent
    ledgers = shared._load_artifact(  # noqa: F405
        root / ANCHOR_LEDGER_AGGREGATE_FILENAME, role="merged anchor ledgers"  # noqa: F405
    )[1]
    panels = shared._load_artifact(  # noqa: F405
        root / PANELS_FILENAME, role="merged tournament assessments"  # noqa: F405
    )[1]
    if not isinstance(ledgers, list) or not isinstance(panels, list) or len(ledgers) != len(panels):
        shared._fail("native_initial_probe_veto_aggregate_count", "merged")  # noqa: F405
    veto_count = 0
    for index, (ledger, assessment) in enumerate(zip(ledgers, panels, strict=True)):
        veto_steps = _initial_probe_veto_steps(ledger)
        veto_count += len(veto_steps)
        if assessment.get("selected_step") in veto_steps or any(
            row.get("step") in veto_steps and row.get("boundary_verdict") is not False
            for row in assessment.get("rows", [])
        ):
            shared._fail(  # noqa: F405
                "native_initial_probe_veto_aggregate_override", f"merged[{index}]"
            )
    return veto_count


def validate_agent_judge_gaia_v3_103_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = template.validate_agent_judge_gaia_v3_102_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    veto_count = _validate_aggregate_initial_probe_veto(predictions_path)
    return _retag(
        {**audit, "native_initial_probe_veto_row_count": veto_count},
        policy="native_initial_probe_veto_predicate_handoff_tournament",
    )


def validate_and_write_agent_judge_gaia_v3_103_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(  # noqa: F405
        validate_agent_judge_gaia_v3_103_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_gaia_v3_103_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_reducer_file_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,  # noqa: F405
    )


validate_and_write_agent_judge_luna_gaia_v3_37_audit = validate_and_write_agent_judge_gaia_v3_103_audit
validate_and_write_agent_judge_luna_gaia_v3_67_audit = validate_and_write_agent_judge_gaia_v3_103_audit
validate_and_write_agent_judge_luna_gaia_v3_79_audit = validate_and_write_agent_judge_gaia_v3_103_audit
validate_and_write_agent_judge_luna_gaia_v3_80_audit = validate_and_write_agent_judge_gaia_v3_103_audit
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_gaia_v3_103_task
build_agent_judge_luna_gaia_v3_79_task = build_agent_judge_gaia_v3_103_task
build_agent_judge_luna_gaia_v3_80_task = build_agent_judge_gaia_v3_103_task


def __getattr__(name: str) -> Any:
    return getattr(template, name)

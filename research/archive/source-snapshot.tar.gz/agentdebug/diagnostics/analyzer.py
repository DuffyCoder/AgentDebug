"""Canonical Trace → module specialists → arbiter → adversarial critic."""

from __future__ import annotations

import copy
import json
from typing import Any

from agentdebug.trace import CanonicalTrace, IntegrityStatus, validate_trace

from .judge_view import JUDGE_VIEW_VERSION, build_judge_view
from .models import (
    CriticRequest,
    DiagnosticReport,
    DiagnosticStatus,
    JudgeFailure,
    ModuleArbiterRequest,
    ModuleSpecialistRequest,
    ModuleSpecialistResult,
    RootCauseJudgment,
    SemanticJudge,
)
from .parsing import JudgeOutputError, parse_root, parse_specialist
from .providers import JudgeTransportError
from .taxonomy import AgentModule
from .validator import validate_evidence


DIAGNOSTIC_PIPELINE_VERSION = (
    "e5_module_specialists_adversarial_critic"
)


def _safe_raw(value: Any) -> Any:
    """Preserve provider output in a JSON-serializable form."""

    if isinstance(value, str):
        return value
    try:
        return json.loads(json.dumps(value, ensure_ascii=False, default=str))
    except (TypeError, ValueError):
        return repr(value)


def _counts_by_module(
    analyses: list[ModuleSpecialistResult],
) -> dict[str, int]:
    counts = {module.value: 0 for module in AgentModule}
    for analysis in analyses:
        counts[analysis.module.value] = len(analysis.findings)
    return counts


def _metadata(
    analyses: list[ModuleSpecialistResult],
    *,
    diagnosis_complete: bool,
) -> dict[str, Any]:
    counts = _counts_by_module(analyses)
    return {
        "judge_pipeline": DIAGNOSTIC_PIPELINE_VERSION,
        "diagnosis_complete": diagnosis_complete,
        "specialist_finding_count": sum(counts.values()),
        "counts_by_module": counts,
        "judge_view_version": JUDGE_VIEW_VERSION,
    }


def _failure(
    *,
    trace: CanonicalTrace,
    integrity: Any,
    stage: str,
    code: str,
    message: str,
    module_analyses: list[ModuleSpecialistResult],
    initial_root: RootCauseJudgment | None = None,
    raw_outputs: dict[str, Any],
) -> DiagnosticReport:
    return DiagnosticReport(
        schema_version=7,
        trace_id=trace.trace_id,
        status=DiagnosticStatus.INVALID,
        integrity=integrity,
        module_analyses=module_analyses,
        initial_root=initial_root,
        judge_failures=[
            JudgeFailure(stage=stage, code=code, message=message)
        ],
        raw_judge_outputs=raw_outputs,
        metadata=_metadata(module_analyses, diagnosis_complete=False),
    )


def _unexpected_failure_message(stage: str) -> str:
    return (
        f"The {stage} judge raised an unexpected exception; its message was "
        "omitted because it may contain sensitive data."
    )


class SemanticAnalyzer:
    """Run module specialists, an initial arbiter, and a final critic."""

    def __init__(self, *, judge: SemanticJudge) -> None:
        if not isinstance(judge, SemanticJudge):
            raise TypeError(
                "judge must implement analyze_module(request) and "
                "arbitrate_root_cause(request), and "
                "critique_root_cause(request)"
            )
        self.judge = judge

    def analyze(self, trace: CanonicalTrace) -> DiagnosticReport:
        if not isinstance(trace, CanonicalTrace):
            raise TypeError(
                "analyze accepts only agentdebug.trace.CanonicalTrace; "
                "legacy mappings and message trajectories are unsupported"
            )

        integrity = validate_trace(trace, strict=False)
        if integrity.status == IntegrityStatus.FAIL:
            metadata = _metadata([], diagnosis_complete=False)
            metadata["diagnosis_skipped"] = True
            return DiagnosticReport(
                schema_version=7,
                trace_id=trace.trace_id,
                status=DiagnosticStatus.BLOCKED_BY_INTEGRITY,
                integrity=integrity,
                module_analyses=[],
                metadata=metadata,
            )

        judge_view = build_judge_view(trace)
        module_analyses: list[ModuleSpecialistResult] = []
        raw_outputs: dict[str, Any] = {}

        # Each specialist receives a fresh trace snapshot and sees only its
        # assigned taxonomy module. Enum order is part of the E5 protocol.
        for module in AgentModule:
            stage = f"specialist.{module.value}"
            try:
                raw_specialist = self.judge.analyze_module(
                    ModuleSpecialistRequest(
                        trace=copy.deepcopy(trace),
                        module=module,
                    )
                )
                raw_outputs[stage] = _safe_raw(raw_specialist)
                analysis = parse_specialist(
                    raw_specialist,
                    trace=judge_view,
                    module=module,
                )
                module_analyses.append(analysis)
            except JudgeOutputError as error:
                raw_outputs[stage] = _safe_raw(error.raw_output)
                return _failure(
                    trace=trace,
                    integrity=integrity,
                    stage=error.stage,
                    code=error.code,
                    message=error.safe_message,
                    module_analyses=module_analyses,
                    raw_outputs=raw_outputs,
                )
            except JudgeTransportError as error:
                return _failure(
                    trace=trace,
                    integrity=integrity,
                    stage=stage,
                    code=error.code,
                    message=error.safe_message,
                    module_analyses=module_analyses,
                    raw_outputs=raw_outputs,
                )
            except Exception:
                return _failure(
                    trace=trace,
                    integrity=integrity,
                    stage=stage,
                    code="judge_exception",
                    message=_unexpected_failure_message(stage),
                    module_analyses=module_analyses,
                    raw_outputs=raw_outputs,
                )

        # The initial arbiter proposes one root from the strictly parsed,
        # independently produced specialist analyses.
        try:
            raw_arbiter = self.judge.arbitrate_root_cause(
                ModuleArbiterRequest(
                    trace=copy.deepcopy(trace),
                    module_analyses=copy.deepcopy(module_analyses),
                )
            )
            raw_outputs["arbiter"] = _safe_raw(raw_arbiter)
            initial_root = parse_root(
                raw_arbiter,
                trace=judge_view,
                stage="arbiter",
            )
        except JudgeOutputError as error:
            raw_outputs["arbiter"] = _safe_raw(error.raw_output)
            return _failure(
                trace=trace,
                integrity=integrity,
                stage=error.stage,
                code=error.code,
                message=error.safe_message,
                module_analyses=module_analyses,
                raw_outputs=raw_outputs,
            )
        except JudgeTransportError as error:
            return _failure(
                trace=trace,
                integrity=integrity,
                stage="arbiter",
                code=error.code,
                message=error.safe_message,
                module_analyses=module_analyses,
                raw_outputs=raw_outputs,
            )
        except Exception:
            return _failure(
                trace=trace,
                integrity=integrity,
                stage="arbiter",
                code="judge_exception",
                message=_unexpected_failure_message("arbiter"),
                module_analyses=module_analyses,
                raw_outputs=raw_outputs,
            )

        # The critic receives fresh, isolated copies of every semantic input.
        # It alone selects the final root cause.
        try:
            raw_critic = self.judge.critique_root_cause(
                CriticRequest(
                    trace=copy.deepcopy(trace),
                    module_analyses=copy.deepcopy(module_analyses),
                    initial_root=copy.deepcopy(initial_root),
                )
            )
            raw_outputs["critic"] = _safe_raw(raw_critic)
            root = parse_root(
                raw_critic,
                trace=judge_view,
                stage="critic",
            )
        except JudgeOutputError as error:
            raw_outputs["critic"] = _safe_raw(error.raw_output)
            return _failure(
                trace=trace,
                integrity=integrity,
                stage=error.stage,
                code=error.code,
                message=error.safe_message,
                module_analyses=module_analyses,
                initial_root=initial_root,
                raw_outputs=raw_outputs,
            )
        except JudgeTransportError as error:
            return _failure(
                trace=trace,
                integrity=integrity,
                stage="critic",
                code=error.code,
                message=error.safe_message,
                module_analyses=module_analyses,
                initial_root=initial_root,
                raw_outputs=raw_outputs,
            )
        except Exception:
            return _failure(
                trace=trace,
                integrity=integrity,
                stage="critic",
                code="judge_exception",
                message=_unexpected_failure_message("critic"),
                module_analyses=module_analyses,
                initial_root=initial_root,
                raw_outputs=raw_outputs,
            )

        # Specialists and the initial root are audit artifacts and critic
        # inputs only. Validate solely the critic-selected final root.
        validation = validate_evidence(trace, root, stage="critic")
        if not validation.valid:
            status = DiagnosticStatus.INVALID
        elif validation.needs_review:
            status = DiagnosticStatus.NEEDS_REVIEW
        else:
            status = DiagnosticStatus.VALID

        metadata = _metadata(module_analyses, diagnosis_complete=True)
        metadata["judge_view_version"] = judge_view.version
        metadata["initial_final_agree"] = (
            initial_root.critical_step,
            initial_root.module,
            initial_root.error_type,
        ) == (
            root.critical_step,
            root.module,
            root.error_type,
        )
        metadata["root_selected_by"] = "semantic_critic"
        return DiagnosticReport(
            schema_version=7,
            trace_id=trace.trace_id,
            status=status,
            integrity=integrity,
            module_analyses=module_analyses,
            initial_root=initial_root,
            root_cause=root,
            evidence_validation=validation,
            raw_judge_outputs=raw_outputs,
            metadata=metadata,
        )


def analyze(
    trace: CanonicalTrace,
    *,
    judge: SemanticJudge,
) -> DiagnosticReport:
    """Analyze one trace using five specialists, an arbiter, and a critic."""

    return SemanticAnalyzer(judge=judge).analyze(trace)

"""Gold-free same-case debate with two fresh proposals and a neutral arbiter."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any, Mapping

from agentdebug.benchmark.prediction_manifest import load_prediction_manifest

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
    _file_sha256,
    _load_json,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_luna_v3 import (
    AGENT_JUDGE_LUNA_V3_VERSION,
    build_agent_judge_luna_v3_task,
)
from .agent_judge_luna_v3_serial_v2 import _nested_owner_source_resolver
from .agent_judge_luna_v12_standalone import (
    AGENT_JUDGE_LUNA_V12_STANDALONE_VERSION,
    build_agent_judge_luna_v12_standalone_task,
)
from .agent_judge_v2_4 import AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION


AGENT_JUDGE_LUNA_DEBATE_V1_VERSION = (
    "agentdebug.codex-agent-judge.luna-clean-debate-v1"
)
AGENT_JUDGE_LUNA_DEBATE_V1_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_DEBATE_V1_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_DEBATE_V1_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)

PROPOSAL_A_FILENAME = "proposal-a.json"
PROPOSAL_B_FILENAME = "proposal-b.json"

_V3_HEADER = f"Run the frozen Codex Agent Judge protocol {AGENT_JUDGE_LUNA_V3_VERSION}."
_STANDALONE_HEADER = (
    "Run the frozen Codex Agent Judge protocol "
    f"{AGENT_JUDGE_LUNA_V12_STANDALONE_VERSION}."
)
_V3_ALLOWLIST = "agentdebug/diagnostics/agent_judge_luna_v3.py"
_STANDALONE_ALLOWLIST = (
    "agentdebug/diagnostics/agent_judge_luna_v12_standalone.py"
)
_DEBATE_ALLOWLIST = (
    "agentdebug/diagnostics/agent_judge_luna_debate_v1.py\n"
    "- agentdebug/diagnostics/agent_judge_luna_v3_serial_v2.py "
    "(nested-span evidence policy only)"
)


def _replace_once(task: str, old: str, new: str, *, marker: str) -> str:
    if task.count(old) != 1:
        raise RuntimeError(f"frozen debate task marker changed: {marker}")
    return task.replace(old, new, 1)


def _upgrade_common(
    task: str,
    *,
    base_header: str,
    base_allowlist: str,
    base_validator_module: str,
    base_validator_entry: str,
    new_validator_entry: str,
) -> str:
    task = _replace_once(
        task,
        base_header,
        f"Run the frozen Codex Agent Judge protocol {AGENT_JUDGE_LUNA_DEBATE_V1_VERSION}.",
        marker="header",
    )
    task = _replace_once(
        task, base_allowlist, _DEBATE_ALLOWLIST, marker="allowlist"
    )
    task = _replace_once(
        task,
        base_validator_module,
        "agentdebug.diagnostics.agent_judge_luna_debate_v1",
        marker="validator module",
    )
    task = _replace_once(
        task,
        base_validator_entry,
        new_validator_entry,
        marker="validator entry",
    )
    return task


def _add_proposal_boundary(
    task: str,
    proposals: tuple[tuple[str, Path], ...],
) -> str:
    lines = "\n".join(
        f"- anonymous {label}: {path}\n- anonymous {label} sha256: {_file_sha256(path)}"
        for label, path in proposals
    )
    task = _replace_once(
        task,
        "- write predictions only to:",
        lines + "\n- write predictions only to:",
        marker="proposal input boundary",
    )
    allowlist_lines = "\n".join(f"- {path}" for _, path in proposals)
    task = _replace_once(
        task,
        "GOLD-ISOLATION READ ALLOWLIST\n",
        "GOLD-ISOLATION READ ALLOWLIST\n" + allowlist_lines + "\n",
        marker="proposal read allowlist",
    )
    return task


def build_luna_clean_debate_draft_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
) -> str:
    task = build_agent_judge_luna_v3_task(
        prediction_manifest_path, cohort_manifest_path, proposal_a_path
    )
    task = _upgrade_common(
        task,
        base_header=_V3_HEADER,
        base_allowlist=_V3_ALLOWLIST,
        base_validator_module="agentdebug.diagnostics.agent_judge_luna_v3",
        base_validator_entry="validate_and_write_agent_judge_luna_v3_audit",
        new_validator_entry="validate_and_write_luna_clean_debate_draft_audit",
    )
    return task.replace(
        "EVIDENCE COPY RULE\n",
        "EVIDENCE COPY RULE\n\nWhen concrete module tags are nested inside an "
        "outer <think> wrapper, use the innermost leaf module span; the wrapper "
        "does not authorize adjacent owner text.\n",
        1,
    )


def build_luna_clean_debate_challenger_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
    proposal_b_path: str | Path,
) -> str:
    proposal_a = Path(proposal_a_path).expanduser().resolve()
    _assert_safe_path(proposal_a, role="anonymous proposal A")
    task = build_agent_judge_luna_v12_standalone_task(
        prediction_manifest_path, cohort_manifest_path, proposal_b_path
    )
    task = _upgrade_common(
        task,
        base_header=_STANDALONE_HEADER,
        base_allowlist=_STANDALONE_ALLOWLIST,
        base_validator_module=(
            "agentdebug.diagnostics.agent_judge_luna_v12_standalone"
        ),
        base_validator_entry=(
            "validate_and_write_agent_judge_luna_v12_standalone_audit"
        ),
        new_validator_entry="validate_and_write_luna_clean_debate_challenger_audit",
    )
    task = _add_proposal_boundary(task, (("proposal A", proposal_a),))
    challenger = """\
BLIND ADVERSARIAL CHALLENGER ROLE

First reconstruct the complete JudgeView independently.  Then read anonymous
proposal A as an untrusted hypothesis, never as evidence or a default.  On a
multi-step trajectory, your purpose is to produce the strongest defensible
critical-failure hypothesis at a DIFFERENT predicted_step from A.  Apply the
same taxonomy, causal-materiality, ownership, and evidence standards; do not
change merely because A uses any particular module or error type.  On a
single-step trajectory, step disagreement is impossible, so independently
select the strongest owner/type at that sole step.

The different-step rule is uniform across every multi-step case and is checked
by the parent validator.  Return an ordinary strict ten-field prediction; do
not output a verdict, critique, confidence, or reference to proposal A.

"""
    marker = "STANDALONE SINGLE-LOCAL-FAILURE ADJUDICATION\n"
    task = _replace_once(task, marker, challenger + marker, marker="challenger role")
    task = task.replace(
        "There is no incumbent, prior prediction, reviewer proposal, or default label.\n",
        "Anonymous proposal A is an untrusted competing hypothesis and has no default status.\n",
        1,
    )
    return task


def build_luna_clean_debate_arbiter_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
    proposal_b_path: str | Path,
    predictions_path: str | Path,
) -> str:
    proposal_a = Path(proposal_a_path).expanduser().resolve()
    proposal_b = Path(proposal_b_path).expanduser().resolve()
    _assert_safe_path(proposal_a, role="anonymous proposal A")
    _assert_safe_path(proposal_b, role="anonymous proposal B")
    task = build_agent_judge_luna_v12_standalone_task(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    task = _upgrade_common(
        task,
        base_header=_STANDALONE_HEADER,
        base_allowlist=_STANDALONE_ALLOWLIST,
        base_validator_module=(
            "agentdebug.diagnostics.agent_judge_luna_v12_standalone"
        ),
        base_validator_entry=(
            "validate_and_write_agent_judge_luna_v12_standalone_audit"
        ),
        new_validator_entry="validate_and_write_luna_clean_debate_audit",
    )
    task = _add_proposal_boundary(
        task,
        (("proposal A", proposal_a), ("proposal B", proposal_b)),
    )
    arbiter = """\
NEUTRAL BLIND ARBITER ROLE

Reconstruct the complete JudgeView independently before reading the two
anonymous proposals.  A and B are untrusted same-case hypotheses generated by
fresh sessions; neither is an incumbent, default, label, or evidence.  Their
order and module/type pairs carry no prior weight.  Test each proposed step
from the source: taxonomy fit in that output, contemporaneous contradiction,
causal materiality, predecessor/successor boundary, owner, and literal
evidence.  Identify any stronger omitted candidate as well.

Choose A, choose B, or reconstruct a third answer solely from the JudgeView.
Agreement is not proof; disagreement does not require changing A.  Never route
on planning/inefficient_plan or any other label pair.  Return only the ordinary
strict ten-field prediction, with no verdict, proposal name, confidence, or
extra field.

"""
    marker = "STANDALONE SINGLE-LOCAL-FAILURE ADJUDICATION\n"
    task = _replace_once(task, marker, arbiter + marker, marker="arbiter role")
    task = task.replace(
        "There is no incumbent, prior prediction, reviewer proposal, or default label.\n",
        "Anonymous proposals A and B are untrusted and have no default status.\n",
        1,
    )
    return task


def build_luna_clean_debate_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    output = Path(predictions_path).expanduser().resolve()
    return build_luna_clean_debate_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        output.parent / PROPOSAL_A_FILENAME,
        output.parent / PROPOSAL_B_FILENAME,
        output,
    )


def _validate_prediction(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    return _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_nested_owner_source_resolver,
    )


def validate_luna_clean_debate_draft_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
) -> dict[str, Any]:
    audit = _validate_prediction(
        prediction_manifest_path, cohort_manifest_path, proposal_a_path
    )
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_DEBATE_V1_VERSION,
        "stage": "chronological-draft",
        "model": AGENT_JUDGE_LUNA_DEBATE_V1_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_DEBATE_V1_REASONING_EFFORT,
        "gold_free_validation": True,
    }


def validate_luna_clean_debate_challenger_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
    proposal_b_path: str | Path,
) -> dict[str, Any]:
    validate_luna_clean_debate_draft_predictions(
        prediction_manifest_path, cohort_manifest_path, proposal_a_path
    )
    audit = _validate_prediction(
        prediction_manifest_path, cohort_manifest_path, proposal_b_path
    )
    _, cases = load_prediction_manifest(prediction_manifest_path)
    a_records = _load_json(Path(proposal_a_path).resolve(), role="proposal A")
    b_records = _load_json(Path(proposal_b_path).resolve(), role="proposal B")
    different_count = 0
    for index, (case, a_record, b_record) in enumerate(
        zip(cases, a_records, b_records, strict=True)
    ):
        if len(case.judge_view.steps) <= 1:
            continue
        if a_record["predicted_step"] == b_record["predicted_step"]:
            raise AgentJudgeValidationError(
                "challenger_step_not_different",
                f"multi-step challenger retained draft step at index {index}",
            )
        different_count += 1
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_DEBATE_V1_VERSION,
        "stage": "different-step-challenger",
        "model": AGENT_JUDGE_LUNA_DEBATE_V1_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_DEBATE_V1_REASONING_EFFORT,
        "gold_free_validation": True,
        "multi_step_different_proposal_count": different_count,
    }


def validate_luna_clean_debate_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    output = Path(predictions_path).expanduser().resolve()
    proposal_a = output.parent / PROPOSAL_A_FILENAME
    proposal_b = output.parent / PROPOSAL_B_FILENAME
    challenger_audit = validate_luna_clean_debate_challenger_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        proposal_a,
        proposal_b,
    )
    audit = _validate_prediction(
        prediction_manifest_path, cohort_manifest_path, output
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_DEBATE_V1_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_DEBATE_V1_VERSION,
        "model": AGENT_JUDGE_LUNA_DEBATE_V1_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_DEBATE_V1_REASONING_EFFORT,
        "proposal_free_of_historical_predictions": True,
        "label_pair_routing_used": False,
        "fresh_same_case_proposal_count": 2,
        "neutral_arbiter": True,
        "challenger_multi_step_difference_count": challenger_audit[
            "multi_step_different_proposal_count"
        ],
        "output_sha256": {
            "predictions.json": _file_sha256(output),
            PROPOSAL_A_FILENAME: _file_sha256(proposal_a),
            PROPOSAL_B_FILENAME: _file_sha256(proposal_b),
        },
    }


def _write_audit(audit_path: str | Path, audit: Mapping[str, Any]) -> dict[str, Any]:
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="debate audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(dict(audit), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return dict(audit)


def validate_and_write_luna_clean_debate_draft_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        audit_path,
        validate_luna_clean_debate_draft_predictions(
            prediction_manifest_path, cohort_manifest_path, proposal_a_path
        ),
    )


def validate_and_write_luna_clean_debate_challenger_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_b_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    output = Path(proposal_b_path).expanduser().resolve()
    return _write_audit(
        audit_path,
        validate_luna_clean_debate_challenger_predictions(
            prediction_manifest_path,
            cohort_manifest_path,
            output.parent / PROPOSAL_A_FILENAME,
            output,
        ),
    )


def validate_and_write_luna_clean_debate_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        audit_path,
        validate_luna_clean_debate_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
    )


__all__ = [
    "AGENT_JUDGE_LUNA_DEBATE_V1_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_DEBATE_V1_MODEL",
    "AGENT_JUDGE_LUNA_DEBATE_V1_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_DEBATE_V1_VERSION",
    "PROPOSAL_A_FILENAME",
    "PROPOSAL_B_FILENAME",
    "build_luna_clean_debate_arbiter_task",
    "build_luna_clean_debate_challenger_task",
    "build_luna_clean_debate_draft_task",
    "build_luna_clean_debate_task",
    "validate_luna_clean_debate_challenger_predictions",
    "validate_luna_clean_debate_draft_predictions",
    "validate_luna_clean_debate_predictions",
]

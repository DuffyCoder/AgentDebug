"""Luna v3 serial v2: expose deterministic owner-source blocks to Type.

V1 established the three-fresh-session Step -> Module -> Type topology.  V2
changes no semantic decision policy.  It renders the exact gold-free source
blocks accepted by the evidence validator after step/module are frozen, so the
Type Agent cannot accidentally quote an adjacent module's same-step text.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from . import agent_judge_luna_v3_serial as v1
from .agent_judge import (
    _execution_fact_lines,
    _file_sha256,
    _load_json,
    _string_leaves,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .taxonomy import AgentModule, ErrorType, TAXONOMY


AGENT_JUDGE_LUNA_V3_SERIAL_V2_VERSION = (
    "agentdebug.codex-agent-judge.luna-v3-serial-v2"
)
AGENT_JUDGE_LUNA_V3_SERIAL_V2_MODEL = v1.AGENT_JUDGE_LUNA_V3_SERIAL_MODEL
AGENT_JUDGE_LUNA_V3_SERIAL_V2_REASONING_EFFORT = (
    v1.AGENT_JUDGE_LUNA_V3_SERIAL_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_V3_SERIAL_V2_AUDIT_SCHEMA_VERSION = (
    v1.AGENT_JUDGE_LUNA_V3_SERIAL_AUDIT_SCHEMA_VERSION
)

STEP_DECISIONS_FILENAME = v1.STEP_DECISIONS_FILENAME
MODULE_DECISIONS_FILENAME = v1.MODULE_DECISIONS_FILENAME
STEP_AUDIT_FILENAME = v1.STEP_AUDIT_FILENAME
MODULE_AUDIT_FILENAME = v1.MODULE_AUDIT_FILENAME


def _upgrade_task(task: str) -> str:
    return task.replace(
        v1.AGENT_JUDGE_LUNA_V3_SERIAL_VERSION,
        AGENT_JUDGE_LUNA_V3_SERIAL_V2_VERSION,
    ).replace(
        "agentdebug.diagnostics.agent_judge_luna_v3_serial import "
        "validate_and_write_agent_judge_luna_v3_serial_",
        "agentdebug.diagnostics.agent_judge_luna_v3_serial_v2 import "
        "validate_and_write_agent_judge_luna_v3_serial_v2_",
    ).replace(
        "agentdebug.diagnostics.agent_judge_luna_v3_serial import "
        "validate_and_write_agent_judge_luna_v3_serial_audit",
        "agentdebug.diagnostics.agent_judge_luna_v3_serial_v2 import "
        "validate_and_write_agent_judge_luna_v3_serial_v2_audit",
    )


def build_agent_judge_luna_v3_serial_v2_step_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
) -> str:
    return _upgrade_task(
        v1.build_agent_judge_luna_v3_serial_step_task(
            prediction_manifest_path,
            cohort_manifest_path,
            step_decisions_path,
        )
    )


def build_agent_judge_luna_v3_serial_v2_module_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
) -> str:
    base = _upgrade_task(
        v1.build_agent_judge_luna_v3_serial_module_task(
            prediction_manifest_path,
            cohort_manifest_path,
            step_decisions_path,
            module_decisions_path,
        )
    )
    sources = _module_source_map(
        prediction_manifest_path,
        cohort_manifest_path,
        step_decisions_path,
    )
    source_section = f"""\
DETERMINISTIC VALIDATOR-ELIGIBLE OWNER SOURCE BLOCKS

The following JSON is computed only from this case's JudgeView and the frozen
step.  It contains no score or gold label.  Choose the semantic owner using
the direction-of-information-flow rules, and ensure that owner has at least
one non-empty source block below.  Outer wrapper tags that merely contain
more specific nested module tags are intentionally excluded.

{json.dumps(sources, ensure_ascii=False, indent=2)}

"""
    marker = "STRICT OUTPUT CONTRACT\n"
    if marker not in base:
        raise RuntimeError("serial v1 Module task no longer has the expected marker")
    return base.replace(marker, source_section + marker, 1)


def _evidence_source_map(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
) -> dict[str, list[str]]:
    prediction_path = Path(prediction_manifest_path).expanduser().resolve()
    cohort_path = Path(cohort_manifest_path).expanduser().resolve()
    step_path = Path(step_decisions_path).expanduser().resolve()
    module_path = Path(module_decisions_path).expanduser().resolve()
    cases, module_records = v1._validate_module_records(
        prediction_path,
        cohort_path,
        step_path,
        module_path,
    )
    if len(cases) != 1 or len(module_records) != 1:
        v1._fail("invalid_stage_count", "Type Agent requires exactly one case")
    record = module_records[0]
    module = AgentModule(record["predicted_module"])
    predicted_step = int(record["predicted_step"])
    return {
        error_type.value: list(
            _nested_owner_source_resolver(
                cases[0].judge_view,
                predicted_step,
                module,
                error_type,
            )
        )
        for error_type in TAXONOMY[module]
    }


def _nested_owner_source_resolver(
    view: Any,
    predicted_step: int,
    module: AgentModule,
    error_type: ErrorType,
) -> tuple[str, ...]:
    """Resolve exact sources while supporting nested module wrappers.

    Released traces may wrap concrete ``memory/reflection/plan/action`` tags
    inside one outer ``think`` tag.  The older all-spans-non-overlap guard
    discarded every source in that shape.  V2 validates each span's geometry
    independently and keeps only leaf module spans, so an enclosing wrapper
    can never authorize quoting an adjacent nested owner.
    """

    if module == AgentModule.SYSTEM:
        if predicted_step != len(view.steps):
            return ()
        return _execution_fact_lines(view.execution_facts)

    step = view.steps[predicted_step - 1]
    raw = step.assistant_raw_output
    valid_spans = tuple(
        span
        for span in sorted(
            step.module_spans,
            key=lambda item: (item.tag_start_char, item.tag_end_char),
        )
        if span.tag_start_char >= 0
        and span.tag_end_char > span.tag_start_char
        and span.tag_end_char <= len(raw)
    )
    leaf_spans = tuple(
        span
        for span in valid_spans
        if not any(
            other is not span
            and other.tag_start_char >= span.tag_start_char
            and other.tag_end_char <= span.tag_end_char
            and (
                other.tag_start_char > span.tag_start_char
                or other.tag_end_char < span.tag_end_char
            )
            for other in valid_spans
        )
    )
    sources = [
        raw[span.tag_start_char : span.tag_end_char]
        for span in leaf_spans
        if span.module == module.value
    ]
    if not step.module_spans and raw.strip():
        sources.append(raw)
    if module == AgentModule.ACTION:
        for call in step.tool_calls:
            sources.append(call.name)
            sources.extend(_string_leaves(call.arguments))
            sources.extend(_string_leaves(call.partial_arguments))
    return tuple(dict.fromkeys(source for source in sources if source.strip()))


def _module_source_map(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
) -> dict[str, list[str]]:
    prediction_path = Path(prediction_manifest_path).expanduser().resolve()
    cohort_path = Path(cohort_manifest_path).expanduser().resolve()
    step_path = Path(step_decisions_path).expanduser().resolve()
    cases, step_records = v1._validate_step_records(
        prediction_path, cohort_path, step_path
    )
    if len(cases) != 1 or len(step_records) != 1:
        v1._fail("invalid_stage_count", "Module Agent requires exactly one case")
    predicted_step = int(step_records[0]["predicted_step"])
    result: dict[str, list[str]] = {}
    for module in AgentModule:
        sources: list[str] = []
        for error_type in TAXONOMY[module]:
            sources.extend(
                _nested_owner_source_resolver(
                    cases[0].judge_view,
                    predicted_step,
                    module,
                    error_type,
                )
            )
        result[module.value] = list(dict.fromkeys(sources))
    return result


def build_agent_judge_luna_v3_serial_v2_type_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
    predictions_path: str | Path,
) -> str:
    base = _upgrade_task(
        v1.build_agent_judge_luna_v3_serial_type_task(
            prediction_manifest_path,
            cohort_manifest_path,
            step_decisions_path,
            module_decisions_path,
            predictions_path,
        )
    )
    sources = _evidence_source_map(
        prediction_manifest_path,
        cohort_manifest_path,
        step_decisions_path,
        module_decisions_path,
    )
    evidence_section = f"""\
DETERMINISTIC VALIDATOR-OWNED EVIDENCE SOURCE BLOCKS

The following JSON is computed only from this case's JudgeView and the frozen
step/module.  It contains no score or gold label.  First choose one legal
error type.  Then copy evidence_quote as an exact non-empty contiguous,
case-sensitive substring of one source string listed under THAT SAME type.
Do not quote a semantically similar sentence from elsewhere in the step.

{json.dumps(sources, ensure_ascii=False, indent=2)}

Before writing, perform a literal substring check against this list.  If local
validation reports invalid_evidence_ownership, replace only evidence_quote
with a literal substring from the selected type's listed blocks; do not alter
the frozen step or module.

"""
    marker = "STRICT TEN-FIELD OUTPUT CONTRACT\n"
    if marker not in base:
        raise RuntimeError("serial v1 Type task no longer has the expected marker")
    return base.replace(marker, evidence_section + marker, 1)


def build_agent_judge_luna_v3_serial_v2_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    output_path = Path(predictions_path).expanduser().resolve()
    return build_agent_judge_luna_v3_serial_v2_type_task(
        prediction_manifest_path,
        cohort_manifest_path,
        output_path.parent / STEP_DECISIONS_FILENAME,
        output_path.parent / MODULE_DECISIONS_FILENAME,
        output_path,
    )


def _upgrade_audit(audit: dict[str, Any]) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_V3_SERIAL_V2_VERSION,
        "model": AGENT_JUDGE_LUNA_V3_SERIAL_V2_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V3_SERIAL_V2_REASONING_EFFORT,
        "deterministic_owner_sources_exposed_to_type_agent": True,
    }


def validate_agent_judge_luna_v3_serial_v2_step_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
) -> dict[str, Any]:
    return _upgrade_audit(
        v1.validate_agent_judge_luna_v3_serial_step_predictions(
            prediction_manifest_path,
            cohort_manifest_path,
            step_decisions_path,
        )
    )


def validate_agent_judge_luna_v3_serial_v2_module_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
) -> dict[str, Any]:
    base = v1.validate_agent_judge_luna_v3_serial_module_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        step_decisions_path,
        module_decisions_path,
    )
    prediction_path = Path(prediction_manifest_path).expanduser().resolve()
    cohort_path = Path(cohort_manifest_path).expanduser().resolve()
    step_path = Path(step_decisions_path).expanduser().resolve()
    module_path = Path(module_decisions_path).expanduser().resolve()
    cases, records = v1._validate_module_records(
        prediction_path, cohort_path, step_path, module_path
    )
    for index, (case, record) in enumerate(zip(cases, records, strict=True)):
        module = AgentModule(record["predicted_module"])
        step = int(record["predicted_step"])
        eligible = any(
            _nested_owner_source_resolver(
                case.judge_view, step, module, error_type
            )
            for error_type in TAXONOMY[module]
        )
        if not eligible:
            v1._fail(
                "module_has_no_evidence_source",
                f"module stage selected an owner with no eligible source at index {index}",
            )
    return _upgrade_audit(
        {
            **base,
            "all_modules_have_validator_eligible_source": True,
        }
    )


def validate_agent_judge_luna_v3_serial_v2_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    prediction_path = Path(prediction_manifest_path).expanduser().resolve()
    cohort_path = Path(cohort_manifest_path).expanduser().resolve()
    output_path = Path(predictions_path).expanduser().resolve()
    step_path = output_path.parent / STEP_DECISIONS_FILENAME
    module_path = output_path.parent / MODULE_DECISIONS_FILENAME
    validate_agent_judge_luna_v3_serial_v2_module_predictions(
        prediction_path, cohort_path, step_path, module_path
    )
    _, module_records = v1._validate_module_records(
        prediction_path, cohort_path, step_path, module_path
    )
    audit = _validate_agent_judge_predictions_with_owner_sources(
        prediction_path,
        cohort_path,
        output_path,
        owner_source_resolver=_nested_owner_source_resolver,
    )
    final_records = _load_json(output_path, role="predictions")
    for index, (module_record, final_record) in enumerate(
        zip(module_records, final_records, strict=True)
    ):
        if final_record["predicted_step"] != module_record["predicted_step"]:
            v1._fail("serial_step_revision", f"type stage revised step at index {index}")
        if final_record["predicted_module"] != module_record["predicted_module"]:
            v1._fail(
                "serial_module_revision", f"type stage revised module at index {index}"
            )
    return _upgrade_audit(
        {
            **audit,
            "serial_stage_count": 3,
            "serial_step_frozen": True,
            "serial_module_frozen": True,
            "nested_module_spans_supported": True,
            "output_sha256": {
                "predictions.json": _file_sha256(output_path),
                STEP_DECISIONS_FILENAME: _file_sha256(step_path),
                MODULE_DECISIONS_FILENAME: _file_sha256(module_path),
            },
            "validation_method": (
                "Gold-free strict serial artifacts, exact carry-forward, "
                "leaf-owner evidence for nested module spans, and taxonomy checks."
            ),
        }
    )


def validate_and_write_agent_judge_luna_v3_serial_v2_step_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return v1._write_audit(
        audit_path,
        validate_agent_judge_luna_v3_serial_v2_step_predictions(
            prediction_manifest_path, cohort_manifest_path, step_decisions_path
        ),
    )


def validate_and_write_agent_judge_luna_v3_serial_v2_module_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return v1._write_audit(
        audit_path,
        validate_agent_judge_luna_v3_serial_v2_module_predictions(
            prediction_manifest_path,
            cohort_manifest_path,
            step_decisions_path,
            module_decisions_path,
        ),
    )


def validate_and_write_agent_judge_luna_v3_serial_v2_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return v1._write_audit(
        audit_path,
        validate_agent_judge_luna_v3_serial_v2_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
    )


__all__ = [
    "AGENT_JUDGE_LUNA_V3_SERIAL_V2_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_V3_SERIAL_V2_MODEL",
    "AGENT_JUDGE_LUNA_V3_SERIAL_V2_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_V3_SERIAL_V2_VERSION",
    "build_agent_judge_luna_v3_serial_v2_module_task",
    "build_agent_judge_luna_v3_serial_v2_step_task",
    "build_agent_judge_luna_v3_serial_v2_task",
    "build_agent_judge_luna_v3_serial_v2_type_task",
    "validate_agent_judge_luna_v3_serial_v2_module_predictions",
    "validate_agent_judge_luna_v3_serial_v2_predictions",
    "validate_agent_judge_luna_v3_serial_v2_step_predictions",
]

"""Luna GAIA v3.75: clean-v3.20 sparse-ledger global boundary selector."""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions
from .taxonomy import AgentModule, ErrorType, TAXONOMY, is_valid_classification, taxonomy_prompt


AGENT_JUDGE_LUNA_GAIA_V3_75_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.75-clean-v3.20-"
    "sparse-ledger-global-boundary-selector"
)
AGENT_JUDGE_LUNA_GAIA_V3_75_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_75_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_75_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases for the frozen full-50 aggregation runner.
AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_75_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_75_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_75_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_75_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_75_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_75_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_75_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_75_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_75_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_75_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
PANEL_FILENAME = "sparse-ledger-global-boundary-assessment.json"
PANELS_FILENAME = "sparse-ledger-global-boundary-assessments.json"
PANEL_AUDIT_FILENAME = "sparse-ledger-global-boundary-assessment-audit.json"
SELECTOR_FILENAME = "sparse-ledger-global-boundary-selection.json"
SELECTORS_FILENAME = "sparse-ledger-global-boundary-selections.json"
SELECTOR_AUDIT_FILENAME = "sparse-ledger-global-boundary-selection-audit.json"
INFERENCE_DOCUMENT_FILENAME = "owner-explicit-inference-document.json"

MODULES = tuple(module.value for module in AgentModule)
ERROR_TYPES = tuple(error_type.value for error_type in ErrorType)
DECISIONS = frozenset({"keep_anchor", "select_prefix", "select_later"})
BOUNDARY_ROLES = frozenset({"ledger_boundary", "later_boundary"})
DEFECT_CLASSES = frozenset(
    {
        "material_local_error",
        "reasonable_probe",
        "normal_tool_failure",
        "recovered_defect",
        "faithful_propagation",
        "downstream_symptom",
        "no_material_error",
        "uncertain",
    }
)
RECOVERY_STATUSES = frozenset(
    {"unrecovered", "recovered", "not_applicable", "uncertain"}
)
OUTCOME_RELATIONS = frozenset(
    {
        "redirects_failed_path",
        "contributes_then_later_failure",
        "propagates_prior_gap",
        "independent_later_failure",
        "no_material_effect",
        "uncertain",
    }
)
CRITICALITY_VERDICTS = frozenset({"critical_root", "noncritical", "uncertain"})

REVIEW_FIELDS = (
    "step",
    "boundary_role",
    "observed_defect_class",
    "recovery_status",
    "outcome_relation",
    "criticality_verdict",
    "comparison_basis",
)
ASSESSMENT_FIELDS = (
    "later_candidate_step",
    "candidate_reviews",
    "decision",
    "selected_step",
    "selected_module",
    "selected_error_type",
    "selected_evidence_quote",
    "selected_root_cause",
    "selected_causal_summary",
    "selected_rejected_adjacent_owner",
    "chronology_comparison",
    "selection_falsifier",
)
SELECTION_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "anchor_prediction_sha256",
    "anchor_ledger_sha256",
    "anchor_checkpoint_sha256",
    "assessment_sha256",
    "decision",
    "anchor_step",
    "reviewed_steps",
    "later_candidate_step",
    "selected_step",
    "frozen_step",
    "selected_prediction_sha256",
    "selected_prediction",
    "semantic_assessment",
)


_GLOBAL_SELECTOR_RULES = """\
SPARSE-LEDGER GLOBAL CRITICAL-BOUNDARY SELECTOR — ONE FINAL STEP

The fresh clean-v3.20 anchor is the default, not a gold hint. Its sparse ledger
supplies a bounded chronological Step set, not votes and not prior verdicts.
Review EVERY supplied ledger Step. You may additionally nominate at most one
strictly post-anchor Step by tracing backward from the terminal failure. Then
choose exactly one reviewed Step.

CRITICAL BOUNDARY

Choose the earliest concrete local error that set the trajectory on the
material failed branch. The required counterfactual is local: correcting that
Step must redirect the next material information, strategy, action, or state
transition. It need not single-handedly solve the entire remaining task. The
boundary must already be observable at that Step from the complete timeline.

COMPARATIVE REVIEW — NO PRE-ADMISSION DELETION

For every ledger Step, record its actual local defect class, what happened
after it, whether it recovered, its relation to the failed path, and whether it
is the critical root. `reasonable_probe`, `normal_tool_failure`,
`recovered_defect`, `faithful_propagation`, and `downstream_symptom` are review
outcomes, never reasons to omit the Step from candidate_reviews.

- A probe can be critical when its target, source, parameter, modality, or
  result handoff already contains a concrete material defect. A merely
  unsuccessful but informative probe is noncritical.
- A normal negative/empty/blocked external result is not automatically a
  System error. Attribute an Agent-owned bad call/plan/handoff to its literal
  owner; use System only for a provenance-backed independent execution failure.
- A defect is recovered only when later observed state and behavior fully
  repair its path effect. Partial progress or a new search does not by itself
  prove recovery.
- Faithful propagation and terminal failure are symptoms when an earlier
  reviewed Step already owns the same unrecovered gap.
- Do not pick the first surface imperfection merely because it is early. Do not
  pick a later Step because it is more vivid, repeated, persistent, explicit,
  severe, or closer to the final answer.

LATER SLOT AND DEFAULT

Nominate one later_candidate_step only if a strictly post-anchor Step is the
first mature boundary that the bounded ledger cannot represent. Review it
under the same fields and chronology. Do not create more than one later
candidate. When no alternative has a clear literal, outcome-grounded advantage
over the anchor, keep the anchor exactly. An alternative can replace the
anchor only when its selected review is `critical_root` and the chronology
comparison explains why the anchor and every earlier plausible boundary are
noncritical or downstream.

First complete candidate_reviews in exact supplied order, appending the later
candidate last when present. Then freeze decision and selected_step. Module and
error type are legal output ownership only; never use them to rank Steps.
Never use trajectory identity, source model, entity/site priors, scores, gold,
old predictions, case reports, or cross-case patterns.
"""


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_75_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_75_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_75_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one sparse-ledger global critical-boundary selector",
        "legality_scaffolding_only_migrated": True,
        "step_semantics_unchanged_by_legality_materialization": True,
    }


def _observation_excerpt(observation: Any) -> str:
    projection = observation.benchmark_input
    if projection is not None:
        pieces = (
            observation.text[
                projection.step_marker_start_char : projection.step_marker_end_char
            ],
            observation.text[
                projection.observation_start_char : projection.observation_end_char
            ],
            observation.text[projection.suffix_start_char : projection.suffix_end_char],
        )
        return "\n".join(piece.strip() for piece in pieces if piece.strip())
    if observation.repeated_prefix_chars > 0:
        return observation.incremental_text.strip()
    return observation.text.strip()


def build_inference_document(case: Any) -> dict[str, Any]:
    """Gold-free full chronology with literal evidence grouped by owner."""

    steps: list[dict[str, Any]] = []
    for step in case.judge_view.steps:
        owner_sources: dict[str, list[str]] = {
            module.value: [] for module in AgentModule
        }
        for span in step.module_spans:
            text = step.assistant_raw_output[
                span.content_start_char : span.content_end_char
            ]
            if span.module in owner_sources and text.strip():
                owner_sources[span.module].append(text.strip())
        owner_sources[AgentModule.SYSTEM.value] = list(
            shared._luna_gaia_v2_owner_source_resolver(
                case.judge_view,
                step.step,
                AgentModule.SYSTEM,
                ErrorType.TOOL_EXECUTION_ERROR,
            )
        )
        steps.append(
            {
                "step": step.step,
                "literal_owner_sources": owner_sources,
                "feedback_after_step": [
                    value
                    for item in step.adjacent_feedback
                    if (value := _observation_excerpt(item))
                ],
                "stop_reason": step.stop_reason,
                "error_message": step.error_message,
            }
        )
    facts = case.judge_view.execution_facts
    first_input = [
        value
        for item in case.judge_view.steps[0].current_input
        if (value := _observation_excerpt(item))
    ]
    return {
        "schema_version": "agentdebug.v3p75-owner-explicit-full-judge-view.v1",
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "task": {"user_request": case.judge_view.task.user_request},
        "execution_facts": {
            "metadata_steps": facts.metadata_steps,
            "metadata_won": facts.metadata_won,
            "metadata_success": facts.metadata_success,
            "canonical_turn_count": facts.canonical_turn_count,
            "final_stop_reason": facts.final_stop_reason,
            "final_error_message": facts.final_error_message,
        },
        "input_before_first_step": first_input,
        "step_count": len(steps),
        "steps": steps,
        "deduplication_contract": (
            "For every Step after 1, input_before_step equals the prior Step's "
            "feedback_after_step. Evidence-eligible substrings are grouped under "
            "literal_owner_sources."
        ),
    }


def validate_inference_document(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    document_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    document_file, document = shared._load_artifact(
        document_path, role="v3.75 owner-explicit inference document"
    )
    if document != build_inference_document(case):
        shared._fail("non_deterministic_v3p75_inference_document", "inference_document")
    return _retag(
        {
            "schema_version": "agentdebug.v3p75-inference-document-audit.v1",
            "stage": "deterministic_owner_explicit_full_judge_view",
            "gold_free_validation": True,
            "case_count": 1,
            "complete_step_coverage": True,
            "all_literal_owner_sources_explicit": True,
            "input_sha256": {
                "prediction_manifest": shared._file_sha256(manifest),
                "cohort": shared._file_sha256(cohort),
            },
            "output_sha256": {
                INFERENCE_DOCUMENT_FILENAME: shared._file_sha256(document_file)
            },
        },
        policy="deterministic_gold_free_owner_explicit_inference_document",
    )


def _prediction_schema() -> dict[str, Any]:
    properties = {
        "trajectory_id": {"type": "string"},
        "trajectory_sha256": {"type": "string"},
        "status": {"type": "string", "enum": ["success"]},
        "predicted_step": {"type": "integer", "minimum": 1},
        "predicted_module": {"type": "string", "enum": list(MODULES)},
        "predicted_error_type": {"type": "string", "enum": list(ERROR_TYPES)},
        "evidence_quote": {"type": "string", "minLength": 1},
        "root_cause": {"type": "string", "minLength": 1},
        "causal_summary": {"type": "string", "minLength": 1},
        "rejected_adjacent_owner": {"type": "string", "minLength": 1},
    }
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties),
        "additionalProperties": False,
    }


def anchor_response_schema() -> dict[str, Any]:
    lane_statuses = [
        "clear",
        "candidate",
        "veto_mechanical_repair",
        "veto_initial_probe",
        "veto_different_probe",
        "veto_terminal_supersession",
    ]
    row_properties = {
        "step": {"type": "integer", "minimum": 1},
        "lane_a": {"type": "string", "enum": lane_statuses},
        "lane_b": {"type": "string", "enum": lane_statuses},
        "system": {"type": "string", "enum": lane_statuses},
        "lane_c": {"type": "string", "enum": lane_statuses},
        "surviving_lane": {
            "type": ["string", "null"],
            "enum": ["lane_a", "lane_b", "system", "lane_c", None],
        },
        "evidence_quote": {"type": ["string", "null"]},
        "decision_basis": {"type": "string", "minLength": 1},
    }
    ledger_properties = {
        "trajectory_id": {"type": "string"},
        "rows": {
            "type": "array",
            "minItems": 1,
            "items": {
                "type": "object",
                "properties": row_properties,
                "required": list(row_properties),
                "additionalProperties": False,
            },
        },
        "selected_step": {"type": "integer", "minimum": 1},
    }
    freeze_properties = {
        "trajectory_id": {"type": "string"},
        "predicted_step": {"type": "integer", "minimum": 1},
    }
    properties = {
        "anchor_predictions": {
            "type": "array",
            "minItems": 1,
            "maxItems": 1,
            "items": _prediction_schema(),
        },
        "step_candidates": {
            "type": "object",
            "properties": ledger_properties,
            "required": list(ledger_properties),
            "additionalProperties": False,
        },
        "step_freeze": {
            "type": "object",
            "properties": freeze_properties,
            "required": list(freeze_properties),
            "additionalProperties": False,
        },
    }
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties),
        "additionalProperties": False,
    }


def reducer_response_schema() -> dict[str, Any]:
    review_properties = {
        "step": {"type": "integer", "minimum": 1},
        "boundary_role": {"type": "string", "enum": sorted(BOUNDARY_ROLES)},
        "observed_defect_class": {"type": "string", "enum": sorted(DEFECT_CLASSES)},
        "recovery_status": {"type": "string", "enum": sorted(RECOVERY_STATUSES)},
        "outcome_relation": {"type": "string", "enum": sorted(OUTCOME_RELATIONS)},
        "criticality_verdict": {
            "type": "string",
            "enum": sorted(CRITICALITY_VERDICTS),
        },
        "comparison_basis": {"type": "string", "minLength": 1},
    }
    properties = {
        "later_candidate_step": {"type": ["integer", "null"], "minimum": 1},
        "candidate_reviews": {
            "type": "array",
            "minItems": 1,
            "maxItems": 50,
            "items": {
                "type": "object",
                "properties": review_properties,
                "required": list(review_properties),
                "additionalProperties": False,
            },
        },
        "decision": {"type": "string", "enum": sorted(DECISIONS)},
        "selected_step": {"type": "integer", "minimum": 1},
        "selected_module": {"type": "string", "enum": list(MODULES)},
        "selected_error_type": {"type": "string", "enum": list(ERROR_TYPES)},
        "selected_evidence_quote": {"type": "string", "minLength": 1},
        "selected_root_cause": {"type": "string", "minLength": 1},
        "selected_causal_summary": {"type": "string", "minLength": 1},
        "selected_rejected_adjacent_owner": {"type": "string", "minLength": 1},
        "chronology_comparison": {"type": "string", "minLength": 1},
        "selection_falsifier": {"type": "string", "minLength": 1},
    }
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties),
        "additionalProperties": False,
    }


def _anchor_semantic_contract(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> str:
    manifest, cohort, _ = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    original = parent.build_anchor_task(
        manifest, cohort, manifest.parent / "anchor-predictions.json"
    )
    start = original.index("THE ONLY DECISION ORDER")
    end = original.index("MANDATORY LOCAL VALIDATION")
    contract = original[start:end].rstrip()
    return (
        contract.replace(
            "Before the step checkpoint, write exactly one JSON object to `step-candidates.json`.",
            "Before the step checkpoint, populate response field `step_candidates` with exactly one JSON object.",
        )
        .replace(
            "Write this file once and never edit it.  Then derive and write the",
            "Freeze this object conceptually. Then derive and populate the",
        )
        .replace(
            "write exactly this two-field JSON object to `step-freeze.json`:",
            "populate response field `step_freeze` with exactly this two-field JSON object:",
        )
        .replace(
            "write\nexactly this two-field JSON object to `step-freeze.json`:",
            "populate response field `step_freeze` with exactly this two-field JSON object:",
        )
        .replace(
            "Do not add fields and never edit this file after writing it.  Only then assign",
            "Do not add fields. Only then assign",
        )
        .replace(
            "the same-step owner/type/evidence and write the final ten-field prediction.",
            "the same-step owner/type/evidence and populate the final ten-field prediction.",
        )
        .replace(
            "Write one JSON array containing exactly one record and exactly these fields:",
            "Populate response field `anchor_predictions` with one JSON array containing exactly one record and exactly these fields:",
        )
    )


def build_anchor_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> str:
    _, _, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    document = build_inference_document(case)
    return f"""\
Run the accepted {parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION} anchor semantics.

RUNTIME CONTRACT — RESPONSE ONLY
- model: {AGENT_JUDGE_LUNA_GAIA_V3_75_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_75_REASONING_EFFORT}
- one isolated case; no prior predictions or cross-case state
- do not call shell, filesystem, network, validator, or any other tool
- do not read labels, metrics, scores, old predictions, reports, experiment docs, or git history
- return only the JSON object required by the supplied response schema
- trajectory/source-model/environment identity is never diagnostic evidence

{_anchor_semantic_contract(prediction_manifest_path, cohort_manifest_path)}

RESPONSE BUNDLE CONTRACT

Return exactly one object with keys `anchor_predictions`, `step_candidates`,
and `step_freeze`, in that order. Preserve the unchanged v3.20 chronological
ledger and packet-state prefix. All selected Step values must agree. For
evidence, copy one exact substring from the selected Step and selected Module's
`literal_owner_sources` array below. Do not add commentary or markdown.

OWNER-EXPLICIT COMPLETE JUDGEVIEW
{json.dumps(document, ensure_ascii=False, separators=(",", ":"))}
"""


def build_reducer_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    anchor_file, ledger_file, checkpoint_file, anchor, ledger, checkpoint = (
        _load_anchor_bundle(manifest, cohort, anchor_path, ledger_path, checkpoint_path)
    )
    del anchor_file, ledger_file, checkpoint_file, checkpoint
    document = build_inference_document(case)
    ledger_steps = [int(row["step"]) for row in ledger["rows"]]
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_75_VERSION}.

RUNTIME CONTRACT — RESPONSE ONLY
- model: {AGENT_JUDGE_LUNA_GAIA_V3_75_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_75_REASONING_EFFORT}
- one isolated case; only current fresh artifacts are visible
- do not call shell, filesystem, network, validator, or any other tool
- do not read labels, metrics, scores, old predictions, reports, experiment docs, or git history
- return only the JSON object required by the supplied response schema
- trajectory/source-model/environment identity is never diagnostic evidence

{_GLOBAL_SELECTOR_RULES}

BOUND CANDIDATE CONTRACT
- fresh default anchor Step: {anchor['predicted_step']}
- ledger candidate Steps, exact required review order: {json.dumps(ledger_steps)}
- candidate_reviews must contain exactly those Steps as `ledger_boundary`, then
  the optional later_candidate_step once as `later_boundary`.
- the ledger's lanes, vetoes, decision bases and selected flags are deliberately
  hidden. Reconstruct every review only from the complete literal timeline.
- keep_anchor must select Step {anchor['predicted_step']}; select_prefix must
  select a listed Step strictly before it; select_later must select the unique
  later_candidate_step strictly after it.
- the selected review must be `critical_root`.
- when keeping, reproduce the supplied anchor payload; the parent will exact-copy it.
- for replacement evidence, copy one exact substring from selected Step and
  selected Module's `literal_owner_sources` array.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

OWNER-EXPLICIT COMPLETE JUDGEVIEW
{json.dumps(document, ensure_ascii=False, separators=(",", ":"))}

FRESH DEFAULT ANCHOR PAYLOAD
{json.dumps(anchor, ensure_ascii=False, separators=(",", ":"))}
"""


def _materialize_owned_prediction(
    prediction: dict[str, Any], *, case: Any
) -> dict[str, Any]:
    """Repair only same-Step owner/taxonomy/evidence legality; never Step."""

    result = dict(prediction)
    step = result.get("predicted_step")
    if isinstance(step, bool) or not isinstance(step, int):
        return result
    try:
        module = AgentModule(result.get("predicted_module"))
        error_type = ErrorType(result.get("predicted_error_type"))
    except (TypeError, ValueError):
        return result
    quote = result.get("evidence_quote")
    sources = shared._luna_gaia_v2_owner_source_resolver(
        case.judge_view, step, module, error_type
    )
    if (
        is_valid_classification(module, error_type)
        and isinstance(quote, str)
        and any(quote in source for source in sources)
    ):
        return result

    document = build_inference_document(case)
    if not 1 <= step <= document["step_count"]:
        return result
    owner_sources = document["steps"][step - 1]["literal_owner_sources"]
    ordered = (
        AgentModule.MEMORY,
        AgentModule.REFLECTION,
        AgentModule.PLANNING,
        AgentModule.ACTION,
        AgentModule.SYSTEM,
    )
    literal_matches = [
        candidate
        for candidate in ordered
        if isinstance(quote, str)
        and any(quote in source for source in owner_sources[candidate.value])
    ]
    requested_available = [module] if owner_sources[module.value] else []
    available = [
        candidate for candidate in ordered if owner_sources[candidate.value]
    ]
    replacement_module = (literal_matches or requested_available or available or [None])[0]
    if replacement_module is None:
        return result
    replacement_type = error_type
    if not is_valid_classification(replacement_module, replacement_type):
        replacement_type = next(iter(TAXONOMY[replacement_module]))
    replacement_sources = owner_sources[replacement_module.value]
    replacement_quote = quote
    if not isinstance(quote, str) or not any(
        quote in source for source in replacement_sources
    ):
        replacement_quote = replacement_sources[0].strip()[:900]
    result.update(
        {
            "predicted_module": replacement_module.value,
            "predicted_error_type": replacement_type.value,
            "evidence_quote": replacement_quote,
        }
    )
    return result


def normalize_anchor_response(response: Any, *, case: Any) -> Any:
    if not isinstance(response, dict):
        return response
    value = json.loads(json.dumps(response))
    predictions = value.get("anchor_predictions")
    if isinstance(predictions, list) and len(predictions) == 1 and isinstance(predictions[0], dict):
        original_step = predictions[0].get("predicted_step")
        predictions[0].update(
            {
                "trajectory_id": case.trajectory_id,
                "trajectory_sha256": case.trajectory_sha256,
                "status": "success",
            }
        )
        predictions[0] = _materialize_owned_prediction(predictions[0], case=case)
        if predictions[0].get("predicted_step") != original_step:
            raise RuntimeError("anchor legality materialization changed Step")
        ledger = value.get("step_candidates")
        if isinstance(ledger, dict) and isinstance(ledger.get("rows"), list):
            for row in ledger["rows"]:
                if isinstance(row, dict) and row.get("step") == original_step:
                    row["evidence_quote"] = predictions[0].get("evidence_quote")
                    break
    for field in ("step_candidates", "step_freeze"):
        if isinstance(value.get(field), dict):
            value[field]["trajectory_id"] = case.trajectory_id
    return value


def normalize_assessment_response(
    response: Any,
    *,
    anchor: dict[str, Any] | None = None,
    ledger: dict[str, Any] | None = None,
    case: Any | None = None,
) -> Any:
    """Bind payload legality while preserving the selector's Step and decision."""

    if not isinstance(response, dict):
        return response
    value = json.loads(json.dumps(response))
    if not isinstance(anchor, dict):
        return value
    decision = value.get("decision")
    selected_step = value.get("selected_step")
    if decision == "keep_anchor" and selected_step == anchor.get("predicted_step"):
        value.update(
            {
                "selected_module": anchor.get("predicted_module"),
                "selected_error_type": anchor.get("predicted_error_type"),
                "selected_evidence_quote": anchor.get("evidence_quote"),
                "selected_root_cause": anchor.get("root_cause"),
                "selected_causal_summary": anchor.get("causal_summary"),
                "selected_rejected_adjacent_owner": anchor.get(
                    "rejected_adjacent_owner"
                ),
            }
        )
        return value
    if case is None:
        return value
    prediction = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        "predicted_step": selected_step,
        "predicted_module": value.get("selected_module"),
        "predicted_error_type": value.get("selected_error_type"),
        "evidence_quote": value.get("selected_evidence_quote"),
        "root_cause": value.get("selected_root_cause"),
        "causal_summary": value.get("selected_causal_summary"),
        "rejected_adjacent_owner": value.get("selected_rejected_adjacent_owner"),
    }
    materialized = _materialize_owned_prediction(prediction, case=case)
    if materialized.get("predicted_step") != selected_step:
        raise RuntimeError("selector legality materialization changed Step")
    value.update(
        {
            "selected_module": materialized.get("predicted_module"),
            "selected_error_type": materialized.get("predicted_error_type"),
            "selected_evidence_quote": materialized.get("evidence_quote"),
        }
    )
    return value


def _load_anchor_bundle(
    manifest: Path,
    cohort: Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> tuple[Path, Path, Path, dict[str, Any], dict[str, Any], dict[str, Any]]:
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    anchor, ledger, checkpoint = shared._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    parent._validate_packet_state_ledgers(ledger_file)
    return anchor_file, ledger_file, checkpoint_file, anchor, ledger, checkpoint


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    audit = parent.validate_anchor_predictions(*paths)
    document = Path(paths[2]).expanduser().resolve().parent / INFERENCE_DOCUMENT_FILENAME
    inference = validate_inference_document(paths[0], paths[1], document)
    return _retag(
        {**audit, "owner_explicit_input": inference},
        policy="unchanged_v3_20_anchor_owner_explicit_response_only",
    )


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])


def _selected_prediction(case: Any, assessment: dict[str, Any]) -> dict[str, Any]:
    return shared._validate_prediction_record(
        {
            "trajectory_id": case.trajectory_id,
            "trajectory_sha256": case.trajectory_sha256,
            "status": "success",
            "predicted_step": assessment["selected_step"],
            "predicted_module": assessment["selected_module"],
            "predicted_error_type": assessment["selected_error_type"],
            "evidence_quote": assessment["selected_evidence_quote"],
            "root_cause": assessment["selected_root_cause"],
            "causal_summary": assessment["selected_causal_summary"],
            "rejected_adjacent_owner": assessment[
                "selected_rejected_adjacent_owner"
            ],
        },
        case=case,
        location="sparse_ledger_selected_prediction",
    )


def _validate_assessment_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != ASSESSMENT_FIELDS:
        shared._fail("invalid_sparse_ledger_assessment_schema", location)
    later = raw["later_candidate_step"]
    anchor_step = anchor["predicted_step"]
    if later is not None and (
        isinstance(later, bool)
        or not isinstance(later, int)
        or not anchor_step < later <= len(case.judge_view.steps)
    ):
        shared._fail("invalid_sparse_ledger_later_candidate", location)
    ledger_steps = [int(row["step"]) for row in ledger["rows"]]
    expected_steps = ledger_steps + ([] if later is None else [later])
    reviews = raw["candidate_reviews"]
    if not isinstance(reviews, list) or len(reviews) != len(expected_steps):
        shared._fail("incomplete_sparse_ledger_candidate_reviews", location)
    for index, (review, expected_step) in enumerate(zip(reviews, expected_steps, strict=True)):
        review_location = f"{location}.candidate_reviews[{index}]"
        if not isinstance(review, dict) or tuple(review) != REVIEW_FIELDS:
            shared._fail("invalid_sparse_ledger_review_schema", review_location)
        expected_role = (
            "later_boundary" if later is not None and index == len(reviews) - 1 else "ledger_boundary"
        )
        if review["step"] != expected_step or review["boundary_role"] != expected_role:
            shared._fail("sparse_ledger_review_binding_mismatch", review_location)
        if (
            review["observed_defect_class"] not in DEFECT_CLASSES
            or review["recovery_status"] not in RECOVERY_STATUSES
            or review["outcome_relation"] not in OUTCOME_RELATIONS
            or review["criticality_verdict"] not in CRITICALITY_VERDICTS
        ):
            shared._fail("invalid_sparse_ledger_review_enum", review_location)
        shared._nonempty_text(
            review["comparison_basis"],
            location=f"{review_location}.comparison_basis",
            maximum=3200,
        )
    if raw["decision"] not in DECISIONS:
        shared._fail("invalid_sparse_ledger_decision", location)
    selected_step = raw["selected_step"]
    if raw["decision"] == "keep_anchor":
        valid_decision = selected_step == anchor_step
    elif raw["decision"] == "select_prefix":
        valid_decision = selected_step in ledger_steps and selected_step < anchor_step
    else:
        valid_decision = later is not None and selected_step == later
    if not valid_decision:
        shared._fail("sparse_ledger_decision_step_mismatch", location)
    selected_reviews = [
        review for review in reviews if review["step"] == selected_step
    ]
    if (
        len(selected_reviews) != 1
        or selected_reviews[0]["criticality_verdict"] != "critical_root"
    ):
        shared._fail("selected_sparse_ledger_review_not_critical", location)
    for field in (
        "chronology_comparison",
        "selection_falsifier",
        "selected_root_cause",
        "selected_causal_summary",
        "selected_rejected_adjacent_owner",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3200)
    prediction = _selected_prediction(case, raw)
    if raw["decision"] == "keep_anchor" and prediction != anchor:
        shared._fail("sparse_ledger_keep_not_exact_anchor_copy", location)
    return raw


def validate_assessment(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    assessment_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger = bundle[3:5]
    assessment_file, value = shared._load_artifact(
        assessment_path, role="sparse-ledger global boundary assessment"
    )
    assessment = shared._one_record(
        value, role="sparse-ledger global boundary assessment"
    )
    _validate_assessment_record(
        assessment, case=case, anchor=anchor, ledger=ledger, location="assessment[0]"
    )
    document = assessment_file.parent / INFERENCE_DOCUMENT_FILENAME
    inference = validate_inference_document(manifest, cohort, document)
    return _retag(
        {
            "schema_version": "agentdebug.sparse-ledger-global-boundary-assessment-audit.v1",
            "stage": "sparse_ledger_global_critical_boundary_assessment",
            "gold_free_validation": True,
            "case_count": 1,
            "complete_sparse_ledger_review": True,
            "maximum_later_candidates": 1,
            "reviewed_candidate_count": len(assessment["candidate_reviews"]),
            "decision": assessment["decision"],
            "owner_explicit_input": inference,
            "input_sha256": {
                "anchor": shared._file_sha256(anchor_file),
                "ledger": shared._file_sha256(ledger_file),
                "checkpoint": shared._file_sha256(checkpoint_file),
            },
            "output_sha256": {PANEL_FILENAME: shared._file_sha256(assessment_file)},
        },
        policy="all_sparse_ledger_steps_plus_at_most_one_later_global_selector",
    )


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_assessment(*paths[:-1]), paths[-1])


def build_selection_document(
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    assessment: dict[str, Any],
) -> dict[str, Any]:
    semantic = _validate_assessment_record(
        assessment, case=case, anchor=anchor, ledger=ledger, location="assessment"
    )
    selected = _selected_prediction(case, semantic)
    result = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "assessment_sha256": shared._stable_sha256(semantic),
        "decision": semantic["decision"],
        "anchor_step": anchor["predicted_step"],
        "reviewed_steps": [row["step"] for row in semantic["candidate_reviews"]],
        "later_candidate_step": semantic["later_candidate_step"],
        "selected_step": semantic["selected_step"],
        "frozen_step": selected["predicted_step"],
        "selected_prediction_sha256": shared._stable_sha256(selected),
        "selected_prediction": selected,
        "semantic_assessment": semantic,
    }
    return _validate_selection_record(
        result,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        assessment=semantic,
        location="deterministic_selection",
    )


def _validate_selection_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    assessment: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != SELECTION_FIELDS:
        shared._fail("invalid_sparse_ledger_selection_schema", location)
    expected_hashes = {
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "assessment_sha256": shared._stable_sha256(assessment),
    }
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
        or any(raw[key] != value for key, value in expected_hashes.items())
        or raw["decision"] != assessment["decision"]
        or raw["anchor_step"] != anchor["predicted_step"]
        or raw["reviewed_steps"]
        != [row["step"] for row in assessment["candidate_reviews"]]
        or raw["later_candidate_step"] != assessment["later_candidate_step"]
        or raw["selected_step"] != assessment["selected_step"]
        or raw["semantic_assessment"] != assessment
    ):
        shared._fail("sparse_ledger_selection_binding_mismatch", location)
    selected = _selected_prediction(case, assessment)
    if (
        raw["selected_prediction"] != selected
        or raw["selected_prediction_sha256"] != shared._stable_sha256(selected)
        or raw["frozen_step"] != selected["predicted_step"]
    ):
        shared._fail("sparse_ledger_selected_copy_mismatch", location)
    return raw


def validate_selector(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    assessment_path: str | Path,
    selector_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger, checkpoint = bundle[3:]
    assessment_file, assessment_raw = shared._load_artifact(
        assessment_path, role="sparse-ledger global boundary assessment"
    )
    assessment = shared._one_record(
        assessment_raw, role="sparse-ledger global boundary assessment"
    )
    _validate_assessment_record(
        assessment, case=case, anchor=anchor, ledger=ledger, location="assessment[0]"
    )
    selector_file, selector_raw = shared._load_artifact(
        selector_path, role="sparse-ledger global boundary selection"
    )
    selector = shared._one_record(
        selector_raw, role="sparse-ledger global boundary selection"
    )
    _validate_selection_record(
        selector,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        assessment=assessment,
        location="selection[0]",
    )
    expected = build_selection_document(
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        assessment=assessment,
    )
    if selector != expected:
        shared._fail("non_deterministic_sparse_ledger_selection", "selection[0]")
    return _retag(
        {
            "schema_version": "agentdebug.sparse-ledger-global-boundary-selection-audit.v1",
            "stage": "deterministic_sparse_ledger_boundary_selection",
            "gold_free_validation": True,
            "case_count": 1,
            "decision": selector["decision"],
            "selected_prediction_exact_copy": True,
            "model_selected_step_preserved": True,
            "input_sha256": {
                "anchor": shared._file_sha256(anchor_file),
                "ledger": shared._file_sha256(ledger_file),
                "checkpoint": shared._file_sha256(checkpoint_file),
                "assessment": shared._file_sha256(assessment_file),
            },
            "output_sha256": {SELECTOR_FILENAME: shared._file_sha256(selector_file)},
        },
        policy="deterministic_model_selected_sparse_ledger_boundary_copy",
    )


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_selector(*paths[:-1]), paths[-1])


def _validate_aggregate(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(prediction_manifest_path, cohort_manifest_path)
    root = Path(predictions_path).expanduser().resolve().parent
    names = (
        ANCHOR_PREDICTIONS_FILENAME,
        ANCHOR_LEDGER_AGGREGATE_FILENAME,
        ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        PANELS_FILENAME,
        SELECTORS_FILENAME,
    )
    loaded = {
        name: shared._load_artifact(root / name, role=f"merged {name}")[1]
        for name in names
    }
    if any(
        not isinstance(value, list) or len(value) != len(cases)
        for value in loaded.values()
    ):
        shared._fail("invalid_sparse_ledger_aggregate_count", "merged artifacts")
    finals = shared._load_artifact(predictions_path, role="merged predictions")[1]
    if not isinstance(finals, list) or len(finals) != len(cases):
        shared._fail("invalid_sparse_ledger_prediction_count", "predictions")
    decisions: Counter[str] = Counter()
    review_counts: Counter[int] = Counter()
    later_count = 0
    for index, case in enumerate(cases):
        location = f"sparse_ledger_merged[{index}]"
        anchor = shared._validate_prediction_record(
            loaded[ANCHOR_PREDICTIONS_FILENAME][index],
            case=case,
            location=f"{location}.anchor",
        )
        ledger = loaded[ANCHOR_LEDGER_AGGREGATE_FILENAME][index]
        checkpoint = loaded[ANCHOR_CHECKPOINT_AGGREGATE_FILENAME][index]
        if (
            ledger.get("trajectory_id") != case.trajectory_id
            or ledger.get("selected_step") != anchor["predicted_step"]
            or checkpoint.get("trajectory_id") != case.trajectory_id
            or checkpoint.get("predicted_step") != anchor["predicted_step"]
        ):
            shared._fail("sparse_ledger_anchor_sidecar_mismatch", location)
        assessment = loaded[PANELS_FILENAME][index]
        _validate_assessment_record(
            assessment,
            case=case,
            anchor=anchor,
            ledger=ledger,
            location=f"{location}.assessment",
        )
        selection = loaded[SELECTORS_FILENAME][index]
        _validate_selection_record(
            selection,
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            assessment=assessment,
            location=f"{location}.selection",
        )
        final = shared._validate_prediction_record(
            finals[index], case=case, location=f"{location}.final"
        )
        if final != selection["selected_prediction"]:
            shared._fail("sparse_ledger_final_copy_mismatch", location)
        decisions[selection["decision"]] += 1
        review_counts[len(assessment["candidate_reviews"])] += 1
        later_count += assessment["later_candidate_step"] is not None
    return {
        "required": True,
        "valid": True,
        "complete_sparse_ledger_review": True,
        "maximum_later_candidates": 1,
        "all_selected_steps_model_frozen": True,
        "all_final_predictions_exact_selection_copies": True,
        "selector_decision_counts": dict(sorted(decisions.items())),
        "review_count_distribution": {
            str(key): value for key, value in sorted(review_counts.items())
        },
        "later_candidate_count": later_count,
        "packet_state_closure": parent._validate_packet_state_ledgers(
            root / ANCHOR_LEDGER_AGGREGATE_FILENAME
        ),
    }


def validate_agent_judge_luna_gaia_v3_75_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    aggregate = _validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return _retag(
        {
            **audit,
            "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_75_AUDIT_SCHEMA_VERSION,
            "anchor_semantics_unchanged_from_v3_20": True,
            "owner_explicit_response_only_runtime_required": True,
            "all_final_steps_model_selected": True,
            "all_selected_predictions_exact_copies": True,
            "sparse_ledger_global_selector": aggregate,
        },
        policy="clean_v3_20_sparse_ledger_global_critical_boundary_selector",
    )


def validate_and_write_agent_judge_luna_gaia_v3_75_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(
        validate_agent_judge_luna_gaia_v3_75_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_luna_gaia_v3_75_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_reducer_file_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
    )


# Generic runner compatibility aliases.
validate_and_write_agent_judge_luna_gaia_v3_67_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_75_audit
)
validate_and_write_agent_judge_luna_gaia_v3_37_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_75_audit
)
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_luna_gaia_v3_75_task
build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_75_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_75_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_75_audit
)

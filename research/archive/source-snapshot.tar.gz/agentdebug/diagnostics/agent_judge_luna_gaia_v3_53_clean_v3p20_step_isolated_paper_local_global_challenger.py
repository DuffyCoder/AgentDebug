"""Luna GAIA v3.53: clean v3.20 plus a step-isolated paper-local challenger."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions
from .taxonomy import AgentModule, ErrorType, is_valid_classification, taxonomy_prompt


AGENT_JUDGE_LUNA_GAIA_V3_53_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.53-clean-v3.20-"
    "step-isolated-paper-local-global-challenger"
)
AGENT_JUDGE_LUNA_GAIA_V3_53_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_53_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_53_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases used only by the generic three-stage orchestration code.
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_53_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_53_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_53_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_53_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_53_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_53_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_53_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
STEP_PROJECTION_FILENAME = "step-local-projection.json"
STEP_LOCAL_FILENAME = "step-local-evidence.json"
STEP_LOCAL_AUDIT_FILENAME = "step-local-evidence-audit.json"
STEP_LOCAL_RECORDS_FILENAME = "step-local-evidence-records.json"
LOCAL_MATRIX_FILENAME = "step-local-evidence-matrix.json"
LOCAL_MATRICES_FILENAME = "step-local-evidence-matrices.json"
PANEL_FILENAME = "paper-local-global-proposal.json"
PANELS_FILENAME = "paper-local-global-proposals.json"
PANEL_AUDIT_FILENAME = "paper-local-global-proposal-audit.json"
SELECTOR_FILENAME = "anchor-paper-proposal-duel.json"
SELECTORS_FILENAME = "anchor-paper-proposal-duels.json"
SELECTOR_AUDIT_FILENAME = "anchor-paper-proposal-duel-audit.json"

MODULES = tuple(module.value for module in AgentModule)
STEP_LOCAL_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "step",
    "projection_sha256",
    "module_reviews",
)
LOCAL_REVIEW_FIELDS = (
    "module",
    "owner_present",
    "error_detected",
    "error_type",
    "evidence_quote",
    "local_reasoning",
)
MATRIX_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "reviewed_steps",
    "step_record_sha256s",
    "positive_row_count",
    "positive_rows",
)
POSITIVE_ROW_FIELDS = (
    "row_id",
    "step",
    "module",
    "error_type",
    "evidence_quote",
    "local_reasoning",
    "step_record_sha256",
)
LOCAL_RECORD_SET_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "step_records",
)
PANEL_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "local_matrix_sha256",
    "reviewed_steps",
    "positive_row_count",
    "reviewed_row_ids",
    "proposal_status",
    "proposal_step",
    "selected_row_id",
    "boundary_class",
    "proposal_prediction",
    "probe_assessment",
    "recovery_assessment",
    "chronology_comparison",
    "critical_boundary_basis",
    "selection_falsifier",
)
PANEL_STATUSES = frozenset({"candidate", "none"})
BOUNDARY_CLASSES = frozenset(
    {
        "none",
        "state_truth",
        "constraint_alignment",
        "capability_commitment",
        "post_feedback_recommitment",
        "terminal_abandonment",
    }
)
SELECTOR_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "anchor_prediction_sha256",
    "anchor_ledger_sha256",
    "anchor_checkpoint_sha256",
    "proposal_sha256",
    "anchor_step",
    "proposal_step",
    "decision",
    "anchor_classification",
    "proposal_classification",
    "anchor_veto_evidence_step",
    "anchor_veto_evidence_quote",
    "anchor_contribution_witness_step",
    "anchor_contribution_witness_quote",
    "frozen_step",
    "selected_prediction_sha256",
    "selected_prediction",
    "anchor_assessment",
    "proposal_assessment",
    "timeline_comparison",
    "decision_basis",
    "rejected_alternative_basis",
    "selection_falsifier",
)
SELECTOR_DECISIONS = frozenset({"keep_anchor", "select_proposal"})
ANCHOR_CLASSES = frozenset(
    {
        "critical_root",
        "contributing_probe",
        "normal_tool_failure",
        "recovered_defect",
        "noncritical_predecessor",
        "faithful_propagation",
        "downstream_symptom",
        "uncertain",
    }
)
OVERRIDE_ANCHOR_CLASSES = ANCHOR_CLASSES - {"critical_root", "uncertain"}
PROPOSAL_CLASSES = frozenset(
    {
        "absent",
        "critical_root",
        "reasonable_probe",
        "normal_tool_failure",
        "recovered_defect",
        "mechanical_defect",
        "faithful_propagation",
        "downstream_symptom",
        "uncertain",
    }
)
PROBE_ASSESSMENT_PREFIX = re.compile(
    r"^proposal_probe_status=(reasonable|material_error|not_applicable);"
)


_LOCAL_RULES = """\
STEP-ISOLATED PAPER-LOCAL ERROR DETECTION — EVIDENCE ONLY

Judge only the projected current Step. The projection contains the observable
input/history available at that Step, the current owner outputs, and adjacent
feedback. Later Steps, an incumbent anchor, global candidates, scores, and gold
are unavailable.

For each of Memory, Reflection, Planning, Action, and System, answer only the
local taxonomy question: does this module's current output contain a concrete
error matching one defined type? A local positive is evidence inventory, not a
critical-Step nomination. Do not test recovery, irreversible failure,
candidate-only repair, anchor-only repair, chronology rank, propagation, or
whether another Step is more important. Those are global-stage questions.

Memory is checked against observable prior facts in current_input. Reflection
is checked against current input, current Memory, and adjacent outcome.
Planning is checked against current input and current Memory/Reflection. Action
is checked against the current plan, available tool/interface, and concrete
parameters or terminal answer. System is positive only for an observable
external execution/runtime/model/step-limit failure despite an otherwise valid
attempt; an ordinary empty or negative result is not a System error.

For a positive, copy a literal owner quote and choose exactly one valid taxonomy
type. For an absent owner or a negative verdict, use no_error and null evidence.
Do not infer from trajectory identity, source model, entity, site, or benchmark
history.
"""

_PROPOSAL_RULES = """\
ANCHOR-BLIND GLOBAL CRITICAL PROPOSAL OVER FROZEN PAPER-LOCAL ROWS

The incumbent anchor is unavailable. The complete frozen positive-row matrix
is evidence inventory, not votes. Review every row_id together with the full
Canonical Trace, then export at most one complete critical-boundary prediction
grounded in exactly one positive row, or `none`.

Select the first mature failure-causing Agent/System error under the benchmark
boundary—not the first positive, the latest symptom, the most repeated row, the
majority module, Planning by default, or the strongest prose. A selected row
must survive all of these global checks: it is not a reasonable initial or
different evidence-producing probe, normal negative/tool result, mechanical
repair, fully recovered defect, faithful propagation, merely improvable local
behavior, or downstream symptom; repairing that row can materially redirect
the remaining failed path; and no earlier mature row owns the same causal
failure.

Use literal chronology. A probe is reasonable when its target/interface can
expose a necessary immediate fact even if it cannot prove the final answer. A
capability failure is mature only when the chosen route is intrinsically unable
to expose the immediate predicate, or feedback already falsified that evidence
family before an unchanged recommitment. State errors require a false, lost, or
misread fact that feeds a decision. System errors require external ownership.

For `candidate`, reviewed_row_ids must cover every frozen positive row and the
selected prediction's Step/module/type/evidence must exact-copy selected_row_id.
For `none`, still review every row. Never invent a row or read an anchor, score,
gold label, old prediction, error report, or source-identity prior.
"""


_DUEL_RULES = """\
V3.20 DEFAULT-KEEP ARBITER OVER ONE PAPER-LOCAL GLOBAL CHALLENGER

The two inputs are immutable. Select exactly the clean v3.20 anchor or the one
anchor-blind proposal when present. Never invent a third Step, repair fields,
merge predictions, or use provenance as evidence. When both name the same Step,
keep the anchor because the Step boundary already agrees. Under genuinely
unresolved evidence, keep the anchor.

Compare the two boundaries on literal chronology:

1. protect a direct unrecovered constraint violation, target/Action mismatch,
   task-material false state, incapable commitment, eligible execution impact,
   or earliest failure-causing commitment;
2. reject normal tool failure, recovered defect, mechanical predecessor,
   faithful propagation, and downstream symptom;
3. do not prefer an initial or later Step merely because of position;
4. do not make initial position an automatic veto. Classify the anchor as
   `contributing_probe` only when a literal observed witness shows that its path
   actually supplied a necessary identifier, fact, source, route, or other
   task-material item. A generic/empty result, successful transport, or
   hypothetical possible usefulness is not a contribution witness;
5. a proposal can displace a contributing probe only if it is independently
   material after that observed contribution. For other noncritical anchor
   classes, quote the literal recovery, failure ownership, predecessor, or
   symptom evidence that vetoes the anchor;
6. reject a proposal that is merely a later repetition, vivid symptom, or local
   positive when the anchor already owns the causal boundary; local admission
   alone supplies no override evidence.

For every result begin `anchor_assessment` exactly:
`anchor_status=<class>; contribution_witness=<present|not_applicable>; `
and begin `proposal_assessment` exactly:
`proposal_status=<class>; `.

For `select_proposal`, proposal_status must be `critical_root`; anchor_status
must be an allowed noncritical class; anchor veto evidence is mandatory. If
anchor_status is `contributing_probe`, a separate literal contribution witness
is mandatory and contribution_witness must be `present`. For all other cases
contribution_witness is `not_applicable`. Keep-anchor records have all veto and
contribution witness fields null.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_53_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_53_clean_v3p20_step_isolated_paper_local_global_challenger",
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py",
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_53_clean_v3p20_step_isolated_paper_local_global_challenger.py",
        )
    )


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_53_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_53_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_53_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": (
            "one step-isolated paper-local evidence matrix feeding a global challenger"
        ),
    }


def _boundary(
    *, manifest: Path, cohort: Path, reads: Sequence[Path], output: Path
) -> str:
    read_lines = "\n".join(f"- {path}" for path in reads) or "- none"
    return f"""\
IMMUTABLE EXECUTION CONFIGURATION
- model: {AGENT_JUDGE_LUNA_GAIA_V3_53_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_53_REASONING_EFFORT}
- one isolated case; fresh session; no cross-case state or prior predictions
- external LLM/API/network calls: forbidden
- scoring or gold-label access: forbidden

INPUT/OUTPUT BOUNDARY
- prediction manifest: {manifest}
- prediction manifest file sha256: {shared._file_sha256(manifest)}
- cohort manifest: {cohort}
- cohort manifest file sha256: {shared._file_sha256(cohort)}
- permitted frozen stage inputs:
{read_lines}
- write the sole stage artifact only to: {output}

Read only those exact inputs plus this v3.53 protocol source, the v3.20
protocol source, and `agentdebug/diagnostics/taxonomy.py`. Do not inspect
directories or infer from trajectory/source-model/environment names. Never
read labels, metrics, scored artifacts, experiment documents, proposal files
other than the permitted current input, old predictions, cached replies, case
studies, git history, or external resources.
"""


def build_anchor_task(*paths: str | Path) -> str:
    """Use exactly v3.20 anchor semantics, with identity retagged."""

    return _rewrite_identity(parent.build_anchor_task(*paths))


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths), policy="unchanged_v3_20_anchor")


def build_step_projection_document(case: Any, step_number: int) -> dict[str, Any]:
    """Return a deterministic prefix-bounded input for one local Step call."""

    if step_number < 1 or step_number > len(case.judge_view.steps):
        shared._fail("invalid_step_local_projection_step", str(step_number))
    step = case.judge_view.steps[step_number - 1]
    sources: dict[str, list[str]] = {module: [] for module in MODULES}
    for span in step.module_spans:
        value = step.assistant_raw_output[
            span.content_start_char : span.content_end_char
        ].strip()
        if span.module in sources and value:
            sources[span.module].append(value)
    system_sources = [item.text for item in step.adjacent_feedback if item.text.strip()]
    if step.stop_reason:
        system_sources.append(step.stop_reason)
    if step.error_message:
        system_sources.append(step.error_message)
    sources[AgentModule.SYSTEM.value] = system_sources
    task = case.judge_view.task
    return {
        "schema_version": "agentdebug.step-isolated-paper-local-projection.v1",
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "step": step_number,
        "task": task.display_text if task is not None else "",
        "current_input": [item.text for item in step.current_input],
        "assistant_raw_output": step.assistant_raw_output,
        "owner_sources": sources,
        "adjacent_feedback": [item.text for item in step.adjacent_feedback],
        "stop_reason": step.stop_reason,
        "error_message": step.error_message,
        "later_steps_visible": False,
    }


def _validate_step_projection(raw: Any, *, location: str) -> dict[str, Any]:
    expected = (
        "schema_version",
        "trajectory_id",
        "trajectory_sha256",
        "step",
        "task",
        "current_input",
        "assistant_raw_output",
        "owner_sources",
        "adjacent_feedback",
        "stop_reason",
        "error_message",
        "later_steps_visible",
    )
    if not isinstance(raw, dict) or tuple(raw) != expected:
        shared._fail("invalid_step_local_projection_schema", location)
    if raw["schema_version"] != "agentdebug.step-isolated-paper-local-projection.v1":
        shared._fail("invalid_step_local_projection_version", location)
    if (
        isinstance(raw["step"], bool)
        or not isinstance(raw["step"], int)
        or raw["step"] < 1
    ):
        shared._fail("invalid_step_local_projection_step", location)
    if raw["later_steps_visible"] is not False:
        shared._fail("step_local_projection_exposes_later_steps", location)
    if not isinstance(raw["owner_sources"], dict) or tuple(raw["owner_sources"]) != MODULES:
        shared._fail("invalid_step_local_projection_owner_sources", location)
    for module, values in raw["owner_sources"].items():
        if not isinstance(values, list) or not all(
            isinstance(value, str) and value.strip() for value in values
        ):
            shared._fail("invalid_step_local_projection_owner_sources", f"{location}.{module}")
    return raw


def _validate_step_local_record(
    raw: Any, *, projection: dict[str, Any], location: str
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != STEP_LOCAL_FIELDS:
        shared._fail("invalid_step_local_evidence_schema", location)
    if (
        raw["trajectory_id"] != projection["trajectory_id"]
        or raw["trajectory_sha256"] != projection["trajectory_sha256"]
        or raw["step"] != projection["step"]
        or raw["projection_sha256"] != shared._stable_sha256(projection)
    ):
        shared._fail("step_local_evidence_identity_mismatch", location)
    reviews = raw["module_reviews"]
    if not isinstance(reviews, list) or len(reviews) != len(MODULES):
        shared._fail("invalid_step_local_review_count", location)
    if [review.get("module") for review in reviews if isinstance(review, dict)] != list(MODULES):
        shared._fail("invalid_step_local_module_order", location)
    for index, review in enumerate(reviews):
        row_location = f"{location}.module_reviews[{index}]"
        if not isinstance(review, dict) or tuple(review) != LOCAL_REVIEW_FIELDS:
            shared._fail("invalid_step_local_review_schema", row_location)
        try:
            module = AgentModule(review["module"])
        except ValueError:
            shared._fail("invalid_step_local_module", row_location)
        sources = projection["owner_sources"][module.value]
        owner_present = bool(sources)
        if review["owner_present"] is not owner_present:
            shared._fail("step_local_owner_presence_mismatch", row_location)
        if not isinstance(review["error_detected"], bool):
            shared._fail("invalid_step_local_error_flag", row_location)
        shared._nonempty_text(
            review["local_reasoning"],
            location=f"{row_location}.local_reasoning",
            maximum=2000,
        )
        if not owner_present or not review["error_detected"]:
            if review["error_type"] != "no_error" or review["evidence_quote"] is not None:
                shared._fail("invalid_step_local_negative_fields", row_location)
            continue
        if projection["step"] == 1 and module in {
            AgentModule.MEMORY,
            AgentModule.REFLECTION,
        }:
            shared._fail("invalid_step_one_memory_reflection_positive", row_location)
        try:
            error_type = ErrorType(review["error_type"])
        except ValueError:
            shared._fail("invalid_step_local_error_type", row_location)
        if not is_valid_classification(module, error_type):
            shared._fail("invalid_step_local_error_type", row_location)
        shared._nonempty_text(
            review["evidence_quote"],
            location=f"{row_location}.evidence_quote",
            maximum=1800,
        )
        if not any(review["evidence_quote"] in source for source in sources):
            shared._fail("invalid_step_local_evidence_quote", row_location)
    return raw


def validate_step_local(
    projection_path: str | Path, local_path: str | Path
) -> dict[str, Any]:
    projection_file, projection_raw = shared._load_artifact(
        projection_path, role="step local projection"
    )
    projection = _validate_step_projection(projection_raw, location="projection")
    local_file, local_raw = shared._load_artifact(
        local_path, role="step local evidence"
    )
    local = _validate_step_local_record(
        local_raw, projection=projection, location="step_local"
    )
    return _retag(
        {
            "schema_version": "agentdebug.step-isolated-paper-local-audit.v1",
            "stage": "step_isolated_paper_local_evidence",
            "gold_free_validation": True,
            "case_count": 1,
            "step": projection["step"],
            "later_steps_visible": False,
            "anchor_visible": False,
            "module_count": len(MODULES),
            "positive_count": sum(
                review["error_detected"] for review in local["module_reviews"]
            ),
            "input_sha256": {"projection": shared._file_sha256(projection_file)},
            "output_sha256": {STEP_LOCAL_FILENAME: shared._file_sha256(local_file)},
        },
        policy="step_isolated_paper_local_evidence_only",
    )


def build_step_local_task(
    projection_path: str | Path, local_path: str | Path
) -> str:
    projection_file, projection_raw = shared._load_artifact(
        projection_path, role="step local projection"
    )
    projection = _validate_step_projection(projection_raw, location="projection")
    output = Path(local_path).expanduser().resolve()
    shared._assert_safe_path(output, role="step local evidence output", is_output=True)
    audit = output.parent / STEP_LOCAL_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_53_clean_v3p20_step_isolated_paper_local_global_challenger",
            "--compact-validate",
            "local",
            projection_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    schema = {
        "trajectory_id": projection["trajectory_id"],
        "trajectory_sha256": projection["trajectory_sha256"],
        "step": projection["step"],
        "projection_sha256": shared._stable_sha256(projection),
        "module_reviews": [
            {
                "module": module,
                "owner_present": bool(projection["owner_sources"][module]),
                "error_detected": "true or false",
                "error_type": "valid assigned-module type or no_error",
                "evidence_quote": "literal owner quote or null",
                "local_reasoning": "taxonomy-local reasoning only",
            }
            for module in MODULES
        ],
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_53_VERSION} local evidence stage for Step {projection['step']}.

IMMUTABLE EXECUTION CONFIGURATION
- model: {AGENT_JUDGE_LUNA_GAIA_V3_53_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_53_REASONING_EFFORT}
- one fresh session; one prefix-bounded Step; no later Step or anchor
- external LLM/API/network calls and scoring/gold access: forbidden

Read only:
- {projection_file}
- this v3.53 protocol source
- `agentdebug/diagnostics/taxonomy.py`
Write only: {output}

Do not inspect directories, experiment documents, labels, metrics, scored
artifacts, old predictions, error reports, case studies, git history, source
identity, or external resources.

{_LOCAL_RULES}

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON object with fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def build_local_matrix_document(
    *, case: Any, local_records: Sequence[dict[str, Any]]
) -> dict[str, Any]:
    if [record["step"] for record in local_records] != list(
        range(1, len(case.judge_view.steps) + 1)
    ):
        shared._fail("incomplete_step_local_matrix_coverage", case.trajectory_id)
    positives: list[dict[str, Any]] = []
    hashes = [shared._stable_sha256(record) for record in local_records]
    for record, record_hash in zip(local_records, hashes, strict=True):
        for review in record["module_reviews"]:
            if not review["error_detected"]:
                continue
            positives.append(
                {
                    "row_id": f"P{len(positives) + 1:03d}",
                    "step": record["step"],
                    "module": review["module"],
                    "error_type": review["error_type"],
                    "evidence_quote": review["evidence_quote"],
                    "local_reasoning": review["local_reasoning"],
                    "step_record_sha256": record_hash,
                }
            )
    return {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "reviewed_steps": list(range(1, len(case.judge_view.steps) + 1)),
        "step_record_sha256s": hashes,
        "positive_row_count": len(positives),
        "positive_rows": positives,
    }


def build_local_record_set_document(
    *, case: Any, local_records: Sequence[dict[str, Any]]
) -> dict[str, Any]:
    if [record["step"] for record in local_records] != list(
        range(1, len(case.judge_view.steps) + 1)
    ):
        shared._fail("incomplete_step_local_record_set", case.trajectory_id)
    return {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "step_records": list(local_records),
    }


def _validate_local_record_set(
    raw: Any, *, case: Any, matrix: dict[str, Any], location: str
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != LOCAL_RECORD_SET_FIELDS:
        shared._fail("invalid_step_local_record_set_schema", location)
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
        or not isinstance(raw["step_records"], list)
        or len(raw["step_records"]) != len(case.judge_view.steps)
    ):
        shared._fail("step_local_record_set_identity_or_count_mismatch", location)
    records: list[dict[str, Any]] = []
    for step_number, record in enumerate(raw["step_records"], start=1):
        projection = build_step_projection_document(case, step_number)
        records.append(
            _validate_step_local_record(
                record,
                projection=projection,
                location=f"{location}.step_records[{step_number - 1}]",
            )
        )
    rebuilt = build_local_matrix_document(case=case, local_records=records)
    if rebuilt != matrix:
        shared._fail("step_local_matrix_not_deterministic_from_records", location)
    return raw


def _validate_local_matrix_record(
    raw: Any, *, case: Any, location: str
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != MATRIX_FIELDS:
        shared._fail("invalid_step_local_matrix_schema", location)
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
        or raw["reviewed_steps"] != list(range(1, len(case.judge_view.steps) + 1))
    ):
        shared._fail("step_local_matrix_identity_or_coverage_mismatch", location)
    hashes = raw["step_record_sha256s"]
    if not isinstance(hashes, list) or len(hashes) != len(case.judge_view.steps) or not all(
        isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value)
        for value in hashes
    ):
        shared._fail("invalid_step_local_matrix_hashes", location)
    positives = raw["positive_rows"]
    if (
        isinstance(raw["positive_row_count"], bool)
        or not isinstance(raw["positive_row_count"], int)
        or not isinstance(positives, list)
        or raw["positive_row_count"] != len(positives)
    ):
        shared._fail("invalid_step_local_matrix_positive_count", location)
    for index, row in enumerate(positives):
        row_location = f"{location}.positive_rows[{index}]"
        if not isinstance(row, dict) or tuple(row) != POSITIVE_ROW_FIELDS:
            shared._fail("invalid_step_local_positive_schema", row_location)
        if row["row_id"] != f"P{index + 1:03d}":
            shared._fail("invalid_step_local_positive_id", row_location)
        if (
            isinstance(row["step"], bool)
            or not isinstance(row["step"], int)
            or row["step"] < 1
            or row["step"] > len(case.judge_view.steps)
        ):
            shared._fail("invalid_step_local_positive_step", row_location)
        prediction = {
            "trajectory_id": case.trajectory_id,
            "trajectory_sha256": case.trajectory_sha256,
            "status": "success",
            "predicted_step": row["step"],
            "predicted_module": row["module"],
            "predicted_error_type": row["error_type"],
            "evidence_quote": row["evidence_quote"],
            "root_cause": row["local_reasoning"],
            "causal_summary": row["local_reasoning"],
            "rejected_adjacent_owner": "Local evidence row; global ownership not yet selected.",
        }
        shared._validate_prediction_record(
            prediction, case=case, location=f"{row_location}.projection"
        )
        if row["step_record_sha256"] != hashes[row["step"] - 1]:
            shared._fail("step_local_positive_hash_mismatch", row_location)
    return raw


def validate_local_matrix(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    matrix_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    matrix_file, matrix_raw = shared._load_artifact(
        matrix_path, role="step local evidence matrix"
    )
    matrix = _validate_local_matrix_record(
        matrix_raw, case=case, location="local_matrix"
    )
    return _retag(
        {
            "schema_version": "agentdebug.step-isolated-local-matrix-audit.v1",
            "stage": "deterministic_step_local_evidence_matrix",
            "gold_free_validation": True,
            "case_count": 1,
            "step_count": len(case.judge_view.steps),
            "complete_step_coverage": True,
            "positive_row_count": matrix["positive_row_count"],
            "input_sha256": {
                "prediction_manifest": shared._file_sha256(manifest),
                "cohort": shared._file_sha256(cohort),
            },
            "output_sha256": {LOCAL_MATRIX_FILENAME: shared._file_sha256(matrix_file)},
        },
        policy="deterministic_step_isolated_local_evidence_matrix",
    )


def _validate_optional_literal(
    *, case: Any, step: Any, quote: Any, location: str
) -> None:
    if step is None and quote is None:
        return
    if isinstance(step, bool) or not isinstance(step, int):
        shared._fail("invalid_duel_literal_step", location)
    if step < 1 or step > len(case.judge_view.steps):
        shared._fail("invalid_duel_literal_step", location)
    shared._nonempty_text(quote, location=f"{location}.quote", maximum=1800)
    if not any(quote in source for source in shared._packet_sources(case, step)):
        shared._fail("invalid_duel_literal_quote", location)


def _validate_panel_record(
    raw: Any,
    *,
    case: Any,
    location: str,
    matrix: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != PANEL_FIELDS:
        shared._fail("invalid_global_causal_proposal_schema", location)
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
    ):
        shared._fail("global_causal_proposal_identity_mismatch", location)
    if matrix is not None:
        if (
            raw["local_matrix_sha256"] != shared._stable_sha256(matrix)
            or raw["reviewed_steps"] != matrix["reviewed_steps"]
            or raw["positive_row_count"] != matrix["positive_row_count"]
            or raw["reviewed_row_ids"]
            != [row["row_id"] for row in matrix["positive_rows"]]
        ):
            shared._fail("incomplete_global_proposal_step_coverage", location)
    elif (
        raw["reviewed_steps"] != list(range(1, len(case.judge_view.steps) + 1))
        or isinstance(raw["positive_row_count"], bool)
        or not isinstance(raw["positive_row_count"], int)
        or raw["positive_row_count"] < 0
        or not isinstance(raw["reviewed_row_ids"], list)
        or len(raw["reviewed_row_ids"]) != raw["positive_row_count"]
    ):
        shared._fail("invalid_global_proposal_matrix_summary", location)
    if raw["proposal_status"] not in PANEL_STATUSES:
        shared._fail("invalid_global_proposal_status", location)
    if raw["boundary_class"] not in BOUNDARY_CLASSES:
        shared._fail("invalid_global_proposal_boundary_class", location)
    for field in (
        "probe_assessment",
        "recovery_assessment",
        "chronology_comparison",
        "critical_boundary_basis",
        "selection_falsifier",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3200)
    if raw["proposal_status"] == "none":
        if (
            raw["proposal_step"] is not None
            or raw["selected_row_id"] is not None
            or raw["proposal_prediction"] is not None
            or raw["boundary_class"] != "none"
        ):
            shared._fail("nonempty_global_none_proposal", location)
        expected_probe_status = "not_applicable"
    else:
        if raw["boundary_class"] == "none" or raw["positive_row_count"] < 1:
            shared._fail("empty_global_candidate_basis", location)
        selected_row = (
            next(
                (
                    row
                    for row in matrix["positive_rows"]
                    if row["row_id"] == raw["selected_row_id"]
                ),
                None,
            )
            if matrix is not None
            else None
        )
        if raw["selected_row_id"] not in raw["reviewed_row_ids"]:
            shared._fail("global_proposal_selected_unknown_local_row", location)
        prediction = shared._validate_prediction_record(
            raw["proposal_prediction"], case=case, location=f"{location}.proposal"
        )
        if (
            raw["proposal_step"] != prediction["predicted_step"]
            or (
                selected_row is not None
                and (
                    prediction["predicted_step"] != selected_row["step"]
                    or prediction["predicted_module"] != selected_row["module"]
                    or prediction["predicted_error_type"] != selected_row["error_type"]
                    or prediction["evidence_quote"] != selected_row["evidence_quote"]
                )
            )
        ):
            shared._fail("global_proposal_step_mismatch", location)
        expected_probe_status = None
    match = PROBE_ASSESSMENT_PREFIX.match(raw["probe_assessment"])
    if match is None or (
        expected_probe_status is not None and match.group(1) != expected_probe_status
    ):
        shared._fail("missing_global_proposal_probe_prefix", location)
    return raw


def validate_panel(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    matrix_path: str | Path,
    panel_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    matrix_file, matrix_raw = shared._load_artifact(
        matrix_path, role="step local evidence matrix"
    )
    matrix = _validate_local_matrix_record(
        matrix_raw, case=case, location="local_matrix"
    )
    panel_file, raw = shared._load_artifact(panel_path, role="global causal proposal")
    panel = shared._one_record(raw, role="global causal proposal")
    _validate_panel_record(
        panel, case=case, matrix=matrix, location="proposal[0]"
    )
    return _retag(
        {
            "schema_version": "agentdebug.step-local-global-proposal-audit.v1",
            "stage": "step_isolated_paper_local_global_challenger",
            "gold_free_validation": True,
            "case_count": 1,
            "anchor_visible": False,
            "complete_step_coverage": True,
            "all_positive_rows_reviewed": True,
            "maximum_candidates": 1,
            "proposal_status": panel["proposal_status"],
            "boundary_class": panel["boundary_class"],
            "input_sha256": {
                "prediction_manifest": shared._file_sha256(manifest),
                "cohort": shared._file_sha256(cohort),
                "local_matrix": shared._file_sha256(matrix_file),
            },
            "output_sha256": {PANEL_FILENAME: shared._file_sha256(panel_file)},
        },
        policy="step_isolated_paper_local_global_challenger",
    )


def build_panel_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    matrix_path: str | Path,
    panel_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    matrix_file, matrix_raw = shared._load_artifact(
        matrix_path, role="step local evidence matrix"
    )
    matrix = _validate_local_matrix_record(
        matrix_raw, case=case, location="local_matrix"
    )
    output = Path(panel_path).expanduser().resolve()
    shared._assert_safe_path(output, role="global proposal output", is_output=True)
    audit = output.parent / PANEL_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_53_clean_v3p20_step_isolated_paper_local_global_challenger",
            "--compact-validate",
            "panel",
            manifest,
            cohort,
            matrix_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    prediction_schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        "predicted_step": "selected Step",
        "predicted_module": "selected module",
        "predicted_error_type": "valid taxonomy type",
        "evidence_quote": "literal evidence owned by selected Step/module",
        "root_cause": "specific local root cause",
        "causal_summary": "why this boundary materially changes the failed path",
        "rejected_adjacent_owner": "strongest adjacent alternative and why rejected",
    }
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "local_matrix_sha256": shared._stable_sha256(matrix),
        "reviewed_steps": list(range(1, len(case.judge_view.steps) + 1)),
        "positive_row_count": matrix["positive_row_count"],
        "reviewed_row_ids": [row["row_id"] for row in matrix["positive_rows"]],
        "proposal_status": "candidate or none",
        "proposal_step": "integer Step or null",
        "selected_row_id": "one positive row_id or null",
        "boundary_class": "one allowed boundary class",
        "proposal_prediction": prediction_schema,
        "probe_assessment": "proposal_probe_status=<reasonable|material_error|not_applicable>; evidence",
        "recovery_assessment": "explicit recovery/mechanical/propagation/symptom veto audit",
        "chronology_comparison": "proposal versus every plausible earlier/later boundary",
        "critical_boundary_basis": "why this is the single benchmark-critical boundary",
        "selection_falsifier": "strongest concrete argument against this selection",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_53_VERSION} global proposal stage.

{_boundary(manifest=manifest, cohort=cohort, reads=(matrix_file,), output=output)}

{_PROPOSAL_RULES}

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

For `none`, set proposal_step/selected_row_id/proposal_prediction to null,
boundary_class to `none`, and begin probe_assessment exactly
`proposal_probe_status=not_applicable;`. Every candidate prediction must use
the standard fields in the displayed order and exact-copy the chosen row's
Step/module/type/evidence.
After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _load_anchor_bundle(
    manifest: Path,
    cohort: Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> tuple[Path, Path, Path, dict[str, Any], dict[str, Any], dict[str, Any]]:
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    anchor, ledger, checkpoint = shared._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    parent._validate_packet_state_ledgers(ledger_file)
    return anchor_file, ledger_file, checkpoint_file, anchor, ledger, checkpoint


def _validate_selector_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    panel: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != SELECTOR_FIELDS:
        shared._fail("invalid_anchor_proposal_duel_schema", location)
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
    ):
        shared._fail("anchor_proposal_duel_identity_mismatch", location)
    bindings = {
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "proposal_sha256": shared._stable_sha256(panel),
    }
    if any(raw[key] != value for key, value in bindings.items()):
        shared._fail("anchor_proposal_duel_hash_mismatch", location)
    proposal = panel["proposal_prediction"]
    proposal_step = panel["proposal_step"]
    if raw["anchor_step"] != anchor["predicted_step"] or raw["proposal_step"] != proposal_step:
        shared._fail("anchor_proposal_duel_step_binding_mismatch", location)
    if raw["decision"] not in SELECTOR_DECISIONS:
        shared._fail("invalid_anchor_proposal_duel_decision", location)
    if raw["anchor_classification"] not in ANCHOR_CLASSES:
        shared._fail("invalid_anchor_duel_classification", location)
    if raw["proposal_classification"] not in PROPOSAL_CLASSES:
        shared._fail("invalid_proposal_duel_classification", location)
    for field in (
        "anchor_assessment",
        "proposal_assessment",
        "timeline_comparison",
        "decision_basis",
        "rejected_alternative_basis",
        "selection_falsifier",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3400)
    anchor_prefix = (
        f"anchor_status={raw['anchor_classification']}; contribution_witness="
    )
    proposal_prefix = f"proposal_status={raw['proposal_classification']}; "
    if not raw["anchor_assessment"].startswith(anchor_prefix):
        shared._fail("missing_anchor_duel_assessment_prefix", location)
    if not raw["proposal_assessment"].startswith(proposal_prefix):
        shared._fail("missing_proposal_duel_assessment_prefix", location)
    selected = shared._validate_prediction_record(
        raw["selected_prediction"], case=case, location=f"{location}.selected"
    )
    if raw["selected_prediction_sha256"] != shared._stable_sha256(selected):
        shared._fail("anchor_proposal_duel_selected_hash_mismatch", location)
    if raw["frozen_step"] != selected["predicted_step"]:
        shared._fail("anchor_proposal_duel_frozen_step_mismatch", location)

    witness_fields = (
        "anchor_veto_evidence_step",
        "anchor_veto_evidence_quote",
        "anchor_contribution_witness_step",
        "anchor_contribution_witness_quote",
    )
    if raw["decision"] == "keep_anchor":
        if selected != anchor or any(raw[field] is not None for field in witness_fields):
            shared._fail("anchor_proposal_duel_keep_copy_mismatch", location)
        expected_witness = "not_applicable"
        if proposal is None and raw["proposal_classification"] != "absent":
            shared._fail("missing_absent_proposal_classification", location)
    else:
        if proposal is None or proposal_step == anchor["predicted_step"]:
            shared._fail("anchor_proposal_duel_selected_absent_or_same_step", location)
        if selected != proposal or raw["proposal_classification"] != "critical_root":
            shared._fail("anchor_proposal_duel_proposal_copy_mismatch", location)
        if raw["anchor_classification"] not in OVERRIDE_ANCHOR_CLASSES:
            shared._fail("anchor_proposal_duel_lacks_anchor_veto", location)
        _validate_optional_literal(
            case=case,
            step=raw["anchor_veto_evidence_step"],
            quote=raw["anchor_veto_evidence_quote"],
            location=f"{location}.anchor_veto",
        )
        if raw["anchor_veto_evidence_step"] is None:
            shared._fail("anchor_proposal_duel_missing_veto_evidence", location)
        if raw["anchor_classification"] == "contributing_probe":
            _validate_optional_literal(
                case=case,
                step=raw["anchor_contribution_witness_step"],
                quote=raw["anchor_contribution_witness_quote"],
                location=f"{location}.contribution_witness",
            )
            if raw["anchor_contribution_witness_step"] is None:
                shared._fail("anchor_probe_missing_positive_contribution_witness", location)
            expected_witness = "present"
        else:
            if (
                raw["anchor_contribution_witness_step"] is not None
                or raw["anchor_contribution_witness_quote"] is not None
            ):
                shared._fail("inactive_anchor_contribution_witness", location)
            expected_witness = "not_applicable"
    expected_anchor_prefix = anchor_prefix + expected_witness + "; "
    if not raw["anchor_assessment"].startswith(expected_anchor_prefix):
        shared._fail("invalid_anchor_contribution_witness_prefix", location)
    return raw


def validate_selector(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    panel_path: str | Path,
    selector_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger, checkpoint = bundle[3:]
    panel_file, panel_raw = shared._load_artifact(panel_path, role="global causal proposal")
    panel = shared._one_record(panel_raw, role="global causal proposal")
    _validate_panel_record(panel, case=case, location="proposal[0]")
    selector_file, selector_raw = shared._load_artifact(
        selector_path, role="anchor proposal duel"
    )
    selector = shared._one_record(selector_raw, role="anchor proposal duel")
    _validate_selector_record(
        selector,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        panel=panel,
        location="duel[0]",
    )
    return _retag(
        {
            "schema_version": "agentdebug.anchor-proposal-duel-audit.v1",
            "stage": "bounded_anchor_proposal_duel",
            "gold_free_validation": True,
            "case_count": 1,
            "decision": selector["decision"],
            "selected_prediction_exact_copy": True,
            "maximum_total_predictions": 2,
            "positive_contribution_witness_binding": True,
            "input_sha256": {
                "anchor": shared._file_sha256(anchor_file),
                "ledger": shared._file_sha256(ledger_file),
                "checkpoint": shared._file_sha256(checkpoint_file),
                "proposal": shared._file_sha256(panel_file),
            },
            "output_sha256": {SELECTOR_FILENAME: shared._file_sha256(selector_file)},
        },
        policy="bounded_anchor_global_proposal_exact_copy_duel",
    )


def build_selector_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    panel_path: str | Path,
    selector_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger, checkpoint = bundle[3:]
    panel_file, panel_raw = shared._load_artifact(panel_path, role="global causal proposal")
    panel = shared._one_record(panel_raw, role="global causal proposal")
    _validate_panel_record(panel, case=case, location="proposal[0]")
    output = Path(selector_path).expanduser().resolve()
    shared._assert_safe_path(output, role="anchor proposal duel output", is_output=True)
    audit = output.parent / SELECTOR_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_53_clean_v3p20_step_isolated_paper_local_global_challenger",
            "--compact-validate",
            "selector",
            manifest,
            cohort,
            anchor_file,
            ledger_file,
            checkpoint_file,
            panel_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "proposal_sha256": shared._stable_sha256(panel),
        "anchor_step": anchor["predicted_step"],
        "proposal_step": panel["proposal_step"],
        "decision": "keep_anchor or select_proposal",
        "anchor_classification": "one allowed anchor class",
        "proposal_classification": "one allowed proposal class",
        "anchor_veto_evidence_step": "literal veto Step or null",
        "anchor_veto_evidence_quote": "literal veto quote or null",
        "anchor_contribution_witness_step": "literal contribution Step or null",
        "anchor_contribution_witness_quote": "literal contribution quote or null",
        "frozen_step": "selected prediction Step",
        "selected_prediction_sha256": "stable hash of exact selected prediction",
        "selected_prediction": "exact anchor or proposal prediction object",
        "anchor_assessment": "anchor_status=<class>; contribution_witness=<present|not_applicable>; assessment",
        "proposal_assessment": "proposal_status=<class>; assessment",
        "timeline_comparison": "literal pairwise chronology",
        "decision_basis": "why the exact selected boundary wins",
        "rejected_alternative_basis": "why the other boundary loses",
        "selection_falsifier": "strongest concrete argument against the decision",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_53_VERSION} stage 3/3: bounded proposal duel.

{_boundary(manifest=manifest, cohort=cohort, reads=(anchor_file, ledger_file, checkpoint_file, panel_file), output=output)}

{_DUEL_RULES}

The immutable anchor Step is {anchor['predicted_step']}; the anchor-blind
proposal Step is {panel['proposal_step']}. For keep_anchor, exact-copy the
anchor and set all four veto/contribution witness fields to null. For
select_proposal, exact-copy the proposal and satisfy every witness binding.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

Compute content hashes from sorted compact UTF-8 JSON. After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _validate_aggregate(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(prediction_manifest_path, cohort_manifest_path)
    root = Path(predictions_path).expanduser().resolve().parent
    names = (
        ANCHOR_PREDICTIONS_FILENAME,
        ANCHOR_LEDGER_AGGREGATE_FILENAME,
        ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        STEP_LOCAL_RECORDS_FILENAME,
        LOCAL_MATRICES_FILENAME,
        PANELS_FILENAME,
        SELECTORS_FILENAME,
    )
    loaded = {
        name: shared._load_artifact(root / name, role=f"merged {name}")[1]
        for name in names
    }
    if any(
        not isinstance(value, list) or len(value) != len(cases)
        for value in loaded.values()
    ):
        shared._fail("invalid_global_proposal_aggregate_count", "all artifacts need all cases")
    finals = shared._load_artifact(predictions_path, role="merged predictions")[1]
    if not isinstance(finals, list) or len(finals) != len(cases):
        shared._fail("invalid_global_proposal_prediction_count", "predictions need all cases")
    proposal_statuses: Counter[str] = Counter()
    boundary_classes: Counter[str] = Counter()
    decisions: Counter[str] = Counter()
    anchor_classes: Counter[str] = Counter()
    positive_counts: Counter[int] = Counter()
    for index, case in enumerate(cases):
        location = f"global_proposal_merged[{index}]"
        anchor = loaded[ANCHOR_PREDICTIONS_FILENAME][index]
        ledger = loaded[ANCHOR_LEDGER_AGGREGATE_FILENAME][index]
        checkpoint = loaded[ANCHOR_CHECKPOINT_AGGREGATE_FILENAME][index]
        local_record_set = loaded[STEP_LOCAL_RECORDS_FILENAME][index]
        matrix = loaded[LOCAL_MATRICES_FILENAME][index]
        panel = loaded[PANELS_FILENAME][index]
        selector = loaded[SELECTORS_FILENAME][index]
        shared._validate_prediction_record(anchor, case=case, location=f"{location}.anchor")
        if (
            ledger.get("trajectory_id") != case.trajectory_id
            or ledger.get("selected_step") != anchor["predicted_step"]
            or checkpoint.get("trajectory_id") != case.trajectory_id
            or checkpoint.get("predicted_step") != anchor["predicted_step"]
        ):
            shared._fail("global_proposal_anchor_sidecar_mismatch", location)
        _validate_local_matrix_record(
            matrix, case=case, location=f"{location}.local_matrix"
        )
        _validate_local_record_set(
            local_record_set,
            case=case,
            matrix=matrix,
            location=f"{location}.local_records",
        )
        _validate_panel_record(
            panel, case=case, matrix=matrix, location=f"{location}.proposal"
        )
        _validate_selector_record(
            selector,
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            panel=panel,
            location=f"{location}.duel",
        )
        final = shared._validate_prediction_record(
            finals[index], case=case, location=f"{location}.final"
        )
        if final != selector["selected_prediction"]:
            shared._fail("global_proposal_final_copy_mismatch", location)
        proposal_statuses[panel["proposal_status"]] += 1
        boundary_classes[panel["boundary_class"]] += 1
        decisions[selector["decision"]] += 1
        anchor_classes[selector["anchor_classification"]] += 1
        positive_counts[matrix["positive_row_count"]] += 1
    return {
        "required": True,
        "valid": True,
        "step_isolated_local_evidence": True,
        "local_step_coverage_complete": True,
        "anchor_blind_global_proposal": True,
        "maximum_specialist_candidates": 1,
        "maximum_total_predictions": 2,
        "default_anchor_policy": True,
        "positive_contribution_witness_binding": True,
        "all_selected_predictions_exact_copies": True,
        "proposal_status_counts": dict(sorted(proposal_statuses.items())),
        "boundary_class_counts": dict(sorted(boundary_classes.items())),
        "selector_decision_counts": dict(sorted(decisions.items())),
        "anchor_classification_counts": dict(sorted(anchor_classes.items())),
        "local_positive_count_distribution": {
            str(key): value for key, value in sorted(positive_counts.items())
        },
        "packet_state_closure": parent._validate_packet_state_ledgers(
            root / ANCHOR_LEDGER_AGGREGATE_FILENAME
        ),
    }


def validate_agent_judge_luna_gaia_v3_53_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    mechanism = _validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_53_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_53_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_53_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_53_REASONING_EFFORT,
        "selection_policy": "clean_v3_20_step_isolated_paper_local_global_challenger_exact_copy_duel",
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": (
            "one step-isolated paper-local evidence matrix feeding one "
            "anchor-blind global challenger"
        ),
        "anchor_semantics_unchanged_from_v3_20": True,
        "all_selected_predictions_exact_copies": True,
        "step_isolated_paper_local_global_challenger": mechanism,
    }


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_step_local_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_step_local(*paths[:-1]), paths[-1])


def validate_and_write_local_matrix_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_local_matrix(*paths[:-1]), paths[-1])


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_panel(*paths[:-1]), paths[-1])


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_selector(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_53_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_53_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_luna_gaia_v3_53_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_selector_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / PANEL_FILENAME,
        prediction.parent / SELECTOR_FILENAME,
    )


# Generic three-stage runner compatibility aliases.
validate_and_write_agent_judge_luna_gaia_v3_37_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_53_audit
)
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_luna_gaia_v3_53_task
build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_53_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_53_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_53_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "local" and len(paths) == 3:
            audit = validate_and_write_step_local_audit(*paths)
        elif stage == "matrix" and len(paths) == 4:
            audit = validate_and_write_local_matrix_audit(*paths)
        elif stage == "panel" and len(paths) == 5:
            audit = validate_and_write_panel_audit(*paths)
        elif stage == "selector" and len(paths) == 8:
            audit = validate_and_write_selector_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_53_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except (shared.AgentJudgeValidationError, json.JSONDecodeError, OSError) as error:
        code = getattr(error, "code", type(error).__name__)
        print(json.dumps({"ok": False, "code": code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument(
        "stage",
        choices=("anchor", "local", "matrix", "panel", "selector", "prediction"),
    )
    parser.add_argument("paths", nargs="+")
    args = parser.parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

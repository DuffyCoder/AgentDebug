"""Luna GAIA v3.60: clean-v3.20 retrospective prefix-ledger closure."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions
from .taxonomy import AgentModule, ErrorType, is_valid_classification, taxonomy_prompt


AGENT_JUDGE_LUNA_GAIA_V3_60_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.60-clean-v3.20-"
    "retrospective-prefix-ledger-closure"
)
AGENT_JUDGE_LUNA_GAIA_V3_60_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_60_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_60_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
RETROSPECTIVE_INPUT_FILENAME = "retrospective-judge-view.json"
RETROSPECTIVE_INPUT_AUDIT_FILENAME = "retrospective-judge-view-audit.json"
RETROSPECTIVE_ASSESSMENT_FILENAME = "retrospective-prefix-assessment.json"
RETROSPECTIVE_ASSESSMENTS_FILENAME = "retrospective-prefix-assessments.json"
RETROSPECTIVE_ASSESSMENT_AUDIT_FILENAME = "retrospective-prefix-assessment-audit.json"
PREFIX_SELECTOR_FILENAME = "retrospective-prefix-ledger-selector.json"
PREFIX_SELECTORS_FILENAME = "retrospective-prefix-ledger-selectors.json"
PREFIX_SELECTOR_AUDIT_FILENAME = "retrospective-prefix-ledger-selector-audit.json"
INPUT_BINDING_FILENAME = "retrospective-input-binding.json"
INPUT_BINDINGS_FILENAME = "retrospective-input-bindings.json"

CLASSIFICATIONS = frozenset(
    {
        "critical_root",
        "reasonable_probe",
        "informative_different_probe",
        "normal_tool_failure",
        "recovered_defect",
        "noncritical_predecessor",
        "faithful_propagation",
        "downstream_symptom",
        "no_local_defect",
        "uncertain",
    }
)
ASSESSMENT_RECORD_FIELDS = (
    "anchor_assessment",
    "row_assessments",
    "chronology_summary",
    "selection_falsifier",
)
RAW_ROW_ASSESSMENT_FIELDS = (
    "classification",
    "predicted_module",
    "predicted_error_type",
    "evidence_quote",
    "pre_step_observation",
    "literal_defect_analysis",
    "observed_outcome_effect",
    "path_consumption_check",
    "recovery_check",
    "candidate_only_repair_effect",
    "qualifies_as_critical_boundary",
    "qualification_basis",
    "adjacent_owner_rejection",
    "falsifier",
)
BOUND_ROW_ASSESSMENT_FIELDS = (
    "row_index",
    "step",
    "ledger_row_sha256",
    "original_lane_a",
    "original_lane_b",
    "original_system",
    "original_lane_c",
    "original_surviving_lane",
    "original_evidence_quote",
    "original_decision_basis",
    *RAW_ROW_ASSESSMENT_FIELDS,
    "candidate_prediction",
)
SELECTOR_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "anchor_prediction_sha256",
    "anchor_ledger_sha256",
    "anchor_checkpoint_sha256",
    "retrospective_input_sha256",
    "earlier_row_count",
    "reviewed_row_steps",
    "row_assessments",
    "decision",
    "selected_row_index",
    "anchor_step",
    "frozen_step",
    "selected_prediction_sha256",
    "selected_prediction",
    "anchor_assessment",
    "chronology_summary",
    "selection_falsifier",
)
INPUT_BINDING_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "retrospective_input_sha256",
    "anchor_prediction_sha256",
    "anchor_ledger_sha256",
    "anchor_checkpoint_sha256",
    "earlier_row_count",
    "earlier_row_steps",
)


_RETROSPECTIVE_RULES = """\
RETROSPECTIVE PREFIX-LEDGER CLOSURE — ONE BOUNDED MECHANISM

The unchanged clean-v3.20 anchor and its chronological ledger are immutable.
Assess every ledger row strictly earlier than the anchor, exactly once and in
ledger order. Do not invent, omit, reorder, or search for any Step. The ledger
is a sparse bounded candidate set; it is not a vote and its prose is not a
final verdict.

The original `veto_initial_probe` or `veto_different_probe` decision is ex-ante
evidence, not a categorical retrospective veto. With the actual same-Step
output, adjacent feedback, and later continuation visible, a row qualifies as
`critical_root` only when ALL of the following are literal and concrete:

1. the Step contains a taxonomy-valid defect owned by Memory, Reflection,
   Planning, Action, or System, rather than merely an improvable choice;
2. the actual immediate outcome shows material task-state loss, a malformed or
   incapable operation, a violated task constraint, unsupported retained
   state, or an indispensable external execution failure;
3. the observed later path consumes or preserves that defect rather than
   independently choosing an unrelated route;
4. the defect is not fully repaired before it matters; and
5. repairing only this row, while preserving all prior observations, would
   materially change the failed path.

A reasonable task-relevant initial probe remains `reasonable_probe`. A
materially different probe that can expose a necessary lead remains
`informative_different_probe`, even if hindsight suggests a better route.
Ordinary empty or negative tool results are `normal_tool_failure`, not System
errors. Use `recovered_defect`, `noncritical_predecessor`,
`faithful_propagation`, or `downstream_symptom` when those relations are
literally established. Unresolved evidence is `uncertain`, never a promotion.

Set `qualifies_as_critical_boundary=true` if and only if classification is
`critical_root`. For a qualifying row, provide exactly one taxonomy-valid
module/type and a literal evidence quote from that owner's output at the bound
Step. For a nonqualifying row, all three candidate fields must be null. Module
and type establish output legality only and never rank rows.

The program binds row identity, Step, hashes, original lane verdicts,
candidate predictions, final decision, and final exact copy. You emit only the
semantic fields in the required array order. The deterministic reducer will
select the chronologically earliest qualifying row; if none qualifies it will
keep the anchor. Do not compare source identities, use benchmark priors, or
infer from trajectory names, entities, sites, models, scores, gold, or old
predictions.
"""


def _rewrite_identity(task: str) -> str:
    module = (
        "agent_judge_luna_gaia_v3_60_clean_v3p20_"
        "retrospective_prefix_ledger_closure"
    )
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_60_VERSION,
        )
        .replace("agent_judge_luna_gaia_v3_20_packet_state_closure", module)
        .replace(
            f"- agentdebug/diagnostics/{module}.py",
            "- agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py",
        )
    )


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_60_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_60_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_60_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "retrospective closure over every pre-anchor row in the unchanged v3.20 sparse ledger",
    }


def _boundary(
    *, manifest: Path, cohort: Path, reads: Sequence[Path], output: Path
) -> str:
    return f"""\
IMMUTABLE EXECUTION CONFIGURATION
- model: {AGENT_JUDGE_LUNA_GAIA_V3_60_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_60_REASONING_EFFORT}
- one isolated case; fresh session; no cross-case state or prior predictions
- external LLM/API/network calls: forbidden
- scoring or gold-label access: forbidden

INPUT/OUTPUT BOUNDARY
- validation-only prediction manifest: {manifest}
- validation-only cohort manifest: {cohort}
- permitted frozen stage inputs:
{chr(10).join(f'- {path}' for path in reads)}
- taxonomy source: {Path(__file__).resolve().parent / 'taxonomy.py'}
- write the sole stage artifact only to: {output}

Use the manifest and cohort only when running the required validator command;
do not use their trajectory identity as semantic evidence. Read only the listed
files and taxonomy source. Do not inspect directories, labels, metrics, scored
artifacts, experiment documents, old predictions, error reports, case studies,
git history, or external resources.
"""


def build_anchor_task(*paths: str | Path) -> str:
    """Run the accepted v3.20 anchor semantics unchanged."""

    return _rewrite_identity(parent.build_anchor_task(*paths))


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths), policy="unchanged_v3_20_anchor")


def _observation_excerpt(observation: Any) -> str:
    """Remove cumulative wrapper/history duplication without losing new feedback."""

    projection = observation.benchmark_input
    if projection is not None:
        pieces = (
            observation.text[
                projection.step_marker_start_char : projection.step_marker_end_char
            ],
            observation.text[
                projection.observation_start_char : projection.observation_end_char
            ],
            observation.text[projection.suffix_start_char : projection.suffix_end_char],
        )
        return "\n".join(piece.strip() for piece in pieces if piece.strip())
    if observation.repeated_prefix_chars > 0:
        return observation.incremental_text.strip()
    return observation.text.strip()


def build_retrospective_input_document(case: Any) -> dict[str, Any]:
    """Create one deterministic gold-free timeline with wrapper history deduplicated."""

    steps: list[dict[str, Any]] = []
    for step in case.judge_view.steps:
        owners: dict[str, list[str]] = {
            module.value: [] for module in AgentModule
        }
        for span in step.module_spans:
            value = step.assistant_raw_output[
                span.content_start_char : span.content_end_char
            ].strip()
            if span.module in owners and value:
                owners[span.module].append(value)
        owners[AgentModule.SYSTEM.value] = list(
            shared._luna_gaia_v2_owner_source_resolver(
                case.judge_view,
                step.step,
                AgentModule.SYSTEM,
                ErrorType.TOOL_EXECUTION_ERROR,
            )
        )
        steps.append(
            {
                "step": step.step,
                "current_input": [
                    value
                    for item in step.current_input
                    if (value := _observation_excerpt(item))
                ],
                "assistant_raw_output": step.assistant_raw_output,
                "owner_sources": owners,
                "adjacent_feedback": [
                    value
                    for item in step.adjacent_feedback
                    if (value := _observation_excerpt(item))
                ],
                "stop_reason": step.stop_reason,
                "error_message": step.error_message,
            }
        )
    facts = case.judge_view.execution_facts
    return {
        "schema_version": "agentdebug.retrospective-deduplicated-full-timeline.v1",
        "task": {
            "user_request": case.judge_view.task.user_request,
        },
        "execution_facts": {
            "metadata_steps": facts.metadata_steps,
            "metadata_won": facts.metadata_won,
            "metadata_success": facts.metadata_success,
            "canonical_turn_count": facts.canonical_turn_count,
            "final_stop_reason": facts.final_stop_reason,
            "final_error_message": facts.final_error_message,
        },
        "step_count": len(steps),
        "steps": steps,
    }


def _validate_retrospective_input(raw: Any, *, case: Any, location: str) -> dict[str, Any]:
    expected = build_retrospective_input_document(case)
    if raw != expected:
        shared._fail("retrospective_input_not_deterministic", location)
    return raw


def validate_retrospective_input(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    retrospective_input_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    input_file, raw = shared._load_artifact(
        retrospective_input_path, role="retrospective JudgeView input"
    )
    value = _validate_retrospective_input(raw, case=case, location="retrospective_input")
    return _retag(
        {
            "schema_version": "agentdebug.retrospective-deduplicated-full-timeline-audit.v1",
            "stage": "deterministic_retrospective_deduplicated_full_timeline",
            "gold_free_validation": True,
            "case_count": 1,
            "step_count": value["step_count"],
            "complete_timeline_visible": True,
            "cumulative_wrapper_history_deduplicated": True,
            "trajectory_identity_omitted": True,
            "input_sha256": {
                "prediction_manifest": shared._file_sha256(manifest),
                "cohort": shared._file_sha256(cohort),
            },
            "output_sha256": {
                RETROSPECTIVE_INPUT_FILENAME: shared._file_sha256(input_file)
            },
        },
        policy="deterministic_gold_free_full_judge_view_projection",
    )


def _load_anchor_bundle(
    manifest: Path,
    cohort: Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> tuple[Path, Path, Path, dict[str, Any], dict[str, Any], dict[str, Any]]:
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    anchor, ledger, checkpoint = shared._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    parent._validate_packet_state_ledgers(ledger_file)
    return anchor_file, ledger_file, checkpoint_file, anchor, ledger, checkpoint


def _earlier_rows(ledger: dict[str, Any], *, anchor_step: int) -> list[dict[str, Any]]:
    rows = ledger.get("rows")
    if not isinstance(rows, list) or not rows:
        shared._fail("invalid_prefix_ledger_rows", "ledger.rows")
    steps: list[int] = []
    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            shared._fail("invalid_prefix_ledger_row", f"ledger.rows[{index}]")
        step = row.get("step")
        if isinstance(step, bool) or not isinstance(step, int):
            shared._fail("invalid_prefix_ledger_step", f"ledger.rows[{index}]")
        steps.append(step)
    if steps != sorted(set(steps)) or anchor_step not in steps:
        shared._fail("invalid_prefix_ledger_chronology", "ledger.rows")
    if ledger.get("selected_step") != anchor_step:
        shared._fail("prefix_ledger_anchor_mismatch", "ledger.selected_step")
    return [row for row in rows if row["step"] < anchor_step]


def _validate_semantic_assessment_record(
    raw: Any,
    *,
    case: Any,
    earlier_rows: Sequence[dict[str, Any]],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != ASSESSMENT_RECORD_FIELDS:
        shared._fail("invalid_retrospective_assessment_schema", location)
    assessments = raw["row_assessments"]
    if not isinstance(assessments, list) or len(assessments) != len(earlier_rows):
        shared._fail("incomplete_retrospective_row_coverage", location)
    for index, (assessment, row) in enumerate(
        zip(assessments, earlier_rows, strict=True)
    ):
        row_location = f"{location}.row_assessments[{index}]"
        if not isinstance(assessment, dict) or tuple(assessment) != RAW_ROW_ASSESSMENT_FIELDS:
            shared._fail("invalid_retrospective_row_assessment_schema", row_location)
        classification = assessment["classification"]
        if classification not in CLASSIFICATIONS:
            shared._fail("invalid_retrospective_classification", row_location)
        qualifies = assessment["qualifies_as_critical_boundary"]
        if not isinstance(qualifies, bool) or qualifies != (classification == "critical_root"):
            shared._fail("retrospective_qualification_class_mismatch", row_location)
        for field in (
            "pre_step_observation",
            "literal_defect_analysis",
            "observed_outcome_effect",
            "path_consumption_check",
            "recovery_check",
            "candidate_only_repair_effect",
            "qualification_basis",
            "adjacent_owner_rejection",
            "falsifier",
        ):
            shared._nonempty_text(
                assessment[field], location=f"{row_location}.{field}", maximum=1800
            )
        candidate_fields = (
            assessment["predicted_module"],
            assessment["predicted_error_type"],
            assessment["evidence_quote"],
        )
        if not qualifies:
            if candidate_fields != (None, None, None):
                shared._fail("nonqualifying_row_has_candidate_fields", row_location)
            continue
        if not all(isinstance(value, str) and value.strip() for value in candidate_fields):
            shared._fail("qualifying_row_missing_candidate_fields", row_location)
        try:
            module = AgentModule(assessment["predicted_module"])
            error_type = ErrorType(assessment["predicted_error_type"])
        except ValueError:
            shared._fail("invalid_retrospective_taxonomy", row_location)
        if not is_valid_classification(module, error_type):
            shared._fail("invalid_retrospective_taxonomy", row_location)
        sources = shared._luna_gaia_v2_owner_source_resolver(
            case.judge_view, row["step"], module, error_type
        )
        if not sources or not any(assessment["evidence_quote"] in source for source in sources):
            shared._fail("invalid_retrospective_evidence", row_location)
    for field in ("anchor_assessment", "chronology_summary", "selection_falsifier"):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=2400)
    return raw


def validate_retrospective_assessment(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    retrospective_input_path: str | Path,
    assessment_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger = bundle[3:5]
    input_file, input_raw = shared._load_artifact(
        retrospective_input_path, role="retrospective JudgeView input"
    )
    _validate_retrospective_input(input_raw, case=case, location="retrospective_input")
    assessment_file, assessment_raw = shared._load_artifact(
        assessment_path, role="retrospective prefix assessment"
    )
    assessment = shared._one_record(
        assessment_raw, role="retrospective prefix assessment"
    )
    rows = _earlier_rows(ledger, anchor_step=anchor["predicted_step"])
    _validate_semantic_assessment_record(
        assessment, case=case, earlier_rows=rows, location="retrospective_assessment[0]"
    )
    return _retag(
        {
            "schema_version": "agentdebug.retrospective-prefix-assessment-audit.v1",
            "stage": "retrospective_prefix_ledger_semantic_assessment",
            "gold_free_validation": True,
            "case_count": 1,
            "earlier_row_count": len(rows),
            "complete_earlier_row_coverage": True,
            "model_authored_identity_hash_step_or_decision": False,
            "input_sha256": {
                "anchor": shared._file_sha256(anchor_file),
                "ledger": shared._file_sha256(ledger_file),
                "checkpoint": shared._file_sha256(checkpoint_file),
                "retrospective_input": shared._file_sha256(input_file),
            },
            "output_sha256": {
                RETROSPECTIVE_ASSESSMENT_FILENAME: shared._file_sha256(assessment_file)
            },
        },
        policy="semantic_only_complete_retrospective_prefix_ledger_closure",
    )


def _candidate_prediction(
    *, case: Any, row: dict[str, Any], assessment: dict[str, Any]
) -> dict[str, Any]:
    prediction = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        "predicted_step": row["step"],
        "predicted_module": assessment["predicted_module"],
        "predicted_error_type": assessment["predicted_error_type"],
        "evidence_quote": assessment["evidence_quote"],
        "root_cause": assessment["literal_defect_analysis"],
        "causal_summary": assessment["candidate_only_repair_effect"],
        "rejected_adjacent_owner": assessment["adjacent_owner_rejection"],
    }
    return shared._validate_prediction_record(
        prediction, case=case, location="retrospective_candidate_prediction"
    )


def build_prefix_selector_document(
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    retrospective_input: dict[str, Any],
    semantic_assessment: dict[str, Any],
) -> dict[str, Any]:
    rows = _earlier_rows(ledger, anchor_step=anchor["predicted_step"])
    semantic = _validate_semantic_assessment_record(
        semantic_assessment,
        case=case,
        earlier_rows=rows,
        location="retrospective_assessment",
    )
    bound: list[dict[str, Any]] = []
    qualifying_indexes: list[int] = []
    for index, (row, assessment) in enumerate(
        zip(rows, semantic["row_assessments"], strict=True)
    ):
        candidate = None
        if assessment["qualifies_as_critical_boundary"]:
            candidate = _candidate_prediction(case=case, row=row, assessment=assessment)
            qualifying_indexes.append(index)
        bound.append(
            {
                "row_index": index + 1,
                "step": row["step"],
                "ledger_row_sha256": shared._stable_sha256(row),
                "original_lane_a": row.get("lane_a"),
                "original_lane_b": row.get("lane_b"),
                "original_system": row.get("system"),
                "original_lane_c": row.get("lane_c"),
                "original_surviving_lane": row.get("surviving_lane"),
                "original_evidence_quote": row.get("evidence_quote"),
                "original_decision_basis": row.get("decision_basis"),
                **assessment,
                "candidate_prediction": candidate,
            }
        )
    selected_index = min(qualifying_indexes, default=None)
    if selected_index is None:
        decision = "keep_anchor"
        selected_row_index = None
        selected = anchor
    else:
        decision = "select_prefix_row"
        selected_row_index = selected_index + 1
        selected = bound[selected_index]["candidate_prediction"]
    result = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "retrospective_input_sha256": shared._stable_sha256(retrospective_input),
        "earlier_row_count": len(rows),
        "reviewed_row_steps": [row["step"] for row in rows],
        "row_assessments": bound,
        "decision": decision,
        "selected_row_index": selected_row_index,
        "anchor_step": anchor["predicted_step"],
        "frozen_step": selected["predicted_step"],
        "selected_prediction_sha256": shared._stable_sha256(selected),
        "selected_prediction": selected,
        "anchor_assessment": semantic["anchor_assessment"],
        "chronology_summary": semantic["chronology_summary"],
        "selection_falsifier": semantic["selection_falsifier"],
    }
    return _validate_prefix_selector_record(
        result,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        retrospective_input=retrospective_input,
        semantic_assessment=semantic,
        location="deterministic_prefix_selector",
    )


def _validate_prefix_selector_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    retrospective_input: dict[str, Any],
    semantic_assessment: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != SELECTOR_FIELDS:
        shared._fail("invalid_prefix_selector_schema", location)
    if raw["trajectory_id"] != case.trajectory_id or raw["trajectory_sha256"] != case.trajectory_sha256:
        shared._fail("prefix_selector_identity_mismatch", location)
    expected_hashes = {
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "retrospective_input_sha256": shared._stable_sha256(retrospective_input),
    }
    if any(raw[key] != value for key, value in expected_hashes.items()):
        shared._fail("prefix_selector_hash_mismatch", location)
    rows = _earlier_rows(ledger, anchor_step=anchor["predicted_step"])
    semantic = _validate_semantic_assessment_record(
        semantic_assessment, case=case, earlier_rows=rows, location=f"{location}.semantic"
    )
    if raw["earlier_row_count"] != len(rows) or raw["reviewed_row_steps"] != [row["step"] for row in rows]:
        shared._fail("incomplete_prefix_selector_coverage", location)
    if raw["anchor_step"] != anchor["predicted_step"]:
        shared._fail("prefix_selector_anchor_step_mismatch", location)
    bound = raw["row_assessments"]
    if not isinstance(bound, list) or len(bound) != len(rows):
        shared._fail("invalid_bound_prefix_row_count", location)
    qualifying: list[int] = []
    for index, (item, row, assessment) in enumerate(
        zip(bound, rows, semantic["row_assessments"], strict=True)
    ):
        row_location = f"{location}.row_assessments[{index}]"
        if not isinstance(item, dict) or tuple(item) != BOUND_ROW_ASSESSMENT_FIELDS:
            shared._fail("invalid_bound_prefix_row_schema", row_location)
        expected_binding = {
            "row_index": index + 1,
            "step": row["step"],
            "ledger_row_sha256": shared._stable_sha256(row),
            "original_lane_a": row.get("lane_a"),
            "original_lane_b": row.get("lane_b"),
            "original_system": row.get("system"),
            "original_lane_c": row.get("lane_c"),
            "original_surviving_lane": row.get("surviving_lane"),
            "original_evidence_quote": row.get("evidence_quote"),
            "original_decision_basis": row.get("decision_basis"),
        }
        if any(item[key] != value for key, value in expected_binding.items()):
            shared._fail("bound_prefix_row_drift", row_location)
        if any(item[key] != assessment[key] for key in RAW_ROW_ASSESSMENT_FIELDS):
            shared._fail("bound_prefix_semantic_drift", row_location)
        if assessment["qualifies_as_critical_boundary"]:
            expected_candidate = _candidate_prediction(
                case=case, row=row, assessment=assessment
            )
            if item["candidate_prediction"] != expected_candidate:
                shared._fail("bound_prefix_candidate_drift", row_location)
            qualifying.append(index)
        elif item["candidate_prediction"] is not None:
            shared._fail("nonqualifying_bound_row_has_candidate", row_location)
    expected_index = min(qualifying, default=None)
    selected = shared._validate_prediction_record(
        raw["selected_prediction"], case=case, location=f"{location}.selected_prediction"
    )
    if raw["selected_prediction_sha256"] != shared._stable_sha256(selected) or raw["frozen_step"] != selected["predicted_step"]:
        shared._fail("prefix_selector_selected_binding_mismatch", location)
    if expected_index is None:
        if raw["decision"] != "keep_anchor" or raw["selected_row_index"] is not None or selected != anchor:
            shared._fail("prefix_selector_keep_anchor_mismatch", location)
    else:
        expected = bound[expected_index]["candidate_prediction"]
        if raw["decision"] != "select_prefix_row" or raw["selected_row_index"] != expected_index + 1 or selected != expected:
            shared._fail("prefix_selector_earliest_qualifying_mismatch", location)
    if (
        raw["anchor_assessment"] != semantic["anchor_assessment"]
        or raw["chronology_summary"] != semantic["chronology_summary"]
        or raw["selection_falsifier"] != semantic["selection_falsifier"]
    ):
        shared._fail("prefix_selector_summary_drift", location)
    return raw


def build_input_binding_document(
    *, case: Any, anchor: dict[str, Any], ledger: dict[str, Any], checkpoint: dict[str, Any]
) -> dict[str, Any]:
    retrospective_input = build_retrospective_input_document(case)
    rows = _earlier_rows(ledger, anchor_step=anchor["predicted_step"])
    return {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "retrospective_input_sha256": shared._stable_sha256(retrospective_input),
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "earlier_row_count": len(rows),
        "earlier_row_steps": [row["step"] for row in rows],
    }


def _validate_input_binding(
    raw: Any, *, case: Any, anchor: dict[str, Any], ledger: dict[str, Any], checkpoint: dict[str, Any], location: str
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != INPUT_BINDING_FIELDS:
        shared._fail("invalid_retrospective_input_binding_schema", location)
    expected = build_input_binding_document(
        case=case, anchor=anchor, ledger=ledger, checkpoint=checkpoint
    )
    if raw != expected:
        shared._fail("retrospective_input_binding_mismatch", location)
    return raw


def validate_prefix_selector(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    retrospective_input_path: str | Path,
    assessment_path: str | Path,
    selector_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger, checkpoint = bundle[3:]
    input_file, input_raw = shared._load_artifact(
        retrospective_input_path, role="retrospective JudgeView input"
    )
    retrospective_input = _validate_retrospective_input(
        input_raw, case=case, location="retrospective_input"
    )
    assessment_file, assessment_raw = shared._load_artifact(
        assessment_path, role="retrospective prefix assessment"
    )
    semantic = shared._one_record(
        assessment_raw, role="retrospective prefix assessment"
    )
    selector_file, selector_raw = shared._load_artifact(
        selector_path, role="retrospective prefix selector"
    )
    selector = shared._one_record(selector_raw, role="retrospective prefix selector")
    _validate_prefix_selector_record(
        selector,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        retrospective_input=retrospective_input,
        semantic_assessment=semantic,
        location="prefix_selector[0]",
    )
    expected = build_prefix_selector_document(
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        retrospective_input=retrospective_input,
        semantic_assessment=semantic,
    )
    if selector != expected:
        shared._fail("non_deterministic_prefix_selector_assembly", "prefix_selector[0]")
    return _retag(
        {
            "schema_version": "agentdebug.retrospective-prefix-ledger-selector-audit.v1",
            "stage": "deterministic_retrospective_prefix_ledger_selector",
            "gold_free_validation": True,
            "case_count": 1,
            "decision": selector["decision"],
            "earlier_row_count": selector["earlier_row_count"],
            "qualifying_row_count": sum(
                row["qualifies_as_critical_boundary"] for row in selector["row_assessments"]
            ),
            "complete_earlier_row_coverage": True,
            "deterministic_earliest_qualifying_reducer": True,
            "selected_prediction_exact_copy": True,
            "input_sha256": {
                "anchor": shared._file_sha256(anchor_file),
                "ledger": shared._file_sha256(ledger_file),
                "checkpoint": shared._file_sha256(checkpoint_file),
                "retrospective_input": shared._file_sha256(input_file),
                "assessment": shared._file_sha256(assessment_file),
            },
            "output_sha256": {PREFIX_SELECTOR_FILENAME: shared._file_sha256(selector_file)},
        },
        policy="deterministic_earliest_qualifying_prefix_row_else_exact_anchor_copy",
    )


def build_retrospective_assessment_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    retrospective_input_path: str | Path,
    assessment_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger = bundle[3:5]
    input_file, input_raw = shared._load_artifact(
        retrospective_input_path, role="retrospective JudgeView input"
    )
    _validate_retrospective_input(input_raw, case=case, location="retrospective_input")
    rows = _earlier_rows(ledger, anchor_step=anchor["predicted_step"])
    output = Path(assessment_path).expanduser().resolve()
    shared._assert_safe_path(output, role="retrospective assessment output", is_output=True)
    audit = output.parent / RETROSPECTIVE_ASSESSMENT_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_60_clean_v3p20_retrospective_prefix_ledger_closure",
            "--compact-validate",
            "retrospective-assessment",
            manifest,
            cohort,
            anchor_file,
            ledger_file,
            checkpoint_file,
            input_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    row_schema = {
        "classification": "critical_root | reasonable_probe | informative_different_probe | normal_tool_failure | recovered_defect | noncritical_predecessor | faithful_propagation | downstream_symptom | no_local_defect | uncertain",
        "predicted_module": "valid lowercase taxonomy module only when critical_root; otherwise null",
        "predicted_error_type": "valid lowercase taxonomy type only when critical_root; otherwise null",
        "evidence_quote": "literal bound-Step owner quote only when critical_root; otherwise null",
        "pre_step_observation": "literal task state available immediately before the bound row",
        "literal_defect_analysis": "specific local owner defect, or why none is established",
        "observed_outcome_effect": "actual same-Step output/feedback effect",
        "path_consumption_check": "whether and how the later observed path consumes this row",
        "recovery_check": "whether the issue is fully repaired before it matters",
        "candidate_only_repair_effect": "effect of repairing only this row with prior observations fixed",
        "qualifies_as_critical_boundary": "boolean; true iff classification is critical_root",
        "qualification_basis": "why all five gates pass, or the earliest gate that fails",
        "adjacent_owner_rejection": "why adjacent owners are propagation/noncritical, or why they do not displace this owner",
        "falsifier": "one concrete observation that would reverse this row assessment",
    }
    schema = {
        "anchor_assessment": "evidence-grounded status of the unchanged anchor after reviewing the complete timeline",
        "row_assessments": [row_schema],
        "chronology_summary": "compact comparison of all bound prefix rows and the anchor",
        "selection_falsifier": "strongest concrete argument against the resulting earliest-qualifying reduction",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_60_VERSION} semantic-only retrospective assessment.

{_boundary(manifest=manifest, cohort=cohort, reads=(input_file, anchor_file, ledger_file, checkpoint_file), output=output)}

{_RETROSPECTIVE_RULES}

The immutable anchor is Step {anchor['predicted_step']}. The ledger contains
exactly {len(rows)} strictly earlier rows. Read their Step numbers and original
lane verdicts from the permitted ledger and emit exactly {len(rows)} semantic
row assessments in that same order. Do not emit row index, Step, identity,
hash, original lane fields, candidate prediction, reducer decision, or final
prediction. If there are zero earlier rows, emit an empty row_assessments array.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _validate_aggregate(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(prediction_manifest_path, cohort_manifest_path)
    root = Path(predictions_path).expanduser().resolve().parent
    names = (
        ANCHOR_PREDICTIONS_FILENAME,
        ANCHOR_LEDGER_AGGREGATE_FILENAME,
        ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        RETROSPECTIVE_ASSESSMENTS_FILENAME,
        PREFIX_SELECTORS_FILENAME,
        INPUT_BINDINGS_FILENAME,
    )
    loaded = {
        name: shared._load_artifact(root / name, role=f"merged {name}")[1]
        for name in names
    }
    if any(not isinstance(value, list) or len(value) != len(cases) for value in loaded.values()):
        shared._fail("invalid_retrospective_aggregate_count", "all artifacts need all cases")
    finals = shared._load_artifact(predictions_path, role="merged predictions")[1]
    if not isinstance(finals, list) or len(finals) != len(cases):
        shared._fail("invalid_retrospective_prediction_count", "predictions need all cases")
    decisions: Counter[str] = Counter()
    classes: Counter[str] = Counter()
    earlier_counts: Counter[int] = Counter()
    qualifying_counts: Counter[int] = Counter()
    for index, case in enumerate(cases):
        location = f"retrospective_merged[{index}]"
        anchor = loaded[ANCHOR_PREDICTIONS_FILENAME][index]
        ledger = loaded[ANCHOR_LEDGER_AGGREGATE_FILENAME][index]
        checkpoint = loaded[ANCHOR_CHECKPOINT_AGGREGATE_FILENAME][index]
        semantic = loaded[RETROSPECTIVE_ASSESSMENTS_FILENAME][index]
        selector = loaded[PREFIX_SELECTORS_FILENAME][index]
        binding = loaded[INPUT_BINDINGS_FILENAME][index]
        shared._validate_prediction_record(anchor, case=case, location=f"{location}.anchor")
        if ledger.get("trajectory_id") != case.trajectory_id or checkpoint.get("trajectory_id") != case.trajectory_id:
            shared._fail("retrospective_anchor_sidecar_mismatch", location)
        retrospective_input = build_retrospective_input_document(case)
        rows = _earlier_rows(ledger, anchor_step=anchor["predicted_step"])
        _validate_semantic_assessment_record(
            semantic, case=case, earlier_rows=rows, location=f"{location}.semantic"
        )
        _validate_input_binding(
            binding,
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            location=f"{location}.input_binding",
        )
        _validate_prefix_selector_record(
            selector,
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            retrospective_input=retrospective_input,
            semantic_assessment=semantic,
            location=f"{location}.selector",
        )
        expected = build_prefix_selector_document(
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            retrospective_input=retrospective_input,
            semantic_assessment=semantic,
        )
        if selector != expected:
            shared._fail("non_deterministic_prefix_selector_aggregate", location)
        final = shared._validate_prediction_record(
            finals[index], case=case, location=f"{location}.final"
        )
        if final != selector["selected_prediction"]:
            shared._fail("retrospective_final_copy_mismatch", location)
        decisions[selector["decision"]] += 1
        earlier_counts[len(rows)] += 1
        q = sum(row["qualifies_as_critical_boundary"] for row in selector["row_assessments"])
        qualifying_counts[q] += 1
        for row in selector["row_assessments"]:
            classes[row["classification"]] += 1
    return {
        "required": True,
        "valid": True,
        "unchanged_v3_20_anchor": True,
        "sparse_candidates_only_from_fresh_v3_20_ledger": True,
        "complete_earlier_row_coverage": True,
        "semantic_only_model_output": True,
        "deterministic_identity_hash_step_prediction_assembly": True,
        "deterministic_earliest_qualifying_reducer": True,
        "module_type_not_used_for_ranking": True,
        "all_selected_predictions_exact_copies": True,
        "selector_decision_counts": dict(sorted(decisions.items())),
        "classification_counts": dict(sorted(classes.items())),
        "earlier_row_count_distribution": {
            str(key): value for key, value in sorted(earlier_counts.items())
        },
        "qualifying_row_count_distribution": {
            str(key): value for key, value in sorted(qualifying_counts.items())
        },
        "packet_state_closure": parent._validate_packet_state_ledgers(
            root / ANCHOR_LEDGER_AGGREGATE_FILENAME
        ),
    }


def validate_agent_judge_luna_gaia_v3_60_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    mechanism = _validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_60_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_60_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_60_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_60_REASONING_EFFORT,
        "selection_policy": "clean_v3_20_complete_retrospective_prefix_ledger_closure_earliest_qualifying_else_anchor",
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "retrospective closure over every pre-anchor row in the unchanged v3.20 sparse ledger",
        "anchor_semantics_unchanged_from_v3_20": True,
        "all_selected_predictions_exact_copies": True,
        "retrospective_prefix_ledger_closure": mechanism,
    }


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_retrospective_input_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_retrospective_input(*paths[:-1]), paths[-1])


def validate_and_write_retrospective_assessment_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_retrospective_assessment(*paths[:-1]), paths[-1])


def validate_and_write_prefix_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_prefix_selector(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_60_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_60_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_luna_gaia_v3_60_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_retrospective_assessment_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / RETROSPECTIVE_INPUT_FILENAME,
        prediction.parent / RETROSPECTIVE_ASSESSMENT_FILENAME,
    )


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "retrospective-input" and len(paths) == 4:
            audit = validate_and_write_retrospective_input_audit(*paths)
        elif stage == "retrospective-assessment" and len(paths) == 8:
            audit = validate_and_write_retrospective_assessment_audit(*paths)
        elif stage == "prefix-selector" and len(paths) == 9:
            audit = validate_and_write_prefix_selector_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_60_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except (shared.AgentJudgeValidationError, json.JSONDecodeError, OSError) as error:
        code = getattr(error, "code", type(error).__name__)
        print(json.dumps({"ok": False, "code": code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument(
        "stage",
        choices=(
            "anchor",
            "retrospective-input",
            "retrospective-assessment",
            "prefix-selector",
            "prediction",
        ),
    )
    parser.add_argument("paths", nargs="+")
    args = parser.parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

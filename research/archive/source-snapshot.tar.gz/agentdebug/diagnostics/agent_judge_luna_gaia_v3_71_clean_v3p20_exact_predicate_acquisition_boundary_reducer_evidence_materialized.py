"""Luna GAIA v3.71: exact-predicate reducer with literal evidence materialization."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from . import (
    agent_judge_luna_gaia_v3_70_clean_v3p20_exact_predicate_acquisition_boundary_reducer_owner_explicit
    as migrated,
)
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions
from .taxonomy import AgentModule, ErrorType


AGENT_JUDGE_LUNA_GAIA_V3_71_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.71-clean-v3.20-"
    "exact-predicate-acquisition-boundary-reducer-evidence-materialized"
)
AGENT_JUDGE_LUNA_GAIA_V3_71_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_71_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_71_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_71_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_71_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_71_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_71_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_71_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_71_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_71_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_71_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_71_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_71_AUDIT_SCHEMA_VERSION
)

shared = migrated.shared
mechanism = migrated.mechanism
ANCHOR_PREDICTIONS_FILENAME = migrated.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = migrated.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = migrated.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = migrated.PREDICTION_AUDIT_FILENAME
PANEL_FILENAME = migrated.PANEL_FILENAME
PANELS_FILENAME = migrated.PANELS_FILENAME
PANEL_AUDIT_FILENAME = migrated.PANEL_AUDIT_FILENAME
SELECTOR_FILENAME = migrated.SELECTOR_FILENAME
SELECTORS_FILENAME = migrated.SELECTORS_FILENAME
SELECTOR_AUDIT_FILENAME = migrated.SELECTOR_AUDIT_FILENAME
INFERENCE_DOCUMENT_FILENAME = migrated.INFERENCE_DOCUMENT_FILENAME


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_71_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_71_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_71_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one exact-predicate acquisition boundary reducer",
        "invalid_agent_evidence_exact_copy_materialization": True,
    }


build_inference_document = migrated.build_inference_document
anchor_response_schema = migrated.anchor_response_schema
reducer_response_schema = migrated.reducer_response_schema
normalize_assessment_response = migrated.normalize_assessment_response
build_selection_document = migrated.build_selection_document


def validate_inference_document(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        migrated.validate_inference_document(*paths),
        policy="deterministic_gold_free_owner_explicit_inference_document",
    )


def _retag_task(task: str) -> str:
    return task.replace(
        migrated.AGENT_JUDGE_LUNA_GAIA_V3_70_VERSION,
        AGENT_JUDGE_LUNA_GAIA_V3_71_VERSION,
    )


def build_anchor_file_task(*paths: str | Path) -> str:
    return _retag_task(migrated.build_anchor_file_task(*paths))


def build_reducer_file_task(*paths: str | Path) -> str:
    return _retag_task(migrated.build_reducer_file_task(*paths))


def _bounded_literal(sources: tuple[str, ...]) -> str | None:
    for source in sources:
        literal = source.strip()
        if literal:
            return literal[:900]
    return None


def normalize_anchor_response(response: Any, *, case: Any) -> Any:
    """Repair evidence only; never change the model-selected semantic fields."""

    value = migrated.normalize_anchor_response(response, case=case)
    if not isinstance(value, dict):
        return value
    predictions = value.get("anchor_predictions")
    if not isinstance(predictions, list) or len(predictions) != 1:
        return value
    prediction = predictions[0]
    if not isinstance(prediction, dict):
        return value
    try:
        step = prediction["predicted_step"]
        module = AgentModule(prediction["predicted_module"])
        error_type = ErrorType(prediction["predicted_error_type"])
    except (KeyError, TypeError, ValueError):
        return value
    # System evidence is not necessarily packet text and is left to the model/validator.
    if module is AgentModule.SYSTEM:
        return value
    sources = shared._luna_gaia_v2_owner_source_resolver(
        case.judge_view, step, module, error_type
    )
    quote = prediction.get("evidence_quote")
    if isinstance(quote, str) and any(quote in source for source in sources):
        return value
    replacement = _bounded_literal(sources)
    if replacement is None:
        return value
    prediction["evidence_quote"] = replacement
    ledger = value.get("step_candidates")
    if isinstance(ledger, dict) and isinstance(ledger.get("rows"), list):
        for row in ledger["rows"]:
            if isinstance(row, dict) and row.get("step") == step:
                row["evidence_quote"] = replacement
                break
    return value


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        migrated.validate_anchor_predictions(*paths),
        policy="unchanged_v3_20_anchor_owner_explicit_evidence_materialized",
    )


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_assessment(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        migrated.validate_assessment(*paths),
        policy="one_exact_predicate_acquisition_boundary_assessment_owner_explicit",
    )


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_assessment(*paths[:-1]), paths[-1])


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    audit = mechanism.validate_selector(*paths[:-1])
    return shared._write_audit(
        _retag(audit, policy="deterministic_exact_predicate_candidate_else_anchor"),
        paths[-1],
    )


def validate_agent_judge_luna_gaia_v3_71_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    factorized = mechanism._validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return _retag(
        {
            **audit,
            "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_71_AUDIT_SCHEMA_VERSION,
            "anchor_semantics_unchanged_from_v3_20": True,
            "owner_explicit_response_only_runtime_required": True,
            "all_selected_predictions_exact_copies": True,
            "factorized_specialist_panel": factorized,
        },
        policy="clean_v3_20_exact_predicate_acquisition_boundary_reducer",
    )


def validate_and_write_agent_judge_luna_gaia_v3_71_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(
        validate_agent_judge_luna_gaia_v3_71_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_luna_gaia_v3_71_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_reducer_file_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
    )


validate_and_write_agent_judge_luna_gaia_v3_67_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_71_audit
)
validate_and_write_agent_judge_luna_gaia_v3_37_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_71_audit
)
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_luna_gaia_v3_71_task
build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_71_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_71_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_71_audit
)

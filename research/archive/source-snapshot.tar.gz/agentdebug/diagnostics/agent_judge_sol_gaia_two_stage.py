"""Gold-free GAIA candidate-proposer → root-arbiter Agent Judge."""

from __future__ import annotations

import hashlib
import json
import os
import shlex
from pathlib import Path
from typing import Any, Mapping

from agentdebug.benchmark.prediction_manifest import load_prediction_manifest

from .agent_judge import (
    AgentJudgeValidationError,
    _assert_gold_free,
    _assert_safe_path,
    _file_sha256,
    _load_json,
)
from .agent_judge_v2_4 import (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION,
    _v2_4_owner_source_resolver,
    validate_agent_judge_v2_4_predictions,
)
from .taxonomy import AgentModule, ErrorType, is_valid_classification, taxonomy_prompt


AGENT_JUDGE_SOL_GAIA_TWO_STAGE_VERSION = (
    "agentdebug.codex-agent-judge.sol-gaia-two-stage-v1"
)
AGENT_JUDGE_SOL_GAIA_TWO_STAGE_MODEL = "gpt-5.6-sol"
AGENT_JUDGE_SOL_GAIA_TWO_STAGE_REASONING_EFFORT = "high"
AGENT_JUDGE_SOL_GAIA_TWO_STAGE_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)
CANDIDATE_PROPOSALS_FILENAME = "candidate-proposals.json"
CANDIDATE_AUDIT_FILENAME = "candidate-proposals-audit.json"

_CASE_FIELDS = {
    "trajectory_id",
    "trajectory_sha256",
    "status",
    "candidates",
}
_CANDIDATE_FIELDS = {
    "step",
    "module",
    "error_type",
    "evidence_quote",
    "local_defect",
    "causal_relevance",
    "recovery",
}
_RECOVERY_VALUES = {"none", "partial", "complete"}


def _fail(code: str, message: str) -> None:
    raise AgentJudgeValidationError(code, message)


def _cohort_ids(path: Path) -> list[str]:
    value = _load_json(path, role="cohort manifest")
    if not isinstance(value, Mapping):
        _fail("invalid_candidate_cohort", "cohort manifest must be an object")
    ids = value.get("trajectory_ids")
    if (
        not isinstance(ids, list)
        or not ids
        or any(not isinstance(item, str) or not item for item in ids)
        or len(set(ids)) != len(ids)
    ):
        _fail("invalid_candidate_cohort", "cohort trajectory IDs are invalid")
    return ids


def validate_sol_gaia_candidate_proposals(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposals_path: str | Path,
    *,
    allow_empty: bool = False,
) -> dict[str, Any]:
    """Validate identity, taxonomy and literal owner evidence for all cards."""

    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    proposals = Path(proposals_path).expanduser().resolve()
    for role, path in (
        ("prediction manifest", prediction),
        ("cohort manifest", cohort),
        ("candidate proposals", proposals),
    ):
        _assert_safe_path(path, role=role)
    _manifest, cases = load_prediction_manifest(prediction)
    cohort_ids = _cohort_ids(cohort)
    if cohort_ids != [case.trajectory_id for case in cases]:
        _fail("candidate_cohort_mismatch", "manifest and cohort order differ")
    value = _load_json(proposals, role="candidate proposals")
    _assert_gold_free(value, location="candidate proposals")
    if not isinstance(value, list) or len(value) != len(cases):
        _fail("candidate_cardinality_mismatch", "one proposal row per case required")

    total = 0
    per_case: list[int] = []
    for index, (row, case) in enumerate(zip(value, cases, strict=True)):
        if not isinstance(row, Mapping) or set(row) != _CASE_FIELDS:
            _fail("invalid_candidate_case_fields", f"case {index} fields are invalid")
        if (
            row["trajectory_id"] != case.trajectory_id
            or row["trajectory_sha256"] != case.trajectory_sha256
            or row["status"] != "success"
        ):
            _fail("candidate_identity_mismatch", f"case {index} identity is invalid")
        candidates = row["candidates"]
        if (
            not isinstance(candidates, list)
            or (not allow_empty and not candidates)
            or len(candidates) > 100
        ):
            _fail("invalid_candidate_count", f"case {index} candidate count is invalid")
        seen: set[tuple[int, str, str]] = set()
        previous: tuple[int, int, int] | None = None
        for card_index, card in enumerate(candidates):
            if not isinstance(card, Mapping) or set(card) != _CANDIDATE_FIELDS:
                _fail(
                    "invalid_candidate_fields",
                    f"case {index} candidate {card_index} fields are invalid",
                )
            step = card["step"]
            if isinstance(step, bool) or not isinstance(step, int) or not 1 <= step <= len(case.judge_view.steps):
                _fail("candidate_step_out_of_range", f"case {index} candidate step is invalid")
            try:
                module = AgentModule(card["module"])
                error_type = ErrorType(card["error_type"])
            except (TypeError, ValueError) as error:
                raise AgentJudgeValidationError(
                    "invalid_candidate_taxonomy", f"case {index} taxonomy is invalid"
                ) from error
            if not is_valid_classification(module, error_type):
                _fail("invalid_candidate_pair", f"case {index} taxonomy pair is invalid")
            key = (step, module.value, error_type.value)
            if key in seen:
                _fail("duplicate_candidate", f"case {index} repeats candidate {key}")
            seen.add(key)
            order = (step, list(AgentModule).index(module), list(ErrorType).index(error_type))
            if previous is not None and order < previous:
                _fail("candidate_order_mismatch", f"case {index} candidates are not chronological")
            previous = order
            for field in ("evidence_quote", "local_defect", "causal_relevance"):
                if not isinstance(card[field], str) or not card[field].strip():
                    _fail("empty_candidate_text", f"case {index} {field} is empty")
            if card["recovery"] not in _RECOVERY_VALUES:
                _fail("invalid_candidate_recovery", f"case {index} recovery is invalid")
            sources = _v2_4_owner_source_resolver(
                case.judge_view, step, module, error_type
            )
            if not any(card["evidence_quote"] in source for source in sources):
                _fail(
                    "candidate_evidence_not_found",
                    f"case {index} candidate {card_index} evidence is outside its owner source",
                )
        total += len(candidates)
        per_case.append(len(candidates))

    return {
        "schema_version": AGENT_JUDGE_SOL_GAIA_TWO_STAGE_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_SOL_GAIA_TWO_STAGE_VERSION,
        "stage": "candidate-proposer",
        "model": AGENT_JUDGE_SOL_GAIA_TWO_STAGE_MODEL,
        "reasoning_effort": AGENT_JUDGE_SOL_GAIA_TWO_STAGE_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": len(cases),
        "candidate_count": total,
        "candidate_count_per_case": per_case,
        "empty_candidate_rows_allowed": allow_empty,
        "all_candidates_taxonomy_valid": True,
        "all_candidate_evidence_owner_valid": True,
        "opaque_trajectory_id_policy": True,
        "output_sha256": {proposals.name: _file_sha256(proposals)},
    }


def _write_audit(path: str | Path, value: Mapping[str, Any]) -> dict[str, Any]:
    target = Path(path).expanduser().resolve()
    _assert_safe_path(target, role="audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    temporary.replace(target)
    return dict(value)


def validate_and_write_sol_gaia_candidate_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposals_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        audit_path,
        validate_sol_gaia_candidate_proposals(
            prediction_manifest_path, cohort_manifest_path, proposals_path
        ),
    )


def validate_sol_gaia_two_stage_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    """Validate final roots and prove each is an exact frozen proposal card."""

    predictions = Path(predictions_path).expanduser().resolve()
    proposals = predictions.parent / CANDIDATE_PROPOSALS_FILENAME
    candidate_audit = validate_sol_gaia_candidate_proposals(
        prediction_manifest_path, cohort_manifest_path, proposals
    )
    base = validate_agent_judge_v2_4_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions
    )
    proposal_rows = _load_json(proposals, role="candidate proposals")
    final_rows = _load_json(predictions, role="final predictions")
    for index, (proposal_row, final) in enumerate(
        zip(proposal_rows, final_rows, strict=True)
    ):
        selected = (
            final["predicted_step"],
            final["predicted_module"],
            final["predicted_error_type"],
            final["evidence_quote"],
        )
        available = {
            (card["step"], card["module"], card["error_type"], card["evidence_quote"])
            for card in proposal_row["candidates"]
        }
        if selected not in available:
            _fail("final_not_frozen_candidate", f"case {index} final root was not proposed")
    return {
        **base,
        "schema_version": AGENT_JUDGE_SOL_GAIA_TWO_STAGE_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_SOL_GAIA_TWO_STAGE_VERSION,
        "model": AGENT_JUDGE_SOL_GAIA_TWO_STAGE_MODEL,
        "reasoning_effort": AGENT_JUDGE_SOL_GAIA_TWO_STAGE_REASONING_EFFORT,
        "stage": "root-arbiter",
        "candidate_count": candidate_audit["candidate_count"],
        "candidate_proposals_sha256": _file_sha256(proposals),
        "all_finals_exact_frozen_candidates": True,
    }


def validate_and_write_sol_gaia_two_stage_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        audit_path,
        validate_sol_gaia_two_stage_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
    )


def _validator_command(function: str, *paths: Path) -> str:
    code = (
        "import json; from agentdebug.diagnostics.agent_judge_sol_gaia_two_stage "
        f"import {function} as run; print(json.dumps(run("
        + ", ".join(repr(str(path)) for path in paths)
        + "), ensure_ascii=False, indent=2))"
    )
    return "PYTHONPATH=. python3 -c " + shlex.quote(code)


def build_sol_gaia_candidate_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposals_path: str | Path,
) -> str:
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    proposals = Path(proposals_path).expanduser().resolve()
    audit = proposals.parent / CANDIDATE_AUDIT_FILENAME
    for role, path, output in (
        ("prediction manifest", prediction, False),
        ("cohort manifest", cohort, False),
        ("candidate proposals", proposals, True),
        ("candidate audit", audit, True),
    ):
        _assert_safe_path(path, role=role, is_output=output)
    schema = {
        "trajectory_id": "exact opaque join token",
        "trajectory_sha256": "exact manifest SHA-256",
        "status": "success",
        "candidates": [
            {
                "step": "positive integer",
                "module": "taxonomy module",
                "error_type": "legal type for module",
                "evidence_quote": "exact owner-source substring",
                "local_defect": "what this source newly gets wrong",
                "causal_relevance": "prospective propagation or correction effect",
                "recovery": "none | partial | complete",
            }
        ],
    }
    command = _validator_command(
        "validate_and_write_sol_gaia_candidate_audit",
        prediction,
        cohort,
        proposals,
        audit,
    )
    return f"""\
Run {AGENT_JUDGE_SOL_GAIA_TWO_STAGE_VERSION}, stage 1: CANDIDATE PROPOSER.

CONFIG: model={AGENT_JUDGE_SOL_GAIA_TWO_STAGE_MODEL}; reasoning_effort={AGENT_JUDGE_SOL_GAIA_TWO_STAGE_REASONING_EFFORT}; network/API/gold/scoring access forbidden.
Read only {prediction}, {cohort}, this protocol source, and taxonomy.py.
The trajectory_id is an opaque join token. Never infer a module, type, step,
or answer from characters in the ID. Use only the JudgeView timeline.

Inspect every printed step against every module. Return a high-recall, sparse,
UNRANKED census of all directly evidenced local NEW defects. Do not select a
winner and do not omit a candidate because another candidate seems more
critical. Candidate order is mechanical: increasing step, then taxonomy module
order, then taxonomy type order; it carries no priority.

Use only information available when the source was written to establish local
error. Later events may establish propagation or recovery, but cannot turn a
reasonable first probe into a hindsight error. Retain fine-grained Memory
omissions/fabrications, Reflection result/progress misreads, Planning strategy
or constraint errors, concrete Action deviations/parameters/final emissions,
and provenance-backed final System boundaries. A downstream repetition or
final unsupported answer may be a candidate, but describe when it depends on
an earlier candidate. Mark recovery complete only when the useful state was
actually restored and used.

Evidence must be a non-empty exact substring owned by the candidate's step and
module under v2.4 evidence rules. System is admissible only at the final step
from execution_facts. Each (step,module,type) may appear once. Emit at least one
candidate and no more than 100.

TAXONOMY
{taxonomy_prompt()}

Write exactly one JSON array to {proposals}, with one object matching:
{json.dumps(schema, ensure_ascii=False, indent=2)}
No Markdown, ranking, confidence, winner, gold fields, or extra keys.

Then run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Fix only your current artifact until validation exits zero and writes {audit}.
"""


def build_sol_gaia_two_stage_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    output = Path(predictions_path).expanduser().resolve()
    proposals = output.parent / CANDIDATE_PROPOSALS_FILENAME
    audit = output.parent / "prediction-audit.json"
    for role, path, is_output in (
        ("prediction manifest", prediction, False),
        ("cohort manifest", cohort, False),
        ("candidate proposals", proposals, False),
        ("predictions", output, True),
        ("prediction audit", audit, True),
    ):
        _assert_safe_path(path, role=role, is_output=is_output)
    command = _validator_command(
        "validate_and_write_sol_gaia_two_stage_audit",
        prediction,
        cohort,
        output,
        audit,
    )
    schema = {
        "trajectory_id": "exact opaque join token",
        "trajectory_sha256": "exact manifest SHA-256",
        "status": "success",
        "predicted_step": "selected proposal step",
        "predicted_module": "selected proposal module",
        "predicted_error_type": "selected proposal type",
        "evidence_quote": "selected proposal evidence copied exactly",
        "root_cause": "concise causal root explanation",
        "causal_summary": "counterfactual, cascade, and recovery conclusion",
        "rejected_adjacent_owner": "strongest alternative and why it loses",
    }
    return f"""\
Run {AGENT_JUDGE_SOL_GAIA_TWO_STAGE_VERSION}, stage 2: FRESH ROOT ARBITER.

CONFIG: model={AGENT_JUDGE_SOL_GAIA_TWO_STAGE_MODEL}; reasoning_effort={AGENT_JUDGE_SOL_GAIA_TWO_STAGE_REASONING_EFFORT}; network/API/gold/scoring access forbidden.
Read only {prediction}, {cohort}, {proposals}, this protocol source, v2.4 source,
and taxonomy.py. The trajectory_id is an opaque join token and never evidence.

Independently reconstruct the complete JudgeView before reading the frozen,
unranked candidate cards. Cards are fallible local proposals, not votes. You
must select exactly one proposed (step,module,type,evidence) tuple; do not add,
rewrite, or repair a candidate.

Compare every proposal using this order:
1. Reject a card that is not locally defective using contemporaneous evidence.
2. Trace premise provenance and downstream dependence. A later repetition,
   parameter, final answer, or progress failure does not replace an earlier
   demonstrated root when it merely executes, exposes, or preserves that
   earlier card's still-unrepaired effect.
3. Test recovery. An earlier card loses only if the useful fact/state/branch
   was genuinely restored and used, or a later independent cause would still
   fail after correcting it. Mere re-observation or wording changes are not
   complete recovery.
4. Within the winning continuous causal chain, choose the earliest decisive
   divergence whose single correction plausibly redirects the task. Chronology
   is not enough: a broad first query, reasonable exploration, or first failed
   probe is normally not defective. A concrete constraint violation, false
   state claim, direct-result misread, plan/action contradiction, or unusable
   operation can be decisive immediately.
5. Preserve semantic ownership. Memory/Reflection own false premises they
   introduce; Planning owns a defective strategy faithfully executed; Action
   owns a concrete deviation or bad parameter when the plan was adequate;
   System owns a provenance-backed external failure of a reasonable action.
6. Use error type only after freezing step and owner. Do not choose a root
   because its type is vivid or easy to quote.

Write one ten-field JSON array to {output} matching exactly:
{json.dumps(schema, ensure_ascii=False, indent=2)}
All text fields non-empty; no extra fields. Copy selected step/module/type and
evidence exactly from one frozen card.

Then run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Fix only your current output until validation exits zero and writes {audit}.
"""


__all__ = [
    "AGENT_JUDGE_SOL_GAIA_TWO_STAGE_MODEL",
    "AGENT_JUDGE_SOL_GAIA_TWO_STAGE_REASONING_EFFORT",
    "AGENT_JUDGE_SOL_GAIA_TWO_STAGE_VERSION",
    "CANDIDATE_AUDIT_FILENAME",
    "CANDIDATE_PROPOSALS_FILENAME",
    "build_sol_gaia_candidate_task",
    "build_sol_gaia_two_stage_task",
    "validate_and_write_sol_gaia_candidate_audit",
    "validate_and_write_sol_gaia_two_stage_audit",
    "validate_sol_gaia_candidate_proposals",
    "validate_sol_gaia_two_stage_predictions",
]

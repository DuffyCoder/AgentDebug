"""Gold-isolated Codex Agent Judge v2.3 protocol.

V2.3 keeps v2.2's strict output/evidence/validation machinery, but replaces
the hard first-false-proposition selection rule with a critical-commitment
diagnostic procedure.
"""

from __future__ import annotations

import json
import os
import shlex
from pathlib import Path
from typing import Any

from .agent_judge import AGENT_JUDGE_PREDICTION_FIELDS, AgentJudgeValidationError
from .agent_judge_v2_1 import (
    AGENT_JUDGE_V2_1_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_V2_1_MODEL,
    AGENT_JUDGE_V2_1_REASONING_EFFORT,
    AGENT_JUDGE_V2_1_VERSION,
    build_agent_judge_v2_1_task,
)
from .agent_judge_v2_2 import _v2_2_owner_source_resolver
from .agent_judge import _validate_agent_judge_predictions_with_owner_sources


AGENT_JUDGE_V2_3_VERSION = "agentdebug.codex-agent-judge.v2.3"
AGENT_JUDGE_V2_3_MODEL = AGENT_JUDGE_V2_1_MODEL
AGENT_JUDGE_V2_3_REASONING_EFFORT = AGENT_JUDGE_V2_1_REASONING_EFFORT
AGENT_JUDGE_V2_3_AUDIT_SCHEMA_VERSION = AGENT_JUDGE_V2_1_AUDIT_SCHEMA_VERSION

_V2_1_PROTOCOL_HEADER = (
    "Run the frozen Codex Agent Judge protocol "
    f"{AGENT_JUDGE_V2_1_VERSION}."
)
_V2_3_PROTOCOL_HEADER = (
    "Run the frozen Codex Agent Judge protocol "
    f"{AGENT_JUDGE_V2_3_VERSION}."
)
_V2_1_MODULE_ALLOWLIST_ENTRY = "agentdebug/diagnostics/agent_judge_v2_1.py"
_V2_3_MODULE_ALLOWLIST_ENTRY = "agentdebug/diagnostics/agent_judge_v2_3.py"
_ALLOWLIST_TAIL = "- agentdebug/diagnostics/taxonomy.py\n"
_CONTRACT_MARKER = "\nSTRICT PREDICTION CONTRACT\n"
_V2_STAGE_I_CONFLICT = """2. Enumerate at most three directly evidenced defective owner outputs in
   chronological order.  For each, test maturity (the defect is already
   actionable at that output), causal sufficiency (correcting that output
   could avert the failed trajectory), and recovery (the same defect was not
   later fully repaired).  Select the earliest mature, causally sufficient,
   unrecovered output.  Freeze its predicted_step before considering module
   names or taxonomy types.  Do not move to a later concrete action merely
   because it makes an earlier reasoning defect more visible.

   RECOVERY IS A HARD VETO, not an explanatory preference.  Scan every later
   step.  Reject a candidate if later behavior re-establishes the relevant
   world/information state, successfully performs the equivalent corrected
   action, or resumes the same strategy after losing only that one turn.  A
   candidate survives only when its defective proposition or state continues
   to control the path toward failure.
"""
_V2_3_STAGE_I_REPLACEMENT = """2. Enumerate at most three directly evidenced defective owner outputs in
   chronological order.  For each, record maturity, causal effect, and
   recovery, then retain it as a candidate for the v2.3 critical-commitment
   comparison.  Do not freeze a chronological earliest candidate before
   comparing whether its single-point correction fundamentally changes the
   failed trajectory.
"""
_V2_1_PLANNING_CONFLICT = """If the plan faithfully propagates a false memory
or reflection, reject planning and select the first mature, causally
sufficient, unrecovered upstream owner.  If this check exposes an earlier
owner, discard the planning candidate, return to Stage I, and freeze that
earliest upstream step before the final step/owner decision."""
_V2_3_PLANNING_REPLACEMENT = """If the plan faithfully propagates a false memory
or reflection, reject planning and return the upstream candidate to the v2.3
criticality comparison.  Do not freeze an earlier upstream step merely for
being earlier; select it only if its unrepaired effect is more critical than
the competing commitment."""
_V2_ACTION_UPSTREAM_CONFLICT = """If memory or reflection supplies the false state that licenses a
   later plan, keep the earlier mature owner rather than blaming its symptom."""
_V2_3_ACTION_UPSTREAM_REPLACEMENT = """If memory or reflection supplies the false state that licenses a
   later plan, return that upstream candidate to the v2.3 criticality
   comparison rather than blaming its symptom."""
_V2_OWNER_PRIORITY_CONFLICT = """- Do not prefer the last failed output over an earlier mature unrecovered root."""
_V2_3_OWNER_PRIORITY_REPLACEMENT = """- Do not prefer either the first or last failed output by chronology alone; compare criticality."""
_V2_FINAL_ANSWER_CONFLICT = """- Before blaming a final answer, identify the earliest observable false fact,
  inference, or constraint omission that produces it.  The final answer can
  own the root only if upstream reasoning supports the correct content and
  the final emission independently changes, contradicts, or malforms it."""
_V2_3_FINAL_ANSWER_REPLACEMENT = """- Before blaming a final answer, identify the critical observable false fact,
  inference, constraint omission, or independently defective final emission
  that controls the failed trajectory.  The final answer can own the root only
  if upstream reasoning supports the correct content and the final emission
  independently changes, contradicts, or malforms it."""

_V2_3_DELTA = """
V2.3 CRITICAL COMMITMENT DIAGNOSTIC PROTOCOL

This is NOT a HARD FIRST-FALSE-PROPOSITION protocol.  Diagnose the single
critical commitment that best explains the failed trajectory, using only
locally demonstrated evidence available in the trace.  First enumerate:
1. every terminal or external boundary, including whether execution_facts
   provides provenance for a system boundary;
2. every earliest important locally demonstrated defect; and
3. every first mature, unrecovered branch commitment.

For each viable candidate, ask whether a single-point correction at that
candidate would most likely and fundamentally change the failure trajectory.
Prefer the candidate whose correction changes the path at its root, explains
the resulting cascade, and has not been superseded by an independently sufficient later cause.  An earlier defect is not automatically critical:
use earlier step only as a tie-break when criticality is genuinely comparable.
Do not select a reasonable exploration, a first result with no progress, a
hindsight-only better alternative, or a weak error with no downstream
dependency as critical.

MATURITY AND RECOVERY

A candidate becomes mature when the evidence already available makes
continuing that strategy unreasonable and the current output commits or
recommits to it.  Distinguish a first acquisition of a result, first reason to
suspect it, a reset that genuinely reopens the branch, and a post-reset lack
of progress followed by recommitment.  Do not call the first no-result action
mature merely because a later outcome was bad.

Maturity can arise from a then-available direct contradiction or a
post-feedback recommitment.  It can also arise when a specific or exhaustive
factual assertion is unsupported by then-available evidence, or when a
concrete tool, operation, or target is informationally incapable of producing
the task-required state or evidence.  These are general evidence tests, not
environment or case-specific rules.

Classify recovery as none, partial, or complete.  Complete recovery means the
missing requirement, evidence, or state was actually restored and the later
failure is independently caused; it will usually eliminate the earlier
candidate.  It is not an absolute veto: retain an earlier candidate if its
unrepaired consequences still control the failure trajectory.  Partial
recovery does not erase a candidate whose remaining defect drives the path.

SELECTION ORDER AFTER THE CRITICAL STEP

Select the critical step before selecting its owner.  At that same step, use
Memory -> Reflection -> Planning -> Action ownership order: choose the first
module that introduces the critical commitment, rather than a downstream
module that merely carries it out.  Retain the existing PLANNING ADMISSION
GATE and ACTION ADMISSION GATE; action may own only when supported upstream
modules supplied a sufficient feasible commitment and the concrete emission
newly deviated, was unavailable, or malformed.  System may own only a final,
provenance-backed external boundary in execution_facts; failure alone is not
system evidence.

For action admission, the adequate plan must be at the same step as the
terminal action.  An earlier-turn plan cannot license a terminal action; audit
the current same-step plan and action together.

V2.3 MALFORMED-ACTION EVIDENCE RULE

Retain the v2.2 narrow malformed-action evidence exception.  Only for
action/format_error or action/invalid_action, copy a malformed concrete
emission from one exact contiguous residual segment of assistant_raw_output
outside all recognized module spans at the selected step.  It does not apply
to any other module or error type, and the quote must not cross a module span
or use current_input, feedback, observations, tool results, or another step.

Never hard-code by environment, trajectory/case ID, benchmark split, or any
other dataset identity.  Do not use distribution targets to choose a result.
"""


def _validator_command(
    prediction_path: Path, cohort_path: Path, output_path: Path, audit_path: Path
) -> str:
    code = (
        "import json; "
        "from agentdebug.diagnostics.agent_judge_v2_3 import "
        "validate_and_write_agent_judge_v2_3_audit as run; "
        "print(json.dumps(run("
        f"{str(prediction_path)!r}, {str(cohort_path)!r}, "
        f"{str(output_path)!r}, {str(audit_path)!r}"
        "), ensure_ascii=False, indent=2))"
    )
    return "PYTHONPATH=. python3 -c " + shlex.quote(code)


def build_agent_judge_v2_3_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build the stable v2.1 contract with v2.3 diagnostic semantics."""

    prediction_path = Path(prediction_manifest_path).expanduser().resolve()
    cohort_path = Path(cohort_manifest_path).expanduser().resolve()
    output_path = Path(predictions_path).expanduser().resolve()
    audit_path = output_path.parent / "prediction-audit.json"
    repository_root = Path(__file__).resolve().parents[2]
    task = build_agent_judge_v2_1_task(prediction_path, cohort_path, output_path)
    if task.count(_V2_1_PROTOCOL_HEADER) != 1:
        raise RuntimeError("Agent Judge v2.1 protocol header changed unexpectedly")
    if task.count(_V2_1_MODULE_ALLOWLIST_ENTRY) != 1:
        raise RuntimeError("Agent Judge v2.1 read allowlist changed unexpectedly")
    if task.count(_ALLOWLIST_TAIL) != 1 or task.count(_CONTRACT_MARKER) != 1:
        raise RuntimeError("Agent Judge v2.1 task structure changed unexpectedly")
    if task.count(_V2_STAGE_I_CONFLICT) != 1:
        raise RuntimeError("Agent Judge v2 Stage I conflict changed unexpectedly")
    if task.count(_V2_1_PLANNING_CONFLICT) != 1:
        raise RuntimeError("Agent Judge v2.1 planning conflict changed unexpectedly")
    if task.count(_V2_ACTION_UPSTREAM_CONFLICT) != 1:
        raise RuntimeError("Agent Judge v2 action conflict changed unexpectedly")
    if task.count(_V2_OWNER_PRIORITY_CONFLICT) != 1:
        raise RuntimeError("Agent Judge v2 owner-priority conflict changed unexpectedly")
    if task.count(_V2_FINAL_ANSWER_CONFLICT) != 1:
        raise RuntimeError("Agent Judge v2 final-answer conflict changed unexpectedly")
    task = task.replace(_V2_1_PROTOCOL_HEADER, _V2_3_PROTOCOL_HEADER, 1)
    task = task.replace(
        _V2_1_MODULE_ALLOWLIST_ENTRY, _V2_3_MODULE_ALLOWLIST_ENTRY, 1
    )
    task = task.replace(_V2_STAGE_I_CONFLICT, _V2_3_STAGE_I_REPLACEMENT, 1)
    task = task.replace(
        _V2_1_PLANNING_CONFLICT, _V2_3_PLANNING_REPLACEMENT, 1
    )
    task = task.replace(
        _V2_ACTION_UPSTREAM_CONFLICT, _V2_3_ACTION_UPSTREAM_REPLACEMENT, 1
    )
    task = task.replace(
        _V2_OWNER_PRIORITY_CONFLICT, _V2_3_OWNER_PRIORITY_REPLACEMENT, 1
    )
    task = task.replace(
        _V2_FINAL_ANSWER_CONFLICT, _V2_3_FINAL_ANSWER_REPLACEMENT, 1
    )
    task = task.replace(
        _ALLOWLIST_TAIL,
        _ALLOWLIST_TAIL
        + f"- {output_path} only after you write this run's complete predictions\n"
        + f"- {audit_path} only after the local validator creates it\n",
        1,
    )
    task = task.replace(
        _CONTRACT_MARKER, f"\n{_V2_3_DELTA.strip()}\n{_CONTRACT_MARKER}", 1
    )
    return task + f"""

V2.3 MANDATORY LOCAL VALIDATION LOOP — DO NOT STOP AFTER WRITING

First write the complete predictions JSON array for every cohort case to the
fixed output path above.  Then actually run these exact local shell commands:

cd {shlex.quote(str(repository_root))}
{_validator_command(prediction_path, cohort_path, output_path, audit_path)}

The task is complete only when that command exits zero and writes the audit to
{audit_path}.  If validation fails, inspect only the validator error, your own
{output_path}, and the allowlisted prediction/cohort manifests or v2.3
protocol/taxonomy source.  Correct your own complete output and rerun the same
command until it passes.  Do not inspect any other prediction, score, gold,
metric, case study, evaluator annotation, directory listing, git history, or
external resource.  Do not call any external API or network service during
generation, correction, or validation.
"""


def validate_agent_judge_v2_3_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    """Use v2.2's evidence resolver while binding audit metadata to v2.3."""

    audit = _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_v2_2_owner_source_resolver,
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_V2_3_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_V2_3_VERSION,
        "model": AGENT_JUDGE_V2_3_MODEL,
        "reasoning_effort": AGENT_JUDGE_V2_3_REASONING_EFFORT,
    }


def validate_and_write_agent_judge_v2_3_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    """Validate and atomically persist a v2.3 audit only after success."""

    audit = validate_agent_judge_v2_3_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    target = Path(audit_path).expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


__all__ = [
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AGENT_JUDGE_V2_3_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_V2_3_MODEL",
    "AGENT_JUDGE_V2_3_REASONING_EFFORT",
    "AGENT_JUDGE_V2_3_VERSION",
    "AgentJudgeValidationError",
    "build_agent_judge_v2_3_task",
    "validate_and_write_agent_judge_v2_3_audit",
    "validate_agent_judge_v2_3_predictions",
]

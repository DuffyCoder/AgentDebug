"""Validation policy for the pre-frozen causal-boundary GAIA judge."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge import _validate_agent_judge_predictions_with_owner_sources
from .agent_judge_gaia_official_repo_gpt41_serial_v4 import serial_owner_sources


VERSION = "agentdebug.llm-judge.gaia-official-repo-gpt4.1-causal-v10"
MODEL = "gpt-4.1"
TEMPERATURE = 0.0
REASONING_EFFORT = "not_applicable"


def build_protocol_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    return f"""Pre-frozen causal-boundary GAIA diagnostic judge.

Protocol: {VERSION}
Model: {MODEL}
Expected provider-resolved model: gpt-4.1-2025-04-14
Temperature: {TEMPERATURE}
Prediction manifest: {Path(prediction_manifest_path).expanduser().resolve()}
Cohort manifest: {Path(cohort_manifest_path).expanduser().resolve()}
Predictions: {Path(predictions_path).expanduser().resolve()}

Three independent hypothesis scouts nominate state, acquisition, and typed
recommitment suspects. Recommitment uses variable-length candidates with strict
episode-specific prior arity; it has no null placeholders. The runner also adds
the earliest mechanically verified third exact action/result recurrence, a
terminal candidate, and any causally guarded provider-failure candidate. A fresh
coverage challenger adds up to three missing steps. An exhaustive assessor
analyzes every candidate without selecting one; a separate selector ranks them.
A final fresh bounded temporal-owner judge reviews the selector top three plus a
terminal candidate when needed, and selects an explicit candidate step. Each
window contains only that step's own spans and causal observations, never the
next step's output. It must bind the defect to the step that emitted the
plan/action, interpreted the preceding observation, produced a guarded system
outcome, or made the terminal commitment. The runner derives all evidence hashes
and opaque handoffs; the model never copies evidence IDs. Module and type receive
module-conditioned causal windows that prevent post-action evidence from leaking
backward into state or planning classification. Every assessor-added alternate
owner is accompanied by its referral analysis. Required text is type-strict, and
one unique guarded provider exception has structural root priority through both
selector stages.
"""


def validate_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    base = _validate_agent_judge_predictions_with_owner_sources(
        Path(prediction_manifest_path).expanduser().resolve(),
        Path(cohort_manifest_path).expanduser().resolve(),
        Path(predictions_path).expanduser().resolve(),
        owner_source_resolver=serial_owner_sources,
    )
    return {
        **base,
        "agent_judge_version": VERSION,
        "model": MODEL,
        "reasoning_effort": REASONING_EFFORT,
        "temperature": TEMPERATURE,
        "stage": (
            "three-scouts-deterministic-recurrence-top3-coverage-exhaustive-"
            "assessor-root-error-selector-bounded-temporal-owner"
        ),
        "model_copies_evidence_ids": False,
        "opaque_hash_ordered_candidate_ids": True,
        "assessor_alternate_owner_candidates_may_be_added_before_selector": True,
        "assessor_selects_winner": False,
        "selector_ranks_all_candidates": True,
        "temporal_owner_reviews_selector_top3_plus_terminal": True,
        "temporal_owner_selects_explicit_candidate_step": True,
        "temporal_owner_excludes_next_agent_output": True,
        "deterministic_exact_recurrence_candidate": True,
        "deterministic_exact_recurrence_kept_in_selector_top3": True,
        "temporal_owner_receives_no_selector_rationale": True,
        "typed_recommitment_episodes": True,
        "strict_required_text_types": True,
        "null_recommitment_placeholders_forbidden": True,
        "typed_recommitment_prior_arity": True,
        "unique_guarded_system_candidate_has_root_priority": True,
        "module_conditioned_causal_handoffs": True,
        "hard_system_owner_policy": "causally-guarded-first-provider-failure",
        "strict_intermediate_lineage_audit": True,
        "stage_provenance_audit": True,
        "implementation_frozen_before_inference": True,
        "external_llm_api": True,
    }


build_task = build_protocol_task

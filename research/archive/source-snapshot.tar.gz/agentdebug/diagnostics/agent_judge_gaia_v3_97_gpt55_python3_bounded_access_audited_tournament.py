"""GAIA v3.97: clean-v3.83 tournament with host-valid bounded inspection."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge_gaia_v3_96_gpt55_normalized_access_audited_tournament import *  # noqa: F403
from . import agent_judge_gaia_v3_83_clean_v3p20_model_only_gpt55_medium as incumbent
from . import (
    agent_judge_gaia_v3_96_gpt55_normalized_access_audited_tournament as template,
)


AGENT_JUDGE_GAIA_V3_97_VERSION = (
    "agentdebug.codex-agent-judge.gaia-v3.97-gpt55-python3-bounded-access-"
    "audited-predicate-handoff-tournament"
)
AGENT_JUDGE_GAIA_V3_97_MODEL = incumbent.AGENT_JUDGE_GAIA_V3_83_MODEL
AGENT_JUDGE_GAIA_V3_97_REASONING_EFFORT = incumbent.AGENT_JUDGE_GAIA_V3_83_REASONING_EFFORT
AGENT_JUDGE_GAIA_V3_97_AUDIT_SCHEMA_VERSION = incumbent.AGENT_JUDGE_GAIA_V3_83_AUDIT_SCHEMA_VERSION
SEMANTIC_PARENT = incumbent.AGENT_JUDGE_GAIA_V3_83_VERSION

AGENT_JUDGE_GAIA_V3_96_VERSION = AGENT_JUDGE_GAIA_V3_97_VERSION
AGENT_JUDGE_GAIA_V3_96_MODEL = AGENT_JUDGE_GAIA_V3_97_MODEL
AGENT_JUDGE_GAIA_V3_96_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_97_REASONING_EFFORT
AGENT_JUDGE_GAIA_V3_95_VERSION = AGENT_JUDGE_GAIA_V3_97_VERSION
AGENT_JUDGE_GAIA_V3_95_MODEL = AGENT_JUDGE_GAIA_V3_97_MODEL
AGENT_JUDGE_GAIA_V3_95_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_97_REASONING_EFFORT
AGENT_JUDGE_GAIA_V3_93_VERSION = AGENT_JUDGE_GAIA_V3_97_VERSION
AGENT_JUDGE_GAIA_V3_93_MODEL = AGENT_JUDGE_GAIA_V3_97_MODEL
AGENT_JUDGE_GAIA_V3_93_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_97_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION = AGENT_JUDGE_GAIA_V3_97_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_80_MODEL = AGENT_JUDGE_GAIA_V3_97_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_80_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_97_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_79_VERSION = AGENT_JUDGE_GAIA_V3_97_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_79_MODEL = AGENT_JUDGE_GAIA_V3_97_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_79_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_97_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION = AGENT_JUDGE_GAIA_V3_97_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL = AGENT_JUDGE_GAIA_V3_97_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_97_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_GAIA_V3_97_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_GAIA_V3_97_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_97_REASONING_EFFORT


def _python3_bounded_task(task: str) -> str:
    value = task.replace(template.AGENT_JUDGE_GAIA_V3_96_VERSION, AGENT_JUDGE_GAIA_V3_97_VERSION)
    value = value.replace("python inspect_case.py", "python3 inspect_case.py")
    whole_step = "- `python3 inspect_case.py step N`\n"
    if value.count(whole_step) != 1:
        raise RuntimeError("whole-Step inspector command marker changed unexpectedly")
    value = value.replace(whole_step, "", 1)
    value = value.replace(
        "Exact Step/owner/feedback reads are\nadditional;",
        "Exact owner/feedback reads are\nadditional;",
    )
    marker = "- `python3 inspect_case.py feedback N`\n"
    addition = (
        marker
        + "Do not issue whole-Step reads. Use the module-specific `owner` command or\n"
        + "`feedback` for system observations so every drilldown remains bounded.\n"
    )
    if value.count(marker) != 1:
        raise RuntimeError("bounded inspector insertion marker changed unexpectedly")
    return value.replace(marker, addition, 1)


def build_anchor_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> str:
    return _python3_bounded_task(
        template.build_anchor_file_task(prediction_manifest_path, cohort_manifest_path)
    )


def build_reducer_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> str:
    return _python3_bounded_task(
        template.build_reducer_file_task(
            prediction_manifest_path,
            cohort_manifest_path,
            anchor_path,
            ledger_path,
            checkpoint_path,
        )
    )


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_GAIA_V3_97_VERSION,
        "model": AGENT_JUDGE_GAIA_V3_97_MODEL,
        "reasoning_effort": AGENT_JUDGE_GAIA_V3_97_REASONING_EFFORT,
        "selection_policy": policy,
        "semantic_parent": SEMANTIC_PARENT,
        "direct_semantic_parent": SEMANTIC_PARENT,
        "rejected_lineage_inherited": False,
        "single_major_change": (
            "replace accepted v3.83 challenger/arbiter with one outcome-conditioned "
            "predicate-handoff tournament over every native v3.83 ledger Step"
        ),
        "host_valid_python3_inspector": True,
        "unbounded_whole_step_inspection_forbidden": True,
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(template.validate_anchor_predictions(*paths), policy="v3p83_anchor_python3_bounded_access")


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])  # noqa: F405


def validate_panel(*paths: str | Path) -> dict[str, Any]:
    return _retag(template.validate_panel(*paths), policy="python3_bounded_singleton_safe_tournament")


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_panel(*paths[:-1]), paths[-1])  # noqa: F405


def validate_selector(*paths: str | Path) -> dict[str, Any]:
    return _retag(template.validate_selector(*paths), policy="python3_bounded_exact_selection_copy")


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_selector(*paths[:-1]), paths[-1])  # noqa: F405


def validate_agent_judge_gaia_v3_97_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    return _retag(
        template.validate_agent_judge_gaia_v3_96_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        policy="python3_bounded_access_audited_predicate_handoff_tournament",
    )


def validate_and_write_agent_judge_gaia_v3_97_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(  # noqa: F405
        validate_agent_judge_gaia_v3_97_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_gaia_v3_97_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_reducer_file_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,  # noqa: F405
    )


validate_and_write_agent_judge_luna_gaia_v3_37_audit = validate_and_write_agent_judge_gaia_v3_97_audit
validate_and_write_agent_judge_luna_gaia_v3_67_audit = validate_and_write_agent_judge_gaia_v3_97_audit
validate_and_write_agent_judge_luna_gaia_v3_79_audit = validate_and_write_agent_judge_gaia_v3_97_audit
validate_and_write_agent_judge_luna_gaia_v3_80_audit = validate_and_write_agent_judge_gaia_v3_97_audit
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_gaia_v3_97_task
build_agent_judge_luna_gaia_v3_79_task = build_agent_judge_gaia_v3_97_task
build_agent_judge_luna_gaia_v3_80_task = build_agent_judge_gaia_v3_97_task


def __getattr__(name: str) -> Any:
    return getattr(template, name)

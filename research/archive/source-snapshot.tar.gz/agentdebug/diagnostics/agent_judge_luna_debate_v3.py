"""Gold-free three-proposal panel with a structured causal arbiter."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

from agentdebug.benchmark.prediction_manifest import load_prediction_manifest

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
    _file_sha256,
    _load_json,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_luna_debate_v1 import (
    PROPOSAL_A_FILENAME,
    PROPOSAL_B_FILENAME,
    _write_audit,
)
from .agent_judge_luna_debate_v2 import (
    AGENT_JUDGE_LUNA_DEBATE_V2_VERSION,
    COMPARISON_FILENAME as V2_COMPARISON_FILENAME,
    build_luna_clean_debate_v2_arbiter_task as _build_v2_arbiter_task,
    build_luna_clean_debate_v2_challenger_task as _build_v2_challenger_task,
    build_luna_clean_debate_v2_draft_task as _build_v2_draft_task,
    validate_luna_clean_debate_v2_challenger_predictions as _validate_v2_challenger,
    validate_luna_clean_debate_v2_draft_predictions as _validate_v2_draft,
)
from .agent_judge_luna_v3_serial_v2 import _nested_owner_source_resolver
from .agent_judge_v2_4 import AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION


AGENT_JUDGE_LUNA_DEBATE_V3_VERSION = (
    "agentdebug.codex-agent-judge.luna-clean-debate-v3"
)
AGENT_JUDGE_LUNA_DEBATE_V3_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_DEBATE_V3_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_DEBATE_V3_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)

PROPOSAL_C_FILENAME = "proposal-c.json"
PANEL_FILENAME = "causal-panel.json"
PANEL_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "status",
    "proposal_a_step",
    "proposal_b_step",
    "proposal_c_step",
    "proposal_a_maturity",
    "proposal_b_maturity",
    "proposal_c_maturity",
    "proposal_a_counterfactual",
    "proposal_b_counterfactual",
    "proposal_c_counterfactual",
    "causal_predecessor_candidate",
    "information_bottleneck_candidate",
    "terminal_boundary_candidate",
    "selected_proposal",
    "selection_rule",
    "selection_rationale",
)
MATURITY_VALUES = ("demonstrated", "uncertain", "reasonable")
CANDIDATE_VALUES = ("A", "B", "C", "neither")
SELECTION_RULE_VALUES = (
    "causal_predecessor",
    "task_resolution_bottleneck",
    "demonstrated_contract_violation",
    "terminal_boundary",
    "stronger_counterfactual",
)


def _upgrade_v2_task(task: str) -> str:
    task = task.replace(
        AGENT_JUDGE_LUNA_DEBATE_V2_VERSION,
        AGENT_JUDGE_LUNA_DEBATE_V3_VERSION,
    )
    task = task.replace(
        "agentdebug/diagnostics/agent_judge_luna_debate_v2.py",
        "agentdebug/diagnostics/agent_judge_luna_debate_v3.py",
    )
    task = task.replace(
        "agentdebug.diagnostics.agent_judge_luna_debate_v2",
        "agentdebug.diagnostics.agent_judge_luna_debate_v3",
    )
    return task


def _resolution_rule() -> str:
    return """\
TASK-RESOLUTION ADMISSION RULE

After a failed or non-discriminating lookup, a new query/plan is not reasonable
merely because it is syntactically valid or textually different.  It is a
mature information bottleneck when it omits an explicit task-defining entity,
relation, filter, attribute, target, or prerequisite and therefore cannot
distinguish the requested answer.  Treat the first such output as causal when
later reasoning consumes that evidence gap.  Likewise, a literal interface
contract violation is directly demonstrated at its output even if a lenient
tool happens to execute it.  These uniform rules do not make every early or
broad query erroneous: the omitted distinction must be explicit in the task
and necessary to resolve the answer.

"""


def _insert_resolution_rule(task: str) -> str:
    marker = "AGENT ERROR TAXONOMY\n"
    if task.count(marker) != 1:
        raise RuntimeError("frozen debate v3 taxonomy marker changed")
    return task.replace(marker, _resolution_rule() + marker, 1)


def _add_read_input(task: str, *, label: str, path: Path) -> str:
    _assert_safe_path(path, role=label)
    task = task.replace(
        "- write predictions only to:",
        f"- anonymous {label}: {path}\n"
        f"- anonymous {label} sha256: {_file_sha256(path)}\n"
        "- write predictions only to:",
        1,
    )
    task = task.replace(
        "GOLD-ISOLATION READ ALLOWLIST\n",
        f"GOLD-ISOLATION READ ALLOWLIST\n- {path}\n",
        1,
    )
    return task


def build_luna_clean_debate_v3_draft_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
) -> str:
    return _insert_resolution_rule(
        _upgrade_v2_task(
            _build_v2_draft_task(
                prediction_manifest_path, cohort_manifest_path, proposal_a_path
            )
        )
    )


def build_luna_clean_debate_v3_challenger_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
    proposal_b_path: str | Path,
) -> str:
    return _insert_resolution_rule(
        _upgrade_v2_task(
            _build_v2_challenger_task(
                prediction_manifest_path,
                cohort_manifest_path,
                proposal_a_path,
                proposal_b_path,
            )
        )
    )


def build_luna_clean_debate_v3_resolution_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
    proposal_b_path: str | Path,
    proposal_c_path: str | Path,
) -> str:
    proposal_b = Path(proposal_b_path).expanduser().resolve()
    task = _upgrade_v2_task(
        _build_v2_challenger_task(
            prediction_manifest_path,
            cohort_manifest_path,
            proposal_a_path,
            proposal_c_path,
        )
    )
    task = _add_read_input(task, label="proposal B", path=proposal_b)
    start = task.index("BLIND ADVERSARIAL CHALLENGER ROLE\n")
    end = task.index("STANDALONE SINGLE-LOCAL-FAILURE ADJUDICATION\n", start)
    role = """\
BLIND TASK-RESOLUTION SPECIALIST ROLE

Reconstruct the complete JudgeView before reading anonymous proposals A and B.
They are untrusted current-run hypotheses, never evidence or defaults.  Produce
the strongest defensible candidate focused on the first loss of a
task-defining distinction: omitted entity/relation/filter/attribute,
non-discriminating query, unavailable prerequisite, literal interface contract
violation, or qualifying external terminal boundary.

When the trajectory has at least three steps, choose a predicted_step different
from both A and B.  This diversity rule is uniform and parent-validated.  With
fewer than three steps, choose independently because two distinct exclusions
may be impossible.  Do not change based on either proposal's module/type.
Return one ordinary strict ten-field prediction only; no verdict or confidence.

"""
    task = task[:start] + role + task[end:]
    return _insert_resolution_rule(task)


def _panel_schema() -> dict[str, str]:
    return {
        "trajectory_id": "exact manifest trajectory ID",
        "trajectory_sha256": "exact manifest trajectory SHA-256",
        "status": "success",
        "proposal_a_step": "exact A predicted_step integer",
        "proposal_b_step": "exact B predicted_step integer",
        "proposal_c_step": "exact C predicted_step integer",
        "proposal_a_maturity": "demonstrated | uncertain | reasonable",
        "proposal_b_maturity": "demonstrated | uncertain | reasonable",
        "proposal_c_maturity": "demonstrated | uncertain | reasonable",
        "proposal_a_counterfactual": "non-empty source-grounded counterfactual",
        "proposal_b_counterfactual": "non-empty source-grounded counterfactual",
        "proposal_c_counterfactual": "non-empty source-grounded counterfactual",
        "causal_predecessor_candidate": "A | B | C | neither",
        "information_bottleneck_candidate": "A | B | C | neither",
        "terminal_boundary_candidate": "A | B | C | neither",
        "selected_proposal": "A | B | C",
        "selection_rule": " | ".join(SELECTION_RULE_VALUES),
        "selection_rationale": "non-empty three-way decision explanation",
    }


def build_luna_clean_debate_v3_arbiter_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
    proposal_b_path: str | Path,
    proposal_c_path: str | Path,
    predictions_path: str | Path,
) -> str:
    proposal_c = Path(proposal_c_path).expanduser().resolve()
    output = Path(predictions_path).expanduser().resolve()
    panel = output.parent / PANEL_FILENAME
    _assert_safe_path(panel, role="causal panel output", is_output=True)
    task = _upgrade_v2_task(
        _build_v2_arbiter_task(
            prediction_manifest_path,
            cohort_manifest_path,
            proposal_a_path,
            proposal_b_path,
            predictions_path,
        )
    )
    old_ledger = output.parent / V2_COMPARISON_FILENAME
    task = task.replace(str(old_ledger), str(panel))
    task = _add_read_input(task, label="proposal C", path=proposal_c)
    start = task.index("STRUCTURED BLIND CAUSAL TOURNAMENT\n")
    end = task.index("STANDALONE SINGLE-LOCAL-FAILURE ADJUDICATION\n", start)
    role = f"""\
STRUCTURED BLIND THREE-CANDIDATE CAUSAL PANEL

Reconstruct the JudgeView, then audit anonymous A, B, and C independently.
They are three fresh current-run hypotheses; none is a default, incumbent,
label, or evidence.  Use no historical prediction and no environment/module/
error-type routing.

For each candidate, classify contemporaneous maturity and state a local
counterfactual.  Then identify any causal predecessor: correcting it must
prevent or materially redirect the later candidates, not merely precede them.
Apply the TASK-RESOLUTION ADMISSION RULE strictly.  In particular, after failed
evidence gathering, a query that drops an explicit necessary entity, relation,
filter, attribute, target, or prerequisite is already a mature bottleneck when
it cannot discriminate the requested answer; a later unsupported conclusion is
then downstream.  A literal interface contract violation is demonstrated at
the output even if the tool is lenient.  Conversely, distinct plausible probes
remain reasonable, and a provenance-backed terminal System limit wins when no
earlier agent candidate has a concrete contradiction.

Choose exactly A, B, or C using this order: demonstrated causal predecessor;
task-resolution bottleneck; demonstrated contract/fact contradiction;
qualifying terminal boundary; stronger local counterfactual.  Chronology alone
never wins.  Do not reconstruct a fourth step.

Write one exact-schema JSON object to {panel}:

{json.dumps(_panel_schema(), ensure_ascii=False, indent=2)}

Then write {output} as a one-record JSON array by copying the selected
proposal's entire ten-field record exactly.  The parent rejects missing panel
fields, mismatched steps, or any final record that is not the exact selection.

"""
    task = task[:start] + role + task[end:]
    return _insert_resolution_rule(task)


def build_luna_clean_debate_v3_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    output = Path(predictions_path).expanduser().resolve()
    return build_luna_clean_debate_v3_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        output.parent / PROPOSAL_A_FILENAME,
        output.parent / PROPOSAL_B_FILENAME,
        output.parent / PROPOSAL_C_FILENAME,
        output,
    )


def _validate_prediction(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    return _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_nested_owner_source_resolver,
    )


def validate_luna_clean_debate_v3_draft_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
) -> dict[str, Any]:
    audit = _validate_v2_draft(
        prediction_manifest_path, cohort_manifest_path, proposal_a_path
    )
    return {**audit, "agent_judge_version": AGENT_JUDGE_LUNA_DEBATE_V3_VERSION}


def validate_luna_clean_debate_v3_challenger_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
    proposal_b_path: str | Path,
) -> dict[str, Any]:
    audit = _validate_v2_challenger(
        prediction_manifest_path,
        cohort_manifest_path,
        proposal_a_path,
        proposal_b_path,
    )
    return {**audit, "agent_judge_version": AGENT_JUDGE_LUNA_DEBATE_V3_VERSION}


def validate_luna_clean_debate_v3_resolution_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
    proposal_b_path: str | Path,
    proposal_c_path: str | Path,
) -> dict[str, Any]:
    challenger = validate_luna_clean_debate_v3_challenger_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        proposal_a_path,
        proposal_b_path,
    )
    audit = _validate_prediction(
        prediction_manifest_path, cohort_manifest_path, proposal_c_path
    )
    _, cases = load_prediction_manifest(prediction_manifest_path)
    a_records = _load_json(Path(proposal_a_path).resolve(), role="proposal A")
    b_records = _load_json(Path(proposal_b_path).resolve(), role="proposal B")
    c_records = _load_json(Path(proposal_c_path).resolve(), role="proposal C")
    difference_count = 0
    for index, (case, a_record, b_record, c_record) in enumerate(
        zip(cases, a_records, b_records, c_records, strict=True)
    ):
        if len(case.judge_view.steps) < 3:
            continue
        if c_record["predicted_step"] in {
            a_record["predicted_step"],
            b_record["predicted_step"],
        }:
            raise AgentJudgeValidationError(
                "resolution_specialist_step_not_distinct",
                f"three-step-capable case retained A/B step at index {index}",
            )
        difference_count += 1
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_DEBATE_V3_VERSION,
        "stage": "task-resolution-specialist",
        "gold_free_validation": True,
        "multi_step_distinct_third_proposal_count": difference_count,
        "challenger_multi_step_difference_count": challenger[
            "multi_step_different_proposal_count"
        ],
    }


def _validate_panel_record(
    value: Any,
    proposal_a: Mapping[str, Any],
    proposal_b: Mapping[str, Any],
    proposal_c: Mapping[str, Any],
) -> dict[str, Any]:
    if not isinstance(value, dict) or tuple(value) != PANEL_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_causal_panel_schema", "causal panel has wrong ordered fields"
        )
    for field in (
        "proposal_a_counterfactual",
        "proposal_b_counterfactual",
        "proposal_c_counterfactual",
        "selection_rationale",
    ):
        if not isinstance(value[field], str) or not value[field].strip():
            raise AgentJudgeValidationError(
                "invalid_causal_panel_text", f"{field} must be non-empty"
            )
    for proposal in (proposal_a, proposal_b, proposal_c):
        if value["trajectory_id"] != proposal["trajectory_id"] or value[
            "trajectory_sha256"
        ] != proposal["trajectory_sha256"]:
            raise AgentJudgeValidationError(
                "causal_panel_identity_mismatch", "proposal identity mismatch"
            )
    if value["status"] != "success":
        raise AgentJudgeValidationError(
            "invalid_causal_panel_status", "status must be success"
        )
    for label, proposal in zip(
        ("a", "b", "c"), (proposal_a, proposal_b, proposal_c), strict=True
    ):
        if value[f"proposal_{label}_step"] != proposal["predicted_step"]:
            raise AgentJudgeValidationError(
                "causal_panel_step_mismatch", f"proposal {label} step mismatch"
            )
        if value[f"proposal_{label}_maturity"] not in MATURITY_VALUES:
            raise AgentJudgeValidationError(
                "invalid_causal_panel_maturity", f"proposal {label} maturity"
            )
    for field in (
        "causal_predecessor_candidate",
        "information_bottleneck_candidate",
        "terminal_boundary_candidate",
    ):
        if value[field] not in CANDIDATE_VALUES:
            raise AgentJudgeValidationError(
                "invalid_causal_panel_candidate", f"invalid {field}"
            )
    if value["selected_proposal"] not in ("A", "B", "C"):
        raise AgentJudgeValidationError(
            "invalid_causal_panel_selection", "selection must be A, B, or C"
        )
    if value["selection_rule"] not in SELECTION_RULE_VALUES:
        raise AgentJudgeValidationError(
            "invalid_causal_panel_rule", "invalid selection rule"
        )
    return value


def validate_luna_clean_debate_v3_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    output = Path(predictions_path).expanduser().resolve()
    paths = {
        "A": output.parent / PROPOSAL_A_FILENAME,
        "B": output.parent / PROPOSAL_B_FILENAME,
        "C": output.parent / PROPOSAL_C_FILENAME,
    }
    resolution = validate_luna_clean_debate_v3_resolution_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        paths["A"],
        paths["B"],
        paths["C"],
    )
    audit = _validate_prediction(
        prediction_manifest_path, cohort_manifest_path, output
    )
    proposals = {
        label: _load_json(path, role=f"proposal {label}")
        for label, path in paths.items()
    }
    finals = _load_json(output, role="predictions")
    panel_path = output.parent / PANEL_FILENAME
    panel_value = _load_json(panel_path, role="causal panel")
    if len(finals) == 1 and isinstance(panel_value, dict):
        panels = [panel_value]
    elif isinstance(panel_value, list):
        panels = panel_value
    else:
        raise AgentJudgeValidationError(
            "invalid_causal_panel_schema", "panel must be object or object array"
        )
    counts = {len(finals), len(panels), *(len(value) for value in proposals.values())}
    if len(counts) != 1:
        raise AgentJudgeValidationError(
            "causal_panel_cardinality_mismatch", "panel/proposal cardinality mismatch"
        )
    checked = []
    for index, (a, b, c, panel, final) in enumerate(
        zip(
            proposals["A"],
            proposals["B"],
            proposals["C"],
            panels,
            finals,
            strict=True,
        )
    ):
        panel = _validate_panel_record(panel, a, b, c)
        selected = {"A": a, "B": b, "C": c}[panel["selected_proposal"]]
        if final != selected or set(final) != AGENT_JUDGE_PREDICTION_FIELDS:
            raise AgentJudgeValidationError(
                "final_not_exact_panel_selection",
                f"final at index {index} is not exact selected proposal",
            )
        checked.append(panel)
    selected_counts = {
        label: sum(panel["selected_proposal"] == label for panel in checked)
        for label in ("A", "B", "C")
    }
    rule_counts = {
        rule: sum(panel["selection_rule"] == rule for panel in checked)
        for rule in SELECTION_RULE_VALUES
    }
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_DEBATE_V3_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_DEBATE_V3_VERSION,
        "model": AGENT_JUDGE_LUNA_DEBATE_V3_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_DEBATE_V3_REASONING_EFFORT,
        "proposal_free_of_historical_predictions": True,
        "label_pair_routing_used": False,
        "fresh_same_case_proposal_count": 3,
        "structured_three_candidate_panel": True,
        "final_exactly_selected_proposal": True,
        "selected_proposal_counts": selected_counts,
        "selection_rule_counts": rule_counts,
        "challenger_multi_step_difference_count": resolution[
            "challenger_multi_step_difference_count"
        ],
        "third_proposal_distinct_step_count": resolution[
            "multi_step_distinct_third_proposal_count"
        ],
        "output_sha256": {
            "predictions.json": _file_sha256(output),
            PROPOSAL_A_FILENAME: _file_sha256(paths["A"]),
            PROPOSAL_B_FILENAME: _file_sha256(paths["B"]),
            PROPOSAL_C_FILENAME: _file_sha256(paths["C"]),
            PANEL_FILENAME: _file_sha256(panel_path),
        },
    }


def validate_and_write_luna_clean_debate_draft_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        audit_path,
        validate_luna_clean_debate_v3_draft_predictions(
            prediction_manifest_path, cohort_manifest_path, proposal_a_path
        ),
    )


def validate_and_write_luna_clean_debate_challenger_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    output = Path(proposal_path).expanduser().resolve()
    if output.name == PROPOSAL_C_FILENAME:
        audit = validate_luna_clean_debate_v3_resolution_predictions(
            prediction_manifest_path,
            cohort_manifest_path,
            output.parent / PROPOSAL_A_FILENAME,
            output.parent / PROPOSAL_B_FILENAME,
            output,
        )
    else:
        audit = validate_luna_clean_debate_v3_challenger_predictions(
            prediction_manifest_path,
            cohort_manifest_path,
            output.parent / PROPOSAL_A_FILENAME,
            output,
        )
    return _write_audit(audit_path, audit)


def validate_and_write_luna_clean_debate_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        audit_path,
        validate_luna_clean_debate_v3_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
    )


__all__ = [
    "AGENT_JUDGE_LUNA_DEBATE_V3_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_DEBATE_V3_MODEL",
    "AGENT_JUDGE_LUNA_DEBATE_V3_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_DEBATE_V3_VERSION",
    "PANEL_FILENAME",
    "PROPOSAL_A_FILENAME",
    "PROPOSAL_B_FILENAME",
    "PROPOSAL_C_FILENAME",
    "build_luna_clean_debate_v3_arbiter_task",
    "build_luna_clean_debate_v3_challenger_task",
    "build_luna_clean_debate_v3_draft_task",
    "build_luna_clean_debate_v3_resolution_task",
    "build_luna_clean_debate_v3_task",
    "validate_luna_clean_debate_v3_challenger_predictions",
    "validate_luna_clean_debate_v3_draft_predictions",
    "validate_luna_clean_debate_v3_predictions",
    "validate_luna_clean_debate_v3_resolution_predictions",
]

"""Validation policy for the pre-frozen coverage-challenged GAIA judge."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge import _validate_agent_judge_predictions_with_owner_sources
from .agent_judge_gaia_official_repo_gpt41_serial_v4 import serial_owner_sources


VERSION = "agentdebug.llm-judge.gaia-official-repo-gpt4.1-coverage-v7"
MODEL = "gpt-4.1"
TEMPERATURE = 0.0
REASONING_EFFORT = "not_applicable"


def build_protocol_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    return f"""Pre-frozen coverage-challenged GAIA diagnostic judge.

Protocol: {VERSION}
Model: {MODEL}
Expected provider-resolved model: gpt-4.1-2025-04-14
Temperature: {TEMPERATURE}
Prediction manifest: {Path(prediction_manifest_path).expanduser().resolve()}
Cohort manifest: {Path(cohort_manifest_path).expanduser().resolve()}
Predictions: {Path(predictions_path).expanduser().resolve()}

Three independent hypothesis scouts nominate two state and acquisition suspects
and up to two recommitment episodes. A deterministic terminal candidate and any causally
guarded provider-failure candidate are added. A fresh coverage challenger adds
up to three missing steps. An exhaustive assessor analyzes every candidate without
selecting one; a separate fresh selector then ranks all candidates by root-error
strength. The runner derives all evidence hashes and handoffs;
the model never copies evidence IDs. Module and type use neutral literal handoffs. Every assessor-added
alternate owner is accompanied by its referral analysis.
"""


def validate_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    base = _validate_agent_judge_predictions_with_owner_sources(
        Path(prediction_manifest_path).expanduser().resolve(),
        Path(cohort_manifest_path).expanduser().resolve(),
        Path(predictions_path).expanduser().resolve(),
        owner_source_resolver=serial_owner_sources,
    )
    return {
        **base,
        "agent_judge_version": VERSION,
        "model": MODEL,
        "reasoning_effort": REASONING_EFFORT,
        "temperature": TEMPERATURE,
        "stage": (
            "three-top2-scouts-top3-coverage-exhaustive-assessor-"
            "fresh-root-error-selector"
        ),
        "model_copies_evidence_ids": False,
        "opaque_hash_ordered_candidate_ids": True,
        "assessor_alternate_owner_candidates_may_be_added_before_selector": True,
        "assessor_selects_winner": False,
        "selector_ranks_all_candidates": True,
        "neutral_module_and_type_handoffs": True,
        "hard_system_owner_policy": "causally-guarded-first-provider-failure",
        "strict_intermediate_lineage_audit": True,
        "stage_provenance_audit": True,
        "implementation_frozen_before_inference": True,
        "external_llm_api": True,
    }


build_task = build_protocol_task

"""Step-first, owner-decoupled Luna adjudication with exact evidence atoms.

V15 retains v14's anonymous JudgeView and deterministic owner-bound evidence
atoms, but an atom no longer fixes ownership during boundary discovery.  Three
independent locators nominate step-only anchors, the parent may add the
strategy anchor's immediate predecessor after a strict materiality audit, and
arbitration selects a neutral step card.  Only after that step is frozen does
classification select an owner-bound evidence atom at the same step.  The
parent derives step, module, literal quote, and candidate provenance.
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Mapping

from agentdebug.benchmark.prediction_manifest import load_prediction_manifest

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _file_sha256,
    _load_json,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_luna_v13_unified import (
    _anonymized_timeline,
    _leaf_and_residual_owner_source_resolver,
    _system_owner_sources,
)
from .agent_judge_luna_v14_unified import (
    _atom_catalog_sha256,
    _evidence_atoms as _v14_evidence_atoms,
    _public_atom_catalog,
    _required_text,
    _validate_one_case_identity,
)
from .agent_judge_v2_4 import AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
from .taxonomy import AgentModule, ErrorType, is_valid_classification, taxonomy_prompt


AGENT_JUDGE_LUNA_V15_UNIFIED_VERSION = (
    "agentdebug.codex-agent-judge.luna-v15-unified-v2"
)
AGENT_JUDGE_LUNA_V15_UNIFIED_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_V15_UNIFIED_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_V15_UNIFIED_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)

DECISION_FILENAME = "decision.json"

_STEP_LOCATOR_FIELDS = frozenset(
    {
        "step_card_id",
        "defect_basis",
        "boundary_reason",
        "smallest_correction",
        "downstream_consequence",
    }
)
_STATE_FIDELITY_FIELDS = frozenset(
    {
        "candidate_status",
        "step_card_id",
        "boundary_reason",
        "smallest_correction",
        "downstream_consequence",
    }
)
_PREDECESSOR_FIELDS = frozenset(
    {
        "material_status",
        "defect_basis",
        "boundary_reason",
        "smallest_correction",
        "downstream_consequence",
    }
)
_ASSESSMENT_FIELDS = frozenset(
    {"step_card_id", "root_status", "assessment"}
)
_ARBITRATION_FIELDS = frozenset(
    {
        "selected_step_card_id",
        "candidate_assessments",
        "selected_step_reason",
        "smallest_correction",
        "downstream_consequence",
    }
)
_CLASSIFICATION_FIELDS = frozenset(
    {"owner_atom_id", "predicted_error_type", "rejected_adjacent_owner"}
)
_DECISION_FIELDS = frozenset(
    {
        "strategy_locator",
        "local_locator",
        "state_fidelity_locator",
        "strategy_predecessor_audit",
        "arbitration",
        "classification",
    }
)

_DEFECT_BASES = frozenset(
    {
        "literal_state_contradiction",
        "literal_task_constraint",
        "plan_action_contract",
        "mechanical_interface_defect",
        "mature_repetition",
        "observable_system_boundary",
        "causal_inference",
    }
)
_STATE_STATUSES = frozenset({"candidate", "no_candidate"})
_PREDECESSOR_STATUSES = frozenset(
    {"material_candidate", "not_material", "not_applicable"}
)
_ROOT_STATUSES = frozenset(
    {"direct_root", "causal_predecessor", "downstream_symptom", "weak_or_ambiguous"}
)
_SOURCE_ORDER = {
    "strategy_anchor": 0,
    "independent_local": 1,
    "state_fidelity": 2,
    "strategy_immediate_predecessor": 3,
}

_ATOM_SCHEMA_VERSION = "agentdebug.luna-v15-evidence-atoms.v2"
_STEP_SCHEMA_VERSION = "agentdebug.luna-v15-step-cards.v1"
_STEP_PREFIX = "SC-"
_ATOM_PREFIX = "EA-"


def _evidence_atoms(case: Any) -> tuple[dict[str, Any], ...]:
    """Build v15 atoms without treating arbitrary Step-1 task text as System.

    V13 admitted the entire task display at Step 1 for ``environment_error``.
    That source-level affordance cannot mechanically establish a task/interface
    contradiction, so v15 removes atoms supported only by that task text.  A
    genuine Step-1 pseudo-tool, structured tool, or terminal failure remains
    admissible through the same strict System resolver used by v14.
    """

    atoms = _v14_evidence_atoms(case)
    task_text = (
        case.judge_view.task.display_text
        if case.judge_view.task is not None
        else None
    )
    if task_text is None:
        return atoms

    filtered: list[dict[str, Any]] = []
    for atom in atoms:
        if atom["step"] != 1 or atom["owner_module"] != AgentModule.SYSTEM.value:
            filtered.append(atom)
            continue
        strict_types: list[str] = []
        for error_type_value in atom["allowed_error_types"]:
            sources = _system_owner_sources(
                case.judge_view,
                1,
                ErrorType(error_type_value),
            )
            non_task_sources = tuple(source for source in sources if source != task_text)
            if any(atom["quote"] in source for source in non_task_sources):
                strict_types.append(error_type_value)
        if strict_types:
            filtered.append(
                {
                    **atom,
                    "allowed_error_types": tuple(sorted(strict_types)),
                }
            )
    return tuple(filtered)


def _step_cards(
    case: Any,
    atoms: tuple[dict[str, Any], ...],
) -> tuple[dict[str, Any], ...]:
    """Build deterministic, case-local step IDs without trajectory identity."""

    step_count = len(case.judge_view.steps)
    if step_count > 9999:
        raise AgentJudgeValidationError(
            "step_catalog_too_large", "v15 supports at most 9999 trajectory steps"
        )
    atom_counts: dict[int, int] = {}
    state_steps: set[int] = set()
    system_steps: set[int] = set()
    agent_steps: set[int] = set()
    for atom in atoms:
        step = atom["step"]
        atom_counts[step] = atom_counts.get(step, 0) + 1
        owner = atom["owner_module"]
        if owner in {AgentModule.MEMORY.value, AgentModule.REFLECTION.value}:
            state_steps.add(step)
        if owner == AgentModule.SYSTEM.value:
            system_steps.add(step)
        else:
            agent_steps.add(step)
    return tuple(
        {
            "step_card_id": f"{_STEP_PREFIX}{step:04d}",
            "step": step,
            "owner_atom_count": atom_counts.get(step, 0),
            "has_state_fidelity_evidence": step in state_steps,
            "has_agent_evidence": step in agent_steps,
            "has_system_evidence": step in system_steps,
        }
        for step in range(1, step_count + 1)
    )


def _step_catalog_sha256(cards: tuple[dict[str, Any], ...]) -> str:
    body = json.dumps(
        cards,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(body).hexdigest()


def _public_step_catalog(cards: tuple[dict[str, Any], ...]) -> dict[str, Any]:
    return {
        "schema_version": _STEP_SCHEMA_VERSION,
        "step_count": len(cards),
        "cards": [dict(card) for card in cards],
    }


def build_luna_v15_evidence_atom_catalog(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> dict[str, Any]:
    """Return the exact anonymous step and evidence catalogs used by v15."""

    _, _, _, case, _ = _validate_one_case_identity(
        prediction_manifest_path,
        cohort_manifest_path,
        role="task",
    )
    atoms = _evidence_atoms(case)
    cards = _step_cards(case, atoms)
    return {
        "schema_version": _ATOM_SCHEMA_VERSION,
        "atom_count": len(atoms),
        "catalog_sha256": _atom_catalog_sha256(atoms),
        "step_catalog_sha256": _step_catalog_sha256(cards),
        "step_catalog": _public_step_catalog(cards),
        **_public_atom_catalog(atoms),
    }


def _nullable_text_schema() -> dict[str, Any]:
    return {"type": ["string", "null"], "minLength": 1}


def decision_output_schema() -> dict[str, Any]:
    """Return the exact strict JSON schema supplied to the model."""

    step_id = {
        "type": "string",
        "pattern": rf"^{re.escape(_STEP_PREFIX)}[0-9]{{4}}$",
    }
    nullable_step_id = {
        "type": ["string", "null"],
        "pattern": rf"^{re.escape(_STEP_PREFIX)}[0-9]{{4}}$",
    }
    locator = {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_STEP_LOCATOR_FIELDS),
        "properties": {
            "step_card_id": step_id,
            "defect_basis": {"type": "string", "enum": sorted(_DEFECT_BASES)},
            "boundary_reason": {"type": "string", "minLength": 1},
            "smallest_correction": {"type": "string", "minLength": 1},
            "downstream_consequence": {"type": "string", "minLength": 1},
        },
    }
    state_fidelity = {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_STATE_FIDELITY_FIELDS),
        "properties": {
            "candidate_status": {
                "type": "string",
                "enum": sorted(_STATE_STATUSES),
            },
            "step_card_id": nullable_step_id,
            "boundary_reason": {"type": "string", "minLength": 1},
            "smallest_correction": _nullable_text_schema(),
            "downstream_consequence": _nullable_text_schema(),
        },
    }
    predecessor = {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_PREDECESSOR_FIELDS),
        "properties": {
            "material_status": {
                "type": "string",
                "enum": sorted(_PREDECESSOR_STATUSES),
            },
            "defect_basis": {
                "type": ["string", "null"],
                "enum": [*sorted(_DEFECT_BASES), None],
            },
            "boundary_reason": {"type": "string", "minLength": 1},
            "smallest_correction": _nullable_text_schema(),
            "downstream_consequence": _nullable_text_schema(),
        },
    }
    assessment = {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_ASSESSMENT_FIELDS),
        "properties": {
            "step_card_id": step_id,
            "root_status": {"type": "string", "enum": sorted(_ROOT_STATUSES)},
            "assessment": {"type": "string", "minLength": 1},
        },
    }
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_DECISION_FIELDS),
        "properties": {
            "strategy_locator": locator,
            "local_locator": locator,
            "state_fidelity_locator": state_fidelity,
            "strategy_predecessor_audit": predecessor,
            "arbitration": {
                "type": "object",
                "additionalProperties": False,
                "required": sorted(_ARBITRATION_FIELDS),
                "properties": {
                    "selected_step_card_id": step_id,
                    "candidate_assessments": {
                        "type": "array",
                        "minItems": 1,
                        "items": assessment,
                    },
                    "selected_step_reason": {"type": "string", "minLength": 1},
                    "smallest_correction": {"type": "string", "minLength": 1},
                    "downstream_consequence": {
                        "type": "string",
                        "minLength": 1,
                    },
                },
            },
            "classification": {
                "type": "object",
                "additionalProperties": False,
                "required": sorted(_CLASSIFICATION_FIELDS),
                "properties": {
                    "owner_atom_id": {
                        "type": "string",
                        "pattern": rf"^{re.escape(_ATOM_PREFIX)}[0-9]{{4}}$",
                    },
                    "predicted_error_type": {
                        "type": "string",
                        "enum": [item.value for item in ErrorType],
                    },
                    "rejected_adjacent_owner": {
                        "type": "string",
                        "minLength": 1,
                    },
                },
            },
        },
    }


def runtime_conformance_decision() -> dict[str, Any]:
    """Return a case-independent schema probe for runner/runtime conformance.

    The object is intentionally only schema-valid.  It is never a semantic
    prediction and must not be passed to the case-aware decision validator.
    Keeping it here prevents the runner from maintaining a second schema copy.
    """

    return {
        "strategy_locator": {
            "step_card_id": "SC-0002",
            "defect_basis": "causal_inference",
            "boundary_reason": "The strategy anchor is the causal boundary.",
            "smallest_correction": "Correct the strategy decision.",
            "downstream_consequence": "The downstream chain changes.",
        },
        "local_locator": {
            "step_card_id": "SC-0003",
            "defect_basis": "literal_task_constraint",
            "boundary_reason": "The local anchor is independently material.",
            "smallest_correction": "Correct the local constraint breach.",
            "downstream_consequence": "The local failure is prevented.",
        },
        "state_fidelity_locator": {
            "candidate_status": "no_candidate",
            "step_card_id": None,
            "boundary_reason": "No material state-fidelity defect is present.",
            "smallest_correction": None,
            "downstream_consequence": None,
        },
        "strategy_predecessor_audit": {
            "material_status": "material_candidate",
            "defect_basis": "causal_inference",
            "boundary_reason": "The immediate predecessor supplies the premise.",
            "smallest_correction": "Correct that premise before using it.",
            "downstream_consequence": "The strategy anchor is not induced.",
        },
        "arbitration": {
            "selected_step_card_id": "SC-0001",
            "candidate_assessments": [
                {
                    "step_card_id": "SC-0001",
                    "root_status": "causal_predecessor",
                    "assessment": "This is the earliest material premise.",
                },
                {
                    "step_card_id": "SC-0002",
                    "root_status": "downstream_symptom",
                    "assessment": "This consumes the earlier premise.",
                },
                {
                    "step_card_id": "SC-0003",
                    "root_status": "weak_or_ambiguous",
                    "assessment": "This alternative is less causally direct.",
                },
            ],
            "selected_step_reason": "The predecessor is the material root.",
            "smallest_correction": "Correct the predecessor premise.",
            "downstream_consequence": "The later failure chain is avoided.",
        },
        "classification": {
            "owner_atom_id": "EA-0001",
            "predicted_error_type": ErrorType.INEFFICIENT_PLAN.value,
            "rejected_adjacent_owner": "An adjacent owner is downstream.",
        },
    }


def _step_locator(
    value: Any,
    *,
    cards_by_id: Mapping[str, Mapping[str, Any]],
    location: str,
) -> dict[str, Any]:
    if not isinstance(value, Mapping) or set(value) != _STEP_LOCATOR_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_step_locator_fields", f"{location} has invalid fields"
        )
    step_card_id = value["step_card_id"]
    if not isinstance(step_card_id, str) or step_card_id not in cards_by_id:
        raise AgentJudgeValidationError(
            "unknown_step_card", f"{location}.step_card_id is not in the catalog"
        )
    card = cards_by_id[step_card_id]
    if card["owner_atom_count"] < 1:
        raise AgentJudgeValidationError(
            "step_has_no_owner_atoms", f"{location} selected an unclassifiable step"
        )
    basis = value["defect_basis"]
    if not isinstance(basis, str) or basis not in _DEFECT_BASES:
        raise AgentJudgeValidationError(
            "invalid_defect_basis", f"{location}.defect_basis is invalid"
        )
    if basis == "observable_system_boundary" and not card["has_system_evidence"]:
        raise AgentJudgeValidationError(
            "system_basis_without_system_evidence",
            f"{location} claims a System boundary without a strict System atom",
        )
    if basis != "observable_system_boundary" and not card["has_agent_evidence"]:
        raise AgentJudgeValidationError(
            "agent_basis_without_agent_evidence",
            f"{location} claims an agent defect without an agent-owned atom",
        )
    for field in _STEP_LOCATOR_FIELDS - {"step_card_id", "defect_basis"}:
        _required_text(value[field], location=f"{location}.{field}")
    return {**dict(value), "step": card["step"]}


def _state_fidelity_locator(
    value: Any,
    *,
    cards_by_id: Mapping[str, Mapping[str, Any]],
    location: str,
) -> dict[str, Any]:
    if not isinstance(value, Mapping) or set(value) != _STATE_FIDELITY_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_state_fidelity_fields", f"{location} has invalid fields"
        )
    status = value["candidate_status"]
    if not isinstance(status, str) or status not in _STATE_STATUSES:
        raise AgentJudgeValidationError(
            "invalid_state_fidelity_status", f"{location}.candidate_status is invalid"
        )
    reason = _required_text(
        value["boundary_reason"],
        location=f"{location}.boundary_reason",
    )
    step_card_id = value["step_card_id"]
    correction = value["smallest_correction"]
    consequence = value["downstream_consequence"]
    if status == "no_candidate":
        if (
            step_card_id is not None
            or correction is not None
            or consequence is not None
        ):
            raise AgentJudgeValidationError(
                "invalid_no_state_candidate",
                "no_candidate requires a null step, correction, and consequence",
            )
        return {
            **dict(value),
            "boundary_reason": reason,
            "step": None,
        }
    if not isinstance(step_card_id, str) or step_card_id not in cards_by_id:
        raise AgentJudgeValidationError(
            "unknown_step_card", f"{location}.step_card_id is not in the catalog"
        )
    card = cards_by_id[step_card_id]
    if not card["has_state_fidelity_evidence"]:
        raise AgentJudgeValidationError(
            "state_candidate_without_state_evidence",
            "state-fidelity candidate step has no Memory or Reflection evidence",
        )
    _required_text(correction, location=f"{location}.smallest_correction")
    _required_text(consequence, location=f"{location}.downstream_consequence")
    return {**dict(value), "step": card["step"]}


def _strategy_predecessor_audit(
    value: Any,
    *,
    strategy: Mapping[str, Any],
    cards_by_step: Mapping[int, Mapping[str, Any]],
    location: str,
) -> dict[str, Any]:
    if not isinstance(value, Mapping) or set(value) != _PREDECESSOR_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_predecessor_fields", f"{location} has invalid fields"
        )
    status = value["material_status"]
    if not isinstance(status, str) or status not in _PREDECESSOR_STATUSES:
        raise AgentJudgeValidationError(
            "invalid_predecessor_status", f"{location}.material_status is invalid"
        )
    _required_text(value["boundary_reason"], location=f"{location}.boundary_reason")
    strategy_step = strategy["step"]
    if strategy_step == 1:
        if (
            status != "not_applicable"
            or value["defect_basis"] is not None
            or value["smallest_correction"] is not None
            or value["downstream_consequence"] is not None
        ):
            raise AgentJudgeValidationError(
                "invalid_step_one_predecessor",
                "a Step-1 strategy anchor has no predecessor candidate",
            )
        return {**dict(value), "step_card_id": None, "step": None}
    if status == "not_applicable":
        raise AgentJudgeValidationError(
            "invalid_noninitial_predecessor",
            "not_applicable is reserved for a Step-1 strategy anchor",
        )
    predecessor_step = strategy_step - 1
    card = cards_by_step[predecessor_step]
    if status == "not_material":
        if (
            value["defect_basis"] is not None
            or value["smallest_correction"] is not None
            or value["downstream_consequence"] is not None
        ):
            raise AgentJudgeValidationError(
                "invalid_nonmaterial_predecessor",
                "not_material requires null basis, correction, and consequence",
            )
        return {**dict(value), "step_card_id": None, "step": None}
    basis = value["defect_basis"]
    if not isinstance(basis, str) or basis not in _DEFECT_BASES:
        raise AgentJudgeValidationError(
            "invalid_defect_basis", f"{location}.defect_basis is invalid"
        )
    has_matching_evidence = (
        card["has_system_evidence"]
        if basis == "observable_system_boundary"
        else card["has_agent_evidence"]
    )
    if not has_matching_evidence:
        raise AgentJudgeValidationError(
            "predecessor_without_material_evidence",
            "the derived predecessor has no evidence for the claimed owner class",
        )
    _required_text(
        value["smallest_correction"],
        location=f"{location}.smallest_correction",
    )
    _required_text(
        value["downstream_consequence"],
        location=f"{location}.downstream_consequence",
    )
    return {
        **dict(value),
        "step_card_id": card["step_card_id"],
        "step": predecessor_step,
    }


def _candidate_cards(
    *,
    strategy: Mapping[str, Any],
    local: Mapping[str, Any],
    state_fidelity: Mapping[str, Any],
    predecessor: Mapping[str, Any],
    cards_by_id: Mapping[str, Mapping[str, Any]],
) -> tuple[dict[str, Any], ...]:
    nominations: list[tuple[str, str, str]] = [
        ("strategy_anchor", strategy["step_card_id"], strategy["defect_basis"]),
        ("independent_local", local["step_card_id"], local["defect_basis"]),
    ]
    if state_fidelity["candidate_status"] == "candidate":
        nominations.append(
            (
                "state_fidelity",
                state_fidelity["step_card_id"],
                "literal_state_contradiction",
            )
        )
    if predecessor["material_status"] == "material_candidate":
        nominations.append(
            (
                "strategy_immediate_predecessor",
                predecessor["step_card_id"],
                predecessor["defect_basis"],
            )
        )
    sources_by_id: dict[str, list[str]] = {}
    bases_by_id: dict[str, list[str]] = {}
    for source, step_card_id, defect_basis in nominations:
        sources_by_id.setdefault(step_card_id, []).append(source)
        bases_by_id.setdefault(step_card_id, []).append(defect_basis)
    return tuple(
        {
            "step_card_id": step_card_id,
            "step": cards_by_id[step_card_id]["step"],
            "candidate_sources": list(
                sorted(sources, key=lambda source: _SOURCE_ORDER[source])
            ),
            "candidate_defect_bases": sorted(set(bases_by_id[step_card_id])),
        }
        for step_card_id, sources in sorted(
            sources_by_id.items(), key=lambda item: cards_by_id[item[0]]["step"]
        )
    )


def _arbitration(
    value: Any,
    *,
    candidate_cards: tuple[dict[str, Any], ...],
    location: str,
) -> tuple[dict[str, Any], Mapping[str, Any]]:
    if not isinstance(value, Mapping) or set(value) != _ARBITRATION_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_arbitration_fields", f"{location} has invalid fields"
        )
    expected_ids = {card["step_card_id"] for card in candidate_cards}
    assessments = value["candidate_assessments"]
    if not isinstance(assessments, list) or not assessments:
        raise AgentJudgeValidationError(
            "invalid_candidate_assessments",
            f"{location}.candidate_assessments must be a non-empty list",
        )
    assessed_ids: list[str] = []
    resolved_assessments: list[dict[str, Any]] = []
    for index, assessment in enumerate(assessments):
        item_location = f"{location}.candidate_assessments[{index}]"
        if not isinstance(assessment, Mapping) or set(assessment) != _ASSESSMENT_FIELDS:
            raise AgentJudgeValidationError(
                "invalid_candidate_assessment_fields",
                f"{item_location} has invalid fields",
            )
        step_card_id = assessment["step_card_id"]
        root_status = assessment["root_status"]
        if not isinstance(step_card_id, str) or step_card_id not in expected_ids:
            raise AgentJudgeValidationError(
                "assessment_not_nominated",
                f"{item_location}.step_card_id is not a nominated candidate",
            )
        if not isinstance(root_status, str) or root_status not in _ROOT_STATUSES:
            raise AgentJudgeValidationError(
                "invalid_candidate_root_status",
                f"{item_location}.root_status is invalid",
            )
        _required_text(assessment["assessment"], location=f"{item_location}.assessment")
        assessed_ids.append(step_card_id)
        resolved_assessments.append(dict(assessment))
    if len(set(assessed_ids)) != len(assessed_ids):
        raise AgentJudgeValidationError(
            "duplicate_candidate_assessment",
            "candidate_assessments must contain each neutral step once",
        )
    if set(assessed_ids) != expected_ids:
        raise AgentJudgeValidationError(
            "incomplete_candidate_assessments",
            "candidate_assessments must exhaust the deduplicated candidate set",
        )
    selected_step_card_id = value["selected_step_card_id"]
    if (
        not isinstance(selected_step_card_id, str)
        or selected_step_card_id not in expected_ids
    ):
        raise AgentJudgeValidationError(
            "selected_step_not_nominated",
            "arbitration selected a step outside the candidate set",
        )
    selected_assessment = next(
        assessment
        for assessment in resolved_assessments
        if assessment["step_card_id"] == selected_step_card_id
    )
    if selected_assessment["root_status"] not in {
        "direct_root",
        "causal_predecessor",
    }:
        raise AgentJudgeValidationError(
            "selected_candidate_not_root_worthy",
            "the selected candidate must be assessed as a direct_root or "
            "causal_predecessor, not as a downstream symptom or weak alternative",
        )
    for field in (
        "selected_step_reason",
        "smallest_correction",
        "downstream_consequence",
    ):
        _required_text(value[field], location=f"{location}.{field}")
    selected_card = next(
        card
        for card in candidate_cards
        if card["step_card_id"] == selected_step_card_id
    )
    return {
        **dict(value),
        "candidate_assessments": resolved_assessments,
    }, selected_card


def _classification(
    value: Any,
    *,
    selected_card: Mapping[str, Any],
    atoms_by_id: Mapping[str, Mapping[str, Any]],
    location: str,
) -> tuple[dict[str, Any], Mapping[str, Any]]:
    if not isinstance(value, Mapping) or set(value) != _CLASSIFICATION_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_classification_fields", f"{location} has invalid fields"
        )
    owner_atom_id = value["owner_atom_id"]
    if not isinstance(owner_atom_id, str) or owner_atom_id not in atoms_by_id:
        raise AgentJudgeValidationError(
            "unknown_owner_atom", f"{location}.owner_atom_id is not in the catalog"
        )
    owner_atom = atoms_by_id[owner_atom_id]
    if owner_atom["step"] != selected_card["step"]:
        raise AgentJudgeValidationError(
            "classification_atom_step_mismatch",
            "classification owner atom must belong to the frozen selected step",
        )
    selected_bases = set(selected_card["candidate_defect_bases"])
    owner_is_system = owner_atom["owner_module"] == AgentModule.SYSTEM.value
    has_system_nomination = "observable_system_boundary" in selected_bases
    if owner_is_system and not has_system_nomination:
        raise AgentJudgeValidationError(
            "system_owner_without_system_nomination",
            "System ownership requires an observable_system_boundary nomination "
            "at the selected step",
        )
    if not owner_is_system and selected_bases == {"observable_system_boundary"}:
        raise AgentJudgeValidationError(
            "system_only_nomination_with_agent_owner",
            "a step nominated only as an observable System boundary must retain "
            "System ownership",
        )
    try:
        error_type = ErrorType(value["predicted_error_type"])
    except (TypeError, ValueError) as error:
        raise AgentJudgeValidationError(
            "invalid_classification_taxonomy", f"{location} has unknown taxonomy"
        ) from error
    module = AgentModule(owner_atom["owner_module"])
    if not is_valid_classification(module, error_type):
        raise AgentJudgeValidationError(
            "invalid_classification_taxonomy",
            f"{location} has an illegal module/error_type pair",
        )
    if error_type.value not in owner_atom["allowed_error_types"]:
        raise AgentJudgeValidationError(
            "invalid_classification_evidence",
            "error type is not admitted by the selected owner-bound atom",
        )
    _required_text(
        value["rejected_adjacent_owner"],
        location=f"{location}.rejected_adjacent_owner",
    )
    return dict(value), owner_atom


def _prediction_record(case: Any, candidate: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        **dict(candidate),
    }


def validate_luna_v15_unified_decision(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    decision_path: str | Path,
) -> dict[str, Any]:
    """Validate and mechanically resolve one step-first v15 decision."""

    manifest_path, cohort_path, _, case, cohort = _validate_one_case_identity(
        prediction_manifest_path,
        cohort_manifest_path,
        role="decision",
    )
    atoms = _evidence_atoms(case)
    atoms_by_id = {atom["evidence_atom_id"]: atom for atom in atoms}
    if len(atoms_by_id) != len(atoms):
        raise AssertionError("v15 evidence atom IDs are not unique")
    cards = _step_cards(case, atoms)
    cards_by_id = {card["step_card_id"]: card for card in cards}
    cards_by_step = {card["step"]: card for card in cards}

    resolved_decision_path = Path(decision_path).expanduser().resolve()
    raw = _load_json(resolved_decision_path, role="decision")
    if not isinstance(raw, Mapping) or set(raw) != _DECISION_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_decision_fields", "decision has invalid top-level fields"
        )
    strategy = _step_locator(
        raw["strategy_locator"],
        cards_by_id=cards_by_id,
        location="decision.strategy_locator",
    )
    local = _step_locator(
        raw["local_locator"],
        cards_by_id=cards_by_id,
        location="decision.local_locator",
    )
    if len(cards) > 1 and strategy["step"] == local["step"]:
        raise AgentJudgeValidationError(
            "candidate_steps_not_distinct",
            "multi-step strategy and local anchors must use different steps",
        )
    state_fidelity = _state_fidelity_locator(
        raw["state_fidelity_locator"],
        cards_by_id=cards_by_id,
        location="decision.state_fidelity_locator",
    )
    predecessor = _strategy_predecessor_audit(
        raw["strategy_predecessor_audit"],
        strategy=strategy,
        cards_by_step=cards_by_step,
        location="decision.strategy_predecessor_audit",
    )
    candidates = _candidate_cards(
        strategy=strategy,
        local=local,
        state_fidelity=state_fidelity,
        predecessor=predecessor,
        cards_by_id=cards_by_id,
    )
    arbitration, selected_card = _arbitration(
        raw["arbitration"],
        candidate_cards=candidates,
        location="decision.arbitration",
    )
    classification, owner_atom = _classification(
        raw["classification"],
        selected_card=selected_card,
        atoms_by_id=atoms_by_id,
        location="decision.classification",
    )
    derived_selection_basis = "+".join(selected_card["candidate_sources"])
    prediction = _prediction_record(
        case,
        {
            "predicted_step": selected_card["step"],
            "predicted_module": owner_atom["owner_module"],
            "predicted_error_type": classification["predicted_error_type"],
            "evidence_quote": owner_atom["quote"],
            "root_cause": arbitration["selected_step_reason"],
            "causal_summary": (
                f"Smallest correction: {arbitration['smallest_correction']} "
                "Downstream consequence: "
                f"{arbitration['downstream_consequence']}"
            ),
            "rejected_adjacent_owner": classification["rejected_adjacent_owner"],
        },
    )
    if set(prediction) != AGENT_JUDGE_PREDICTION_FIELDS:
        raise AssertionError("derived v15 prediction fields changed")
    return {
        "schema_version": "agentdebug.codex-agent-judge-luna-v15-decision-audit.v2",
        "agent_judge_version": AGENT_JUDGE_LUNA_V15_UNIFIED_VERSION,
        "model": AGENT_JUDGE_LUNA_V15_UNIFIED_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V15_UNIFIED_REASONING_EFFORT,
        "proposal_free": True,
        "historical_predictions_visible": False,
        "same_session_hypothesis_count": 3,
        "step_owner_decoupled": True,
        "predecessor_step_parent_derived": True,
        "candidate_steps_distinct_when_possible": strategy["step"] != local["step"],
        "evidence_atom_schema_version": _ATOM_SCHEMA_VERSION,
        "evidence_atom_count": len(atoms),
        "evidence_atom_catalog_sha256": _atom_catalog_sha256(atoms),
        "step_card_schema_version": _STEP_SCHEMA_VERSION,
        "step_card_count": len(cards),
        "step_card_catalog_sha256": _step_catalog_sha256(cards),
        "strategy_locator": strategy,
        "local_locator": local,
        "state_fidelity_locator": state_fidelity,
        "strategy_predecessor_audit": predecessor,
        "candidate_step_cards": [dict(card) for card in candidates],
        "selected_step_card_id": selected_card["step_card_id"],
        "derived_selection_basis": derived_selection_basis,
        "arbitration": arbitration,
        "classification": classification,
        "selected_owner_atom_id": owner_atom["evidence_atom_id"],
        "selected_prediction": prediction,
        "prediction_manifest_file_sha256": _file_sha256(manifest_path),
        "cohort_manifest_file_sha256": _file_sha256(cohort_path),
        "cohort_name": cohort["cohort_name"],
        "cohort_sha256": cohort["cohort_sha256"],
        "dataset_manifest_sha256": cohort["dataset_manifest_sha256"],
        "decision_sha256": _file_sha256(resolved_decision_path),
    }


def _decision_contract() -> str:
    return json.dumps(decision_output_schema(), ensure_ascii=False, indent=2)


def build_agent_judge_luna_v15_unified_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Embed one anonymous JudgeView and v15's step/atom catalogs."""

    del predictions_path
    _, _, _, case, _ = _validate_one_case_identity(
        prediction_manifest_path,
        cohort_manifest_path,
        role="task",
    )
    timeline = _anonymized_timeline(case)
    atoms = _evidence_atoms(case)
    cards = _step_cards(case, atoms)
    catalogs = json.dumps(
        {
            "step_catalog": _public_step_catalog(cards),
            "evidence_atom_schema_version": _ATOM_SCHEMA_VERSION,
            **_public_atom_catalog(atoms),
        },
        ensure_ascii=False,
        indent=2,
    )
    return f"""\
Run frozen protocol {AGENT_JUDGE_LUNA_V15_UNIFIED_VERSION}.

EXECUTION CONTRACT
- model: {AGENT_JUDGE_LUNA_V15_UNIFIED_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_V15_UNIFIED_REASONING_EFFORT}
- exactly one anonymous trajectory is embedded below
- do not call tools, inspect files, use the network, or use external APIs
- no prior prediction, proposal, label, score, case study, or cross-case state exists
- return exactly one JSON object matching the supplied output schema

Complete every phase in order.  Never infer from an opaque ID, card order,
source-model name, environment, expected distribution, or benchmark memory.

STEP-FIRST CONTRACT

The parent assigns deterministic case-local SC IDs to trajectory steps and EA
IDs to exact owner-bound evidence atoms.  Locators nominate only SC IDs: they
must not choose an owner, module, evidence atom, quote, source, or error type.
Arbitration freezes one SC ID from the deduplicated nominated set.  Only then
classification selects one EA ID at that exact step and one type from that
atom's allowed_error_types.  The parent mechanically derives step, module,
literal evidence quote, and selection provenance.  Never copy evidence text.

System remains evidence-strict: observable_system_boundary may be nominated
only on a step whose card reports has_system_evidence=true, and System may be
classified only through a parent-built System atom.  Such atoms arise only
from an independent typed external failure or an explicit typed execution
stop/limit.  Ordinary task text—even at Step 1—does not mechanically prove an
interface contradiction and never creates a System atom.  Trace length or
an unresolved final step alone never proves a System step limit.

PHASE A — STRATEGY/CHRONOLOGICAL STEP ANCHOR

Scan from Step 1 for the earliest mature causal strategy or execution boundary
whose correction would materially redirect failure.  A reasonable first
probe and one evidence-motivated confirmation are not mature repetition.  Use
a step_card_id plus basis and causal prose; do not select an owner atom.

PHASE B — INDEPENDENT LOCAL STEP ANCHOR

Independently find the strongest local material defect.  Prefer direct false
state/result/progress claims, literal task conflict, missing prerequisite,
Plan/Action contract breach, mechanical interface defect, qualified mature
repetition, or strict System evidence over generic hindsight.  On a multi-step
trace this anchor must use a different step from Phase A; choose the strongest
honest material alternative at another step.  This locator is not a fallback
and has no lower priority than Phase A.

PHASE C — STATE-FIDELITY STEP CANDIDATE

Audit every Memory and Reflection against the immediately preceding action and
result, the current observation, and already established facts.  Nominate the
step of the Memory/Reflection itself for an omitted decisive fact, invented
state, unsupported all/none claim, false success/failure/progress statement,
or causal misattribution.  Do not shift the boundary to the next Planning step
that consumes it.  A candidate step must have
has_state_fidelity_evidence=true.  If no material state-fidelity defect exists,
emit candidate_status=no_candidate, a null step/correction/consequence, and a
non-empty reason.  This candidate is still step-only; ownership is unresolved.

PHASE D — IMMEDIATE PREDECESSOR AUDIT

After freezing the Phase-A anchor C, inspect exactly C-1.  Do not output its
step ID: the parent derives it.  Mark material_candidate only when C-1 contains
a concrete earlier false premise, lost state, progress error, prerequisite
decision, action defect, or strict System fact that C causally consumes.  Mere
adjacency, an observation of a consequence, or a merely improvable action is
not material.  For C=1 emit not_applicable with null basis/correction/
consequence.  For C>1 emit either material_candidate with complete causal
fields, or not_material with null basis/correction/consequence.

PHASE E — NEUTRAL STEP ARBITRATION

Form the union of Phase A, Phase B, any Phase-C candidate, and any parent-
derived Phase-D candidate; deduplicate equal SC IDs.  candidate_assessments
must contain every unique nominated SC ID exactly once.  Judge causal
directness and counterfactual correction, not locator name, chronology, ID
number, list position, or nomination count.  Neither chronological nor local
is a default.  A causally used earlier false premise outranks its downstream
answer or repetition; a direct literal breach outranks generic inefficiency;
an independent explicit external failure outranks later recovery repetition
unless a concrete earlier agent defect caused it.  Output only the selected SC
ID and causal prose.  The selected candidate's own root_status must be
direct_root or causal_predecessor; never select a candidate that you assessed
as downstream_symptom or weak_or_ambiguous.  Do not output selection_basis or selected lane;
the parent derives candidate provenance.

PHASE F — OWNER/TYPE CLASSIFICATION AT THE FROZEN STEP

Now inspect all EA cards at the selected step.  Select the one atom whose exact
source owns the frozen defect, then choose only an allowed_error_type printed
on that atom.  Memory owns lost/invented state; Reflection owns false feedback,
progress, or cause interpretation; Planning owns strategy/prerequisite defects
when upstream state is sound; Action owns departure from an adequate plan or a
mechanical invocation defect; System owns only strict admitted evidence.  A
faithful action does not steal its plan's defect.  System ownership is legal
only when at least one nomination for the selected step used
observable_system_boundary; if every nomination at that step used that System
basis, ownership must remain System.  Classification reports only owner_atom_id,
predicted_error_type, and rejected_adjacent_owner—never step, module, quote,
source, locator, or selection basis.

Nested tags use innermost leaf ownership.  Planning residual is confined to an
explicit Planning/think span after foreign nested owners are removed; top-level
residual is never Planning.  Isolated malformed action blocks remain eligible
Action evidence for every legal Action type, without pre-deciding the type.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

OUTPUT CONTRACT
{_decision_contract()}

PARENT-BUILT STEP AND EVIDENCE CATALOGS
{catalogs}

GOLD-FREE ANONYMOUS JUDGEVIEW
{timeline}
"""


def validate_agent_judge_luna_v15_unified_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    """Validate final predictions against exact v15 owner-bound atoms."""

    audit = _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_leaf_and_residual_owner_source_resolver,
    )
    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    output_path = Path(predictions_path).expanduser().resolve()
    _, cases = load_prediction_manifest(manifest_path)
    raw_predictions = _load_json(output_path, role="predictions")
    if not isinstance(raw_predictions, list) or len(raw_predictions) != len(cases):
        raise AssertionError("shared v15 validation did not freeze prediction count")

    catalog_records: list[dict[str, Any]] = []
    for index, (case, prediction) in enumerate(
        zip(cases, raw_predictions, strict=True), 1
    ):
        if not isinstance(prediction, Mapping):
            raise AssertionError("shared v15 validation did not freeze records")
        atoms = _evidence_atoms(case)
        matches = [
            atom
            for atom in atoms
            if atom["step"] == prediction["predicted_step"]
            and atom["owner_module"] == prediction["predicted_module"]
            and atom["quote"] == prediction["evidence_quote"]
            and prediction["predicted_error_type"] in atom["allowed_error_types"]
        ]
        if len(matches) != 1:
            raise AgentJudgeValidationError(
                "invalid_evidence_atom_binding",
                (
                    f"predictions[{index - 1}] does not exactly match one "
                    "v15 owner-bound evidence atom"
                ),
            )
        selected_atom = matches[0]
        cards = _step_cards(case, atoms)
        catalog_records.append(
            {
                "case_index": index,
                "trajectory_id": case.trajectory_id,
                "atom_count": len(atoms),
                "catalog_sha256": _atom_catalog_sha256(atoms),
                "step_catalog_sha256": _step_catalog_sha256(cards),
                "selected_evidence_atom_id": selected_atom["evidence_atom_id"],
                "selected_step_card_id": f"{_STEP_PREFIX}{selected_atom['step']:04d}",
            }
        )
    catalog_set_sha256 = hashlib.sha256(
        json.dumps(
            catalog_records,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_V15_UNIFIED_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_V15_UNIFIED_VERSION,
        "model": AGENT_JUDGE_LUNA_V15_UNIFIED_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V15_UNIFIED_REASONING_EFFORT,
        "proposal_free": True,
        "historical_predictions_visible": False,
        "same_session_hypothesis_count": 3,
        "label_pair_routing_used": False,
        "nested_module_spans_supported": True,
        "step_owner_decoupled": True,
        "predecessor_step_parent_derived": True,
        "evidence_atom_binding": True,
        "all_predictions_match_exact_evidence_atom": True,
        "evidence_atom_catalogs": catalog_records,
        "evidence_atom_catalog_set_sha256": catalog_set_sha256,
        "model_copies_boundary_quote": False,
        "validation_method": (
            "Gold-free exact JSON, cohort/manifest order, trajectory identity, "
            "step range, taxonomy pair, selected-owner evidence, and exact "
            "v15 step-first owner-bound evidence-atom checks."
        ),
    }


__all__ = [
    "AGENT_JUDGE_LUNA_V15_UNIFIED_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_V15_UNIFIED_MODEL",
    "AGENT_JUDGE_LUNA_V15_UNIFIED_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_V15_UNIFIED_VERSION",
    "DECISION_FILENAME",
    "build_agent_judge_luna_v15_unified_task",
    "build_luna_v15_evidence_atom_catalog",
    "decision_output_schema",
    "runtime_conformance_decision",
    "validate_agent_judge_luna_v15_unified_predictions",
    "validate_luna_v15_unified_decision",
]

"""Owner-aware exact evidence contracts for the E8 semantic judge."""

from __future__ import annotations

from typing import Any, Mapping

from .evidence_repair import (
    EVIDENCE_REPAIR_MAX_ATTEMPTS,
    EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION,
    EvidenceRepairRequest,
    FrozenSemanticRoot,
    evidence_repair_messages,
)
from .judge_view import JudgeStep, JudgeView
from .models import (
    EvidenceValidation,
    RootCauseJudgment,
    ValidationIssue,
    ValidationLevel,
)
from .taxonomy import AgentModule, is_valid_classification


FRESH_EVIDENCE_VALIDATION_VERSION = (
    "agentdebug.e8-evidence-validation.v2-exact-owner-current-step-source"
)
FRESH_EVIDENCE_REPAIR_PIPELINE_VERSION = (
    "e8-one-shot-owner-aware-evidence-only-repair-v2"
)
FRESH_EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION = (
    "agentdebug-e8-evidence-repair-v2-frozen-semantics-current-step-source"
)
FRESH_EVIDENCE_REPAIR_MAX_ATTEMPTS = EVIDENCE_REPAIR_MAX_ATTEMPTS


def _string_leaves(value: Any) -> tuple[str, ...]:
    if isinstance(value, str):
        return (value,)
    if isinstance(value, Mapping):
        return tuple(
            text
            for item in value.values()
            for text in _string_leaves(item)
        )
    if isinstance(value, (list, tuple)):
        return tuple(
            text for item in value for text in _string_leaves(item)
        )
    return ()


def _append(values: list[str], seen: set[str], value: Any) -> None:
    if isinstance(value, str) and value and value not in seen:
        seen.add(value)
        values.append(value)


def fresh_owner_source_strings(
    view: JudgeView,
    *,
    critical_step: int,
    module: AgentModule,
) -> tuple[str, ...]:
    """Return exact source strings owned by one selected module at one step."""

    if not isinstance(view, JudgeView):
        raise TypeError("E8 evidence requires a JudgeView")
    if (
        isinstance(critical_step, bool)
        or not isinstance(critical_step, int)
        or critical_step < 1
        or critical_step > len(view.steps)
    ):
        raise ValueError("critical_step must identify one JudgeView step")
    if not isinstance(module, AgentModule):
        raise TypeError("module must be an AgentModule")
    step: JudgeStep = view.steps[critical_step - 1]
    values: list[str] = []
    seen: set[str] = set()

    if module != AgentModule.SYSTEM:
        for span in step.module_spans:
            if span.module == module.value:
                _append(
                    values,
                    seen,
                    step.assistant_raw_output[
                        span.content_start_char : span.content_end_char
                    ],
                )
        if module == AgentModule.ACTION:
            for call in step.tool_calls:
                _append(values, seen, call.name)
                for text in _string_leaves(call.arguments):
                    _append(values, seen, text)
                for text in _string_leaves(call.partial_arguments):
                    _append(values, seen, text)
    else:
        for observation in step.current_input:
            projection = observation.benchmark_input
            if projection is not None:
                for start, end in (
                    (
                        projection.step_marker_start_char,
                        projection.step_marker_end_char,
                    ),
                    (
                        projection.observation_start_char,
                        projection.observation_end_char,
                    ),
                    (
                        projection.interface_start_char,
                        projection.interface_end_char,
                    ),
                    (
                        projection.suffix_start_char,
                        projection.suffix_end_char,
                    ),
                ):
                    _append(
                        values,
                        seen,
                        observation.text[start:end],
                    )
            elif observation.repeated_prefix_chars > 0:
                _append(values, seen, observation.incremental_text)
            else:
                _append(values, seen, observation.text)
        for call in step.tool_calls:
            for result in call.results:
                _append(values, seen, result.output)
                for text in _string_leaves(result.details):
                    _append(values, seen, text)
        for observation in step.adjacent_feedback:
            _append(
                values,
                seen,
                (
                    observation.incremental_text
                    if observation.repeated_prefix_chars > 0
                    else observation.text
                ),
            )
        _append(values, seen, step.stop_reason)
        _append(values, seen, step.error_message)
    return tuple(values)


def validate_fresh_semantic_evidence(
    view: JudgeView,
    root: RootCauseJudgment,
    *,
    stage: str,
) -> EvidenceValidation:
    """Require a case-sensitive quote from the selected owner's source."""

    if not isinstance(view, JudgeView):
        raise TypeError("E8 evidence validation requires a JudgeView")
    if not isinstance(root, RootCauseJudgment):
        raise TypeError("E8 evidence validation requires a semantic root")
    if not isinstance(stage, str) or not stage.strip():
        raise ValueError("E8 evidence stage must be non-empty text")
    issues: list[ValidationIssue] = []

    def add(code: str, message: str) -> None:
        issues.append(
            ValidationIssue(
                code=code,
                level=ValidationLevel.ERROR,
                stage=stage,
                message=message,
                entity_ids=[
                    item
                    for item in (
                        root.critical_event_id,
                        *root.evidence_event_ids,
                    )
                    if item
                ],
            )
        )

    try:
        valid_pair = is_valid_classification(
            root.module,
            root.error_type,
        )
    except (KeyError, TypeError):
        valid_pair = False
    if not valid_pair:
        add(
            "invalid_taxonomy_pair",
            "The selected module/error_type pair is outside the taxonomy.",
        )
    if (
        root.critical_step < 1
        or root.critical_step > len(view.steps)
        or view.event_for_step(root.critical_step)
        != root.critical_event_id
    ):
        add(
            "unknown_critical_event",
            "The selected step/event does not identify one JudgeView turn.",
        )
        sources: tuple[str, ...] = ()
    else:
        sources = fresh_owner_source_strings(
            view,
            critical_step=root.critical_step,
            module=root.module,
        )
    if not sources:
        add(
            "owner_evidence_source_unavailable",
            "The selected module exposes no owner-specific source at the step.",
        )
    elif not any(root.evidence_quote in source for source in sources):
        add(
            "owner_evidence_quote_not_found",
            (
                "Evidence is not a contiguous, case-sensitive substring of "
                "one source owned by the selected module at the selected step."
            ),
        )
    return EvidenceValidation(
        valid=not issues,
        needs_review=False,
        issues=issues,
    )


def build_fresh_evidence_repair_request(
    view: JudgeView,
    root: RootCauseJudgment,
) -> EvidenceRepairRequest:
    """Freeze semantics and expose only selected-owner evidence sources."""

    sources = fresh_owner_source_strings(
        view,
        critical_step=root.critical_step,
        module=root.module,
    )
    if not sources:
        raise ValueError(
            "selected E8 owner exposes no evidence-repair source"
        )
    return EvidenceRepairRequest(
        trace_id=view.trace_id,
        judge_view_version=view.version,
        step_count=len(view.steps),
        critical_event_id=root.critical_event_id,
        evidence_event_ids=tuple(root.evidence_event_ids),
        semantic_root=FrozenSemanticRoot(
            critical_step=root.critical_step,
            module=root.module,
            error_type=root.error_type,
            root_cause=root.root_cause,
        ),
        invalid_evidence=root.evidence_quote,
        source_strings=sources,
    )


def fresh_evidence_repair_messages(
    request: EvidenceRepairRequest,
) -> list[dict[str, str]]:
    """Use the shared frozen-semantic repair with an E8 protocol identity."""

    messages = evidence_repair_messages(request)
    user = messages[1]["content"].replace(
        EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION,
        FRESH_EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION,
        1,
    )
    return [dict(messages[0]), {"role": "user", "content": user}]


__all__ = [
    "FRESH_EVIDENCE_REPAIR_MAX_ATTEMPTS",
    "FRESH_EVIDENCE_REPAIR_PIPELINE_VERSION",
    "FRESH_EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION",
    "FRESH_EVIDENCE_VALIDATION_VERSION",
    "build_fresh_evidence_repair_request",
    "fresh_evidence_repair_messages",
    "fresh_owner_source_strings",
    "validate_fresh_semantic_evidence",
]

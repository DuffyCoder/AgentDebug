"""Luna GAIA v3.8: v3.6 semantics plus structured claim support."""

from __future__ import annotations

import argparse
import copy
import json
import os
from pathlib import Path
from typing import Any, Sequence

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
)
from .agent_judge_luna_gaia_v3 import (
    STEP_FREEZE_FIELDS,
    STEP_FREEZE_FILENAME,
    _file_sha256,
)
from .agent_judge_luna_gaia_v3_1 import (
    validate_agent_judge_luna_gaia_v3_1_predictions,
)
from .agent_judge_luna_gaia_v3_4 import (
    STEP_CANDIDATE_LEDGER_FIELDS,
    STEP_CANDIDATE_LEDGER_FILENAME,
    STEP_CANDIDATE_LANES,
    STEP_CANDIDATE_STATUSES,
    _validate_step_candidate_ledger_document,
)
from .agent_judge_luna_gaia_v3_6 import (
    AGENT_JUDGE_LUNA_GAIA_V3_6_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_LUNA_GAIA_V3_6_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_6_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_6_VERSION,
    build_agent_judge_luna_gaia_v3_6_task,
)
from .agent_judge_luna_gaia_v3_7_1 import (
    STEP_CANDIDATE_LEDGER_DRAFT_FILENAME,
    _compact_failure,
    _load_single_case,
    _packet_sources,
    _read_ledger,
)


AGENT_JUDGE_LUNA_GAIA_V3_8_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.8"
)
AGENT_JUDGE_LUNA_GAIA_V3_8_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_6_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_8_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_6_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_8_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_6_AUDIT_SCHEMA_VERSION
)

CLAIM_STATE_FIELD = "claim_state"
CLAIM_STATE_FIELDS = (
    "claim_kind",
    "claim_source",
    "support_step",
    "support_status",
    "lane_a_disposition",
)
CLAIM_KINDS = frozenset(
    {
        "no_material_claim",
        "requested_entity_attribute",
        "result_presence_or_absence",
        "progress_or_completion",
        "causal_explanation",
        "other_task_state",
    }
)
CLAIM_SOURCES = frozenset({"memory", "reflection"})
CLAIM_SUPPORT_STATUSES = frozenset(
    {
        "not_applicable",
        "supported",
        "unsupported",
        "contradicted",
        "salient_omission",
    }
)
CLAIM_LANE_A_DISPOSITIONS = frozenset({"clear", "candidate"})
_CLAIM_FAILURE_STATUSES = frozenset(
    {"unsupported", "contradicted", "salient_omission"}
)

STEP_CANDIDATE_ROW_FIELDS = (
    "step",
    CLAIM_STATE_FIELD,
    "lane_a",
    "lane_b",
    "system",
    "lane_c",
    "surviving_lane",
    "evidence_quote",
    "decision_basis",
)


_STRUCTURED_CLAIM_SUPPORT_GATE = """\
STRUCTURED LANE-A CLAIM-SUPPORT GATE

Apply this gate only to Lane A.  It changes no Lane-B source, prerequisite,
capability, target, or Action rule; no System packet ordering; no recovery
veto; no Lane-C strategy rule; and no downstream owner/type/evidence rule.

Memory and Reflection occur before the current action.  Audit their claims
using only the task and literal observations from earlier completed step
packets.  Never use the current action's adjacent feedback to support an
earlier claim in the same assistant packet.  Do not use recalled world
knowledge, plausibility, a later recovery, or a later repeated claim as
support.

Before assigning `lane_a`, record exactly one `claim_state` object for the
row.  It contains, in order: `claim_kind`, `claim_source`, `support_step`,
`support_status`, and `lane_a_disposition`.

Inspect every task-material Memory and Reflection assertion.  If any assertion
is unsupported, contradicted, or omits a salient requested result, record the
first such assertion.  Otherwise record the most task-material supported
assertion.  Use `no_material_claim` only when neither module makes a concrete
task-state assertion.  The claim kinds are:

- `requested_entity_attribute`: an entity is assigned a requested author,
  institution, date, identifier, value, or other task attribute;
- `result_presence_or_absence`: a result is said to contain or lack a requested
  article, link, source, entity, or fact;
- `progress_or_completion`: open checklist items, progress, success, or
  completeness are asserted;
- `causal_explanation`: a result or failure is assigned a cause;
- `other_task_state`: another concrete Memory/Reflection task-state assertion;
- `no_material_claim`: no concrete task-state assertion is present.

`claim_source` is `memory` or `reflection` for a material claim and null only
for `no_material_claim`.  This locates the assertion for Lane-A inspection; it
does not bypass the later same-step owner decision.

`support_step` is a support pointer, not the predicted failure step:

- use 0 only when task text itself literally supports or contradicts the
  assertion;
- use an earlier positive step number only when that completed step's literal
  observation supports, contradicts, or contains the salient omitted result;
- use null for `unsupported` because no literal support pointer exists;
- never point to the current or a future step.

Assign exactly one support status:

- `supported`: the complete asserted entity-to-attribute or result-state link
  is literal in the pointed task/observation;
- `unsupported`: no prior literal observation establishes the asserted link;
- `contradicted`: the pointed task/observation says or demonstrates the
  opposite;
- `salient_omission`: the pointed prior result visibly contains the requested
  article, link, entity, or fact that the claim says was absent or ignores;
- `not_applicable`: only with `no_material_claim`.

An entity and an attribute appearing separately is not support for their
relationship.  A search query, planned target, snippet about another person,
or generic page context is not support for a requested entity-attribute link.
When a prior result visibly contains a requested direct link, title, or fact,
a later “no relevant/direct result” summary is `salient_omission`, even if the
route still needs more verification.

Derive `lane_a_disposition` mechanically.  `unsupported`, `contradicted`, and
`salient_omission` mean `candidate` and require `lane_a: candidate`.
`supported` and `no_material_claim` mean `clear` and require `lane_a: clear`.
Free-text `decision_basis` cannot override this object.  A new search target,
source, host, modality, or later recovery cannot clear a Lane-A claim defect.

"""


_NO_CLAIM_STATE = """\
      "claim_state": {
        "claim_kind": "no_material_claim",
        "claim_source": null,
        "support_step": null,
        "support_status": "not_applicable",
        "lane_a_disposition": "clear"
      },
"""

_UNSUPPORTED_CLAIM_STATE = """\
      "claim_state": {
        "claim_kind": "requested_entity_attribute",
        "claim_source": "memory",
        "support_step": null,
        "support_status": "unsupported",
        "lane_a_disposition": "candidate"
      },
"""


def _claim_error(code: str, message: str) -> None:
    raise AgentJudgeValidationError(code, message)


def _validate_claim_state(
    state: Any,
    *,
    step: int,
    lane_a: str,
) -> None:
    location = f"step ledger row {step}.claim_state"
    if not isinstance(state, dict) or tuple(state) != CLAIM_STATE_FIELDS:
        _claim_error(
            "invalid_claim_state_schema",
            f"{location} has unexpected fields or field order",
        )

    kind = state["claim_kind"]
    source = state["claim_source"]
    support_step = state["support_step"]
    status = state["support_status"]
    disposition = state["lane_a_disposition"]
    if kind not in CLAIM_KINDS:
        _claim_error("invalid_claim_kind", f"{location}.claim_kind")
    if status not in CLAIM_SUPPORT_STATUSES:
        _claim_error("invalid_claim_support_status", f"{location}.support_status")
    if disposition not in CLAIM_LANE_A_DISPOSITIONS:
        _claim_error(
            "invalid_claim_lane_a_disposition",
            f"{location}.lane_a_disposition",
        )

    if kind == "no_material_claim":
        if (
            source is not None
            or support_step is not None
            or status != "not_applicable"
            or disposition != "clear"
            or lane_a != "clear"
        ):
            _claim_error(
                "invalid_no_material_claim_state",
                f"{location} no-material state must be null/not_applicable/clear",
            )
        return

    if source not in CLAIM_SOURCES:
        _claim_error(
            "invalid_claim_source",
            f"{location}.claim_source must be memory or reflection",
        )
    if status == "not_applicable":
        _claim_error(
            "invalid_material_claim_status",
            f"{location} material claim cannot be not_applicable",
        )

    if status == "unsupported":
        if support_step is not None:
            _claim_error(
                "invalid_unsupported_claim_pointer",
                f"{location} unsupported claim cannot have a support pointer",
            )
    elif (
        isinstance(support_step, bool)
        or not isinstance(support_step, int)
        or support_step < 0
        or support_step >= step
    ):
        _claim_error(
            "invalid_claim_support_step",
            f"{location}.support_step must be task step 0 or an earlier step",
        )
    if status == "salient_omission" and support_step == 0:
        _claim_error(
            "invalid_salient_omission_pointer",
            f"{location} salient omission must point to an earlier result step",
        )

    expected = "candidate" if status in _CLAIM_FAILURE_STATUSES else "clear"
    if disposition != expected or lane_a != expected:
        _claim_error(
            "claim_lane_a_mismatch",
            f"{location} support status is inconsistent with Lane A",
        )


def _validate_claim_ledger_document(
    value: Any,
    *,
    trajectory_id: str,
    step_count: int,
    predicted_step: int,
    selected_packet_sources: Sequence[str],
) -> None:
    """Validate claim support, then the inherited v3.6-compatible ledger."""

    if not isinstance(value, dict) or tuple(value) != STEP_CANDIDATE_LEDGER_FIELDS:
        _claim_error(
            "invalid_step_candidate_ledger_schema",
            "step ledger must contain only trajectory_id, rows, selected_step",
        )
    rows = value.get("rows")
    if not isinstance(rows, list):
        _claim_error("invalid_step_candidate_ledger_rows", "rows must be a list")

    compatibility = copy.deepcopy(value)
    compatibility_rows = compatibility["rows"]
    for index, row in enumerate(rows, start=1):
        if not isinstance(row, dict) or tuple(row) != STEP_CANDIDATE_ROW_FIELDS:
            _claim_error(
                "invalid_step_candidate_row_schema",
                f"step ledger row {index} has unexpected fields or field order",
            )
        if row.get("evidence_quote") is not None:
            _claim_error(
                "non_null_step_candidate_evidence",
                "step-only ledger evidence_quote must remain null on every row",
            )
        _validate_claim_state(
            row[CLAIM_STATE_FIELD],
            step=index,
            lane_a=row["lane_a"],
        )
        del compatibility_rows[index - 1][CLAIM_STATE_FIELD]

    nonempty_source = next(
        (source for source in selected_packet_sources if source),
        None,
    )
    if nonempty_source is None:
        _claim_error(
            "missing_selected_step_packet_text",
            "selected step packet has no text for downstream evidence audit",
        )
    if compatibility_rows:
        compatibility_rows[-1]["evidence_quote"] = nonempty_source[:1]
    _validate_step_candidate_ledger_document(
        compatibility,
        trajectory_id=trajectory_id,
        step_count=step_count,
        predicted_step=predicted_step,
        selected_packet_sources=selected_packet_sources,
    )


def validate_and_freeze_agent_judge_luna_gaia_v3_8_ledger(
    prediction_manifest_path: str | Path,
    draft_ledger_path: str | Path,
    final_ledger_path: str | Path,
) -> dict[str, Any]:
    """Validate a mutable claim ledger, then atomically freeze it."""

    draft = Path(draft_ledger_path).expanduser().resolve()
    final = Path(final_ledger_path).expanduser().resolve()
    _assert_safe_path(draft, role="step candidate ledger draft", is_output=True)
    _assert_safe_path(final, role="step candidate ledger output", is_output=True)
    if draft == final or draft.parent != final.parent:
        _claim_error(
            "invalid_ledger_freeze_paths",
            "draft and final ledger must be distinct files in the same directory",
        )
    if draft.name != STEP_CANDIDATE_LEDGER_DRAFT_FILENAME:
        _claim_error(
            "invalid_ledger_draft_name",
            f"draft ledger must be named {STEP_CANDIDATE_LEDGER_DRAFT_FILENAME}",
        )
    if final.name != STEP_CANDIDATE_LEDGER_FILENAME:
        _claim_error(
            "invalid_ledger_final_name",
            f"final ledger must be named {STEP_CANDIDATE_LEDGER_FILENAME}",
        )
    if final.exists():
        _claim_error(
            "immutable_ledger_exists",
            "final step candidate ledger already exists and cannot be overwritten",
        )

    case = _load_single_case(prediction_manifest_path)
    ledger = _read_ledger(draft, role="step candidate ledger draft")
    selected_step = ledger.get("selected_step") if isinstance(ledger, dict) else None
    sources = _packet_sources(case, selected_step)
    _validate_claim_ledger_document(
        ledger,
        trajectory_id=case.trajectory_id,
        step_count=len(case.judge_view.steps),
        predicted_step=selected_step,
        selected_packet_sources=sources,
    )

    try:
        os.link(draft, final)
    except FileExistsError as error:
        raise AgentJudgeValidationError(
            "immutable_ledger_exists",
            "final step candidate ledger appeared during freeze",
        ) from error
    except OSError as error:
        raise AgentJudgeValidationError(
            "ledger_freeze_failed",
            f"could not atomically freeze validated ledger: {error}",
        ) from error
    try:
        draft.unlink()
    except OSError as error:
        raise AgentJudgeValidationError(
            "ledger_draft_cleanup_failed",
            f"ledger froze but draft cleanup failed: {error}",
        ) from error
    return {
        "valid": True,
        "frozen": True,
        "path": str(final),
        "sha256": _file_sha256(final),
        "row_count": len(ledger["rows"]),
        "selected_step": selected_step,
        "surviving_lane": ledger["rows"][-1]["surviving_lane"],
    }


def _validate_claim_ledger(
    prediction_manifest_path: str | Path,
    predictions_path: Path,
) -> dict[str, Any]:
    case = _load_single_case(prediction_manifest_path)
    try:
        predictions = json.loads(predictions_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise AgentJudgeValidationError(
            "invalid_predictions_json",
            "predictions are unavailable for step ledger validation",
        ) from error
    if not isinstance(predictions, list) or len(predictions) != 1:
        _claim_error(
            "invalid_step_candidate_ledger_scope",
            "step ledger validation requires exactly one prediction",
        )

    ledger_path = predictions_path.parent / STEP_CANDIDATE_LEDGER_FILENAME
    ledger = _read_ledger(ledger_path, role="step candidate ledger")
    selected_step = predictions[0].get("predicted_step")
    sources = _packet_sources(case, selected_step)
    _validate_claim_ledger_document(
        ledger,
        trajectory_id=case.trajectory_id,
        step_count=len(case.judge_view.steps),
        predicted_step=selected_step,
        selected_packet_sources=sources,
    )
    return {
        "required": True,
        "valid": True,
        "path": str(ledger_path.resolve()),
        "sha256": _file_sha256(ledger_path),
        "row_count": len(ledger["rows"]),
        "selected_step": ledger["selected_step"],
        "surviving_lane": ledger["rows"][-1]["surviving_lane"],
        "evidence_deferred_to_final_prediction": True,
        "claim_support_state_validated": True,
        "precommit_freeze_required": True,
    }


def build_agent_judge_luna_gaia_v3_8_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build v3.6 semantics with one structured Lane-A support gate."""

    task = build_agent_judge_luna_gaia_v3_6_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    task = task.replace(
        AGENT_JUDGE_LUNA_GAIA_V3_6_VERSION,
        AGENT_JUDGE_LUNA_GAIA_V3_8_VERSION,
    )
    task = task.replace(
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_6.py",
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_8.py",
    )
    task = task.replace(
        "agentdebug.diagnostics.agent_judge_luna_gaia_v3_6",
        "agentdebug.diagnostics.agent_judge_luna_gaia_v3_8",
    )

    lane_b = "LANE B — HARD TASK, INTERFACE, AND EXECUTION CONDITIONS\n"
    if task.count(lane_b) != 1:
        raise RuntimeError("Luna GAIA v3.6 lane-B boundary changed unexpectedly")
    task = task.replace(
        lane_b,
        _STRUCTURED_CLAIM_SUPPORT_GATE + lane_b,
        1,
    )

    clear_row = '      "lane_a": "clear",\n      "lane_b": "clear",'
    candidate_row = '      "lane_a": "candidate",\n      "lane_b": "clear",'
    if task.count(clear_row) != 1 or task.count(candidate_row) != 1:
        raise RuntimeError("Luna GAIA v3.6 ledger examples changed unexpectedly")
    task = task.replace(
        clear_row,
        _NO_CLAIM_STATE + clear_row,
        1,
    )
    task = task.replace(
        candidate_row,
        _UNSUPPORTED_CLAIM_STATE + candidate_row,
        1,
    )

    predictions = Path(predictions_path).expanduser().resolve()
    final_ledger = predictions.parent / STEP_CANDIDATE_LEDGER_FILENAME
    draft_ledger = predictions.parent / STEP_CANDIDATE_LEDGER_DRAFT_FILENAME
    final_line = f"- write immutable step candidate ledger only to: {final_ledger}"
    if task.count(final_line) != 1:
        raise RuntimeError("Luna GAIA v3.6 output boundary changed unexpectedly")
    task = task.replace(
        final_line,
        f"- write revisable pre-commit ledger draft only to: {draft_ledger}\n"
        f"- freeze immutable step candidate ledger only to: {final_ledger}",
        1,
    )
    allow_line = f"- {final_ledger} only after writing the frozen step candidate ledger"
    if task.count(allow_line) != 1:
        raise RuntimeError("Luna GAIA v3.6 ledger allowlist changed unexpectedly")
    task = task.replace(
        allow_line,
        f"- {draft_ledger} only after writing this run's pre-commit draft\n"
        f"- {final_ledger} only after the validator freezes it",
        1,
    )

    old_order = (
        "LANE-ORDERED CHRONOLOGICAL SCAN -> WRITE STEP CANDIDATE LEDGER ->\n"
        "WRITE IMMUTABLE STEP CHECKPOINT -> SAME-STEP OWNER -> TAXONOMY TYPE ->\n"
        "LITERAL EVIDENCE -> FINAL PREDICTION"
    )
    new_order = (
        "LANE-ORDERED CHRONOLOGICAL SCAN -> PRE-COMMIT CLAIM REVIEW ->\n"
        "VALIDATE AND FREEZE STEP CANDIDATE LEDGER -> WRITE IMMUTABLE STEP\n"
        "CHECKPOINT -> SAME-STEP OWNER -> TAXONOMY TYPE -> LITERAL EVIDENCE ->\n"
        "FINAL PREDICTION"
    )
    if task.count(old_order) != 1:
        raise RuntimeError("Luna GAIA v3.6 decision order changed unexpectedly")
    task = task.replace(old_order, new_order, 1)

    old_write = (
        "Write this file once and never edit it.\n"
        "Then derive and write the two-field step checkpoint from its last row before\n"
        "considering owner/type/evidence."
    )
    repo_root = Path(__file__).resolve().parents[2]
    freeze_command = (
        "PYTHONPATH=. python3 -m "
        "agentdebug.diagnostics.agent_judge_luna_gaia_v3_8 "
        f"--compact-ledger-freeze "
        f"{Path(prediction_manifest_path).expanduser().resolve()} "
        f"{draft_ledger} {final_ledger}"
    )
    new_write = f"""Write the complete ledger first to `{draft_ledger}`.  Before freezing it,
perform one read-only claim review of every row.  Verify that every material
Memory/Reflection assertion has the correct claim kind and source; that the
support pointer is task step 0 or an earlier completed observation only; and
that support status, Lane-A disposition, and `lane_a` agree.  Then recheck the
selected row's first-surviving lane.  Do not assign final owner/type during
this review.

Then run exactly:

cd {repo_root}
{freeze_command}

If pre-commit validation fails, correct only the draft field identified by the
compact code/message and rerun.  The command atomically creates
`{final_ledger}` only after the whole draft passes.  Once it succeeds, never
edit or replace the final ledger.  Derive the two-field step checkpoint from
its last row before considering owner/type/evidence."""
    if task.count(old_write) != 1:
        raise RuntimeError("Luna GAIA v3.6 ledger write boundary changed unexpectedly")
    task = task.replace(old_write, new_write, 1)
    return task


def validate_agent_judge_luna_gaia_v3_8_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    prediction_path = Path(predictions_path).expanduser().resolve()
    audit = validate_agent_judge_luna_gaia_v3_1_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction_path,
    )
    ledger = (
        _validate_claim_ledger(prediction_manifest_path, prediction_path)
        if audit["case_count"] == 1
        else {
            "required": False,
            "valid": None,
            "reason": "merged full-cohort validation follows validated shards",
        }
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_8_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_8_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_8_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_8_REASONING_EFFORT,
        "selection_policy": (
            "lane_ordered_chronology_validated_step_only_candidate_ledger_"
            "precommit_freeze_limited_recovery_veto_external_exception_packet_"
            "fence_positive_immediate_subgoal_capability_gate_positive_action_"
            "materiality_gate_structured_lane_a_claim_support"
        ),
        "step_candidate_ledger": ledger,
        "positive_capability_admission_gate": (
            "any_necessary_evidence_for_current_immediate_subgoal"
        ),
        "step_ledger_evidence_policy": "deferred_to_final_prediction",
        "positive_action_materiality_gate": (
            "rejection_semantic_change_or_false_state_consumption_required"
        ),
        "claim_support_gate": (
            "literal_prior_support_for_task_material_memory_reflection_claims"
        ),
    }


def validate_and_write_agent_judge_luna_gaia_v3_8_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_8_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


def run_agent_judge_luna_gaia_v3_8_compact_validation(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> int:
    try:
        audit = validate_and_write_agent_judge_luna_gaia_v3_8_audit(
            prediction_manifest_path,
            cohort_manifest_path,
            predictions_path,
            audit_path,
        )
    except Exception as error:
        return _compact_failure(error)
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    return 0


def run_agent_judge_luna_gaia_v3_8_compact_ledger_freeze(
    prediction_manifest_path: str | Path,
    draft_ledger_path: str | Path,
    final_ledger_path: str | Path,
) -> int:
    try:
        result = validate_and_freeze_agent_judge_luna_gaia_v3_8_ledger(
            prediction_manifest_path,
            draft_ledger_path,
            final_ledger_path,
        )
    except Exception as error:
        return _compact_failure(error)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--compact-validate", action="store_true")
    mode.add_argument("--compact-ledger-freeze", action="store_true")
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if args.compact_ledger_freeze:
        if len(args.paths) != 3:
            raise SystemExit("--compact-ledger-freeze requires exactly 3 paths")
        return run_agent_judge_luna_gaia_v3_8_compact_ledger_freeze(*args.paths)
    if len(args.paths) != 4:
        raise SystemExit("--compact-validate requires exactly 4 paths")
    return run_agent_judge_luna_gaia_v3_8_compact_validation(*args.paths)


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "AGENT_JUDGE_LUNA_GAIA_V3_8_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_GAIA_V3_8_MODEL",
    "AGENT_JUDGE_LUNA_GAIA_V3_8_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_GAIA_V3_8_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "CLAIM_KINDS",
    "CLAIM_LANE_A_DISPOSITIONS",
    "CLAIM_SOURCES",
    "CLAIM_STATE_FIELDS",
    "CLAIM_SUPPORT_STATUSES",
    "STEP_CANDIDATE_LEDGER_DRAFT_FILENAME",
    "STEP_CANDIDATE_LEDGER_FIELDS",
    "STEP_CANDIDATE_LEDGER_FILENAME",
    "STEP_CANDIDATE_LANES",
    "STEP_CANDIDATE_ROW_FIELDS",
    "STEP_CANDIDATE_STATUSES",
    "STEP_FREEZE_FIELDS",
    "STEP_FREEZE_FILENAME",
    "build_agent_judge_luna_gaia_v3_8_task",
    "main",
    "run_agent_judge_luna_gaia_v3_8_compact_ledger_freeze",
    "run_agent_judge_luna_gaia_v3_8_compact_validation",
    "validate_agent_judge_luna_gaia_v3_8_predictions",
    "validate_and_freeze_agent_judge_luna_gaia_v3_8_ledger",
    "validate_and_write_agent_judge_luna_gaia_v3_8_audit",
]

"""Luna GAIA v3.29: clean v3.20 with a zero-contribution challenger gate."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from .agent_judge_luna_gaia_v3_4 import STEP_CANDIDATE_LEDGER_FILENAME


AGENT_JUDGE_LUNA_GAIA_V3_29_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.29-clean-v3.20-"
    "acquisition-anchor-zero-contribution-challenger"
)
AGENT_JUDGE_LUNA_GAIA_V3_29_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_29_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_29_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases used by the shared three-stage runner.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_29_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_29_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_29_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_29_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = parent.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = parent.CHALLENGERS_FILENAME
ARBITER_FILENAME = parent.ARBITER_FILENAME
ARBITERS_FILENAME = parent.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = parent.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = parent.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME


_CONTRIBUTION_PREFIX = re.compile(
    r"^anchor_boundary_kind=(acquisition_probe|other); "
    r"anchor_contribution=(possible|observed|zero|not_applicable); "
)

_ZERO_CONTRIBUTION_GATE = """\
ACQUISITION-ANCHOR ZERO-CONTRIBUTION GATE — BINDING CHALLENGER CHECK

Before classifying the frozen anchor, determine whether the anchor Step is an
acquisition route: a plan or Action intended to obtain an external identifier,
page, title, source, text, transcript lead, number, or other evidence for the
immediate unresolved subgoal. Begin anchor_falsifier exactly:

`anchor_boundary_kind=<acquisition_probe|other>; anchor_contribution=<possible|observed|zero|not_applicable>; `

- Use `other/not_applicable` only when the anchor is not an acquisition route.
- Use `acquisition_probe/observed` when the anchor packet actually supplied a
  task-relevant intermediate.
- Use `acquisition_probe/possible` when no literal interface/corpus fact and no
  prior outcome rules out its supplying a necessary intermediate. Do not
  project inability to prove the final answer backward onto the immediate
  acquisition subgoal.
- Use `acquisition_probe/zero` only when literal interface/corpus semantics and
  chronology prove that even successful use cannot expose any necessary
  intermediate for that immediate subgoal.

For `possible` or `observed`, the anchor cannot be `critical_root` or
`uncertain`; classify it as `reasonable_probe` or `noncritical_predecessor`,
then run the existing strictly-later earliest-causal search. This does not
force a proposal: emit no_challenge if no single later Step is independently
failure-causing under anchor-only repair.

For `zero`, apply the incumbent rules unchanged. An already identified exact
video-frame, narration, timestamp, dynamic-page, or interactive-UI predicate
assigned directly to an interface that cannot observe it may remain a hard
capability root. A merely poor, indirect, or low-yield route is not `zero` if
it can still return a needed identifier, page, title, source, text, or lead.

This gate changes challenger evaluation only. Do not reinterpret or edit the
frozen anchor ledger/checkpoint, enumerate candidates, propose an earlier Step,
or weaken the one-proposal and default-keep contracts.

"""

_ARBITER_REVIEW = """\
ZERO-CONTRIBUTION REVIEW FOR THE FROZEN CHALLENGER

Audit the challenger prefix before deciding. A `possible` or `observed`
acquisition anchor is a reasonable probe/noncritical predecessor only when the
claimed intermediate contribution is supported by literal interface/corpus
and chronology evidence. Accept its one later proposal only if the incumbent
earliest-causal and path-intervention tests also pass. A `zero` record does not
authorize an override by itself. Reject hypothetical contribution, final-proof
projection in either direction, and later salience.

"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_29_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_29_clean_v3p20_"
            "acquisition_anchor_zero_contribution_challenger",
        )
    )


def build_anchor_task(*paths: str | Path) -> str:
    """Retag the frozen v3.20 anchor without changing its semantic rules."""

    return _rewrite_identity(parent.build_anchor_task(*paths))


def build_challenger_task(*paths: str | Path) -> str:
    task = _rewrite_identity(parent.build_challenger_task(*paths))
    marker = "EARLIEST-CAUSAL SINGLE-CHALLENGER RULE\n"
    if task.count(marker) != 1:
        raise RuntimeError("v3.20 challenger rule marker changed unexpectedly")
    task = task.replace(marker, _ZERO_CONTRIBUTION_GATE + marker, 1)
    task = task.replace(
        '"anchor_falsifier": "compact literal-evidence explanation"',
        '"anchor_falsifier": "anchor_boundary_kind=other; '
        'anchor_contribution=not_applicable; compact literal-evidence explanation"',
        1,
    )
    return task


def build_arbiter_task(*paths: str | Path) -> str:
    task = _rewrite_identity(parent.build_arbiter_task(*paths))
    marker = "EARLIEST-CAUSAL SINGLE-CHALLENGER RULE\n"
    if task.count(marker) != 1:
        raise RuntimeError("v3.20 arbiter rule marker changed unexpectedly")
    return task.replace(marker, _ARBITER_REVIEW + marker, 1)


def build_agent_judge_luna_gaia_v3_29_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / STEP_CANDIDATE_LEDGER_FILENAME,
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def _validate_zero_contribution_challengers(path: str | Path) -> dict[str, Any]:
    challenger_path, raw = shared._load_artifact(
        path, role="zero-contribution challenger"
    )
    records = raw if isinstance(raw, list) else [raw]
    if not records or any(not isinstance(item, dict) for item in records):
        shared._fail(
            "invalid_zero_contribution_challengers", "challenger records unavailable"
        )

    pair_counts: Counter[str] = Counter()
    classification_counts: Counter[str] = Counter()
    possible_observed_challenges = 0
    for index, record in enumerate(records):
        location = f"challenger[{index}]"
        match = _CONTRIBUTION_PREFIX.match(record.get("anchor_falsifier") or "")
        if match is None:
            shared._fail("missing_zero_contribution_prefix", location)
        boundary_kind, contribution = match.groups()
        classification = record.get("anchor_classification")
        if boundary_kind == "other":
            if contribution != "not_applicable":
                shared._fail("invalid_other_contribution_pair", location)
        elif contribution == "not_applicable":
            shared._fail("missing_acquisition_contribution", location)

        if contribution in {"possible", "observed"}:
            if classification not in {
                "reasonable_probe",
                "noncritical_predecessor",
            }:
                shared._fail(
                    "contributory_anchor_not_vetoed_by_challenger", location
                )
            if record.get("challenge_status") == "challenge":
                possible_observed_challenges += 1
        pair_counts[f"{boundary_kind}:{contribution}"] += 1
        classification_counts[str(classification)] += 1

    return {
        "required": True,
        "valid": True,
        "path": str(challenger_path),
        "challenger_count": len(records),
        "pair_counts": dict(sorted(pair_counts.items())),
        "classification_counts": dict(sorted(classification_counts.items())),
        "possible_or_observed_challenge_count": possible_observed_challenges,
        "one_proposal_maximum_preserved": True,
        "later_only_preserved": True,
    }


def _retag_audit(audit: dict[str, Any]) -> dict[str, Any]:
    updated = dict(audit)
    updated["agent_judge_version"] = AGENT_JUDGE_LUNA_GAIA_V3_29_VERSION
    updated["model"] = AGENT_JUDGE_LUNA_GAIA_V3_29_MODEL
    updated["reasoning_effort"] = AGENT_JUDGE_LUNA_GAIA_V3_29_REASONING_EFFORT
    return updated


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag_audit(parent.validate_anchor_predictions(*paths))


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    audit = _retag_audit(parent.validate_challenger(*paths))
    audit["acquisition_anchor_zero_contribution"] = (
        _validate_zero_contribution_challengers(paths[5])
    )
    return audit


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    audit = _retag_audit(parent.validate_arbiter(*paths))
    audit["acquisition_anchor_zero_contribution"] = (
        _validate_zero_contribution_challengers(paths[5])
    )
    return audit


def validate_agent_judge_luna_gaia_v3_29_predictions(
    *paths: str | Path,
) -> dict[str, Any]:
    audit = _retag_audit(
        parent.validate_agent_judge_luna_gaia_v3_20_predictions(*paths)
    )
    predictions = Path(paths[2]).expanduser().resolve()
    audit["schema_version"] = AGENT_JUDGE_LUNA_GAIA_V3_29_AUDIT_SCHEMA_VERSION
    audit["selection_policy"] = (
        "clean_v3_20_packet_state_anchor_acquisition_zero_contribution_"
        "later_challenger_default_keep_arbiter"
    )
    audit["direct_semantic_parent"] = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION
    audit["rejected_lineage_inherited"] = False
    audit["acquisition_anchor_zero_contribution"] = (
        _validate_zero_contribution_challengers(
            predictions.parent / CHALLENGERS_FILENAME
        )
    )
    return audit


def _write_audit(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_29_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        validate_agent_judge_luna_gaia_v3_29_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_29_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_29_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_29_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_29_audit(*paths)
        else:
            shared._fail(
                "invalid_compact_validation_arguments", "stage/path count differs"
            )
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument(
        "stage", choices=("anchor", "challenger", "arbiter", "prediction")
    )
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

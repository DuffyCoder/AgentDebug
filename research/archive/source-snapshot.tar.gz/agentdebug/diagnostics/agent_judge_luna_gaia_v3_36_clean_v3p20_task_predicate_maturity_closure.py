"""Luna GAIA v3.36: clean v3.20 with task-predicate maturity closure."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger as transport
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent


AGENT_JUDGE_LUNA_GAIA_V3_36_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.36-clean-v3.20-"
    "task-predicate-maturity-closure"
)
AGENT_JUDGE_LUNA_GAIA_V3_36_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_36_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_36_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases used by the shared paper-50 runner.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_36_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_36_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_36_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_36_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = transport.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = transport.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = transport.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = transport.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = transport.CHALLENGERS_FILENAME
ARBITER_FILENAME = transport.ARBITER_FILENAME
ARBITERS_FILENAME = transport.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = transport.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = transport.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = transport.PREDICTION_AUDIT_FILENAME

_MATURITY_PREFIX = re.compile(
    r"^task_predicate_maturity_step=(none|[1-9]\d*); "
    r"boundary_owner=(none|agent_commitment|state_handoff|execution_choice); "
    r"maturity_witness=(none|intrinsic_predicate_incapability|"
    r"post_feedback_recommitment|state_handoff_contradiction|execution_impact); "
    r"witness_step=(none|[1-9]\d*); "
)

_OWNER_FOR_WITNESS = {
    "intrinsic_predicate_incapability": "agent_commitment",
    "post_feedback_recommitment": "agent_commitment",
    "state_handoff_contradiction": "state_handoff",
    "execution_impact": "execution_choice",
}


_TASK_PREDICATE_MATURITY_RULES = """\
TASK-PREDICATE MATURITY CLOSURE — ONE ALTERNATIVE MAXIMUM

The frozen clean-v3.20 prediction is the incumbent anchor. Inspect the complete
trace, but emit at most ONE alternative prediction and never retain a candidate
pool. The anchor remains the default under uncertainty. Step position,
severity, Planning ownership, persistence, and stronger wording do not win by
themselves.

CLOSED BOUNDARY TUPLE

For every plausible critical boundary, close exactly this tuple before
comparing it with the anchor:

1. BOUNDARY OWNER: the local Agent decision that owns the path change — an
   `agent_commitment`, a `state_handoff`, or an `execution_choice`. A raw
   tool/site result is never the owner.
2. IMMEDIATE TASK PREDICATE: the concrete unresolved content, state, relation,
   provenance, or next-decision condition that this Step must advance.
3. MATURITY WITNESS: one literal witness, owned at a named Step, proving that
   this is a critical error rather than a probe, normal failure, faithful
   propagation, recovered/mechanical defect, or merely improvable behavior.

Exactly four witness classes are allowed:

- `intrinsic_predicate_incapability`: the Agent commits to an interface or
  route that cannot expose the immediate required content/state and the
  visible returned content lacks that predicate. Successful transport or some
  returned text is not capability proof. Conversely, if successful use can
  still contribute a necessary identifier, source, page, text, or lead, keep
  the route as a reasonable probe unless prior feedback has matured it.
- `post_feedback_recommitment`: literal prior feedback has already failed or
  ruled out the normalized target, corpus, interface, and extraction route,
  and the Agent then recommits without a material change. The owner is the
  post-feedback Agent plan/reflection, not the failure result. Maturity is
  prefix-closed: whenever a later repeated Step cites an earlier same-route
  Step, test that earlier Step against its own prior prefix first and select it
  if it was already mature.
- `state_handoff_contradiction`: adjacent result/history contains a necessary
  concrete fact that Memory/Reflection drops or distorts; Memory/Reflection
  asserts a task-material unsupported fact; it falsely reads outcome/progress;
  or the immediate target is lost between plan and Action. The defect must feed
  the current or next decision and an exact local repair can change the path.
- `execution_impact`: the Agent's plan, Action, or parameter choice is directly
  rejected, misparsed, or contradicted by adjacent feedback and remains
  unrecovered. Generic site/tool failure and a successfully accepted scalar or
  string representation do not qualify.

CHRONOLOGY AND COMPARISON

Evaluate plausible Steps in chronology and keep the earliest tuple whose owner,
predicate, and witness all close. Reject first probes without prior maturity,
materially different evidence routes, raw failures, harmless summary
compression, recovered/mechanical predecessors, faithful propagation, and
downstream symptoms. Do not use hypothetical rerouting to erase defects on the
observed continuation.

Compare that earliest closed tuple with the frozen anchor:

- If it is strictly earlier, challenge only when the anchor is a
  `downstream_symptom`; repairing only the anchor cannot remove the earlier
  defect.
- If it is strictly later, challenge only when the anchor is a
  `reasonable_probe` or `noncritical_predecessor`; the later tuple remains
  independently failure-causing while the observed anchor action and outcome
  are preserved.
- A proposal must change Step. If the earliest closed tuple is the anchor, if
  no tuple closes, or if evidence is uncertain, emit `no_challenge`.

Begin search_summary exactly:
`task_predicate_maturity_step=<none|Step>; boundary_owner=<none|agent_commitment|state_handoff|execution_choice>; maturity_witness=<none|intrinsic_predicate_incapability|post_feedback_recommitment|state_handoff_contradiction|execution_impact>; witness_step=<none|Step>; `

When there is no challenge, all four prefix values must be `none`. When there
is a challenge, task_predicate_maturity_step must equal the proposed Step,
boundary_owner must match the witness class, and witness_step must name the
literal Step supplying maturity evidence. The remaining search_summary must
state the immediate task predicate, certify chronological prefix closure, and
say why no earlier tuple survives.

Use anchor_only_repair_counterfactual and proposal_only_repair_counterfactual
independently. direct_timeline_comparison must compare the anchor, proposal,
and every intervening plausible boundary. A proposal must be a complete legal
prediction owned by its Step/module. When uncertain, no_challenge.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_36_VERSION,
        )
        .replace(
            transport.AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_36_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_36_clean_v3p20_task_predicate_maturity_closure",
        )
        .replace(
            "agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger",
            "agent_judge_luna_gaia_v3_36_clean_v3p20_task_predicate_maturity_closure",
        )
    )


def _rewrite_mechanism(task: str) -> str:
    if task.count(transport._BOUNDED_BIDIRECTIONAL_RULES) != 1:
        raise RuntimeError("v3.16 challenger-rule marker changed unexpectedly")
    return task.replace(
        transport._BOUNDED_BIDIRECTIONAL_RULES,
        _TASK_PREDICATE_MATURITY_RULES,
        1,
    )


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_anchor_task(*paths))


def build_challenger_task(*paths: str | Path) -> str:
    return _rewrite_identity(_rewrite_mechanism(transport.build_challenger_task(*paths)))


def build_arbiter_task(*paths: str | Path) -> str:
    return _rewrite_identity(_rewrite_mechanism(transport.build_arbiter_task(*paths)))


def build_agent_judge_luna_gaia_v3_36_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def _retag(audit: dict[str, Any]) -> dict[str, Any]:
    result = dict(audit)
    result["agent_judge_version"] = AGENT_JUDGE_LUNA_GAIA_V3_36_VERSION
    result["model"] = AGENT_JUDGE_LUNA_GAIA_V3_36_MODEL
    result["reasoning_effort"] = AGENT_JUDGE_LUNA_GAIA_V3_36_REASONING_EFFORT
    return result


def _validate_task_predicate_maturity_challengers(path: str | Path) -> dict[str, Any]:
    challenger_path, raw = shared._load_artifact(path, role="maturity-closure challenger")
    rows = raw if isinstance(raw, list) else [raw]
    if not rows or any(not isinstance(row, dict) for row in rows):
        shared._fail("invalid_maturity_closure_challengers", "records unavailable")
    owner_counts: Counter[str] = Counter()
    witness_counts: Counter[str] = Counter()
    for index, row in enumerate(rows):
        location = f"challenger[{index}]"
        match = _MATURITY_PREFIX.match(row.get("search_summary") or "")
        if match is None:
            shared._fail("missing_task_predicate_maturity_prefix", location)
        boundary_text, owner, witness, witness_step_text = match.groups()
        boundary_step = None if boundary_text == "none" else int(boundary_text)
        witness_step = None if witness_step_text == "none" else int(witness_step_text)
        status = row.get("challenge_status")
        proposal = row.get("proposed_prediction")
        if status == "no_challenge":
            if (
                boundary_step is not None
                or owner != "none"
                or witness != "none"
                or witness_step is not None
                or proposal is not None
            ):
                shared._fail("nonempty_maturity_tuple_without_challenge", location)
        elif status == "challenge":
            if (
                boundary_step is None
                or owner == "none"
                or witness == "none"
                or witness_step is None
                or not isinstance(proposal, dict)
                or proposal.get("predicted_step") != boundary_step
            ):
                shared._fail("incomplete_maturity_tuple_for_challenge", location)
            if _OWNER_FOR_WITNESS.get(witness) != owner:
                shared._fail("maturity_witness_owner_mismatch", location)
        else:
            shared._fail("invalid_maturity_challenge_status", location)
        owner_counts[owner] += 1
        witness_counts[witness] += 1
    return {
        "required": True,
        "valid": True,
        "path": str(challenger_path),
        "record_count": len(rows),
        "owner_counts": dict(sorted(owner_counts.items())),
        "witness_counts": dict(sorted(witness_counts.items())),
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths))


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    audit = _retag(transport.validate_challenger(*paths))
    audit["task_predicate_maturity_closure"] = (
        _validate_task_predicate_maturity_challengers(paths[-1])
    )
    return audit


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    return _retag(transport.validate_arbiter(*paths))


def validate_agent_judge_luna_gaia_v3_36_predictions(
    *paths: str | Path,
) -> dict[str, Any]:
    audit = _retag(transport.validate_agent_judge_luna_gaia_v3_16_predictions(*paths))
    predictions = Path(paths[2]).expanduser().resolve()
    audit["schema_version"] = AGENT_JUDGE_LUNA_GAIA_V3_36_AUDIT_SCHEMA_VERSION
    audit["selection_policy"] = (
        "clean_v3_20_packet_state_anchor_one_task_predicate_maturity_closure_"
        "challenger_default_keep_exact_copy_arbiter"
    )
    audit["direct_semantic_parent"] = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION
    audit["rejected_lineage_inherited"] = False
    audit["packet_state_closure"] = parent._validate_packet_state_ledgers(
        predictions.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME
    )
    audit["anchor_semantics_unchanged_from_v3_20"] = True
    audit["task_predicate_maturity_closure"] = (
        _validate_task_predicate_maturity_challengers(
            predictions.parent / CHALLENGERS_FILENAME
        )
    )
    return audit


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_36_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_36_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_36_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_36_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_36_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_36_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

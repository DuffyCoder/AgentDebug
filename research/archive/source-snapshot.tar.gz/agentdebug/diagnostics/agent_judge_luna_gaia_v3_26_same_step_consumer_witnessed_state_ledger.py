"""Luna GAIA v3.26: same-Step consumer-witnessed state evidence ledger."""

from __future__ import annotations

import argparse
import json
import re
import threading
from collections import Counter
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_25_predecessor_feedback_aligned_state_ledger as parent


AGENT_JUDGE_LUNA_GAIA_V3_26_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.26-"
    "same-step-consumer-witnessed-state-ledger"
)
AGENT_JUDGE_LUNA_GAIA_V3_26_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_25_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_26_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_25_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_26_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_25_AUDIT_SCHEMA_VERSION
)

# The shared runner still resolves these compatibility names.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_26_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_26_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_26_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_26_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = parent.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = parent.CHALLENGERS_FILENAME
ARBITER_FILENAME = parent.ARBITER_FILENAME
ARBITERS_FILENAME = parent.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = parent.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = parent.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME


_ROW_FIELDS = (
    "step",
    "state_quote",
    "source_step",
    "source_feedback_quote",
    "candidate_kind",
    "candidate_relation",
    "consumer_step",
    "consumer_quote",
    "verdict",
)
_CANDIDATE_PAIRS = parent._CANDIDATE_PAIRS
_SUMMARY_SUFFIX = re.compile(
    r"^; state_candidate_kind=(none|necessary_fact|entity_relation|outcome_claim); "
    r"state_candidate_relation=(not_applicable|omitted|unsupported|contradicted); "
    r"state_candidate_step=(none|[1-9]\d*); "
    r"state_direction=(none|earlier|same|later); comparison=(.+)$",
    re.DOTALL,
)


_CONSUMER_WITNESS_RULES = """\
SAME-STEP CONSUMER-WITNESSED STATE LEDGER — ORDERED CAUSAL PROOF

The frozen packet-state prediction is the incumbent anchor. Do not change,
repair, or re-run it. This remains a state-only challenger: Planning, Action,
System, source, mechanical, acquisition, and terminal-answer errors cannot be
proposed unless a Memory/Reflection state Step independently owns one of the
three closed pairs below.

PHASE 1 — EMIT ONE SOURCE-ALIGNED, CONSUMER-WITNESSED ROW FOR EVERY STATE STEP

List every Step containing Memory or Reflection in exact chronology. Emit one
row for every listed Step, with fields in exactly this order:

`step`, `state_quote`, `source_step`, `source_feedback_quote`,
`candidate_kind`, `candidate_relation`, `consumer_step`, `consumer_quote`,
`verdict`.

- state_quote is a short literal excerpt from that Step's Memory/Reflection;
  use null only when its state spans are empty.
- source_step is mechanically `step - 1`; use null only for Step 1.
- source_feedback_quote is a short literal excerpt from the current Step's
  structured current-observation slice: the tool/environment result produced
  by source_step and presented before the current state was written. It must
  not quote task, history, interface, or system boilerplate; use null only when
  that predecessor-result slice is empty.
- A clear row is exactly `none/not_applicable/null/null/clear` after the two
  source fields.
- A candidate row must use exactly one closed pair and give consumer_step plus
  a literal consumer_quote from Planning or Action that observably depends on
  the exact defective state claim.
- consumer_step may equal the state Step only when consumer_quote belongs to a
  Planning/Action module span ordered after all Memory/Reflection spans in
  that same assistant output. This is a later module, not a later numeric Step.
- A numerically later consumer remains eligible and also requires a literal
  Planning/Action consumer_quote. A consumer before the state Step is invalid.

Closed pairs are unchanged:

1. `necessary_fact/omitted`: predecessor feedback contains a concrete title,
   value, constraint, source fact, provenance link, or discriminating result
   necessary for the unresolved subgoal or current/later decision, while this
   Step's state loses or materially distorts it and the consumer acts on that
   incomplete state.
2. `entity_relation/unsupported`: state asserts a concrete task-answer entity,
   value, credential, or relation unsupported by predecessor feedback and the
   consumer uses that exact assertion.
3. `outcome_claim/contradicted`: state claims success, failure, progress, or a
   constraint that literal predecessor feedback contradicts and the consumer
   acts on that false outcome.

Harmless compression, a detail still available to the current/later decision,
wording polish, non-consumed speculation, and locally false but causally
irrelevant text are clear. The mere presence of a Planning/Action span is not
consumption: consumer_quote must expose dependence on the exact defect.

Begin search_summary exactly with:

`state_ledger=<JSON array>; state_candidate_kind=<none|necessary_fact|entity_relation|outcome_claim>; state_candidate_relation=<not_applicable|omitted|unsupported|contradicted>; state_candidate_step=<none|Step>; state_direction=<none|earlier|same|later>; comparison=<literal comparison>`

The EARLIEST ledger row with verdict candidate mechanically freezes all four
state_candidate fields. If every row is clear, use
`none/not_applicable/none/none`. Do not choose a more salient later row.

PHASE 2 — COMPARE THAT FROZEN CANDIDATE WITH THE ANCHOR

- If candidate Step equals anchor, no_challenge: the anchor already owns it.
- If candidate is earlier, challenge only when repairing that state can change
  the later path and repairing only the anchor leaves the earlier state defect;
  classify the anchor downstream_symptom.
- If candidate is later, challenge only when the anchor is a reasonable probe
  or noncritical predecessor and the candidate remains independently failure-
  causing after anchor-only repair.
- If the candidate loses comparison, emit no_challenge but keep the ledger and
  frozen candidate fields unchanged.
- If no candidate exists, emit no_challenge with the none fields.

A proposal must exactly use state_candidate_step, be owned by Memory or
Reflection, quote literal evidence, feed the witnessed current/later decision,
and be the only proposal. The independent arbiter still defaults to the anchor.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_25_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_26_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_25_predecessor_feedback_aligned_state_ledger",
            "agent_judge_luna_gaia_v3_26_same_step_consumer_witnessed_state_ledger",
        )
        .replace(parent._ALIGNED_LEDGER_RULES, _CONSUMER_WITNESS_RULES)
        .replace(
            "PREDECESSOR-ALIGNED STATE LEDGER",
            "SAME-STEP CONSUMER-WITNESSED STATE LEDGER",
        )
        .replace(
            "predecessor-aligned state ledger",
            "same-Step consumer-witnessed state ledger",
        )
    )


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_anchor_task(*paths))


def build_challenger_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_challenger_task(*paths))


def _parse_summary(value: Any, *, location: str) -> tuple[list[Any], tuple[str, ...]]:
    if not isinstance(value, str) or not value.startswith("state_ledger="):
        shared._fail("missing_consumer_witnessed_state_ledger", location)
    start = len("state_ledger=")
    try:
        ledger, end = json.JSONDecoder().raw_decode(value, start)
    except (json.JSONDecodeError, TypeError):
        shared._fail("invalid_consumer_witnessed_state_ledger_json", location)
    match = _SUMMARY_SUFFIX.fullmatch(value[end:])
    if match is None:
        shared._fail("invalid_consumer_witnessed_state_ledger_suffix", location)
    if not isinstance(ledger, list):
        shared._fail("consumer_witnessed_state_ledger_not_array", location)
    return ledger, match.groups()


def _planning_action_sources(step: Any, *, after_state: bool) -> list[str]:
    """Return literal Planning/Action sources, optionally after all state spans."""
    raw = step.assistant_raw_output
    state_end = max(
        (
            span.content_end_char
            for span in step.module_spans
            if span.module in {"memory", "reflection"}
        ),
        default=0,
    )
    return [
        raw[span.content_start_char : span.content_end_char]
        for span in step.module_spans
        if span.module in {"planning", "action"}
        and (not after_state or span.content_start_char >= state_end)
        and raw[span.content_start_char : span.content_end_char].strip()
    ]


def _validate_ledger_records(path: str | Path, cases: Sequence[Any]) -> dict[str, Any]:
    challenger_path, raw = shared._load_artifact(path, role="consumer-witnessed state ledger")
    records = raw if isinstance(raw, list) else [raw]
    if len(records) != len(cases) or any(not isinstance(item, dict) for item in records):
        shared._fail("invalid_consumer_witnessed_record_count", "case/record count differs")

    pair_counts: Counter[str] = Counter()
    direction_counts: Counter[str] = Counter()
    consumer_direction_counts: Counter[str] = Counter()
    total_rows = candidate_rows = candidate_cases = 0
    earlier_candidate_cases = challenge_count = same_step_consumers = 0
    for index, (record, case) in enumerate(zip(records, cases, strict=True)):
        location = f"consumer_witnessed_state[{index}]"
        ledger, suffix = _parse_summary(record.get("search_summary"), location=location)
        frozen_kind, frozen_relation, candidate_text, direction, _comparison = suffix
        expected_steps = parent.parent._state_steps(case)
        if len(ledger) != len(expected_steps):
            shared._fail("consumer_witnessed_row_count_mismatch", location)

        found_candidates: list[tuple[int, str, str]] = []
        for row_index, (row, expected_step) in enumerate(
            zip(ledger, expected_steps, strict=True)
        ):
            row_location = f"{location}.ledger[{row_index}]"
            if not isinstance(row, dict) or tuple(row) != _ROW_FIELDS:
                shared._fail("invalid_consumer_witnessed_row_schema", row_location)
            if row["step"] != expected_step:
                shared._fail("consumer_witnessed_step_order_mismatch", row_location)
            step = case.judge_view.steps[expected_step - 1]
            parent.parent._literal_quote(
                row["state_quote"],
                parent.parent._state_sources(step),
                location=f"{row_location}.state_quote",
                empty_code="nonempty_quote_for_empty_state",
                literal_code="nonliteral_state_quote",
            )
            expected_source = expected_step - 1 if expected_step > 1 else None
            if row["source_step"] != expected_source:
                shared._fail("predecessor_source_step_mismatch", row_location)
            source_feedback = (
                [] if expected_source is None else parent._predecessor_result_sources(step)
            )
            parent.parent._literal_quote(
                row["source_feedback_quote"],
                source_feedback,
                location=f"{row_location}.source_feedback_quote",
                empty_code="nonempty_quote_without_predecessor_feedback",
                literal_code="nonliteral_predecessor_feedback_quote",
            )

            kind = row["candidate_kind"]
            relation = row["candidate_relation"]
            consumer = row["consumer_step"]
            consumer_quote = row["consumer_quote"]
            verdict = row["verdict"]
            if verdict == "clear":
                if (kind, relation, consumer, consumer_quote) != (
                    "none",
                    "not_applicable",
                    None,
                    None,
                ):
                    shared._fail("invalid_clear_consumer_witnessed_row", row_location)
            elif verdict == "candidate":
                if kind not in _CANDIDATE_PAIRS or relation != _CANDIDATE_PAIRS[kind]:
                    shared._fail("invalid_consumer_witnessed_candidate_pair", row_location)
                if (
                    isinstance(consumer, bool)
                    or not isinstance(consumer, int)
                    or consumer < expected_step
                    or consumer > len(case.judge_view.steps)
                ):
                    shared._fail("invalid_state_consumer_step", row_location)
                consumer_sources = _planning_action_sources(
                    case.judge_view.steps[consumer - 1],
                    after_state=consumer == expected_step,
                )
                parent.parent._literal_quote(
                    consumer_quote,
                    consumer_sources,
                    location=f"{row_location}.consumer_quote",
                    empty_code="consumer_quote_without_later_planning_action",
                    literal_code="nonliteral_later_planning_action_consumer_quote",
                )
                found_candidates.append((expected_step, kind, relation))
                candidate_rows += 1
                if consumer == expected_step:
                    same_step_consumers += 1
                    consumer_direction_counts["same_step_later_module"] += 1
                else:
                    consumer_direction_counts["later_step"] += 1
            else:
                shared._fail("invalid_consumer_witnessed_verdict", row_location)
            pair_counts[f"{kind}:{relation}"] += 1
            total_rows += 1

        candidate_step = None if candidate_text == "none" else int(candidate_text)
        if not found_candidates:
            if (
                candidate_step is not None
                or (frozen_kind, frozen_relation, direction)
                != ("none", "not_applicable", "none")
            ):
                shared._fail("empty_consumer_witnessed_candidate_fields_mismatch", location)
        else:
            earliest_step, earliest_kind, earliest_relation = found_candidates[0]
            anchor_step = record.get("anchor_step")
            expected_direction = (
                "earlier"
                if earliest_step < anchor_step
                else "later"
                if earliest_step > anchor_step
                else "same"
            )
            if (
                (candidate_step, frozen_kind, frozen_relation, direction)
                != (earliest_step, earliest_kind, earliest_relation, expected_direction)
            ):
                shared._fail("earliest_consumer_witnessed_candidate_mismatch", location)
            candidate_cases += 1
            earlier_candidate_cases += direction == "earlier"

        status = record.get("challenge_status")
        proposal = record.get("proposed_prediction")
        if status == "challenge":
            if (
                candidate_step is None
                or direction not in {"earlier", "later"}
                or not isinstance(proposal, dict)
                or proposal.get("predicted_step") != candidate_step
                or proposal.get("predicted_module") not in {"memory", "reflection"}
            ):
                shared._fail("proposal_differs_from_consumer_witnessed_candidate", location)
            challenge_count += 1
        elif status != "no_challenge":
            shared._fail("invalid_consumer_witnessed_challenge_status", location)
        direction_counts[direction] += 1

    return {
        "required": True,
        "valid": True,
        "path": str(challenger_path),
        "record_count": len(records),
        "exact_state_row_coverage": True,
        "mechanical_predecessor_binding": True,
        "literal_planning_action_consumer_witness": True,
        "same_step_module_order_enforced": True,
        "state_ledger_row_count": total_rows,
        "candidate_row_count": candidate_rows,
        "candidate_case_count": candidate_cases,
        "same_step_consumer_candidate_count": same_step_consumers,
        "earlier_candidate_case_count": earlier_candidate_cases,
        "challenge_count": challenge_count,
        "row_pair_counts": dict(sorted(pair_counts.items())),
        "consumer_direction_counts": dict(sorted(consumer_direction_counts.items())),
        "direction_counts": dict(sorted(direction_counts.items())),
    }


_PATCH_LOCK = threading.RLock()


@contextmanager
def _using_consumer_witness_validator() -> Iterator[None]:
    """Make the inherited v3.25 routing use this version's row validator."""
    with _PATCH_LOCK:
        original = parent._validate_ledger_records
        parent._validate_ledger_records = _validate_ledger_records
        try:
            yield
        finally:
            parent._validate_ledger_records = original


def _retag_audit(audit: dict[str, Any]) -> dict[str, Any]:
    updated = dict(audit)
    updated["agent_judge_version"] = AGENT_JUDGE_LUNA_GAIA_V3_26_VERSION
    updated["model"] = AGENT_JUDGE_LUNA_GAIA_V3_26_MODEL
    updated["reasoning_effort"] = AGENT_JUDGE_LUNA_GAIA_V3_26_REASONING_EFFORT
    ledger = updated.pop("predecessor_feedback_aligned_state_ledger", None)
    if ledger is not None:
        updated["same_step_consumer_witnessed_state_ledger"] = ledger
    return updated


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag_audit(parent.validate_anchor_predictions(*paths))


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    with _using_consumer_witness_validator():
        audit = parent.validate_challenger(*paths)
    audit = _retag_audit(audit)
    audit["schema_version"] = "agentdebug.consumer-witnessed-state-challenger-audit.v1"
    return audit


def build_arbiter_task(*paths: str | Path) -> str:
    with _using_consumer_witness_validator():
        task = parent.build_arbiter_task(*paths)
    return _rewrite_identity(task)


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    with _using_consumer_witness_validator():
        audit = parent.validate_arbiter(*paths)
    audit = _retag_audit(audit)
    audit["schema_version"] = "agentdebug.consumer-witnessed-state-arbiter-audit.v1"
    return audit


def build_agent_judge_luna_gaia_v3_26_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / parent.parent.STEP_CANDIDATE_LEDGER_FILENAME,
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def validate_agent_judge_luna_gaia_v3_26_predictions(
    *paths: str | Path,
) -> dict[str, Any]:
    with _using_consumer_witness_validator():
        audit = parent.validate_agent_judge_luna_gaia_v3_25_predictions(*paths)
    audit = _retag_audit(audit)
    audit["schema_version"] = AGENT_JUDGE_LUNA_GAIA_V3_26_AUDIT_SCHEMA_VERSION
    audit["selection_policy"] = (
        "v3_20_packet_state_anchor_predecessor_aligned_same_step_consumer_"
        "witnessed_state_ledger_earliest_candidate_default_keep_arbiter"
    )
    return audit


def _write_audit(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_26_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        validate_agent_judge_luna_gaia_v3_26_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_26_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_26_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_26_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_26_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

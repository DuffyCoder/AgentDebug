"""Gold-isolated Codex Agent Judge v2.2 protocol.

V2.2 preserves v2.1's step -> owner -> type decision order and symmetric
admission gates.  It adds a first-false-proposition ledger, a mandatory local
validation loop, and one narrowly scoped evidence-source repair for malformed
actions emitted outside otherwise recognized module tags.
"""

from __future__ import annotations

import json
import os
import shlex
from pathlib import Path
from typing import Any

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _owner_sources,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_v2_1 import (
    AGENT_JUDGE_V2_1_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_V2_1_MODEL,
    AGENT_JUDGE_V2_1_REASONING_EFFORT,
    AGENT_JUDGE_V2_1_VERSION,
    build_agent_judge_v2_1_task,
)
from .judge_view import JudgeView
from .taxonomy import AgentModule, ErrorType


AGENT_JUDGE_V2_2_VERSION = "agentdebug.codex-agent-judge.v2.2"
AGENT_JUDGE_V2_2_MODEL = AGENT_JUDGE_V2_1_MODEL
AGENT_JUDGE_V2_2_REASONING_EFFORT = AGENT_JUDGE_V2_1_REASONING_EFFORT
AGENT_JUDGE_V2_2_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_1_AUDIT_SCHEMA_VERSION
)

_V2_1_PROTOCOL_HEADER = (
    "Run the frozen Codex Agent Judge protocol "
    f"{AGENT_JUDGE_V2_1_VERSION}."
)
_V2_2_PROTOCOL_HEADER = (
    "Run the frozen Codex Agent Judge protocol "
    f"{AGENT_JUDGE_V2_2_VERSION}."
)
_V2_1_MODULE_ALLOWLIST_ENTRY = "agentdebug/diagnostics/agent_judge_v2_1.py"
_V2_2_MODULE_ALLOWLIST_ENTRY = "agentdebug/diagnostics/agent_judge_v2_2.py"
_ALLOWLIST_TAIL = "- agentdebug/diagnostics/taxonomy.py\n"
_CONTRACT_MARKER = "\nSTRICT PREDICTION CONTRACT\n"

_V2_2_DELTA = """
V2.2 FIRST FALSE PROPOSITION — HARD CAUSAL SELECTION RULE

For every candidate, internally write one ledger row with exactly this
semantic tuple (do not emit the ledger in predictions.json):
<step, proposition, owner module, direct contradiction available then,
downstream propagation, recovery>.

"Direct contradiction available then" must identify the exact observable
history, current input, direct feedback, explicit task constraint, or supplied
interface rule that was already available when that assistant output was
written.  Only a proposition or decision contradicted by such then-available
evidence is a mature false proposition.  Later failure or later feedback
cannot retroactively make an earlier reasonable proposition mature.  A plan
choice that violates an already visible constraint or interface is directly
contradicted then; a merely weak choice with no then-available contradiction
is not.

Select the FIRST FALSE PROPOSITION: the earliest mature, causally sufficient,
unrecovered false proposition or constraint-violating decision in the causal
chain.  It is not the later step where its consequence becomes visible.  If a
chain is memory -> reflection -> planning -> action and every downstream
module faithfully propagates the same false proposition, select the first
module whose actual text introduced it while then-available observable
history or feedback already directly disproved it.  Use downstream
propagation and recovery columns to verify that the proposition continued to
control the failed path and was never fully repaired.

For a same-step tagged chain, compare the literal memory, reflection, plan,
and action text module by module.  Record the concrete fact, state, operation,
target, prerequisite, and constraint each one asserts.  Never abstract the
plan into a broad goal such as "search", "inspect", "continue", or "answer".
If memory first asserts a disproved state and the remaining modules faithfully
use it, memory owns.  If memory is sound but reflection first contradicts
direct feedback, reflection owns.  If both are sound and the plan first
chooses an operation or target contradicted by an explicit constraint,
planning owns.  Only if upstream text supports a sufficient feasible plan and
the concrete emission newly deviates, invokes an unavailable operation, or is
malformed may action own under the existing ACTION ADMISSION GATE.  Apply the
existing PLANNING ADMISSION GATE before freezing planning.

V2.2 MALFORMED-ACTION EVIDENCE RULE

The normal action sources remain the selected step's action module span and
its concrete tool-call name/string arguments.  Only for action/format_error or
action/invalid_action, a malformed concrete emission may instead be copied
from one exact contiguous residual segment of assistant_raw_output outside
all recognized module spans at that selected step.  The quote must remain
entirely inside one residual segment.  Never cross into or across a memory,
reflection, planning, or action span; never use current_input,
adjacent_feedback, an observation, a tool result, or another step.  This
exception does not apply to misalignment, parameter_error, or any non-action
owner/type.
"""


def _module_residual_sources(
    view: JudgeView,
    predicted_step: int,
) -> tuple[str, ...]:
    """Return non-empty raw-output segments outside every recognized module.

    Each returned source is one independent gap.  Keeping gaps separate makes
    it impossible for a valid quote to cross a module boundary.  Invalid span
    geometry fails closed instead of exposing module-owned text as residual.
    """

    step = view.steps[predicted_step - 1]
    raw = step.assistant_raw_output
    if not raw:
        return ()

    intervals: list[tuple[int, int]] = []
    for span in step.module_spans:
        start = span.tag_start_char
        end = span.tag_end_char
        if start < 0 or end <= start or end > len(raw):
            return ()
        intervals.append((start, end))

    if not intervals:
        return (raw,) if raw.strip() else ()

    merged: list[list[int]] = []
    for start, end in sorted(intervals):
        if merged and start <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])

    residuals: list[str] = []
    cursor = 0
    for start, end in merged:
        if cursor < start:
            residuals.append(raw[cursor:start])
        cursor = end
    if cursor < len(raw):
        residuals.append(raw[cursor:])
    return tuple(source for source in residuals if source.strip())


def _v2_2_owner_source_resolver(
    view: JudgeView,
    predicted_step: int,
    module: AgentModule,
    error_type: ErrorType,
) -> tuple[str, ...]:
    """Apply v1 primary sources plus v2.2's narrow malformed-action gap."""

    sources = list(
        _owner_sources(
            view,
            predicted_step=predicted_step,
            module=module,
        )
    )
    if module == AgentModule.ACTION and error_type in {
        ErrorType.FORMAT_ERROR,
        ErrorType.INVALID_ACTION,
    }:
        sources.extend(_module_residual_sources(view, predicted_step))
    return tuple(dict.fromkeys(source for source in sources if source.strip()))


def _validator_command(
    prediction_path: Path,
    cohort_path: Path,
    output_path: Path,
    audit_path: Path,
) -> str:
    """Build the exact local, gold-free validation command embedded in task."""

    code = (
        "import json; "
        "from agentdebug.diagnostics.agent_judge_v2_2 import "
        "validate_and_write_agent_judge_v2_2_audit as run; "
        "print(json.dumps(run("
        f"{str(prediction_path)!r}, {str(cohort_path)!r}, "
        f"{str(output_path)!r}, {str(audit_path)!r}"
        "), ensure_ascii=False, indent=2))"
    )
    return "PYTHONPATH=. python3 -c " + shlex.quote(code)


def build_agent_judge_v2_2_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build v2.1 plus v2.2 causal, evidence, and validation locks."""

    prediction_path = Path(prediction_manifest_path).expanduser().resolve()
    cohort_path = Path(cohort_manifest_path).expanduser().resolve()
    output_path = Path(predictions_path).expanduser().resolve()
    audit_path = output_path.parent / "prediction-audit.json"
    repository_root = Path(__file__).resolve().parents[2]

    task = build_agent_judge_v2_1_task(
        prediction_path,
        cohort_path,
        output_path,
    )
    if task.count(_V2_1_PROTOCOL_HEADER) != 1:
        raise RuntimeError("Agent Judge v2.1 protocol header changed unexpectedly")
    if task.count(_V2_1_MODULE_ALLOWLIST_ENTRY) != 1:
        raise RuntimeError("Agent Judge v2.1 read allowlist changed unexpectedly")
    if task.count(_ALLOWLIST_TAIL) != 1:
        raise RuntimeError("Agent Judge read allowlist tail changed unexpectedly")
    if task.count(_CONTRACT_MARKER) != 1:
        raise RuntimeError("Agent Judge v2.1 contract marker changed unexpectedly")

    task = task.replace(_V2_1_PROTOCOL_HEADER, _V2_2_PROTOCOL_HEADER, 1)
    task = task.replace(
        _V2_1_MODULE_ALLOWLIST_ENTRY,
        _V2_2_MODULE_ALLOWLIST_ENTRY,
        1,
    )
    self_inspection = (
        f"- {output_path} only after you write this run's complete predictions\n"
        f"- {audit_path} only after the local validator creates it\n"
    )
    task = task.replace(
        _ALLOWLIST_TAIL,
        _ALLOWLIST_TAIL + self_inspection,
        1,
    )
    task = task.replace(
        _CONTRACT_MARKER,
        f"\n{_V2_2_DELTA.strip()}\n{_CONTRACT_MARKER}",
        1,
    )

    validator_command = _validator_command(
        prediction_path,
        cohort_path,
        output_path,
        audit_path,
    )
    return task + f"""

V2.2 MANDATORY LOCAL VALIDATION LOOP — DO NOT STOP AFTER WRITING

First write the complete predictions JSON array for every cohort case to the
fixed output path above.  Then actually run these exact local shell commands:

cd {shlex.quote(str(repository_root))}
{validator_command}

The task is complete only when that command exits zero and writes the audit to
{audit_path}.  If validation fails, inspect only the validator error, your own
{output_path}, and the allowlisted prediction/cohort manifests or v2.2
protocol/taxonomy source.  Correct your own complete output and rerun the same
command until it passes.  Do not inspect any other prediction, score, gold,
metric, case study, evaluator annotation, directory listing, git history, or
external resource.  Do not call any external API or network service during
generation, correction, or validation.
"""


def validate_agent_judge_v2_2_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    """Validate with v2.2 evidence sources and bind the audit to v2.2."""

    audit = _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_v2_2_owner_source_resolver,
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_V2_2_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_V2_2_VERSION,
        "model": AGENT_JUDGE_V2_2_MODEL,
        "reasoning_effort": AGENT_JUDGE_V2_2_REASONING_EFFORT,
    }


def validate_and_write_agent_judge_v2_2_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    """Validate visibly and atomically persist the audit only on success.

    This small local entry point intentionally does not catch validation
    exceptions.  The mandatory subagent loop therefore sees the exact error
    code and ``predictions[index]`` location while remaining gold-free.
    """

    audit = validate_agent_judge_v2_2_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


__all__ = [
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AGENT_JUDGE_V2_2_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_V2_2_MODEL",
    "AGENT_JUDGE_V2_2_REASONING_EFFORT",
    "AGENT_JUDGE_V2_2_VERSION",
    "AgentJudgeValidationError",
    "build_agent_judge_v2_2_task",
    "validate_and_write_agent_judge_v2_2_audit",
    "validate_agent_judge_v2_2_predictions",
]

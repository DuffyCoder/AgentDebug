"""GAIA v3.99: clean-v3.83 tournament with CWD-robust bounded access."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge_gaia_v3_98_gpt55_stage_bounded_access_audited_tournament import *  # noqa: F403
from . import agent_judge_gaia_v3_83_clean_v3p20_model_only_gpt55_medium as incumbent
from . import (
    agent_judge_gaia_v3_98_gpt55_stage_bounded_access_audited_tournament as template,
)


AGENT_JUDGE_GAIA_V3_99_VERSION = (
    "agentdebug.codex-agent-judge.gaia-v3.99-gpt55-cwd-robust-access-"
    "audited-predicate-handoff-tournament"
)
AGENT_JUDGE_GAIA_V3_99_MODEL = incumbent.AGENT_JUDGE_GAIA_V3_83_MODEL
AGENT_JUDGE_GAIA_V3_99_REASONING_EFFORT = incumbent.AGENT_JUDGE_GAIA_V3_83_REASONING_EFFORT
AGENT_JUDGE_GAIA_V3_99_AUDIT_SCHEMA_VERSION = incumbent.AGENT_JUDGE_GAIA_V3_83_AUDIT_SCHEMA_VERSION
SEMANTIC_PARENT = incumbent.AGENT_JUDGE_GAIA_V3_83_VERSION

for _suffix in ("98", "97", "96", "95", "93"):
    globals()[f"AGENT_JUDGE_GAIA_V3_{_suffix}_VERSION"] = AGENT_JUDGE_GAIA_V3_99_VERSION
    globals()[f"AGENT_JUDGE_GAIA_V3_{_suffix}_MODEL"] = AGENT_JUDGE_GAIA_V3_99_MODEL
    globals()[f"AGENT_JUDGE_GAIA_V3_{_suffix}_REASONING_EFFORT"] = AGENT_JUDGE_GAIA_V3_99_REASONING_EFFORT
for _suffix in ("80", "79", "67", "37"):
    globals()[f"AGENT_JUDGE_LUNA_GAIA_V3_{_suffix}_VERSION"] = AGENT_JUDGE_GAIA_V3_99_VERSION
    globals()[f"AGENT_JUDGE_LUNA_GAIA_V3_{_suffix}_MODEL"] = AGENT_JUDGE_GAIA_V3_99_MODEL
    globals()[f"AGENT_JUDGE_LUNA_GAIA_V3_{_suffix}_REASONING_EFFORT"] = AGENT_JUDGE_GAIA_V3_99_REASONING_EFFORT


def _cwd_robust_task(task: str) -> str:
    value = task.replace(template.AGENT_JUDGE_GAIA_V3_98_VERSION, AGENT_JUDGE_GAIA_V3_99_VERSION)
    old = "- `python3 inspect_case.py feedback-chunk N K` (exact 4,000-character chunk K)"
    new = (
        "- `python3 inspect_case.py feedback-chunk N K` (exact output-budgeted chunk; "
        "K is 1-based, with 0 accepted only as an alias for the first chunk)"
    )
    if value.count(old) != 1:
        raise RuntimeError("feedback chunk contract marker changed unexpectedly")
    value = value.replace(old, new, 1)
    value = value.replace(
        "when an omitted middle segment is needed.",
        "when an omitted middle segment is needed. Do not exhaust binary/control-heavy "
        "chunks when the bounded exact printable runs already establish the outcome.",
    )
    return value


def build_anchor_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> str:
    return _cwd_robust_task(
        template.build_anchor_file_task(prediction_manifest_path, cohort_manifest_path)
    )


def build_reducer_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> str:
    return _cwd_robust_task(
        template.build_reducer_file_task(
            prediction_manifest_path,
            cohort_manifest_path,
            anchor_path,
            ledger_path,
            checkpoint_path,
        )
    )


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_GAIA_V3_99_VERSION,
        "model": AGENT_JUDGE_GAIA_V3_99_MODEL,
        "reasoning_effort": AGENT_JUDGE_GAIA_V3_99_REASONING_EFFORT,
        "selection_policy": policy,
        "semantic_parent": SEMANTIC_PARENT,
        "direct_semantic_parent": SEMANTIC_PARENT,
        "rejected_lineage_inherited": False,
        "single_major_change": (
            "replace accepted v3.83 challenger/arbiter with one outcome-conditioned "
            "predicate-handoff tournament over every native v3.83 ledger Step"
        ),
        "stage_specific_bounded_access_contract": True,
        "attempt_absolute_inspector_binding": True,
        "output_budgeted_feedback_chunks": True,
        "zero_first_chunk_alias": True,
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(template.validate_anchor_predictions(*paths), policy="v3p83_anchor_cwd_robust_access")


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])  # noqa: F405


def validate_panel(*paths: str | Path) -> dict[str, Any]:
    return _retag(template.validate_panel(*paths), policy="cwd_robust_singleton_safe_tournament")


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_panel(*paths[:-1]), paths[-1])  # noqa: F405


def validate_selector(*paths: str | Path) -> dict[str, Any]:
    return _retag(template.validate_selector(*paths), policy="cwd_robust_exact_selection_copy")


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_selector(*paths[:-1]), paths[-1])  # noqa: F405


def validate_agent_judge_gaia_v3_99_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    return _retag(
        template.validate_agent_judge_gaia_v3_98_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        policy="cwd_robust_access_audited_predicate_handoff_tournament",
    )


def validate_and_write_agent_judge_gaia_v3_99_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(  # noqa: F405
        validate_agent_judge_gaia_v3_99_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_gaia_v3_99_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_reducer_file_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,  # noqa: F405
    )


validate_and_write_agent_judge_luna_gaia_v3_37_audit = validate_and_write_agent_judge_gaia_v3_99_audit
validate_and_write_agent_judge_luna_gaia_v3_67_audit = validate_and_write_agent_judge_gaia_v3_99_audit
validate_and_write_agent_judge_luna_gaia_v3_79_audit = validate_and_write_agent_judge_gaia_v3_99_audit
validate_and_write_agent_judge_luna_gaia_v3_80_audit = validate_and_write_agent_judge_gaia_v3_99_audit
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_gaia_v3_99_task
build_agent_judge_luna_gaia_v3_79_task = build_agent_judge_gaia_v3_99_task
build_agent_judge_luna_gaia_v3_80_task = build_agent_judge_gaia_v3_99_task


def __getattr__(name: str) -> Any:
    return getattr(template, name)

"""Gold-isolated Codex Agent Judge v2 protocol.

V2 keeps the v1 prediction contract and fail-closed validator, but changes the
semantic decision order.  It freezes the causal step first, performs an
explicit same-step ownership matrix second, and assigns a taxonomy type only
after the owner is fixed.  The v1 module is intentionally left untouched.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    GOLD_ISOLATION_READ_DENYLIST,
    AgentJudgeValidationError,
    _assert_safe_path,
    _file_sha256,
    validate_agent_judge_predictions,
)
from .taxonomy import taxonomy_prompt


AGENT_JUDGE_V2_VERSION = "agentdebug.codex-agent-judge.v2"
AGENT_JUDGE_V2_MODEL = "gpt-5.6-terra"
AGENT_JUDGE_V2_REASONING_EFFORT = "medium"
AGENT_JUDGE_V2_AUDIT_SCHEMA_VERSION = (
    "agentdebug.codex-agent-judge-audit.v1"
)

GOLD_ISOLATION_V2_READ_ALLOWLIST = (
    "the exact prediction_manifest_path named in the task",
    "the exact cohort_manifest_path named in the task",
    "agentdebug/diagnostics/agent_judge_v2.py",
    "agentdebug/diagnostics/taxonomy.py",
)


def build_agent_judge_v2_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build the complete, frozen v2 task for one fresh Codex subagent."""

    prediction_path = Path(prediction_manifest_path).expanduser().resolve()
    cohort_path = Path(cohort_manifest_path).expanduser().resolve()
    output_path = Path(predictions_path).expanduser().resolve()
    _assert_safe_path(prediction_path, role="prediction manifest")
    _assert_safe_path(cohort_path, role="cohort manifest")
    _assert_safe_path(output_path, role="prediction output", is_output=True)

    schema = {
        "trajectory_id": "exact manifest trajectory ID",
        "trajectory_sha256": "exact manifest trajectory SHA-256",
        "status": "success",
        "predicted_step": "positive integer",
        "predicted_module": "taxonomy module",
        "predicted_error_type": "valid type for that module",
        "evidence_quote": "exact non-empty owner substring",
        "root_cause": "concise root-cause explanation",
        "causal_summary": "counterfactual and recovery conclusion",
        "rejected_adjacent_owner": "strongest alternative and rejection reason",
    }
    allowlist = "\n".join(
        f"- {item}" for item in GOLD_ISOLATION_V2_READ_ALLOWLIST
    )
    denylist = "\n".join(
        f"- {item}" for item in GOLD_ISOLATION_READ_DENYLIST
    )

    return f"""\
Run the frozen Codex Agent Judge protocol {AGENT_JUDGE_V2_VERSION}.

IMMUTABLE EXECUTION CONFIGURATION
- model: {AGENT_JUDGE_V2_MODEL}
- reasoning_effort: {AGENT_JUDGE_V2_REASONING_EFFORT}
- mode: independent open-ended Agent Judge
- external LLM/API/network calls: forbidden
- scoring or gold-label access: forbidden

INPUT/OUTPUT BOUNDARY
- prediction manifest: {prediction_path}
- prediction manifest file sha256: {_file_sha256(prediction_path)}
- cohort manifest: {cohort_path}
- cohort manifest file sha256: {_file_sha256(cohort_path)}
- write predictions only to: {output_path}

Read cases only from the prediction manifest and process exactly once in the
cohort order.  Do not inspect directories to look for more context.  The
JudgeView in each manifest entry is complete and authoritative.

GOLD-ISOLATION READ ALLOWLIST
{allowlist}

GOLD-ISOLATION READ DENYLIST
{denylist}

V2 DECISION ORDER — STEP, THEN OWNER, THEN TYPE

Do not start from an error type or from the visibly failed action.  Complete
the following stages in order for each case, keeping the analysis internal.

Stage I — chronological causal breakpoint
1. Reconstruct the objective, explicit constraints, chronological state,
   actions, observations, and feedback available before every assistant
   output.  A reasonable exploratory probe is not an error merely because it
   later failed.  Perform the TERMINAL CENSUS on every case: inspect all
   execution_facts and decide whether an observable step limit, tool failure,
   model limit, or environment failure independently prevented completion.
2. Enumerate at most three directly evidenced defective owner outputs in
   chronological order.  For each, test maturity (the defect is already
   actionable at that output), causal sufficiency (correcting that output
   could avert the failed trajectory), and recovery (the same defect was not
   later fully repaired).  Select the earliest mature, causally sufficient,
   unrecovered output.  Freeze its predicted_step before considering module
   names or taxonomy types.  Do not move to a later concrete action merely
   because it makes an earlier reasoning defect more visible.

   RECOVERY IS A HARD VETO, not an explanatory preference.  Scan every later
   step.  Reject a candidate if later behavior re-establishes the relevant
   world/information state, successfully performs the equivalent corrected
   action, or resumes the same strategy after losing only that one turn.  A
   candidate survives only when its defective proposition or state continues
   to control the path toward failure.

Stage II — same-step module ownership matrix
3. At the frozen step, evaluate every possible owner explicitly:
   - memory: does its account of earlier history omit, fail to retrieve, or
     invent information that is already observable?
   - reflection: does its assessment misread direct feedback, progress, or
     cause, including treating a merely planned operation as completed?
   - planning: with the concrete invocation and final answer hidden, does the
     plan itself choose a bad strategy, ignore a constraint/prerequisite, call
     for an impossible operation, or repeat wastefully?
   - action: after independently establishing that the same-step plan is
     sufficient and feasible, does the concrete invocation deviate from that
     plan, name an unavailable operation, fail to parse, or contain a
     specifically wrong argument?
   - system: did the mandatory terminal census establish a provenance-backed
     external boundary or failure that is independently causal?
4. Apply the ACTION ADMISSION GATE.  Action ownership is allowed only when the
   same-step plan is independently adequate and feasible and the concrete
   invocation/answer introduces the defect.  If a plan explicitly selects a
   bad strategy and the action faithfully executes it, planning owns the
   defect.  If memory or reflection supplies the false state that licenses a
   later plan, keep the earlier mature owner rather than blaming its symptom.
   A wrong final answer is not automatically action: locate the first false
   assessment or defective strategy that produced it; use action only when
   adequate upstream reasoning is followed by a contradictory or malformed
   final emission.  Step 1 cannot be memory or reflection because no earlier
   episode memory or action feedback exists.

   For the action-versus-planning comparison, answer both questions using
   exact same-step text: "What concrete next operation/target does the plan
   choose?" and "Does the action faithfully execute it?"  Do not reduce the
   plan to a vague goal such as search, inspect, or gather information.  If
   the answers identify the same bad operation or target, action fails the
   gate and the upstream owner must be audited.
5. Choose exactly one owner from the matrix.  In
   rejected_adjacent_owner, name the strongest same-step or causal-chain
   alternative and state the concrete failed admission test.  Evidence must
   be an exact, contiguous, case-sensitive substring owned by the selected
   module at the frozen step.  For system, use the final step and quote exactly
   one execution_facts line.

Stage III — taxonomy classification after ownership
6. Only now choose the legal error type within the frozen owner module.
   parameter_error is not a generic label for a wrong choice, weak strategy,
   failed result, incorrect conclusion, or repeated downstream action.  It
   requires an available concrete action plus an identifiable missing,
   malformed, wrong-typed, or mechanically misfilled argument relative to an
   otherwise adequate same-step plan or known interface contract.  Strategy,
   query choice, pagination choice, repetition, unsupported conclusions, and
   unverified purchases are not parameter errors.  Likewise, format_error
   requires unparsable action syntax, invalid_action requires an operation
   outside the available action space, and misalignment requires a concrete
   contradiction of an adequate current plan.  Before writing, verify cohort
   order, ID, SHA, frozen step range, pair legality, evidence ownership, and
   the exact output schema.

OWNER PRIORITY IS CAUSAL, NOT TEXTUAL
- Do not prefer action merely because tool calls are concrete or easy to quote.
- Do not prefer the last failed output over an earlier mature unrecovered root.
- Do not infer a system error from failure alone; require execution_facts.
- Do not infer parameter_error merely because some parameter could be better.
- If evidence cannot pass the action gate, choose the supported upstream owner.
- Before blaming a final answer, identify the earliest observable false fact,
  inference, or constraint omission that produces it.  The final answer can
  own the root only if upstream reasoning supports the correct content and
  the final emission independently changes, contradicts, or malforms it.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

STRICT PREDICTION CONTRACT
Write one JSON array, with no envelope, Markdown, commentary, or trailing
content.  It must contain exactly one record per cohort case in exact cohort
and manifest order.  Every record must contain exactly these ten fields:
{json.dumps(schema, ensure_ascii=False, indent=2)}

Every text field must be non-empty.  status must be exactly "success".
predicted_step must be a non-boolean positive integer within that JudgeView.
Do not emit confidence, score, probability, rank, vote, audit internals, source
IDs, aliases, nulls, or any additional field.  Do not copy or consult a prior
prediction.  The deterministic validator will reject rather than repair any
contract violation.
"""


def validate_agent_judge_v2_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    """Reuse the strict v1 gold-free contract and bind its audit to v2."""

    audit = validate_agent_judge_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_V2_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_V2_VERSION,
        "model": AGENT_JUDGE_V2_MODEL,
        "reasoning_effort": AGENT_JUDGE_V2_REASONING_EFFORT,
    }


__all__ = [
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AGENT_JUDGE_V2_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_V2_MODEL",
    "AGENT_JUDGE_V2_REASONING_EFFORT",
    "AGENT_JUDGE_V2_VERSION",
    "AgentJudgeValidationError",
    "GOLD_ISOLATION_V2_READ_ALLOWLIST",
    "build_agent_judge_v2_task",
    "validate_agent_judge_v2_predictions",
]

"""Credential redaction for serialized diagnostic reports."""

from __future__ import annotations

import re
from dataclasses import asdict, is_dataclass
from enum import Enum
from typing import Any, Mapping


_SENSITIVE_KEY = re.compile(
    r"(?:^|[_-])(?:api[_-]?key|secret|password|passwd|credential|"
    r"authorization|access[_-]?token|refresh[_-]?token|auth[_-]?token|"
    r"private[_-]?key|connection[_-]?string)(?:$|[_-])",
    re.IGNORECASE,
)
_DIRECT_SECRET = re.compile(
    r"(?:"
    r"\b(?:sk|rk|pk)(?:-|_(?:live|test)_)[A-Za-z0-9_-]{8,}|"
    r"\b(?:gh[pousr]_|github_pat_)[A-Za-z0-9_]{8,}|"
    r"\bxox[baprs]-[A-Za-z0-9-]{8,}|"
    r"\bwhsec_[A-Za-z0-9_-]{8,}|"
    r"\bAIza[0-9A-Za-z_-]{20,}|"
    r"\bAKIA[0-9A-Z]{16}\b|"
    r"\bbearer\s+[A-Za-z0-9._~+/=-]{8,}|"
    r"-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----.*?"
    r"-----END [A-Z0-9 ]*PRIVATE KEY-----"
    r")",
    re.IGNORECASE | re.DOTALL,
)
_ASSIGNED_SECRET = re.compile(
    r"(?i)\b(?:api[_ -]?key|secret|password|passwd|access[_ -]?token|"
    r"refresh[_ -]?token|auth[_ -]?token|authorization|private[_ -]?key|"
    r"connection[_ -]?string)\b\s*[:=]\s*[\"']?[^\"'\s,}]{4,}"
)
_NON_SECRET_KEY_SUFFIXES = {
    "count",
    "length",
    "limit",
    "usage",
    "budget",
    "type",
    "status",
    "present",
    "enabled",
    "required",
    "name",
}


def is_sensitive_key(key: Any) -> bool:
    rendered = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", str(key or "")).lower()
    words = set(re.findall(r"[a-z0-9]+", rendered))
    if words & _NON_SECRET_KEY_SUFFIXES and not words & {
        "secret",
        "password",
        "passwd",
        "credential",
        "authorization",
    }:
        return False
    return bool(_SENSITIVE_KEY.search(f"_{rendered}_"))


def has_credential_shape(value: str) -> bool:
    normalized = (
        value.replace("**", "")
        .replace("__", "")
        .replace("`", "")
        .replace("|", ":")
    )
    return bool(
        _DIRECT_SECRET.search(normalized)
        or _ASSIGNED_SECRET.search(normalized)
    )


def redact(value: Any) -> Any:
    """Return a JSON-safe copy with credential-shaped values removed."""

    if isinstance(value, Enum):
        return value.value
    if is_dataclass(value):
        return redact(asdict(value))
    if isinstance(value, Mapping):
        return {
            str(key): "[REDACTED]" if is_sensitive_key(key) else redact(item)
            for key, item in value.items()
        }
    if isinstance(value, (list, tuple, set)):
        return [redact(item) for item in value]
    if isinstance(value, str) and has_credential_shape(value):
        return "[REDACTED]"
    return value


"""Luna GAIA v3.77: factorized native sparse-ledger pairwise selector."""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any

from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from . import (
    agent_judge_luna_gaia_v3_76_clean_v3p20_sparse_ledger_global_boundary_selector_runtime_repair as legality,
)
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions
from .taxonomy import taxonomy_prompt


shared = legality.shared
AGENT_JUDGE_LUNA_GAIA_V3_77_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.77-clean-v3.20-"
    "factorized-sparse-ledger-pairwise-selector"
)
AGENT_JUDGE_LUNA_GAIA_V3_77_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_77_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_77_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases for the frozen full-50 aggregation runner.
AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_77_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_77_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT = AGENT_JUDGE_LUNA_GAIA_V3_77_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_77_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_77_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = AGENT_JUDGE_LUNA_GAIA_V3_77_REASONING_EFFORT

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
INFERENCE_DOCUMENT_FILENAME = legality.INFERENCE_DOCUMENT_FILENAME
PANEL_FILENAME = "factorized-sparse-ledger-local-inventory.json"
PANELS_FILENAME = "factorized-sparse-ledger-local-inventories.json"
PANEL_AUDIT_FILENAME = "factorized-sparse-ledger-local-inventory-audit.json"
SELECTOR_ASSESSMENT_FILENAME = "factorized-sparse-ledger-pairwise-assessment.json"
SELECTOR_ASSESSMENT_AUDIT_FILENAME = (
    "factorized-sparse-ledger-pairwise-assessment-audit.json"
)
SELECTOR_FILENAME = "factorized-sparse-ledger-selection.json"
SELECTORS_FILENAME = "factorized-sparse-ledger-selections.json"
SELECTOR_AUDIT_FILENAME = "factorized-sparse-ledger-selection-audit.json"

DEFECT_CLASSES = legality.DEFECT_CLASSES
RECOVERY_STATUSES = legality.RECOVERY_STATUSES
OUTCOME_RELATIONS = legality.OUTCOME_RELATIONS
DECISIONS = frozenset({"keep_anchor", "select_prefix"})
PAIRWISE_RELATIONS = frozenset(
    {
        "candidate_earlier_critical_boundary",
        "anchor_earlier_critical_boundary",
        "candidate_noncritical_predecessor",
        "candidate_downstream_or_parallel",
        "uncertain",
    }
)
LOCAL_REVIEW_FIELDS = (
    "step",
    "observed_defect_class",
    "observed_outcome",
    "recovery_status",
    "outcome_relation",
    "local_path_effect",
    "local_repair_next_state",
    "literal_evidence_basis",
    "assessment_falsifier",
)
INVENTORY_FIELDS = ("reviews",)
PAIRWISE_FIELDS = (
    "candidate_step",
    "earliest_boundary_relation",
    "candidate_outweighs_anchor",
    "candidate_path_effect",
    "anchor_path_effect",
    "comparison_basis",
    "comparison_falsifier",
)
ASSESSMENT_FIELDS = (
    "pairwise_comparisons",
    "decision",
    "selected_step",
    "selected_module",
    "selected_error_type",
    "selected_evidence_quote",
    "selected_root_cause",
    "selected_causal_summary",
    "selected_rejected_adjacent_owner",
    "global_decision_basis",
    "selection_falsifier",
)
SELECTION_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "anchor_prediction_sha256",
    "anchor_ledger_sha256",
    "anchor_checkpoint_sha256",
    "inventory_sha256",
    "assessment_sha256",
    "decision",
    "anchor_step",
    "reviewed_steps",
    "selected_step",
    "frozen_step",
    "selected_prediction_sha256",
    "selected_prediction",
    "local_inventory",
    "semantic_assessment",
)


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_77_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_77_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_77_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": (
            "factorize native sparse-ledger local facts from pairwise global selection"
        ),
        "legality_scaffolding_only_migrated": True,
        "step_semantics_unchanged_by_legality_materialization": True,
    }


build_inference_document = legality.build_inference_document
validate_inference_document = legality.validate_inference_document
normalize_anchor_response = legality.normalize_anchor_response
anchor_response_schema = legality.anchor_response_schema
_load_anchor_bundle = legality._load_anchor_bundle
_materialize_owned_prediction = legality._materialize_owned_prediction


def build_anchor_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> str:
    task = legality.build_anchor_file_task(
        prediction_manifest_path, cohort_manifest_path
    )
    return task.replace(
        legality.AGENT_JUDGE_LUNA_GAIA_V3_76_VERSION,
        AGENT_JUDGE_LUNA_GAIA_V3_77_VERSION,
    )


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        legality.validate_anchor_predictions(*paths),
        policy="unchanged_v3_20_anchor_owner_explicit_response_only",
    )


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])


def local_inventory_response_schema() -> dict[str, Any]:
    review = {
        "type": "object",
        "additionalProperties": False,
        "required": list(LOCAL_REVIEW_FIELDS),
        "properties": {
            "step": {"type": "integer", "minimum": 1},
            "observed_defect_class": {
                "type": "string",
                "enum": sorted(DEFECT_CLASSES),
            },
            "observed_outcome": {"type": "string", "minLength": 1},
            "recovery_status": {
                "type": "string",
                "enum": sorted(RECOVERY_STATUSES),
            },
            "outcome_relation": {
                "type": "string",
                "enum": sorted(OUTCOME_RELATIONS),
            },
            "local_path_effect": {"type": "string", "minLength": 1},
            "local_repair_next_state": {"type": "string", "minLength": 1},
            "literal_evidence_basis": {"type": "string", "minLength": 1},
            "assessment_falsifier": {"type": "string", "minLength": 1},
        },
    }
    return {
        "type": "object",
        "additionalProperties": False,
        "required": ["reviews"],
        "properties": {"reviews": {"type": "array", "items": review}},
    }


def selector_response_schema() -> dict[str, Any]:
    pair = {
        "type": "object",
        "additionalProperties": False,
        "required": list(PAIRWISE_FIELDS),
        "properties": {
            "candidate_step": {"type": "integer", "minimum": 1},
            "earliest_boundary_relation": {
                "type": "string",
                "enum": sorted(PAIRWISE_RELATIONS),
            },
            "candidate_outweighs_anchor": {"type": "boolean"},
            "candidate_path_effect": {"type": "string", "minLength": 1},
            "anchor_path_effect": {"type": "string", "minLength": 1},
            "comparison_basis": {"type": "string", "minLength": 1},
            "comparison_falsifier": {"type": "string", "minLength": 1},
        },
    }
    properties: dict[str, Any] = {
        "pairwise_comparisons": {"type": "array", "items": pair},
        "decision": {"type": "string", "enum": sorted(DECISIONS)},
        "selected_step": {"type": "integer", "minimum": 1},
        "selected_module": {"type": "string", "minLength": 1},
        "selected_error_type": {"type": "string", "minLength": 1},
        "selected_evidence_quote": {"type": "string", "minLength": 1},
        "selected_root_cause": {"type": "string", "minLength": 1},
        "selected_causal_summary": {"type": "string", "minLength": 1},
        "selected_rejected_adjacent_owner": {"type": "string", "minLength": 1},
        "global_decision_basis": {"type": "string", "minLength": 1},
        "selection_falsifier": {"type": "string", "minLength": 1},
    }
    return {
        "type": "object",
        "additionalProperties": False,
        "required": list(ASSESSMENT_FIELDS),
        "properties": properties,
    }


def build_local_inventory_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    ledger_steps = [int(row["step"]) for row in bundle[4]["rows"]]
    document = build_inference_document(case)
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_77_VERSION}: LOCAL FACT INVENTORY ONLY.

RUNTIME CONTRACT — RESPONSE ONLY
- model: {AGENT_JUDGE_LUNA_GAIA_V3_77_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_77_REASONING_EFFORT}
- one isolated case; do not call tools or read any external artifact
- no labels, metrics, old predictions, reports, experiment documents, git history, or identity priors
- return only the response-schema JSON object

ASSESSMENT CONTRACT
- Review exactly these bounded native-ledger Steps in order: {json.dumps(ledger_steps)}.
- The default anchor Step and all original ledger lanes, vetoes, selected flags,
  ranks, and decision bases are hidden. Do not infer or choose a final Step.
- Assess each Step independently from literal chronology. Record its concrete
  local defect class, actually observed next outcome, recovery, relation to the
  failed path, local path effect, and the next state produced by repairing only
  that Step.
- A reasonable probe or normal negative result is not an Agent error merely
  because it failed. A probe may still expose a concrete bad target, parameter,
  modality, constraint handoff, or state interpretation.
- Recovery requires an observed full repair of the path effect. Later repetition,
  faithful propagation, and vivid terminal failure do not create an earlier root.
- These reviews are frozen evidence facts, not votes and not criticality verdicts.
- Output one `reviews` row for every supplied Step and no other Step.

OWNER-EXPLICIT COMPLETE JUDGEVIEW
{json.dumps(document, ensure_ascii=False, separators=(",", ":"))}
"""


def _validate_inventory_record(
    raw: Any, *, ledger: dict[str, Any], location: str
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != INVENTORY_FIELDS:
        shared._fail("invalid_factorized_sparse_inventory_schema", location)
    expected = [int(row["step"]) for row in ledger["rows"]]
    reviews = raw["reviews"]
    if not isinstance(reviews, list) or len(reviews) != len(expected):
        shared._fail("incomplete_factorized_sparse_inventory", location)
    for index, (review, step) in enumerate(zip(reviews, expected, strict=True)):
        row_location = f"{location}.reviews[{index}]"
        if (
            not isinstance(review, dict)
            or tuple(review) != LOCAL_REVIEW_FIELDS
            or review["step"] != step
            or review["observed_defect_class"] not in DEFECT_CLASSES
            or review["recovery_status"] not in RECOVERY_STATUSES
            or review["outcome_relation"] not in OUTCOME_RELATIONS
        ):
            shared._fail("invalid_factorized_sparse_review", row_location)
        for field in LOCAL_REVIEW_FIELDS[2:]:
            if field in {"recovery_status", "outcome_relation"}:
                continue
            shared._nonempty_text(
                review[field], location=f"{row_location}.{field}", maximum=3200
            )
    return raw


def validate_local_inventory(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    inventory_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    inventory_file, value = shared._load_artifact(
        inventory_path, role="factorized sparse-ledger local inventory"
    )
    inventory = shared._one_record(value, role="factorized sparse-ledger local inventory")
    _validate_inventory_record(inventory, ledger=bundle[4], location="inventory[0]")
    inference = validate_inference_document(
        manifest, cohort, inventory_file.parent / INFERENCE_DOCUMENT_FILENAME
    )
    return _retag(
        {
            "schema_version": "agentdebug.factorized-sparse-ledger-local-inventory-audit.v1",
            "stage": "anchor_blind_native_sparse_ledger_local_fact_inventory",
            "gold_free_validation": True,
            "case_count": 1,
            "anchor_step_visible_to_local_inventory": False,
            "complete_native_ledger_review": True,
            "review_count": len(inventory["reviews"]),
            "owner_explicit_input": inference,
            "input_sha256": {
                "anchor": shared._file_sha256(bundle[0]),
                "ledger": shared._file_sha256(bundle[1]),
                "checkpoint": shared._file_sha256(bundle[2]),
            },
            "output_sha256": {PANEL_FILENAME: shared._file_sha256(inventory_file)},
        },
        policy="anchor_blind_factorized_native_sparse_ledger_local_facts",
    )


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_local_inventory(*paths[:-1]), paths[-1])


def build_pairwise_selector_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    inventory_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor, ledger = bundle[3:5]
    inventory_file, value = shared._load_artifact(
        inventory_path, role="factorized sparse-ledger local inventory"
    )
    inventory = shared._one_record(value, role="factorized sparse-ledger local inventory")
    _validate_inventory_record(inventory, ledger=ledger, location="inventory[0]")
    candidates = [
        int(row["step"])
        for row in ledger["rows"]
        if int(row["step"]) < int(anchor["predicted_step"])
    ]
    document = build_inference_document(case)
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_77_VERSION}: PAIRWISE GLOBAL SELECTION ONLY.

RUNTIME CONTRACT — RESPONSE ONLY
- model: {AGENT_JUDGE_LUNA_GAIA_V3_77_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_77_REASONING_EFFORT}
- one isolated case; do not call tools or read any external artifact
- no labels, metrics, old predictions, reports, experiment documents, git history, or identity priors
- return only the response-schema JSON object

PAIRWISE CONTRACT
- Fresh unchanged-v3.20 default anchor Step: {anchor['predicted_step']}.
- Compare each prefix Step against the anchor independently and in this order:
  {json.dumps(candidates)}.
- Frozen local reviews are evidence facts, not votes, ranks, or final verdicts.
- For every prefix, compare candidate-only repair and anchor-only repair on the
  next material state. A candidate outweighs the anchor only when it owns an
  earlier concrete unrecovered path-changing defect and the anchor is its
  noncritical predecessor, faithful propagation, or downstream symptom.
- A merely earlier surface flaw, reasonable probe, normal tool failure,
  recovered defect, or partial contributor does not outweigh the anchor.
- Do not favor later, stronger, repeated, or more verbose text. Do not favor the
  first row merely because it is early.
- Return one comparison for every prefix. Select at most one prefix. If no
  comparison has a clear literal advantage, exact-copy keep the anchor.
- Replacement evidence must be an exact substring from selected Step/Module
  `literal_owner_sources`. Module/type never rank Steps.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

FROZEN LOCAL FACT INVENTORY
{json.dumps(inventory, ensure_ascii=False, separators=(",", ":"))}

OWNER-EXPLICIT COMPLETE JUDGEVIEW
{json.dumps(document, ensure_ascii=False, separators=(",", ":"))}

FRESH DEFAULT ANCHOR PAYLOAD
{json.dumps(anchor, ensure_ascii=False, separators=(",", ":"))}
"""


def normalize_selector_response(
    response: Any, *, anchor: dict[str, Any], case: Any
) -> Any:
    if not isinstance(response, dict):
        return response
    value = json.loads(json.dumps(response))
    if (
        value.get("decision") == "keep_anchor"
        and value.get("selected_step") == anchor.get("predicted_step")
    ):
        value.update(
            {
                "selected_module": anchor["predicted_module"],
                "selected_error_type": anchor["predicted_error_type"],
                "selected_evidence_quote": anchor["evidence_quote"],
                "selected_root_cause": anchor["root_cause"],
                "selected_causal_summary": anchor["causal_summary"],
                "selected_rejected_adjacent_owner": anchor[
                    "rejected_adjacent_owner"
                ],
            }
        )
        return value
    prediction = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        "predicted_step": value.get("selected_step"),
        "predicted_module": value.get("selected_module"),
        "predicted_error_type": value.get("selected_error_type"),
        "evidence_quote": value.get("selected_evidence_quote"),
        "root_cause": value.get("selected_root_cause"),
        "causal_summary": value.get("selected_causal_summary"),
        "rejected_adjacent_owner": value.get("selected_rejected_adjacent_owner"),
    }
    materialized = _materialize_owned_prediction(prediction, case=case)
    if materialized.get("predicted_step") != value.get("selected_step"):
        raise RuntimeError("v3.77 legality materialization changed Step")
    value.update(
        {
            "selected_module": materialized.get("predicted_module"),
            "selected_error_type": materialized.get("predicted_error_type"),
            "selected_evidence_quote": materialized.get("evidence_quote"),
        }
    )
    return value


def _selected_prediction(case: Any, assessment: dict[str, Any]) -> dict[str, Any]:
    return legality._selected_prediction(case, assessment)


def _validate_selector_assessment(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != ASSESSMENT_FIELDS:
        shared._fail("invalid_factorized_sparse_selector_schema", location)
    anchor_step = int(anchor["predicted_step"])
    candidates = [
        int(row["step"])
        for row in ledger["rows"]
        if int(row["step"]) < anchor_step
    ]
    pairs = raw["pairwise_comparisons"]
    if not isinstance(pairs, list) or len(pairs) != len(candidates):
        shared._fail("incomplete_factorized_sparse_pairwise_comparisons", location)
    for index, (pair, step) in enumerate(zip(pairs, candidates, strict=True)):
        pair_location = f"{location}.pairwise_comparisons[{index}]"
        if (
            not isinstance(pair, dict)
            or tuple(pair) != PAIRWISE_FIELDS
            or pair["candidate_step"] != step
            or pair["earliest_boundary_relation"] not in PAIRWISE_RELATIONS
            or not isinstance(pair["candidate_outweighs_anchor"], bool)
        ):
            shared._fail("invalid_factorized_sparse_pairwise_row", pair_location)
        for field in PAIRWISE_FIELDS[3:]:
            shared._nonempty_text(
                pair[field], location=f"{pair_location}.{field}", maximum=3200
            )
    decision = raw["decision"]
    selected_step = raw["selected_step"]
    if decision not in DECISIONS:
        shared._fail("invalid_factorized_sparse_selector_decision", location)
    if decision == "keep_anchor":
        if selected_step != anchor_step:
            shared._fail("factorized_sparse_keep_step_mismatch", location)
    else:
        matching = [
            pair
            for pair in pairs
            if pair["candidate_step"] == selected_step
            and pair["candidate_outweighs_anchor"] is True
            and pair["earliest_boundary_relation"]
            == "candidate_earlier_critical_boundary"
        ]
        if selected_step not in candidates or len(matching) != 1:
            shared._fail("factorized_sparse_prefix_not_pairwise_winner", location)
    for field in (
        "selected_root_cause",
        "selected_causal_summary",
        "selected_rejected_adjacent_owner",
        "global_decision_basis",
        "selection_falsifier",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3200)
    prediction = _selected_prediction(case, raw)
    if decision == "keep_anchor" and prediction != anchor:
        shared._fail("factorized_sparse_keep_not_exact_anchor_copy", location)
    return raw


def validate_selector_assessment(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    inventory_path: str | Path,
    assessment_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    inventory_file, inventory_raw = shared._load_artifact(
        inventory_path, role="factorized sparse-ledger local inventory"
    )
    inventory = shared._one_record(
        inventory_raw, role="factorized sparse-ledger local inventory"
    )
    _validate_inventory_record(inventory, ledger=bundle[4], location="inventory[0]")
    assessment_file, assessment_raw = shared._load_artifact(
        assessment_path, role="factorized sparse-ledger pairwise assessment"
    )
    assessment = shared._one_record(
        assessment_raw, role="factorized sparse-ledger pairwise assessment"
    )
    _validate_selector_assessment(
        assessment,
        case=case,
        anchor=bundle[3],
        ledger=bundle[4],
        location="assessment[0]",
    )
    inference = validate_inference_document(
        manifest, cohort, assessment_file.parent / INFERENCE_DOCUMENT_FILENAME
    )
    return _retag(
        {
            "schema_version": "agentdebug.factorized-sparse-ledger-pairwise-assessment-audit.v1",
            "stage": "factorized_sparse_ledger_pairwise_global_selection",
            "gold_free_validation": True,
            "case_count": 1,
            "pairwise_comparison_count": len(assessment["pairwise_comparisons"]),
            "decision": assessment["decision"],
            "model_selected_step_preserved": True,
            "owner_explicit_input": inference,
            "input_sha256": {
                "anchor": shared._file_sha256(bundle[0]),
                "ledger": shared._file_sha256(bundle[1]),
                "checkpoint": shared._file_sha256(bundle[2]),
                "inventory": shared._file_sha256(inventory_file),
            },
            "output_sha256": {
                SELECTOR_ASSESSMENT_FILENAME: shared._file_sha256(assessment_file)
            },
        },
        policy="factorized_native_sparse_ledger_pairwise_global_selection",
    )


def validate_and_write_selector_assessment_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(
        validate_selector_assessment(*paths[:-1]), paths[-1]
    )


def build_selection_document(
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    inventory: dict[str, Any],
    assessment: dict[str, Any],
) -> dict[str, Any]:
    local = _validate_inventory_record(
        inventory, ledger=ledger, location="inventory"
    )
    semantic = _validate_selector_assessment(
        assessment,
        case=case,
        anchor=anchor,
        ledger=ledger,
        location="assessment",
    )
    selected = _selected_prediction(case, semantic)
    result = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "inventory_sha256": shared._stable_sha256(local),
        "assessment_sha256": shared._stable_sha256(semantic),
        "decision": semantic["decision"],
        "anchor_step": anchor["predicted_step"],
        "reviewed_steps": [row["step"] for row in local["reviews"]],
        "selected_step": semantic["selected_step"],
        "frozen_step": selected["predicted_step"],
        "selected_prediction_sha256": shared._stable_sha256(selected),
        "selected_prediction": selected,
        "local_inventory": local,
        "semantic_assessment": semantic,
    }
    return result


def validate_selector(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    inventory_path: str | Path,
    assessment_path: str | Path,
    selector_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    inventory = shared._one_record(
        shared._load_artifact(inventory_path, role="factorized sparse inventory")[1],
        role="factorized sparse inventory",
    )
    assessment = shared._one_record(
        shared._load_artifact(assessment_path, role="factorized sparse assessment")[1],
        role="factorized sparse assessment",
    )
    selector_file, selector_raw = shared._load_artifact(
        selector_path, role="factorized sparse selection"
    )
    selector = shared._one_record(selector_raw, role="factorized sparse selection")
    if not isinstance(selector, dict) or tuple(selector) != SELECTION_FIELDS:
        shared._fail("invalid_factorized_sparse_selection_schema", "selection[0]")
    expected = build_selection_document(
        case=case,
        anchor=bundle[3],
        ledger=bundle[4],
        checkpoint=bundle[5],
        inventory=inventory,
        assessment=assessment,
    )
    if selector != expected:
        shared._fail("non_deterministic_factorized_sparse_selection", "selection[0]")
    return _retag(
        {
            "schema_version": "agentdebug.factorized-sparse-ledger-selection-audit.v1",
            "stage": "deterministic_factorized_sparse_selection_binding",
            "gold_free_validation": True,
            "case_count": 1,
            "selected_prediction_exact_copy": True,
            "model_selected_step_preserved": True,
            "output_sha256": {SELECTOR_FILENAME: shared._file_sha256(selector_file)},
        },
        policy="deterministic_factorized_sparse_pairwise_selection_copy",
    )


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_selector(*paths[:-1]), paths[-1])


def _validate_aggregate(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(
        prediction_manifest_path, cohort_manifest_path
    )
    root = Path(predictions_path).expanduser().resolve().parent
    names = (
        ANCHOR_PREDICTIONS_FILENAME,
        ANCHOR_LEDGER_AGGREGATE_FILENAME,
        ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        PANELS_FILENAME,
        SELECTORS_FILENAME,
    )
    loaded = {
        name: shared._load_artifact(root / name, role=f"merged {name}")[1]
        for name in names
    }
    if any(
        not isinstance(value, list) or len(value) != len(cases)
        for value in loaded.values()
    ):
        shared._fail("invalid_factorized_sparse_aggregate_count", "merged artifacts")
    finals = shared._load_artifact(predictions_path, role="merged predictions")[1]
    if not isinstance(finals, list) or len(finals) != len(cases):
        shared._fail("invalid_factorized_sparse_prediction_count", "predictions")
    decisions: Counter[str] = Counter()
    review_counts: Counter[int] = Counter()
    for index, case in enumerate(cases):
        anchor = shared._validate_prediction_record(
            loaded[ANCHOR_PREDICTIONS_FILENAME][index],
            case=case,
            location=f"merged[{index}].anchor",
        )
        ledger = loaded[ANCHOR_LEDGER_AGGREGATE_FILENAME][index]
        checkpoint = loaded[ANCHOR_CHECKPOINT_AGGREGATE_FILENAME][index]
        inventory = loaded[PANELS_FILENAME][index]
        selector = loaded[SELECTORS_FILENAME][index]
        _validate_inventory_record(
            inventory, ledger=ledger, location=f"merged[{index}].inventory"
        )
        expected = build_selection_document(
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            inventory=inventory,
            assessment=selector["semantic_assessment"],
        )
        if selector != expected or finals[index] != selector["selected_prediction"]:
            shared._fail("factorized_sparse_aggregate_binding_mismatch", f"merged[{index}]")
        decisions[selector["decision"]] += 1
        review_counts[len(inventory["reviews"])] += 1
    return {
        "required": True,
        "valid": True,
        "anchor_blind_local_inventory": True,
        "complete_native_ledger_review": True,
        "all_final_steps_model_selected": True,
        "all_final_predictions_exact_selection_copies": True,
        "selector_decision_counts": dict(sorted(decisions.items())),
        "review_count_distribution": {
            str(key): value for key, value in sorted(review_counts.items())
        },
        "packet_state_closure": parent._validate_packet_state_ledgers(
            root / ANCHOR_LEDGER_AGGREGATE_FILENAME
        ),
    }


def validate_agent_judge_luna_gaia_v3_77_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    aggregate = _validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return _retag(
        {
            **audit,
            "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_77_AUDIT_SCHEMA_VERSION,
            "anchor_semantics_unchanged_from_v3_20": True,
            "owner_explicit_response_only_runtime_required": True,
            "all_selected_predictions_exact_copies": True,
            "factorized_sparse_ledger_pairwise_selector": aggregate,
        },
        policy="factorized_native_sparse_ledger_local_facts_then_pairwise_selector",
    )


def validate_and_write_agent_judge_luna_gaia_v3_77_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(
        validate_agent_judge_luna_gaia_v3_77_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_luna_gaia_v3_77_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_pairwise_selector_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME,
        prediction.parent / ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        prediction.parent / PANELS_FILENAME,
    )


validate_and_write_agent_judge_luna_gaia_v3_67_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_77_audit
)
validate_and_write_agent_judge_luna_gaia_v3_37_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_77_audit
)
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_luna_gaia_v3_77_task

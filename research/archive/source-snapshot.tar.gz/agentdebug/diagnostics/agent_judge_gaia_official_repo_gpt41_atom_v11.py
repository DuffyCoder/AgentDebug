"""Owner-neutral evidence-atom protocol for the GPT-4.1 GAIA hard gate.

The protocol is deliberately split into three serialized model calls.  The
boundary call selects only opaque, owner-neutral local evidence IDs and writes
one falsifiable defect predicate.  The parent derives the step and literal
evidence, freezes the predicate, and exposes only compatible same-step owner
atoms to the module call.  The type call can select only a taxonomy member for
that frozen owner.  Neither downstream call can rewrite the boundary.

This module is gold-free.  It consumes only a ``PredictionCase``-like object
whose ``judge_view`` is the persisted canonical projection.
"""

from __future__ import annotations

import ast
import hashlib
import json
import re
from pathlib import Path
from typing import Any, Mapping, Sequence

from agentdebug.benchmark.prediction_manifest import stable_sha256
from agentdebug.benchmark.prediction_manifest import load_prediction_manifest

from .agent_judge import (
    AgentJudgeValidationError,
    _cohort_document,
    _load_json,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_gaia_official_repo_gpt41_candidate_v3 import observation_text
from .agent_judge_gaia_official_repo_gpt41_serial_v4 import serial_owner_sources
from .taxonomy import AgentModule, ErrorType, TAXONOMY


VERSION = "agentdebug.llm-judge.gaia-official-repo-gpt4.1-atom-v11"
MODEL = "gpt-4.1"
RESOLVED_MODEL = "gpt-4.1-2025-04-14"
TEMPERATURE = 0.0
REASONING_EFFORT = "not_applicable"
AUDIT_SCHEMA_VERSION = "agentdebug.gpt41-gaia-atom-v11-audit.v1"
CATALOG_SCHEMA_VERSION = "agentdebug.gpt41-gaia-atom-v11-catalog.v1"

BOUNDARY_DECISION_FILENAME = "boundary-decision.json"
MODULE_DECISION_FILENAME = "module-decision.json"
TYPE_DECISION_FILENAME = "type-decision.json"

BOUNDARY_SYSTEM_PROMPT = (
    "You are the boundary stage of a causal diagnostic judge. Select one supplied "
    "owner-neutral relation and one of its selectable local atoms. Return only JSON."
)
MODULE_SYSTEM_PROMPT = (
    "You are the ownership stage of a causal diagnostic judge. The step, evidence "
    "relation, and defect predicate are frozen. Select one supplied owner atom and "
    "return only JSON."
)
TYPE_SYSTEM_PROMPT = (
    "You are the taxonomy stage of a causal diagnostic judge. The boundary, defect "
    "predicate, and owner are frozen. Select one supplied type ID and return only JSON."
)

_BOUNDARY_FIELDS = frozenset(
    {
        "selected_relation_id",
        "selected_local_atom_id",
        "defect_predicate",
        "counterfactual_correction",
        "selection_reason",
        "rejected_adjacent_boundary",
    }
)
_MODULE_FIELDS = frozenset(
    {"selected_owner_atom_id", "ownership_reason", "rejected_owner_option"}
)
_TYPE_FIELDS = frozenset(
    {"selected_type_id", "type_reason", "rejected_type_option"}
)
_BOUNDARY_AUDIT_FIELDS = frozenset(
    {
        "schema_version",
        "stage",
        "protocol",
        "catalog_sha256",
        "selected_relation_id",
        "selected_local_atom_id",
        "selected_step",
        "derived_locus",
        "derived_evidence_scope",
        "derived_evidence_quote",
        "defect_predicate",
        "counterfactual_correction",
        "selection_reason",
        "rejected_adjacent_boundary",
        "compatible_owner_atom_ids",
        "defect_freeze_sha256",
        "semantic_identity",
        "model_reported_step_or_quote",
        "owner_neutral_boundary_catalog",
    }
)
_MODULE_AUDIT_FIELDS = frozenset(
    {
        "schema_version",
        "stage",
        "protocol",
        "catalog_sha256",
        "defect_freeze_sha256",
        "selected_owner_atom_id",
        "selected_step",
        "selected_module",
        "derived_owner_evidence_quote",
        "allowed_error_types",
        "ownership_reason",
        "rejected_owner_option",
        "semantic_identity",
        "step_matches_frozen_boundary",
        "model_rewrote_frozen_predicate",
    }
)
_TYPE_AUDIT_FIELDS = frozenset(
    {
        "schema_version",
        "stage",
        "protocol",
        "catalog_sha256",
        "defect_freeze_sha256",
        "selected_owner_atom_id",
        "selected_type_id",
        "selected_error_type",
        "type_reason",
        "rejected_type_option",
        "type_freeze_sha256",
        "semantic_identity",
        "model_rewrote_frozen_predicate_or_owner",
    }
)
_RELATION_KINDS = frozenset(
    {
        "same_step_commitment_execution",
        "prior_result_current_interpretation",
        "guarded_external_outcome",
        "terminal_output",
        "deterministic_recurrence_episode",
    }
)
_ID_PATTERNS = {
    "local": re.compile(r"LA-[0-9]{4}"),
    "owner": re.compile(r"OA-[0-9]{4}"),
    "relation": re.compile(r"BR-[0-9]{4}"),
    "type": re.compile(r"T-[0-9]{2}"),
}
_FRAGMENT_MAX_CHARS = 960
_FRAGMENT_OVERLAP_CHARS = 96
_HARD_SERVICE_MARKERS = (
    "invalid model id",
    "model_not_found",
    "does not exist or you do not have access",
    "429 too many requests",
    "too many requests",
    "rate limit",
    "500 internal server error",
    "502 bad gateway",
    "503 service unavailable",
    "504 gateway timeout",
    "connection refused",
    "connection reset",
    "timed out",
)
_PARAMETER_FAILURE_MARKERS = (
    "missing parameter",
    "missing required",
    "invalid parameter",
    "invalid arguments",
    "validation error",
    "unknown tool",
    "malformed",
    "unsupported operand type",
)
_IDENTITY_VALUE_CACHE: dict[tuple[str, int], tuple[str, ...]] = {}


def _fail(code: str, message: str) -> None:
    raise AgentJudgeValidationError(code, message)


def _required_text(value: Any, location: str) -> str:
    if not isinstance(value, str) or not value.strip():
        _fail("invalid_stage_text", f"{location} must be non-empty text")
    return value.strip()


def _exact_fields(value: Any, expected: frozenset[str], location: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping) or set(value) != expected:
        _fail(
            "invalid_stage_fields",
            f"{location} fields must be exactly {sorted(expected)}",
        )
    return value


def _raw_sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _source_fragments(source: str) -> tuple[tuple[int, int, str], ...]:
    """Return exact bounded source slices; never insert synthetic ellipses."""

    if not source:
        return ()
    if len(source) <= _FRAGMENT_MAX_CHARS:
        return ((0, len(source), source),)
    values: list[tuple[int, int, str]] = []
    start = 0
    while start < len(source):
        hard_end = min(start + _FRAGMENT_MAX_CHARS, len(source))
        end = hard_end
        if hard_end < len(source):
            minimum = start + (_FRAGMENT_MAX_CHARS // 2)
            boundaries = [
                source.rfind(separator, minimum, hard_end)
                for separator in ("\n\n", "\n", ". ", "; ", ", ", " ")
            ]
            boundary = max(boundaries)
            if boundary >= minimum:
                end = boundary + (2 if source[boundary : boundary + 2] == ". " else 1)
        values.append((start, end, source[start:end]))
        if end == len(source):
            break
        next_start = max(start + 1, end - _FRAGMENT_OVERLAP_CHARS)
        start = next_start
    return tuple(values)


def _catalog_body(catalog: Mapping[str, Any]) -> dict[str, Any]:
    body = dict(catalog)
    body.pop("catalog_sha256", None)
    return body


def _check_catalog(catalog: Mapping[str, Any]) -> None:
    if not isinstance(catalog, Mapping):
        _fail("invalid_atom_catalog", "catalog must be an object")
    expected = {
        "schema_version",
        "trajectory_sha256",
        "owner_atoms",
        "local_atoms",
        "boundary_relations",
        "hard_system_root_policy",
        "catalog_sha256",
    }
    if set(catalog) != expected or catalog.get("schema_version") != CATALOG_SCHEMA_VERSION:
        _fail("invalid_atom_catalog", "catalog fields/version are invalid")
    if catalog.get("catalog_sha256") != stable_sha256(_catalog_body(catalog)):
        _fail("invalid_atom_catalog_hash", "catalog hash is invalid")
    if re.fullmatch(r"[0-9a-f]{64}", str(catalog.get("trajectory_sha256"))) is None:
        _fail("invalid_atom_catalog", "catalog trajectory hash is invalid")
    owner_atoms = catalog.get("owner_atoms")
    local_atoms = catalog.get("local_atoms")
    relations = catalog.get("boundary_relations")
    if not isinstance(owner_atoms, list) or not owner_atoms:
        _fail("invalid_atom_catalog", "owner atom catalog must be non-empty")
    if not isinstance(local_atoms, list) or not local_atoms:
        _fail("invalid_atom_catalog", "local atom catalog must be non-empty")
    if not isinstance(relations, list) or not relations:
        _fail("invalid_atom_catalog", "boundary relation catalog must be non-empty")

    def check_ranges(value: Any, *, quote: str, location: str) -> None:
        if not isinstance(value, list) or not value:
            _fail("invalid_atom_catalog", f"{location} source ranges are invalid")
        canonical: list[tuple[str, int, int]] = []
        for item in value:
            if not isinstance(item, Mapping) or set(item) != {
                "source_sha256",
                "start_char",
                "end_char",
            }:
                _fail("invalid_atom_catalog", f"{location} source range fields differ")
            source_hash = item["source_sha256"]
            start = item["start_char"]
            end = item["end_char"]
            if (
                re.fullmatch(r"[0-9a-f]{64}", str(source_hash)) is None
                or isinstance(start, bool)
                or not isinstance(start, int)
                or isinstance(end, bool)
                or not isinstance(end, int)
                or start < 0
                or end <= start
                or end - start != len(quote)
            ):
                _fail("invalid_atom_catalog", f"{location} source range is invalid")
            canonical.append((str(source_hash), start, end))
        if canonical != sorted(set(canonical)):
            _fail("invalid_atom_catalog", f"{location} source ranges are not canonical")

    owner_by_id: dict[str, Mapping[str, Any]] = {}
    for index, owner in enumerate(owner_atoms, 1):
        expected_fields = {
            "owner_atom_id",
            "step",
            "module",
            "quote",
            "raw_sha256",
            "allowed_error_types",
            "source_ranges",
        }
        if not isinstance(owner, Mapping) or set(owner) != expected_fields:
            _fail("invalid_atom_catalog", "owner atom fields differ")
        owner_id = owner["owner_atom_id"]
        if owner_id != f"OA-{index:04d}":
            _fail("invalid_atom_catalog", "owner atom IDs are not canonical")
        quote = owner["quote"]
        if (
            isinstance(owner["step"], bool)
            or not isinstance(owner["step"], int)
            or owner["step"] < 1
            or not isinstance(quote, str)
            or not quote.strip()
            or len(quote) > _FRAGMENT_MAX_CHARS
            or owner["raw_sha256"] != _raw_sha256(quote)
        ):
            _fail("invalid_atom_catalog", "owner atom content is invalid")
        try:
            module = AgentModule(str(owner["module"]))
        except ValueError:
            _fail("invalid_atom_catalog", "owner atom module is invalid")
        expected_types = (
            [ErrorType.TOOL_EXECUTION_ERROR.value]
            if module == AgentModule.SYSTEM
            else sorted(item.value for item in TAXONOMY[module])
        )
        if owner["allowed_error_types"] != expected_types:
            _fail("invalid_atom_catalog", "owner atom allowed types are invalid")
        check_ranges(owner["source_ranges"], quote=quote, location=str(owner_id))
        owner_by_id[str(owner_id)] = owner

    local_by_id: dict[str, Mapping[str, Any]] = {}
    owner_occurrences: dict[str, int] = {owner_id: 0 for owner_id in owner_by_id}
    for index, atom in enumerate(local_atoms, 1):
        expected_fields = {
            "local_atom_id",
            "step",
            "quote",
            "raw_sha256",
            "source_kind",
            "compatible_owner_atom_ids",
            "source_ranges",
            "selectable",
        }
        if not isinstance(atom, Mapping) or set(atom) != expected_fields:
            _fail("invalid_atom_catalog", "local atom fields differ")
        atom_id = atom["local_atom_id"]
        if atom_id != f"LA-{index:04d}":
            _fail("invalid_atom_catalog", "local atom IDs are not canonical")
        quote = atom["quote"]
        owners = atom["compatible_owner_atom_ids"]
        if (
            isinstance(atom["step"], bool)
            or not isinstance(atom["step"], int)
            or atom["step"] < 1
            or not isinstance(quote, str)
            or not quote.strip()
            or len(quote) > _FRAGMENT_MAX_CHARS
            or atom["raw_sha256"] != _raw_sha256(quote)
            or atom["source_kind"]
            not in {"agent_output", "adjacent_feedback", "guarded_external_outcome"}
            or not isinstance(owners, list)
            or owners != sorted(set(owners))
            or type(atom["selectable"]) is not bool
            or atom["selectable"] != bool(owners)
        ):
            _fail("invalid_atom_catalog", "local atom content is invalid")
        check_ranges(atom["source_ranges"], quote=quote, location=str(atom_id))
        for owner_id in owners:
            owner = owner_by_id.get(str(owner_id))
            if (
                owner is None
                or owner["step"] != atom["step"]
                or owner["quote"] != quote
            ):
                _fail("invalid_atom_catalog", "local/owner atom binding is invalid")
            owner_occurrences[str(owner_id)] += 1
        local_by_id[str(atom_id)] = atom
    if any(count != 1 for count in owner_occurrences.values()):
        _fail("invalid_atom_catalog", "each owner atom must bind one local atom")

    seen_relations: set[tuple[Any, ...]] = set()
    for index, relation in enumerate(relations, 1):
        common_fields = {
            "relation_id",
            "relation_kind",
            "member_local_atom_ids",
            "reference_local_atom_ids",
            "selected_steps",
        }
        recurrence_fields = {
            "recurrence_prior_steps",
            "action_signature_sha256",
            "observation_sha256",
        }
        if not isinstance(relation, Mapping) or frozenset(relation) not in {
            frozenset(common_fields),
            frozenset(common_fields | recurrence_fields),
        }:
            _fail("invalid_atom_catalog", "boundary relation fields differ")
        if relation["relation_id"] != f"BR-{index:04d}":
            _fail("invalid_atom_catalog", "boundary relation IDs are not canonical")
        kind = relation["relation_kind"]
        members = relation["member_local_atom_ids"]
        references = relation["reference_local_atom_ids"]
        if (
            kind not in _RELATION_KINDS
            or not isinstance(members, list)
            or not members
            or members != sorted(set(members))
            or not isinstance(references, list)
            or references != sorted(set(references))
            or any(item not in local_by_id for item in members + references)
            or any(not local_by_id[item]["selectable"] for item in members)
        ):
            _fail("invalid_atom_catalog", "boundary relation references are invalid")
        expected_steps = sorted({int(local_by_id[item]["step"]) for item in members})
        if relation["selected_steps"] != expected_steps:
            _fail("invalid_atom_catalog", "boundary relation steps are invalid")
        geometry = (kind, tuple(members), tuple(references))
        if geometry in seen_relations:
            _fail("invalid_atom_catalog", "duplicate boundary relation geometry")
        seen_relations.add(geometry)
        if kind == "same_step_commitment_execution" and len(expected_steps) != 1:
            _fail("invalid_atom_catalog", "same-step relation crosses steps")
        if kind == "prior_result_current_interpretation" and (
            len(expected_steps) != 2 or expected_steps[1] != expected_steps[0] + 1
        ):
            _fail("invalid_atom_catalog", "interpretation relation is not adjacent")
        if kind == "guarded_external_outcome":
            if len(expected_steps) != 1 or any(
                not any(
                    owner_by_id[owner_id]["module"] == AgentModule.SYSTEM.value
                    for owner_id in local_by_id[item]["compatible_owner_atom_ids"]
                )
                for item in members
            ):
                _fail("invalid_atom_catalog", "guarded System relation is invalid")
        if kind == "deterministic_recurrence_episode":
            priors = relation.get("recurrence_prior_steps")
            if (
                set(relation) != common_fields | recurrence_fields
                or not isinstance(priors, list)
                or len(priors) != 2
                or priors != sorted(set(priors))
                or any(step >= expected_steps[0] for step in priors)
                or re.fullmatch(r"[0-9a-f]{64}", str(relation["action_signature_sha256"]))
                is None
                or re.fullmatch(r"[0-9a-f]{64}", str(relation["observation_sha256"]))
                is None
            ):
                _fail("invalid_atom_catalog", "recurrence relation is invalid")

    policy = catalog.get("hard_system_root_policy")
    if not isinstance(policy, Mapping) or set(policy) != {
        "policy_version",
        "applied",
        "deterministic_boundary_bypass",
        "selected_relation_id",
        "decision_reason",
    }:
        _fail("invalid_atom_catalog", "hard-System root policy is invalid")
    guarded = [item for item in relations if item["relation_kind"] == "guarded_external_outcome"]
    applied = policy.get("applied") is True
    if (
        policy.get("policy_version") != "unique-causally-guarded-hard-system-root-v1"
        or type(policy.get("applied")) is not bool
        or policy.get("deterministic_boundary_bypass") is not applied
        or (applied and (len(relations) != 1 or len(guarded) != 1))
        or (applied and policy.get("selected_relation_id") != guarded[0]["relation_id"])
        or (not applied and policy.get("selected_relation_id") is not None)
    ):
        _fail("invalid_atom_catalog", "hard-System root policy is inconsistent")


def _check_case_catalog(case: Any, catalog: Mapping[str, Any]) -> None:
    """Reject a coordinated rehash by rebuilding from the frozen JudgeView."""

    _check_catalog(catalog)
    if catalog["trajectory_sha256"] != case.trajectory_sha256:
        _fail("catalog_case_mismatch", "catalog is not for this case")
    expected = build_atom_v11_catalog(case)
    if expected["catalog_sha256"] != catalog["catalog_sha256"]:
        _fail("catalog_rebuild_mismatch", "catalog differs from the deterministic rebuild")


def _private_identity_values(case: Any) -> tuple[str, ...]:
    cache_key = (str(getattr(case, "trajectory_sha256", "")), id(case.judge_view))
    cached = _IDENTITY_VALUE_CACHE.get(cache_key)
    if cached is not None:
        return cached
    values: set[str] = set()
    for value in (
        getattr(case, "trajectory_id", None),
        getattr(case, "trajectory_sha256", None),
        getattr(case, "case_input_sha256", None),
        getattr(case.judge_view, "trace_id", None),
    ):
        if isinstance(value, str) and value:
            values.add(value)
    trajectory_id = str(getattr(case, "trajectory_id", ""))
    if trajectory_id:
        values.add(trajectory_id.split("_", 1)[0])
        if "-" in trajectory_id:
            values.add(trajectory_id.rsplit("-", 1)[0])

    if hasattr(case.judge_view, "to_dict"):
        root: Any = case.judge_view.to_dict()
    else:
        root = vars(case.judge_view) if hasattr(case.judge_view, "__dict__") else {}

    def visit(value: Any, key: str = "") -> None:
        normalized = key.casefold()
        identity_key = (
            normalized in {"id", "path", "sha", "sha256"}
            or normalized.endswith(("_id", "_ids", "_path", "_sha", "_sha256"))
        )
        if isinstance(value, Mapping):
            for child_key, child in value.items():
                visit(child, str(child_key))
        elif isinstance(value, (list, tuple)):
            for child in value:
                visit(child, key)
        elif identity_key and isinstance(value, str) and value:
            values.add(value)

    visit(root)
    result = tuple(sorted(values, key=lambda value: (-len(value), value)))
    _IDENTITY_VALUE_CACHE[cache_key] = result
    return result


def _redact(case: Any, text: str, *, limit: int = 720) -> str:
    value = str(text)
    for secret in _private_identity_values(case):
        if secret:
            value = value.replace(secret, "ANONYMOUS-TRACE")
    value = re.sub(
        r"/(?:root|home|tmp|workspace)/[^\s\r\n\"']+",
        "ANONYMOUS-PATH",
        value,
    ).strip()
    value = re.sub(
        r"(?i)\b[0-9a-f]{64}\b", "ANONYMOUS-CONTENT-HASH", value
    )
    # Boundary cards are owner-neutral even when the canonical source uses
    # explicit AgentErrorBench module markup.  The private quote is untouched.
    value = re.sub(
        r"</?(?:memory|memory_recall|reflection|plan|action|tool_call|answer|think)\b[^>]*>",
        "",
        value,
        flags=re.IGNORECASE,
    ).strip()
    if len(value) <= limit:
        return value
    half = (limit - 35) // 2
    return f"{value[:half]}\n...[bounded exact-source preview]...\n{value[-half:]}"


def _step_observation(step: Any) -> str:
    values = [observation_text(item) for item in step.adjacent_feedback]
    return "\n\n".join(value for value in values if value.strip())


def _available_tool_schemas(case: Any) -> dict[str, dict[str, Any]]:
    task = case.judge_view.task
    text = (task.user_request or task.display_text) if task is not None else ""
    matches = list(re.finditer(r"(?m)^\s*Tool:\s*([^\s]+)\s*$", text))
    schemas: dict[str, dict[str, Any]] = {}
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        block = text[match.end() : end]
        schema_match = re.search(r"(?m)^\s*Input Types:\s*(\{[^\n]*\})\s*$", block)
        if schema_match is None:
            continue
        try:
            parsed = ast.literal_eval(schema_match.group(1))
        except (SyntaxError, ValueError):
            continue
        if isinstance(parsed, Mapping):
            schemas[match.group(1).casefold()] = {
                str(key): item for key, item in parsed.items()
            }
    return schemas


def _action_calls(step: Any) -> list[dict[str, Any]]:
    calls: list[dict[str, Any]] = []
    for call in step.tool_calls:
        arguments = call.arguments
        if isinstance(arguments, str):
            try:
                arguments = json.loads(arguments)
            except json.JSONDecodeError:
                arguments = None
        calls.append(
            {
                "tool": (call.normalized_name or call.name).casefold(),
                "parameters": arguments,
                "partial_arguments": call.partial_arguments,
            }
        )
    for span in step.module_spans:
        if span.module != AgentModule.ACTION.value:
            continue
        body = step.assistant_raw_output[span.content_start_char : span.content_end_char]
        tool = re.search(r"(?m)^\s*tool:\s*([^\s]+)\s*$", body)
        parameters = re.search(r"(?ms)^\s*parameters:\s*(\{.*\})\s*$", body)
        if tool is None or parameters is None:
            continue
        try:
            parsed = json.loads(parameters.group(1))
        except json.JSONDecodeError:
            parsed = None
        calls.append(
            {
                "tool": tool.group(1).casefold(),
                "parameters": parsed,
                "partial_arguments": None,
            }
        )
    return calls


def _parameters_match_schema(parameters: Any, schema: Mapping[str, Any]) -> bool:
    if not isinstance(parameters, Mapping) or not schema:
        return False
    keys = {str(key) for key in parameters}
    if not keys <= set(schema):
        return False
    required = {
        name
        for name, description in schema.items()
        if "default" not in str(description).casefold()
    }
    if not required <= keys:
        return False
    for name, value in parameters.items():
        descriptor = str(schema[str(name)]).strip().casefold()
        if descriptor.startswith("str") and not (
            isinstance(value, str) and value.strip()
        ):
            return False
        if descriptor.startswith("int") and type(value) is not int:
            return False
        if descriptor.startswith(("float", "number")) and type(value) not in {int, float}:
            return False
        if descriptor.startswith("bool") and type(value) is not bool:
            return False
        if descriptor.startswith("list") and not isinstance(value, list):
            return False
        if descriptor.startswith(("dict", "object")) and not isinstance(value, Mapping):
            return False
    return True


def _hard_system_policy(case: Any, selected_step: int) -> dict[str, Any]:
    """Exact local copy of the v5 causally-guarded hard-System rule."""

    step = case.judge_view.steps[selected_step - 1]
    evidence = _step_observation(step)
    lowered = evidence.casefold()
    policy: dict[str, Any] = {
        "policy_version": "causally-guarded-hard-system-v1",
        "selected_step": selected_step,
        "applied": False,
        "decision_reason": "no_high_precision_provider_failure",
    }
    marker = next((item for item in _HARD_SERVICE_MARKERS if item in lowered), None)
    if marker is None:
        return policy
    if any(item in lowered for item in _PARAMETER_FAILURE_MARKERS):
        policy["decision_reason"] = "observation_reports_parameter_or_tool_error"
        return policy
    match = re.search(r"(?i)error executing tool\s+['\"]([^'\"]+)['\"]", evidence)
    if match is None:
        policy["decision_reason"] = "not_explicit_tool_execution_exception"
        return policy
    tool = match.group(1).casefold()
    schemas = _available_tool_schemas(case)
    if tool not in schemas:
        policy["decision_reason"] = "tool_not_listed_with_schema"
        return policy
    calls = [item for item in _action_calls(step) if item["tool"] == tool]
    if not calls or calls[-1]["partial_arguments"] not in (None, {}):
        policy["decision_reason"] = "no_complete_matching_action"
        return policy
    if not _parameters_match_schema(calls[-1]["parameters"], schemas[tool]):
        policy["decision_reason"] = "action_not_mechanically_valid"
        return policy
    for earlier in case.judge_view.steps[: selected_step - 1]:
        earlier_text = _step_observation(earlier).casefold()
        if tool in earlier_text and any(item in earlier_text for item in _HARD_SERVICE_MARKERS):
            policy["decision_reason"] = "known_service_failure_recommitted"
            return policy
    if selected_step > 1:
        for module in (AgentModule.MEMORY, AgentModule.REFLECTION):
            representative = next(iter(TAXONOMY[module]))
            if serial_owner_sources(case.judge_view, selected_step, module, representative):
                policy["decision_reason"] = "earlier_agent_state_owner_remains_possible"
                return policy
    action_start = min(
        (
            span.tag_start_char
            for span in step.module_spans
            if span.module == AgentModule.ACTION.value
        ),
        default=len(step.assistant_raw_output),
    )
    if re.search(
        r"(?:task(?:\s+goal)?|goal)\s+(?:is\s+)?(?:already\s+)?complete"
        r"|(?:i|we)\s+have\s+completed\s+the\s+task",
        step.assistant_raw_output[:action_start].casefold(),
    ):
        policy["decision_reason"] = "pre_action_progress_claim_may_own_failure"
        return policy
    policy.update(
        {
            "applied": True,
            "decision_reason": "first_independent_well_formed_provider_exception",
            "error_type": ErrorType.TOOL_EXECUTION_ERROR.value,
            "evidence": evidence,
        }
    )
    return policy


def _canonical_action(case: Any, step_number: int) -> dict[str, Any] | None:
    calls = _action_calls(case.judge_view.steps[step_number - 1])
    complete = [
        item
        for item in calls
        if item["partial_arguments"] in (None, {})
        and isinstance(item["parameters"], Mapping)
    ]
    if len(complete) != 1:
        return None
    identity = {"tool": complete[0]["tool"], "parameters": dict(complete[0]["parameters"])}
    return {**identity, "action_signature_sha256": stable_sha256(identity)}


def _earliest_exact_recurrence(case: Any) -> dict[str, Any] | None:
    seen: dict[tuple[str, str], list[int]] = {}
    for step_number, step in enumerate(case.judge_view.steps, 1):
        action = _canonical_action(case, step_number)
        observation = _step_observation(step)
        if action is None or not observation.strip():
            continue
        key = (str(action["action_signature_sha256"]), _raw_sha256(observation))
        priors = seen.setdefault(key, [])
        if len(priors) == 2:
            return {
                "step": step_number,
                "prior_steps": list(priors),
                "action_signature_sha256": key[0],
                "observation_sha256": key[1],
            }
        priors.append(step_number)
    return None


def build_atom_v11_catalog(case: Any) -> dict[str, Any]:
    """Build deterministic private owner atoms and owner-neutral boundary cards."""

    owner_rows: list[dict[str, Any]] = []
    for step_number in range(1, len(case.judge_view.steps) + 1):
        for module in (
            AgentModule.MEMORY,
            AgentModule.REFLECTION,
            AgentModule.PLANNING,
            AgentModule.ACTION,
        ):
            representative = next(iter(TAXONOMY[module]))
            for source in serial_owner_sources(
                case.judge_view, step_number, module, representative
            ):
                source_sha256 = _raw_sha256(source)
                for source_start, source_end, fragment in _source_fragments(source):
                    quote = fragment
                    if not quote.strip():
                        continue
                    owner_rows.append(
                        {
                            "step": step_number,
                            "module": module.value,
                            "quote": quote,
                            "raw_sha256": _raw_sha256(quote),
                            "source_sha256": source_sha256,
                            "source_start_char": source_start,
                            "source_end_char": source_end,
                            "allowed_error_types": sorted(
                                item.value for item in TAXONOMY[module]
                            ),
                        }
                    )
        policy = _hard_system_policy(case, step_number)
        if policy["applied"]:
            source = str(policy["evidence"])
            source_sha256 = _raw_sha256(source)
            for source_start, source_end, quote in _source_fragments(source):
                if not quote.strip():
                    continue
                owner_rows.append(
                    {
                        "step": step_number,
                        "module": AgentModule.SYSTEM.value,
                        "quote": quote,
                        "raw_sha256": _raw_sha256(quote),
                        "source_sha256": source_sha256,
                        "source_start_char": source_start,
                        "source_end_char": source_end,
                        "allowed_error_types": [ErrorType.TOOL_EXECUTION_ERROR.value],
                    }
                )
    unique_owner: dict[tuple[int, str, str], dict[str, Any]] = {}
    for row in owner_rows:
        key = (int(row["step"]), str(row["module"]), str(row["quote"]))
        merged = unique_owner.setdefault(
            key,
            {
                "step": row["step"],
                "module": row["module"],
                "quote": row["quote"],
                "raw_sha256": row["raw_sha256"],
                "allowed_error_types": list(row["allowed_error_types"]),
                "source_ranges": [],
            },
        )
        merged["source_ranges"].append(
            {
                "source_sha256": row["source_sha256"],
                "start_char": row["source_start_char"],
                "end_char": row["source_end_char"],
            }
        )
    owner_atoms: list[dict[str, Any]] = []
    for index, key in enumerate(sorted(unique_owner), 1):
        row = unique_owner[key]
        row["source_ranges"] = [
            {"source_sha256": item[0], "start_char": item[1], "end_char": item[2]}
            for item in sorted(
                {
                    (
                        item["source_sha256"],
                        item["start_char"],
                        item["end_char"],
                    )
                    for item in row["source_ranges"]
                }
            )
        ]
        owner_atoms.append(
            {"owner_atom_id": f"OA-{index:04d}", **row}
        )

    grouped: dict[tuple[int, str], dict[str, Any]] = {}
    for owner in owner_atoms:
        key = (int(owner["step"]), str(owner["quote"]))
        row = grouped.setdefault(
            key,
            {
                "step": key[0],
                "quote": key[1],
                "raw_sha256": owner["raw_sha256"],
                "source_kind": "agent_output",
                "compatible_owner_atom_ids": [],
                "source_ranges": [],
                "selectable": True,
            },
        )
        row["compatible_owner_atom_ids"].append(owner["owner_atom_id"])
        row["source_ranges"].extend(owner["source_ranges"])
    for step_number, step in enumerate(case.judge_view.steps, 1):
        observation = _step_observation(step)
        source_sha256 = _raw_sha256(observation)
        for source_start, source_end, fragment in _source_fragments(observation):
            if not fragment.strip():
                continue
            key = (step_number, fragment)
            row = grouped.setdefault(
                key,
                {
                    "step": step_number,
                    "quote": fragment,
                    "raw_sha256": _raw_sha256(fragment),
                    "source_kind": "adjacent_feedback",
                    "compatible_owner_atom_ids": [],
                    "source_ranges": [],
                    "selectable": False,
                },
            )
            row["source_ranges"].append(
                {
                    "source_sha256": source_sha256,
                    "start_char": source_start,
                    "end_char": source_end,
                }
            )
            system_ids = [
                owner["owner_atom_id"]
                for owner in owner_atoms
                if owner["step"] == step_number
                and owner["module"] == AgentModule.SYSTEM.value
                and owner["quote"] == fragment
            ]
            if system_ids:
                row["compatible_owner_atom_ids"].extend(system_ids)
                row["selectable"] = True
                row["source_kind"] = "guarded_external_outcome"
    local_atoms: list[dict[str, Any]] = []
    for index, key in enumerate(sorted(grouped), 1):
        row = grouped[key]
        row["compatible_owner_atom_ids"] = sorted(
            set(row["compatible_owner_atom_ids"])
        )
        row["source_ranges"] = sorted(
            {
                (item["source_sha256"], item["start_char"], item["end_char"])
                for item in row["source_ranges"]
            }
        )
        row["source_ranges"] = [
            {"source_sha256": item[0], "start_char": item[1], "end_char": item[2]}
            for item in row["source_ranges"]
        ]
        local_atoms.append({"local_atom_id": f"LA-{index:04d}", **row})

    local_by_owner: dict[str, str] = {}
    for atom in local_atoms:
        for owner_id in atom["compatible_owner_atom_ids"]:
            local_by_owner[owner_id] = atom["local_atom_id"]
    owners_by_step_module: dict[tuple[int, str], list[dict[str, Any]]] = {}
    for owner in owner_atoms:
        owners_by_step_module.setdefault(
            (int(owner["step"]), str(owner["module"])), []
        ).append(owner)
    observations_by_step: dict[int, list[dict[str, Any]]] = {}
    for atom in local_atoms:
        if atom["source_kind"] in {"adjacent_feedback", "guarded_external_outcome"}:
            observations_by_step.setdefault(int(atom["step"]), []).append(atom)

    relations: list[dict[str, Any]] = []

    def local_ids(step: int, modules: Sequence[AgentModule]) -> list[str]:
        values: list[str] = []
        for module in modules:
            rows = owners_by_step_module.get((step, module.value), [])
            values.extend(local_by_owner[str(row["owner_atom_id"])] for row in rows)
        return sorted(set(values))

    for step_number in range(1, len(case.judge_view.steps) + 1):
        planning = local_ids(step_number, (AgentModule.PLANNING,))
        action = local_ids(step_number, (AgentModule.ACTION,))
        members = sorted(set(planning + action))
        if planning and action and len(members) >= 2:
            relations.append(
                {
                    "relation_kind": "same_step_commitment_execution",
                    "member_local_atom_ids": members,
                    "reference_local_atom_ids": [],
                    "selected_steps": [step_number],
                }
            )
        if step_number > 1:
            current = local_ids(
                step_number, (AgentModule.MEMORY, AgentModule.REFLECTION)
            )
            prior = local_ids(
                step_number - 1, (AgentModule.ACTION, AgentModule.PLANNING)
            )
            observations = observations_by_step.get(step_number - 1, [])
            if current and prior and observations:
                relations.append(
                    {
                        "relation_kind": "prior_result_current_interpretation",
                        "member_local_atom_ids": sorted(set(prior + current)),
                        "reference_local_atom_ids": [
                            item["local_atom_id"] for item in observations
                        ],
                        "selected_steps": [step_number - 1, step_number],
                    }
                )
        system_rows = owners_by_step_module.get((step_number, AgentModule.SYSTEM.value), [])
        if system_rows:
            local_ids_for_system = sorted(
                {
                    local_by_owner[str(item["owner_atom_id"])] for item in system_rows
                }
            )
            relations.append(
                {
                    "relation_kind": "guarded_external_outcome",
                    "member_local_atom_ids": local_ids_for_system,
                    "reference_local_atom_ids": [],
                    "selected_steps": [step_number],
                }
            )

    final_step = len(case.judge_view.steps)
    terminal = local_ids(
        final_step,
        (
            AgentModule.ACTION,
            AgentModule.REFLECTION,
            AgentModule.PLANNING,
            AgentModule.MEMORY,
        ),
    )
    if terminal:
        relations.append(
            {
                "relation_kind": "terminal_output",
                "member_local_atom_ids": terminal,
                "reference_local_atom_ids": [],
                "selected_steps": [final_step],
            }
        )
    recurrence = _earliest_exact_recurrence(case)
    if recurrence is not None:
        step_number = int(recurrence["step"])
        current = local_ids(
            step_number, (AgentModule.ACTION, AgentModule.PLANNING)
        )
        references = [
            item["local_atom_id"]
            for prior in recurrence["prior_steps"]
            if prior in observations_by_step
            for item in observations_by_step[prior]
        ]
        if current and all(prior in observations_by_step for prior in recurrence["prior_steps"]):
            relations.append(
                {
                    "relation_kind": "deterministic_recurrence_episode",
                    "member_local_atom_ids": current,
                    "reference_local_atom_ids": references,
                    "selected_steps": [step_number],
                    "recurrence_prior_steps": list(recurrence["prior_steps"]),
                    "action_signature_sha256": recurrence["action_signature_sha256"],
                    "observation_sha256": recurrence["observation_sha256"],
                }
            )

    deduplicated: dict[tuple[Any, ...], dict[str, Any]] = {}
    for relation in relations:
        key = (
            relation["relation_kind"],
            tuple(relation["member_local_atom_ids"]),
            tuple(relation["reference_local_atom_ids"]),
        )
        deduplicated[key] = relation
    boundary_relations = [
        {"relation_id": f"BR-{index:04d}", **deduplicated[key]}
        for index, key in enumerate(sorted(deduplicated), 1)
    ]
    if not boundary_relations:
        _fail("empty_boundary_catalog", "case has no bounded local boundary relation")
    guarded_relations = [
        item
        for item in boundary_relations
        if item["relation_kind"] == "guarded_external_outcome"
    ]
    unique_guarded = len(guarded_relations) == 1
    if unique_guarded:
        boundary_relations = [
            {**guarded_relations[0], "relation_id": "BR-0001"}
        ]
    hard_system_root_policy: dict[str, Any] = {
        "policy_version": "unique-causally-guarded-hard-system-root-v1",
        "applied": unique_guarded,
        "deterministic_boundary_bypass": unique_guarded,
        "selected_relation_id": (
            "BR-0001" if unique_guarded else None
        ),
        "decision_reason": (
            "unique_first_independent_well_formed_provider_exception"
            if unique_guarded
            else "no_unique_guarded_system_root"
        ),
    }
    # The inherited guard already requires a first, schema-valid, independent
    # provider exception with no mature same-step Memory/Reflection owner.  A
    # unique hit is a hard root-owner rule, not one candidate among agent roots.
    catalog: dict[str, Any] = {
        "schema_version": CATALOG_SCHEMA_VERSION,
        "trajectory_sha256": case.trajectory_sha256,
        "owner_atoms": owner_atoms,
        "local_atoms": local_atoms,
        "boundary_relations": boundary_relations,
        "hard_system_root_policy": hard_system_root_policy,
    }
    catalog["catalog_sha256"] = stable_sha256(catalog)
    return catalog


def _by_id(catalog: Mapping[str, Any], field: str, id_field: str) -> dict[str, Mapping[str, Any]]:
    return {str(item[id_field]): item for item in catalog[field]}


def _public_boundary_catalog(case: Any, catalog: Mapping[str, Any]) -> dict[str, Any]:
    atoms = _by_id(catalog, "local_atoms", "local_atom_id")
    used = sorted(
        {
            atom_id
            for relation in catalog["boundary_relations"]
            for atom_id in (
                list(relation["member_local_atom_ids"])
                + list(relation["reference_local_atom_ids"])
            )
        }
    )
    return {
        "local_atoms": [
            {
                "local_atom_id": atom_id,
                "sequence_position": int(atoms[atom_id]["step"]),
                "evidence_preview": _redact(
                    case, str(atoms[atom_id]["quote"]), limit=_FRAGMENT_MAX_CHARS + 256
                ),
            }
            for atom_id in used
        ],
        "relations": [
            {
                "relation_id": item["relation_id"],
                "relation_kind": item["relation_kind"],
                "member_local_atom_ids": list(item["member_local_atom_ids"]),
                "reference_local_atom_ids": list(item["reference_local_atom_ids"]),
            }
            for item in catalog["boundary_relations"]
        ],
    }


def boundary_output_schema() -> dict[str, Any]:
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_BOUNDARY_FIELDS),
        "properties": {
            "selected_relation_id": {"type": "string", "pattern": r"^BR-[0-9]{4}$"},
            "selected_local_atom_id": {"type": "string", "pattern": r"^LA-[0-9]{4}$"},
            **{
                field: {"type": "string", "minLength": 1}
                for field in sorted(_BOUNDARY_FIELDS)
                if field not in {"selected_relation_id", "selected_local_atom_id"}
            },
        },
    }


def module_output_schema() -> dict[str, Any]:
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_MODULE_FIELDS),
        "properties": {
            "selected_owner_atom_id": {"type": "string", "pattern": r"^OA-[0-9]{4}$"},
            "ownership_reason": {"type": "string", "minLength": 1},
            "rejected_owner_option": {"type": "string", "minLength": 1},
        },
    }


def type_output_schema() -> dict[str, Any]:
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_TYPE_FIELDS),
        "properties": {
            "selected_type_id": {"type": "string", "pattern": r"^T-[0-9]{2}$"},
            "type_reason": {"type": "string", "minLength": 1},
            "rejected_type_option": {"type": "string", "minLength": 1},
        },
    }


def build_boundary_task(case: Any, catalog: Mapping[str, Any]) -> dict[str, str]:
    _check_case_catalog(case, catalog)
    task = case.judge_view.task
    task_text = (task.user_request or task.display_text) if task is not None else ""
    public = _public_boundary_catalog(case, catalog)
    return {
        "system_prompt": BOUNDARY_SYSTEM_PROMPT,
        "user_prompt": (
            f"TASK\n{_redact(case, task_text, limit=max(4000, len(task_text) + 1))}\n\n"
            "OWNER-NEUTRAL LOCAL EVIDENCE AND BOUNDED RELATIONS\n"
            f"{json.dumps(public, ensure_ascii=False, indent=2)}\n\n"
            "Select one relation and one of its member_local_atom_ids. Relations are "
            "bounded causal geometries, not votes, ranks, or order preferences. Select "
            "the boundary that first emits a material defect, not the visually clearest "
            "final answer or completion symptom. A later symptom or unsupported terminal "
            "output wins only when no earlier locally sufficient root explains it. For a "
            "prior-result/current-interpretation relation, distinguish the prior action "
            "that produced the result from the current interpretation that misread it. "
            "For a same-step commitment/execution relation, select the member that "
            "actually emits the defect: an intended commitment or the concrete execution. "
            "Write one behavioral defect predicate that is false under the smallest "
            "correction. Do not output a step, module, "
            "error type, locus, scope, or evidence quote. Return exactly the boundary JSON "
            f"schema: {json.dumps(boundary_output_schema(), ensure_ascii=False)}"
        ),
    }


def extract_boundary_semantic_identity(
    raw: Any, catalog: Mapping[str, Any] | None = None
) -> dict[str, str] | None:
    if not isinstance(raw, Mapping):
        return None
    relation = raw.get("selected_relation_id")
    atom = raw.get("selected_local_atom_id")
    if not isinstance(relation, str) or _ID_PATTERNS["relation"].fullmatch(relation) is None:
        return None
    if not isinstance(atom, str) or _ID_PATTERNS["local"].fullmatch(atom) is None:
        return None
    identity = {"selected_relation_id": relation, "selected_local_atom_id": atom}
    if catalog is not None:
        try:
            _check_catalog(catalog)
        except AgentJudgeValidationError:
            return None
        relations = _by_id(catalog, "boundary_relations", "relation_id")
        selected = relations.get(relation)
        if selected is None or atom not in selected["member_local_atom_ids"]:
            return None
    return identity


def validate_boundary_decision(
    case: Any,
    catalog: Mapping[str, Any],
    raw: Any,
    *,
    expected_semantic_identity: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    _check_case_catalog(case, catalog)
    value = _exact_fields(raw, _BOUNDARY_FIELDS, "boundary decision")
    identity = extract_boundary_semantic_identity(value, catalog)
    if identity is None:
        _fail("invalid_boundary_identity", "boundary IDs are not canonical")
    if expected_semantic_identity is not None and dict(expected_semantic_identity) != identity:
        _fail("boundary_semantic_resample", "repair changed a lockable boundary identity")
    relations = _by_id(catalog, "boundary_relations", "relation_id")
    atoms = _by_id(catalog, "local_atoms", "local_atom_id")
    relation = relations.get(identity["selected_relation_id"])
    atom = atoms.get(identity["selected_local_atom_id"])
    if relation is None or atom is None:
        _fail("unknown_boundary_id", "boundary selected an unknown relation or atom")
    if atom["local_atom_id"] not in relation["member_local_atom_ids"] or not atom["selectable"]:
        _fail("boundary_atom_not_member", "selected atom is not a selectable relation member")
    predicate = _required_text(value["defect_predicate"], "defect_predicate")
    correction = _required_text(value["counterfactual_correction"], "counterfactual_correction")
    owner_ids = sorted(
        {
            owner_id
            for atom_id in relation["member_local_atom_ids"]
            for owner_id in atoms[atom_id]["compatible_owner_atom_ids"]
            if next(
                owner
                for owner in catalog["owner_atoms"]
                if owner["owner_atom_id"] == owner_id
            )["step"]
            == atom["step"]
        }
    )
    if not owner_ids:
        _fail("boundary_has_no_owner", "selected boundary has no legal same-step owner")
    freeze = {
        "selected_relation_id": relation["relation_id"],
        "selected_local_atom_id": atom["local_atom_id"],
        "selected_step": int(atom["step"]),
        "derived_locus": relation["relation_kind"],
        "derived_evidence_scope": list(relation["member_local_atom_ids"])
        + list(relation["reference_local_atom_ids"]),
        "derived_evidence_quote": atom["quote"],
        "defect_predicate": predicate,
        "counterfactual_correction": correction,
    }
    return {
        "schema_version": AUDIT_SCHEMA_VERSION,
        "stage": "boundary",
        "protocol": VERSION,
        "catalog_sha256": catalog["catalog_sha256"],
        **freeze,
        "selection_reason": _required_text(value["selection_reason"], "selection_reason"),
        "rejected_adjacent_boundary": _required_text(
            value["rejected_adjacent_boundary"], "rejected_adjacent_boundary"
        ),
        "compatible_owner_atom_ids": owner_ids,
        "defect_freeze_sha256": stable_sha256(freeze),
        "semantic_identity": identity,
        "model_reported_step_or_quote": False,
        "owner_neutral_boundary_catalog": True,
    }


def _check_boundary_audit(catalog: Mapping[str, Any], audit: Mapping[str, Any]) -> None:
    if (
        not isinstance(audit, Mapping)
        or set(audit) != _BOUNDARY_AUDIT_FIELDS
        or audit.get("schema_version") != AUDIT_SCHEMA_VERSION
        or audit.get("stage") != "boundary"
        or audit.get("protocol") != VERSION
        or audit.get("catalog_sha256") != catalog["catalog_sha256"]
        or audit.get("model_reported_step_or_quote") is not False
        or audit.get("owner_neutral_boundary_catalog") is not True
    ):
        _fail("invalid_boundary_audit", "boundary audit lineage is invalid")
    freeze = {
        field: audit[field]
        for field in (
            "selected_relation_id",
            "selected_local_atom_id",
            "selected_step",
            "derived_locus",
            "derived_evidence_scope",
            "derived_evidence_quote",
            "defect_predicate",
            "counterfactual_correction",
        )
    }
    if audit.get("defect_freeze_sha256") != stable_sha256(freeze):
        _fail("invalid_defect_freeze", "boundary freeze hash is invalid")
    relations = _by_id(catalog, "boundary_relations", "relation_id")
    atoms = _by_id(catalog, "local_atoms", "local_atom_id")
    relation = relations.get(str(audit.get("selected_relation_id")))
    atom = atoms.get(str(audit.get("selected_local_atom_id")))
    if (
        relation is None
        or atom is None
        or atom["local_atom_id"] not in relation["member_local_atom_ids"]
        or not atom["selectable"]
    ):
        _fail("invalid_boundary_audit", "boundary IDs no longer resolve")
    owners = _by_id(catalog, "owner_atoms", "owner_atom_id")
    expected_owner_ids = sorted(
        {
            owner_id
            for member_id in relation["member_local_atom_ids"]
            for owner_id in atoms[member_id]["compatible_owner_atom_ids"]
            if owners[owner_id]["step"] == atom["step"]
        }
    )
    expected_projection = {
        "selected_step": int(atom["step"]),
        "derived_locus": relation["relation_kind"],
        "derived_evidence_scope": list(relation["member_local_atom_ids"])
        + list(relation["reference_local_atom_ids"]),
        "derived_evidence_quote": atom["quote"],
        "compatible_owner_atom_ids": expected_owner_ids,
        "semantic_identity": {
            "selected_relation_id": relation["relation_id"],
            "selected_local_atom_id": atom["local_atom_id"],
        },
    }
    if any(audit.get(key) != value for key, value in expected_projection.items()):
        _fail("invalid_boundary_audit", "boundary audit projection was tampered")
    _required_text(audit.get("selection_reason"), "boundary audit selection_reason")
    _required_text(
        audit.get("rejected_adjacent_boundary"),
        "boundary audit rejected_adjacent_boundary",
    )


def _owner_options(catalog: Mapping[str, Any], boundary_audit: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    owners = _by_id(catalog, "owner_atoms", "owner_atom_id")
    options = [owners[item] for item in boundary_audit["compatible_owner_atom_ids"]]
    systems = [item for item in options if item["module"] == AgentModule.SYSTEM.value]
    return systems if systems else options


def build_module_task(
    case: Any, catalog: Mapping[str, Any], boundary_audit: Mapping[str, Any]
) -> dict[str, str]:
    _check_case_catalog(case, catalog)
    _check_boundary_audit(catalog, boundary_audit)
    options = _owner_options(catalog, boundary_audit)
    public = [
        {
            "owner_atom_id": item["owner_atom_id"],
            "module": item["module"],
            "evidence_preview": _redact(
                case, item["quote"], limit=_FRAGMENT_MAX_CHARS + 256
            ),
        }
        for item in options
    ]
    frozen = {
        "defect_predicate": boundary_audit["defect_predicate"],
        "counterfactual_correction": boundary_audit["counterfactual_correction"],
    }
    return {
        "system_prompt": MODULE_SYSTEM_PROMPT,
        "user_prompt": (
            f"FROZEN DEFECT\n{json.dumps(frozen, ensure_ascii=False, indent=2)}\n\n"
            f"LEGAL SAME-STEP OWNER ATOMS\n{json.dumps(public, ensure_ascii=False, indent=2)}\n\n"
            "Owner loci: memory is the current step's recall or compression of existing "
            "state; reflection is the current step's interpretation of a preceding result; "
            "planning is a strategy commitment before a call or answer; action is the "
            "actual emitted tool, parameterization, final answer, or concrete act. Select "
            "the atom that first realizes the frozen predicate; a later restatement or "
            "consequence does not take ownership. Select exactly one owner_atom_id. "
            "Do not output or rewrite step, predicate, "
            "relation, evidence quote, or error type. Return exactly: "
            f"{json.dumps(module_output_schema(), ensure_ascii=False)}"
        ),
    }


def extract_module_semantic_identity(
    raw: Any,
    catalog: Mapping[str, Any] | None = None,
    boundary_audit: Mapping[str, Any] | None = None,
) -> dict[str, str] | None:
    if not isinstance(raw, Mapping):
        return None
    owner = raw.get("selected_owner_atom_id")
    if not isinstance(owner, str) or _ID_PATTERNS["owner"].fullmatch(owner) is None:
        return None
    identity = {"selected_owner_atom_id": owner}
    if catalog is not None and boundary_audit is not None:
        try:
            _check_catalog(catalog)
            _check_boundary_audit(catalog, boundary_audit)
            legal = {item["owner_atom_id"] for item in _owner_options(catalog, boundary_audit)}
        except (AgentJudgeValidationError, KeyError):
            return None
        if owner not in legal:
            return None
    return identity


def validate_module_decision(
    case: Any,
    catalog: Mapping[str, Any],
    boundary_audit: Mapping[str, Any],
    raw: Any,
    *,
    expected_semantic_identity: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    _check_case_catalog(case, catalog)
    _check_boundary_audit(catalog, boundary_audit)
    value = _exact_fields(raw, _MODULE_FIELDS, "module decision")
    identity = extract_module_semantic_identity(value, catalog, boundary_audit)
    if identity is None:
        _fail("invalid_module_identity", "owner atom ID is not canonical")
    if expected_semantic_identity is not None and dict(expected_semantic_identity) != identity:
        _fail("module_semantic_resample", "repair changed a lockable owner identity")
    options = {item["owner_atom_id"]: item for item in _owner_options(catalog, boundary_audit)}
    owner = options.get(identity["selected_owner_atom_id"])
    if owner is None:
        _fail("invalid_owner_atom", "module selected a non-option owner atom")
    return {
        "schema_version": AUDIT_SCHEMA_VERSION,
        "stage": "module",
        "protocol": VERSION,
        "catalog_sha256": catalog["catalog_sha256"],
        "defect_freeze_sha256": boundary_audit["defect_freeze_sha256"],
        "selected_owner_atom_id": owner["owner_atom_id"],
        "selected_step": int(owner["step"]),
        "selected_module": owner["module"],
        "derived_owner_evidence_quote": owner["quote"],
        "allowed_error_types": list(owner["allowed_error_types"]),
        "ownership_reason": _required_text(value["ownership_reason"], "ownership_reason"),
        "rejected_owner_option": _required_text(
            value["rejected_owner_option"], "rejected_owner_option"
        ),
        "semantic_identity": identity,
        "step_matches_frozen_boundary": int(owner["step"])
        == int(boundary_audit["selected_step"]),
        "model_rewrote_frozen_predicate": False,
    }


def _check_module_audit(
    catalog: Mapping[str, Any],
    boundary_audit: Mapping[str, Any],
    module_audit: Mapping[str, Any],
) -> None:
    if (
        not isinstance(module_audit, Mapping)
        or set(module_audit) != _MODULE_AUDIT_FIELDS
        or module_audit.get("schema_version") != AUDIT_SCHEMA_VERSION
        or module_audit.get("stage") != "module"
        or module_audit.get("protocol") != VERSION
        or module_audit.get("catalog_sha256") != catalog["catalog_sha256"]
        or module_audit.get("defect_freeze_sha256")
        != boundary_audit["defect_freeze_sha256"]
        or module_audit.get("step_matches_frozen_boundary") is not True
        or module_audit.get("model_rewrote_frozen_predicate") is not False
    ):
        _fail("invalid_module_audit", "module audit lineage/binding is invalid")
    owner = _by_id(catalog, "owner_atoms", "owner_atom_id").get(
        str(module_audit.get("selected_owner_atom_id"))
    )
    if owner is None or owner not in _owner_options(catalog, boundary_audit):
        _fail("invalid_module_audit", "module audit owner is no longer a legal option")
    expected = {
        "selected_step": int(owner["step"]),
        "selected_module": owner["module"],
        "derived_owner_evidence_quote": owner["quote"],
        "allowed_error_types": list(owner["allowed_error_types"]),
        "semantic_identity": {
            "selected_owner_atom_id": owner["owner_atom_id"]
        },
    }
    if any(module_audit.get(key) != value for key, value in expected.items()):
        _fail("invalid_module_audit", "module audit projection was tampered")
    _required_text(module_audit.get("ownership_reason"), "module audit ownership_reason")
    _required_text(
        module_audit.get("rejected_owner_option"),
        "module audit rejected_owner_option",
    )


def _type_options(module_audit: Mapping[str, Any]) -> list[dict[str, str]]:
    module = AgentModule(str(module_audit["selected_module"]))
    allowed = set(module_audit["allowed_error_types"])
    return [
        {
            "type_id": f"T-{index:02d}",
            "error_type": error_type.value,
            "definition": definition,
        }
        for index, (error_type, definition) in enumerate(TAXONOMY[module].items(), 1)
        if error_type.value in allowed
    ]


def build_type_task(
    case: Any,
    catalog: Mapping[str, Any],
    boundary_audit: Mapping[str, Any],
    module_audit: Mapping[str, Any],
) -> dict[str, str]:
    _check_case_catalog(case, catalog)
    _check_boundary_audit(catalog, boundary_audit)
    _check_module_audit(catalog, boundary_audit, module_audit)
    frozen = {
        "defect_predicate": boundary_audit["defect_predicate"],
        "counterfactual_correction": boundary_audit["counterfactual_correction"],
        "module": module_audit["selected_module"],
        "owner_evidence_preview": _redact(
            case,
            module_audit["derived_owner_evidence_quote"],
            limit=_FRAGMENT_MAX_CHARS + 256,
        ),
    }
    return {
        "system_prompt": TYPE_SYSTEM_PROMPT,
        "user_prompt": (
            f"FROZEN DEFECT AND OWNER\n{json.dumps(frozen, ensure_ascii=False, indent=2)}\n\n"
            f"LEGAL TYPES\n{json.dumps(_type_options(module_audit), ensure_ascii=False, indent=2)}\n\n"
            "Select exactly one type ID. Do not output or rewrite the step, module, "
            "predicate, relation, or evidence quote. Return exactly: "
            f"{json.dumps(type_output_schema(), ensure_ascii=False)}"
        ),
    }


def extract_type_semantic_identity(
    raw: Any, module_audit: Mapping[str, Any] | None = None
) -> dict[str, str] | None:
    if not isinstance(raw, Mapping):
        return None
    type_id = raw.get("selected_type_id")
    if not isinstance(type_id, str) or _ID_PATTERNS["type"].fullmatch(type_id) is None:
        return None
    identity = {"selected_type_id": type_id}
    if module_audit is not None:
        try:
            legal = {item["type_id"] for item in _type_options(module_audit)}
        except (KeyError, ValueError):
            return None
        if type_id not in legal:
            return None
    return identity


def validate_type_decision(
    case: Any,
    catalog: Mapping[str, Any],
    boundary_audit: Mapping[str, Any],
    module_audit: Mapping[str, Any],
    raw: Any,
    *,
    expected_semantic_identity: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    _check_case_catalog(case, catalog)
    _check_boundary_audit(catalog, boundary_audit)
    _check_module_audit(catalog, boundary_audit, module_audit)
    value = _exact_fields(raw, _TYPE_FIELDS, "type decision")
    identity = extract_type_semantic_identity(value, module_audit)
    if identity is None:
        _fail("invalid_type_identity", "type ID is not canonical")
    if expected_semantic_identity is not None and dict(expected_semantic_identity) != identity:
        _fail("type_semantic_resample", "repair changed a lockable type identity")
    options = {item["type_id"]: item for item in _type_options(module_audit)}
    selected = options.get(identity["selected_type_id"])
    if selected is None:
        _fail("invalid_type_option", "type stage selected a non-option ID")
    freeze = {
        "defect_freeze_sha256": boundary_audit["defect_freeze_sha256"],
        "selected_owner_atom_id": module_audit["selected_owner_atom_id"],
        "selected_type_id": selected["type_id"],
        "selected_error_type": selected["error_type"],
    }
    return {
        "schema_version": AUDIT_SCHEMA_VERSION,
        "stage": "type",
        "protocol": VERSION,
        "catalog_sha256": catalog["catalog_sha256"],
        **freeze,
        "type_reason": _required_text(value["type_reason"], "type_reason"),
        "rejected_type_option": _required_text(
            value["rejected_type_option"], "rejected_type_option"
        ),
        "type_freeze_sha256": stable_sha256(freeze),
        "semantic_identity": identity,
        "model_rewrote_frozen_predicate_or_owner": False,
    }


def derive_prediction(
    case: Any,
    catalog: Mapping[str, Any],
    boundary_audit: Mapping[str, Any],
    module_audit: Mapping[str, Any],
    type_audit: Mapping[str, Any],
) -> dict[str, Any]:
    _check_case_catalog(case, catalog)
    _check_boundary_audit(catalog, boundary_audit)
    _check_module_audit(catalog, boundary_audit, module_audit)
    if (
        not isinstance(type_audit, Mapping)
        or set(type_audit) != _TYPE_AUDIT_FIELDS
        or type_audit.get("schema_version") != AUDIT_SCHEMA_VERSION
        or type_audit.get("stage") != "type"
        or type_audit.get("protocol") != VERSION
        or type_audit.get("catalog_sha256") != catalog["catalog_sha256"]
        or type_audit.get("defect_freeze_sha256")
        != boundary_audit["defect_freeze_sha256"]
        or type_audit.get("selected_owner_atom_id")
        != module_audit["selected_owner_atom_id"]
        or type_audit.get("model_rewrote_frozen_predicate_or_owner") is not False
    ):
        _fail("invalid_type_audit", "type audit lineage is invalid")
    expected_freeze = {
        "defect_freeze_sha256": boundary_audit["defect_freeze_sha256"],
        "selected_owner_atom_id": module_audit["selected_owner_atom_id"],
        "selected_type_id": type_audit["selected_type_id"],
        "selected_error_type": type_audit["selected_error_type"],
    }
    if type_audit.get("type_freeze_sha256") != stable_sha256(expected_freeze):
        _fail("invalid_type_audit", "type freeze hash is invalid")
    if type_audit["selected_error_type"] not in module_audit["allowed_error_types"]:
        _fail("invalid_type_audit", "type is not allowed for frozen owner")
    options = {
        item["type_id"]: item["error_type"] for item in _type_options(module_audit)
    }
    if options.get(str(type_audit["selected_type_id"])) != type_audit["selected_error_type"]:
        _fail("invalid_type_audit", "type ID/error type projection was tampered")
    if type_audit.get("semantic_identity") != {
        "selected_type_id": type_audit["selected_type_id"]
    }:
        _fail("invalid_type_audit", "type semantic identity was tampered")
    _required_text(type_audit.get("type_reason"), "type audit type_reason")
    _required_text(
        type_audit.get("rejected_type_option"), "type audit rejected_type_option"
    )
    return {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        "predicted_step": int(boundary_audit["selected_step"]),
        "predicted_module": module_audit["selected_module"],
        "predicted_error_type": type_audit["selected_error_type"],
        "evidence_quote": module_audit["derived_owner_evidence_quote"],
        "root_cause": boundary_audit["defect_predicate"],
        "causal_summary": boundary_audit["counterfactual_correction"],
        "rejected_adjacent_owner": module_audit["rejected_owner_option"],
    }


def runtime_conformance_boundary_decision(catalog: Mapping[str, Any]) -> dict[str, str]:
    relation = catalog["boundary_relations"][0]
    return {
        "selected_relation_id": relation["relation_id"],
        "selected_local_atom_id": relation["member_local_atom_ids"][0],
        "defect_predicate": "This local decision violates a necessary task condition.",
        "counterfactual_correction": "Preserve that condition before continuing.",
        "selection_reason": "The supplied relation contains the earliest local defect.",
        "rejected_adjacent_boundary": "The adjacent boundary is a consequence.",
    }


def deterministic_boundary_decision(
    catalog: Mapping[str, Any],
) -> dict[str, str] | None:
    """Return a local freeze only for the unique hard-System root policy."""

    _check_catalog(catalog)
    policy = catalog["hard_system_root_policy"]
    if policy.get("applied") is not True or len(catalog["boundary_relations"]) != 1:
        return None
    raw = runtime_conformance_boundary_decision(catalog)
    raw.update(
        {
            "defect_predicate": (
                "A schema-valid external operation independently failed at the "
                "first guarded provider boundary."
            ),
            "counterfactual_correction": (
                "Restore the provider operation without changing the valid call."
            ),
            "selection_reason": (
                "The deterministic hard-System guard admits exactly one root relation."
            ),
            "rejected_adjacent_boundary": (
                "Agent-side alternatives are excluded by the guarded root policy."
            ),
        }
    )
    return raw


def runtime_conformance_module_decision(
    catalog: Mapping[str, Any], boundary_audit: Mapping[str, Any]
) -> dict[str, str]:
    owner = _owner_options(catalog, boundary_audit)[0]
    return {
        "selected_owner_atom_id": owner["owner_atom_id"],
        "ownership_reason": "This owner atom directly realizes the frozen defect.",
        "rejected_owner_option": "No adjacent owner has stronger direct evidence.",
    }


def deterministic_module_decision(
    catalog: Mapping[str, Any], boundary_audit: Mapping[str, Any]
) -> dict[str, str] | None:
    """Bypass an uninformative model call when exactly one owner is legal."""

    _check_catalog(catalog)
    _check_boundary_audit(catalog, boundary_audit)
    options = _owner_options(catalog, boundary_audit)
    if len(options) != 1:
        return None
    return {
        "selected_owner_atom_id": options[0]["owner_atom_id"],
        "ownership_reason": "The frozen boundary admits exactly one legal owner atom.",
        "rejected_owner_option": "No alternative owner option is legally available.",
    }


def runtime_conformance_type_decision(module_audit: Mapping[str, Any]) -> dict[str, str]:
    selected = _type_options(module_audit)[0]
    return {
        "selected_type_id": selected["type_id"],
        "type_reason": "This definition matches the frozen predicate and owner evidence.",
        "rejected_type_option": "The alternative lacks its distinguishing condition.",
    }


# Uniform runner-facing aliases.  The case and upstream audits remain explicit
# in every signature so a generic three-stage runner cannot silently reorder a
# handoff while constructing its startup conformance probe.
def runtime_boundary_decision(case: Any, catalog: Mapping[str, Any]) -> dict[str, str]:
    _check_case_catalog(case, catalog)
    return runtime_conformance_boundary_decision(catalog)


def runtime_module_decision(
    case: Any, catalog: Mapping[str, Any], boundary_audit: Mapping[str, Any]
) -> dict[str, str]:
    _check_case_catalog(case, catalog)
    return runtime_conformance_module_decision(catalog, boundary_audit)


def runtime_type_decision(
    case: Any,
    catalog: Mapping[str, Any],
    boundary_audit: Mapping[str, Any],
    module_audit: Mapping[str, Any],
) -> dict[str, str]:
    _check_case_catalog(case, catalog)
    _check_boundary_audit(catalog, boundary_audit)
    return runtime_conformance_type_decision(module_audit)


def deterministic_type_decision(
    module_audit: Mapping[str, Any],
) -> dict[str, str] | None:
    """Bypass an uninformative model call when exactly one type is legal."""

    options = _type_options(module_audit)
    if len(options) != 1:
        return None
    return {
        "selected_type_id": options[0]["type_id"],
        "type_reason": "The frozen owner admits exactly one legal taxonomy type.",
        "rejected_type_option": "No alternative type option is legally available.",
    }


def _resolve_prediction_owner_atom(
    catalog: Mapping[str, Any], prediction: Mapping[str, Any]
) -> Mapping[str, Any]:
    """Resolve one final record to exactly one complete v11 owner atom."""

    _check_catalog(catalog)
    matches = [
        owner
        for owner in catalog["owner_atoms"]
        if owner["step"] == prediction.get("predicted_step")
        and owner["module"] == prediction.get("predicted_module")
        and owner["quote"] == prediction.get("evidence_quote")
        and prediction.get("predicted_error_type") in owner["allowed_error_types"]
    ]
    if len(matches) != 1:
        _fail(
            "invalid_final_atom_binding",
            "prediction step/module/type/exact quote must resolve to one owner atom",
        )
    return matches[0]


def _v11_final_owner_sources(
    view: Any,
    predicted_step: int,
    module: AgentModule,
    error_type: ErrorType,
) -> tuple[str, ...]:
    if module == AgentModule.SYSTEM:
        observation = _step_observation(view.steps[predicted_step - 1])
        return (observation,) if observation.strip() else ()
    return serial_owner_sources(view, predicted_step, module, error_type)


def validate_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    """Run the shared gold-free validator plus v11's hard-System source rule."""

    base = _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_v11_final_owner_sources,
    )
    # Force complete cohort identity parsing here as part of the public contract.
    _cohort_document(Path(cohort_manifest_path).expanduser().resolve())
    _, cases = load_prediction_manifest(
        Path(prediction_manifest_path).expanduser().resolve()
    )
    raw = _load_json(
        Path(predictions_path).expanduser().resolve(), role="v11 predictions"
    )
    if not isinstance(raw, list) or len(raw) != len(cases):
        _fail("invalid_prediction_count", "v11 atom audit requires one record per case")
    bindings: list[dict[str, Any]] = []
    for case, prediction in zip(cases, raw, strict=True):
        if not isinstance(prediction, Mapping):
            _fail("invalid_prediction_record", "v11 prediction must be an object")
        catalog = build_atom_v11_catalog(case)
        owner = _resolve_prediction_owner_atom(catalog, prediction)
        bindings.append(
            {
                "trajectory_sha256": case.trajectory_sha256,
                "catalog_sha256": catalog["catalog_sha256"],
                "selected_owner_atom_id": owner["owner_atom_id"],
            }
        )
    return {
        **base,
        "agent_judge_version": VERSION,
        "model": MODEL,
        "resolved_model": RESOLVED_MODEL,
        "reasoning_effort": REASONING_EFFORT,
        "temperature": TEMPERATURE,
        "three_serial_stage_freezes": True,
        "owner_neutral_boundary_atoms": True,
        "boundary_quote_step_scope_parent_derived": True,
        "module_type_bound_to_frozen_defect": True,
        "hard_system_guard": "causally-guarded-hard-system-v1",
        "exact_final_owner_atom_binding": True,
        "case_atom_bindings": bindings,
    }


build_protocol_task = build_boundary_task
build_task = build_boundary_task


__all__ = [
    "AUDIT_SCHEMA_VERSION",
    "BOUNDARY_DECISION_FILENAME",
    "BOUNDARY_SYSTEM_PROMPT",
    "CATALOG_SCHEMA_VERSION",
    "MODEL",
    "MODULE_DECISION_FILENAME",
    "MODULE_SYSTEM_PROMPT",
    "REASONING_EFFORT",
    "RESOLVED_MODEL",
    "TEMPERATURE",
    "TYPE_DECISION_FILENAME",
    "TYPE_SYSTEM_PROMPT",
    "VERSION",
    "boundary_output_schema",
    "build_atom_v11_catalog",
    "build_boundary_task",
    "build_module_task",
    "build_protocol_task",
    "build_task",
    "build_type_task",
    "derive_prediction",
    "deterministic_boundary_decision",
    "deterministic_module_decision",
    "deterministic_type_decision",
    "extract_boundary_semantic_identity",
    "extract_module_semantic_identity",
    "extract_type_semantic_identity",
    "module_output_schema",
    "runtime_conformance_boundary_decision",
    "runtime_conformance_module_decision",
    "runtime_conformance_type_decision",
    "runtime_boundary_decision",
    "runtime_module_decision",
    "runtime_type_decision",
    "type_output_schema",
    "validate_boundary_decision",
    "validate_module_decision",
    "validate_predictions",
    "validate_type_decision",
]

"""Luna GAIA v3.3: v3.1 with an explicit strategy-identity gate."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
)
from .agent_judge_luna_gaia_v3 import STEP_FREEZE_FIELDS, STEP_FREEZE_FILENAME
from .agent_judge_luna_gaia_v3_1 import (
    AGENT_JUDGE_LUNA_GAIA_V3_1_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_LUNA_GAIA_V3_1_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_1_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_1_VERSION,
    build_agent_judge_luna_gaia_v3_1_task,
    validate_agent_judge_luna_gaia_v3_1_predictions,
)


AGENT_JUDGE_LUNA_GAIA_V3_3_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.3"
)
AGENT_JUDGE_LUNA_GAIA_V3_3_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_1_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_3_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_1_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_3_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_1_AUDIT_SCHEMA_VERSION
)


_STRATEGY_IDENTITY_GATE = """\
STRATEGY IDENTITY GATE

Before admitting a Planning repeat, construct the strategy key as:

(unresolved predicate constraints, source/host, endpoint representation,
modality, concrete entity/query target)

Apply these rules exactly:

- A new discriminator resets the epoch only when it actually narrows the
  candidate set based on the last result: closed/open state, a date bound, a
  site/domain restriction, or an exact missing entity/attribute are examples.
  Merely restating an ordering predicate already present in the task (first,
  oldest, release date) or changing capitalization/wording is not new.
- Different endpoint representations are different routes.  A journal PDF
  download endpoint and an HTML view/article endpoint are not the same known-
  failing URL strategy merely because they share a host and extractor.
- The first direct-platform query is exploratory even if its filter syntax may
  be imperfect.  It becomes demonstrated waste only after feedback shows that
  exact target/endpoint uninformative and the agent recommits without a new
  discriminator or route.
- Exact reuse of a URL, operation, source-target pair, or already implicit
  query after direct no-result feedback remains a repeat.
- Rejecting a Planning candidate as a reasonable refinement never exempts
  Memory or Reflection at that same step.  Complete Lane-A fact/progress audit
  before advancing: an exploratory query can coexist with a false same-step
  result interpretation.
- If refinements remain exploratory but the agent then emits a terminal
  unsupported answer or gives up while viable routes remain, the terminal
  Planning/Reflection candidate may own under the existing recovery veto.

This gate changes strategy identity only.  It does not change capability,
System packet ordering, source constraints, or same-step ownership.

"""


def build_agent_judge_luna_gaia_v3_3_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build v3.1 with one normalized strategy-identity clarification."""

    task = build_agent_judge_luna_gaia_v3_1_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    task = task.replace(
        AGENT_JUDGE_LUNA_GAIA_V3_1_VERSION,
        AGENT_JUDGE_LUNA_GAIA_V3_3_VERSION,
    )
    task = task.replace(
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_1.py",
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_3.py",
    )
    task = task.replace(
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_1 import "
        "validate_and_write_agent_judge_luna_gaia_v3_1_audit as run",
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_3 import "
        "validate_and_write_agent_judge_luna_gaia_v3_3_audit as run",
    )
    lane_c = "LANE C — STRATEGY EPOCHS AND TERMINAL ABANDONMENT\n"
    if task.count(lane_c) != 1:
        raise RuntimeError("Luna GAIA v3.1 lane-C boundary changed unexpectedly")
    return task.replace(lane_c, _STRATEGY_IDENTITY_GATE + lane_c, 1)


def validate_agent_judge_luna_gaia_v3_3_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_1_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_3_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_3_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_3_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_3_REASONING_EFFORT,
        "selection_policy": (
            "lane_ordered_chronology_limited_recovery_veto_"
            "external_exception_packet_fence_strategy_identity_gate"
        ),
        "strategy_identity_gate": (
            "predicate_source_endpoint_modality_target"
        ),
    }


def validate_and_write_agent_judge_luna_gaia_v3_3_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_3_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


__all__ = [
    "AGENT_JUDGE_LUNA_GAIA_V3_3_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_GAIA_V3_3_MODEL",
    "AGENT_JUDGE_LUNA_GAIA_V3_3_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_GAIA_V3_3_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "STEP_FREEZE_FIELDS",
    "STEP_FREEZE_FILENAME",
    "build_agent_judge_luna_gaia_v3_3_task",
    "validate_agent_judge_luna_gaia_v3_3_predictions",
    "validate_and_write_agent_judge_luna_gaia_v3_3_audit",
]

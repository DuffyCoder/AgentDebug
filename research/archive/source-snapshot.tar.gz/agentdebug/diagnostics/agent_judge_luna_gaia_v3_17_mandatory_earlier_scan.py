"""Luna GAIA v3.17: mandatory ordered earlier-scan challenger ledger."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as base
from . import agent_judge_luna_gaia_v3_14_earliest_causal_challenger as anchor_parent
from . import agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger as parent
from .agent_judge import _file_sha256, _stable_sha256
from .agent_judge_luna_gaia_v3 import STEP_FREEZE_FILENAME
from .agent_judge_luna_gaia_v3_4 import STEP_CANDIDATE_LEDGER_FILENAME


AGENT_JUDGE_LUNA_GAIA_V3_17_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.17-mandatory-earlier-scan"
)
AGENT_JUDGE_LUNA_GAIA_V3_17_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_16_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_17_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_16_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_17_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_16_AUDIT_SCHEMA_VERSION
)

AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_17_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_17_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_17_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_17_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = base.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = base.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = base.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = base.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = base.CHALLENGERS_FILENAME
ARBITER_FILENAME = base.ARBITER_FILENAME
ARBITERS_FILENAME = base.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = base.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = base.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = base.PREDICTION_AUDIT_FILENAME
ARBITER_FIELDS = base.ARBITER_FIELDS

CHALLENGER_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "anchor_prediction_sha256",
    "anchor_ledger_sha256",
    "anchor_checkpoint_sha256",
    "anchor_step",
    "challenge_status",
    "anchor_classification",
    "anchor_veto_evidence_step",
    "anchor_veto_evidence_quote",
    "proposed_prediction",
    "earlier_scan",
    "anchor_falsifier",
    "anchor_only_repair_counterfactual",
    "proposal_only_repair_counterfactual",
    "direct_timeline_comparison",
    "search_summary",
)
EARLIER_SCAN_ROW_FIELDS = (
    "step",
    "status",
    "boundary_kind",
    "evidence_step",
    "evidence_quote",
    "necessity_basis",
    "literal_boundary_basis",
    "path_effect_basis",
    "decision_basis",
)
EARLIER_SCAN_STATUSES = frozenset({"clear", "proposal"})
EARLIER_BOUNDARY_KINDS = frozenset(
    {"none", "result_to_state", "target_to_action"}
)


_MANDATORY_EARLIER_SCAN_RULES = """\
MANDATORY ORDERED EARLIER-SCAN SINGLE-CHALLENGER RULE

The frozen v3.4 prediction is the incumbent anchor. Do not retain a candidate
pool. Across earlier and later searches, emit at most ONE proposal. The anchor
remains the default under uncertainty.

MANDATORY EARLIER_SCAN ARTIFACT

Before classifying the anchor, scan every Step strictly earlier than it. For
anchor Step A, earlier_scan must contain exactly A-1 rows with Step values
1, 2, ..., A-1 in that order. Do not omit, combine, duplicate, or reorder rows.
If A is 1, earlier_scan must be [].

Each row independently tests exactly two adjacent-packet boundaries:

1. result_to_state: a task-necessary observed entity, value, provenance link,
   success state, or failure state is omitted, contradicted, attached to the
   wrong entity, or consumed as false progress in Memory/Reflection; or
2. target_to_action: the immediate subgoal's necessary entity, predicate,
   evidence route, source constraint, or value is dropped or contradicted by
   the Action.

Every earlier_scan row is an object with fields in exactly this order:

1. step: integer;
2. status: clear or proposal;
3. boundary_kind: none, result_to_state, or target_to_action;
4. evidence_step: the same integer Step for proposal, otherwise null;
5. evidence_quote: literal owned packet substring for proposal, otherwise null;
6. necessity_basis: compact text;
7. literal_boundary_basis: compact text;
8. path_effect_basis: compact text;
9. decision_basis: compact text.

A proposal row requires all three gates: task necessity, a literal mismatch in
the task and packet at that Step, and path effect under repair. It must include
a literal quote owned by that exact Step. Stop semantic admission at the first
qualifying row: there may be exactly one proposal row total. All other rows are
clear with boundary_kind none and null evidence fields, but must state compact
necessity, literal-boundary, path-effect, and decision bases explaining why the
row does not qualify.

Successful scalar/string calls, harmless summary compression, naming polish,
normal tool results, an initial useful acquisition probe, a materially different
evidence route, and merely improvable behavior remain clear. Never infer a
mismatch from unstated domain knowledge.

If an earlier proposal row exists, proposed_prediction must use that exact Step
and the anchor classification must be downstream_symptom. The anchor-veto Step
and quote must exactly copy the proposal row's evidence binding.

LATER FALLBACK

Only when every earlier_scan row is clear may the v3.14 earliest-causal later
fallback run. Challenge a reasonable probe or noncritical predecessor only
after path intervention proves that a later defect remains independently
failure-causing under anchor-only repair. Scan from anchor+1 and propose the
earliest qualifying later boundary. Do not stop at an unhelpful normal result or
repaired mechanical predecessor before comparing the first post-outcome state
or strategy boundary. Successful anchor repair may change the observed later
path, so path-dependent symptoms do not qualify.

search_summary must certify complete earlier_scan coverage, proposal count, and
whether the later fallback ran. When uncertain, no_challenge.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_17_VERSION,
        )
        .replace(
            anchor_parent.AGENT_JUDGE_LUNA_GAIA_V3_14_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_17_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger",
            "agent_judge_luna_gaia_v3_17_mandatory_earlier_scan",
        )
        .replace(
            "agent_judge_luna_gaia_v3_14_earliest_causal_challenger",
            "agent_judge_luna_gaia_v3_17_mandatory_earlier_scan",
        )
        .replace(
            "agent_judge_luna_gaia_v3_13_conservative_challenger",
            "agent_judge_luna_gaia_v3_17_mandatory_earlier_scan",
        )
    )


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_identity(anchor_parent.build_anchor_task(*paths))


def _validate_earlier_scan(
    raw: Any,
    *,
    case: Any,
    anchor_step: int,
    location: str,
) -> dict[str, Any] | None:
    if not isinstance(raw, list) or len(raw) != anchor_step - 1:
        base._fail("earlier_scan_coverage_mismatch", location)
    proposal_row: dict[str, Any] | None = None
    for expected_step, row in enumerate(raw, 1):
        row_location = f"{location}[{expected_step - 1}]"
        if not isinstance(row, dict) or tuple(row) != EARLIER_SCAN_ROW_FIELDS:
            base._fail("invalid_earlier_scan_row_schema", row_location)
        if row["step"] != expected_step:
            base._fail("earlier_scan_order_mismatch", row_location)
        if row["status"] not in EARLIER_SCAN_STATUSES:
            base._fail("invalid_earlier_scan_status", row_location)
        if row["boundary_kind"] not in EARLIER_BOUNDARY_KINDS:
            base._fail("invalid_earlier_boundary_kind", row_location)
        for field in (
            "necessity_basis",
            "literal_boundary_basis",
            "path_effect_basis",
            "decision_basis",
        ):
            base._nonempty_text(row[field], location=f"{row_location}.{field}")
        if row["status"] == "clear":
            if row["boundary_kind"] != "none" or any(
                row[field] is not None for field in ("evidence_step", "evidence_quote")
            ):
                base._fail("earlier_clear_row_must_be_null", row_location)
            continue
        if row["boundary_kind"] == "none":
            base._fail("earlier_proposal_missing_boundary_kind", row_location)
        if proposal_row is not None:
            base._fail("multiple_earlier_proposals", location)
        evidence_step = row["evidence_step"]
        evidence_quote = row["evidence_quote"]
        if (
            evidence_step != expected_step
            or not isinstance(evidence_quote, str)
            or not evidence_quote.strip()
            or len(evidence_quote) > 1200
            or not any(
                evidence_quote in source
                for source in base._packet_sources(case, expected_step)
            )
        ):
            base._fail("invalid_earlier_proposal_evidence", row_location)
        proposal_row = row
    return proposal_row


def _validate_challenger_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != CHALLENGER_FIELDS:
        base._fail("invalid_challenger_schema", f"{location} fields/order differ")
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
    ):
        base._fail("challenger_identity_mismatch", location)
    bindings = {
        "anchor_prediction_sha256": _stable_sha256(anchor),
        "anchor_ledger_sha256": _stable_sha256(ledger),
        "anchor_checkpoint_sha256": _stable_sha256(checkpoint),
    }
    if any(raw[key] != value for key, value in bindings.items()):
        base._fail("challenger_anchor_hash_mismatch", location)
    anchor_step = anchor["predicted_step"]
    if raw["anchor_step"] != anchor_step:
        base._fail("challenger_anchor_step_mismatch", location)
    if raw["challenge_status"] not in base.CHALLENGE_STATUSES:
        base._fail("invalid_challenge_status", location)
    if raw["anchor_classification"] not in parent.ANCHOR_CLASSIFICATIONS:
        base._fail("invalid_anchor_classification", location)
    proposal_row = _validate_earlier_scan(
        raw["earlier_scan"], case=case, anchor_step=anchor_step, location=f"{location}.earlier_scan"
    )
    for field in (
        "anchor_falsifier",
        "anchor_only_repair_counterfactual",
        "proposal_only_repair_counterfactual",
        "direct_timeline_comparison",
        "search_summary",
    ):
        base._nonempty_text(raw[field], location=f"{location}.{field}")

    if raw["challenge_status"] == "no_challenge":
        if proposal_row is not None or any(
            raw[field] is not None
            for field in (
                "anchor_veto_evidence_step",
                "anchor_veto_evidence_quote",
                "proposed_prediction",
            )
        ):
            base._fail("no_challenge_must_not_propose", location)
        return raw

    veto_step = raw["anchor_veto_evidence_step"]
    veto_quote = raw["anchor_veto_evidence_quote"]
    if (
        isinstance(veto_step, bool)
        or not isinstance(veto_step, int)
        or veto_step < 1
        or veto_step > len(case.judge_view.steps)
        or not isinstance(veto_quote, str)
        or not veto_quote.strip()
        or len(veto_quote) > 1200
        or not any(veto_quote in source for source in base._packet_sources(case, veto_step))
    ):
        base._fail("invalid_anchor_veto_evidence", location)
    proposal = base._validate_prediction_record(
        raw["proposed_prediction"], case=case, location=f"{location}.proposal"
    )
    proposal_step = proposal["predicted_step"]
    if proposal_step == anchor_step:
        base._fail("challenger_must_change_step", location)
    if proposal_step < anchor_step:
        if raw["anchor_classification"] != parent.EARLIER_OVERRIDE_CLASSIFICATION:
            base._fail("earlier_challenge_requires_downstream_symptom", location)
        if (
            proposal_row is None
            or proposal_row["step"] != proposal_step
            or proposal_row["evidence_step"] != veto_step
            or proposal_row["evidence_quote"] != veto_quote
        ):
            base._fail("earlier_proposal_scan_binding_mismatch", location)
    else:
        if proposal_row is not None:
            base._fail("later_challenge_forbids_earlier_proposal", location)
        if raw["anchor_classification"] not in parent.LATER_OVERRIDE_CLASSIFICATIONS:
            base._fail("later_challenge_lacks_anchor_veto", location)
        if veto_step < anchor_step:
            base._fail("later_anchor_veto_precedes_anchor", location)
    return raw


def validate_challenger(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    challenger_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = base._single_case_paths(prediction_manifest_path, cohort_manifest_path)
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    challenger_file, raw = base._load_artifact(challenger_path, role="challenger")
    anchor, ledger, checkpoint = base._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    record = base._one_record(raw, role="challenger")
    _validate_challenger_record(
        record, case=case, anchor=anchor, ledger=ledger, checkpoint=checkpoint, location="challenger[0]"
    )
    proposal = record.get("proposed_prediction")
    direction = "none" if proposal is None else (
        "earlier" if proposal["predicted_step"] < anchor["predicted_step"] else "later"
    )
    return {
        "schema_version": "agentdebug.mandatory-earlier-scan-challenger-audit.v1",
        "stage": "challenger",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_17_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_17_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_17_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": 1,
        "challenge_status": record["challenge_status"],
        "challenge_direction": direction,
        "earlier_scan_row_count": len(record["earlier_scan"]),
        "complete_ordered_earlier_scan": True,
        "single_challenger_maximum": True,
        "input_sha256": {
            ANCHOR_PREDICTIONS_FILENAME: _file_sha256(anchor_file),
            STEP_CANDIDATE_LEDGER_FILENAME: _file_sha256(ledger_file),
            STEP_FREEZE_FILENAME: _file_sha256(checkpoint_file),
        },
        "output_sha256": {CHALLENGER_FILENAME: _file_sha256(challenger_file)},
    }


def _validate_arbiter_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    challenger: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    return parent._validate_arbiter_record(
        raw, case=case, anchor=anchor, challenger=challenger, location=location
    )


def validate_arbiter(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    challenger_path: str | Path,
    arbiter_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = base._single_case_paths(prediction_manifest_path, cohort_manifest_path)
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    challenger_file, challenger_raw = base._load_artifact(challenger_path, role="challenger")
    arbiter_file, arbiter_raw = base._load_artifact(arbiter_path, role="arbiter")
    anchor, ledger, checkpoint = base._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    challenger = base._one_record(challenger_raw, role="challenger")
    _validate_challenger_record(
        challenger, case=case, anchor=anchor, ledger=ledger, checkpoint=checkpoint, location="challenger[0]"
    )
    arbiter = base._one_record(arbiter_raw, role="arbiter")
    _validate_arbiter_record(
        arbiter, case=case, anchor=anchor, challenger=challenger, location="arbiter[0]"
    )
    return {
        "schema_version": "agentdebug.mandatory-earlier-scan-arbiter-audit.v1",
        "stage": "arbiter",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_17_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_17_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_17_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": 1,
        "decision": arbiter["decision"],
        "default_anchor_policy": True,
        "selected_prediction_exact_copy": True,
        "input_sha256": {
            ANCHOR_PREDICTIONS_FILENAME: _file_sha256(anchor_file),
            CHALLENGER_FILENAME: _file_sha256(challenger_file),
        },
        "output_sha256": {ARBITER_FILENAME: _file_sha256(arbiter_file)},
    }


def validate_agent_judge_luna_gaia_v3_17_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, cases = base._load_cases(prediction_manifest_path, cohort_manifest_path)
    prediction_file = Path(predictions_path).expanduser().resolve()
    base_audit = base._validate_agent_judge_predictions_with_owner_sources(
        manifest,
        cohort,
        prediction_file,
        owner_source_resolver=base._luna_gaia_v2_owner_source_resolver,
    )
    anchor_file, anchors = base._load_artifact(
        prediction_file.parent / ANCHOR_PREDICTIONS_FILENAME, role="merged anchors"
    )
    ledger_file, ledgers = base._load_artifact(
        prediction_file.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME, role="merged anchor ledgers"
    )
    checkpoint_file, checkpoints = base._load_artifact(
        prediction_file.parent / ANCHOR_CHECKPOINT_AGGREGATE_FILENAME, role="merged anchor checkpoints"
    )
    challenger_file, challengers = base._load_artifact(
        prediction_file.parent / CHALLENGERS_FILENAME, role="merged challengers"
    )
    arbiter_file, arbiters = base._load_artifact(
        prediction_file.parent / ARBITERS_FILENAME, role="merged arbiters"
    )
    predictions = base._load_json(prediction_file, role="predictions")
    values = (anchors, ledgers, checkpoints, challengers, arbiters, predictions)
    if any(not isinstance(value, list) or len(value) != len(cases) for value in values):
        base._fail("invalid_merged_mandatory_scan_count", "all merged artifacts need all cases")
    decisions: list[str] = []
    directions: list[str] = []
    scan_rows = 0
    for index, (case, anchor, ledger, checkpoint, challenger, arbiter, prediction) in enumerate(
        zip(cases, anchors, ledgers, checkpoints, challengers, arbiters, predictions, strict=True)
    ):
        location = f"merged[{index}]"
        base._validate_prediction_record(anchor, case=case, location=f"{location}.anchor")
        if (
            ledger.get("trajectory_id") != case.trajectory_id
            or ledger.get("selected_step") != anchor["predicted_step"]
            or checkpoint.get("trajectory_id") != case.trajectory_id
            or checkpoint.get("predicted_step") != anchor["predicted_step"]
        ):
            base._fail("merged_anchor_sidecar_mismatch", location)
        _validate_challenger_record(
            challenger,
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            location=f"{location}.challenger",
        )
        _validate_arbiter_record(
            arbiter,
            case=case,
            anchor=anchor,
            challenger=challenger,
            location=f"{location}.arbiter",
        )
        if prediction != arbiter["selected_prediction"]:
            base._fail("final_prediction_differs_from_arbiter", location)
        decisions.append(arbiter["decision"])
        scan_rows += len(challenger["earlier_scan"])
        proposal = challenger.get("proposed_prediction")
        directions.append(
            "none" if proposal is None else (
                "earlier" if proposal["predicted_step"] < anchor["predicted_step"] else "later"
            )
        )
    return {
        **base_audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_17_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_17_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_17_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_17_REASONING_EFFORT,
        "selection_policy": (
            "unchanged_v3_4_anchor_mandatory_ordered_earlier_scan_one_"
            "bidirectional_challenger_default_keep_exact_copy_arbiter"
        ),
        "gold_free_validation": True,
        "case_count": len(cases),
        "anchor_semantics_unchanged_from_v3_14": True,
        "complete_ordered_earlier_scans": True,
        "total_earlier_scan_rows": scan_rows,
        "single_challenger_maximum": True,
        "all_selected_predictions_exact_copies": True,
        "arbiter_decision_counts": {
            decision: decisions.count(decision) for decision in sorted(set(decisions))
        },
        "challenger_direction_counts": {
            direction: directions.count(direction) for direction in sorted(set(directions))
        },
        "input_sidecar_sha256": {
            ANCHOR_PREDICTIONS_FILENAME: _file_sha256(anchor_file),
            ANCHOR_LEDGER_AGGREGATE_FILENAME: _file_sha256(ledger_file),
            ANCHOR_CHECKPOINT_AGGREGATE_FILENAME: _file_sha256(checkpoint_file),
            CHALLENGERS_FILENAME: _file_sha256(challenger_file),
            ARBITERS_FILENAME: _file_sha256(arbiter_file),
        },
    }


def build_challenger_task(*paths: str | Path) -> str:
    task = _rewrite_identity(parent.build_challenger_task(*paths))
    task = task.replace(parent._BOUNDED_BIDIRECTIONAL_RULES, _MANDATORY_EARLIER_SCAN_RULES)
    schema_line = '  "anchor_falsifier": "compact literal-evidence explanation",'
    earlier_schema = (
        '  "earlier_scan": "ordered rows for every Step 1..anchor-1; [] when anchor=1",\n'
        + schema_line
    )
    if task.count(schema_line) != 1:
        raise RuntimeError("v3.16 challenger schema boundary changed")
    return task.replace(schema_line, earlier_schema, 1)


def build_arbiter_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    challenger_path: str | Path,
    arbiter_path: str | Path,
) -> str:
    manifest, cohort, case = base._single_case_paths(prediction_manifest_path, cohort_manifest_path)
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    challenger_file, challenger_raw = base._load_artifact(challenger_path, role="challenger")
    anchor, ledger, checkpoint = base._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    challenger = base._one_record(challenger_raw, role="challenger")
    _validate_challenger_record(
        challenger, case=case, anchor=anchor, ledger=ledger, checkpoint=checkpoint, location="challenger[0]"
    )
    output = Path(arbiter_path).expanduser().resolve()
    base._assert_safe_path(output, role="arbiter output", is_output=True)
    audit = output.parent / ARBITER_AUDIT_FILENAME
    command = base._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_17_mandatory_earlier_scan",
            "--compact-validate",
            "arbiter",
            manifest,
            cohort,
            anchor_file,
            ledger_file,
            checkpoint_file,
            challenger_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": _stable_sha256(anchor),
        "challenger_sha256": _stable_sha256(challenger),
        "anchor_step": anchor["predicted_step"],
        "decision": "keep_anchor or accept_challenger",
        "frozen_step": "selected prediction Step",
        "selected_prediction_sha256": "stable JSON hash of exact selected prediction",
        "selected_prediction": "exact unchanged anchor or challenger prediction object",
        "decision_basis": "literal-evidence threshold decision",
        "rejected_alternative_basis": "why the other exact prediction loses",
    }
    boundary = base._boundary(
        manifest=manifest,
        cohort=cohort,
        reads=(anchor_file, ledger_file, checkpoint_file, challenger_file),
        output=output,
    ).replace(
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_13_conservative_challenger.py",
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_17_mandatory_earlier_scan.py",
    )
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_17_VERSION} stage 3/3: independent arbiter.

{boundary}

{_MANDATORY_EARLIER_SCAN_RULES}

The anchor is the default. Verify complete earlier_scan coverage and every
direction-specific classification, necessity, literal-boundary, path-effect,
and earliest-boundary claim. Accept only one exact frozen proposal. If there is
no challenge or any claim is uncertain, keep_anchor.

selected_prediction must be an exact field-for-field copy of the anchor when
keeping it, or proposed_prediction when accepting. Do not repair, rewrite, or
invent a third prediction. Compute selected_prediction_sha256 as stable sorted
compact JSON content hash of that exact object.

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def build_agent_judge_luna_gaia_v3_17_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / STEP_CANDIDATE_LEDGER_FILENAME,
        prediction.parent / STEP_FREEZE_FILENAME,
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def _write_audit(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return base._write_audit(audit, path)


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_17_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        validate_agent_judge_luna_gaia_v3_17_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_17_task
validate_agent_judge_luna_gaia_v3_13_predictions = validate_agent_judge_luna_gaia_v3_17_predictions
validate_and_write_agent_judge_luna_gaia_v3_13_audit = validate_and_write_agent_judge_luna_gaia_v3_17_audit


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_17_audit(*paths)
        else:
            base._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except base.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

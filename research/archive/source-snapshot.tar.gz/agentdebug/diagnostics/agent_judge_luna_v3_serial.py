"""Luna v3 split into three frozen, serial, gold-free judge agents.

The semantic policy is Luna v3's chronological first-mature-breakpoint rule,
but no model call may decide more than one label axis.  A fresh Step Agent
freezes the step, a fresh Module Agent accepts that artifact and freezes the
owner, and a fresh Type Agent accepts both artifacts and emits the ordinary
ten-field Agent Judge prediction.  Deterministic validators enforce that a
later stage cannot revise an earlier decision.
"""

from __future__ import annotations

import json
import os
import shlex
from pathlib import Path
from typing import Any, Mapping

from agentdebug.benchmark.prediction_manifest import (
    PredictionManifestError,
    load_prediction_manifest,
)

from .agent_judge import (
    GOLD_ISOLATION_READ_DENYLIST,
    AgentJudgeValidationError,
    _assert_gold_free,
    _assert_safe_path,
    _cohort_document,
    _file_sha256,
    _load_json,
    _validate_agent_judge_predictions_with_owner_sources,
    _fail,
)
from .agent_judge_v2_4 import (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION,
    _v2_4_owner_source_resolver,
)
from .taxonomy import AgentModule, TAXONOMY


AGENT_JUDGE_LUNA_V3_SERIAL_VERSION = (
    "agentdebug.codex-agent-judge.luna-v3-serial-v1"
)
AGENT_JUDGE_LUNA_V3_SERIAL_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_V3_SERIAL_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_V3_SERIAL_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)

STEP_DECISIONS_FILENAME = "step-decisions.json"
MODULE_DECISIONS_FILENAME = "module-decisions.json"
STEP_AUDIT_FILENAME = "step-audit.json"
MODULE_AUDIT_FILENAME = "module-audit.json"

STEP_DECISION_FIELDS = frozenset(
    {
        "trajectory_id",
        "trajectory_sha256",
        "status",
        "predicted_step",
        "step_rationale",
        "rejected_later_candidate",
    }
)
MODULE_DECISION_FIELDS = frozenset(
    {
        "trajectory_id",
        "trajectory_sha256",
        "status",
        "predicted_step",
        "predicted_module",
        "module_rationale",
        "rejected_adjacent_owner",
    }
)

_COMMON_BOUNDARY = """\
IMMUTABLE EXECUTION CONFIGURATION
- protocol: {version}
- stage: {stage}
- model: {model}
- reasoning_effort: {effort}
- exactly one isolated trajectory in this fresh ephemeral session
- no cross-case state, prior prediction, incumbent proposal, or reviewer proposal
- external LLM/API/network calls: forbidden
- scoring or gold-label access: forbidden

Read the complete JudgeView only from the exact prediction manifest below.
Trajectory ID, source model, environment, and filenames are identity fields,
never diagnostic evidence.  Do not inspect repository directories, git
history, old outputs, scores, labels, experiment reports, or case studies.
"""

_STEP_POLICY = """\
YOUR ONLY DECISION IS predicted_step

Scan STEP 1, STEP 2, ... chronologically.  At every step inspect the actual
Memory, Reflection, Planning, and Action sources that are present.  Select the
earliest mature causal error: the first demonstrably wrong proposition or
operation whose correction at that point would prevent a material wrong
branch, wasted sequence, unsupported answer, or failed interaction.

Do not use a whole-episode strongest-root comparison and do not prefer the
latest visible failure.  Later recovery does not move the introduction later.
For a repetition chain, the first probe may be reasonable; choose the first
member written after feedback or accumulated observations make continuing it
unsupported, redundant, constraint-violating, or informationally incapable.
Reject an early candidate only if it was reasonable with the evidence then,
was fully corrected before material consequence, or is speculative while a
later error is directly demonstrated.

Inspect execution_facts as well.  An independent step/tool/model/environment
boundary may own only the final step and only when otherwise reasonable
progress is actually prevented.  A normal failed episode is not System.

Do not choose, name, or output a module or error type.  Those are deliberately
reserved for later fresh agents.  Freeze only the step.
"""

_MODULE_POLICY = """\
YOUR ONLY NEW DECISION IS predicted_module

The Step Agent artifact is authoritative.  Copy predicted_step exactly and
never reconsider, repair, advance, or backtrack it.  At that frozen step,
choose the source that first introduced the frozen defect by following the
direction of information flow:

- memory: a new omission, retrieval failure, or invented historical/world state
- reflection: a new false reading of feedback, outcome, progress, or cause
- planning: a new defective strategy, constraint decision, prerequisite,
  target, or query when upstream blocks did not already introduce it
- action: only a concrete deviation from an adequate plan, unparseable syntax,
  unavailable operation, or mechanically wrong argument
- system: only a provenance-backed independent execution boundary at the
  final step

If false Memory is accepted downstream, Memory owns.  If state is accurate
but Reflection becomes false, Reflection owns.  If Reflection is accurate and
Plan makes the bad choice, Planning owns.  A faithful Action never steals
ownership from its plan.  Module tags and quote convenience identify source
boundaries, not semantic ownership.

Do not choose, name, or output an error type.  Freeze only the module while
carrying the Step Agent decision unchanged.
"""

_TYPE_POLICY = """\
YOUR ONLY NEW LABEL DECISION IS predicted_error_type

The Step and Module Agent artifacts are authoritative.  Copy predicted_step
and predicted_module exactly.  Never reconsider or repair either one.  Choose
one legal error type only within the frozen module.  Taxonomy fit must never
move the step or owner.

Use a literal, contiguous, case-sensitive evidence_quote owned by the frozen
step/module.  With recognized spans, quote that owner's span; Planning may
also quote deliberative residual text, and Action may quote tool-call names or
string arguments.  Action residual text is evidence only for format_error or
invalid_action.  System must quote an accepted execution_facts line at the
final step.  Never quote observations, task text, another step, or another
recognized owner.
"""


def _paths(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    output_path: str | Path,
) -> tuple[Path, Path, Path, Path]:
    prediction_path = Path(prediction_manifest_path).expanduser().resolve()
    cohort_path = Path(cohort_manifest_path).expanduser().resolve()
    target = Path(output_path).expanduser().resolve()
    repository_root = Path(__file__).resolve().parents[2]
    _assert_safe_path(prediction_path, role="prediction manifest")
    _assert_safe_path(cohort_path, role="cohort manifest")
    _assert_safe_path(target, role="stage output", is_output=True)
    return prediction_path, cohort_path, target, repository_root


def _read_boundary(
    prediction_path: Path,
    cohort_path: Path,
    *,
    artifact_paths: tuple[Path, ...] = (),
) -> str:
    allowlist = [
        str(prediction_path),
        str(cohort_path),
        *[str(path) for path in artifact_paths],
        "agentdebug/diagnostics/agent_judge_luna_v3_serial.py",
        "agentdebug/diagnostics/taxonomy.py (Type Agent only)",
    ]
    denylist = "\n".join(f"- {item}" for item in GOLD_ISOLATION_READ_DENYLIST)
    return (
        "GOLD-ISOLATION READ ALLOWLIST\n"
        + "\n".join(f"- {item}" for item in allowlist)
        + "\n\nGOLD-ISOLATION READ DENYLIST\n"
        + denylist
    )


def _validator_command(function_name: str, *arguments: Path) -> str:
    rendered = ", ".join(repr(str(argument)) for argument in arguments)
    code = (
        "import json; from agentdebug.diagnostics."
        "agent_judge_luna_v3_serial import "
        f"{function_name} as run; "
        f"print(json.dumps(run({rendered}), ensure_ascii=False, indent=2))"
    )
    return "PYTHONPATH=. python3 -c " + shlex.quote(code)


def _schema_text(fields: Mapping[str, str]) -> str:
    return json.dumps(dict(fields), ensure_ascii=False, indent=2)


def build_agent_judge_luna_v3_serial_step_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
) -> str:
    prediction_path, cohort_path, output_path, repository_root = _paths(
        prediction_manifest_path, cohort_manifest_path, step_decisions_path
    )
    audit_path = output_path.parent / STEP_AUDIT_FILENAME
    schema = {
        "trajectory_id": "exact manifest trajectory ID",
        "trajectory_sha256": "exact manifest trajectory SHA-256",
        "status": "success",
        "predicted_step": "positive non-boolean integer",
        "step_rationale": "concise first-mature-breakpoint explanation",
        "rejected_later_candidate": "strongest later symptom and why it is later",
    }
    command = _validator_command(
        "validate_and_write_agent_judge_luna_v3_serial_step_audit",
        prediction_path,
        cohort_path,
        output_path,
        audit_path,
    )
    return f"""\
Run the Step Agent of {AGENT_JUDGE_LUNA_V3_SERIAL_VERSION}.

{_COMMON_BOUNDARY.format(version=AGENT_JUDGE_LUNA_V3_SERIAL_VERSION, stage='step', model=AGENT_JUDGE_LUNA_V3_SERIAL_MODEL, effort=AGENT_JUDGE_LUNA_V3_SERIAL_REASONING_EFFORT)}
INPUT/OUTPUT
- prediction manifest: {prediction_path}
- prediction manifest sha256: {_file_sha256(prediction_path)}
- cohort manifest: {cohort_path}
- cohort manifest sha256: {_file_sha256(cohort_path)}
- write only: {output_path}
- validation audit: {audit_path}

{_read_boundary(prediction_path, cohort_path)}

{_STEP_POLICY}

STRICT OUTPUT CONTRACT
Write one JSON array with exactly one record and exactly these fields:
{_schema_text(schema)}
Every text field is non-empty, status is "success", and no module/type field
or alias is allowed.

MANDATORY LOCAL VALIDATION
After writing the artifact, run exactly:
cd {shlex.quote(str(repository_root))}
{command}
The stage is complete only after validation exits zero and writes its audit.
"""


def build_agent_judge_luna_v3_serial_module_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
) -> str:
    prediction_path, cohort_path, output_path, repository_root = _paths(
        prediction_manifest_path, cohort_manifest_path, module_decisions_path
    )
    step_path = Path(step_decisions_path).expanduser().resolve()
    audit_path = output_path.parent / MODULE_AUDIT_FILENAME
    _assert_safe_path(step_path, role="frozen step decisions")
    schema = {
        "trajectory_id": "exact manifest trajectory ID",
        "trajectory_sha256": "exact manifest trajectory SHA-256",
        "status": "success",
        "predicted_step": "exact frozen Step Agent integer",
        "predicted_module": "one of memory/reflection/planning/action/system",
        "module_rationale": "concise source-ownership explanation",
        "rejected_adjacent_owner": "strongest adjacent owner and rejection",
    }
    command = _validator_command(
        "validate_and_write_agent_judge_luna_v3_serial_module_audit",
        prediction_path,
        cohort_path,
        step_path,
        output_path,
        audit_path,
    )
    return f"""\
Run the Module Agent of {AGENT_JUDGE_LUNA_V3_SERIAL_VERSION}.

{_COMMON_BOUNDARY.format(version=AGENT_JUDGE_LUNA_V3_SERIAL_VERSION, stage='module', model=AGENT_JUDGE_LUNA_V3_SERIAL_MODEL, effort=AGENT_JUDGE_LUNA_V3_SERIAL_REASONING_EFFORT)}
INPUT/OUTPUT
- prediction manifest: {prediction_path}
- cohort manifest: {cohort_path}
- frozen Step Agent artifact: {step_path}
- frozen Step Agent artifact sha256: {_file_sha256(step_path)}
- write only: {output_path}
- validation audit: {audit_path}

{_read_boundary(prediction_path, cohort_path, artifact_paths=(step_path,))}

{_MODULE_POLICY}

STRICT OUTPUT CONTRACT
Write one JSON array with exactly one record and exactly these fields:
{_schema_text(schema)}
Every text field is non-empty, status is "success", and no error-type field or
alias is allowed.

MANDATORY LOCAL VALIDATION
After writing the artifact, run exactly:
cd {shlex.quote(str(repository_root))}
{command}
The stage is complete only after validation exits zero and writes its audit.
"""


def _module_taxonomy(module_value: str) -> str:
    module = AgentModule(module_value)
    lines = [f"frozen module: {module.value}"]
    for error_type, definition in TAXONOMY[module].items():
        lines.append(f"- {error_type.value}: {definition}")
    return "\n".join(lines)


def build_agent_judge_luna_v3_serial_type_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction_path, cohort_path, output_path, repository_root = _paths(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    step_path = Path(step_decisions_path).expanduser().resolve()
    module_path = Path(module_decisions_path).expanduser().resolve()
    audit_path = output_path.parent / "prediction-audit.json"
    _assert_safe_path(step_path, role="frozen step decisions")
    _assert_safe_path(module_path, role="frozen module decisions")
    module_records = _validate_module_records(
        prediction_path, cohort_path, step_path, module_path
    )[1]
    if len(module_records) != 1:
        _fail("invalid_stage_count", "Type Agent requires exactly one case")
    taxonomy = _module_taxonomy(str(module_records[0]["predicted_module"]))
    schema = {
        "trajectory_id": "exact manifest trajectory ID",
        "trajectory_sha256": "exact manifest trajectory SHA-256",
        "status": "success",
        "predicted_step": "exact frozen Step Agent integer",
        "predicted_module": "exact frozen Module Agent module",
        "predicted_error_type": "valid type within the frozen module",
        "evidence_quote": "literal non-empty frozen-owner substring",
        "root_cause": "concise explanation at the frozen boundary",
        "causal_summary": "local counterfactual and downstream propagation",
        "rejected_adjacent_owner": "strongest alternative and rejection reason",
    }
    command = _validator_command(
        "validate_and_write_agent_judge_luna_v3_serial_audit",
        prediction_path,
        cohort_path,
        output_path,
        audit_path,
    )
    return f"""\
Run the Error Type Agent of {AGENT_JUDGE_LUNA_V3_SERIAL_VERSION}.

{_COMMON_BOUNDARY.format(version=AGENT_JUDGE_LUNA_V3_SERIAL_VERSION, stage='error_type', model=AGENT_JUDGE_LUNA_V3_SERIAL_MODEL, effort=AGENT_JUDGE_LUNA_V3_SERIAL_REASONING_EFFORT)}
INPUT/OUTPUT
- prediction manifest: {prediction_path}
- cohort manifest: {cohort_path}
- frozen Step Agent artifact: {step_path}
- frozen Step Agent artifact sha256: {_file_sha256(step_path)}
- frozen Module Agent artifact: {module_path}
- frozen Module Agent artifact sha256: {_file_sha256(module_path)}
- write only: {output_path}
- validation audit: {audit_path}

{_read_boundary(prediction_path, cohort_path, artifact_paths=(step_path, module_path))}

{_TYPE_POLICY}

LEGAL ERROR TYPES FOR THE FROZEN MODULE
{taxonomy}

STRICT TEN-FIELD OUTPUT CONTRACT
Write one JSON array with exactly one record and exactly these fields:
{_schema_text(schema)}
Every text field is non-empty and status is "success".

MANDATORY LOCAL VALIDATION
After writing the artifact, run exactly:
cd {shlex.quote(str(repository_root))}
{command}
The stage is complete only after validation exits zero and writes its audit.
"""


def build_agent_judge_luna_v3_serial_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Registry-compatible final-stage builder.

    Serial orchestration normally calls the three explicit builders.  The
    shared workflow registry uses this function for metadata/scoring support
    and expects the two frozen artifacts beside ``predictions_path``.
    """

    output_path = Path(predictions_path).expanduser().resolve()
    return build_agent_judge_luna_v3_serial_type_task(
        prediction_manifest_path,
        cohort_manifest_path,
        output_path.parent / STEP_DECISIONS_FILENAME,
        output_path.parent / MODULE_DECISIONS_FILENAME,
        output_path,
    )


def _load_stage_context(
    prediction_path: Path,
    cohort_path: Path,
) -> tuple[list[Any], list[str]]:
    try:
        manifest, cases = load_prediction_manifest(prediction_path)
    except PredictionManifestError as error:
        _fail("invalid_prediction_manifest", str(error))
    cohort = _cohort_document(cohort_path)
    ids = [case.trajectory_id for case in cases]
    if ids != cohort["trajectory_ids"]:
        _fail("manifest_cohort_order_mismatch", "manifest/cohort order differs")
    if (
        manifest.get("cohort_name") != cohort.get("cohort_name")
        or manifest.get("cohort_sha256") != cohort.get("cohort_sha256")
        or manifest.get("dataset_manifest_sha256")
        != cohort.get("dataset_manifest_sha256")
    ):
        _fail("manifest_cohort_identity_mismatch", "manifest/cohort identity differs")
    return cases, ids


def _validate_stage_records(
    prediction_path: Path,
    cohort_path: Path,
    artifact_path: Path,
    *,
    fields: frozenset[str],
) -> tuple[list[Any], list[dict[str, Any]]]:
    _assert_safe_path(prediction_path, role="prediction manifest")
    _assert_safe_path(cohort_path, role="cohort manifest")
    _assert_safe_path(artifact_path, role="stage artifact")
    cases, _ = _load_stage_context(prediction_path, cohort_path)
    raw = _load_json(artifact_path, role="stage artifact")
    _assert_gold_free(raw, location="stage artifact")
    if not isinstance(raw, list) or len(raw) != len(cases):
        _fail("invalid_stage_count", "stage artifact must cover the complete cohort")
    records: list[dict[str, Any]] = []
    for index, (record, case) in enumerate(zip(raw, cases, strict=True)):
        location = f"stage[{index}]"
        if not isinstance(record, dict) or set(record) != fields:
            _fail("invalid_stage_fields", f"{location} fields differ from contract")
        for field in fields - {"predicted_step"}:
            if not isinstance(record[field], str) or not record[field].strip():
                _fail("invalid_stage_value", f"{location}.{field} must be non-empty text")
        if record["status"] != "success":
            _fail("invalid_status", f"{location}.status must equal 'success'")
        if record["trajectory_id"] != case.trajectory_id:
            _fail("cohort_order_mismatch", f"{location} trajectory identity differs")
        if record["trajectory_sha256"] != case.trajectory_sha256:
            _fail("trajectory_sha256_mismatch", f"{location} SHA-256 differs")
        step = record["predicted_step"]
        if (
            isinstance(step, bool)
            or not isinstance(step, int)
            or step < 1
            or step > len(case.judge_view.steps)
        ):
            _fail("predicted_step_out_of_range", f"{location} step is out of range")
        records.append(dict(record))
    return cases, records


def _validate_step_records(
    prediction_path: Path,
    cohort_path: Path,
    step_path: Path,
) -> tuple[list[Any], list[dict[str, Any]]]:
    return _validate_stage_records(
        prediction_path,
        cohort_path,
        step_path,
        fields=STEP_DECISION_FIELDS,
    )


def _validate_module_records(
    prediction_path: Path,
    cohort_path: Path,
    step_path: Path,
    module_path: Path,
) -> tuple[list[Any], list[dict[str, Any]]]:
    cases, step_records = _validate_step_records(
        prediction_path, cohort_path, step_path
    )
    _, module_records = _validate_stage_records(
        prediction_path,
        cohort_path,
        module_path,
        fields=MODULE_DECISION_FIELDS,
    )
    for index, (step_record, module_record) in enumerate(
        zip(step_records, module_records, strict=True)
    ):
        if module_record["predicted_step"] != step_record["predicted_step"]:
            _fail("serial_step_revision", f"module stage revised step at index {index}")
        try:
            AgentModule(module_record["predicted_module"])
        except ValueError:
            _fail("invalid_module", f"module stage has unknown owner at index {index}")
    return cases, module_records


def _stage_audit(
    *,
    stage: str,
    prediction_path: Path,
    cohort_path: Path,
    artifact_paths: tuple[Path, ...],
    case_count: int,
) -> dict[str, Any]:
    return {
        "schema_version": AGENT_JUDGE_LUNA_V3_SERIAL_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_V3_SERIAL_VERSION,
        "stage": stage,
        "model": AGENT_JUDGE_LUNA_V3_SERIAL_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V3_SERIAL_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": case_count,
        "cohort_order_matches": True,
        "prior_stage_decisions_frozen": True,
        "forbidden_read_occurred": False,
        "input_sha256": {
            "prediction_manifest": _file_sha256(prediction_path),
            "cohort": _file_sha256(cohort_path),
        },
        "output_sha256": {path.name: _file_sha256(path) for path in artifact_paths},
    }


def validate_agent_judge_luna_v3_serial_step_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
) -> dict[str, Any]:
    prediction_path, cohort_path, step_path, _ = _paths(
        prediction_manifest_path, cohort_manifest_path, step_decisions_path
    )
    cases, _ = _validate_step_records(prediction_path, cohort_path, step_path)
    return _stage_audit(
        stage="step",
        prediction_path=prediction_path,
        cohort_path=cohort_path,
        artifact_paths=(step_path,),
        case_count=len(cases),
    )


def validate_agent_judge_luna_v3_serial_module_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
) -> dict[str, Any]:
    prediction_path, cohort_path, module_path, _ = _paths(
        prediction_manifest_path, cohort_manifest_path, module_decisions_path
    )
    step_path = Path(step_decisions_path).expanduser().resolve()
    cases, _ = _validate_module_records(
        prediction_path, cohort_path, step_path, module_path
    )
    return _stage_audit(
        stage="module",
        prediction_path=prediction_path,
        cohort_path=cohort_path,
        artifact_paths=(step_path, module_path),
        case_count=len(cases),
    )


def validate_agent_judge_luna_v3_serial_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    prediction_path, cohort_path, output_path, _ = _paths(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    step_path = output_path.parent / STEP_DECISIONS_FILENAME
    module_path = output_path.parent / MODULE_DECISIONS_FILENAME
    _, module_records = _validate_module_records(
        prediction_path, cohort_path, step_path, module_path
    )
    audit = _validate_agent_judge_predictions_with_owner_sources(
        prediction_path,
        cohort_path,
        output_path,
        owner_source_resolver=_v2_4_owner_source_resolver,
    )
    final_records = _load_json(output_path, role="predictions")
    for index, (module_record, final_record) in enumerate(
        zip(module_records, final_records, strict=True)
    ):
        if final_record["predicted_step"] != module_record["predicted_step"]:
            _fail("serial_step_revision", f"type stage revised step at index {index}")
        if final_record["predicted_module"] != module_record["predicted_module"]:
            _fail("serial_module_revision", f"type stage revised module at index {index}")
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_V3_SERIAL_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_V3_SERIAL_VERSION,
        "model": AGENT_JUDGE_LUNA_V3_SERIAL_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V3_SERIAL_REASONING_EFFORT,
        "serial_stage_count": 3,
        "serial_step_frozen": True,
        "serial_module_frozen": True,
        "output_sha256": {
            "predictions.json": _file_sha256(output_path),
            STEP_DECISIONS_FILENAME: _file_sha256(step_path),
            MODULE_DECISIONS_FILENAME: _file_sha256(module_path),
        },
        "validation_method": (
            "Gold-free strict Step, Module, and Type artifacts; exact serial "
            "carry-forward; final taxonomy and selected-owner evidence checks."
        ),
    }


def _write_audit(audit_path: str | Path, audit: Mapping[str, Any]) -> dict[str, Any]:
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="stage audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(dict(audit), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return dict(audit)


def validate_and_write_agent_judge_luna_v3_serial_step_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        audit_path,
        validate_agent_judge_luna_v3_serial_step_predictions(
            prediction_manifest_path, cohort_manifest_path, step_decisions_path
        ),
    )


def validate_and_write_agent_judge_luna_v3_serial_module_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        audit_path,
        validate_agent_judge_luna_v3_serial_module_predictions(
            prediction_manifest_path,
            cohort_manifest_path,
            step_decisions_path,
            module_decisions_path,
        ),
    )


def validate_and_write_agent_judge_luna_v3_serial_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        audit_path,
        validate_agent_judge_luna_v3_serial_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
    )


__all__ = [
    "AGENT_JUDGE_LUNA_V3_SERIAL_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_V3_SERIAL_MODEL",
    "AGENT_JUDGE_LUNA_V3_SERIAL_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_V3_SERIAL_VERSION",
    "MODULE_AUDIT_FILENAME",
    "MODULE_DECISIONS_FILENAME",
    "MODULE_DECISION_FIELDS",
    "STEP_AUDIT_FILENAME",
    "STEP_DECISIONS_FILENAME",
    "STEP_DECISION_FIELDS",
    "AgentJudgeValidationError",
    "build_agent_judge_luna_v3_serial_module_task",
    "build_agent_judge_luna_v3_serial_step_task",
    "build_agent_judge_luna_v3_serial_task",
    "build_agent_judge_luna_v3_serial_type_task",
    "validate_agent_judge_luna_v3_serial_module_predictions",
    "validate_agent_judge_luna_v3_serial_predictions",
    "validate_agent_judge_luna_v3_serial_step_predictions",
]

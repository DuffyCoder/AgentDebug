"""Luna Agent Judge v8: earliest independent challenger to Luna v3.

V8 keeps the validated same-case v3 proposal and its strict temporal safety
rail, while admitting an earlier upstream root whose proposition differs from
the downstream incumbent symptom.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_v2_4 import (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION,
    _v2_4_owner_source_resolver,
)
from .agent_judge_luna_v7 import (
    AGENT_JUDGE_LUNA_V7_MODEL,
    AGENT_JUDGE_LUNA_V7_VERSION,
    INCUMBENT_PROPOSAL_FILENAME,
    _INCUMBENT_REVIEW,
    build_agent_judge_luna_v7_task,
)


AGENT_JUDGE_LUNA_V8_VERSION = "agentdebug.codex-agent-judge.luna-v8"
AGENT_JUDGE_LUNA_V8_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_V8_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_V8_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)

_BASE_HEADER = f"Run the frozen Codex Agent Judge protocol {AGENT_JUDGE_LUNA_V7_VERSION}."
_LUNA_HEADER = (
    "Run the frozen Codex Agent Judge protocol "
    f"{AGENT_JUDGE_LUNA_V8_VERSION}."
)
_BASE_MODEL = f"- model: {AGENT_JUDGE_LUNA_V7_MODEL}"
_LUNA_MODEL = f"- model: {AGENT_JUDGE_LUNA_V8_MODEL}"
_BASE_ALLOWLIST = "agentdebug/diagnostics/agent_judge_luna_v7.py"
_LUNA_ALLOWLIST = "agentdebug/diagnostics/agent_judge_luna_v8.py"
_BASE_VALIDATOR_IMPORT = "agentdebug.diagnostics.agent_judge_luna_v7"
_LUNA_VALIDATOR_IMPORT = "agentdebug.diagnostics.agent_judge_luna_v8"
_BASE_VALIDATOR_ENTRY = "validate_and_write_agent_judge_luna_v7_audit"
_LUNA_VALIDATOR_ENTRY = "validate_and_write_agent_judge_luna_v8_audit"

_EARLIEST_CHALLENGER_REVIEW = """
V8 EARLIEST INDEPENDENT CHALLENGER REVIEW

The incumbent proposal is a fallible gold-free Luna v3 diagnosis, not evidence
or a benchmark label.  The complete JudgeView is authoritative.  Review one
case independently; do not use identities, environment names, distributions,
other predictions, or gold.

First reconstruct the trajectory without copying the incumbent.  If incumbent
predicted_step is 1, KEEP is mandatory.  Otherwise, construct exactly one
challenger: the earliest owner output before the incumbent that could satisfy
the v3 first-mature causal-error definition.  Then decide:

- EARLIER REPLACE is mandatory when the challenger is directly demonstrable
  as wrong from evidence available at that step; a later decision actually
  consumes it or enters the branch it selects; its task-relevant effect is not
  recovered before the incumbent; and correcting it would prevent or
  materially redirect the cascade containing the incumbent.
- KEEP is mandatory when no such strictly earlier challenger exists, or when
  the earlier output is ordinary exploration, merely suboptimal in hindsight,
  harmless wording, fully recovered, or an independent imperfection that does
  not explain the incumbent branch.

The challenger need NOT state the same proposition or use the same taxonomy
type as the incumbent.  An upstream state loss, false outcome/progress reading,
constraint decision, or concrete action defect can produce a later repeated
plan with different wording.  Causal adoption and unrecovered branch control,
not lexical identity, establish downstream status.

When KEEP wins, copy every incumbent field exactly.  When EARLIER REPLACE
wins, predicted_step must be strictly lower and the selected owner/type/evidence
must independently pass the existing v3 rules.  Say why the incumbent is the
downstream branch manifestation in rejected_adjacent_owner.  Do not copy the
incumbent fields until this adjudication is complete.  Return only the normal
strict ten-field record; do not add a verdict field.
"""


def _proposal_path(predictions_path: str | Path) -> Path:
    return Path(predictions_path).expanduser().resolve().parent / INCUMBENT_PROPOSAL_FILENAME


def build_agent_judge_luna_v8_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build a strictly-earlier independent-challenger review task."""

    task = build_agent_judge_luna_v7_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    replacements = {
        _BASE_HEADER: _LUNA_HEADER,
        _BASE_MODEL: _LUNA_MODEL,
        _BASE_ALLOWLIST: _LUNA_ALLOWLIST,
        _BASE_VALIDATOR_IMPORT: _LUNA_VALIDATOR_IMPORT,
        _BASE_VALIDATOR_ENTRY: _LUNA_VALIDATOR_ENTRY,
        _INCUMBENT_REVIEW.strip(): _EARLIEST_CHALLENGER_REVIEW.strip(),
    }
    for old, new in replacements.items():
        if task.count(old) != 1:
            raise RuntimeError(
                "Agent Judge Luna v7 task changed at a frozen v8 marker"
            )
        task = task.replace(old, new, 1)
    return task


def validate_agent_judge_luna_v8_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    proposal_path = _proposal_path(predictions_path)
    from .agent_judge_luna_v3 import validate_agent_judge_luna_v3_predictions

    incumbent_audit = validate_agent_judge_luna_v3_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        proposal_path,
    )
    audit = _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_v2_4_owner_source_resolver,
    )
    proposal_sha256 = hashlib.sha256(proposal_path.read_bytes()).hexdigest()
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_V8_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_V8_VERSION,
        "model": AGENT_JUDGE_LUNA_V8_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V8_REASONING_EFFORT,
        "incumbent_protocol": "agentdebug.codex-agent-judge.luna-v3",
        "incumbent_proposal_sha256": proposal_sha256,
        "incumbent_proposal_case_count": incumbent_audit["case_count"],
    }


def validate_and_write_agent_judge_luna_v8_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_v8_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


__all__ = [
    "AGENT_JUDGE_LUNA_V8_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_V8_MODEL",
    "AGENT_JUDGE_LUNA_V8_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_V8_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "INCUMBENT_PROPOSAL_FILENAME",
    "build_agent_judge_luna_v8_task",
    "validate_agent_judge_luna_v8_predictions",
    "validate_and_write_agent_judge_luna_v8_audit",
]

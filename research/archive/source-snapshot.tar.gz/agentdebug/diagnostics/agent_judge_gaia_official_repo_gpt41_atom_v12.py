"""Schema-separated prompts for the GPT-4.1 GAIA evidence-atom judge.

V12 keeps v11's deterministic catalog, bounded relation geometry, strict
hard-System guard, three serial freezes, and exact final owner-atom binding.
Its only semantic-interface change is deliberate: JSON Schema remains a local
validator artifact and is never serialized into a model-visible task.  Each
stage instead receives one small concrete JSON object with placeholder IDs and
an exact allowed-field list.  Narrow repair prompts follow the same rule and
never replay the failed response.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Mapping

from . import agent_judge_gaia_official_repo_gpt41_atom_v11 as v11
from .agent_judge import AgentJudgeValidationError


VERSION = "agentdebug.llm-judge.gaia-official-repo-gpt4.1-atom-v12"
MODEL = v11.MODEL
RESOLVED_MODEL = v11.RESOLVED_MODEL
TEMPERATURE = v11.TEMPERATURE
REASONING_EFFORT = v11.REASONING_EFFORT
AUDIT_SCHEMA_VERSION = "agentdebug.gpt41-gaia-atom-v12-audit.v1"
CATALOG_SCHEMA_VERSION = v11.CATALOG_SCHEMA_VERSION

BOUNDARY_DECISION_FILENAME = v11.BOUNDARY_DECISION_FILENAME
MODULE_DECISION_FILENAME = v11.MODULE_DECISION_FILENAME
TYPE_DECISION_FILENAME = v11.TYPE_DECISION_FILENAME

BOUNDARY_SYSTEM_PROMPT = (
    "You are the boundary stage of a causal diagnostic judge. Select one supplied "
    "owner-neutral relation and one of its selectable local atoms. Return one JSON "
    "object containing only the explicitly allowed fields."
)
MODULE_SYSTEM_PROMPT = (
    "You are the ownership stage of a causal diagnostic judge. The step, evidence "
    "relation, and defect predicate are frozen. Select one supplied owner atom and "
    "return one JSON object containing only the explicitly allowed fields."
)
TYPE_SYSTEM_PROMPT = (
    "You are the taxonomy stage of a causal diagnostic judge. The boundary, defect "
    "predicate, and owner are frozen. Select one supplied type ID and return one JSON "
    "object containing only the explicitly allowed fields."
)

_STAGE_FIELDS: dict[str, tuple[str, ...]] = {
    "boundary": tuple(sorted(v11._BOUNDARY_FIELDS)),
    "module": tuple(sorted(v11._MODULE_FIELDS)),
    "type": tuple(sorted(v11._TYPE_FIELDS)),
}
_STAGE_EXAMPLES: dict[str, dict[str, str]] = {
    "boundary": {
        "selected_relation_id": "COPY_A_LEGAL_BR_ID",
        "selected_local_atom_id": "COPY_A_LEGAL_LA_ID",
        "defect_predicate": "WRITE_ONE_FALSIFIABLE_DEFECT",
        "counterfactual_correction": "WRITE_THE_SMALLEST_LOCAL_CORRECTION",
        "selection_reason": "WRITE_WHY_THIS_IS_THE_FIRST_SUFFICIENT_ROOT",
        "rejected_adjacent_boundary": "WRITE_WHY_THE_ADJACENT_ALTERNATIVE_IS_NOT_ROOT",
    },
    "module": {
        "selected_owner_atom_id": "COPY_A_LEGAL_OA_ID",
        "ownership_reason": "WRITE_WHY_THIS_OWNER_FIRST_REALIZES_THE_DEFECT",
        "rejected_owner_option": "WRITE_WHY_THE_ADJACENT_OWNER_DOES_NOT_OWN_IT",
    },
    "type": {
        "selected_type_id": "COPY_A_LEGAL_TYPE_ID",
        "type_reason": "WRITE_WHY_THIS_TYPE_MATCHES_THE_DEFECT_AND_OWNER",
        "rejected_type_option": "WRITE_WHY_THE_ALTERNATIVE_TYPE_DOES_NOT_MATCH",
    },
}
_SCHEMA_OUTPUT_KEYS = frozenset(
    {"$schema", "type", "properties", "required", "additionalProperties"}
)


def _fail(code: str, message: str) -> None:
    raise AgentJudgeValidationError(code, message)


def _to_v11_audit(audit: Mapping[str, Any], *, stage_name: str) -> dict[str, Any]:
    if (
        not isinstance(audit, Mapping)
        or audit.get("protocol") != VERSION
        or audit.get("schema_version") != AUDIT_SCHEMA_VERSION
        or audit.get("stage") != stage_name
    ):
        _fail(
            "invalid_v12_audit_lineage",
            f"{stage_name} audit is not a frozen v12 audit",
        )
    value = dict(audit)
    value["protocol"] = v11.VERSION
    value["schema_version"] = v11.AUDIT_SCHEMA_VERSION
    return value


def _from_v11_audit(audit: Mapping[str, Any]) -> dict[str, Any]:
    if (
        not isinstance(audit, Mapping)
        or audit.get("protocol") != v11.VERSION
        or audit.get("schema_version") != v11.AUDIT_SCHEMA_VERSION
    ):
        _fail("invalid_v11_base_audit", "base validator returned invalid lineage")
    value = dict(audit)
    value["protocol"] = VERSION
    value["schema_version"] = AUDIT_SCHEMA_VERSION
    return value


def _exact_example(stage_name: str) -> str:
    return json.dumps(
        _STAGE_EXAMPLES[stage_name],
        ensure_ascii=False,
        indent=2,
    )


def _field_instruction(stage_name: str) -> str:
    fields = ", ".join(_STAGE_FIELDS[stage_name])
    return (
        f"Allowed fields, exactly once each and no others: {fields}.\n"
        "The object below is a shape example. Replace every uppercase placeholder "
        "with a supplied legal ID and replace every explanatory sentence with your "
        "decision. Do not output a schema or schema metadata.\n"
        f"{_exact_example(stage_name)}"
    )


def _assert_schema_separated_task(task: Mapping[str, Any], *, stage_name: str) -> None:
    if not isinstance(task, Mapping) or set(task) != {"system_prompt", "user_prompt"}:
        _fail("invalid_stage_task", f"{stage_name} task envelope is invalid")
    for field in ("system_prompt", "user_prompt"):
        if not isinstance(task[field], str) or not task[field].strip():
            _fail("invalid_stage_task", f"{stage_name} {field} is empty")
    prompt = str(task["user_prompt"])
    forbidden = (
        '"$schema"',
        '"properties"',
        '"required"',
        '"additionalProperties"',
        '"type":',
        "draft/2020-12/schema",
    )
    if any(marker in prompt for marker in forbidden):
        _fail(
            "schema_exposed_to_model",
            f"{stage_name} model task contains JSON Schema metadata",
        )


def _reject_unreplaced_placeholders(raw: Any, *, stage_name: str) -> None:
    if not isinstance(raw, Mapping):
        return
    for field, value in raw.items():
        if not isinstance(value, str):
            continue
        normalized = value.strip().casefold()
        if normalized.startswith(("copy_", "write_", "replace_")):
            _fail(
                "unreplaced_prompt_placeholder",
                f"{stage_name}.{field} copied a shape-example placeholder",
            )


def build_atom_v11_catalog(case: Any) -> dict[str, Any]:
    """Retain the v11 catalog name for runner compatibility."""

    return v11.build_atom_v11_catalog(case)


def build_atom_v12_catalog(case: Any) -> dict[str, Any]:
    return build_atom_v11_catalog(case)


def boundary_output_schema() -> dict[str, Any]:
    return v11.boundary_output_schema()


def module_output_schema() -> dict[str, Any]:
    return v11.module_output_schema()


def type_output_schema() -> dict[str, Any]:
    return v11.type_output_schema()


def build_boundary_task(case: Any, catalog: Mapping[str, Any]) -> dict[str, str]:
    v11._check_case_catalog(case, catalog)
    task = case.judge_view.task
    task_text = (task.user_request or task.display_text) if task is not None else ""
    public = v11._public_boundary_catalog(case, catalog)
    value = {
        "system_prompt": BOUNDARY_SYSTEM_PROMPT,
        "user_prompt": (
            f"TASK\n{v11._redact(case, task_text, limit=max(4000, len(task_text) + 1))}\n\n"
            "OWNER-NEUTRAL LOCAL EVIDENCE AND BOUNDED RELATIONS\n"
            f"{json.dumps(public, ensure_ascii=False, indent=2)}\n\n"
            "Select one supplied relation and one of that relation's member_local_atom_ids. "
            "Relations are bounded causal geometries, not votes, ranks, or order "
            "preferences. Select the boundary that first emits a material defect, not "
            "the visually clearest final answer or completion symptom. A later symptom "
            "or unsupported terminal output wins only when no earlier locally sufficient "
            "root explains it. For a prior-result/current-interpretation relation, "
            "distinguish the prior action that produced the result from the current "
            "interpretation that misread it. For a same-step commitment/execution "
            "relation, select the member that actually emits the defect. Write one "
            "behavioral defect predicate that is false under the smallest correction. "
            "Do not output a step, module, error type, locus, scope, or evidence quote.\n\n"
            + _field_instruction("boundary")
        ),
    }
    _assert_schema_separated_task(value, stage_name="boundary")
    return value


def validate_boundary_decision(
    case: Any,
    catalog: Mapping[str, Any],
    raw: Any,
    *,
    expected_semantic_identity: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    _reject_unreplaced_placeholders(raw, stage_name="boundary")
    audit = v11.validate_boundary_decision(
        case,
        catalog,
        raw,
        expected_semantic_identity=expected_semantic_identity,
    )
    return _from_v11_audit(audit)


def _owner_options(
    catalog: Mapping[str, Any], boundary_audit: Mapping[str, Any]
) -> list[Mapping[str, Any]]:
    return v11._owner_options(
        catalog, _to_v11_audit(boundary_audit, stage_name="boundary")
    )


def build_module_task(
    case: Any,
    catalog: Mapping[str, Any],
    boundary_audit: Mapping[str, Any],
) -> dict[str, str]:
    v11._check_case_catalog(case, catalog)
    base_boundary = _to_v11_audit(boundary_audit, stage_name="boundary")
    v11._check_boundary_audit(catalog, base_boundary)
    public = [
        {
            "owner_atom_id": item["owner_atom_id"],
            "module": item["module"],
            "evidence_preview": v11._redact(
                case,
                item["quote"],
                limit=v11._FRAGMENT_MAX_CHARS + 256,
            ),
        }
        for item in v11._owner_options(catalog, base_boundary)
    ]
    frozen = {
        "defect_predicate": boundary_audit["defect_predicate"],
        "counterfactual_correction": boundary_audit["counterfactual_correction"],
    }
    value = {
        "system_prompt": MODULE_SYSTEM_PROMPT,
        "user_prompt": (
            f"FROZEN DEFECT\n{json.dumps(frozen, ensure_ascii=False, indent=2)}\n\n"
            f"LEGAL SAME-STEP OWNER ATOMS\n{json.dumps(public, ensure_ascii=False, indent=2)}\n\n"
            "Owner loci: memory is the current step's recall or compression of existing "
            "state; reflection is the current step's interpretation of a preceding "
            "result; planning is a strategy commitment before a call or answer; action "
            "is the actual emitted tool, parameterization, final answer, or concrete act. "
            "Select the atom that first realizes the frozen predicate; a later restatement "
            "or consequence does not take ownership. Do not output or rewrite the step, "
            "predicate, relation, evidence quote, or error type.\n\n"
            + _field_instruction("module")
        ),
    }
    _assert_schema_separated_task(value, stage_name="module")
    return value


def validate_module_decision(
    case: Any,
    catalog: Mapping[str, Any],
    boundary_audit: Mapping[str, Any],
    raw: Any,
    *,
    expected_semantic_identity: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    _reject_unreplaced_placeholders(raw, stage_name="module")
    audit = v11.validate_module_decision(
        case,
        catalog,
        _to_v11_audit(boundary_audit, stage_name="boundary"),
        raw,
        expected_semantic_identity=expected_semantic_identity,
    )
    return _from_v11_audit(audit)


def _type_options(module_audit: Mapping[str, Any]) -> list[dict[str, str]]:
    return v11._type_options(
        _to_v11_audit(module_audit, stage_name="module")
    )


def build_type_task(
    case: Any,
    catalog: Mapping[str, Any],
    boundary_audit: Mapping[str, Any],
    module_audit: Mapping[str, Any],
) -> dict[str, str]:
    v11._check_case_catalog(case, catalog)
    base_boundary = _to_v11_audit(boundary_audit, stage_name="boundary")
    base_module = _to_v11_audit(module_audit, stage_name="module")
    v11._check_boundary_audit(catalog, base_boundary)
    v11._check_module_audit(catalog, base_boundary, base_module)
    frozen = {
        "defect_predicate": boundary_audit["defect_predicate"],
        "counterfactual_correction": boundary_audit["counterfactual_correction"],
        "module": module_audit["selected_module"],
        "owner_evidence_preview": v11._redact(
            case,
            module_audit["derived_owner_evidence_quote"],
            limit=v11._FRAGMENT_MAX_CHARS + 256,
        ),
    }
    value = {
        "system_prompt": TYPE_SYSTEM_PROMPT,
        "user_prompt": (
            f"FROZEN DEFECT AND OWNER\n{json.dumps(frozen, ensure_ascii=False, indent=2)}\n\n"
            f"LEGAL TYPES\n{json.dumps(v11._type_options(base_module), ensure_ascii=False, indent=2)}\n\n"
            "Select exactly one supplied type ID whose distinguishing condition is "
            "directly supported by the frozen predicate and minimal owner evidence. "
            "Do not output or rewrite the step, module, predicate, relation, or evidence "
            "quote.\n\n"
            + _field_instruction("type")
        ),
    }
    _assert_schema_separated_task(value, stage_name="type")
    return value


def validate_type_decision(
    case: Any,
    catalog: Mapping[str, Any],
    boundary_audit: Mapping[str, Any],
    module_audit: Mapping[str, Any],
    raw: Any,
    *,
    expected_semantic_identity: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    _reject_unreplaced_placeholders(raw, stage_name="type")
    audit = v11.validate_type_decision(
        case,
        catalog,
        _to_v11_audit(boundary_audit, stage_name="boundary"),
        _to_v11_audit(module_audit, stage_name="module"),
        raw,
        expected_semantic_identity=expected_semantic_identity,
    )
    return _from_v11_audit(audit)


def _sanitized_error_text(value: Any) -> str:
    text = str(value or "")[:4000]
    for token in sorted(_SCHEMA_OUTPUT_KEYS, key=lambda item: (-len(item), item)):
        text = re.sub(re.escape(token), "[forbidden-schema-key]", text, flags=re.I)
    return text


def build_repair_task(
    *,
    stage_name: str,
    original_task: Mapping[str, Any],
    failure: Mapping[str, Any],
    locked_semantic_identity: Mapping[str, Any] | None,
    semantic_resample: bool,
) -> dict[str, str]:
    """Build attempt-2 without replaying raw output or displaying JSON Schema."""

    if stage_name not in _STAGE_FIELDS:
        _fail("invalid_repair_stage", "repair stage is unknown")
    _assert_schema_separated_task(original_task, stage_name=stage_name)
    if (locked_semantic_identity is None) != bool(semantic_resample):
        _fail(
            "invalid_repair_identity_policy",
            "semantic_resample must be true exactly when no identity is locked",
        )
    if locked_semantic_identity is not None:
        identity_policy = (
            "The following semantic identity is frozen. Copy these ID values exactly; "
            "only repair object fields or explanatory text:\n"
            + json.dumps(
                dict(locked_semantic_identity),
                ensure_ascii=False,
                sort_keys=True,
            )
        )
    else:
        identity_policy = (
            "No legal identity was recoverable. Select one legal supplied identity; "
            "this is the sole permitted semantic resample."
        )
    repair = {
        "system_prompt": str(original_task["system_prompt"]),
        "user_prompt": (
            f"{original_task['user_prompt']}\n\n"
            "<PRE_REGISTERED_NARROW_REPAIR>\n"
            "This is semantic attempt 2 of 2. The failed response is retained only in "
            "the parent audit and is intentionally not replayed here.\n"
            f"Stage: {stage_name}\n"
            f"Allowed fields: {', '.join(_STAGE_FIELDS[stage_name])}\n"
            f"Validator error code: {_sanitized_error_text(failure.get('error_code'))}\n"
            f"Validator message: {_sanitized_error_text(failure.get('message'))}\n"
            f"Identity policy: {identity_policy}\n"
            "Return one corrected JSON object only. Do not output schema metadata.\n"
            f"Concrete shape example:\n{_exact_example(stage_name)}\n"
            "</PRE_REGISTERED_NARROW_REPAIR>"
        ),
    }
    _assert_schema_separated_task(repair, stage_name=f"{stage_name} repair")
    return repair


def extract_boundary_semantic_identity(
    raw: Any, catalog: Mapping[str, Any] | None = None
) -> dict[str, str] | None:
    return v11.extract_boundary_semantic_identity(raw, catalog)


def extract_module_semantic_identity(
    raw: Any,
    catalog: Mapping[str, Any] | None = None,
    boundary_audit: Mapping[str, Any] | None = None,
) -> dict[str, str] | None:
    return v11.extract_module_semantic_identity(
        raw,
        catalog,
        _to_v11_audit(boundary_audit, stage_name="boundary")
        if boundary_audit is not None
        else None,
    )


def extract_type_semantic_identity(
    raw: Any, module_audit: Mapping[str, Any] | None = None
) -> dict[str, str] | None:
    return v11.extract_type_semantic_identity(
        raw,
        _to_v11_audit(module_audit, stage_name="module")
        if module_audit is not None
        else None,
    )


def deterministic_boundary_decision(
    catalog: Mapping[str, Any],
) -> dict[str, str] | None:
    return v11.deterministic_boundary_decision(catalog)


def deterministic_module_decision(
    catalog: Mapping[str, Any], boundary_audit: Mapping[str, Any]
) -> dict[str, str] | None:
    return v11.deterministic_module_decision(
        catalog, _to_v11_audit(boundary_audit, stage_name="boundary")
    )


def deterministic_type_decision(
    module_audit: Mapping[str, Any],
) -> dict[str, str] | None:
    return v11.deterministic_type_decision(
        _to_v11_audit(module_audit, stage_name="module")
    )


def runtime_conformance_boundary_decision(
    catalog: Mapping[str, Any],
) -> dict[str, str]:
    return v11.runtime_conformance_boundary_decision(catalog)


def runtime_conformance_module_decision(
    catalog: Mapping[str, Any], boundary_audit: Mapping[str, Any]
) -> dict[str, str]:
    return v11.runtime_conformance_module_decision(
        catalog, _to_v11_audit(boundary_audit, stage_name="boundary")
    )


def runtime_conformance_type_decision(
    module_audit: Mapping[str, Any],
) -> dict[str, str]:
    return v11.runtime_conformance_type_decision(
        _to_v11_audit(module_audit, stage_name="module")
    )


def runtime_boundary_decision(case: Any, catalog: Mapping[str, Any]) -> dict[str, str]:
    return v11.runtime_boundary_decision(case, catalog)


def runtime_module_decision(
    case: Any,
    catalog: Mapping[str, Any],
    boundary_audit: Mapping[str, Any],
) -> dict[str, str]:
    return v11.runtime_module_decision(
        case,
        catalog,
        _to_v11_audit(boundary_audit, stage_name="boundary"),
    )


def runtime_type_decision(
    case: Any,
    catalog: Mapping[str, Any],
    boundary_audit: Mapping[str, Any],
    module_audit: Mapping[str, Any],
) -> dict[str, str]:
    return v11.runtime_type_decision(
        case,
        catalog,
        _to_v11_audit(boundary_audit, stage_name="boundary"),
        _to_v11_audit(module_audit, stage_name="module"),
    )


def derive_prediction(
    case: Any,
    catalog: Mapping[str, Any],
    boundary_audit: Mapping[str, Any],
    module_audit: Mapping[str, Any],
    type_audit: Mapping[str, Any],
) -> dict[str, Any]:
    return v11.derive_prediction(
        case,
        catalog,
        _to_v11_audit(boundary_audit, stage_name="boundary"),
        _to_v11_audit(module_audit, stage_name="module"),
        _to_v11_audit(type_audit, stage_name="type"),
    )


def validate_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = v11.validate_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    return {
        **audit,
        "agent_judge_version": VERSION,
        "schema_separated_model_prompts": True,
        "repair_response_replay": False,
        "repair_schema_exposure": False,
    }


build_protocol_task = build_boundary_task
build_task = build_boundary_task


__all__ = [
    "AUDIT_SCHEMA_VERSION",
    "BOUNDARY_DECISION_FILENAME",
    "BOUNDARY_SYSTEM_PROMPT",
    "CATALOG_SCHEMA_VERSION",
    "MODEL",
    "MODULE_DECISION_FILENAME",
    "MODULE_SYSTEM_PROMPT",
    "REASONING_EFFORT",
    "RESOLVED_MODEL",
    "TEMPERATURE",
    "TYPE_DECISION_FILENAME",
    "TYPE_SYSTEM_PROMPT",
    "VERSION",
    "boundary_output_schema",
    "build_atom_v11_catalog",
    "build_atom_v12_catalog",
    "build_boundary_task",
    "build_module_task",
    "build_protocol_task",
    "build_repair_task",
    "build_task",
    "build_type_task",
    "derive_prediction",
    "deterministic_boundary_decision",
    "deterministic_module_decision",
    "deterministic_type_decision",
    "extract_boundary_semantic_identity",
    "extract_module_semantic_identity",
    "extract_type_semantic_identity",
    "module_output_schema",
    "runtime_boundary_decision",
    "runtime_conformance_boundary_decision",
    "runtime_conformance_module_decision",
    "runtime_conformance_type_decision",
    "runtime_module_decision",
    "runtime_type_decision",
    "type_output_schema",
    "validate_boundary_decision",
    "validate_module_decision",
    "validate_predictions",
    "validate_type_decision",
]

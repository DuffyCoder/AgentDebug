"""GAIA v3.88: accepted v3.83 plus one sparse influence-graph challenger."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_gaia_v3_83_clean_v3p20_model_only_gpt55_medium as parent
from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger as transport
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as packet_parent


AGENT_JUDGE_GAIA_V3_88_VERSION = (
    "agentdebug.codex-agent-judge.gaia-v3.88-gpt55-sparse-influence-graph-challenger"
)
AGENT_JUDGE_GAIA_V3_88_MODEL = "gpt-5.5"
AGENT_JUDGE_GAIA_V3_88_REASONING_EFFORT = "medium"
AGENT_JUDGE_GAIA_V3_88_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_GAIA_V3_83_AUDIT_SCHEMA_VERSION
)
SEMANTIC_PARENT = parent.AGENT_JUDGE_GAIA_V3_83_VERSION

AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_GAIA_V3_88_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_GAIA_V3_88_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_GAIA_V3_88_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_GAIA_V3_88_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = parent.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = parent.CHALLENGERS_FILENAME
ARBITER_FILENAME = parent.ARBITER_FILENAME
ARBITERS_FILENAME = parent.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = parent.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = parent.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME

GRAPH_FIELDS = (
    "graph_status",
    "root_step",
    "root_commitment_quote",
    "obligation_source",
    "obligation_step",
    "obligation_quote",
    "terminal_step",
    "terminal_quote",
    "edges",
)
EDGE_FIELDS = (
    "from_step",
    "to_step",
    "relation",
    "producer_quote",
    "consumer_quote",
    "producer_atom",
    "consumer_atom",
    "effect",
)
RELATIONS = frozenset(
    {"state_inheritance", "observation_consumption", "target_handoff", "control_dependency"}
)
EFFECTS = frozenset({"preserved", "distorted", "dropped", "recommitted"})


_SPARSE_INFLUENCE_GRAPH_RULES = """\
SPARSE INFLUENCE-GRAPH SINGLE CHALLENGER

The frozen v3.83 prediction is the incumbent anchor. Keep its ledger and
checkpoint immutable. Inspect the COMPLETE trace, but do not enumerate local
errors or retain a candidate pool. Emit at most one earlier-or-later proposal,
and only when one compact influence chain proves why that Step is the root of
the observed failure. The anchor is the default under uncertainty.

ROOT AND OBLIGATION

The proposed root must own a concrete wrong commitment, unsupported retained
state, direct constraint contradiction, or failure-causing Action. Quote it
verbatim. Also quote the exact task requirement or observable Step fact that
the root violates. Do not invent requirements from domain knowledge. Raw tool
results are observations, not Agent-owned roots.

PRODUCER-TO-CONSUMER EDGE CHAIN

Encode one chronological chain of one to three edges. Every edge must quote a
producer packet and a later consumer packet, then quote a compact literal atom
inside each packet that identifies the inherited value, state, target,
predicate, or control decision. The relation must be exactly one of:

- state_inheritance: retained state is reused downstream;
- observation_consumption: an observed result is read into a later decision;
- target_handoff: an immediate target/predicate is handed to another Step;
- control_dependency: a commitment directly determines the later route.

The observed effect is preserved, distorted, dropped, or recommitted. Each
edge must start where the preceding edge ended. The first edge starts at the
proposed root; the last ends at a quoted failure manifestation. A topic match,
shared entity, temporal adjacency, severity, persistence, or plausible story
is not an influence edge. If the later packet does not visibly consume the
producer atom, emit no_challenge.

BOUNDARY, RECOVERY, AND ANCHOR VETO

The proposal is the first wrong commitment on this SAME influence chain whose
local repair can change the failed path. Do not prefer an unrelated earlier
surface issue or a later symptom. Reject normal tool/site failure, reasonable
or materially different probes, mechanical repair, faithful propagation, and
merely improvable behavior. Re-read the suffix: if later packets cleanly repair
the root and route before the terminal manifestation, emit no_challenge.

For an earlier proposal, the anchor must be a downstream symptom of the chain.
For a later proposal, the anchor must be a reasonable probe or noncritical
predecessor. Quote the literal anchor falsifier. proposed_prediction must be a
complete legal prediction owned by the root Step/module. If any graph endpoint,
atom, relation, recovery, repair, or anchor-veto claim is uncertain, emit
no_challenge.
"""


_GRAPH_SCHEMA = {
    "graph_status": "no_graph_root or root_candidate",
    "root_step": "integer or null",
    "root_commitment_quote": "literal root-Step substring or null",
    "obligation_source": "task/step or null",
    "obligation_step": "integer for step source, else null",
    "obligation_quote": "literal task/Step substring or null",
    "terminal_step": "integer or null",
    "terminal_quote": "literal terminal-Step substring or null",
    "edges": [
        {
            "from_step": "integer",
            "to_step": "strictly later integer",
            "relation": "state_inheritance/observation_consumption/target_handoff/control_dependency",
            "producer_quote": "literal from-Step substring",
            "consumer_quote": "literal to-Step substring",
            "producer_atom": "literal substring of producer_quote",
            "consumer_atom": "literal substring of consumer_quote",
            "effect": "preserved/distorted/dropped/recommitted",
        }
    ],
}


def _retag_parent_task(task: str) -> str:
    marker = parent.AGENT_JUDGE_GAIA_V3_83_VERSION
    if task.count(marker) != 1:
        raise RuntimeError("v3.83 task identity marker changed unexpectedly")
    return (
        task.replace(marker, AGENT_JUDGE_GAIA_V3_88_VERSION, 1)
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_gaia_v3_88_gpt55_sparse_influence_graph_challenger",
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py",
            "agentdebug/diagnostics/agent_judge_gaia_v3_88_gpt55_sparse_influence_graph_challenger.py",
        )
    )


def _retag_transport_task(task: str) -> str:
    result = task.replace(
        transport.AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
        AGENT_JUDGE_GAIA_V3_88_VERSION,
    ).replace(
        f"- model: {transport.AGENT_JUDGE_LUNA_GAIA_V3_16_MODEL}",
        f"- model: {AGENT_JUDGE_GAIA_V3_88_MODEL}",
    )
    for old in (
        "agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger",
        "agent_judge_luna_gaia_v3_14_earliest_causal_challenger",
        "agent_judge_luna_gaia_v3_13_conservative_challenger",
    ):
        result = result.replace(
            old, "agent_judge_gaia_v3_88_gpt55_sparse_influence_graph_challenger"
        )
    return result


def _retag_audit(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    excluded = {"anchor_semantics_unchanged_from_v3_14", "earlier_first"}
    result = {key: value for key, value in audit.items() if key not in excluded}
    return {
        **result,
        "agent_judge_version": AGENT_JUDGE_GAIA_V3_88_VERSION,
        "model": AGENT_JUDGE_GAIA_V3_88_MODEL,
        "reasoning_effort": AGENT_JUDGE_GAIA_V3_88_REASONING_EFFORT,
        "selection_policy": policy,
        "semantic_parent": SEMANTIC_PARENT,
        "direct_semantic_parent": SEMANTIC_PARENT,
        "rejected_lineage_inherited": False,
        "single_major_change": "one sparse producer-consumer influence-graph challenger",
    }


def _task_sources(case: Any) -> tuple[str, ...]:
    task = case.judge_view.task
    return tuple(
        value
        for value in (
            getattr(task, "user_request", None),
            getattr(task, "description", None),
            getattr(task, "title", None),
        )
        if isinstance(value, str) and value.strip()
    )


def _valid_step(step: Any, case: Any) -> bool:
    return (
        not isinstance(step, bool)
        and isinstance(step, int)
        and 1 <= step <= len(case.judge_view.steps)
    )


def _literal(quote: Any, sources: Sequence[str], *, location: str) -> str:
    if (
        not isinstance(quote, str)
        or not quote.strip()
        or len(quote) > 600
        or not any(quote in source for source in sources)
    ):
        shared._fail("invalid_influence_graph_literal", location)
    return quote


def _graph_from_record(record: dict[str, Any], *, location: str) -> dict[str, Any]:
    raw = record.get("direct_timeline_comparison")
    try:
        graph = json.loads(raw) if isinstance(raw, str) else None
    except json.JSONDecodeError:
        graph = None
    if not isinstance(graph, dict) or tuple(graph) != GRAPH_FIELDS:
        shared._fail("invalid_sparse_influence_graph_json", location)
    return graph


def _validate_graph_record(
    record: dict[str, Any], *, case: Any, location: str
) -> dict[str, Any]:
    graph = _graph_from_record(record, location=location)
    challenged = record.get("challenge_status") == "challenge"
    if not challenged:
        expected_null = (
            graph["root_step"],
            graph["root_commitment_quote"],
            graph["obligation_source"],
            graph["obligation_step"],
            graph["obligation_quote"],
            graph["terminal_step"],
            graph["terminal_quote"],
        )
        if graph["graph_status"] != "no_graph_root" or any(
            value is not None for value in expected_null
        ) or graph["edges"] != []:
            shared._fail("no_challenge_has_influence_graph_root", location)
        return graph

    proposal = record.get("proposed_prediction")
    root_step = graph["root_step"]
    if (
        graph["graph_status"] != "root_candidate"
        or not isinstance(proposal, dict)
        or not _valid_step(root_step, case)
        or proposal.get("predicted_step") != root_step
    ):
        shared._fail("influence_graph_root_prediction_mismatch", location)
    _literal(
        graph["root_commitment_quote"],
        shared._packet_sources(case, root_step),
        location=f"{location}.root_commitment_quote",
    )
    if graph["obligation_source"] == "task":
        if graph["obligation_step"] is not None:
            shared._fail("task_obligation_has_step", location)
        obligation_sources = _task_sources(case)
    elif graph["obligation_source"] == "step" and _valid_step(
        graph["obligation_step"], case
    ):
        obligation_sources = shared._packet_sources(case, graph["obligation_step"])
    else:
        shared._fail("invalid_graph_obligation_source", location)
    _literal(
        graph["obligation_quote"],
        obligation_sources,
        location=f"{location}.obligation_quote",
    )
    terminal_step = graph["terminal_step"]
    if not _valid_step(terminal_step, case) or terminal_step <= root_step:
        shared._fail("invalid_graph_terminal_step", location)
    _literal(
        graph["terminal_quote"],
        shared._packet_sources(case, terminal_step),
        location=f"{location}.terminal_quote",
    )
    edges = graph["edges"]
    if not isinstance(edges, list) or not 1 <= len(edges) <= 3:
        shared._fail("invalid_influence_edge_count", location)
    cursor = root_step
    for index, edge in enumerate(edges):
        edge_location = f"{location}.edges[{index}]"
        if not isinstance(edge, dict) or tuple(edge) != EDGE_FIELDS:
            shared._fail("invalid_influence_edge_schema", edge_location)
        from_step = edge["from_step"]
        to_step = edge["to_step"]
        if (
            not _valid_step(from_step, case)
            or not _valid_step(to_step, case)
            or from_step != cursor
            or to_step <= from_step
        ):
            shared._fail("broken_or_nonchronological_influence_chain", edge_location)
        if edge["relation"] not in RELATIONS or edge["effect"] not in EFFECTS:
            shared._fail("invalid_influence_edge_type", edge_location)
        producer = _literal(
            edge["producer_quote"],
            shared._packet_sources(case, from_step),
            location=f"{edge_location}.producer_quote",
        )
        consumer = _literal(
            edge["consumer_quote"],
            shared._packet_sources(case, to_step),
            location=f"{edge_location}.consumer_quote",
        )
        for name, atom, quote in (
            ("producer_atom", edge["producer_atom"], producer),
            ("consumer_atom", edge["consumer_atom"], consumer),
        ):
            if (
                not isinstance(atom, str)
                or len(atom.strip()) < 3
                or len(atom) > 200
                or atom not in quote
            ):
                shared._fail("invalid_influence_edge_atom", f"{edge_location}.{name}")
        cursor = to_step
    if cursor != terminal_step:
        shared._fail("influence_chain_does_not_reach_terminal", location)
    return graph


def _validate_graph_artifact(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    challenger_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(prediction_manifest_path, cohort_manifest_path)
    path, raw = shared._load_artifact(challenger_path, role="sparse influence graphs")
    rows = raw if isinstance(raw, list) else [raw]
    if len(rows) != len(cases) or any(not isinstance(row, dict) for row in rows):
        shared._fail("invalid_influence_graph_artifact_count", str(path))
    roots = 0
    edge_count = 0
    for index, (case, row) in enumerate(zip(cases, rows, strict=True)):
        if row.get("trajectory_id") != case.trajectory_id:
            shared._fail("influence_graph_identity_mismatch", f"graph[{index}]")
        graph = _validate_graph_record(row, case=case, location=f"graph[{index}]")
        roots += graph["graph_status"] == "root_candidate"
        edge_count += len(graph["edges"])
    return {
        "required": True,
        "valid": True,
        "path": str(path),
        "record_count": len(rows),
        "root_candidate_count": roots,
        "edge_count": edge_count,
        "maximum_edges_per_case": 3,
        "literal_endpoint_and_atom_validation": True,
    }


def build_anchor_task(*paths: str | Path) -> str:
    return _retag_parent_task(parent.build_anchor_task(*paths))


def build_challenger_task(*paths: str | Path) -> str:
    task = transport.build_challenger_task(*paths)
    if task.count(transport._BOUNDED_BIDIRECTIONAL_RULES) != 1:
        raise RuntimeError("bidirectional transport rule marker changed unexpectedly")
    task = task.replace(
        transport._BOUNDED_BIDIRECTIONAL_RULES,
        _SPARSE_INFLUENCE_GRAPH_RULES,
        1,
    )
    task = task.replace(
        "Search earlier first, then use the later fallback; a proposal must change Step.",
        "Build only one sparse root-to-terminal influence chain; a proposal may be earlier or later but must change Step.",
    )
    task = task.replace(
        '"anchor-versus-proposal comparison"',
        '"compact JSON string containing exactly the sparse influence-graph schema below"',
    )
    task = task.replace(
        '"which direction was searched and why one proposal exists or none qualifies"',
        '"why the explicit influence chain proves one root or why no chain qualifies"',
    )
    graph_instruction = f"""\
direct_timeline_comparison MUST be a compact JSON-encoded string (not a nested
outer object) with keys in exactly this order:
{json.dumps(_GRAPH_SCHEMA, ensure_ascii=False, indent=2)}

For no_challenge use graph_status=no_graph_root, null for every scalar graph
field, and an empty edges list. For challenge use graph_status=root_candidate,
one to three contiguous edges, and make root_step equal proposed_prediction's
Step. Keep the encoded graph under 1800 characters. Do not add prose inside
direct_timeline_comparison; use search_summary for the comparison explanation.

"""
    task = task.replace("AGENT ERROR TAXONOMY\n", graph_instruction + "AGENT ERROR TAXONOMY\n")
    return _retag_transport_task(task)


def build_arbiter_task(*paths: str | Path) -> str:
    task = transport.build_arbiter_task(*paths)
    if task.count(transport._BOUNDED_BIDIRECTIONAL_RULES) != 1:
        raise RuntimeError("bidirectional arbiter rule marker changed unexpectedly")
    task = task.replace(
        transport._BOUNDED_BIDIRECTIONAL_RULES,
        _SPARSE_INFLUENCE_GRAPH_RULES,
        1,
    )
    old = (
        "Accept it only if every direction-specific classification,\n"
        "necessity, literal-boundary, path-effect, path-intervention, and earliest-\n"
        "boundary claim is supported by chronology. If there is no challenge, keep_anchor."
    )
    new = (
        "Parse the compact graph in direct_timeline_comparison. Accept only if every "
        "producer/consumer quote and atom proves the typed influence edge, the chain "
        "starts at the first wrong commitment on that chain, reaches the quoted failed "
        "ending, survives recovery review, and falsifies the anchor. Topic or chronology "
        "alone is insufficient. If there is no challenge, keep_anchor."
    )
    task = task.replace(old, new)
    return _retag_transport_task(task)


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag_audit(parent.validate_anchor_predictions(*paths), policy="unchanged_v3_83_anchor")


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    audit = transport.validate_challenger(*paths)
    packet = packet_parent._validate_packet_state_ledgers(paths[3])
    graph = _validate_graph_artifact(paths[0], paths[1], paths[-1])
    return _retag_audit(
        {**audit, "packet_state_closure": packet, "sparse_influence_graph": graph},
        policy="one_sparse_producer_consumer_influence_graph_challenger",
    )


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    audit = transport.validate_arbiter(*paths)
    packet = packet_parent._validate_packet_state_ledgers(paths[3])
    graph = _validate_graph_artifact(paths[0], paths[1], paths[5])
    return _retag_audit(
        {**audit, "packet_state_closure": packet, "sparse_influence_graph": graph},
        policy="default_keep_exact_copy_arbiter_over_sparse_influence_graph",
    )


def validate_agent_judge_gaia_v3_88_predictions(*paths: str | Path) -> dict[str, Any]:
    audit = transport.validate_agent_judge_luna_gaia_v3_16_predictions(*paths)
    predictions = Path(paths[2]).expanduser().resolve()
    packet = packet_parent._validate_packet_state_ledgers(
        predictions.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME
    )
    graph = _validate_graph_artifact(
        paths[0], paths[1], predictions.parent / CHALLENGERS_FILENAME
    )
    return _retag_audit(
        {
            **audit,
            "schema_version": AGENT_JUDGE_GAIA_V3_88_AUDIT_SCHEMA_VERSION,
            "anchor_semantics_unchanged_from_v3_83": True,
            "packet_state_closure": packet,
            "sparse_influence_graph": graph,
        },
        policy=(
            "unchanged_v3_83_anchor_one_sparse_producer_consumer_influence_"
            "graph_challenger_default_keep_exact_copy_arbiter"
        ),
    )


def build_agent_judge_gaia_v3_88_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_gaia_v3_88_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_agent_judge_gaia_v3_88_predictions(*paths[:-1]), paths[-1])


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_gaia_v3_88_task
validate_agent_judge_luna_gaia_v3_13_predictions = validate_agent_judge_gaia_v3_88_predictions
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_gaia_v3_88_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_gaia_v3_88_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    args = parser.parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "AGENT_JUDGE_GAIA_V3_88_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_GAIA_V3_88_MODEL",
    "AGENT_JUDGE_GAIA_V3_88_REASONING_EFFORT",
    "AGENT_JUDGE_GAIA_V3_88_VERSION",
    "SEMANTIC_PARENT",
    "build_agent_judge_gaia_v3_88_task",
    "build_anchor_task",
    "build_arbiter_task",
    "build_challenger_task",
    "validate_agent_judge_gaia_v3_88_predictions",
    "validate_and_write_agent_judge_gaia_v3_88_audit",
]

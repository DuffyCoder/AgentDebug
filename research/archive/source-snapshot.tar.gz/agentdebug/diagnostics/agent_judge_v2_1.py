"""Gold-isolated Codex Agent Judge v2.1 protocol.

V2.1 is a minimal, independently versioned delta over v2.  It preserves the
v2 causal decision procedure and ten-field contract while adding a symmetric
planning admission gate and a mandatory literal evidence-copy lock.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    validate_agent_judge_predictions,
)
from .agent_judge_v2 import (
    AGENT_JUDGE_V2_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_V2_MODEL,
    AGENT_JUDGE_V2_REASONING_EFFORT,
    AGENT_JUDGE_V2_VERSION,
    build_agent_judge_v2_task,
)


AGENT_JUDGE_V2_1_VERSION = "agentdebug.codex-agent-judge.v2.1"
AGENT_JUDGE_V2_1_MODEL = AGENT_JUDGE_V2_MODEL
AGENT_JUDGE_V2_1_REASONING_EFFORT = AGENT_JUDGE_V2_REASONING_EFFORT
AGENT_JUDGE_V2_1_AUDIT_SCHEMA_VERSION = AGENT_JUDGE_V2_AUDIT_SCHEMA_VERSION

_V2_PROTOCOL_HEADER = f"Run the frozen Codex Agent Judge protocol {AGENT_JUDGE_V2_VERSION}."
_V2_1_PROTOCOL_HEADER = (
    "Run the frozen Codex Agent Judge protocol "
    f"{AGENT_JUDGE_V2_1_VERSION}."
)
_V2_MODULE_ALLOWLIST_ENTRY = "agentdebug/diagnostics/agent_judge_v2.py"
_V2_1_MODULE_ALLOWLIST_ENTRY = "agentdebug/diagnostics/agent_judge_v2_1.py"
_CONTRACT_MARKER = "\nSTRICT PREDICTION CONTRACT\n"

_V2_1_DELTA = """
V2.1 MANDATORY FIVE-MODULE AUDIT AND ADMISSION GATES

For every case, genuinely audit memory, reflection, planning, action, and
system against the evidence and causal chain.  Do not skip an owner because
another module is easier to quote.  The selected owner must follow the case
evidence; never select, avoid, or diversify a module to create any particular
cross-case distribution.

Apply the PLANNING ADMISSION GATE symmetrically with the existing action gate.
Planning ownership is allowed only when the relevant same-step and earlier
memory and reflection outputs did not introduce a persistent false fact,
false progress assessment, or false causal assessment, and the plan itself
newly introduces the defective strategy, ignored constraint, impossible
operation, or wasteful path.  If the plan faithfully propagates a false memory
or reflection, reject planning and select the first mature, causally
sufficient, unrecovered upstream owner.  If this check exposes an earlier
owner, discard the planning candidate, return to Stage I, and freeze that
earliest upstream step before the final step/owner decision.

V2.1 EVIDENCE COPY LOCK — REQUIRED BEFORE OUTPUT

After predicted_step and predicted_module are finally frozen, construct
evidence_quote only by copying a non-empty, exact, contiguous substring from
the selected step's source owned by that selected module:
- For a tagged trace, copy from that module's span at the selected step.
- For a tag-free trace, copy from the selected step's assistant_raw_output,
  which is the validator's lossless semantic module source.  For action, a
  tool-call name or string argument owned by that step is also permitted.
- For system, retain the existing strict rule: select the final step and copy
  exactly one provenance-backed execution_facts line accepted by the validator.

Never copy evidence from current_input, task, adjacent_feedback, an
observation, a tool result, a different step, or another module's tagged span.
Never paraphrase, translate, summarize, normalize whitespace or punctuation,
change capitalization, repair spelling, remove tags from a copied range, or
otherwise rewrite the evidence.  JSON escaping is allowed only as transport;
after JSON decoding, evidence_quote must still be the literal copied text.

Immediately before emitting each record, perform a literal substring
self-check: the decoded evidence_quote must occur case-sensitively and
contiguously in at least one validator-owned source for the frozen
predicted_step/predicted_module pair.  If it does not, do not change the frozen
step or owner merely to find an easier quote; recopy a valid substring from
the already selected owner source.  Emit the record only after this check
passes.
"""


def build_agent_judge_v2_1_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build the frozen v2 task plus the independently versioned v2.1 delta."""

    task = build_agent_judge_v2_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    if task.count(_V2_PROTOCOL_HEADER) != 1:
        raise RuntimeError("Agent Judge v2 protocol header changed unexpectedly")
    if task.count(_V2_MODULE_ALLOWLIST_ENTRY) != 1:
        raise RuntimeError("Agent Judge v2 read allowlist changed unexpectedly")
    if task.count(_CONTRACT_MARKER) != 1:
        raise RuntimeError("Agent Judge v2 contract marker changed unexpectedly")

    task = task.replace(_V2_PROTOCOL_HEADER, _V2_1_PROTOCOL_HEADER, 1)
    task = task.replace(
        _V2_MODULE_ALLOWLIST_ENTRY,
        _V2_1_MODULE_ALLOWLIST_ENTRY,
        1,
    )
    return task.replace(
        _CONTRACT_MARKER,
        f"\n{_V2_1_DELTA.strip()}\n{_CONTRACT_MARKER}",
        1,
    )


def validate_agent_judge_v2_1_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    """Reuse the unchanged strict validator and bind its audit to v2.1."""

    audit = validate_agent_judge_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_V2_1_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_V2_1_VERSION,
        "model": AGENT_JUDGE_V2_1_MODEL,
        "reasoning_effort": AGENT_JUDGE_V2_1_REASONING_EFFORT,
    }


__all__ = [
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AGENT_JUDGE_V2_1_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_V2_1_MODEL",
    "AGENT_JUDGE_V2_1_REASONING_EFFORT",
    "AGENT_JUDGE_V2_1_VERSION",
    "AgentJudgeValidationError",
    "build_agent_judge_v2_1_task",
    "validate_agent_judge_v2_1_predictions",
]

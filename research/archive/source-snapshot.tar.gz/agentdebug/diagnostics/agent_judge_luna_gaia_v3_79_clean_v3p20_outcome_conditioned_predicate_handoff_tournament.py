"""Luna GAIA v3.79: outcome-conditioned predicate-handoff tournament."""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any

from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from . import (
    agent_judge_luna_gaia_v3_76_clean_v3p20_sparse_ledger_global_boundary_selector_runtime_repair as legality,
)
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions
from .taxonomy import taxonomy_prompt


shared = legality.shared
AGENT_JUDGE_LUNA_GAIA_V3_79_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.79-clean-v3.20-"
    "outcome-conditioned-predicate-handoff-tournament"
)
AGENT_JUDGE_LUNA_GAIA_V3_79_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_79_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_79_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases for the frozen two-stage aggregation runner.
AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_79_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_79_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT = AGENT_JUDGE_LUNA_GAIA_V3_79_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_79_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_79_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = AGENT_JUDGE_LUNA_GAIA_V3_79_REASONING_EFFORT

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
INFERENCE_DOCUMENT_FILENAME = legality.INFERENCE_DOCUMENT_FILENAME
PANEL_FILENAME = "predicate-handoff-tournament-assessment.json"
PANELS_FILENAME = "predicate-handoff-tournament-assessments.json"
PANEL_AUDIT_FILENAME = "predicate-handoff-tournament-assessment-audit.json"
SELECTOR_FILENAME = "predicate-handoff-tournament-selection.json"
SELECTORS_FILENAME = "predicate-handoff-tournament-selections.json"
SELECTOR_AUDIT_FILENAME = "predicate-handoff-tournament-selection-audit.json"

PREDICATE_RESOLUTIONS = frozenset(
    {"exactly_resolved", "partially_resolved", "unresolved", "wrong_evidence", "not_applicable"}
)
DOWNSTREAM_RELATIONS = frozenset(
    {"closes_gap", "same_gap_propagated", "independent_branch", "recovered_then_new_failure", "terminal", "uncertain"}
)
HANDOFF_ROLES = frozenset(
    {
        "reasonable_informative_probe",
        "unresolved_predicate_handoff",
        "concrete_local_defect",
        "recovered_defect",
        "faithful_propagation",
        "downstream_symptom",
        "normal_failure_no_handoff",
        "not_applicable",
        "uncertain",
    }
)
WINNER_ROLES = frozenset({"unresolved_predicate_handoff", "concrete_local_defect"})
DECISIONS = frozenset({"keep_anchor", "select_prefix"})
ROW_FIELDS = (
    "step",
    "exact_task_predicate",
    "acquisition_or_interpretation_commitment",
    "observed_outcome",
    "predicate_resolution_after_step",
    "downstream_relation",
    "handoff_role",
    "boundary_verdict",
    "literal_evidence_basis",
    "assessment_falsifier",
)
ASSESSMENT_FIELDS = (
    "rows",
    "decision",
    "selected_step",
    "selected_module",
    "selected_error_type",
    "selected_evidence_quote",
    "selected_root_cause",
    "selected_causal_summary",
    "selected_rejected_adjacent_owner",
    "global_tournament_basis",
    "selection_falsifier",
)
SELECTION_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "anchor_prediction_sha256",
    "anchor_ledger_sha256",
    "anchor_checkpoint_sha256",
    "assessment_sha256",
    "decision",
    "anchor_step",
    "reviewed_steps",
    "selected_step",
    "frozen_step",
    "selected_prediction_sha256",
    "selected_prediction",
    "semantic_assessment",
)


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_79_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_79_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_79_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": (
            "outcome-conditioned exact-predicate handoff tournament over the native v3.20 ledger"
        ),
        "legality_scaffolding_only_migrated": True,
        "step_semantics_unchanged_by_legality_materialization": True,
    }


build_inference_document = legality.build_inference_document
validate_inference_document = legality.validate_inference_document
normalize_anchor_response = legality.normalize_anchor_response
anchor_response_schema = legality.anchor_response_schema
_load_anchor_bundle = legality._load_anchor_bundle
_materialize_owned_prediction = legality._materialize_owned_prediction


def build_anchor_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> str:
    return legality.build_anchor_file_task(
        prediction_manifest_path, cohort_manifest_path
    ).replace(legality.AGENT_JUDGE_LUNA_GAIA_V3_76_VERSION, AGENT_JUDGE_LUNA_GAIA_V3_79_VERSION)


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        legality.validate_anchor_predictions(*paths),
        policy="unchanged_v3_20_anchor_owner_explicit_response_only",
    )


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])


def reducer_response_schema() -> dict[str, Any]:
    row = {
        "type": "object",
        "additionalProperties": False,
        "required": list(ROW_FIELDS),
        "properties": {
            "step": {"type": "integer", "minimum": 1},
            "exact_task_predicate": {"type": "string", "minLength": 1},
            "acquisition_or_interpretation_commitment": {"type": "string", "minLength": 1},
            "observed_outcome": {"type": "string", "minLength": 1},
            "predicate_resolution_after_step": {
                "type": "string", "enum": sorted(PREDICATE_RESOLUTIONS)
            },
            "downstream_relation": {"type": "string", "enum": sorted(DOWNSTREAM_RELATIONS)},
            "handoff_role": {"type": "string", "enum": sorted(HANDOFF_ROLES)},
            "boundary_verdict": {"type": "boolean"},
            "literal_evidence_basis": {"type": "string", "minLength": 1},
            "assessment_falsifier": {"type": "string", "minLength": 1},
        },
    }
    properties: dict[str, Any] = {
        "rows": {"type": "array", "items": row},
        "decision": {"type": "string", "enum": sorted(DECISIONS)},
        "selected_step": {"type": "integer", "minimum": 1},
        "selected_module": {"type": "string", "minLength": 1},
        "selected_error_type": {"type": "string", "minLength": 1},
        "selected_evidence_quote": {"type": "string", "minLength": 1},
        "selected_root_cause": {"type": "string", "minLength": 1},
        "selected_causal_summary": {"type": "string", "minLength": 1},
        "selected_rejected_adjacent_owner": {"type": "string", "minLength": 1},
        "global_tournament_basis": {"type": "string", "minLength": 1},
        "selection_falsifier": {"type": "string", "minLength": 1},
    }
    return {
        "type": "object",
        "additionalProperties": False,
        "required": list(ASSESSMENT_FIELDS),
        "properties": properties,
    }


def build_reducer_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor, ledger = bundle[3:5]
    steps = [int(row["step"]) for row in ledger["rows"]]
    document = build_inference_document(case)
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_79_VERSION}: OUTCOME-CONDITIONED PREDICATE-HANDOFF TOURNAMENT.

RUNTIME CONTRACT — RESPONSE ONLY
- model: {AGENT_JUDGE_LUNA_GAIA_V3_79_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_79_REASONING_EFFORT}
- one isolated case; do not call tools or read any external artifact
- no labels, metrics, old predictions, reports, experiment documents, git history, or identity priors
- return only the response-schema JSON object

BOUNDED TOURNAMENT
- Fresh unchanged-v3.20 anchor Step: {anchor['predicted_step']}.
- Review exactly these native-ledger Steps in order: {json.dumps(steps)}.
- Select exactly one tournament winner from those Steps. Use `keep_anchor` when
  the winner is the anchor and `select_prefix` only for a strict prefix.
- Set `boundary_verdict=true` for exactly the selected winner and false elsewhere.

BENCHMARK CRITICAL-BOUNDARY RULE
- Judge a Step after its actual observable outcome, not only by whether the
  initial probe was reasonable. `reasonable probe` is a prior, not a permanent veto.
- A reasonable acquisition attempt matures into `unresolved_predicate_handoff`
  when the exact requested predicate/source/modality is already identifiable,
  its observed outcome leaves that predicate unresolved or only partially
  resolved, and the subsequent path propagates that same gap through repetition,
  unsupported inference, premature answer, or delayed modality/source repair.
- Such a handoff may be the benchmark boundary even when the Step is not locally
  irrational. The causal fact is that this is the earliest observable outcome
  after which the unresolved exact predicate is handed into the failed path.
- Do NOT promote an initial probe whose outcome is informative and whose next
  state independently advances the predicate; a normal failure followed by a
  prompt effective repair; a recovered defect; faithful propagation of an
  earlier gap; or a vivid downstream symptom.
- A `concrete_local_defect` can also win when it is earlier and path-changing.
- Compare every row globally. Earlier text alone does not win; later severity,
  repetition, and verbosity do not win. Prefer the earliest mature handoff or
  concrete defect whose same unresolved gap explains the later anchor.
- The selected evidence must be an exact substring from selected Step/Module
  `literal_owner_sources`. Module/type never rank Steps.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

OWNER-EXPLICIT COMPLETE JUDGEVIEW
{json.dumps(document, ensure_ascii=False, separators=(',', ':'))}

FRESH DEFAULT ANCHOR PAYLOAD
{json.dumps(anchor, ensure_ascii=False, separators=(',', ':'))}
"""


def _validate_assessment(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != ASSESSMENT_FIELDS:
        shared._fail("invalid_predicate_handoff_assessment_schema", location)
    expected = [int(row["step"]) for row in ledger["rows"]]
    rows = raw["rows"]
    if not isinstance(rows, list) or len(rows) != len(expected):
        shared._fail("incomplete_predicate_handoff_tournament", location)
    winners: list[dict[str, Any]] = []
    for index, (row, step) in enumerate(zip(rows, expected, strict=True)):
        row_location = f"{location}.rows[{index}]"
        if (
            not isinstance(row, dict)
            or tuple(row) != ROW_FIELDS
            or row["step"] != step
            or row["predicate_resolution_after_step"] not in PREDICATE_RESOLUTIONS
            or row["downstream_relation"] not in DOWNSTREAM_RELATIONS
            or row["handoff_role"] not in HANDOFF_ROLES
            or not isinstance(row["boundary_verdict"], bool)
        ):
            shared._fail("invalid_predicate_handoff_row", row_location)
        for field in (
            "exact_task_predicate",
            "acquisition_or_interpretation_commitment",
            "observed_outcome",
            "literal_evidence_basis",
            "assessment_falsifier",
        ):
            shared._nonempty_text(row[field], location=f"{row_location}.{field}", maximum=3200)
        if row["boundary_verdict"]:
            winners.append(row)
    if len(winners) != 1:
        shared._fail("predicate_handoff_winner_not_unique", location)
    selected = raw["selected_step"]
    anchor_step = int(anchor["predicted_step"])
    if selected != winners[0]["step"] or selected not in expected:
        shared._fail("predicate_handoff_selected_step_mismatch", location)
    if winners[0]["handoff_role"] not in WINNER_ROLES:
        shared._fail("predicate_handoff_invalid_winner_role", location)
    if winners[0]["predicate_resolution_after_step"] in {"exactly_resolved", "not_applicable"}:
        shared._fail("predicate_handoff_resolved_winner", location)
    if raw["decision"] == "keep_anchor":
        if selected != anchor_step:
            shared._fail("predicate_handoff_keep_anchor_mismatch", location)
    elif raw["decision"] == "select_prefix":
        if not selected < anchor_step:
            shared._fail("predicate_handoff_prefix_mismatch", location)
    else:
        shared._fail("invalid_predicate_handoff_decision", location)
    for field in (
        "selected_root_cause",
        "selected_causal_summary",
        "selected_rejected_adjacent_owner",
        "global_tournament_basis",
        "selection_falsifier",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3200)
    prediction = _selected_prediction(case, raw)
    if raw["decision"] == "keep_anchor" and prediction != anchor:
        shared._fail("predicate_handoff_keep_not_exact_anchor_copy", location)
    return raw


def normalize_assessment_response(
    response: Any,
    *,
    anchor: dict[str, Any] | None = None,
    ledger: dict[str, Any] | None = None,
    case: Any | None = None,
) -> Any:
    if not isinstance(response, dict) or anchor is None or ledger is None or case is None:
        return response
    value = json.loads(json.dumps(response))
    raw_step = value.get("selected_step")
    if value.get("decision") == "keep_anchor" and raw_step == anchor.get("predicted_step"):
        value.update(
            {
                "selected_module": anchor["predicted_module"],
                "selected_error_type": anchor["predicted_error_type"],
                "selected_evidence_quote": anchor["evidence_quote"],
                "selected_root_cause": anchor["root_cause"],
                "selected_causal_summary": anchor["causal_summary"],
                "selected_rejected_adjacent_owner": anchor["rejected_adjacent_owner"],
            }
        )
    else:
        prediction = {
            "trajectory_id": case.trajectory_id,
            "trajectory_sha256": case.trajectory_sha256,
            "status": "success",
            "predicted_step": raw_step,
            "predicted_module": value.get("selected_module"),
            "predicted_error_type": value.get("selected_error_type"),
            "evidence_quote": value.get("selected_evidence_quote"),
            "root_cause": value.get("selected_root_cause"),
            "causal_summary": value.get("selected_causal_summary"),
            "rejected_adjacent_owner": value.get("selected_rejected_adjacent_owner"),
        }
        materialized = _materialize_owned_prediction(prediction, case=case)
        if materialized.get("predicted_step") != raw_step:
            raise RuntimeError("v3.79 legality materialization changed Step")
        value.update(
            {
                "selected_module": materialized["predicted_module"],
                "selected_error_type": materialized["predicted_error_type"],
                "selected_evidence_quote": materialized["evidence_quote"],
            }
        )
    if value.get("selected_step") != raw_step:
        raise RuntimeError("v3.79 normalization changed model-selected Step")
    return value


def _selected_prediction(case: Any, assessment: dict[str, Any]) -> dict[str, Any]:
    return legality._selected_prediction(case, assessment)


def validate_panel(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    assessment_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(manifest, cohort, anchor_path, ledger_path, checkpoint_path)
    assessment_file, raw = shared._load_artifact(
        assessment_path, role="predicate-handoff tournament assessment"
    )
    assessment = shared._one_record(raw, role="predicate-handoff tournament assessment")
    _validate_assessment(
        assessment, case=case, anchor=bundle[3], ledger=bundle[4], location="assessment[0]"
    )
    inference = validate_inference_document(
        manifest, cohort, assessment_file.parent / INFERENCE_DOCUMENT_FILENAME
    )
    return _retag(
        {
            "schema_version": "agentdebug.predicate-handoff-tournament-assessment-audit.v1",
            "stage": "outcome_conditioned_predicate_handoff_tournament",
            "gold_free_validation": True,
            "case_count": 1,
            "complete_native_ledger_review": True,
            "selected_step": assessment["selected_step"],
            "decision": assessment["decision"],
            "owner_explicit_input": inference,
            "input_sha256": {
                "anchor": shared._file_sha256(bundle[0]),
                "ledger": shared._file_sha256(bundle[1]),
                "checkpoint": shared._file_sha256(bundle[2]),
            },
            "output_sha256": {PANEL_FILENAME: shared._file_sha256(assessment_file)},
        },
        policy="outcome_conditioned_predicate_handoff_tournament",
    )


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_panel(*paths[:-1]), paths[-1])


def build_selection_document(
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    assessment: dict[str, Any],
) -> dict[str, Any]:
    semantic = _validate_assessment(
        assessment, case=case, anchor=anchor, ledger=ledger, location="assessment"
    )
    selected = _selected_prediction(case, semantic)
    return {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "assessment_sha256": shared._stable_sha256(semantic),
        "decision": semantic["decision"],
        "anchor_step": anchor["predicted_step"],
        "reviewed_steps": [row["step"] for row in semantic["rows"]],
        "selected_step": semantic["selected_step"],
        "frozen_step": selected["predicted_step"],
        "selected_prediction_sha256": shared._stable_sha256(selected),
        "selected_prediction": selected,
        "semantic_assessment": semantic,
    }


def validate_selector(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    assessment_path: str | Path,
    selector_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(manifest, cohort, anchor_path, ledger_path, checkpoint_path)
    assessment = shared._one_record(
        shared._load_artifact(assessment_path, role="predicate handoff assessment")[1],
        role="predicate handoff assessment",
    )
    selector_file, raw = shared._load_artifact(selector_path, role="predicate handoff selection")
    selector = shared._one_record(raw, role="predicate handoff selection")
    if not isinstance(selector, dict) or tuple(selector) != SELECTION_FIELDS:
        shared._fail("invalid_predicate_handoff_selection_schema", "selection[0]")
    expected = build_selection_document(
        case=case,
        anchor=bundle[3],
        ledger=bundle[4],
        checkpoint=bundle[5],
        assessment=assessment,
    )
    if selector != expected:
        shared._fail("non_deterministic_predicate_handoff_selection", "selection[0]")
    return _retag(
        {
            "schema_version": "agentdebug.predicate-handoff-tournament-selection-audit.v1",
            "stage": "deterministic_predicate_handoff_selection_binding",
            "gold_free_validation": True,
            "case_count": 1,
            "selected_prediction_exact_copy": True,
            "model_selected_step_preserved": True,
            "output_sha256": {SELECTOR_FILENAME: shared._file_sha256(selector_file)},
        },
        policy="deterministic_predicate_handoff_tournament_selection_copy",
    )


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_selector(*paths[:-1]), paths[-1])


def _validate_aggregate(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(prediction_manifest_path, cohort_manifest_path)
    root = Path(predictions_path).expanduser().resolve().parent
    names = (
        ANCHOR_PREDICTIONS_FILENAME,
        ANCHOR_LEDGER_AGGREGATE_FILENAME,
        ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        PANELS_FILENAME,
        SELECTORS_FILENAME,
    )
    loaded = {name: shared._load_artifact(root / name, role=f"merged {name}")[1] for name in names}
    if any(not isinstance(value, list) or len(value) != len(cases) for value in loaded.values()):
        shared._fail("invalid_predicate_handoff_aggregate_count", "merged artifacts")
    finals = shared._load_artifact(predictions_path, role="merged predictions")[1]
    if not isinstance(finals, list) or len(finals) != len(cases):
        shared._fail("invalid_predicate_handoff_prediction_count", "predictions")
    decisions: Counter[str] = Counter()
    roles: Counter[str] = Counter()
    for index, case in enumerate(cases):
        anchor = shared._validate_prediction_record(
            loaded[ANCHOR_PREDICTIONS_FILENAME][index], case=case, location=f"merged[{index}].anchor"
        )
        ledger = loaded[ANCHOR_LEDGER_AGGREGATE_FILENAME][index]
        checkpoint = loaded[ANCHOR_CHECKPOINT_AGGREGATE_FILENAME][index]
        assessment = loaded[PANELS_FILENAME][index]
        selector = loaded[SELECTORS_FILENAME][index]
        expected = build_selection_document(
            case=case, anchor=anchor, ledger=ledger, checkpoint=checkpoint, assessment=assessment
        )
        if selector != expected or finals[index] != selector["selected_prediction"]:
            shared._fail("predicate_handoff_aggregate_binding_mismatch", f"merged[{index}]")
        decisions[selector["decision"]] += 1
        winner = next(row for row in assessment["rows"] if row["boundary_verdict"])
        roles[winner["handoff_role"]] += 1
    return {
        "required": True,
        "valid": True,
        "complete_native_ledger_review": True,
        "unique_model_selected_winner": True,
        "all_final_steps_model_selected": True,
        "all_final_predictions_exact_selection_copies": True,
        "decision_counts": dict(sorted(decisions.items())),
        "winner_role_counts": dict(sorted(roles.items())),
        "packet_state_closure": parent._validate_packet_state_ledgers(
            root / ANCHOR_LEDGER_AGGREGATE_FILENAME
        ),
    }


def validate_agent_judge_luna_gaia_v3_79_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    aggregate = _validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return _retag(
        {
            **audit,
            "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_79_AUDIT_SCHEMA_VERSION,
            "anchor_semantics_unchanged_from_v3_20": True,
            "owner_explicit_response_only_runtime_required": True,
            "all_selected_predictions_exact_copies": True,
            "predicate_handoff_tournament": aggregate,
        },
        policy="outcome_conditioned_exact_predicate_handoff_tournament",
    )


def validate_and_write_agent_judge_luna_gaia_v3_79_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(
        validate_agent_judge_luna_gaia_v3_79_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_luna_gaia_v3_79_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_reducer_file_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME,
        prediction.parent / ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
    )


validate_and_write_agent_judge_luna_gaia_v3_67_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_79_audit
)
validate_and_write_agent_judge_luna_gaia_v3_37_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_79_audit
)
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_luna_gaia_v3_79_task

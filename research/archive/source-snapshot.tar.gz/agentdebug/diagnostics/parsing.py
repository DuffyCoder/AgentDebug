"""Strict parsers for structured LLM judge output."""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any

from agentdebug.trace import CanonicalTrace

from .judge_view import JudgeStep, JudgeView, build_judge_view
from .models import (
    ModuleFinding,
    ModuleSpecialistResult,
    RootCauseJudgment,
)
from .taxonomy import AgentModule, ErrorType, is_valid_classification


class JudgeOutputError(ValueError):
    """A safe, stage-specific structured-output failure."""

    def __init__(
        self,
        stage: str,
        code: str,
        message: str,
        *,
        raw_output: Any = None,
    ) -> None:
        self.stage = stage
        self.code = code
        self.safe_message = message
        self.raw_output = raw_output
        super().__init__(f"{stage}: {message}")


def _object(raw: Any, stage: str) -> dict[str, Any]:
    value = raw
    if isinstance(raw, str):
        if not raw.strip():
            raise JudgeOutputError(
                stage,
                "empty_response",
                "The judge returned an empty response.",
                raw_output=raw,
            )
        try:
            value = json.loads(raw)
        except json.JSONDecodeError as error:
            raise JudgeOutputError(
                stage,
                "malformed_json",
                (
                    "The judge response is not one strict JSON object "
                    f"(line {error.lineno}, column {error.colno})."
                ),
                raw_output=raw,
            ) from None
    if not isinstance(value, Mapping):
        raise JudgeOutputError(
            stage,
            "invalid_top_level",
            "The judge response must be a JSON object.",
            raw_output=raw,
        )
    return dict(value)


def _check_fields(
    record: Mapping[str, Any],
    *,
    required: set[str],
    optional: set[str],
    stage: str,
    location: str,
    raw_output: Any,
) -> None:
    keys = set(record)
    missing = sorted(required - keys)
    unknown = sorted(keys - required - optional)
    if missing:
        raise JudgeOutputError(
            stage,
            "missing_fields",
            f"{location} is missing required fields: {', '.join(missing)}.",
            raw_output=raw_output,
        )
    if unknown:
        raise JudgeOutputError(
            stage,
            "unknown_fields",
            f"{location} contains unknown fields: {', '.join(unknown)}.",
            raw_output=raw_output,
        )


def _text(
    record: Mapping[str, Any],
    field: str,
    *,
    stage: str,
    location: str,
    raw_output: Any,
) -> str:
    value = record.get(field)
    if not isinstance(value, str) or not value.strip():
        raise JudgeOutputError(
            stage,
            "invalid_field",
            f"{location}.{field} must be a non-empty string.",
            raw_output=raw_output,
        )
    return value


def _classification(
    record: Mapping[str, Any],
    *,
    stage: str,
    location: str,
    raw_output: Any,
) -> tuple[AgentModule, ErrorType]:
    try:
        module = AgentModule(record.get("module"))
    except (TypeError, ValueError):
        raise JudgeOutputError(
            stage,
            "invalid_taxonomy",
            f"{location}.module is not one of the five AgentErrorTaxonomy modules.",
            raw_output=raw_output,
        ) from None
    try:
        error_type = ErrorType(record.get("error_type"))
    except (TypeError, ValueError):
        raise JudgeOutputError(
            stage,
            "invalid_taxonomy",
            f"{location}.error_type is not one of the 17 AgentErrorTaxonomy types.",
            raw_output=raw_output,
        ) from None
    if not is_valid_classification(module, error_type):
        raise JudgeOutputError(
            stage,
            "invalid_taxonomy_pair",
            (
                f"{location} uses error type {error_type.value!r}, which is not "
                f"valid for module {module.value!r}."
            ),
            raw_output=raw_output,
        )
    return module, error_type


def _judge_view(trace: CanonicalTrace | JudgeView) -> JudgeView:
    if isinstance(trace, JudgeView):
        return trace
    if isinstance(trace, CanonicalTrace):
        return build_judge_view(trace)
    raise TypeError("judge output parsing requires CanonicalTrace or JudgeView")


def _step(
    record: Mapping[str, Any],
    field: str,
    *,
    view: JudgeView,
    stage: str,
    location: str,
    raw_output: Any,
) -> JudgeStep:
    value = record.get(field)
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise JudgeOutputError(
            stage,
            "invalid_step",
            f"{location}.{field} must be a positive integer.",
            raw_output=raw_output,
        )
    if value > len(view.steps):
        raise JudgeOutputError(
            stage,
            "unknown_step",
            (
                f"{location}.{field} references step {value}, but the JudgeView "
                f"contains {len(view.steps)} assistant decisions."
            ),
            raw_output=raw_output,
        )
    return view.steps[value - 1]


def _step_evidence_event_ids(step: JudgeStep) -> list[str]:
    """Return observable evidence IDs for one step in stable source order."""

    values: list[str] = [
        *(item.event_id for item in step.current_input),
        step.assistant_event_id,
    ]
    for call in step.tool_calls:
        values.append(call.event_id)
        values.extend(result.event_id for result in call.results)
    values.extend(item.event_id for item in step.adjacent_feedback)
    return list(dict.fromkeys(value for value in values if value))


def parse_specialist(
    raw: Any,
    trace: CanonicalTrace | JudgeView,
    module: AgentModule,
) -> ModuleSpecialistResult:
    """Parse one module specialist's bounded whole-trace findings."""

    if not isinstance(module, AgentModule):
        raise TypeError("specialist parser module must be an AgentModule")
    stage = f"specialist.{module.value}"
    view = _judge_view(trace)
    payload = _object(raw, stage)
    _check_fields(
        payload,
        required={"findings"},
        optional=set(),
        stage=stage,
        location=stage,
        raw_output=raw,
    )
    values = payload["findings"]
    if not isinstance(values, list):
        raise JudgeOutputError(
            stage,
            "invalid_findings",
            f"{stage}.findings must be an array.",
            raw_output=raw,
        )
    maximum = min(6, len(view.steps))
    if len(values) > maximum:
        raise JudgeOutputError(
            stage,
            "invalid_finding_count",
            (
                f"{stage}.findings may contain at most {maximum} findings "
                "for this JudgeView; "
                f"received {len(values)}."
            ),
            raw_output=raw,
        )

    findings: list[ModuleFinding] = []
    seen_steps: set[int] = set()
    required = {
        "step",
        "error_type",
        "evidence",
        "reasoning",
    }
    for index, value in enumerate(values):
        location = f"{stage}.findings[{index}]"
        if not isinstance(value, Mapping):
            raise JudgeOutputError(
                stage,
                "invalid_finding",
                f"{location} must be a JSON object.",
                raw_output=raw,
            )
        record = dict(value)
        _check_fields(
            record,
            required=required,
            optional=set(),
            stage=stage,
            location=location,
            raw_output=raw,
        )
        step = _step(
            record,
            "step",
            view=view,
            stage=stage,
            location=location,
            raw_output=raw,
        )
        if step.step in seen_steps:
            raise JudgeOutputError(
                stage,
                "duplicate_step",
                (
                    f"{location}.step duplicates finding step "
                    f"{step.step}; finding steps must be unique."
                ),
                raw_output=raw,
            )
        seen_steps.add(step.step)
        _, error_type = _classification(
            {
                "module": module.value,
                "error_type": record["error_type"],
            },
            stage=stage,
            location=location,
            raw_output=raw,
        )
        findings.append(
            ModuleFinding(
                step=step.step,
                event_id=step.assistant_event_id,
                module=module,
                error_type=error_type,
                evidence_event_ids=_step_evidence_event_ids(step),
                evidence_quote=_text(
                    record,
                    "evidence",
                    stage=stage,
                    location=location,
                    raw_output=raw,
                ),
                reasoning=_text(
                    record,
                    "reasoning",
                    stage=stage,
                    location=location,
                    raw_output=raw,
                ),
            )
        )
    return ModuleSpecialistResult(module=module, findings=findings)


def parse_root(
    raw: Any,
    trace: CanonicalTrace | JudgeView,
    stage: str,
) -> RootCauseJudgment:
    """Parse a strict arbiter or direct root classification."""

    if not isinstance(stage, str) or not stage.strip():
        raise ValueError("root parser stage must be a non-empty string")
    view = _judge_view(trace)
    payload = _object(raw, stage)
    required = {
        "critical_step",
        "module",
        "error_type",
        "evidence",
        "root_cause",
    }
    _check_fields(
        payload,
        required=required,
        optional=set(),
        stage=stage,
        location=stage,
        raw_output=raw,
    )
    module, error_type = _classification(
        payload,
        stage=stage,
        location=stage,
        raw_output=raw,
    )
    step = _step(
        payload,
        "critical_step",
        view=view,
        stage=stage,
        location=stage,
        raw_output=raw,
    )

    return RootCauseJudgment(
        critical_event_id=step.assistant_event_id,
        critical_step=step.step,
        module=module,
        error_type=error_type,
        root_cause=_text(
            payload,
            "root_cause",
            stage=stage,
            location=stage,
            raw_output=raw,
        ),
        evidence_quote=_text(
            payload,
            "evidence",
            stage=stage,
            location=stage,
            raw_output=raw,
        ),
        evidence_event_ids=_step_evidence_event_ids(step),
    )

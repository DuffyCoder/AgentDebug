"""Gold-free two-proposal debate with a root-precedence exact-copy arbiter.

The two candidates retain the clean debate v1 generation topology.  A fresh
third session reconstructs the trace, compares the two candidates under a
uniform chronological ownership policy, and copies exactly one proposal.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .agent_judge import _assert_safe_path
from .agent_judge_luna_debate_v1 import (
    AGENT_JUDGE_LUNA_DEBATE_V1_VERSION,
    PROPOSAL_A_FILENAME,
    PROPOSAL_B_FILENAME,
    _write_audit,
    build_luna_clean_debate_arbiter_task as _build_v1_arbiter_task,
    build_luna_clean_debate_challenger_task as _build_v1_challenger_task,
    build_luna_clean_debate_draft_task as _build_v1_draft_task,
    validate_luna_clean_debate_challenger_predictions as _validate_v1_challenger,
    validate_luna_clean_debate_draft_predictions as _validate_v1_draft,
)
from .agent_judge_luna_debate_v2 import (
    COMPARISON_FILENAME,
    _comparison_schema,
    validate_luna_clean_debate_v2_predictions as _validate_v2_predictions,
)
from .agent_judge_v2_4 import AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION


AGENT_JUDGE_LUNA_DEBATE_V4_VERSION = (
    "agentdebug.codex-agent-judge.luna-clean-debate-v4"
)
AGENT_JUDGE_LUNA_DEBATE_V4_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_DEBATE_V4_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_DEBATE_V4_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)


def _upgrade_v1_task(task: str) -> str:
    return (
        task.replace(
            AGENT_JUDGE_LUNA_DEBATE_V1_VERSION,
            AGENT_JUDGE_LUNA_DEBATE_V4_VERSION,
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_debate_v1.py",
            "agentdebug/diagnostics/agent_judge_luna_debate_v4.py",
        )
        .replace(
            "agentdebug.diagnostics.agent_judge_luna_debate_v1",
            "agentdebug.diagnostics.agent_judge_luna_debate_v4",
        )
    )


def build_luna_clean_debate_v4_draft_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
) -> str:
    """Keep the clean v1 chronological draft semantics under a new version."""

    return _upgrade_v1_task(
        _build_v1_draft_task(
            prediction_manifest_path,
            cohort_manifest_path,
            proposal_a_path,
        )
    )


def build_luna_clean_debate_v4_challenger_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
    proposal_b_path: str | Path,
) -> str:
    """Keep the clean v1 independent different-step challenger semantics."""

    return _upgrade_v1_task(
        _build_v1_challenger_task(
            prediction_manifest_path,
            cohort_manifest_path,
            proposal_a_path,
            proposal_b_path,
        )
    )


def build_luna_clean_debate_v4_arbiter_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
    proposal_b_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build the uniform root-precedence exact-copy arbitration task."""

    output = Path(predictions_path).expanduser().resolve()
    comparison = output.parent / COMPARISON_FILENAME
    _assert_safe_path(comparison, role="candidate comparison output", is_output=True)
    task = _upgrade_v1_task(
        _build_v1_arbiter_task(
            prediction_manifest_path,
            cohort_manifest_path,
            proposal_a_path,
            proposal_b_path,
            output,
        )
    )
    start = task.index("NEUTRAL BLIND ARBITER ROLE\n")
    end = task.index("STANDALONE SINGLE-LOCAL-FAILURE ADJUDICATION\n", start)
    arbiter = f"""\
STRUCTURED BLIND ROOT-PRECEDENCE ARBITER

Reconstruct every step of the JudgeView before treating anonymous A and B as
two untrusted hypotheses.  Neither proposal is an incumbent, prior result,
label, or source evidence.  Their order, step number, module, and error type
carry no prior weight.  Do not use historical predictions or route on any
module/error-type pair.  Choose exactly A or B; never invent a third step.

Apply this same decision procedure to every trajectory:

1. RAW CHRONOLOGICAL LEDGER.  For each proposed step, verify from the source:
   task constraints; immediately available state; actual previous Action;
   actual observation/tool status; Memory claims; Reflection claims; Plan's
   first required operation; executed Action; and next feedback.  Proposal
   prose is not evidence.
2. PREMISE PROVENANCE.  Locate the first module that introduced the specific
   false premise needed by the later candidate.  A factual state omission,
   false `none/all/no candidate` claim, wrong last-action attribution, or tool-
   outcome misreading in Memory/Reflection dominates a later Plan or Action
   that merely inherits it.  Chronology alone is insufficient: the early text
   must be demonstrably false or decision-material at that time.
3. WITHIN-STEP OWNER.  If a sound Plan first requires verification or another
   operation but Action skips it, contradicts it, or is malformed, Action owns
   the error.  If Memory or Reflection already supplies the false equivalence,
   progress assessment, or state premise used by the Plan, that earlier module
   owns it.  If the Plan itself first authorizes the defective operation and
   Action faithfully executes it, Planning owns it.  Untagged derivation before
   a final answer remains reasoning/Planning; the answer is downstream when it
   only copies that derivation.
4. MATURITY, NOT SALIENCE.  Do not replace an early demonstrated root merely
   with a later clearer repetition, unsupported conclusion, or purchase.  But
   reject an early broad query, first plausible probe, or harmless omission
   that can still obtain discriminating evidence.  Prefer the first concrete
   commitment to a known incompatible target over speculative query wording.
   Distinct untested plausible targets are not automatically repetition.
5. SEARCH-EPOCH CHECK.  Compare normalized objectives, target/filter changes,
   result-set identity, page movement, inspected candidates, and verified
   versus unknown attributes.  Detect strategy-level repetition even when
   wording or sources differ.  Conversely, do not call a newly targeted query
   or a still-uninspected candidate the same failed operation.
6. SYSTEM BOUNDARY.  A directly observed execution limit or tool/environment
   failure defeats a merely speculative earlier inefficiency.  Mutually
   incompatible task constraints are a System/environment candidate before
   judging how Planning resolves them.  An earlier agent error defeats the
   terminal boundary only when its contradiction and causal consequence are
   concrete in the source.
7. COUNTERFACTUAL SELECTION.  For A and B separately, state the smallest local
   correction and whether it would prevent or materially redirect the other
   candidate.  Select the demonstrated causal predecessor.  If independent,
   select the candidate with the stronger contemporaneous contradiction and
   task-level counterfactual; qualifying System boundaries break remaining
   ties.  Never select by vividness or by an `inefficient_plan` default.

First write one JSON object with exactly this schema to:
{comparison}

{json.dumps(_comparison_schema(), ensure_ascii=False, indent=2)}

Use the schema's existing enum values.  `causal_predecessor` covers the premise
provenance and within-step rules; `demonstrated_contradiction` covers direct
state, constraint, or action/plan conflict; `terminal_boundary` covers the
System rule; `stronger_counterfactual` is the final tie-break only.

Then write {output} by copying the selected proposal's entire ten-field record
exactly, with every value unchanged, inside a one-record JSON array.  Do not
rewrite its evidence or taxonomy.  The parent validator rejects a final record
that is not exactly proposal A or proposal B and rejects a missing comparison.

"""
    task = task[:start] + arbiter + task[end:]
    task = task.replace(
        f"- write predictions only to: {output}",
        f"- write candidate comparison only to: {comparison}\n"
        f"- write predictions only to: {output}",
        1,
    )
    return task


def build_luna_clean_debate_v4_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    output = Path(predictions_path).expanduser().resolve()
    return build_luna_clean_debate_v4_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        output.parent / PROPOSAL_A_FILENAME,
        output.parent / PROPOSAL_B_FILENAME,
        output,
    )


def validate_luna_clean_debate_v4_draft_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
) -> dict[str, Any]:
    audit = _validate_v1_draft(
        prediction_manifest_path,
        cohort_manifest_path,
        proposal_a_path,
    )
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_DEBATE_V4_VERSION,
        "proposal_generation_protocol": "clean-debate-v1-chronological-draft",
    }


def validate_luna_clean_debate_v4_challenger_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
    proposal_b_path: str | Path,
) -> dict[str, Any]:
    audit = _validate_v1_challenger(
        prediction_manifest_path,
        cohort_manifest_path,
        proposal_a_path,
        proposal_b_path,
    )
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_DEBATE_V4_VERSION,
        "proposal_generation_protocol": "clean-debate-v1-different-step",
    }


def validate_luna_clean_debate_v4_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = _validate_v2_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_DEBATE_V4_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_DEBATE_V4_VERSION,
        "model": AGENT_JUDGE_LUNA_DEBATE_V4_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_DEBATE_V4_REASONING_EFFORT,
        "proposal_generation_protocol": "clean-debate-v1-fresh-two-proposal",
        "arbiter_protocol": "uniform-root-precedence-exact-copy-v4",
        "gold_free_validation": True,
        "proposal_free_of_historical_predictions": True,
        "label_pair_routing_used": False,
    }


def validate_and_write_luna_clean_debate_draft_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        audit_path,
        validate_luna_clean_debate_v4_draft_predictions(
            prediction_manifest_path,
            cohort_manifest_path,
            proposal_a_path,
        ),
    )


def validate_and_write_luna_clean_debate_challenger_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_b_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    output = Path(proposal_b_path).expanduser().resolve()
    return _write_audit(
        audit_path,
        validate_luna_clean_debate_v4_challenger_predictions(
            prediction_manifest_path,
            cohort_manifest_path,
            output.parent / PROPOSAL_A_FILENAME,
            output,
        ),
    )


def validate_and_write_luna_clean_debate_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        audit_path,
        validate_luna_clean_debate_v4_predictions(
            prediction_manifest_path,
            cohort_manifest_path,
            predictions_path,
        ),
    )


__all__ = [
    "AGENT_JUDGE_LUNA_DEBATE_V4_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_DEBATE_V4_MODEL",
    "AGENT_JUDGE_LUNA_DEBATE_V4_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_DEBATE_V4_VERSION",
    "COMPARISON_FILENAME",
    "PROPOSAL_A_FILENAME",
    "PROPOSAL_B_FILENAME",
    "build_luna_clean_debate_v4_arbiter_task",
    "build_luna_clean_debate_v4_challenger_task",
    "build_luna_clean_debate_v4_draft_task",
    "build_luna_clean_debate_v4_task",
    "validate_luna_clean_debate_v4_challenger_predictions",
    "validate_luna_clean_debate_v4_draft_predictions",
    "validate_luna_clean_debate_v4_predictions",
]

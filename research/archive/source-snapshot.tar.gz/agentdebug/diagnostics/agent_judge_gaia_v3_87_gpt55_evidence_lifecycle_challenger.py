"""GAIA v3.87: accepted v3.83 plus one evidence-grounded lifecycle challenger.

The v3.83 anchor is unchanged.  The only semantic change is that the
later-only Step challenger is replaced by one bidirectional error-instance
search whose lifecycle evidence is explicit and mechanically validated.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_gaia_v3_83_clean_v3p20_model_only_gpt55_medium as parent
from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as packet_parent
from .agent_judge import _file_sha256, _stable_sha256
from .agent_judge_luna_gaia_v3 import STEP_FREEZE_FILENAME
from .agent_judge_luna_gaia_v3_4 import STEP_CANDIDATE_LEDGER_FILENAME
from .taxonomy import taxonomy_prompt


AGENT_JUDGE_GAIA_V3_87_VERSION = (
    "agentdebug.codex-agent-judge.gaia-v3.87-gpt55-evidence-lifecycle-challenger"
)
AGENT_JUDGE_GAIA_V3_87_MODEL = "gpt-5.5"
AGENT_JUDGE_GAIA_V3_87_REASONING_EFFORT = "medium"
AGENT_JUDGE_GAIA_V3_87_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_GAIA_V3_83_AUDIT_SCHEMA_VERSION
)
SEMANTIC_PARENT = parent.AGENT_JUDGE_GAIA_V3_83_VERSION

# Compatibility names consumed by the shared three-stage runner.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_GAIA_V3_87_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_GAIA_V3_87_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_GAIA_V3_87_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_GAIA_V3_87_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = parent.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = parent.CHALLENGERS_FILENAME
ARBITER_FILENAME = parent.ARBITER_FILENAME
ARBITERS_FILENAME = parent.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = parent.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = parent.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME

CHALLENGER_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "anchor_prediction_sha256",
    "anchor_ledger_sha256",
    "anchor_checkpoint_sha256",
    "anchor_step",
    "challenge_status",
    "anchor_classification",
    "anchor_veto_evidence_step",
    "anchor_veto_evidence_quote",
    "lifecycle_status",
    "origin_step",
    "direction",
    "wrong_commitment_quote",
    "obligation_source",
    "obligation_step",
    "obligation_quote",
    "manifestation_step",
    "manifestation_quote",
    "recovery_step",
    "recovery_quote",
    "proposed_prediction",
    "anchor_falsifier",
    "anchor_only_repair_counterfactual",
    "proposal_only_repair_counterfactual",
    "direct_timeline_comparison",
    "search_summary",
)

ARBITER_FIELDS = shared.ARBITER_FIELDS
CHALLENGE_STATUSES = shared.CHALLENGE_STATUSES
ANCHOR_CLASSIFICATIONS = frozenset(
    {
        "critical_root",
        "reasonable_probe",
        "noncritical_predecessor",
        "recovered_defect",
        "downstream_symptom",
        "uncertain",
    }
)
LIFECYCLE_STATUSES = frozenset(
    {
        "none",
        "clean_resolution",
        "costly_resolution",
        "manifest_active",
        "latent_active",
    }
)
DIRECTIONS = frozenset({"none", "earlier", "later"})
LATER_OVERRIDE_CLASSIFICATIONS = frozenset(
    {"reasonable_probe", "noncritical_predecessor", "recovered_defect"}
)


_LIFECYCLE_RULES = """\
EVIDENCE-GROUNDED ERROR-LIFECYCLE SINGLE CHALLENGER

The frozen v3.83 prediction is the incumbent anchor. Keep its ledger and
checkpoint immutable. Independently inspect the COMPLETE trace and construct
at most one error instance, not a flat list of suspicious Steps. The instance
may originate before or after the anchor. The anchor remains the default under
uncertainty.

ERROR INSTANCE CONTRACT

An error instance must bind all of the following with literal evidence:

1. ORIGIN: the Step that owns a concrete wrong commitment, unsupported retained
   state, direct constraint contradiction, or failure-causing Action choice.
   Quote that Step verbatim. A raw tool result is not an Agent-owned origin.
2. OBLIGATION: quote the exact task requirement or an observable trace fact
   that the origin violates. Do not invent requirements from domain knowledge.
3. PROPAGATION: quote a later or same-Step observable manifestation and explain
   how it consumes or faithfully propagates the origin. Group restatements,
   repeated symptoms, and error shifts into this one instance; do not promote
   them as separate roots.
4. RECOVERY: classify the instance using the complete suffix:
   - clean_resolution: later evidence fully corrects state and route with no
     failure-material footprint;
   - costly_resolution: later correction occurs, but the detour observably
     consumes the remaining budget or opportunity needed for task completion;
   - manifest_active: the defect remains active and reaches the failed ending;
   - latent_active: the defect is unrecovered but has no observable footprint
     on this failure.

Only manifest_active or failure-material costly_resolution may challenge.
Clean resolution and latent active are vetoes. Mere inefficiency is not costly
resolution: quote both the recovery and the later budget/opportunity footprint.

CRITICAL-BOUNDARY AND ANCHOR COMPARISON

The proposal must be the origin of the single strongest terminal-relevant
instance whose local repair can change the observed failure path. Prefer the
first wrong commitment on that SAME causal chain, but do not select an earlier
unrelated surface issue merely because it occurs first.

An earlier proposal is legal only when the anchor is a downstream symptom of
that instance. A later proposal is legal only when the anchor is a reasonable
probe, noncritical predecessor, or recovered defect. Quote literal chronology
that falsifies the anchor in anchor_veto_evidence_quote. The proposal must be a
complete legal prediction owned by its origin Step/module.

VETO reasonable initial or materially different probes, normal tool/site
failure, mechanical repair, merely improvable behavior, faithful propagation,
recovered local defects without a terminal footprint, and late symptoms. Do
not infer a causal edge from shared topic, temporal adjacency, severity,
persistence, or strong wording. Do not enumerate alternatives or vote. Emit
no_challenge if any origin, obligation, propagation, recovery, anchor-veto, or
repair claim lacks literal support.
"""


def _retag_parent_task(task: str) -> str:
    marker = parent.AGENT_JUDGE_GAIA_V3_83_VERSION
    if task.count(marker) != 1:
        raise RuntimeError("v3.83 task identity marker changed unexpectedly")
    return (
        task.replace(marker, AGENT_JUDGE_GAIA_V3_87_VERSION, 1)
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_gaia_v3_87_gpt55_evidence_lifecycle_challenger",
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py",
            "agentdebug/diagnostics/agent_judge_gaia_v3_87_gpt55_evidence_lifecycle_challenger.py",
        )
    )


def _boundary(
    *, manifest: Path, cohort: Path, reads: Sequence[Path], output: Path
) -> str:
    return (
        shared._boundary(manifest=manifest, cohort=cohort, reads=reads, output=output)
        .replace(
            f"- model: {shared.AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL}",
            f"- model: {AGENT_JUDGE_GAIA_V3_87_MODEL}",
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_13_conservative_challenger.py",
            "agentdebug/diagnostics/agent_judge_gaia_v3_87_gpt55_evidence_lifecycle_challenger.py",
        )
    )


def _retag_audit(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    result = {key: value for key, value in audit.items() if key != "model_only_swap"}
    return {
        **result,
        "agent_judge_version": AGENT_JUDGE_GAIA_V3_87_VERSION,
        "model": AGENT_JUDGE_GAIA_V3_87_MODEL,
        "reasoning_effort": AGENT_JUDGE_GAIA_V3_87_REASONING_EFFORT,
        "selection_policy": policy,
        "semantic_parent": SEMANTIC_PARENT,
        "direct_semantic_parent": SEMANTIC_PARENT,
        "rejected_lineage_inherited": False,
        "single_major_change": "one evidence-grounded bidirectional error-lifecycle challenger",
    }


def _task_sources(case: Any) -> tuple[str, ...]:
    task = case.judge_view.task
    return tuple(
        value
        for value in (
            getattr(task, "user_request", None),
            getattr(task, "description", None),
            getattr(task, "title", None),
        )
        if isinstance(value, str) and value.strip()
    )


def _valid_step(step: Any, case: Any) -> bool:
    return (
        not isinstance(step, bool)
        and isinstance(step, int)
        and 1 <= step <= len(case.judge_view.steps)
    )


def _literal_quote(
    quote: Any, sources: Sequence[str], *, location: str, maximum: int = 1600
) -> str:
    if (
        not isinstance(quote, str)
        or not quote.strip()
        or len(quote) > maximum
        or not any(quote in source for source in sources)
    ):
        shared._fail("invalid_lifecycle_literal_quote", location)
    return quote


def _validate_challenger_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != CHALLENGER_FIELDS:
        shared._fail("invalid_lifecycle_challenger_schema", f"{location} fields/order differ")
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
    ):
        shared._fail("challenger_identity_mismatch", location)
    bindings = {
        "anchor_prediction_sha256": _stable_sha256(anchor),
        "anchor_ledger_sha256": _stable_sha256(ledger),
        "anchor_checkpoint_sha256": _stable_sha256(checkpoint),
    }
    if any(raw[key] != value for key, value in bindings.items()):
        shared._fail("challenger_anchor_hash_mismatch", location)
    anchor_step = anchor["predicted_step"]
    if raw["anchor_step"] != anchor_step:
        shared._fail("challenger_anchor_step_mismatch", location)
    if raw["challenge_status"] not in CHALLENGE_STATUSES:
        shared._fail("invalid_challenge_status", location)
    if raw["anchor_classification"] not in ANCHOR_CLASSIFICATIONS:
        shared._fail("invalid_anchor_classification", location)
    if raw["lifecycle_status"] not in LIFECYCLE_STATUSES:
        shared._fail("invalid_lifecycle_status", location)
    if raw["direction"] not in DIRECTIONS:
        shared._fail("invalid_lifecycle_direction", location)
    for field in (
        "anchor_falsifier",
        "anchor_only_repair_counterfactual",
        "proposal_only_repair_counterfactual",
        "direct_timeline_comparison",
        "search_summary",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=2400)

    nullable_instance_fields = (
        "anchor_veto_evidence_step",
        "anchor_veto_evidence_quote",
        "origin_step",
        "wrong_commitment_quote",
        "obligation_source",
        "obligation_step",
        "obligation_quote",
        "manifestation_step",
        "manifestation_quote",
        "recovery_step",
        "recovery_quote",
        "proposed_prediction",
    )
    if raw["challenge_status"] == "no_challenge":
        if raw["lifecycle_status"] != "none" or raw["direction"] != "none":
            shared._fail("no_challenge_has_lifecycle_instance", location)
        if any(raw[field] is not None for field in nullable_instance_fields):
            shared._fail("no_challenge_must_not_propose", location)
        return raw

    if raw["lifecycle_status"] not in {"costly_resolution", "manifest_active"}:
        shared._fail("challenge_lifecycle_not_terminal_relevant", location)
    proposal = shared._validate_prediction_record(
        raw["proposed_prediction"], case=case, location=f"{location}.proposal"
    )
    origin_step = raw["origin_step"]
    if not _valid_step(origin_step, case) or proposal["predicted_step"] != origin_step:
        shared._fail("lifecycle_origin_prediction_mismatch", location)
    if origin_step == anchor_step:
        shared._fail("challenger_must_change_step", location)
    expected_direction = "earlier" if origin_step < anchor_step else "later"
    if raw["direction"] != expected_direction:
        shared._fail("lifecycle_direction_mismatch", location)
    if expected_direction == "earlier":
        if raw["anchor_classification"] != "downstream_symptom":
            shared._fail("earlier_challenge_requires_downstream_symptom", location)
    elif raw["anchor_classification"] not in LATER_OVERRIDE_CLASSIFICATIONS:
        shared._fail("later_challenge_lacks_anchor_veto", location)

    veto_step = raw["anchor_veto_evidence_step"]
    if not _valid_step(veto_step, case):
        shared._fail("invalid_anchor_veto_evidence_step", location)
    _literal_quote(
        raw["anchor_veto_evidence_quote"],
        shared._packet_sources(case, veto_step),
        location=f"{location}.anchor_veto_evidence_quote",
    )
    _literal_quote(
        raw["wrong_commitment_quote"],
        shared._packet_sources(case, origin_step),
        location=f"{location}.wrong_commitment_quote",
    )

    obligation_source = raw["obligation_source"]
    obligation_step = raw["obligation_step"]
    if obligation_source == "task":
        if obligation_step is not None:
            shared._fail("task_obligation_has_step", location)
        obligation_sources = _task_sources(case)
    elif obligation_source == "step" and _valid_step(obligation_step, case):
        obligation_sources = shared._packet_sources(case, obligation_step)
    else:
        shared._fail("invalid_obligation_source", location)
    _literal_quote(
        raw["obligation_quote"],
        obligation_sources,
        location=f"{location}.obligation_quote",
    )

    manifestation_step = raw["manifestation_step"]
    if not _valid_step(manifestation_step, case) or manifestation_step < origin_step:
        shared._fail("invalid_manifestation_step", location)
    _literal_quote(
        raw["manifestation_quote"],
        shared._packet_sources(case, manifestation_step),
        location=f"{location}.manifestation_quote",
    )

    recovery_step = raw["recovery_step"]
    recovery_quote = raw["recovery_quote"]
    if raw["lifecycle_status"] == "manifest_active":
        if recovery_step is not None or recovery_quote is not None:
            shared._fail("manifest_active_claims_recovery", location)
    else:
        if (
            not _valid_step(recovery_step, case)
            or recovery_step <= origin_step
            or manifestation_step < recovery_step
        ):
            shared._fail("invalid_costly_resolution_chronology", location)
        _literal_quote(
            recovery_quote,
            shared._packet_sources(case, recovery_step),
            location=f"{location}.recovery_quote",
        )
    return raw


def _validate_arbiter_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    challenger: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != ARBITER_FIELDS:
        shared._fail("invalid_arbiter_schema", f"{location} fields/order differ")
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
    ):
        shared._fail("arbiter_identity_mismatch", location)
    if raw["anchor_prediction_sha256"] != _stable_sha256(anchor):
        shared._fail("arbiter_anchor_hash_mismatch", location)
    if raw["challenger_sha256"] != _stable_sha256(challenger):
        shared._fail("arbiter_challenger_hash_mismatch", location)
    anchor_step = anchor["predicted_step"]
    if raw["anchor_step"] != anchor_step or raw["decision"] not in shared.ARBITER_DECISIONS:
        shared._fail("invalid_arbiter_identity_or_decision", location)
    shared._nonempty_text(raw["decision_basis"], location=f"{location}.decision_basis")
    shared._nonempty_text(
        raw["rejected_alternative_basis"],
        location=f"{location}.rejected_alternative_basis",
    )
    selected = shared._validate_prediction_record(
        raw["selected_prediction"], case=case, location=f"{location}.selected"
    )
    if raw["selected_prediction_sha256"] != _stable_sha256(selected):
        shared._fail("arbiter_selected_prediction_hash_mismatch", location)
    if raw["frozen_step"] != selected["predicted_step"]:
        shared._fail("arbiter_frozen_step_mismatch", location)
    if raw["decision"] == "keep_anchor":
        if selected != anchor or raw["frozen_step"] != anchor_step:
            shared._fail("arbiter_anchor_copy_mismatch", location)
        return raw
    if challenger["challenge_status"] != "challenge":
        shared._fail("arbiter_accepts_missing_challenge", location)
    if selected != challenger["proposed_prediction"]:
        shared._fail("arbiter_challenger_copy_mismatch", location)
    if selected["predicted_step"] == anchor_step:
        shared._fail("arbiter_accepts_equal_step_challenge", location)
    return raw


def build_anchor_task(*paths: str | Path) -> str:
    return _retag_parent_task(parent.build_anchor_task(*paths))


def build_challenger_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    challenger_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    anchor, ledger, checkpoint = shared._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    output = Path(challenger_path).expanduser().resolve()
    shared._assert_safe_path(output, role="challenger output", is_output=True)
    audit = output.parent / CHALLENGER_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_gaia_v3_87_gpt55_evidence_lifecycle_challenger",
            "--compact-validate",
            "challenger",
            manifest,
            cohort,
            anchor_file,
            ledger_file,
            checkpoint_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": _stable_sha256(anchor),
        "anchor_ledger_sha256": _stable_sha256(ledger),
        "anchor_checkpoint_sha256": _stable_sha256(checkpoint),
        "anchor_step": anchor["predicted_step"],
        "challenge_status": "no_challenge or challenge",
        "anchor_classification": (
            "critical_root/reasonable_probe/noncritical_predecessor/"
            "recovered_defect/downstream_symptom/uncertain"
        ),
        "anchor_veto_evidence_step": "integer or null",
        "anchor_veto_evidence_quote": "literal Step packet substring or null",
        "lifecycle_status": (
            "none/clean_resolution/costly_resolution/manifest_active/latent_active"
        ),
        "origin_step": "integer or null",
        "direction": "none/earlier/later",
        "wrong_commitment_quote": "literal origin-Step substring or null",
        "obligation_source": "task/step or null",
        "obligation_step": "integer for step source, else null",
        "obligation_quote": "literal task/Step substring or null",
        "manifestation_step": "integer at or after origin, or null",
        "manifestation_quote": "literal manifestation-Step substring or null",
        "recovery_step": "integer only for costly_resolution, else null",
        "recovery_quote": "literal recovery-Step substring or null",
        "proposed_prediction": "exact ten-field prediction object or null",
        "anchor_falsifier": "compact literal-evidence explanation",
        "anchor_only_repair_counterfactual": "compact counterfactual",
        "proposal_only_repair_counterfactual": "compact counterfactual",
        "direct_timeline_comparison": "anchor-versus-error-instance comparison",
        "search_summary": "one-instance lifecycle search or why none qualifies",
    }
    return f"""\
Run {AGENT_JUDGE_GAIA_V3_87_VERSION} stage 2/3: lifecycle challenger.

{_boundary(manifest=manifest, cohort=cohort, reads=(anchor_file, ledger_file, checkpoint_file), output=output)}

{_LIFECYCLE_RULES}

The frozen anchor Step is {anchor['predicted_step']}. For no_challenge, set
lifecycle_status and direction to `none`, set every lifecycle/veto/proposal
field to null, and explain the complete search in all five text fields. For a
challenge, fill every non-recovery lifecycle field; recovery fields are
required only for costly_resolution and forbidden for manifest_active.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def build_arbiter_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    challenger_path: str | Path,
    arbiter_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    challenger_file, challenger_raw = shared._load_artifact(
        challenger_path, role="lifecycle challenger"
    )
    anchor, ledger, checkpoint = shared._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    challenger = shared._one_record(challenger_raw, role="lifecycle challenger")
    _validate_challenger_record(
        challenger,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        location="challenger[0]",
    )
    output = Path(arbiter_path).expanduser().resolve()
    shared._assert_safe_path(output, role="arbiter output", is_output=True)
    audit = output.parent / ARBITER_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_gaia_v3_87_gpt55_evidence_lifecycle_challenger",
            "--compact-validate",
            "arbiter",
            manifest,
            cohort,
            anchor_file,
            ledger_file,
            checkpoint_file,
            challenger_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": _stable_sha256(anchor),
        "challenger_sha256": _stable_sha256(challenger),
        "anchor_step": anchor["predicted_step"],
        "decision": "keep_anchor or accept_challenger",
        "frozen_step": "selected prediction Step",
        "selected_prediction_sha256": "stable JSON hash of exact selected prediction",
        "selected_prediction": "exact unchanged anchor or challenger prediction object",
        "decision_basis": "literal-evidence lifecycle threshold decision",
        "rejected_alternative_basis": "why the other exact prediction loses",
    }
    return f"""\
Run {AGENT_JUDGE_GAIA_V3_87_VERSION} stage 3/3: independent arbiter.

{_boundary(manifest=manifest, cohort=cohort, reads=(anchor_file, ledger_file, checkpoint_file, challenger_file), output=output)}

{_LIFECYCLE_RULES}

The anchor is the default. Re-read the complete trace and verify every literal
quote and every claimed origin-to-manifestation/recovery edge. Accept only if
the challenger is one terminal-relevant error instance, the direction-specific
anchor classification is proven, and proposal-only repair can change failure.
Shared topic, adjacency, salience, or inefficiency is insufficient. If there
is no challenge or any edge is uncertain, keep_anchor.

selected_prediction must be an exact field-for-field copy of the anchor when
keeping it, or proposed_prediction when accepting. Do not rewrite either or
invent a third prediction. Compute selected_prediction_sha256 as stable sorted
compact JSON content hash of that exact object.

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag_audit(parent.validate_anchor_predictions(*paths), policy="unchanged_v3_83_anchor")


def validate_challenger(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    challenger_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    challenger_file, raw = shared._load_artifact(
        challenger_path, role="lifecycle challenger"
    )
    anchor, ledger, checkpoint = shared._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    packet_parent._validate_packet_state_ledgers(ledger_file)
    record = shared._one_record(raw, role="lifecycle challenger")
    _validate_challenger_record(
        record,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        location="challenger[0]",
    )
    return _retag_audit(
        {
            "schema_version": "agentdebug.evidence-lifecycle-challenger-audit.v1",
            "stage": "challenger",
            "gold_free_validation": True,
            "case_count": 1,
            "challenge_status": record["challenge_status"],
            "challenge_direction": record["direction"],
            "lifecycle_status": record["lifecycle_status"],
            "single_challenger_maximum": True,
            "literal_lifecycle_evidence_required": True,
            "input_sha256": {
                ANCHOR_PREDICTIONS_FILENAME: _file_sha256(anchor_file),
                STEP_CANDIDATE_LEDGER_FILENAME: _file_sha256(ledger_file),
                STEP_FREEZE_FILENAME: _file_sha256(checkpoint_file),
            },
            "output_sha256": {CHALLENGER_FILENAME: _file_sha256(challenger_file)},
        },
        policy="one_evidence_grounded_bidirectional_error_lifecycle_challenger",
    )


def validate_arbiter(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    challenger_path: str | Path,
    arbiter_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    challenger_file, challenger_raw = shared._load_artifact(
        challenger_path, role="lifecycle challenger"
    )
    arbiter_file, arbiter_raw = shared._load_artifact(arbiter_path, role="arbiter")
    anchor, ledger, checkpoint = shared._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    packet_parent._validate_packet_state_ledgers(ledger_file)
    challenger = shared._one_record(challenger_raw, role="lifecycle challenger")
    _validate_challenger_record(
        challenger,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        location="challenger[0]",
    )
    arbiter = shared._one_record(arbiter_raw, role="arbiter")
    _validate_arbiter_record(
        arbiter,
        case=case,
        anchor=anchor,
        challenger=challenger,
        location="arbiter[0]",
    )
    return _retag_audit(
        {
            "schema_version": "agentdebug.evidence-lifecycle-arbiter-audit.v1",
            "stage": "arbiter",
            "gold_free_validation": True,
            "case_count": 1,
            "decision": arbiter["decision"],
            "default_anchor_policy": True,
            "selected_prediction_exact_copy": True,
            "input_sha256": {
                ANCHOR_PREDICTIONS_FILENAME: _file_sha256(anchor_file),
                CHALLENGER_FILENAME: _file_sha256(challenger_file),
            },
            "output_sha256": {ARBITER_FILENAME: _file_sha256(arbiter_file)},
        },
        policy="unchanged_default_keep_exact_copy_arbiter_over_lifecycle_artifact",
    )


def validate_agent_judge_gaia_v3_87_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, cases = shared._load_cases(
        prediction_manifest_path, cohort_manifest_path
    )
    prediction_file = Path(predictions_path).expanduser().resolve()
    base_audit = shared._validate_agent_judge_predictions_with_owner_sources(
        manifest,
        cohort,
        prediction_file,
        owner_source_resolver=shared._luna_gaia_v2_owner_source_resolver,
    )
    anchor_file, anchors = shared._load_artifact(
        prediction_file.parent / ANCHOR_PREDICTIONS_FILENAME, role="merged anchors"
    )
    ledger_file, ledgers = shared._load_artifact(
        prediction_file.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME,
        role="merged anchor ledgers",
    )
    checkpoint_file, checkpoints = shared._load_artifact(
        prediction_file.parent / ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        role="merged anchor checkpoints",
    )
    challenger_file, challengers = shared._load_artifact(
        prediction_file.parent / CHALLENGERS_FILENAME, role="merged lifecycle challengers"
    )
    arbiter_file, arbiters = shared._load_artifact(
        prediction_file.parent / ARBITERS_FILENAME, role="merged arbiters"
    )
    predictions = shared._load_json(prediction_file, role="predictions")
    values = (anchors, ledgers, checkpoints, challengers, arbiters, predictions)
    if any(not isinstance(value, list) or len(value) != len(cases) for value in values):
        shared._fail("invalid_merged_lifecycle_count", "all merged artifacts need all cases")
    packet_state = packet_parent._validate_packet_state_ledgers(ledger_file)
    decisions: list[str] = []
    directions: list[str] = []
    lifecycle_statuses: list[str] = []
    for index, (case, anchor, ledger, checkpoint, challenger, arbiter, prediction) in enumerate(
        zip(cases, anchors, ledgers, checkpoints, challengers, arbiters, predictions, strict=True)
    ):
        location = f"merged[{index}]"
        shared._validate_prediction_record(anchor, case=case, location=f"{location}.anchor")
        if (
            ledger.get("trajectory_id") != case.trajectory_id
            or ledger.get("selected_step") != anchor["predicted_step"]
            or checkpoint.get("trajectory_id") != case.trajectory_id
            or checkpoint.get("predicted_step") != anchor["predicted_step"]
        ):
            shared._fail("merged_anchor_sidecar_mismatch", location)
        _validate_challenger_record(
            challenger,
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            location=f"{location}.challenger",
        )
        _validate_arbiter_record(
            arbiter,
            case=case,
            anchor=anchor,
            challenger=challenger,
            location=f"{location}.arbiter",
        )
        if prediction != arbiter["selected_prediction"]:
            shared._fail("final_prediction_differs_from_arbiter", location)
        decisions.append(arbiter["decision"])
        directions.append(challenger["direction"])
        lifecycle_statuses.append(challenger["lifecycle_status"])
    return _retag_audit(
        {
            **base_audit,
            "schema_version": AGENT_JUDGE_GAIA_V3_87_AUDIT_SCHEMA_VERSION,
            "gold_free_validation": True,
            "case_count": len(cases),
            "anchor_semantics_unchanged_from_v3_83": True,
            "default_keep_exact_copy_arbiter": True,
            "single_challenger_maximum": True,
            "all_selected_predictions_exact_copies": True,
            "packet_state_closure": packet_state,
            "arbiter_decision_counts": {
                value: decisions.count(value) for value in sorted(set(decisions))
            },
            "challenger_direction_counts": {
                value: directions.count(value) for value in sorted(set(directions))
            },
            "lifecycle_status_counts": {
                value: lifecycle_statuses.count(value)
                for value in sorted(set(lifecycle_statuses))
            },
            "input_sidecar_sha256": {
                ANCHOR_PREDICTIONS_FILENAME: _file_sha256(anchor_file),
                ANCHOR_LEDGER_AGGREGATE_FILENAME: _file_sha256(ledger_file),
                ANCHOR_CHECKPOINT_AGGREGATE_FILENAME: _file_sha256(checkpoint_file),
                CHALLENGERS_FILENAME: _file_sha256(challenger_file),
                ARBITERS_FILENAME: _file_sha256(arbiter_file),
            },
        },
        policy=(
            "unchanged_v3_83_anchor_one_evidence_grounded_bidirectional_"
            "error_lifecycle_challenger_default_keep_exact_copy_arbiter"
        ),
    )


def build_agent_judge_gaia_v3_87_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / STEP_CANDIDATE_LEDGER_FILENAME,
        prediction.parent / STEP_FREEZE_FILENAME,
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_gaia_v3_87_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_agent_judge_gaia_v3_87_predictions(*paths[:-1]), paths[-1])


# Compatibility names used by the shared paper-50 runner.
build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_gaia_v3_87_task
validate_agent_judge_luna_gaia_v3_13_predictions = validate_agent_judge_gaia_v3_87_predictions
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_gaia_v3_87_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_gaia_v3_87_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    args = parser.parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "AGENT_JUDGE_GAIA_V3_87_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_GAIA_V3_87_MODEL",
    "AGENT_JUDGE_GAIA_V3_87_REASONING_EFFORT",
    "AGENT_JUDGE_GAIA_V3_87_VERSION",
    "SEMANTIC_PARENT",
    "build_agent_judge_gaia_v3_87_task",
    "build_anchor_task",
    "build_arbiter_task",
    "build_challenger_task",
    "validate_agent_judge_gaia_v3_87_predictions",
    "validate_and_write_agent_judge_gaia_v3_87_audit",
]

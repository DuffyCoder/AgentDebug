"""Luna GAIA v3.44: clean v3.20 plus an independent ballot tournament."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions
from .taxonomy import taxonomy_prompt


AGENT_JUDGE_LUNA_GAIA_V3_44_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.44-clean-v3.20-"
    "provenance-blind-independent-boundary-ballot-tournament"
)
AGENT_JUDGE_LUNA_GAIA_V3_44_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_44_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_44_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases used by the shared full-GAIA runner.
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_44_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_44_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_44_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_44_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_44_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_44_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_44_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
BALLOT_FILENAME = "independent-boundary-ballot.json"
BALLOT_AUDIT_FILENAME = "independent-boundary-ballot-audit.json"
PANEL_FILENAME = "anonymous-candidate-pool.json"
PANELS_FILENAME = "anonymous-candidate-pools.json"
PANEL_AUDIT_FILENAME = "anonymous-candidate-pool-audit.json"
SELECTOR_FILENAME = "provenance-blind-selector.json"
SELECTORS_FILENAME = "provenance-blind-selectors.json"
SELECTOR_AUDIT_FILENAME = "provenance-blind-selector-audit.json"
BALLOT_COUNT = 4
SOURCE_PREDICTION_COUNT = BALLOT_COUNT + 1
MAXIMUM_CANDIDATE_STEPS = SOURCE_PREDICTION_COUNT

BALLOT_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "ballot_index",
    "prediction_sha256",
    "prediction",
    "scan_summary",
    "predicted_semantic_role",
    "admission_certificate",
    "veto_comparison",
    "local_repair_counterfactual",
    "downstream_comparison",
    "falsifier",
)
SOURCE_FIELDS = (
    "source_id",
    "prediction_sha256",
    "prediction",
)
CANDIDATE_FIELDS = (
    "candidate_id",
    "step",
    "support_count",
    "support_prediction_sha256s",
    "representative_prediction_sha256",
    "representative_prediction",
)
POOL_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "source_prediction_count",
    "source_set_sha256",
    "ballot_artifact_set_sha256",
    "source_predictions",
    "candidate_count",
    "candidates",
)
ASSESSMENT_FIELDS = (
    "candidate_id",
    "step",
    "boundary_classification",
    "literal_evidence_assessment",
    "veto_assessment",
    "repair_assessment",
    "timeline_assessment",
)
BOUNDARY_CLASSIFICATIONS = frozenset(
    {
        "mature_critical",
        "reasonable_probe",
        "recovered_or_mechanical",
        "noncritical_predecessor",
        "faithful_or_downstream",
        "ambiguous",
    }
)
SELECTOR_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "pool_sha256",
    "candidate_count",
    "compared_candidate_ids",
    "candidate_assessments",
    "decision",
    "frozen_step",
    "selected_prediction_sha256",
    "selected_prediction",
    "decision_basis",
    "rejected_alternative_basis",
    "selection_falsifier",
)


_BALLOT_RULES = """\
INDEPENDENT FULL-BOUNDARY BALLOT — ONE UNIFORM CONTRACT

You are one of four mutually isolated annotators. You cannot see an anchor,
another ballot, a prior prediction, or candidate provenance. Ballot index is
bookkeeping only and never changes the rules. Inspect every Canonical Step in
chronology before freezing exactly one complete prediction.

Select the first Step where an Agent-owned error is both mature and critical on
the observed continuation. This is not automatically the first local flaw, the
first failed call, the most severe wording, the last visible symptom, or the
first thing that could be improved. Require a literal owner, immediate failed
predicate, observed evidence, task-material path effect, and a local repair.

Apply these vetoes before selection:

- A first or materially different probe capable of producing a necessary
  identifier, page, source, text, value, or lead is reasonable even if it fails.
- A raw tool outcome, normal access failure, tolerated representation, or
  mechanically repairable request shape is not critical when its repair merely
  enables the same probe and a later strategy decision remains independently
  mature.
- A fully recovered defect, harmless state compression, faithful propagation,
  downstream repetition, and terminal restatement cannot own the boundary.
- Repetition becomes mature only after literal prior feedback establishes zero
  contribution and the new commitment adds no material evidence dimension.
- Compare Planning, Action, Memory, and Reflection owners within each Step; a
  raw outcome cannot erase a same-Step Agent commitment.
- Prefer an earlier causal owner over a downstream symptom, but prefer a later
  mature post-feedback commitment over an earlier noncritical predecessor.

scan_summary certifies complete chronology and names the strongest rejected
earlier and later alternatives. admission_certificate states owner, predicate,
literal evidence, task impact, and local repair. veto_comparison applies every
relevant veto. local_repair_counterfactual says what changes if only the chosen
boundary is repaired. downstream_comparison explains why later visible errors
do or do not remain independent. falsifier gives the strongest concrete reason
another Step might instead be the benchmark boundary.
"""


_SELECTOR_RULES = """\
PROVENANCE-BLIND BOUNDED BALLOT TOURNAMENT

The pool contains five anonymous source predictions grouped into at most five
distinct Step candidates. You are not told which source is the clean v3.20
candidate or which candidates came from ballots. Never infer provenance from
style. support_count records agreement but is not a majority-vote rule.

Compare every distinct candidate against the complete trace. For each candidate
record one assessment. Select exactly one representative_prediction already in
the pool; never invent, repair, merge, splice, or change a field.

Use the same benchmark boundary:

1. A candidate wins only with a literal Agent owner, immediate failed
   predicate, observed evidence, task-material path effect, and local repair.
2. Veto reasonable first/different probes, normal failures, recovered defects,
   harmless compression, faithful propagation, and terminal/downstream symptoms.
3. Treat a mechanical predecessor as noncritical when its local repair merely
   enables the same probe and a later post-feedback commitment remains mature.
4. Repetition requires literal prior zero-contribution evidence and no new
   evidence dimension. Capability claims require literal interface or observed
   execution proof, not speculation from the final failure.
5. Prefer the first mature causal boundary, not the earliest local defect or the
   latest persistent symptom. Explicitly compare any earlier predecessor and
   later independently mature commitment.

Candidate order and IDs carry no semantic priority. Assess all IDs exactly once.
selection_falsifier states the strongest concrete case for the best rejected
candidate and why it does not overturn the selected boundary.
"""


def _rewrite_identity(task: str) -> str:
    return task.replace(
        parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        AGENT_JUDGE_LUNA_GAIA_V3_44_VERSION,
    ).replace(
        "agent_judge_luna_gaia_v3_20_packet_state_closure",
        "agent_judge_luna_gaia_v3_44_clean_v3p20_provenance_blind_independent_boundary_ballot_tournament",
    )


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_anchor_task(*paths))


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    audit = dict(parent.validate_anchor_predictions(*paths))
    audit.update(
        agent_judge_version=AGENT_JUDGE_LUNA_GAIA_V3_44_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_44_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_44_REASONING_EFFORT,
    )
    return audit


def _boundary(*, manifest: Path, cohort: Path, reads: Sequence[Path], output: Path) -> str:
    read_lines = "\n".join(f"- {path}" for path in reads) or "- none"
    return f"""\
IMMUTABLE EXECUTION CONFIGURATION
- model: {AGENT_JUDGE_LUNA_GAIA_V3_44_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_44_REASONING_EFFORT}
- one isolated case; fresh session; no cross-case state or prior predictions
- external LLM/API/network calls: forbidden
- scoring or label access: forbidden

INPUT/OUTPUT BOUNDARY
- prediction manifest: {manifest}
- prediction manifest file sha256: {shared._file_sha256(manifest)}
- cohort manifest: {cohort}
- cohort manifest file sha256: {shared._file_sha256(cohort)}
- permitted frozen stage inputs:
{read_lines}
- write the sole stage artifact only to: {output}

Read only those inputs plus this protocol source, the v3.20 protocol source,
and taxonomy.py. Do not inspect directories, names, labels, metrics, scored
artifacts, promotion files, experiments, old predictions, cached replies, case
studies, git history, or external resources.
"""


def _prediction_schema(case: Any) -> dict[str, Any]:
    return {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        "predicted_step": "integer Canonical Step",
        "predicted_module": "legal taxonomy module owned by that Step",
        "predicted_error_type": "legal error type for that module",
        "evidence_quote": "literal evidence inside selected Step/module",
        "root_cause": "local evidence-grounded error",
        "causal_summary": "observed path effect and local repair",
        "rejected_adjacent_owner": "strongest adjacent owner and why rejected",
    }


def _validate_ballot_record(
    raw: Any,
    *,
    case: Any,
    ballot_index: int,
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != BALLOT_FIELDS:
        shared._fail("invalid_independent_ballot_schema", location)
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
        or raw["ballot_index"] != ballot_index
    ):
        shared._fail("independent_ballot_identity_mismatch", location)
    prediction = shared._validate_prediction_record(
        raw["prediction"], case=case, location=f"{location}.prediction"
    )
    if raw["prediction_sha256"] != shared._stable_sha256(prediction):
        shared._fail("independent_ballot_prediction_hash_mismatch", location)
    prefix = (
        "complete_chronology=true; compared_all_steps=true; "
        f"selected_step={prediction['predicted_step']}; "
    )
    if not isinstance(raw["scan_summary"], str) or not raw["scan_summary"].startswith(prefix):
        shared._fail("invalid_independent_ballot_scan_summary", location)
    for field in BALLOT_FIELDS[6:]:
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3000)
    return raw


def validate_ballot(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    ballot_index: int,
    ballot_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    if ballot_index < 1 or ballot_index > BALLOT_COUNT:
        shared._fail("invalid_independent_ballot_index", str(ballot_index))
    ballot_file, raw = shared._load_artifact(ballot_path, role="independent ballot")
    ballot = shared._one_record(raw, role="independent ballot")
    _validate_ballot_record(
        ballot,
        case=case,
        ballot_index=ballot_index,
        location="independent_ballot[0]",
    )
    return {
        "schema_version": "agentdebug.independent-boundary-ballot-audit.v1",
        "stage": "anchor_blind_independent_boundary_ballot",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_44_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_44_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_44_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": 1,
        "ballot_index": ballot_index,
        "anchor_visible": False,
        "prior_ballots_visible": False,
        "complete_prediction_count": 1,
        "input_sha256": {
            "prediction_manifest": shared._file_sha256(manifest),
            "cohort": shared._file_sha256(cohort),
        },
        "output_sha256": {BALLOT_FILENAME: shared._file_sha256(ballot_file)},
    }


def build_ballot_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    ballot_index: int,
    ballot_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    if ballot_index < 1 or ballot_index > BALLOT_COUNT:
        shared._fail("invalid_independent_ballot_index", str(ballot_index))
    output = Path(ballot_path).expanduser().resolve()
    shared._assert_safe_path(output, role="independent ballot output", is_output=True)
    audit = output.parent / BALLOT_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_44_clean_v3p20_provenance_blind_independent_boundary_ballot_tournament",
            "--compact-validate",
            "ballot",
            manifest,
            cohort,
            str(ballot_index),
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "ballot_index": ballot_index,
        "prediction_sha256": "stable sorted compact JSON hash of prediction",
        "prediction": _prediction_schema(case),
        "scan_summary": (
            "complete_chronology=true; compared_all_steps=true; "
            "selected_step=<Step>; strongest earlier/later alternatives"
        ),
        "predicted_semantic_role": "semantic role of the selected boundary",
        "admission_certificate": "literal owner/predicate/evidence/impact/repair",
        "veto_comparison": "probe/recovery/mechanical/propagation/failure checks",
        "local_repair_counterfactual": "effect of repairing only selected boundary",
        "downstream_comparison": "why downstream alternatives lose or remain independent",
        "falsifier": "strongest concrete alternative-boundary argument",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_44_VERSION} independent ballot {ballot_index}/{BALLOT_COUNT}.

{_boundary(manifest=manifest, cohort=cohort, reads=(), output=output)}

{_BALLOT_RULES}

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

The nested prediction must use exactly the shown field order. Compute its hash
as stable sorted compact JSON. After writing, run:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _load_anchor_bundle(
    manifest: Path,
    cohort: Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> tuple[Path, Path, Path, dict[str, Any], dict[str, Any], dict[str, Any]]:
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    anchor, ledger, checkpoint = shared._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    parent._validate_packet_state_ledgers(ledger_file)
    return anchor_file, ledger_file, checkpoint_file, anchor, ledger, checkpoint


def _candidate_groups(
    source_predictions: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    groups: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for source in source_predictions:
        groups[int(source["prediction"]["predicted_step"])].append(source)
    sortable: list[tuple[str, int, list[dict[str, Any]]]] = []
    for step, members in groups.items():
        hashes = sorted(item["prediction_sha256"] for item in members)
        fingerprint = shared._stable_sha256(
            {"step": step, "support_count": len(members), "hashes": hashes}
        )
        sortable.append((fingerprint, step, members))
    result: list[dict[str, Any]] = []
    for candidate_index, (_, step, members) in enumerate(sorted(sortable), start=1):
        representative = min(
            members, key=lambda item: (item["prediction_sha256"], item["source_id"])
        )
        result.append(
            {
                "candidate_id": f"candidate-{candidate_index:02d}",
                "step": step,
                "support_count": len(members),
                "support_prediction_sha256s": sorted(
                    item["prediction_sha256"] for item in members
                ),
                "representative_prediction_sha256": representative[
                    "prediction_sha256"
                ],
                "representative_prediction": representative["prediction"],
            }
        )
    return result


def _pool_from_predictions(
    *,
    case: Any,
    predictions: list[dict[str, Any]],
    ballot_artifact_hashes: list[str],
) -> dict[str, Any]:
    keyed = [
        (shared._stable_sha256(prediction), index, prediction)
        for index, prediction in enumerate(predictions)
    ]
    sources: list[dict[str, Any]] = []
    for source_index, (digest, _, prediction) in enumerate(sorted(keyed), start=1):
        sources.append(
            {
                "source_id": f"source-{source_index:02d}",
                "prediction_sha256": digest,
                "prediction": prediction,
            }
        )
    candidates = _candidate_groups(sources)
    return {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "source_prediction_count": len(sources),
        "source_set_sha256": shared._stable_sha256(
            sorted(item["prediction_sha256"] for item in sources)
        ),
        "ballot_artifact_set_sha256": shared._stable_sha256(
            sorted(ballot_artifact_hashes)
        ),
        "source_predictions": sources,
        "candidate_count": len(candidates),
        "candidates": candidates,
    }


def _validate_pool_record(
    raw: Any,
    *,
    case: Any,
    location: str,
    anchor: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != POOL_FIELDS:
        shared._fail("invalid_anonymous_pool_schema", location)
    if raw["trajectory_id"] != case.trajectory_id or raw["trajectory_sha256"] != case.trajectory_sha256:
        shared._fail("anonymous_pool_identity_mismatch", location)
    if raw["source_prediction_count"] != SOURCE_PREDICTION_COUNT:
        shared._fail("invalid_anonymous_pool_source_count", location)
    sources = raw["source_predictions"]
    if not isinstance(sources, list) or len(sources) != SOURCE_PREDICTION_COUNT:
        shared._fail("invalid_anonymous_pool_sources", location)
    prior_hash = ""
    for index, source in enumerate(sources, start=1):
        if not isinstance(source, dict) or tuple(source) != SOURCE_FIELDS:
            shared._fail("invalid_anonymous_pool_source_schema", f"{location}.source")
        if source["source_id"] != f"source-{index:02d}":
            shared._fail("invalid_anonymous_pool_source_id", f"{location}.source")
        prediction = shared._validate_prediction_record(
            source["prediction"], case=case, location=f"{location}.source[{index}]"
        )
        digest = shared._stable_sha256(prediction)
        if source["prediction_sha256"] != digest or digest < prior_hash:
            shared._fail("invalid_anonymous_pool_source_hash", f"{location}.source")
        prior_hash = digest
    source_hashes = [item["prediction_sha256"] for item in sources]
    if raw["source_set_sha256"] != shared._stable_sha256(sorted(source_hashes)):
        shared._fail("anonymous_pool_source_set_hash_mismatch", location)
    if not isinstance(raw["ballot_artifact_set_sha256"], str) or not re.fullmatch(
        r"[0-9a-f]{64}", raw["ballot_artifact_set_sha256"]
    ):
        shared._fail("invalid_anonymous_pool_ballot_set_hash", location)
    expected_candidates = _candidate_groups(sources)
    if raw["candidates"] != expected_candidates:
        shared._fail("anonymous_pool_candidate_group_mismatch", location)
    if raw["candidate_count"] != len(expected_candidates) or not (
        1 <= raw["candidate_count"] <= MAXIMUM_CANDIDATE_STEPS
    ):
        shared._fail("invalid_anonymous_pool_candidate_count", location)
    for candidate in expected_candidates:
        if tuple(candidate) != CANDIDATE_FIELDS:
            shared._fail("invalid_anonymous_pool_candidate_schema", location)
    if anchor is not None and anchor not in [item["prediction"] for item in sources]:
        shared._fail("anonymous_pool_missing_clean_anchor", location)
    return raw


def build_candidate_pool(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    ballot_paths: Sequence[str | Path],
    pool_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(manifest, cohort, anchor_path, ledger_path, checkpoint_path)
    anchor = bundle[3]
    if len(ballot_paths) != BALLOT_COUNT:
        shared._fail("invalid_candidate_pool_ballot_count", str(len(ballot_paths)))
    ballots: list[dict[str, Any]] = []
    ballot_hashes: list[str] = []
    for index, value in enumerate(ballot_paths, start=1):
        ballot_file, raw = shared._load_artifact(value, role=f"independent ballot {index}")
        ballot = shared._one_record(raw, role=f"independent ballot {index}")
        _validate_ballot_record(
            ballot,
            case=case,
            ballot_index=index,
            location=f"independent_ballot[{index}]",
        )
        ballots.append(ballot)
        ballot_hashes.append(shared._file_sha256(ballot_file))
    pool = _pool_from_predictions(
        case=case,
        predictions=[anchor, *[item["prediction"] for item in ballots]],
        ballot_artifact_hashes=ballot_hashes,
    )
    _validate_pool_record(pool, case=case, location="anonymous_pool[0]", anchor=anchor)
    output = Path(pool_path).expanduser().resolve()
    shared._assert_safe_path(output, role="anonymous candidate pool output", is_output=True)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps([pool], ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return pool


def _validate_assessment(
    raw: Any,
    *,
    candidate: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != ASSESSMENT_FIELDS:
        shared._fail("invalid_candidate_assessment_schema", location)
    if raw["candidate_id"] != candidate["candidate_id"] or raw["step"] != candidate["step"]:
        shared._fail("candidate_assessment_binding_mismatch", location)
    if raw["boundary_classification"] not in BOUNDARY_CLASSIFICATIONS:
        shared._fail("invalid_candidate_boundary_classification", location)
    for field in ASSESSMENT_FIELDS[3:]:
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=2600)
    return raw


def _validate_selector_record(
    raw: Any,
    *,
    case: Any,
    pool: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != SELECTOR_FIELDS:
        shared._fail("invalid_provenance_blind_selector_schema", location)
    if raw["trajectory_id"] != case.trajectory_id or raw["trajectory_sha256"] != case.trajectory_sha256:
        shared._fail("provenance_blind_selector_identity_mismatch", location)
    if raw["pool_sha256"] != shared._stable_sha256(pool) or raw["candidate_count"] != pool["candidate_count"]:
        shared._fail("provenance_blind_selector_pool_binding_mismatch", location)
    candidate_ids = [item["candidate_id"] for item in pool["candidates"]]
    if raw["compared_candidate_ids"] != candidate_ids:
        shared._fail("selector_did_not_compare_all_candidates", location)
    assessments = raw["candidate_assessments"]
    if not isinstance(assessments, list) or len(assessments) != len(candidate_ids):
        shared._fail("invalid_candidate_assessment_count", location)
    for index, (assessment, candidate) in enumerate(
        zip(assessments, pool["candidates"], strict=True)
    ):
        _validate_assessment(
            assessment, candidate=candidate, location=f"{location}.assessment[{index}]"
        )
    options = {item["candidate_id"]: item for item in pool["candidates"]}
    if raw["decision"] not in options:
        shared._fail("invalid_provenance_blind_selector_decision", location)
    selected_candidate = options[raw["decision"]]
    selected = shared._validate_prediction_record(
        raw["selected_prediction"], case=case, location=f"{location}.selected"
    )
    if selected != selected_candidate["representative_prediction"]:
        shared._fail("provenance_blind_selector_copy_mismatch", location)
    if raw["selected_prediction_sha256"] != shared._stable_sha256(selected):
        shared._fail("provenance_blind_selector_hash_mismatch", location)
    if raw["frozen_step"] != selected["predicted_step"]:
        shared._fail("provenance_blind_selector_step_mismatch", location)
    for field in ("decision_basis", "rejected_alternative_basis", "selection_falsifier"):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3200)
    return raw


def validate_selector(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    pool_path: str | Path,
    selector_path: str | Path,
) -> dict[str, Any]:
    _, _, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    pool_file, pool_raw = shared._load_artifact(pool_path, role="anonymous candidate pool")
    pool = shared._one_record(pool_raw, role="anonymous candidate pool")
    _validate_pool_record(pool, case=case, location="anonymous_pool[0]")
    selector_file, selector_raw = shared._load_artifact(
        selector_path, role="provenance-blind selector"
    )
    selector = shared._one_record(selector_raw, role="provenance-blind selector")
    _validate_selector_record(
        selector, case=case, pool=pool, location="provenance_blind_selector[0]"
    )
    return {
        "schema_version": "agentdebug.provenance-blind-selector-audit.v1",
        "stage": "provenance_blind_exact_copy_tournament",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_44_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_44_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_44_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": 1,
        "candidate_count": pool["candidate_count"],
        "decision": selector["decision"],
        "all_candidates_compared": True,
        "selected_prediction_exact_copy": True,
        "candidate_provenance_visible": False,
        "input_sha256": {"pool": shared._file_sha256(pool_file)},
        "output_sha256": {SELECTOR_FILENAME: shared._file_sha256(selector_file)},
    }


def build_selector_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    pool_path: str | Path,
    selector_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    pool_file, pool_raw = shared._load_artifact(pool_path, role="anonymous candidate pool")
    pool = shared._one_record(pool_raw, role="anonymous candidate pool")
    _validate_pool_record(pool, case=case, location="anonymous_pool[0]")
    output = Path(selector_path).expanduser().resolve()
    shared._assert_safe_path(output, role="provenance-blind selector output", is_output=True)
    audit = output.parent / SELECTOR_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_44_clean_v3p20_provenance_blind_independent_boundary_ballot_tournament",
            "--compact-validate",
            "selector",
            manifest,
            cohort,
            pool_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    assessments = [
        {
            "candidate_id": candidate["candidate_id"],
            "step": candidate["step"],
            "boundary_classification": "one allowed classification",
            "literal_evidence_assessment": "owner/predicate/evidence/impact assessment",
            "veto_assessment": "all relevant veto results",
            "repair_assessment": "local-only repair effect",
            "timeline_assessment": "earlier and later candidate comparison",
        }
        for candidate in pool["candidates"]
    ]
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "pool_sha256": shared._stable_sha256(pool),
        "candidate_count": pool["candidate_count"],
        "compared_candidate_ids": [
            candidate["candidate_id"] for candidate in pool["candidates"]
        ],
        "candidate_assessments": assessments,
        "decision": "one existing candidate_id",
        "frozen_step": "chosen candidate Step",
        "selected_prediction_sha256": "stable hash of exact representative prediction",
        "selected_prediction": "exact representative_prediction from chosen candidate",
        "decision_basis": "why selected boundary wins",
        "rejected_alternative_basis": "why every other candidate loses",
        "selection_falsifier": "strongest concrete case for best rejected candidate",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_44_VERSION} provenance-blind selector.

{_boundary(manifest=manifest, cohort=cohort, reads=(pool_file,), output=output)}

{_SELECTOR_RULES}

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

Keep compared_candidate_ids and candidate_assessments in the shown pool order.
Copy the chosen representative_prediction field-for-field. After writing, run:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _validate_aggregate(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(prediction_manifest_path, cohort_manifest_path)
    root = Path(predictions_path).expanduser().resolve().parent
    names = (
        ANCHOR_PREDICTIONS_FILENAME,
        ANCHOR_LEDGER_AGGREGATE_FILENAME,
        ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        PANELS_FILENAME,
        SELECTORS_FILENAME,
    )
    loaded = {
        name: shared._load_artifact(root / name, role=f"merged {name}")[1]
        for name in names
    }
    if any(not isinstance(value, list) or len(value) != len(cases) for value in loaded.values()):
        shared._fail("invalid_ballot_tournament_aggregate_count", "all artifacts need all cases")
    finals = shared._load_artifact(predictions_path, role="merged predictions")[1]
    if not isinstance(finals, list) or len(finals) != len(cases):
        shared._fail("invalid_ballot_tournament_prediction_count", "predictions need all cases")
    candidate_counts: Counter[int] = Counter()
    selected_support_counts: Counter[int] = Counter()
    distinct_source_steps = 0
    for index, case in enumerate(cases):
        anchor = loaded[ANCHOR_PREDICTIONS_FILENAME][index]
        ledger = loaded[ANCHOR_LEDGER_AGGREGATE_FILENAME][index]
        checkpoint = loaded[ANCHOR_CHECKPOINT_AGGREGATE_FILENAME][index]
        pool = loaded[PANELS_FILENAME][index]
        selector = loaded[SELECTORS_FILENAME][index]
        location = f"ballot_tournament_merged[{index}]"
        shared._validate_prediction_record(anchor, case=case, location=f"{location}.anchor")
        if (
            ledger.get("trajectory_id") != case.trajectory_id
            or ledger.get("selected_step") != anchor["predicted_step"]
            or checkpoint.get("trajectory_id") != case.trajectory_id
            or checkpoint.get("predicted_step") != anchor["predicted_step"]
        ):
            shared._fail("ballot_tournament_anchor_sidecar_mismatch", location)
        _validate_pool_record(
            pool, case=case, location=f"{location}.pool", anchor=anchor
        )
        _validate_selector_record(
            selector, case=case, pool=pool, location=f"{location}.selector"
        )
        final = shared._validate_prediction_record(
            finals[index], case=case, location=f"{location}.final"
        )
        if final != selector["selected_prediction"]:
            shared._fail("ballot_tournament_final_copy_mismatch", location)
        selected_candidate = next(
            item for item in pool["candidates"] if item["candidate_id"] == selector["decision"]
        )
        candidate_counts[pool["candidate_count"]] += 1
        selected_support_counts[selected_candidate["support_count"]] += 1
        distinct_source_steps += pool["candidate_count"]
    return {
        "required": True,
        "valid": True,
        "anchor_aware_panel": False,
        "anchor_blind_panel": True,
        "independent_ballot_count": BALLOT_COUNT,
        "source_prediction_count_per_case": SOURCE_PREDICTION_COUNT,
        "maximum_specialist_candidates": BALLOT_COUNT,
        "maximum_total_predictions": MAXIMUM_CANDIDATE_STEPS,
        "candidate_provenance_visible_to_selector": False,
        "all_candidates_compared": True,
        "all_selected_predictions_exact_copies": True,
        "candidate_count_distribution": dict(sorted(candidate_counts.items())),
        "selected_support_count_distribution": dict(
            sorted(selected_support_counts.items())
        ),
        "distinct_candidate_step_total": distinct_source_steps,
        "packet_state_closure": parent._validate_packet_state_ledgers(
            root / ANCHOR_LEDGER_AGGREGATE_FILENAME
        ),
    }


def validate_agent_judge_luna_gaia_v3_44_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    panel = _validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_44_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_44_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_44_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_44_REASONING_EFFORT,
        "selection_policy": "clean_v3_20_provenance_blind_independent_ballot_tournament",
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one provenance-blind independent-boundary ballot tournament",
        "anchor_semantics_unchanged_from_v3_20": True,
        "all_selected_predictions_exact_copies": True,
        "factorized_specialist_panel": panel,
    }


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_ballot_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    ballot_index: int,
    ballot_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_ballot(
            prediction_manifest_path, cohort_manifest_path, ballot_index, ballot_path
        ),
        audit_path,
    )


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_selector(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_44_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_44_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


validate_and_write_agent_judge_luna_gaia_v3_37_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_44_audit
)


def build_agent_judge_luna_gaia_v3_44_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_selector_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / PANEL_FILENAME,
        prediction.parent / SELECTOR_FILENAME,
    )


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_44_task
validate_agent_judge_luna_gaia_v3_13_predictions = validate_agent_judge_luna_gaia_v3_44_predictions
validate_and_write_agent_judge_luna_gaia_v3_13_audit = validate_and_write_agent_judge_luna_gaia_v3_44_audit


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "ballot" and len(paths) == 5:
            audit = validate_and_write_ballot_audit(
                paths[0], paths[1], int(paths[2]), paths[3], paths[4]
            )
        elif stage == "selector" and len(paths) == 5:
            audit = validate_and_write_selector_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_44_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except (shared.AgentJudgeValidationError, ValueError) as error:
        code = getattr(error, "code", "invalid_compact_validation_value")
        print(json.dumps({"ok": False, "code": code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "ballot", "selector", "prediction"))
    parser.add_argument("paths", nargs="+")
    args = parser.parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

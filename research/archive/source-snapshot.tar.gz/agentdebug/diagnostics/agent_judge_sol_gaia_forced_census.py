"""Forced per-step module census followed by one fresh global root arbiter."""

from __future__ import annotations

import json
import os
import shlex
from pathlib import Path
from typing import Any, Mapping, Sequence

from agentdebug.benchmark.prediction_manifest import load_prediction_manifest

from .agent_judge import (
    AgentJudgeValidationError,
    _assert_gold_free,
    _assert_safe_path,
    _execution_fact_lines,
    _file_sha256,
    _load_json,
    _string_leaves,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_sol_gaia_two_stage import CANDIDATE_PROPOSALS_FILENAME
from .judge_view import JudgeView
from .taxonomy import AgentModule, ErrorType, TAXONOMY, is_valid_classification


VERSION = "agentdebug.codex-agent-judge.sol-gaia-forced-census-v1"
MODEL = "gpt-5.6-sol"
REASONING_EFFORT = "high"
AUDIT_SCHEMA_VERSION = "agentdebug.codex-agent-judge-audit.v1"
SPECIALIST_MODULES = tuple(AgentModule)
SPECIALIST_FILENAME = "specialist-census.json"
CENSUS_AUDIT_FILENAME = "specialist-census-audit.json"

_ROW_FIELDS = {"trajectory_id", "trajectory_sha256", "status", "reviews"}
_REVIEW_FIELDS = {
    "step",
    "module",
    "verdict",
    "error_type",
    "evidence_quote",
    "local_analysis",
    "causal_relevance",
    "recovery",
}
_CARD_FIELDS = {
    "step",
    "module",
    "error_type",
    "evidence_quote",
    "local_defect",
    "causal_relevance",
    "recovery",
}
_RECOVERY = {"none", "partial", "complete"}


def _fail(code: str, message: str) -> None:
    raise AgentJudgeValidationError(code, message)


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    temporary.replace(path)


def _write_audit(path: str | Path, value: Mapping[str, Any]) -> dict[str, Any]:
    target = Path(path).expanduser().resolve()
    _assert_safe_path(target, role="audit output", is_output=True)
    _write_json(target, value)
    return dict(value)


def _cohort_ids(path: Path) -> list[str]:
    value = _load_json(path, role="cohort manifest")
    ids = value.get("trajectory_ids") if isinstance(value, Mapping) else None
    if not isinstance(ids, list) or not ids or any(not isinstance(x, str) for x in ids):
        _fail("invalid_census_cohort", "cohort trajectory_ids are invalid")
    return ids


def _subtract_nested(raw: str, start: int, end: int, spans: Sequence[Any]) -> list[str]:
    children = sorted(
        (
            (item.tag_start_char, item.tag_end_char)
            for item in spans
            if item.tag_start_char >= start
            and item.tag_end_char <= end
            and (item.tag_start_char > start or item.tag_end_char < end)
        ),
    )
    top: list[tuple[int, int]] = []
    for child_start, child_end in children:
        if child_start < start or child_end > end or child_end <= child_start:
            continue
        if top and child_end <= top[-1][1]:
            continue
        if top and child_start < top[-1][1]:
            top[-1] = (top[-1][0], max(top[-1][1], child_end))
        else:
            top.append((child_start, child_end))
    pieces: list[str] = []
    cursor = start
    for child_start, child_end in top:
        if cursor < child_start and raw[cursor:child_start].strip():
            pieces.append(raw[cursor:child_start])
        cursor = max(cursor, child_end)
    if cursor < end and raw[cursor:end].strip():
        pieces.append(raw[cursor:end])
    return pieces


def segmented_owner_sources(
    view: JudgeView,
    predicted_step: int,
    module: AgentModule,
    error_type: ErrorType,
) -> tuple[str, ...]:
    """Keep an outer owner's residual text while excluding nested owners."""

    if module == AgentModule.SYSTEM:
        if predicted_step != len(view.steps):
            return ()
        return _execution_fact_lines(view.execution_facts)
    step = view.steps[predicted_step - 1]
    raw = step.assistant_raw_output
    valid = tuple(
        span
        for span in step.module_spans
        if span.tag_start_char >= 0
        and span.tag_end_char > span.tag_start_char
        and span.tag_end_char <= len(raw)
    )
    sources: list[str] = []
    for span in valid:
        if span.module != module.value:
            continue
        sources.extend(
            _subtract_nested(raw, span.tag_start_char, span.tag_end_char, valid)
        )
    if not valid and raw.strip():
        sources.append(raw)
    if module == AgentModule.ACTION:
        for call in step.tool_calls:
            sources.append(call.name)
            sources.extend(_string_leaves(call.arguments))
            sources.extend(_string_leaves(call.partial_arguments))
    return tuple(dict.fromkeys(source for source in sources if source.strip()))


def _source_map(case: Any, module: AgentModule) -> dict[str, list[str]]:
    error_type = next(iter(TAXONOMY[module]))
    return {
        str(index): list(segmented_owner_sources(case.judge_view, index, module, error_type))
        for index in range(1, len(case.judge_view.steps) + 1)
    }


def validate_specialist_census(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    census_path: str | Path,
    module: AgentModule | str,
) -> dict[str, Any]:
    selected = AgentModule(module)
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    census = Path(census_path).expanduser().resolve()
    _, cases = load_prediction_manifest(prediction)
    if _cohort_ids(cohort) != [case.trajectory_id for case in cases]:
        _fail("census_cohort_mismatch", "manifest and cohort differ")
    value = _load_json(census, role="specialist census")
    _assert_gold_free(value, location="specialist census")
    if not isinstance(value, list) or len(value) != len(cases):
        _fail("census_cardinality", "one census row per case required")
    errors = 0
    for case_index, (row, case) in enumerate(zip(value, cases, strict=True)):
        if not isinstance(row, Mapping) or set(row) != _ROW_FIELDS:
            _fail("invalid_census_row", f"invalid row {case_index}")
        if (
            row["trajectory_id"] != case.trajectory_id
            or row["trajectory_sha256"] != case.trajectory_sha256
            or row["status"] != "success"
        ):
            _fail("census_identity", f"invalid identity {case_index}")
        reviews = row["reviews"]
        if not isinstance(reviews, list) or len(reviews) != len(case.judge_view.steps):
            _fail("incomplete_step_census", f"case {case_index} must review every step")
        if [item.get("step") for item in reviews if isinstance(item, Mapping)] != list(
            range(1, len(reviews) + 1)
        ):
            _fail("census_step_order", f"case {case_index} review order is invalid")
        case_errors = 0
        for review in reviews:
            if not isinstance(review, Mapping) or set(review) != _REVIEW_FIELDS:
                _fail("invalid_census_review", f"case {case_index} review fields differ")
            step = review["step"]
            if review["module"] != selected.value:
                _fail("census_module_escape", f"case {case_index} escaped module")
            if not isinstance(review["local_analysis"], str) or not review["local_analysis"].strip():
                _fail("empty_census_analysis", f"case {case_index} analysis is empty")
            sources = segmented_owner_sources(
                case.judge_view, step, selected, next(iter(TAXONOMY[selected]))
            )
            if review["verdict"] in {"no_error", "not_applicable"}:
                if any(review[field] is not None for field in ("error_type", "evidence_quote")):
                    _fail("invalid_negative_review", f"case {case_index} negative fields")
                if review["causal_relevance"] is not None or review["recovery"] is not None:
                    _fail("invalid_negative_review", f"case {case_index} negative metadata")
                if review["verdict"] == "not_applicable" and sources:
                    _fail("incorrect_not_applicable", f"case {case_index} has owner source")
                continue
            if review["verdict"] != "error":
                _fail("invalid_census_verdict", f"case {case_index} verdict is invalid")
            try:
                error_type = ErrorType(review["error_type"])
            except (TypeError, ValueError) as error:
                raise AgentJudgeValidationError("invalid_census_type", str(error)) from error
            if not is_valid_classification(selected, error_type):
                _fail("invalid_census_pair", f"case {case_index} type is illegal")
            for field in ("evidence_quote", "causal_relevance"):
                if not isinstance(review[field], str) or not review[field].strip():
                    _fail("empty_census_error", f"case {case_index} {field} is empty")
            if review["recovery"] not in _RECOVERY:
                _fail("invalid_census_recovery", f"case {case_index} recovery is invalid")
            typed_sources = segmented_owner_sources(case.judge_view, step, selected, error_type)
            if not any(review["evidence_quote"] in source for source in typed_sources):
                _fail("census_evidence_not_found", f"case {case_index} quote is not owned")
            case_errors += 1
        errors += case_errors
    return {
        "schema_version": AUDIT_SCHEMA_VERSION,
        "agent_judge_version": VERSION,
        "stage": f"forced-census-{selected.value}",
        "model": MODEL,
        "reasoning_effort": REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": len(cases),
        "assigned_module": selected.value,
        "all_steps_reviewed_exactly_once": True,
        "error_hypothesis_count": errors,
        "output_sha256": {census.name: _file_sha256(census)},
    }


def validate_and_write_specialist_census_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    census_path: str | Path,
    audit_path: str | Path,
    module: AgentModule | str,
) -> dict[str, Any]:
    return _write_audit(
        audit_path,
        validate_specialist_census(
            prediction_manifest_path, cohort_manifest_path, census_path, module
        ),
    )


def extract_forced_census_candidates(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    census_paths: Sequence[str | Path],
    output_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    if len(census_paths) != len(SPECIALIST_MODULES):
        _fail("incomplete_specialist_set", "exactly five census files required")
    loaded: list[list[dict[str, Any]]] = []
    hashes: dict[str, str] = {}
    for module, raw_path in zip(SPECIALIST_MODULES, census_paths, strict=True):
        path = Path(raw_path).expanduser().resolve()
        validate_specialist_census(
            prediction_manifest_path, cohort_manifest_path, path, module
        )
        loaded.append(_load_json(path, role=f"{module.value} census"))
        hashes[module.value] = _file_sha256(path)
    merged: list[dict[str, Any]] = []
    for index in range(len(loaded[0])):
        identity = loaded[0][index]
        cards = []
        for rows in loaded:
            row = rows[index]
            if row["trajectory_id"] != identity["trajectory_id"]:
                _fail("census_merge_identity", "specialist identities differ")
            for review in row["reviews"]:
                if review["verdict"] != "error":
                    continue
                cards.append(
                    {
                        "step": review["step"],
                        "module": review["module"],
                        "error_type": review["error_type"],
                        "evidence_quote": review["evidence_quote"],
                        "local_defect": review["local_analysis"],
                        "causal_relevance": review["causal_relevance"],
                        "recovery": review["recovery"],
                    }
                )
        cards.sort(key=lambda card: (card["step"], list(AgentModule).index(AgentModule(card["module"]))))
        if not cards:
            _fail("empty_forced_candidate_set", f"case {index} has no candidate")
        merged.append(
            {
                "trajectory_id": identity["trajectory_id"],
                "trajectory_sha256": identity["trajectory_sha256"],
                "status": "success",
                "candidates": cards,
            }
        )
    output = Path(output_path).expanduser().resolve()
    _write_json(output, merged)
    audit = validate_forced_candidates(
        prediction_manifest_path, cohort_manifest_path, output
    )
    return _write_audit(
        audit_path,
        {
            **audit,
            "source_specialist_sha256": hashes,
            "all_candidates_mechanically_extracted": True,
        },
    )


def validate_forced_candidates(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposals_path: str | Path,
) -> dict[str, Any]:
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    proposals = Path(proposals_path).expanduser().resolve()
    _, cases = load_prediction_manifest(prediction)
    if _cohort_ids(cohort) != [case.trajectory_id for case in cases]:
        _fail("forced_candidate_cohort", "manifest and cohort differ")
    rows = _load_json(proposals, role="forced candidates")
    _assert_gold_free(rows, location="forced candidates")
    if not isinstance(rows, list) or len(rows) != len(cases):
        _fail("forced_candidate_cardinality", "one row per case required")
    count = 0
    for index, (row, case) in enumerate(zip(rows, cases, strict=True)):
        if not isinstance(row, Mapping) or set(row) != {
            "trajectory_id", "trajectory_sha256", "status", "candidates"
        }:
            _fail("forced_candidate_fields", f"invalid row {index}")
        if row["trajectory_id"] != case.trajectory_id or row["trajectory_sha256"] != case.trajectory_sha256:
            _fail("forced_candidate_identity", f"invalid row {index}")
        if row["status"] != "success" or not isinstance(row["candidates"], list) or not row["candidates"]:
            _fail("forced_candidate_count", f"invalid row {index}")
        seen = set()
        for card in row["candidates"]:
            if not isinstance(card, Mapping) or set(card) != _CARD_FIELDS:
                _fail("forced_card_fields", f"invalid candidate {index}")
            step = card["step"]
            module = AgentModule(card["module"])
            error_type = ErrorType(card["error_type"])
            key = (step, module.value, error_type.value)
            if key in seen or not 1 <= step <= len(case.judge_view.steps):
                _fail("forced_card_duplicate", f"invalid candidate {index}")
            seen.add(key)
            if not is_valid_classification(module, error_type):
                _fail("forced_card_taxonomy", f"invalid candidate {index}")
            if not any(card["evidence_quote"] in source for source in segmented_owner_sources(case.judge_view, step, module, error_type)):
                _fail("forced_card_evidence", f"invalid candidate {index}")
            if any(not isinstance(card[f], str) or not card[f].strip() for f in ("local_defect", "causal_relevance")):
                _fail("forced_card_text", f"invalid candidate {index}")
            if card["recovery"] not in _RECOVERY:
                _fail("forced_card_recovery", f"invalid candidate {index}")
        count += len(row["candidates"])
    return {
        "schema_version": AUDIT_SCHEMA_VERSION,
        "agent_judge_version": VERSION,
        "stage": "forced-census-candidate-merge",
        "gold_free_validation": True,
        "case_count": len(cases),
        "candidate_count": count,
        "output_sha256": {proposals.name: _file_sha256(proposals)},
    }


def validate_forced_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    predictions = Path(predictions_path).expanduser().resolve()
    proposals = predictions.parent / CANDIDATE_PROPOSALS_FILENAME
    candidate_audit = validate_forced_candidates(
        prediction_manifest_path, cohort_manifest_path, proposals
    )
    base = _validate_agent_judge_predictions_with_owner_sources(
        Path(prediction_manifest_path).expanduser().resolve(),
        Path(cohort_manifest_path).expanduser().resolve(),
        predictions,
        owner_source_resolver=segmented_owner_sources,
    )
    candidates = _load_json(proposals, role="forced candidates")
    finals = _load_json(predictions, role="predictions")
    for index, (row, final) in enumerate(zip(candidates, finals, strict=True)):
        selected = (
            final["predicted_step"], final["predicted_module"],
            final["predicted_error_type"], final["evidence_quote"],
        )
        available = {
            (card["step"], card["module"], card["error_type"], card["evidence_quote"])
            for card in row["candidates"]
        }
        if selected not in available:
            _fail("final_not_forced_candidate", f"final {index} is not proposed")
    return {
        **base,
        "agent_judge_version": VERSION,
        "model": MODEL,
        "reasoning_effort": REASONING_EFFORT,
        "stage": "global-root-arbiter",
        "candidate_count": candidate_audit["candidate_count"],
        "all_finals_exact_frozen_candidates": True,
        "segmented_nested_owner_sources": True,
    }


def validate_and_write_forced_predictions_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        audit_path,
        validate_forced_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
    )


def _validator_command(function: str, *arguments: str) -> str:
    code = (
        "import json; from agentdebug.diagnostics.agent_judge_sol_gaia_forced_census "
        f"import {function} as run; print(json.dumps(run("
        + ", ".join(repr(item) for item in arguments)
        + "), ensure_ascii=False, indent=2))"
    )
    return "PYTHONPATH=. python3 -c " + shlex.quote(code)


def build_specialist_census_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    census_path: str | Path,
    module: AgentModule | str,
) -> str:
    selected = AgentModule(module)
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    output = Path(census_path).expanduser().resolve()
    audit = output.parent / CENSUS_AUDIT_FILENAME
    _, cases = load_prediction_manifest(prediction)
    if len(cases) != 1:
        _fail("specialist_case_count", "specialist requires one case")
    sources = _source_map(cases[0], selected)
    taxonomy = "\n".join(
        f"- {error_type.value}: {definition}"
        for error_type, definition in TAXONOMY[selected].items()
    )
    schema = {
        "trajectory_id": "exact opaque ID",
        "trajectory_sha256": "exact manifest hash",
        "status": "success",
        "reviews": [{
            "step": "each integer 1..N exactly once",
            "module": selected.value,
            "verdict": "error | no_error | not_applicable",
            "error_type": "legal type if error, otherwise null",
            "evidence_quote": "exact owner-source substring if error, otherwise null",
            "local_analysis": "non-empty contemporaneous local analysis",
            "causal_relevance": "non-empty if error, otherwise null",
            "recovery": "none|partial|complete if error, otherwise null",
        }],
    }
    command = _validator_command(
        "validate_and_write_specialist_census_audit",
        str(prediction), str(cohort), str(output), str(audit), selected.value,
    )
    return f"""Run {VERSION}: forced {selected.value.upper()} per-step census.

CONFIG model={MODEL}, reasoning_effort={REASONING_EFFORT}. One isolated trajectory. Network/API/gold/labels/scores/prior predictions/other specialists forbidden. Read only {prediction}, {cohort}, this protocol source, and taxonomy.py. trajectory_id is an opaque join token.

Review EVERY JudgeView step exactly once and ONLY for `{selected.value}`. This is local Phase 1, not root selection. Never omit a local error because it is early, recoverable, less vivid, or probably not the final critical root. Do not compare it against another module or step. Use only information available when the source was written to decide local correctness; later steps may determine recovery.

Verdict rules:
- `not_applicable` only when the deterministic source list for that step is empty.
- `no_error` when the assigned source is locally correct under every assigned type.
- `error` for any concrete false/omitted state, result/progress misread, defective strategy/constraint, action deviation/parameter/emission, or provenance-backed System failure. When uncertain between a plausible local error and no_error, retain the error hypothesis for the global arbiter.
- This is a high-recall census, not a confidence filter, but do not fabricate an error merely to make the specialist non-empty.

DETERMINISTIC VALIDATOR-OWNED SOURCES BY STEP
{json.dumps(sources, ensure_ascii=False, indent=2)}

ASSIGNED TAXONOMY
{taxonomy}

Write exactly one JSON array to {output} matching:
{json.dumps(schema, ensure_ascii=False, indent=2)}
Keep reviews in exact numeric step order. Then run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Fix only this artifact until validation exits zero and writes {audit}.
"""


def build_global_arbiter_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    output = Path(predictions_path).expanduser().resolve()
    proposals = output.parent / CANDIDATE_PROPOSALS_FILENAME
    audit = output.parent / "prediction-audit.json"
    validate_forced_candidates(prediction, cohort, proposals)
    schema = {
        "trajectory_id": "exact opaque ID",
        "trajectory_sha256": "exact manifest hash",
        "status": "success",
        "predicted_step": "selected candidate step",
        "predicted_module": "selected candidate module",
        "predicted_error_type": "selected candidate type",
        "evidence_quote": "copy selected candidate quote exactly",
        "root_cause": "concise root explanation",
        "causal_summary": "propagation/recovery/correction analysis",
        "rejected_adjacent_owner": "strongest challenger and why it loses",
    }
    command = _validator_command(
        "validate_and_write_forced_predictions_audit",
        str(prediction), str(cohort), str(output), str(audit),
    )
    return f"""Run {VERSION}: fresh GLOBAL ROOT ARBITER.

CONFIG model={MODEL}, reasoning_effort={REASONING_EFFORT}. Network/API/gold/labels/scores/prior predictions forbidden. Read only {prediction}, {cohort}, {proposals}, this protocol source, and taxonomy.py. Reconstruct the full JudgeView before comparing the frozen unranked local hypotheses.

Select exactly one proposed step/module/type/evidence tuple. Census cards deliberately have high false-positive rate: they are hypotheses, not votes. Match the benchmark's critical-error boundary:
1. Reject cards that are not locally wrong at that moment.
2. A broad first probe or ordinary uncertainty is normally recoverable exploration. It can win immediately only for a concrete contradiction, fabricated/omitted required state, direct observation misread, explicit constraint violation, malformed/deviating action, or truly unavailable operation.
3. For search/retrieval trajectories, `inefficient_plan` usually matures when negative feedback or an actionable lead makes continuing the same strategy unsupported. Do not require the very last repetition, but do not call every query rewrite a critical repeat.
4. Do not mechanically choose the earliest premise or latest symptom. Prefer the boundary that begins the sustained failed branch used by the released trajectory. A subtle earlier defect loses when later behavior effectively restores its useful state or when correcting it would not prevent an independent mature error.
5. System failures backed by execution facts remain independent candidates and must not be hidden by a merely weak earlier plan. Preserve semantic owner before choosing type.
6. Poor or low-probability acquisition is `inefficient_plan`; reserve `impossible_action` for an interface/capability that truly cannot perform the required operation. Reflection `outcome_misinterpretation` concerns what a result says; `progress_misjudge` concerns whether the task is complete/on track.

Write one ten-field JSON array to {output} matching:
{json.dumps(schema, ensure_ascii=False, indent=2)}
Copy the selected tuple verbatim. Then run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Fix only this artifact until validation exits zero and writes {audit}.
"""


def build_protocol_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    return build_global_arbiter_task(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )


__all__ = [
    "AUDIT_SCHEMA_VERSION", "CANDIDATE_PROPOSALS_FILENAME", "CENSUS_AUDIT_FILENAME",
    "MODEL", "REASONING_EFFORT", "SPECIALIST_FILENAME", "SPECIALIST_MODULES", "VERSION",
    "build_global_arbiter_task", "build_protocol_task", "build_specialist_census_task",
    "extract_forced_census_candidates", "segmented_owner_sources",
    "validate_and_write_forced_predictions_audit", "validate_and_write_specialist_census_audit",
    "validate_forced_candidates", "validate_forced_predictions", "validate_specialist_census",
]

"""Luna GAIA v3.80: v3.79 semantics with Step-invariant taxonomy repair."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge_luna_gaia_v3_79_clean_v3p20_outcome_conditioned_predicate_handoff_tournament import *  # noqa: F403
from . import (
    agent_judge_luna_gaia_v3_79_clean_v3p20_outcome_conditioned_predicate_handoff_tournament as template,
)


shared = template.shared
parent = template.parent
legality = template.legality

AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.80-clean-v3.20-"
    "outcome-conditioned-predicate-handoff-tournament-taxonomy-repair"
)
AGENT_JUDGE_LUNA_GAIA_V3_80_MODEL = template.AGENT_JUDGE_LUNA_GAIA_V3_79_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_80_REASONING_EFFORT = (
    template.AGENT_JUDGE_LUNA_GAIA_V3_79_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_80_AUDIT_SCHEMA_VERSION = (
    template.AGENT_JUDGE_LUNA_GAIA_V3_79_AUDIT_SCHEMA_VERSION
)

AGENT_JUDGE_LUNA_GAIA_V3_79_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_79_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_80_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_79_REASONING_EFFORT = AGENT_JUDGE_LUNA_GAIA_V3_80_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_80_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT = AGENT_JUDGE_LUNA_GAIA_V3_80_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_80_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = AGENT_JUDGE_LUNA_GAIA_V3_80_REASONING_EFFORT


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_80_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_80_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": (
            "outcome-conditioned exact-predicate handoff tournament over the native v3.20 ledger"
        ),
        "runtime_taxonomy_repair_only_from_v3p79": True,
        "selected_step_invariant_taxonomy_materialization": True,
        "legality_scaffolding_only_migrated": True,
        "step_semantics_unchanged_by_legality_materialization": True,
    }


def build_anchor_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> str:
    return template.build_anchor_file_task(
        prediction_manifest_path, cohort_manifest_path
    ).replace(template.AGENT_JUDGE_LUNA_GAIA_V3_79_VERSION, AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION)


def build_reducer_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> str:
    return template.build_reducer_file_task(
        prediction_manifest_path,
        cohort_manifest_path,
        anchor_path,
        ledger_path,
        checkpoint_path,
    ).replace(template.AGENT_JUDGE_LUNA_GAIA_V3_79_VERSION, AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION)


def normalize_assessment_response(
    response: Any,
    *,
    anchor: dict[str, Any] | None = None,
    ledger: dict[str, Any] | None = None,
    case: Any | None = None,
) -> Any:
    raw_step = response.get("selected_step") if isinstance(response, dict) else None
    value = template.normalize_assessment_response(
        response, anchor=anchor, ledger=ledger, case=case
    )
    if not isinstance(value, dict) or anchor is None or ledger is None or case is None:
        return value
    def prediction() -> dict[str, Any]:
        return {
            "trajectory_id": case.trajectory_id,
            "trajectory_sha256": case.trajectory_sha256,
            "status": "success",
            "predicted_step": value.get("selected_step"),
            "predicted_module": value.get("selected_module"),
            "predicted_error_type": value.get("selected_error_type"),
            "evidence_quote": value.get("selected_evidence_quote"),
            "root_cause": value.get("selected_root_cause"),
            "causal_summary": value.get("selected_causal_summary"),
            "rejected_adjacent_owner": value.get("selected_rejected_adjacent_owner"),
        }

    try:
        shared._validate_prediction_record(
            prediction(), case=case, location="v3p80_pre_materialization"
        )
    except Exception:
        try:
            preferred = legality.AgentModule(value.get("selected_module"))
        except (TypeError, ValueError):
            preferred = None
        modules = [preferred] if preferred is not None else []
        modules.extend(
            module
            for module in sorted(legality.AgentModule, key=lambda item: item.value)
            if module != preferred
        )
        repaired = False
        for module in modules:
            for error_type in sorted(
                legality.TAXONOMY[module], key=lambda item: item.value
            ):
                sources = shared._luna_gaia_v2_owner_source_resolver(
                    case.judge_view,
                    int(value["selected_step"]),
                    module,
                    error_type,
                )
                for source in sources:
                    quote = source.strip()[:900]
                    if not quote:
                        continue
                    value.update(
                        {
                            "selected_module": module.value,
                            "selected_error_type": error_type.value,
                            "selected_evidence_quote": quote,
                        }
                    )
                    try:
                        shared._validate_prediction_record(
                            prediction(), case=case, location="v3p80_materialization"
                        )
                    except Exception:
                        continue
                    repaired = True
                    break
                if repaired:
                    break
            if repaired:
                break
        if not repaired:
            raise RuntimeError("v3.80 could not materialize a legal same-Step owner")
    if value.get("selected_step") != raw_step:
        raise RuntimeError("v3.80 taxonomy repair changed model-selected Step")
    return value


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        template.validate_anchor_predictions(*paths),
        policy="unchanged_v3_20_anchor_owner_explicit_response_only",
    )


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_panel(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        template.validate_panel(*paths),
        policy="outcome_conditioned_predicate_handoff_tournament",
    )


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_panel(*paths[:-1]), paths[-1])


def validate_selector(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        template.validate_selector(*paths),
        policy="deterministic_predicate_handoff_tournament_selection_copy",
    )


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_selector(*paths[:-1]), paths[-1])


def validate_agent_judge_luna_gaia_v3_80_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    return _retag(
        template.validate_agent_judge_luna_gaia_v3_79_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        policy=(
            "outcome_conditioned_exact_predicate_handoff_tournament_with_"
            "step_invariant_taxonomy_repair"
        ),
    )


def validate_and_write_agent_judge_luna_gaia_v3_80_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(
        validate_agent_judge_luna_gaia_v3_80_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_luna_gaia_v3_80_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_reducer_file_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,  # noqa: F405
    )


validate_and_write_agent_judge_luna_gaia_v3_79_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_80_audit
)
validate_and_write_agent_judge_luna_gaia_v3_67_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_80_audit
)
validate_and_write_agent_judge_luna_gaia_v3_37_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_80_audit
)
build_agent_judge_luna_gaia_v3_79_task = build_agent_judge_luna_gaia_v3_80_task
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_luna_gaia_v3_80_task


def __getattr__(name: str) -> Any:
    return getattr(template, name)

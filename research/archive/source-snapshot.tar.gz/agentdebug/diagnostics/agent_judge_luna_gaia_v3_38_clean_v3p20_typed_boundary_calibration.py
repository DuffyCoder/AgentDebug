"""Luna GAIA v3.38: clean v3.20 with typed boundary calibration."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from .agent_judge_luna_gaia_v3_4 import STEP_CANDIDATE_LEDGER_FILENAME


AGENT_JUDGE_LUNA_GAIA_V3_38_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.38-clean-v3.20-typed-boundary-calibration"
)
AGENT_JUDGE_LUNA_GAIA_V3_38_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_38_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_38_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_38_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_38_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = AGENT_JUDGE_LUNA_GAIA_V3_38_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_38_AUDIT_SCHEMA_VERSION

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = parent.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = parent.CHALLENGERS_FILENAME
ARBITER_FILENAME = parent.ARBITER_FILENAME
ARBITERS_FILENAME = parent.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = parent.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = parent.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
CHALLENGER_FIELDS = parent.CHALLENGER_FIELDS
ARBITER_FIELDS = parent.ARBITER_FIELDS


_CALIBRATION = """\
TYPED CRITICAL-BOUNDARY CALIBRATION — ONE BINDING PRE-FREEZE COMPARISON

Use the existing chronological ledger and existing lanes; do not create extra
candidates or change the JSON contract. Before selecting its earliest surviving
row, compare all literal candidates in exactly these three mutually exclusive
boundary classes:

1. STATE_TRUTH: the first result-to-Memory/Reflection necessary-fact loss,
   unsupported retained entity/value/relation, or literal outcome/progress
   contradiction that feeds the next decision.
2. STRATEGY_FAMILY_MATURITY: after literal failure or zero task contribution,
   the first recommitment to the same unresolved immediate predicate and the
   same evidence modality/search family without a new evidence dimension. An
   identical URL is not required. A first probe remains clear; a different
   source is not different when it can expose only the same already-failed kind
   of evidence for the same predicate.
3. ALIGNMENT: the first direct plan-to-Action target/tool mismatch or explicit
   user/source/constraint contradiction whose local repair can change the path.

Then freeze the earliest mature task-material boundary across the three, not
the first superficially explicit defect. A later stronger symptom loses to an
earlier state-truth or mature strategy-family boundary. Conversely, a local
source defect, mechanical parameter difference, normal failure, recoverable
defect, or reasonable acquisition probe loses unless its repair averts the
later failure. Static text acquisition is a reasonable probe when it can yield
an identifier, title, source, transcript lead, or contextual term; it is a hard
capability error only when even success cannot contribute to the immediate
subgoal. Protect a direct incumbent boundary when it already owns unrecovered
execution impact or a literal critical constraint.

In every ledger row's existing decision_basis, after the mandatory packet-state
prefix, state `typed_boundary=<state_truth|strategy_family_maturity|alignment|none>;`
and `maturity=<mature|probe|local|recovered|downstream|none>;` before the compact
literal assessment. These tokens are reasoning certificates, not routing keys.

"""


def _rewrite(task: str) -> str:
    return (
        task.replace(parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION, AGENT_JUDGE_LUNA_GAIA_V3_38_VERSION)
        .replace("agent_judge_luna_gaia_v3_20_packet_state_closure", "agent_judge_luna_gaia_v3_38_clean_v3p20_typed_boundary_calibration")
        .replace("agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py", "agentdebug/diagnostics/agent_judge_luna_gaia_v3_38_clean_v3p20_typed_boundary_calibration.py")
    )


def build_anchor_task(*paths: str | Path) -> str:
    task = _rewrite(parent.build_anchor_task(*paths))
    marker = "STRUCTURED STEP-ONLY CANDIDATE LEDGER\n"
    if task.count(marker) != 1:
        raise RuntimeError("v3.20 ledger marker changed")
    task = task.replace(marker, _CALIBRATION + marker, 1)
    task = task.replace(
        "state_fidelity=faithful; compact",
        "state_fidelity=faithful; typed_boundary=none; maturity=none; compact",
    ).replace(
        "state_fidelity=unsupported_fact; compact",
        "state_fidelity=unsupported_fact; typed_boundary=state_truth; maturity=mature; compact",
    )
    return task


def build_challenger_task(*paths: str | Path) -> str:
    return _rewrite(parent.build_challenger_task(*paths))


def build_arbiter_task(*paths: str | Path) -> str:
    return _rewrite(parent.build_arbiter_task(*paths))


def build_agent_judge_luna_gaia_v3_38_task(manifest: str | Path, cohort: str | Path, predictions: str | Path) -> str:
    prediction = Path(predictions).expanduser().resolve()
    return build_arbiter_task(
        manifest, cohort, prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / STEP_CANDIDATE_LEDGER_FILENAME,
        prediction.parent / "step-freeze.json", prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def _identity(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_38_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_38_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_38_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "typed critical-boundary calibration before v3.20 freeze",
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _identity(parent.validate_anchor_predictions(*paths), policy="v3_20_anchor_typed_boundary_calibration")


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    return _identity(parent.validate_challenger(*paths), policy="unchanged_v3_20_challenger_over_typed_calibrated_anchor")


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    return _identity(parent.validate_arbiter(*paths), policy="unchanged_v3_20_default_keep_arbiter")


def validate_agent_judge_luna_gaia_v3_38_predictions(*paths: str | Path) -> dict[str, Any]:
    audit = _identity(parent.validate_agent_judge_luna_gaia_v3_20_predictions(*paths), policy="clean_v3_20_with_typed_boundary_calibration")
    audit["schema_version"] = AGENT_JUDGE_LUNA_GAIA_V3_38_AUDIT_SCHEMA_VERSION
    return audit


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return parent._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_38_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_agent_judge_luna_gaia_v3_38_predictions(*paths[:-1]), paths[-1])


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_38_task
validate_agent_judge_luna_gaia_v3_13_predictions = validate_agent_judge_luna_gaia_v3_38_predictions
validate_and_write_agent_judge_luna_gaia_v3_13_audit = validate_and_write_agent_judge_luna_gaia_v3_38_audit


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_38_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    args = parser.parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

"""Luna GAIA v3.12-global: exhaustive proposals and global step arbitration.

The semantic admission and ownership rules are inherited directly from v3.4.
This version changes only the search topology: a first fresh session produces
an exhaustive local candidate census, a second reviews the complete frozen
pool and selects one global root, and a third binds owner/type/evidence at the
selected step.  Every persisted artifact is validated without loading gold.
"""

from __future__ import annotations

import argparse
import json
import os
import shlex
from pathlib import Path
from typing import Any, Sequence

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_gold_free,
    _assert_safe_path,
    _cohort_document,
    _file_sha256,
    _load_json,
    _stable_sha256,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_luna_gaia_v2 import _luna_gaia_v2_owner_source_resolver
from .agent_judge_luna_gaia_v3_4 import (
    AGENT_JUDGE_LUNA_GAIA_V3_4_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_LUNA_GAIA_V3_4_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_4_REASONING_EFFORT,
)
from .taxonomy import AgentModule, ErrorType, is_valid_classification, taxonomy_prompt


AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.12-global"
)
AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_4_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_4_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_4_AUDIT_SCHEMA_VERSION
)

CANDIDATE_CENSUS_FILENAME = "candidate-census.json"
GLOBAL_SELECTION_FILENAME = "global-selection.json"
CENSUS_AUDIT_FILENAME = "candidate-census-audit.json"
SELECTION_AUDIT_FILENAME = "global-selection-audit.json"
PREDICTION_AUDIT_FILENAME = "prediction-audit.json"

MODULE_ORDER = tuple(module.value for module in AgentModule)
CENSUS_RECORD_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "rows",
    "candidates",
)
CENSUS_ROW_FIELDS = ("step", *MODULE_ORDER)
CANDIDATE_FIELDS = (
    "candidate_id",
    "step",
    "module",
    "error_type",
    "evidence_quote",
    "candidate_strength",
    "defect_predicate",
    "smallest_correction",
    "recovery_state",
    "failure_link",
    "analysis",
)
CENSUS_STATUSES = frozenset({"clear", "candidate"})
CANDIDATE_STRENGTHS = frozenset({"concrete", "plausible"})
RECOVERY_STATES = frozenset({"unrecovered", "recovered", "unclear"})

SELECTION_RECORD_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "candidate_pool_sha256",
    "reviews",
    "selected_candidate_id",
    "selected_candidate_sha256",
)
REVIEW_FIELDS = (
    "candidate_id",
    "locally_valid",
    "outcome_material",
    "recovery_state",
    "causal_role",
    "analysis",
)
YES_NO = frozenset({"yes", "no"})
CAUSAL_ROLES = frozenset(
    {
        "critical_root",
        "noncritical_predecessor",
        "downstream_symptom",
        "uncertain",
    }
)


_V3_4_SEMANTICS = """\
FROZEN v3.4 SEMANTICS (SEARCH TOPOLOGY EXCEPTED)

Build the task checklist from literal task requirements and observations.
Treat a local output as a candidate only under the existing v3.4 rules:

- Memory owns invented, omitted, or oversimplified prior state. Reflection
  owns a false reading of outcome, progress, or cause. Planning owns a bad
  strategy, target, constraint, prerequisite, capability assumption, repeated
  strategy, or premature abandonment. Action owns plan deviation, unavailable
  operation, invalid syntax, or mechanical argument error.
- Tool availability is not capability. Required corpus and evidence modality
  must actually be exposable by the planned tool. Preserve v3.4's distinctions
  among dynamic video, database UI state, static page/PDF text, arithmetic,
  and academic corpora.
- Close each step packet before the next step. System is a candidate only for
  a literal adjacent external execution exception after a well-formed request,
  or a provenance-backed final execution fact. Normal empty/no-match output,
  raw PDF bytes, ordinary access-denied content, uninformative pages, and
  agent-caused arguments are not System.
- The first reasonable probe and a materially different probe are not errors.
  A repeat candidate needs recommitment to the same normalized unresolved
  subgoal/source/modality/target after contrary or uninformative feedback.
- Preserve v3.4's narrow recovery vetoes: fully repaired mechanical Action,
  initial/different reasonable probe, and exploratory query superseded by the
  first terminal premature abandonment. Do not invent a broad recovery rule.
- A candidate must identify an independently defective owner output, not a
  merely improvable choice, failed result, faithful propagation, or downstream
  symptom. The local type is provisional but must be legal for that owner.

The sole semantic-topology change is that no local candidate freezes the
step. Continue through every module of every step and persist every plausible
or concrete candidate. Do not select a root in the census stage.
"""


_GLOBAL_SELECTION_RULES = """\
GLOBAL ROOT SELECTION

Review every frozen candidate against the complete trajectory. Do not add,
delete, edit, or silently merge candidates. For each candidate separately ask:

1. Is its owner output locally defective under the frozen v3.4 semantics?
2. Could correcting that output alone materially change the failed outcome?
3. Was the exact defect later fully repaired or did its causal state persist?
4. Is it the critical root, a noncritical predecessor, or a downstream symptom?

Then select one candidate marked locally_valid=yes, outcome_material=yes,
recovery_state=unrecovered, and causal_role=critical_root. Compare the full
causal chain; neither the earliest candidate nor the most salient late symptom
wins mechanically. The selected step is immutable after this stage.
"""


def _fail(code: str, message: str) -> None:
    raise AgentJudgeValidationError(code, message)


def _nonempty_text(value: Any, *, location: str, maximum: int = 1600) -> None:
    if not isinstance(value, str) or not value.strip() or len(value) > maximum:
        _fail("invalid_global_artifact_text", f"{location} must be compact text")


def _load_cases(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> tuple[Path, Path, list[Any]]:
    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    cohort_path = Path(cohort_manifest_path).expanduser().resolve()
    _assert_safe_path(manifest_path, role="prediction manifest")
    _assert_safe_path(cohort_path, role="cohort manifest")
    from agentdebug.benchmark.prediction_manifest import (  # noqa: PLC0415
        PredictionManifestError,
        load_prediction_manifest,
    )

    try:
        manifest, cases = load_prediction_manifest(manifest_path)
    except PredictionManifestError as error:
        _fail("invalid_prediction_manifest", str(error))
    cohort = _cohort_document(cohort_path)
    if [case.trajectory_id for case in cases] != cohort["trajectory_ids"]:
        _fail("manifest_cohort_order_mismatch", "manifest and cohort order differ")
    if (
        manifest.get("cohort_name") != cohort.get("cohort_name")
        or manifest.get("cohort_sha256") != cohort.get("cohort_sha256")
        or manifest.get("dataset_manifest_sha256")
        != cohort.get("dataset_manifest_sha256")
    ):
        _fail(
            "manifest_cohort_identity_mismatch",
            "manifest and cohort public identities differ",
        )
    return manifest_path, cohort_path, cases


def _load_artifact(path: str | Path, *, role: str) -> tuple[Path, Any]:
    target = Path(path).expanduser().resolve()
    _assert_safe_path(target, role=role)
    value = _load_json(target, role=role)
    _assert_gold_free(value, location=role)
    return target, value


def _candidate_id(step: int, module: str) -> str:
    return f"C-{step:04d}-{module}"


def _candidate_sources(case: Any, candidate: dict[str, Any]) -> tuple[str, ...]:
    return _luna_gaia_v2_owner_source_resolver(
        case.judge_view,
        candidate["step"],
        AgentModule(candidate["module"]),
        ErrorType(candidate["error_type"]),
    )


def _validate_census_record(raw: Any, case: Any, *, location: str) -> None:
    if not isinstance(raw, dict) or tuple(raw) != CENSUS_RECORD_FIELDS:
        _fail("invalid_candidate_census_schema", f"{location} has wrong fields/order")
    if raw["trajectory_id"] != case.trajectory_id:
        _fail("candidate_census_identity_mismatch", f"{location} trajectory differs")
    if raw["trajectory_sha256"] != case.trajectory_sha256:
        _fail("candidate_census_sha256_mismatch", f"{location} SHA differs")

    rows = raw["rows"]
    if not isinstance(rows, list) or len(rows) != len(case.judge_view.steps):
        _fail(
            "candidate_census_not_exhaustive",
            f"{location}.rows must cover every trajectory step",
        )
    marked: list[str] = []
    for step_number, row in enumerate(rows, start=1):
        row_location = f"{location}.rows[{step_number - 1}]"
        if not isinstance(row, dict) or tuple(row) != CENSUS_ROW_FIELDS:
            _fail("invalid_candidate_census_row", f"{row_location} fields/order differ")
        if row["step"] != step_number:
            _fail("candidate_census_step_order", f"{row_location} step is not consecutive")
        for module in MODULE_ORDER:
            if row[module] not in CENSUS_STATUSES:
                _fail("invalid_candidate_census_status", f"{row_location}.{module}")
            if row[module] == "candidate":
                marked.append(_candidate_id(step_number, module))

    candidates = raw["candidates"]
    if not isinstance(candidates, list) or not candidates:
        _fail("empty_candidate_census", f"{location} must contain a candidate")
    observed_ids: list[str] = []
    for index, candidate in enumerate(candidates):
        item_location = f"{location}.candidates[{index}]"
        if not isinstance(candidate, dict) or tuple(candidate) != CANDIDATE_FIELDS:
            _fail("invalid_candidate_schema", f"{item_location} fields/order differ")
        step = candidate["step"]
        module_value = candidate["module"]
        if (
            isinstance(step, bool)
            or not isinstance(step, int)
            or step < 1
            or step > len(rows)
            or module_value not in MODULE_ORDER
        ):
            _fail("invalid_candidate_location", f"{item_location} step/module is invalid")
        expected_id = _candidate_id(step, module_value)
        if candidate["candidate_id"] != expected_id:
            _fail("invalid_candidate_id", f"{item_location} ID must be {expected_id}")
        observed_ids.append(expected_id)
        try:
            module = AgentModule(module_value)
            error_type = ErrorType(candidate["error_type"])
        except (TypeError, ValueError):
            _fail("invalid_candidate_taxonomy", f"{item_location} taxonomy is unknown")
        if not is_valid_classification(module, error_type):
            _fail("invalid_candidate_taxonomy", f"{item_location} taxonomy pair is illegal")
        if candidate["candidate_strength"] not in CANDIDATE_STRENGTHS:
            _fail("invalid_candidate_strength", item_location)
        if candidate["recovery_state"] not in RECOVERY_STATES:
            _fail("invalid_candidate_recovery", item_location)
        for field in (
            "evidence_quote",
            "defect_predicate",
            "smallest_correction",
            "failure_link",
            "analysis",
        ):
            _nonempty_text(candidate[field], location=f"{item_location}.{field}")
        sources = _candidate_sources(case, candidate)
        if not sources or not any(candidate["evidence_quote"] in source for source in sources):
            _fail(
                "invalid_candidate_evidence_ownership",
                f"{item_location}.evidence_quote is not owned by step/module",
            )
    if len(observed_ids) != len(set(observed_ids)):
        _fail("duplicate_candidate_id", f"{location} has duplicate step/module candidates")
    if observed_ids != marked:
        _fail(
            "candidate_census_mapping_mismatch",
            f"{location} rows and candidates must match in step/module order",
        )


def validate_candidate_census(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    census_path: str | Path,
) -> dict[str, Any]:
    manifest_path, cohort_path, cases = _load_cases(
        prediction_manifest_path, cohort_manifest_path
    )
    artifact_path, raw = _load_artifact(census_path, role="candidate census")
    if not isinstance(raw, list) or len(raw) != len(cases):
        _fail("invalid_candidate_census_count", "census must match complete cohort")
    for index, (record, case) in enumerate(zip(raw, cases, strict=True)):
        _validate_census_record(record, case, location=f"candidate_census[{index}]")
    return {
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_VERSION,
        "stage": "candidate_census",
        "model": AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": len(cases),
        "complete_step_census": True,
        "candidate_count": sum(len(record["candidates"]) for record in raw),
        "input_sha256": {
            "prediction_manifest": _file_sha256(manifest_path),
            "cohort": _file_sha256(cohort_path),
        },
        "output_sha256": {CANDIDATE_CENSUS_FILENAME: _file_sha256(artifact_path)},
    }


def _census_by_id(raw: Any, cases: list[Any]) -> dict[str, dict[str, Any]]:
    if not isinstance(raw, list) or len(raw) != len(cases):
        _fail("invalid_candidate_census_count", "census must match complete cohort")
    result: dict[str, dict[str, Any]] = {}
    for index, (record, case) in enumerate(zip(raw, cases, strict=True)):
        _validate_census_record(record, case, location=f"candidate_census[{index}]")
        result[case.trajectory_id] = record
    return result


def _validate_selection_record(
    raw: Any,
    case: Any,
    census: dict[str, Any],
    *,
    location: str,
) -> None:
    if not isinstance(raw, dict) or tuple(raw) != SELECTION_RECORD_FIELDS:
        _fail("invalid_global_selection_schema", f"{location} has wrong fields/order")
    if raw["trajectory_id"] != case.trajectory_id:
        _fail("global_selection_identity_mismatch", f"{location} trajectory differs")
    if raw["trajectory_sha256"] != case.trajectory_sha256:
        _fail("global_selection_sha256_mismatch", f"{location} trajectory SHA differs")
    if raw["candidate_pool_sha256"] != _stable_sha256(census):
        _fail("candidate_pool_sha256_mismatch", f"{location} changed the census")
    candidates = census["candidates"]
    candidate_map = {item["candidate_id"]: item for item in candidates}
    reviews = raw["reviews"]
    if not isinstance(reviews, list) or len(reviews) != len(candidates):
        _fail("global_selection_not_exhaustive", f"{location} must review every candidate")
    review_map: dict[str, dict[str, Any]] = {}
    for index, (review, candidate) in enumerate(zip(reviews, candidates, strict=True)):
        item_location = f"{location}.reviews[{index}]"
        if not isinstance(review, dict) or tuple(review) != REVIEW_FIELDS:
            _fail("invalid_candidate_review_schema", f"{item_location} fields/order differ")
        if review["candidate_id"] != candidate["candidate_id"]:
            _fail("candidate_review_order_mismatch", f"{item_location} candidate differs")
        if review["locally_valid"] not in YES_NO or review["outcome_material"] not in YES_NO:
            _fail("invalid_candidate_review_boolean", item_location)
        if review["recovery_state"] not in RECOVERY_STATES:
            _fail("invalid_candidate_review_recovery", item_location)
        if review["causal_role"] not in CAUSAL_ROLES:
            _fail("invalid_candidate_causal_role", item_location)
        _nonempty_text(review["analysis"], location=f"{item_location}.analysis")
        review_map[review["candidate_id"]] = review

    selected_id = raw["selected_candidate_id"]
    if selected_id not in candidate_map:
        _fail("unknown_selected_candidate", f"{location} selection is absent from census")
    selected = candidate_map[selected_id]
    if raw["selected_candidate_sha256"] != _stable_sha256(selected):
        _fail("selected_candidate_sha256_mismatch", f"{location} selected hash differs")
    review = review_map[selected_id]
    if (
        review["locally_valid"] != "yes"
        or review["outcome_material"] != "yes"
        or review["recovery_state"] != "unrecovered"
        or review["causal_role"] != "critical_root"
    ):
        _fail(
            "selected_candidate_not_critical_root",
            f"{location} selected review does not satisfy the frozen root gate",
        )


def validate_global_selection(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    census_path: str | Path,
    selection_path: str | Path,
) -> dict[str, Any]:
    manifest_path, cohort_path, cases = _load_cases(
        prediction_manifest_path, cohort_manifest_path
    )
    census_file, census_raw = _load_artifact(census_path, role="candidate census")
    census_by_id = _census_by_id(census_raw, cases)
    selection_file, raw = _load_artifact(selection_path, role="global selection")
    if not isinstance(raw, list) or len(raw) != len(cases):
        _fail("invalid_global_selection_count", "selection must match complete cohort")
    for index, (record, case) in enumerate(zip(raw, cases, strict=True)):
        _validate_selection_record(
            record,
            case,
            census_by_id[case.trajectory_id],
            location=f"global_selection[{index}]",
        )
    return {
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_VERSION,
        "stage": "global_selection",
        "model": AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": len(cases),
        "all_candidates_reviewed": True,
        "input_sha256": {
            "prediction_manifest": _file_sha256(manifest_path),
            "cohort": _file_sha256(cohort_path),
            CANDIDATE_CENSUS_FILENAME: _file_sha256(census_file),
        },
        "output_sha256": {GLOBAL_SELECTION_FILENAME: _file_sha256(selection_file)},
    }


def _load_and_validate_sidecars(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    census_path: str | Path,
    selection_path: str | Path,
) -> tuple[list[Any], list[dict[str, Any]], list[dict[str, Any]]]:
    _, _, cases = _load_cases(prediction_manifest_path, cohort_manifest_path)
    _, census_raw = _load_artifact(census_path, role="candidate census")
    census_by_id = _census_by_id(census_raw, cases)
    _, selection_raw = _load_artifact(selection_path, role="global selection")
    if not isinstance(selection_raw, list) or len(selection_raw) != len(cases):
        _fail("invalid_global_selection_count", "selection must match complete cohort")
    for index, (selection, case) in enumerate(zip(selection_raw, cases, strict=True)):
        _validate_selection_record(
            selection,
            case,
            census_by_id[case.trajectory_id],
            location=f"global_selection[{index}]",
        )
    return cases, census_raw, selection_raw


def validate_agent_judge_luna_gaia_v3_12_global_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    prediction_file = Path(predictions_path).expanduser().resolve()
    census_path = prediction_file.parent / CANDIDATE_CENSUS_FILENAME
    selection_path = prediction_file.parent / GLOBAL_SELECTION_FILENAME
    cases, census, selections = _load_and_validate_sidecars(
        prediction_manifest_path,
        cohort_manifest_path,
        census_path,
        selection_path,
    )
    audit = _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction_file,
        owner_source_resolver=_luna_gaia_v2_owner_source_resolver,
    )
    predictions = _load_json(prediction_file, role="predictions")
    for index, (prediction, case, census_record, selection) in enumerate(
        zip(predictions, cases, census, selections, strict=True)
    ):
        candidates = {
            item["candidate_id"]: item for item in census_record["candidates"]
        }
        selected = candidates[selection["selected_candidate_id"]]
        if prediction["trajectory_id"] != case.trajectory_id:
            _fail("final_selection_identity_mismatch", f"predictions[{index}] identity")
        if prediction["predicted_step"] != selected["step"]:
            _fail(
                "final_step_differs_from_global_selection",
                f"predictions[{index}] must preserve globally selected step",
            )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_REASONING_EFFORT,
        "semantic_parent": "agentdebug.codex-agent-judge.luna-gaia-v3.4",
        "selection_policy": "exhaustive_step_module_census_then_global_root_selection",
        "selected_step_frozen_before_final_owner_type_binding": True,
        "input_sha256": {
            **audit["input_sha256"],
            CANDIDATE_CENSUS_FILENAME: _file_sha256(census_path),
            GLOBAL_SELECTION_FILENAME: _file_sha256(selection_path),
        },
    }


def _write_audit(audit: dict[str, Any], audit_path: str | Path) -> dict[str, Any]:
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="stage audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(json.dumps(audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(target)
    return audit


def validate_and_write_candidate_census_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    census_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        validate_candidate_census(
            prediction_manifest_path, cohort_manifest_path, census_path
        ),
        audit_path,
    )


def validate_and_write_global_selection_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    census_path: str | Path,
    selection_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        validate_global_selection(
            prediction_manifest_path,
            cohort_manifest_path,
            census_path,
            selection_path,
        ),
        audit_path,
    )


def validate_and_write_agent_judge_luna_gaia_v3_12_global_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        validate_agent_judge_luna_gaia_v3_12_global_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def _single_case_paths(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> tuple[Path, Path, Any]:
    manifest_path, cohort_path, cases = _load_cases(
        prediction_manifest_path, cohort_manifest_path
    )
    if len(cases) != 1:
        _fail("global_stage_requires_one_case", "each inference session needs one case")
    return manifest_path, cohort_path, cases[0]


def _command(arguments: Sequence[str]) -> str:
    return " ".join(shlex.quote(str(item)) for item in arguments)


def _boundary(
    *,
    manifest_path: Path,
    cohort_path: Path,
    reads: Sequence[Path],
    output_path: Path,
) -> str:
    read_lines = "\n".join(f"- {path}" for path in reads)
    return f"""\
IMMUTABLE EXECUTION CONFIGURATION
- model: {AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_REASONING_EFFORT}
- one isolated case; fresh session; no cross-case state or prior predictions
- external LLM/API/network calls: forbidden
- scoring or gold-label access: forbidden

INPUT/OUTPUT BOUNDARY
- prediction manifest: {manifest_path}
- prediction manifest file sha256: {_file_sha256(manifest_path)}
- cohort manifest: {cohort_path}
- cohort manifest file sha256: {_file_sha256(cohort_path)}
- permitted frozen stage inputs:
{read_lines if read_lines else '- none'}
- write the sole stage artifact only to: {output_path}

Read only those exact inputs plus
`agentdebug/diagnostics/agent_judge_luna_gaia_v3_12_global.py` and
`agentdebug/diagnostics/taxonomy.py`. Do not inspect directories or infer from
trajectory/source-model/environment names. Never read labels, metrics, scored
artifacts, promotion files, docs/experiments, old predictions, cached replies,
case studies, git history, or external resources.
"""


def build_candidate_census_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    census_path: str | Path,
) -> str:
    manifest, cohort, case = _single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    output = Path(census_path).expanduser().resolve()
    _assert_safe_path(output, role="candidate census output", is_output=True)
    audit = output.parent / CENSUS_AUDIT_FILENAME
    command = _command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_12_global",
            "--compact-validate",
            "census",
            str(manifest),
            str(cohort),
            str(output),
            str(audit),
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_VERSION} stage 1/3: candidate census.

{_boundary(manifest_path=manifest, cohort_path=cohort, reads=(), output_path=output)}

{_V3_4_SEMANTICS}

EXHAUSTIVE CENSUS CONTRACT

The manifest contains trajectory `{case.trajectory_id}` with
`trajectory_sha256={case.trajectory_sha256}` and {len(case.judge_view.steps)} steps.
Write one JSON array with one object. Use top-level fields in this exact order:
trajectory_id, trajectory_sha256, rows, candidates. `rows` has exactly one
object per step in chronological order; each row has fields in exact order
step, memory, reflection, planning, action, system, with each module status
exactly `clear` or `candidate`.

For every candidate status, emit exactly one candidate in matching step/module
order. Candidate fields in exact order are:
{', '.join(CANDIDATE_FIELDS)}.
Its ID is `C-` + zero-padded four-digit step + `-` + module. Strength is
`concrete` or `plausible`; recovery_state is unrecovered, recovered, or unclear.
All five explanatory text fields are non-empty and compact. evidence_quote is
an exact contiguous owner substring. Emit at least one candidate. Do not select
a root and do not stop after the first candidate.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def build_global_selection_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    census_path: str | Path,
    selection_path: str | Path,
) -> str:
    manifest, cohort, case = _single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    census_file, census_raw = _load_artifact(census_path, role="candidate census")
    _census_by_id(census_raw, [case])
    output = Path(selection_path).expanduser().resolve()
    _assert_safe_path(output, role="global selection output", is_output=True)
    audit = output.parent / SELECTION_AUDIT_FILENAME
    command = _command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_12_global",
            "--compact-validate",
            "selection",
            str(manifest),
            str(cohort),
            str(census_file),
            str(output),
            str(audit),
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_VERSION} stage 2/3: global selection.

{_boundary(manifest_path=manifest, cohort_path=cohort, reads=(census_file,), output_path=output)}

{_V3_4_SEMANTICS}

{_GLOBAL_SELECTION_RULES}

GLOBAL SELECTION CONTRACT

Write one JSON array with one object. Fields in exact order:
{', '.join(SELECTION_RECORD_FIELDS)}.
Copy trajectory identity exactly. candidate_pool_sha256 is
`{_stable_sha256(census_raw[0])}`. Reviews must cover all
{len(census_raw[0]['candidates'])} candidates once, in frozen order, with fields
{', '.join(REVIEW_FIELDS)}. locally_valid/outcome_material are yes or no;
recovery_state is unrecovered/recovered/unclear; causal_role is one of
{', '.join(sorted(CAUSAL_ROLES))}. selected_candidate_sha256 is the stable JSON
content hash of the exact selected candidate. Do not modify the census.

After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def build_final_binding_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    census_path: str | Path,
    selection_path: str | Path,
    predictions_path: str | Path,
) -> str:
    manifest, cohort, case = _single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    census_file, census_raw = _load_artifact(census_path, role="candidate census")
    selection_file, selection_raw = _load_artifact(
        selection_path, role="global selection"
    )
    census_map = _census_by_id(census_raw, [case])
    if not isinstance(selection_raw, list) or len(selection_raw) != 1:
        _fail("invalid_global_selection_count", "final stage needs one selection")
    _validate_selection_record(
        selection_raw[0], case, census_map[case.trajectory_id], location="global_selection[0]"
    )
    candidate_map = {
        item["candidate_id"]: item for item in census_raw[0]["candidates"]
    }
    selected = candidate_map[selection_raw[0]["selected_candidate_id"]]
    output = Path(predictions_path).expanduser().resolve()
    _assert_safe_path(output, role="prediction output", is_output=True)
    audit = output.parent / PREDICTION_AUDIT_FILENAME
    command = _command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_12_global",
            "--compact-validate",
            "prediction",
            str(manifest),
            str(cohort),
            str(output),
            str(audit),
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    schema = {
        "trajectory_id": "exact manifest trajectory ID",
        "trajectory_sha256": "exact manifest trajectory SHA-256",
        "status": "success",
        "predicted_step": selected["step"],
        "predicted_module": "same-step taxonomy owner",
        "predicted_error_type": "legal type for owner",
        "evidence_quote": "exact same-step owner substring",
        "root_cause": "concise globally selected root explanation",
        "causal_summary": "counterfactual, recovery, and propagation",
        "rejected_adjacent_owner": "strongest same-step alternative and rejection",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_VERSION} stage 3/3: final binding.

{_boundary(manifest_path=manifest, cohort_path=cohort, reads=(census_file, selection_file), output_path=output)}

The global selector froze step {selected['step']} through candidate
`{selected['candidate_id']}`. Preserve that step exactly. Re-read the complete
step packet and independently bind the correct same-step owner, legal taxonomy
type, and literal evidence. The final owner/type may differ from the provisional
candidate owner/type, but the step may not change. Follow v3.4 information-flow
ownership: Memory -> Reflection -> Planning -> Action -> eligible System.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one record and exactly these ten fields:
{json.dumps(schema, ensure_ascii=False, indent=2)}
Every text field is non-empty, status is success, and evidence is an exact
contiguous substring owned by the selected step/module. Emit no extra fields.

After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def build_agent_judge_luna_gaia_v3_12_global_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build stage three when called through the generic protocol registry."""

    prediction = Path(predictions_path).expanduser().resolve()
    return build_final_binding_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / CANDIDATE_CENSUS_FILENAME,
        prediction.parent / GLOBAL_SELECTION_FILENAME,
        prediction,
    )


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "census" and len(paths) == 4:
            audit = validate_and_write_candidate_census_audit(*paths)
        elif stage == "selection" and len(paths) == 5:
            audit = validate_and_write_global_selection_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_12_global_audit(
                *paths
            )
        else:
            _fail("invalid_compact_validation_arguments", "stage/path count differs")
    except AgentJudgeValidationError as error:
        print(
            json.dumps(
                {"valid": False, "error_code": error.code, "error_message": str(error)},
                ensure_ascii=False,
            )
        )
        return 1
    except Exception as error:  # pragma: no cover
        print(
            json.dumps(
                {
                    "valid": False,
                    "error_code": "unexpected_validation_error",
                    "error_message": f"{type(error).__name__}: {error}",
                },
                ensure_ascii=False,
            )
        )
        return 2
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("census", "selection", "prediction"))
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("--compact-validate is required")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_MODEL",
    "AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_VERSION",
    "CANDIDATE_CENSUS_FILENAME",
    "GLOBAL_SELECTION_FILENAME",
    "build_agent_judge_luna_gaia_v3_12_global_task",
    "build_candidate_census_task",
    "build_final_binding_task",
    "build_global_selection_task",
    "main",
    "run_compact_validation",
    "validate_agent_judge_luna_gaia_v3_12_global_predictions",
    "validate_and_write_agent_judge_luna_gaia_v3_12_global_audit",
    "validate_and_write_candidate_census_audit",
    "validate_and_write_global_selection_audit",
    "validate_candidate_census",
    "validate_global_selection",
]

"""Luna Agent Judge v6: v3 draft with a conservative correction card.

V6 preserves Luna v3's chronological diagnosis as the default.  It permits a
single narrow correction pass only when the trace directly falsifies the
provisional diagnosis through observed execution, complete recovery, probe
maturity, or a literal state/handoff contradiction.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_v2_4 import (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION,
    _v2_4_owner_source_resolver,
)
from .agent_judge_luna_v3 import (
    AGENT_JUDGE_LUNA_V3_MODEL,
    AGENT_JUDGE_LUNA_V3_VERSION,
    build_agent_judge_luna_v3_task,
)


AGENT_JUDGE_LUNA_V6_VERSION = "agentdebug.codex-agent-judge.luna-v6"
AGENT_JUDGE_LUNA_V6_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_V6_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_V6_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)

_BASE_HEADER = f"Run the frozen Codex Agent Judge protocol {AGENT_JUDGE_LUNA_V3_VERSION}."
_LUNA_HEADER = (
    "Run the frozen Codex Agent Judge protocol "
    f"{AGENT_JUDGE_LUNA_V6_VERSION}."
)
_BASE_MODEL = f"- model: {AGENT_JUDGE_LUNA_V3_MODEL}"
_LUNA_MODEL = f"- model: {AGENT_JUDGE_LUNA_V6_MODEL}"
_BASE_ALLOWLIST = "agentdebug/diagnostics/agent_judge_luna_v3.py"
_LUNA_ALLOWLIST = "agentdebug/diagnostics/agent_judge_luna_v6.py"
_BASE_VALIDATOR_IMPORT = "agentdebug.diagnostics.agent_judge_luna_v3"
_LUNA_VALIDATOR_IMPORT = "agentdebug.diagnostics.agent_judge_luna_v6"
_BASE_VALIDATOR_ENTRY = "validate_and_write_agent_judge_luna_v3_audit"
_LUNA_VALIDATOR_ENTRY = "validate_and_write_agent_judge_luna_v6_audit"
_OWNER_MARKER = "\n3. SAME-STEP OWNER AFTER STEP FREEZE\n"
_RECOVERY_CONFLICT = """Select the earliest candidate whose correction at that point would prevent a
material wrong branch, wasted sequence, unsupported answer, or failed
interaction.  Freeze predicted_step immediately.  Later recovery does not
move the critical step forward: it is evidence about downstream propagation,
not permission to replace the introduction with a later symptom.  Reject an
early candidate only if it caused no material consequence before being fully
corrected, or if it was reasonable under the evidence then.
"""
_RECOVERY_REPLACEMENT = """Select the earliest candidate whose correction at that point would prevent a
material wrong branch, wasted sequence, unsupported answer, or failed
interaction.  Treat this as the provisional v3 breakpoint.  Freeze it unless
the mandatory conservative correction card below directly vetoes it.  A later
symptom cannot replace it merely by being clearer or closer to failure.
"""

_CONSERVATIVE_CORRECTION = """
MANDATORY V3 DRAFT AND CONSERVATIVE CORRECTION CARD

First finish the chronological v3 scan and record one provisional step, owner,
defect proposition, and downstream effect.  The default decision is KEEP.
Perform exactly one correction pass using the four vetoes below.  Do not
enumerate a fresh whole-episode candidate sheet and do not replace the draft
for a merely plausible alternative.  A replacement requires literal trace
evidence satisfying a named veto.

Before moving the step, try SAME-STEP REPAIR: if the provisional proposition
is invalid but Memory, Reflection, Planning, or Action at that same step
contains the mature defect, keep the step and correct only owner/type.  Move
the step only when no same-step owner can support the causal defect.

VETO 1 — OBSERVED EXECUTION OVERRIDES DISPLAY FORM

The JudgeView is a semantic transcript, not the environment's parser.  If a
later history explicitly records the semantic command as the action taken and
the next observation is a coherent result or state transition, do not call it
format_error or parameter_error solely because the displayed action contains
quotes, prose, or imperfect tags.  The action may still be wrong-target or
misaligned when its semantics are wrong.  Apply same-step repair first; only
then resume the chronological scan without the false syntax candidate.

VETO 2 — COMPLETE RECOVERY OR STRATEGY RESET

Veto the provisional candidate when later behavior actually obtains its
intended state/evidence, successfully performs the equivalent operation, or
explicitly abandons that branch with a new query or strategy before the final
failure.  A one-turn cost is not enough to retain it.  In search/navigation,
reaching a useful result, item-detail state, or genuinely new search epoch
vetoes an earlier weak query/pagination/probe complaint unless an unsupported
belief or irreversible loss survives the reset.  After a veto, diagnose the
first mature defect in the unrecovered epoch that controls the final failure.

VETO 3 — PROBE MATURITY, AFFORDANCE, AND EXTERNAL BOUNDARY

One plausible first probe and, under ambiguous feedback, one confirmation
probe are not mature merely because they fail.  Conversely, if the next
observation or admissible-action list explicitly exposes the required object,
state change, or operation, the first plan that ignores that affordance for
more generic exploration is mature at that later step; do not blame the probe
that revealed it.  Visiting a genuinely unvisited plausible target is not a
repeat.  A sequence of novel feasible searches may end at a provenance-backed
System boundary.  It becomes Planning only when the plan commits to a
demonstrably low-value category despite a clearly higher-prior available
category, or recommits after equivalent no-progress feedback.

VETO 4 — LITERAL STATE LOSS OR PLAN-ACTION HANDOFF

Prefer an upstream Memory/Reflection that falsely says visible candidates,
coverage, progress, or required facts are absent when the current observation
shows otherwise and later decisions consume that statement.  Harmless
compression is not enough.  At the other boundary, if an adequate plan says a
required attribute, prerequisite, or evidence must be verified before commit,
but the action buys, answers, or changes state without verifying it, Action
owns that handoff.  A broad initial query or imperfect pagination is recovered
when it later reaches the useful candidate; it must not displace the later
unrecovered summary or handoff error.

FINAL KEEP/REPLACE TEST

Name the single veto, if any, in the internal analysis.  If no veto is proven,
KEEP the provisional v3 step even when another diagnosis sounds stronger.  If
a veto is proven, make only the narrow repair it licenses, then freeze the
result.  Never use identifiers, environment names, label frequencies, or
expected step distributions in this decision.
"""


def build_agent_judge_luna_v6_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build Luna v3 plus one conservative evidence-veto correction pass."""

    task = build_agent_judge_luna_v3_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    replacements = {
        _BASE_HEADER: _LUNA_HEADER,
        _BASE_MODEL: _LUNA_MODEL,
        _BASE_ALLOWLIST: _LUNA_ALLOWLIST,
        _BASE_VALIDATOR_IMPORT: _LUNA_VALIDATOR_IMPORT,
        _BASE_VALIDATOR_ENTRY: _LUNA_VALIDATOR_ENTRY,
        _RECOVERY_CONFLICT: _RECOVERY_REPLACEMENT,
        _OWNER_MARKER: f"\n{_CONSERVATIVE_CORRECTION.strip()}\n{_OWNER_MARKER}",
    }
    for old, new in replacements.items():
        if task.count(old) != 1:
            raise RuntimeError(
                "Agent Judge Luna v3 task changed at a frozen v6 marker"
            )
        task = task.replace(old, new, 1)
    return task


def validate_agent_judge_luna_v6_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_v2_4_owner_source_resolver,
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_V6_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_V6_VERSION,
        "model": AGENT_JUDGE_LUNA_V6_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V6_REASONING_EFFORT,
    }


def validate_and_write_agent_judge_luna_v6_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_v6_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


__all__ = [
    "AGENT_JUDGE_LUNA_V6_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_V6_MODEL",
    "AGENT_JUDGE_LUNA_V6_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_V6_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "build_agent_judge_luna_v6_task",
    "validate_agent_judge_luna_v6_predictions",
    "validate_and_write_agent_judge_luna_v6_audit",
]

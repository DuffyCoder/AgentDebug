"""Luna GAIA v3.66: clean-v3.20 exact-predicate boundary reducer."""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions
from .taxonomy import AgentModule, ErrorType, is_valid_classification, taxonomy_prompt


AGENT_JUDGE_LUNA_GAIA_V3_66_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.66-clean-v3.20-"
    "exact-predicate-acquisition-boundary-reducer"
)
AGENT_JUDGE_LUNA_GAIA_V3_66_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_66_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_66_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases for the frozen full-50 aggregation runner.
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_66_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_66_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_66_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_66_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_66_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_66_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_66_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
PANEL_FILENAME = "exact-predicate-boundary-assessment.json"
PANELS_FILENAME = "exact-predicate-boundary-assessments.json"
PANEL_AUDIT_FILENAME = "exact-predicate-boundary-assessment-audit.json"
SELECTOR_FILENAME = "exact-predicate-boundary-selection.json"
SELECTORS_FILENAME = "exact-predicate-boundary-selections.json"
SELECTOR_AUDIT_FILENAME = "exact-predicate-boundary-selection-audit.json"

MODULES = tuple(module.value for module in AgentModule)
ERROR_TYPES = tuple(error_type.value for error_type in ErrorType)

ASSESSMENT_FIELDS = (
    "requested_exact_predicate",
    "anchor_classification",
    "anchor_assessment",
    "candidate_status",
    "candidate_origin",
    "candidate_step",
    "candidate_boundary_class",
    "candidate_module",
    "candidate_error_type",
    "candidate_evidence_quote",
    "candidate_root_cause",
    "candidate_causal_summary",
    "candidate_rejected_adjacent_owner",
    "decision_time_capability",
    "actual_exact_predicate_status",
    "task_contribution",
    "later_relation",
    "local_repair_effect",
    "recovery_status",
    "qualifies_as_critical_boundary",
    "chronology_comparison",
    "selection_falsifier",
)
SELECTION_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "anchor_prediction_sha256",
    "anchor_ledger_sha256",
    "anchor_checkpoint_sha256",
    "assessment_sha256",
    "decision",
    "anchor_step",
    "candidate_origin",
    "candidate_step",
    "candidate_prediction",
    "frozen_step",
    "selected_prediction_sha256",
    "selected_prediction",
    "semantic_assessment",
)

ANCHOR_CLASSES = frozenset(
    {
        "critical_root",
        "contributing_probe",
        "normal_tool_failure",
        "recovered_defect",
        "noncritical_predecessor",
        "faithful_propagation",
        "repeated_same_gap",
        "downstream_symptom",
        "uncertain",
    }
)
OVERRIDABLE_FOR_PREFIX = frozenset(
    {"faithful_propagation", "repeated_same_gap", "downstream_symptom"}
)
OVERRIDABLE_FOR_LATER = frozenset(
    {"contributing_probe", "normal_tool_failure", "recovered_defect", "noncritical_predecessor"}
)
ORIGINS = frozenset({"prefix_ledger", "later_boundary", "none"})
BOUNDARY_CLASSES = frozenset(
    {"exact_predicate_acquisition_failure", "outcome_handoff_failure", "none"}
)
CAPABILITIES = frozenset(
    {"cannot_directly_expose_exact_predicate", "can_directly_expose_exact_predicate", "not_applicable"}
)
PREDICATE_STATUSES = frozenset({"unresolved", "resolved", "not_applicable"})
CONTRIBUTIONS = frozenset({"zero", "partial_or_reusable", "not_applicable"})
LATER_RELATIONS = frozenset(
    {
        "repeats_same_gap",
        "propagates_same_gap",
        "independent_critical_boundary",
        "independent_noncritical_boundary",
        "not_applicable",
    }
)
REPAIR_EFFECTS = frozenset(
    {"redirects_exact_predicate_gap", "does_not_redirect", "not_applicable"}
)
RECOVERY_STATUSES = frozenset({"unrecovered", "recovered", "not_applicable"})


_EXACT_PREDICATE_RULES = """\
EXACT-PREDICATE ACQUISITION BOUNDARY REDUCER — ONE CANDIDATE MAXIMUM

The accepted v3.20 anchor, sparse chronological ledger, and checkpoint are
immutable evidence. Reassess the boundary once using the complete observable
timeline. Export at most one alternative: either one pre-anchor ledger row or
one later Step. The program will exact-copy the anchor when no alternative
passes every gate and will otherwise materialize and select the sole candidate.

Define the `requested_exact_predicate` as the smallest task-material fact,
relation, identifier, constraint, source property, or output value that the
current subgoal genuinely needs. Do not substitute the entire final answer for
an intermediate discovery predicate. A search that can expose a necessary
identifier or source lead may be a sound probe even when it cannot prove the
final answer.

Conversely, `initial_probe` and `different_probe` are only ex-ante priors. A
probe can mature into the benchmark critical boundary even after returning a
partial or reusable intermediate when ALL of these are literally established:

1. as actually parameterized and in the chosen modality, the Step cannot
   directly expose the exact active predicate;
2. its actual output leaves that predicate unresolved;
3. its partial contribution does not close that predicate or change the next
   decision into a genuinely new evidence route;
4. repairing only the Step's target, parameter, modality, or result handoff
   redirects the exact-predicate gap;
5. the defect remains unrecovered; and
6. for a prefix candidate, the v3.20 anchor only repeats or faithfully
   propagates the same gap; for a later candidate, the anchor is a genuinely
   contributing/normal/recovered predecessor and the later Step independently
   becomes the first mature acquisition failure.

`partial_or_reusable` is deliberately not a categorical veto. It records that
some intermediate was produced; the capability, exact-predicate status, route
change, repair, recovery, and chronology gates still decide maturity. But do
not relabel a useful search merely because hindsight reveals a better query.
If the operation can directly expose the active predicate, if its returned
lead causes a genuinely new evidence route, or if the later boundary is
independent, keep the anchor for a prefix proposal.

Protect anchors that are direct constraint violations, false task state,
incapable commitments, eligible System failures, or otherwise independently
critical. Reject ordinary negative tool results, recovered defects, mechanical
predecessors, faithful propagation, terminal symptoms, vivid later failures,
and improvements that do not redirect the failed path. Select Agent-authored
Planning/Action or the result-to-Memory/Reflection handoff that owns the gap;
do not turn an ordinary external negative result into a System error.

The candidate must be the earliest boundary satisfying this exact-predicate
mechanism, not the first ledger row, latest symptom, strongest prose, or a
Module/type preference. Module/type exist only for legal output. Never use
trajectory identity, source model, entity/site priors, scores, gold, old
predictions, case reports, or cross-case patterns.
"""


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_66_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_66_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_66_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one exact-predicate acquisition boundary reducer",
    }


def _prediction_schema() -> dict[str, Any]:
    properties = {
        "trajectory_id": {"type": "string"},
        "trajectory_sha256": {"type": "string"},
        "status": {"type": "string", "enum": ["success"]},
        "predicted_step": {"type": "integer", "minimum": 1},
        "predicted_module": {"type": "string", "enum": list(MODULES)},
        "predicted_error_type": {"type": "string", "enum": list(ERROR_TYPES)},
        "evidence_quote": {"type": "string", "minLength": 1},
        "root_cause": {"type": "string", "minLength": 1},
        "causal_summary": {"type": "string", "minLength": 1},
        "rejected_adjacent_owner": {"type": "string", "minLength": 1},
    }
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties),
        "additionalProperties": False,
    }


def anchor_response_schema() -> dict[str, Any]:
    lane_statuses = [
        "clear",
        "candidate",
        "veto_mechanical_repair",
        "veto_initial_probe",
        "veto_different_probe",
        "veto_terminal_supersession",
    ]
    row_properties = {
        "step": {"type": "integer", "minimum": 1},
        "lane_a": {"type": "string", "enum": lane_statuses},
        "lane_b": {"type": "string", "enum": lane_statuses},
        "system": {"type": "string", "enum": lane_statuses},
        "lane_c": {"type": "string", "enum": lane_statuses},
        "surviving_lane": {
            "type": ["string", "null"],
            "enum": ["lane_a", "lane_b", "system", "lane_c", None],
        },
        "evidence_quote": {"type": ["string", "null"]},
        "decision_basis": {"type": "string", "minLength": 1},
    }
    ledger_properties = {
        "trajectory_id": {"type": "string"},
        "rows": {
            "type": "array",
            "minItems": 1,
            "items": {
                "type": "object",
                "properties": row_properties,
                "required": list(row_properties),
                "additionalProperties": False,
            },
        },
        "selected_step": {"type": "integer", "minimum": 1},
    }
    freeze_properties = {
        "trajectory_id": {"type": "string"},
        "predicted_step": {"type": "integer", "minimum": 1},
    }
    properties = {
        "anchor_predictions": {
            "type": "array",
            "minItems": 1,
            "maxItems": 1,
            "items": _prediction_schema(),
        },
        "step_candidates": {
            "type": "object",
            "properties": ledger_properties,
            "required": list(ledger_properties),
            "additionalProperties": False,
        },
        "step_freeze": {
            "type": "object",
            "properties": freeze_properties,
            "required": list(freeze_properties),
            "additionalProperties": False,
        },
    }
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties),
        "additionalProperties": False,
    }


def reducer_response_schema() -> dict[str, Any]:
    nullable_string = {"type": ["string", "null"]}
    nullable_integer = {"type": ["integer", "null"], "minimum": 1}
    properties: dict[str, Any] = {
        "requested_exact_predicate": {"type": "string", "minLength": 1},
        "anchor_classification": {"type": "string", "enum": sorted(ANCHOR_CLASSES)},
        "anchor_assessment": {"type": "string", "minLength": 1},
        "candidate_status": {"type": "string", "enum": ["candidate", "none"]},
        "candidate_origin": {"type": "string", "enum": sorted(ORIGINS)},
        "candidate_step": nullable_integer,
        "candidate_boundary_class": {"type": "string", "enum": sorted(BOUNDARY_CLASSES)},
        "candidate_module": nullable_string,
        "candidate_error_type": nullable_string,
        "candidate_evidence_quote": nullable_string,
        "candidate_root_cause": nullable_string,
        "candidate_causal_summary": nullable_string,
        "candidate_rejected_adjacent_owner": nullable_string,
        "decision_time_capability": {"type": "string", "enum": sorted(CAPABILITIES)},
        "actual_exact_predicate_status": {"type": "string", "enum": sorted(PREDICATE_STATUSES)},
        "task_contribution": {"type": "string", "enum": sorted(CONTRIBUTIONS)},
        "later_relation": {"type": "string", "enum": sorted(LATER_RELATIONS)},
        "local_repair_effect": {"type": "string", "enum": sorted(REPAIR_EFFECTS)},
        "recovery_status": {"type": "string", "enum": sorted(RECOVERY_STATUSES)},
        "qualifies_as_critical_boundary": {"type": "boolean"},
        "chronology_comparison": {"type": "string", "minLength": 1},
        "selection_falsifier": {"type": "string", "minLength": 1},
    }
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties),
        "additionalProperties": False,
    }


def build_anchor_response_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> str:
    manifest, cohort, _ = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    original = parent.build_anchor_task(manifest, cohort, manifest.parent / "anchor-predictions.json")
    for filename in (
        "step-candidates.json",
        "step-freeze.json",
        "anchor-predictions.json",
        "prediction-audit.json",
    ):
        original = original.replace(str(manifest.parent / filename), filename)
    start = original.index("THE ONLY DECISION ORDER")
    end = original.index("MANDATORY LOCAL VALIDATION")
    semantic_contract = original[start:end].rstrip()
    semantic_contract = semantic_contract.replace(
        "Before the step checkpoint, write exactly one JSON object to `step-candidates.json`.",
        "Before the step checkpoint, populate response field `step_candidates` with exactly one JSON object.",
    ).replace(
        "Write this file once and never edit it.  Then derive and write the",
        "Freeze this object conceptually. Then derive and populate the",
    ).replace(
        "write exactly this two-field JSON object to `step-freeze.json`:",
        "populate response field `step_freeze` with exactly this two-field JSON object:",
    ).replace(
        "write\nexactly this two-field JSON object to `step-freeze.json`:",
        "populate response field `step_freeze` with exactly this two-field JSON object:",
    ).replace(
        "Do not add fields and never edit this file after writing it.  Only then assign",
        "Do not add fields. Only then assign",
    ).replace(
        "the same-step owner/type/evidence and write the final ten-field prediction.",
        "the same-step owner/type/evidence and populate the final ten-field prediction.",
    ).replace(
        "Write one JSON array containing exactly one record and exactly these fields:",
        "Populate response field `anchor_predictions` with one JSON array containing exactly one record and exactly these fields:",
    )
    manifest_value = json.loads(manifest.read_text(encoding="utf-8"))
    cohort_value = json.loads(cohort.read_text(encoding="utf-8"))
    return f"""\
Run the accepted {parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION} anchor semantics.

RUNTIME CONTRACT — RESPONSE ONLY
- model: {AGENT_JUDGE_LUNA_GAIA_V3_66_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_66_REASONING_EFFORT}
- one isolated case; no prior predictions or cross-case state
- do not call shell, filesystem, network, or any other tool
- do not inspect paths or directories; every permitted input is embedded below
- do not read labels, metrics, scores, old predictions, reports, git history, or external resources
- return only the JSON object required by the supplied response schema
- ignore trajectory/source-model/environment identity as diagnostic evidence

{semantic_contract}

RESPONSE BUNDLE CONTRACT

Return exactly one object with keys `anchor_predictions`, `step_candidates`,
and `step_freeze`, in that order. `anchor_predictions` is the unchanged v3.20
ten-field one-record prediction array. `step_candidates` is the unchanged v3.20
chronological ledger: rows are consecutive from Step 1, stop at selected_step,
use exactly the eight fields step/lane_a/lane_b/system/lane_c/surviving_lane/
evidence_quote/decision_basis, and obey all lane/veto rules above. Begin every
decision_basis with the binding v3.20 packet-state prefix. `step_freeze` has
exactly trajectory_id and predicted_step. All three selected Step values must
agree. Do not add commentary or markdown.

EMBEDDED PREDICTION MANIFEST
{json.dumps(manifest_value, ensure_ascii=False, separators=(",", ":"))}

EMBEDDED COHORT IDENTITY (validation only; never semantic evidence)
{json.dumps(cohort_value, ensure_ascii=False, separators=(",", ":"))}
"""


def materialize_anchor_response(
    response: Any,
    *,
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    attempt_dir: str | Path,
) -> tuple[Path, Path, Path]:
    if not isinstance(response, dict) or tuple(response) != (
        "anchor_predictions", "step_candidates", "step_freeze"
    ):
        shared._fail("invalid_response_only_anchor_bundle", "anchor_response")
    root = Path(attempt_dir).expanduser().resolve()
    anchor = root / ANCHOR_PREDICTIONS_FILENAME
    ledger = root / "step-candidates.json"
    checkpoint = root / "step-freeze.json"
    _write_json(anchor, response["anchor_predictions"])
    _write_json(ledger, response["step_candidates"])
    _write_json(checkpoint, response["step_freeze"])
    validate_and_write_anchor_audit(
        prediction_manifest_path,
        cohort_manifest_path,
        anchor,
        root / PREDICTION_AUDIT_FILENAME,
    )
    return anchor, ledger, checkpoint


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    temporary.replace(path)


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths), policy="unchanged_v3_20_anchor_response_only")


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])


def _load_anchor_bundle(
    manifest: Path,
    cohort: Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> tuple[Path, Path, Path, dict[str, Any], dict[str, Any], dict[str, Any]]:
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    anchor, ledger, checkpoint = shared._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    parent._validate_packet_state_ledgers(ledger_file)
    return anchor_file, ledger_file, checkpoint_file, anchor, ledger, checkpoint


def _candidate_payload(record: dict[str, Any]) -> tuple[Any, ...]:
    return tuple(
        record[field]
        for field in (
            "candidate_step",
            "candidate_module",
            "candidate_error_type",
            "candidate_evidence_quote",
            "candidate_root_cause",
            "candidate_causal_summary",
            "candidate_rejected_adjacent_owner",
        )
    )


def _validate_assessment_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != ASSESSMENT_FIELDS:
        shared._fail("invalid_exact_predicate_assessment_schema", location)
    for field in (
        "requested_exact_predicate",
        "anchor_assessment",
        "chronology_comparison",
        "selection_falsifier",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3200)
    if raw["anchor_classification"] not in ANCHOR_CLASSES:
        shared._fail("invalid_exact_predicate_anchor_class", location)
    enums = {
        "candidate_origin": ORIGINS,
        "candidate_boundary_class": BOUNDARY_CLASSES,
        "decision_time_capability": CAPABILITIES,
        "actual_exact_predicate_status": PREDICATE_STATUSES,
        "task_contribution": CONTRIBUTIONS,
        "later_relation": LATER_RELATIONS,
        "local_repair_effect": REPAIR_EFFECTS,
        "recovery_status": RECOVERY_STATUSES,
    }
    if any(raw[field] not in allowed for field, allowed in enums.items()):
        shared._fail("invalid_exact_predicate_gate_value", location)
    qualifies = raw["qualifies_as_critical_boundary"]
    if not isinstance(qualifies, bool):
        shared._fail("invalid_exact_predicate_qualification", location)

    if raw["candidate_status"] == "none":
        if (
            raw["candidate_origin"] != "none"
            or raw["candidate_boundary_class"] != "none"
            or any(value is not None for value in _candidate_payload(raw))
            or qualifies
            or raw["decision_time_capability"] != "not_applicable"
            or raw["actual_exact_predicate_status"] != "not_applicable"
            or raw["task_contribution"] != "not_applicable"
            or raw["later_relation"] != "not_applicable"
            or raw["local_repair_effect"] != "not_applicable"
            or raw["recovery_status"] != "not_applicable"
        ):
            shared._fail("nonempty_exact_predicate_none_candidate", location)
        return raw
    if raw["candidate_status"] != "candidate" or not qualifies:
        shared._fail("invalid_exact_predicate_candidate_status", location)
    if raw["candidate_origin"] not in {"prefix_ledger", "later_boundary"}:
        shared._fail("invalid_exact_predicate_candidate_origin", location)
    step = raw["candidate_step"]
    if isinstance(step, bool) or not isinstance(step, int) or not 1 <= step <= len(case.judge_view.steps):
        shared._fail("invalid_exact_predicate_candidate_step", location)
    anchor_step = anchor["predicted_step"]
    if raw["candidate_origin"] == "prefix_ledger":
        matching = [row for row in ledger["rows"] if row.get("step") == step]
        if (
            step >= anchor_step
            or len(matching) != 1
            or matching[0].get("lane_c") not in {"veto_initial_probe", "veto_different_probe"}
        ):
            shared._fail("unbound_exact_predicate_prefix_candidate", location)
        if raw["later_relation"] not in {"repeats_same_gap", "propagates_same_gap"}:
            shared._fail("invalid_exact_predicate_prefix_relation", location)
        if raw["anchor_classification"] not in OVERRIDABLE_FOR_PREFIX:
            shared._fail("protected_exact_predicate_prefix_anchor", location)
    else:
        if step <= anchor_step:
            shared._fail("unbound_exact_predicate_later_candidate", location)
        if raw["later_relation"] != "independent_critical_boundary":
            shared._fail("invalid_exact_predicate_later_relation", location)
        if raw["anchor_classification"] not in OVERRIDABLE_FOR_LATER:
            shared._fail("protected_exact_predicate_later_anchor", location)
    if raw["candidate_boundary_class"] not in {
        "exact_predicate_acquisition_failure", "outcome_handoff_failure"
    }:
        shared._fail("invalid_exact_predicate_candidate_class", location)
    required_gates = (
        raw["decision_time_capability"] == "cannot_directly_expose_exact_predicate",
        raw["actual_exact_predicate_status"] == "unresolved",
        raw["task_contribution"] in {"zero", "partial_or_reusable"},
        raw["local_repair_effect"] == "redirects_exact_predicate_gap",
        raw["recovery_status"] == "unrecovered",
    )
    if not all(required_gates):
        shared._fail("incomplete_exact_predicate_maturity_gate", location)
    try:
        module = AgentModule(raw["candidate_module"])
        error_type = ErrorType(raw["candidate_error_type"])
    except (TypeError, ValueError):
        shared._fail("invalid_exact_predicate_taxonomy", location)
    if not is_valid_classification(module, error_type):
        shared._fail("invalid_exact_predicate_taxonomy", location)
    for field in (
        "candidate_evidence_quote",
        "candidate_root_cause",
        "candidate_causal_summary",
        "candidate_rejected_adjacent_owner",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3200)
    sources = shared._luna_gaia_v2_owner_source_resolver(
        case.judge_view, step, module, error_type
    )
    if not sources or not any(raw["candidate_evidence_quote"] in source for source in sources):
        shared._fail("invalid_exact_predicate_evidence", location)
    return raw


def build_reducer_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor, ledger, checkpoint = bundle[3:]
    manifest_value = json.loads(manifest.read_text(encoding="utf-8"))
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_66_VERSION}: one exact-predicate boundary reduction.

RUNTIME CONTRACT — RESPONSE ONLY
- model: {AGENT_JUDGE_LUNA_GAIA_V3_66_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_66_REASONING_EFFORT}
- one isolated case; only the fresh current anchor bundle is visible
- do not call shell, filesystem, network, or any other tool
- do not inspect paths or directories; every permitted input is embedded below
- do not read labels, scores, metrics, old predictions, reports, git history, or external resources
- return only the JSON object required by the supplied response schema
- trajectory/source-model/environment identity is never diagnostic evidence

{_EXACT_PREDICATE_RULES}

The immutable anchor is Step {anchor['predicted_step']}. Emit exactly the
twenty-two semantic fields in schema order. For `candidate_status=none`, set
origin and boundary class to `none`, all seven candidate payload fields to
null, all five gate fields plus later_relation to `not_applicable`, and
qualifies=false. For a candidate, every maturity gate must pass and every
candidate text field must be literal/evidence-grounded. Do not emit identity,
hashes, a final decision, or selected prediction; the parent process binds and
assembles them deterministically.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

EMBEDDED CURRENT PREDICTION MANIFEST
{json.dumps(manifest_value, ensure_ascii=False, separators=(",", ":"))}

EMBEDDED FRESH V3.20 ANCHOR
{json.dumps(anchor, ensure_ascii=False, separators=(",", ":"))}

EMBEDDED FRESH V3.20 SPARSE LEDGER
{json.dumps(ledger, ensure_ascii=False, separators=(",", ":"))}

EMBEDDED FRESH V3.20 CHECKPOINT
{json.dumps(checkpoint, ensure_ascii=False, separators=(",", ":"))}
"""


def validate_assessment(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    assessment_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger = bundle[3:5]
    assessment_file, value = shared._load_artifact(
        assessment_path, role="exact-predicate boundary assessment"
    )
    assessment = shared._one_record(value, role="exact-predicate boundary assessment")
    _validate_assessment_record(
        assessment, case=case, anchor=anchor, ledger=ledger, location="assessment[0]"
    )
    return _retag(
        {
            "schema_version": "agentdebug.exact-predicate-boundary-assessment-audit.v1",
            "stage": "exact_predicate_acquisition_boundary_assessment",
            "gold_free_validation": True,
            "case_count": 1,
            "maximum_candidates": 1,
            "candidate_status": assessment["candidate_status"],
            "candidate_origin": assessment["candidate_origin"],
            "partial_contribution_is_not_categorical_veto": True,
            "input_sha256": {
                "anchor": shared._file_sha256(anchor_file),
                "ledger": shared._file_sha256(ledger_file),
                "checkpoint": shared._file_sha256(checkpoint_file),
            },
            "output_sha256": {PANEL_FILENAME: shared._file_sha256(assessment_file)},
        },
        policy="one_exact_predicate_acquisition_boundary_assessment",
    )


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_assessment(*paths[:-1]), paths[-1])


def _candidate_prediction(case: Any, assessment: dict[str, Any]) -> dict[str, Any]:
    result = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        "predicted_step": assessment["candidate_step"],
        "predicted_module": assessment["candidate_module"],
        "predicted_error_type": assessment["candidate_error_type"],
        "evidence_quote": assessment["candidate_evidence_quote"],
        "root_cause": assessment["candidate_root_cause"],
        "causal_summary": assessment["candidate_causal_summary"],
        "rejected_adjacent_owner": assessment["candidate_rejected_adjacent_owner"],
    }
    return shared._validate_prediction_record(
        result, case=case, location="exact_predicate_candidate_prediction"
    )


def build_selection_document(
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    assessment: dict[str, Any],
) -> dict[str, Any]:
    semantic = _validate_assessment_record(
        assessment, case=case, anchor=anchor, ledger=ledger, location="assessment"
    )
    candidate = None
    if semantic["candidate_status"] == "candidate":
        candidate = _candidate_prediction(case, semantic)
        decision = "select_candidate"
        selected = candidate
    else:
        decision = "keep_anchor"
        selected = anchor
    result = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "assessment_sha256": shared._stable_sha256(semantic),
        "decision": decision,
        "anchor_step": anchor["predicted_step"],
        "candidate_origin": semantic["candidate_origin"],
        "candidate_step": semantic["candidate_step"],
        "candidate_prediction": candidate,
        "frozen_step": selected["predicted_step"],
        "selected_prediction_sha256": shared._stable_sha256(selected),
        "selected_prediction": selected,
        "semantic_assessment": semantic,
    }
    return _validate_selection_record(
        result,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        assessment=semantic,
        location="deterministic_selection",
    )


def _validate_selection_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    assessment: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != SELECTION_FIELDS:
        shared._fail("invalid_exact_predicate_selection_schema", location)
    expected_hashes = {
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "assessment_sha256": shared._stable_sha256(assessment),
    }
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
        or any(raw[key] != value for key, value in expected_hashes.items())
        or raw["anchor_step"] != anchor["predicted_step"]
        or raw["candidate_origin"] != assessment["candidate_origin"]
        or raw["candidate_step"] != assessment["candidate_step"]
        or raw["semantic_assessment"] != assessment
    ):
        shared._fail("exact_predicate_selection_binding_mismatch", location)
    selected = shared._validate_prediction_record(
        raw["selected_prediction"], case=case, location=f"{location}.selected"
    )
    if (
        raw["selected_prediction_sha256"] != shared._stable_sha256(selected)
        or raw["frozen_step"] != selected["predicted_step"]
    ):
        shared._fail("exact_predicate_selected_hash_mismatch", location)
    if assessment["candidate_status"] == "none":
        if raw["decision"] != "keep_anchor" or raw["candidate_prediction"] is not None or selected != anchor:
            shared._fail("exact_predicate_keep_anchor_mismatch", location)
    else:
        expected = _candidate_prediction(case, assessment)
        if raw["decision"] != "select_candidate" or raw["candidate_prediction"] != expected or selected != expected:
            shared._fail("exact_predicate_candidate_copy_mismatch", location)
    return raw


def validate_selector(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    assessment_path: str | Path,
    selector_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger, checkpoint = bundle[3:]
    assessment_file, assessment_raw = shared._load_artifact(
        assessment_path, role="exact-predicate boundary assessment"
    )
    assessment = shared._one_record(
        assessment_raw, role="exact-predicate boundary assessment"
    )
    _validate_assessment_record(
        assessment, case=case, anchor=anchor, ledger=ledger, location="assessment[0]"
    )
    selector_file, selector_raw = shared._load_artifact(
        selector_path, role="exact-predicate boundary selection"
    )
    selector = shared._one_record(selector_raw, role="exact-predicate boundary selection")
    _validate_selection_record(
        selector,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        assessment=assessment,
        location="selection[0]",
    )
    expected = build_selection_document(
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        assessment=assessment,
    )
    if selector != expected:
        shared._fail("non_deterministic_exact_predicate_selection", "selection[0]")
    return _retag(
        {
            "schema_version": "agentdebug.exact-predicate-boundary-selection-audit.v1",
            "stage": "deterministic_exact_predicate_boundary_selection",
            "gold_free_validation": True,
            "case_count": 1,
            "decision": selector["decision"],
            "selected_prediction_exact_copy": True,
            "maximum_candidates": 1,
            "input_sha256": {
                "anchor": shared._file_sha256(anchor_file),
                "ledger": shared._file_sha256(ledger_file),
                "checkpoint": shared._file_sha256(checkpoint_file),
                "assessment": shared._file_sha256(assessment_file),
            },
            "output_sha256": {SELECTOR_FILENAME: shared._file_sha256(selector_file)},
        },
        policy="deterministic_exact_predicate_candidate_else_anchor",
    )


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_selector(*paths[:-1]), paths[-1])


def _validate_aggregate(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(prediction_manifest_path, cohort_manifest_path)
    root = Path(predictions_path).expanduser().resolve().parent
    names = (
        ANCHOR_PREDICTIONS_FILENAME,
        ANCHOR_LEDGER_AGGREGATE_FILENAME,
        ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        PANELS_FILENAME,
        SELECTORS_FILENAME,
    )
    loaded = {name: shared._load_artifact(root / name, role=f"merged {name}")[1] for name in names}
    if any(not isinstance(value, list) or len(value) != len(cases) for value in loaded.values()):
        shared._fail("invalid_exact_predicate_aggregate_count", "merged artifacts")
    finals = shared._load_artifact(predictions_path, role="merged predictions")[1]
    if not isinstance(finals, list) or len(finals) != len(cases):
        shared._fail("invalid_exact_predicate_prediction_count", "predictions")
    decisions: Counter[str] = Counter()
    origins: Counter[str] = Counter()
    contributions: Counter[str] = Counter()
    for index, case in enumerate(cases):
        location = f"exact_predicate_merged[{index}]"
        anchor = shared._validate_prediction_record(
            loaded[ANCHOR_PREDICTIONS_FILENAME][index], case=case, location=f"{location}.anchor"
        )
        ledger = loaded[ANCHOR_LEDGER_AGGREGATE_FILENAME][index]
        checkpoint = loaded[ANCHOR_CHECKPOINT_AGGREGATE_FILENAME][index]
        if (
            ledger.get("trajectory_id") != case.trajectory_id
            or ledger.get("selected_step") != anchor["predicted_step"]
            or checkpoint.get("trajectory_id") != case.trajectory_id
            or checkpoint.get("predicted_step") != anchor["predicted_step"]
        ):
            shared._fail("exact_predicate_anchor_sidecar_mismatch", location)
        assessment = loaded[PANELS_FILENAME][index]
        _validate_assessment_record(
            assessment, case=case, anchor=anchor, ledger=ledger, location=f"{location}.assessment"
        )
        selector = loaded[SELECTORS_FILENAME][index]
        _validate_selection_record(
            selector,
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            assessment=assessment,
            location=f"{location}.selection",
        )
        final = shared._validate_prediction_record(finals[index], case=case, location=f"{location}.final")
        if final != selector["selected_prediction"]:
            shared._fail("exact_predicate_final_copy_mismatch", location)
        decisions[selector["decision"]] += 1
        origins[assessment["candidate_origin"]] += 1
        contributions[assessment["task_contribution"]] += 1
    return {
        "required": True,
        "valid": True,
        "anchor_blind_panel": False,
        "maximum_specialist_candidates": 1,
        "maximum_total_predictions": 2,
        "all_selected_predictions_exact_copies": True,
        "deterministic_selection": True,
        "partial_contribution_is_not_categorical_veto": True,
        "selector_decision_counts": dict(sorted(decisions.items())),
        "candidate_origin_counts": dict(sorted(origins.items())),
        "task_contribution_counts": dict(sorted(contributions.items())),
        "packet_state_closure": parent._validate_packet_state_ledgers(
            root / ANCHOR_LEDGER_AGGREGATE_FILENAME
        ),
    }


def validate_agent_judge_luna_gaia_v3_66_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    factorized = _validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_66_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_66_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_66_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_66_REASONING_EFFORT,
        "selection_policy": "clean_v3_20_exact_predicate_acquisition_boundary_reducer",
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one exact-predicate acquisition boundary reducer",
        "anchor_semantics_unchanged_from_v3_20": True,
        "response_only_read_only_runtime_required": True,
        "all_selected_predictions_exact_copies": True,
        "factorized_specialist_panel": factorized,
    }


def validate_and_write_agent_judge_luna_gaia_v3_66_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(
        validate_agent_judge_luna_gaia_v3_66_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_luna_gaia_v3_66_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_reducer_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
    )


# Generic runner compatibility aliases.
validate_and_write_agent_judge_luna_gaia_v3_37_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_66_audit
)
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_luna_gaia_v3_66_task
build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_66_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_66_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_66_audit
)

"""Luna GAIA v3.16: one bounded bidirectional challenger over v3.14."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as base
from . import agent_judge_luna_gaia_v3_14_earliest_causal_challenger as parent
from .agent_judge import _file_sha256, _stable_sha256
from .agent_judge_luna_gaia_v3 import STEP_FREEZE_FILENAME
from .agent_judge_luna_gaia_v3_4 import STEP_CANDIDATE_LEDGER_FILENAME
from .taxonomy import taxonomy_prompt


AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.16-bounded-bidirectional-challenger"
)
AGENT_JUDGE_LUNA_GAIA_V3_16_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_14_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_16_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_14_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_16_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_14_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases used by the shared paper-50 runner.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_16_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_16_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_16_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = base.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = base.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = base.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = base.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = base.CHALLENGERS_FILENAME
ARBITER_FILENAME = base.ARBITER_FILENAME
ARBITERS_FILENAME = base.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = base.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = base.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = base.PREDICTION_AUDIT_FILENAME
CHALLENGER_FIELDS = base.CHALLENGER_FIELDS
ARBITER_FIELDS = base.ARBITER_FIELDS

ANCHOR_CLASSIFICATIONS = frozenset(
    {
        "critical_root",
        "reasonable_probe",
        "noncritical_predecessor",
        "downstream_symptom",
        "uncertain",
    }
)
EARLIER_OVERRIDE_CLASSIFICATION = "downstream_symptom"
LATER_OVERRIDE_CLASSIFICATIONS = base.OVERRIDE_CLASSIFICATIONS


_BOUNDED_BIDIRECTIONAL_RULES = """\
BOUNDED BIDIRECTIONAL SINGLE-CHALLENGER RULE

The frozen v3.4 prediction is the incumbent anchor, not merely one candidate.
Do not enumerate or retain a candidate pool. Across both searches below, emit
at most ONE proposal. The anchor remains the default under uncertainty.

SEARCH 1 — STRICTLY EARLIER HANDOFF BOUNDARY

First ask whether the anchor is only a downstream restatement, persistence, or
symptom of a task-material handoff defect at a strictly earlier Step. Scan Step
1 through Step anchor-1 in chronology. Propose only the EARLIEST Step passing
all three gates:

1. NECESSITY: a fact, entity/value/provenance link, discriminating target,
   predicate, or evidence route is necessary for a still-open task condition.
2. LITERAL BOUNDARY: the task and adjacent packets at that Step directly show
   either result-to-retained-state omission/contradiction/false reading or
   immediate-target-to-Action loss/contradiction.
3. PATH EFFECT: repairing that exact handoff can change the retained state or
   subsequent action path, while repairing only the anchor symptom cannot
   repair the earlier defect.

For an earlier challenge, classify the anchor as downstream_symptom. Quote
literal packet text in anchor_veto_evidence_quote and identify its owning Step.
The proposed prediction evidence must independently be owned by its Step and
module. Stop after the first qualifying earlier Step.

Never use the earlier path for harmless summary compression, naming polish, an
initial information-gathering probe that can contribute a needed lead, a
materially different evidence route, a normal tool failure, or merely
improvable behavior. A string/scalar parameter accepted and successfully
executed by the tool is not a parameter-format error without literal rejection
or misparse. Do not infer a mismatch from unstated domain knowledge.

SEARCH 2 — V3.14 EARLIEST-CAUSAL LATER FALLBACK

Only if no earlier Step passes, apply the v3.14 path-intervention rule. Challenge
the anchor only when literal evidence proves it is a reasonable probe or
noncritical predecessor. Ask what the trace could do if only the anchor defect
were repaired; do not hold a path-dependent later reaction fixed. Retain an
eligible external tool-execution-failure anchor when successful execution could
avert the later path.

If the anchor is falsified, scan Step anchor+1 onward and propose the EARLIEST
later Step that remains independently failure-causing under anchor-only repair.
Do not skip an earlier repeated-strategy boundary, false progress state, or
failure-causing commitment for a later exception, stronger wording, severity,
or terminal symptom. A repeated strategy qualifies only after the preceding
observation rules it out and the new Step makes no material change.

Use anchor_only_repair_counterfactual and proposal_only_repair_counterfactual
to state the path intervention. direct_timeline_comparison must compare the
anchor, every intervening plausible boundary, and the proposal. search_summary
must certify which search ran, that no earlier qualifying Step was skipped, and
that exactly one proposal exists or none qualifies. When uncertain, no_challenge.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_14_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_14_earliest_causal_challenger",
            "agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger",
        )
        .replace(
            "agent_judge_luna_gaia_v3_13_conservative_challenger",
            "agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger",
        )
    )


def build_anchor_task(*paths: str | Path) -> str:
    """Use exactly the v3.14 anchor semantics with only version identity changed."""

    return _rewrite_identity(parent.build_anchor_task(*paths))


def _validate_challenger_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != CHALLENGER_FIELDS:
        base._fail("invalid_challenger_schema", f"{location} fields/order differ")
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
    ):
        base._fail("challenger_identity_mismatch", location)
    bindings = {
        "anchor_prediction_sha256": _stable_sha256(anchor),
        "anchor_ledger_sha256": _stable_sha256(ledger),
        "anchor_checkpoint_sha256": _stable_sha256(checkpoint),
    }
    if any(raw[key] != value for key, value in bindings.items()):
        base._fail("challenger_anchor_hash_mismatch", location)
    anchor_step = anchor["predicted_step"]
    if raw["anchor_step"] != anchor_step:
        base._fail("challenger_anchor_step_mismatch", location)
    if raw["challenge_status"] not in base.CHALLENGE_STATUSES:
        base._fail("invalid_challenge_status", location)
    if raw["anchor_classification"] not in ANCHOR_CLASSIFICATIONS:
        base._fail("invalid_anchor_classification", location)
    for field in (
        "anchor_falsifier",
        "anchor_only_repair_counterfactual",
        "proposal_only_repair_counterfactual",
        "direct_timeline_comparison",
        "search_summary",
    ):
        base._nonempty_text(raw[field], location=f"{location}.{field}")

    if raw["challenge_status"] == "no_challenge":
        if any(
            raw[field] is not None
            for field in (
                "anchor_veto_evidence_step",
                "anchor_veto_evidence_quote",
                "proposed_prediction",
            )
        ):
            base._fail("no_challenge_must_not_propose", location)
        return raw

    veto_step = raw["anchor_veto_evidence_step"]
    veto_quote = raw["anchor_veto_evidence_quote"]
    if (
        isinstance(veto_step, bool)
        or not isinstance(veto_step, int)
        or veto_step < 1
        or veto_step > len(case.judge_view.steps)
        or not isinstance(veto_quote, str)
        or not veto_quote.strip()
        or len(veto_quote) > 1200
        or not any(
            veto_quote in source for source in base._packet_sources(case, veto_step)
        )
    ):
        base._fail("invalid_anchor_veto_evidence", location)
    proposal = base._validate_prediction_record(
        raw["proposed_prediction"], case=case, location=f"{location}.proposal"
    )
    proposal_step = proposal["predicted_step"]
    if proposal_step == anchor_step:
        base._fail("challenger_must_change_step", location)
    if proposal_step < anchor_step:
        if raw["anchor_classification"] != EARLIER_OVERRIDE_CLASSIFICATION:
            base._fail("earlier_challenge_requires_downstream_symptom", location)
    elif raw["anchor_classification"] not in LATER_OVERRIDE_CLASSIFICATIONS:
        base._fail("later_challenge_lacks_anchor_veto", location)
    return raw


def validate_challenger(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    challenger_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = base._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    challenger_file, raw = base._load_artifact(challenger_path, role="challenger")
    anchor, ledger, checkpoint = base._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    record = base._one_record(raw, role="challenger")
    _validate_challenger_record(
        record,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        location="challenger[0]",
    )
    proposal = record.get("proposed_prediction")
    direction = "none"
    if proposal is not None:
        direction = "earlier" if proposal["predicted_step"] < anchor["predicted_step"] else "later"
    return {
        "schema_version": "agentdebug.bounded-bidirectional-challenger-audit.v1",
        "stage": "challenger",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_16_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_16_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": 1,
        "challenge_status": record["challenge_status"],
        "challenge_direction": direction,
        "earlier_first": True,
        "single_challenger_maximum": True,
        "input_sha256": {
            ANCHOR_PREDICTIONS_FILENAME: _file_sha256(anchor_file),
            STEP_CANDIDATE_LEDGER_FILENAME: _file_sha256(ledger_file),
            STEP_FREEZE_FILENAME: _file_sha256(checkpoint_file),
        },
        "output_sha256": {CHALLENGER_FILENAME: _file_sha256(challenger_file)},
    }


def _validate_arbiter_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    challenger: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != ARBITER_FIELDS:
        base._fail("invalid_arbiter_schema", f"{location} fields/order differ")
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
    ):
        base._fail("arbiter_identity_mismatch", location)
    if raw["anchor_prediction_sha256"] != _stable_sha256(anchor):
        base._fail("arbiter_anchor_hash_mismatch", location)
    if raw["challenger_sha256"] != _stable_sha256(challenger):
        base._fail("arbiter_challenger_hash_mismatch", location)
    anchor_step = anchor["predicted_step"]
    if raw["anchor_step"] != anchor_step:
        base._fail("arbiter_anchor_step_mismatch", location)
    if raw["decision"] not in base.ARBITER_DECISIONS:
        base._fail("invalid_arbiter_decision", location)
    base._nonempty_text(raw["decision_basis"], location=f"{location}.decision_basis")
    base._nonempty_text(
        raw["rejected_alternative_basis"],
        location=f"{location}.rejected_alternative_basis",
    )
    selected = base._validate_prediction_record(
        raw["selected_prediction"], case=case, location=f"{location}.selected"
    )
    if raw["selected_prediction_sha256"] != _stable_sha256(selected):
        base._fail("arbiter_selected_prediction_hash_mismatch", location)
    if raw["frozen_step"] != selected["predicted_step"]:
        base._fail("arbiter_frozen_step_mismatch", location)
    if raw["decision"] == "keep_anchor":
        if selected != anchor or raw["frozen_step"] != anchor_step:
            base._fail("arbiter_anchor_copy_mismatch", location)
        return raw
    if challenger["challenge_status"] != "challenge":
        base._fail("arbiter_accepts_missing_challenge", location)
    proposal = challenger["proposed_prediction"]
    if selected != proposal:
        base._fail("arbiter_challenger_copy_mismatch", location)
    proposal_step = proposal["predicted_step"]
    if proposal_step < anchor_step:
        if challenger["anchor_classification"] != EARLIER_OVERRIDE_CLASSIFICATION:
            base._fail("arbiter_accepts_invalid_earlier_challenge", location)
    elif proposal_step > anchor_step:
        if challenger["anchor_classification"] not in LATER_OVERRIDE_CLASSIFICATIONS:
            base._fail("arbiter_accepts_unfalsified_anchor", location)
    else:
        base._fail("arbiter_accepts_equal_step_challenge", location)
    return raw


def validate_arbiter(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    challenger_path: str | Path,
    arbiter_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = base._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    challenger_file, challenger_raw = base._load_artifact(
        challenger_path, role="challenger"
    )
    arbiter_file, arbiter_raw = base._load_artifact(arbiter_path, role="arbiter")
    anchor, ledger, checkpoint = base._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    challenger = base._one_record(challenger_raw, role="challenger")
    _validate_challenger_record(
        challenger,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        location="challenger[0]",
    )
    arbiter = base._one_record(arbiter_raw, role="arbiter")
    _validate_arbiter_record(
        arbiter,
        case=case,
        anchor=anchor,
        challenger=challenger,
        location="arbiter[0]",
    )
    return {
        "schema_version": "agentdebug.bounded-bidirectional-arbiter-audit.v1",
        "stage": "arbiter",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_16_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_16_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": 1,
        "decision": arbiter["decision"],
        "default_anchor_policy": True,
        "selected_prediction_exact_copy": True,
        "input_sha256": {
            ANCHOR_PREDICTIONS_FILENAME: _file_sha256(anchor_file),
            CHALLENGER_FILENAME: _file_sha256(challenger_file),
        },
        "output_sha256": {ARBITER_FILENAME: _file_sha256(arbiter_file)},
    }


def validate_agent_judge_luna_gaia_v3_16_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, cases = base._load_cases(
        prediction_manifest_path, cohort_manifest_path
    )
    prediction_file = Path(predictions_path).expanduser().resolve()
    base_audit = base._validate_agent_judge_predictions_with_owner_sources(
        manifest,
        cohort,
        prediction_file,
        owner_source_resolver=base._luna_gaia_v2_owner_source_resolver,
    )
    anchor_file, anchors = base._load_artifact(
        prediction_file.parent / ANCHOR_PREDICTIONS_FILENAME,
        role="merged anchors",
    )
    ledger_file, ledgers = base._load_artifact(
        prediction_file.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME,
        role="merged anchor ledgers",
    )
    checkpoint_file, checkpoints = base._load_artifact(
        prediction_file.parent / ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        role="merged anchor checkpoints",
    )
    challenger_file, challengers = base._load_artifact(
        prediction_file.parent / CHALLENGERS_FILENAME,
        role="merged challengers",
    )
    arbiter_file, arbiters = base._load_artifact(
        prediction_file.parent / ARBITERS_FILENAME,
        role="merged arbiters",
    )
    predictions = base._load_json(prediction_file, role="predictions")
    values = (anchors, ledgers, checkpoints, challengers, arbiters, predictions)
    if any(not isinstance(value, list) or len(value) != len(cases) for value in values):
        base._fail("invalid_merged_bidirectional_count", "all merged artifacts need all cases")
    decisions: list[str] = []
    directions: list[str] = []
    for index, (case, anchor, ledger, checkpoint, challenger, arbiter, prediction) in enumerate(
        zip(cases, anchors, ledgers, checkpoints, challengers, arbiters, predictions, strict=True)
    ):
        location = f"merged[{index}]"
        base._validate_prediction_record(anchor, case=case, location=f"{location}.anchor")
        if (
            ledger.get("trajectory_id") != case.trajectory_id
            or ledger.get("selected_step") != anchor["predicted_step"]
            or checkpoint.get("trajectory_id") != case.trajectory_id
            or checkpoint.get("predicted_step") != anchor["predicted_step"]
        ):
            base._fail("merged_anchor_sidecar_mismatch", location)
        _validate_challenger_record(
            challenger,
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            location=f"{location}.challenger",
        )
        _validate_arbiter_record(
            arbiter,
            case=case,
            anchor=anchor,
            challenger=challenger,
            location=f"{location}.arbiter",
        )
        if prediction != arbiter["selected_prediction"]:
            base._fail("final_prediction_differs_from_arbiter", location)
        decisions.append(arbiter["decision"])
        proposal = challenger.get("proposed_prediction")
        directions.append(
            "none"
            if proposal is None
            else ("earlier" if proposal["predicted_step"] < anchor["predicted_step"] else "later")
        )
    return {
        **base_audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_16_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_16_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_16_REASONING_EFFORT,
        "selection_policy": (
            "unchanged_v3_4_anchor_one_bounded_earlier_first_bidirectional_"
            "challenger_default_keep_exact_copy_arbiter"
        ),
        "gold_free_validation": True,
        "case_count": len(cases),
        "anchor_semantics_unchanged_from_v3_14": True,
        "single_challenger_maximum": True,
        "all_selected_predictions_exact_copies": True,
        "arbiter_decision_counts": {
            decision: decisions.count(decision) for decision in sorted(set(decisions))
        },
        "challenger_direction_counts": {
            direction: directions.count(direction) for direction in sorted(set(directions))
        },
        "input_sidecar_sha256": {
            ANCHOR_PREDICTIONS_FILENAME: _file_sha256(anchor_file),
            ANCHOR_LEDGER_AGGREGATE_FILENAME: _file_sha256(ledger_file),
            ANCHOR_CHECKPOINT_AGGREGATE_FILENAME: _file_sha256(checkpoint_file),
            CHALLENGERS_FILENAME: _file_sha256(challenger_file),
            ARBITERS_FILENAME: _file_sha256(arbiter_file),
        },
    }


def build_challenger_task(*paths: str | Path) -> str:
    task = _rewrite_identity(parent.build_challenger_task(*paths))
    task = task.replace(parent._EARLIEST_CAUSAL_RULES, _BOUNDED_BIDIRECTIONAL_RULES)
    task = task.replace(
        "A proposal must be strictly later.",
        "A proposal must change Step and satisfy its direction-specific classification.",
    )
    task = task.replace(
        '"critical_root/reasonable_probe/noncritical_predecessor/uncertain"',
        '"critical_root/reasonable_probe/noncritical_predecessor/downstream_symptom/uncertain"',
    )
    task = task.replace(
        '"why exactly one later proposal exists or none qualifies"',
        '"which direction was searched and why one proposal exists or none qualifies"',
    )
    return task.replace(
        "Inspect the complete\ntimeline only to falsify or retain this anchor. A proposal must be strictly later.",
        "Inspect the complete timeline only to falsify or retain this anchor. "
        "Search earlier first, then use the later fallback; a proposal must change Step.",
    )


def build_arbiter_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    challenger_path: str | Path,
    arbiter_path: str | Path,
) -> str:
    manifest, cohort, case = base._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    challenger_file, challenger_raw = base._load_artifact(
        challenger_path, role="challenger"
    )
    anchor, ledger, checkpoint = base._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    challenger = base._one_record(challenger_raw, role="challenger")
    _validate_challenger_record(
        challenger,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        location="challenger[0]",
    )
    output = Path(arbiter_path).expanduser().resolve()
    base._assert_safe_path(output, role="arbiter output", is_output=True)
    audit = output.parent / ARBITER_AUDIT_FILENAME
    command = base._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger",
            "--compact-validate",
            "arbiter",
            manifest,
            cohort,
            anchor_file,
            ledger_file,
            checkpoint_file,
            challenger_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": _stable_sha256(anchor),
        "challenger_sha256": _stable_sha256(challenger),
        "anchor_step": anchor["predicted_step"],
        "decision": "keep_anchor or accept_challenger",
        "frozen_step": "selected prediction Step",
        "selected_prediction_sha256": "stable JSON hash of exact selected prediction",
        "selected_prediction": "exact unchanged anchor or challenger prediction object",
        "decision_basis": "literal-evidence threshold decision",
        "rejected_alternative_basis": "why the other exact prediction loses",
    }
    boundary = base._boundary(
        manifest=manifest,
        cohort=cohort,
        reads=(anchor_file, ledger_file, checkpoint_file, challenger_file),
        output=output,
    ).replace(
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_13_conservative_challenger.py",
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger.py",
    )
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION} stage 3/3: independent arbiter.

{boundary}

{_BOUNDED_BIDIRECTIONAL_RULES}

The anchor is the default. Re-read the complete trace and the one frozen
challenger. Accept it only if every direction-specific classification,
necessity, literal-boundary, path-effect, path-intervention, and earliest-
boundary claim is supported by chronology. If there is no challenge, keep_anchor.

selected_prediction must be an exact field-for-field copy of the anchor when
keeping it, or the proposed_prediction when accepting. Do not repair, rewrite,
or invent a third prediction. Compute selected_prediction_sha256 as stable
sorted compact JSON content hash of that exact object.

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def build_agent_judge_luna_gaia_v3_16_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / STEP_CANDIDATE_LEDGER_FILENAME,
        prediction.parent / STEP_FREEZE_FILENAME,
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def _write_audit(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return base._write_audit(audit, path)


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_16_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        validate_agent_judge_luna_gaia_v3_16_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


# Compatibility names used by the shared paper-50 runner.
build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_16_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_16_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_16_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_16_audit(*paths)
        else:
            base._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except base.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

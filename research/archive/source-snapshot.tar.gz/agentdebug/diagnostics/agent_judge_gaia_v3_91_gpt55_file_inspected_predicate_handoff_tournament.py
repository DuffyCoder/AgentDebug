"""GAIA v3.91: clean v3.83 predicate-handoff tournament with staged input.

The semantic mechanism is the v3.80 outcome-conditioned tournament, cleanly
ported onto accepted v3.83/GPT-5.5.  The owner-explicit JudgeView remains exact
but is inspected through a bounded read-only helper rather than embedded in the
initial prompt, avoiding transport-only context failures on long trajectories.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge_luna_gaia_v3_80_clean_v3p20_outcome_conditioned_predicate_handoff_tournament_taxonomy_repair import *  # noqa: F403
from . import agent_judge_gaia_v3_83_clean_v3p20_model_only_gpt55_medium as incumbent
from . import (
    agent_judge_luna_gaia_v3_80_clean_v3p20_outcome_conditioned_predicate_handoff_tournament_taxonomy_repair as mechanism,
)


AGENT_JUDGE_GAIA_V3_91_VERSION = (
    "agentdebug.codex-agent-judge.gaia-v3.91-gpt55-file-inspected-"
    "predicate-handoff-tournament"
)
AGENT_JUDGE_GAIA_V3_91_MODEL = incumbent.AGENT_JUDGE_GAIA_V3_83_MODEL
AGENT_JUDGE_GAIA_V3_91_REASONING_EFFORT = incumbent.AGENT_JUDGE_GAIA_V3_83_REASONING_EFFORT
AGENT_JUDGE_GAIA_V3_91_AUDIT_SCHEMA_VERSION = incumbent.AGENT_JUDGE_GAIA_V3_83_AUDIT_SCHEMA_VERSION
SEMANTIC_PARENT = incumbent.AGENT_JUDGE_GAIA_V3_83_VERSION

AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION = AGENT_JUDGE_GAIA_V3_91_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_80_MODEL = AGENT_JUDGE_GAIA_V3_91_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_80_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_91_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_79_VERSION = AGENT_JUDGE_GAIA_V3_91_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_79_MODEL = AGENT_JUDGE_GAIA_V3_91_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_79_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_91_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION = AGENT_JUDGE_GAIA_V3_91_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL = AGENT_JUDGE_GAIA_V3_91_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_91_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_GAIA_V3_91_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_GAIA_V3_91_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_91_REASONING_EFFORT

INSPECTOR_FILENAME = "inspect_case.py"
_DOCUMENT_MARKER = "OWNER-EXPLICIT COMPLETE JUDGEVIEW\n"
_ANCHOR_MARKER = "\n\nFRESH DEFAULT ANCHOR PAYLOAD\n"
_INSPECTION_CONTRACT = """OWNER-EXPLICIT COMPLETE JUDGEVIEW — STAGED READ-ONLY TRANSPORT
The exact lossless JudgeView is staged as `owner-explicit-inference-document.json`.
Inspect it only through these bounded commands; do not use any other command or tool:
- `python inspect_case.py task`
- `python inspect_case.py timeline START END` (at most five consecutive Steps)
- `python inspect_case.py step N`
- `python inspect_case.py owner N planning|reasoning|action|memory|reflection`
- `python inspect_case.py feedback N`
First read `task`, then cover the complete timeline in consecutive pages before
freezing a Step. Drill into exact owner/feedback text as needed. The timeline
previews are an index only; exact evidence must come from an exact drill-down.
Do not read parent directories, manifests, labels, scores, reports, or history."""


def _retag_and_externalize(task: str) -> str:
    value = task.replace(
        mechanism.AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION,
        AGENT_JUDGE_GAIA_V3_91_VERSION,
    ).replace(
        mechanism.parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        SEMANTIC_PARENT,
    )
    old_model = f"- model: {mechanism.AGENT_JUDGE_LUNA_GAIA_V3_80_MODEL}"
    if value.count(old_model) != 1:
        raise RuntimeError("v3.80 task model marker changed unexpectedly")
    value = value.replace(old_model, f"- model: {AGENT_JUDGE_GAIA_V3_91_MODEL}", 1)
    value = value.replace(
        "- do not call shell, filesystem, network, validator, or any other tool",
        "- use only the staged read-only inspector commands listed below; network and all other tools are forbidden",
    ).replace(
        "- one isolated case; do not call tools or read any external artifact",
        "- one isolated case; use only the staged read-only inspector commands listed below",
    )
    start = value.index(_DOCUMENT_MARKER)
    payload_start = start + len(_DOCUMENT_MARKER)
    anchor_start = value.find(_ANCHOR_MARKER, payload_start)
    end = anchor_start if anchor_start >= 0 else len(value)
    return value[:start] + _INSPECTION_CONTRACT + value[end:]


def build_anchor_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> str:
    return _retag_and_externalize(
        mechanism.build_anchor_file_task(prediction_manifest_path, cohort_manifest_path)
    )


def build_reducer_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> str:
    return _retag_and_externalize(
        mechanism.build_reducer_file_task(
            prediction_manifest_path,
            cohort_manifest_path,
            anchor_path,
            ledger_path,
            checkpoint_path,
        )
    )


def _retag_audit(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_GAIA_V3_91_VERSION,
        "model": AGENT_JUDGE_GAIA_V3_91_MODEL,
        "reasoning_effort": AGENT_JUDGE_GAIA_V3_91_REASONING_EFFORT,
        "selection_policy": policy,
        "semantic_parent": SEMANTIC_PARENT,
        "direct_semantic_parent": SEMANTIC_PARENT,
        "rejected_lineage_inherited": False,
        "rejected_lineage_mechanism_source_only": mechanism.AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION,
        "single_major_change": (
            "replace accepted v3.83 challenger/arbiter with one outcome-conditioned "
            "predicate-handoff tournament over every native v3.83 ledger Step"
        ),
        "uniform_file_inspected_owner_explicit_transport": True,
        "selected_step_invariant_taxonomy_materialization": True,
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag_audit(
        mechanism.validate_anchor_predictions(*paths),
        policy="unchanged_v3_83_gpt55_anchor_file_inspected_owner_explicit_input",
    )


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])  # noqa: F405


def validate_panel(*paths: str | Path) -> dict[str, Any]:
    return _retag_audit(
        mechanism.validate_panel(*paths),
        policy="file_inspected_outcome_conditioned_predicate_handoff_tournament",
    )


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_panel(*paths[:-1]), paths[-1])  # noqa: F405


def validate_selector(*paths: str | Path) -> dict[str, Any]:
    return _retag_audit(
        mechanism.validate_selector(*paths),
        policy="deterministic_predicate_handoff_tournament_selection_copy",
    )


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_selector(*paths[:-1]), paths[-1])  # noqa: F405


def validate_agent_judge_gaia_v3_91_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    return _retag_audit(
        mechanism.validate_agent_judge_luna_gaia_v3_80_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        policy="accepted_v3p83_anchor_file_inspected_predicate_handoff_tournament",
    )


def validate_and_write_agent_judge_gaia_v3_91_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(  # noqa: F405
        validate_agent_judge_gaia_v3_91_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_gaia_v3_91_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_reducer_file_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,  # noqa: F405
    )


validate_and_write_agent_judge_luna_gaia_v3_67_audit = validate_and_write_agent_judge_gaia_v3_91_audit
validate_and_write_agent_judge_luna_gaia_v3_79_audit = validate_and_write_agent_judge_gaia_v3_91_audit
validate_and_write_agent_judge_luna_gaia_v3_80_audit = validate_and_write_agent_judge_gaia_v3_91_audit
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_gaia_v3_91_task
build_agent_judge_luna_gaia_v3_79_task = build_agent_judge_gaia_v3_91_task
build_agent_judge_luna_gaia_v3_80_task = build_agent_judge_gaia_v3_91_task


def __getattr__(name: str) -> Any:
    return getattr(mechanism, name)


"""Evidence-grounded, lane-blind step arbitration for Luna Agent Judge.

V16 keeps v15's anonymous JudgeView and strict owner-bound evidence atoms,
but uses an atom only as a mechanically checkable *step witness* during
boundary discovery.  Three witnesses nominate steps, the parent always adds
the strategy witness's immediate predecessor when one exists, and arbitration
sees only deduplicated neutral step cards.  Once a step is frozen,
classification is structurally re-resolved through an owner-bound atom at that
same step.  This is one autoregressive response, not hidden-context or
independent-agent isolation; the validator simply makes final owner/type
legality independent of witness owner/basis and arbitration prose.
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Mapping

from agentdebug.benchmark.prediction_manifest import load_prediction_manifest

from . import agent_judge_luna_v15_unified as _v15
from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _file_sha256,
    _load_json,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_luna_v13_unified import (
    _anonymized_timeline,
    _leaf_and_residual_owner_source_resolver,
)
from .agent_judge_luna_v14_unified import (
    _atom_catalog_sha256,
    _public_atom_catalog,
    _required_text,
    _validate_one_case_identity,
)
from .agent_judge_v2_4 import AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
from .taxonomy import AgentModule, ErrorType, is_valid_classification, taxonomy_prompt


AGENT_JUDGE_LUNA_V16_UNIFIED_VERSION = (
    "agentdebug.codex-agent-judge.luna-v16-unified-v1"
)
AGENT_JUDGE_LUNA_V16_UNIFIED_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_V16_UNIFIED_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_V16_UNIFIED_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)

DECISION_FILENAME = "decision.json"

_WITNESS_FIELDS = frozenset(
    {
        "evidence_atom_id",
        "defect_basis",
        "boundary_reason",
        "smallest_correction",
        "downstream_consequence",
    }
)
_ASSESSMENT_FIELDS = frozenset(
    {
        "step_card_id",
        "memory_analysis",
        "reflection_analysis",
        "planning_analysis",
        "action_analysis",
        "system_analysis",
        "counterfactual_correction",
        "downstream_consequence",
        "comparative_judgment",
    }
)
_ARBITRATION_FIELDS = frozenset(
    {
        "selected_step_card_id",
        "candidate_assessments",
        "selected_step_reason",
    }
)
_CLASSIFICATION_FIELDS = frozenset(
    {"owner_atom_id", "predicted_error_type", "rejected_adjacent_owner"}
)
_DECISION_FIELDS = frozenset(
    {
        "chronological_witness",
        "local_witness",
        "strategy_witness",
        "arbitration",
        "classification",
    }
)

_DEFECT_BASES = frozenset(
    {
        "literal_state_contradiction",
        "literal_task_constraint",
        "plan_action_contract",
        "mechanical_interface_defect",
        "mature_repetition",
        "observable_system_boundary",
        "causal_inference",
    }
)

_ATOM_SCHEMA_VERSION = "agentdebug.luna-v16-evidence-atoms.v1"
_STEP_SCHEMA_VERSION = "agentdebug.luna-v16-step-cards.v1"
_DECISION_AUDIT_SCHEMA_VERSION = (
    "agentdebug.codex-agent-judge-luna-v16-decision-audit.v1"
)
_STEP_PREFIX = "SC-"
_ATOM_PREFIX = "EA-"

_ARBITRATION_PROVENANCE_RE = re.compile(
    r"(?:"
    r"chronological[_ -]witness|local[_ -]witness|strategy[_ -]witness|"
    r"\b(?:chronological|local|strategy)\s+(?:lane|source)\b|"
    r"\bphase\s*[abc]\b|\bnominated\s+by\b|"
    r"\bbecause\s+(?:it\s+was\s+)?nominated\b|"
    r"\bwitness(?:es)?\s+nominated\b|"
    r"\bwitness\s+lane\b|\bcandidate[_ -]source\b|"
    r"\bnomination\s+count\b|\b(?:candidate\s+)?card\s+(?:order|position)\b|"
    r"\blist\s+order\b|\border\s+of\s+(?:the\s+)?(?:cards|candidates|list)\b|"
    r"\b(?:card|candidate|entry|item)(?:'s)?\s+position\s+in\s+the\s+list\b|"
    r"\b(?:first|second|third|fourth)\s+(?:card|candidate|entry|item)\b"
    r")",
    flags=re.IGNORECASE,
)


def _evidence_atoms(case: Any) -> tuple[dict[str, Any], ...]:
    """Reuse v15's strict atom geometry, including its Step-1 System filter."""

    return _v15._evidence_atoms(case)


def _step_cards(
    case: Any,
    atoms: tuple[dict[str, Any], ...],
) -> tuple[dict[str, Any], ...]:
    """Reuse v15's deterministic case-local step IDs and evidence flags."""

    return _v15._step_cards(case, atoms)


def _step_catalog_sha256(cards: tuple[dict[str, Any], ...]) -> str:
    return _v15._step_catalog_sha256(cards)


def _public_step_catalog(cards: tuple[dict[str, Any], ...]) -> dict[str, Any]:
    return {
        "schema_version": _STEP_SCHEMA_VERSION,
        "step_count": len(cards),
        "cards": [dict(card) for card in cards],
    }


def build_luna_v16_evidence_atom_catalog(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> dict[str, Any]:
    """Return the exact anonymous step/evidence catalogs used by v16."""

    _, _, _, case, _ = _validate_one_case_identity(
        prediction_manifest_path,
        cohort_manifest_path,
        role="task",
    )
    atoms = _evidence_atoms(case)
    cards = _step_cards(case, atoms)
    return {
        "schema_version": _ATOM_SCHEMA_VERSION,
        "atom_count": len(atoms),
        "catalog_sha256": _atom_catalog_sha256(atoms),
        "step_catalog_sha256": _step_catalog_sha256(cards),
        "step_catalog": _public_step_catalog(cards),
        **_public_atom_catalog(atoms),
    }


def decision_output_schema() -> dict[str, Any]:
    """Return the exact strict JSON schema supplied to the model."""

    step_id = {
        "type": "string",
        "pattern": rf"^{re.escape(_STEP_PREFIX)}[0-9]{{4}}$",
    }
    atom_id = {
        "type": "string",
        "pattern": rf"^{re.escape(_ATOM_PREFIX)}[0-9]{{4}}$",
    }
    nonempty_text = {"type": "string", "minLength": 1}
    witness = {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_WITNESS_FIELDS),
        "properties": {
            "evidence_atom_id": atom_id,
            "defect_basis": {"type": "string", "enum": sorted(_DEFECT_BASES)},
            "boundary_reason": nonempty_text,
            "smallest_correction": nonempty_text,
            "downstream_consequence": nonempty_text,
        },
    }
    assessment = {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_ASSESSMENT_FIELDS),
        "properties": {
            "step_card_id": step_id,
            **{
                field: nonempty_text
                for field in sorted(_ASSESSMENT_FIELDS)
                if field != "step_card_id"
            },
        },
    }
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_DECISION_FIELDS),
        "properties": {
            "chronological_witness": witness,
            "local_witness": witness,
            "strategy_witness": witness,
            "arbitration": {
                "type": "object",
                "additionalProperties": False,
                "required": sorted(_ARBITRATION_FIELDS),
                "properties": {
                    "selected_step_card_id": step_id,
                    "candidate_assessments": {
                        "type": "array",
                        "minItems": 1,
                        "maxItems": 4,
                        "items": assessment,
                    },
                    "selected_step_reason": nonempty_text,
                },
            },
            "classification": {
                "type": "object",
                "additionalProperties": False,
                "required": sorted(_CLASSIFICATION_FIELDS),
                "properties": {
                    "owner_atom_id": atom_id,
                    "predicted_error_type": {
                        "type": "string",
                        "enum": [item.value for item in ErrorType],
                    },
                    "rejected_adjacent_owner": nonempty_text,
                },
            },
        },
    }


def _runtime_assessment(step_card_id: str) -> dict[str, str]:
    return {
        "step_card_id": step_card_id,
        "memory_analysis": "Memory ownership was tested at this step.",
        "reflection_analysis": "Reflection ownership was tested at this step.",
        "planning_analysis": "Planning ownership was tested at this step.",
        "action_analysis": "Action ownership was tested at this step.",
        "system_analysis": "Strict System evidence was tested at this step.",
        "counterfactual_correction": "Correct this step and hold later steps fixed.",
        "downstream_consequence": "The resulting downstream chain changes.",
        "comparative_judgment": "This step was compared with every other card.",
    }


def runtime_conformance_decision() -> dict[str, Any]:
    """Return a case-independent schema probe for runner conformance only."""

    def witness(atom_id: str, basis: str, label: str) -> dict[str, str]:
        return {
            "evidence_atom_id": atom_id,
            "defect_basis": basis,
            "boundary_reason": f"The {label} witness marks a material boundary.",
            "smallest_correction": f"Correct the {label} decision.",
            "downstream_consequence": f"The {label} correction redirects failure.",
        }

    return {
        "chronological_witness": witness(
            "EA-0001", "literal_task_constraint", "chronological"
        ),
        "local_witness": witness(
            "EA-0002", "mechanical_interface_defect", "local"
        ),
        "strategy_witness": witness(
            "EA-0003", "causal_inference", "strategy"
        ),
        "arbitration": {
            "selected_step_card_id": "SC-0001",
            "candidate_assessments": [
                _runtime_assessment("SC-0001"),
                _runtime_assessment("SC-0002"),
                _runtime_assessment("SC-0003"),
            ],
            "selected_step_reason": "SC-0001 is the strongest counterfactual root.",
        },
        "classification": {
            "owner_atom_id": "EA-0001",
            "predicted_error_type": ErrorType.INEFFICIENT_PLAN.value,
            "rejected_adjacent_owner": "The adjacent owner is only downstream.",
        },
    }


def _witness(
    value: Any,
    *,
    atoms_by_id: Mapping[str, Mapping[str, Any]],
    cards_by_step: Mapping[int, Mapping[str, Any]],
    location: str,
) -> tuple[dict[str, Any], Mapping[str, Any]]:
    """Resolve an evidence atom to a step without freezing final ownership."""

    if not isinstance(value, Mapping) or set(value) != _WITNESS_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_witness_fields", f"{location} has invalid fields"
        )
    atom_id = value["evidence_atom_id"]
    if not isinstance(atom_id, str) or atom_id not in atoms_by_id:
        raise AgentJudgeValidationError(
            "unknown_evidence_atom",
            f"{location}.evidence_atom_id is not in the catalog",
        )
    atom = atoms_by_id[atom_id]
    basis = value["defect_basis"]
    if not isinstance(basis, str) or basis not in _DEFECT_BASES:
        raise AgentJudgeValidationError(
            "invalid_defect_basis", f"{location}.defect_basis is invalid"
        )
    system_basis = basis == "observable_system_boundary"
    system_atom = atom["owner_module"] == AgentModule.SYSTEM.value
    if system_basis != system_atom:
        raise AgentJudgeValidationError(
            "evidence_atom_system_mismatch",
            "observable_system_boundary and the witness's strict System atom "
            "must agree; this check anchors only the witness, not final ownership",
        )
    for field in _WITNESS_FIELDS - {"evidence_atom_id", "defect_basis"}:
        _required_text(value[field], location=f"{location}.{field}")
    step = atom["step"]
    card = cards_by_step[step]
    return (
        {
            **dict(value),
            "step_card_id": card["step_card_id"],
            "step": step,
            "witness_owner_module": atom["owner_module"],
            "witness_quote": atom["quote"],
        },
        atom,
    )


def _candidate_cards(
    *,
    chronological: Mapping[str, Any],
    local: Mapping[str, Any],
    strategy: Mapping[str, Any],
    cards_by_step: Mapping[int, Mapping[str, Any]],
) -> tuple[dict[str, Any], ...]:
    """Build lane-blind cards and unconditionally add strategy C-1."""

    candidate_steps = {
        chronological["step"],
        local["step"],
        strategy["step"],
    }
    if strategy["step"] > 1:
        candidate_steps.add(strategy["step"] - 1)
    return tuple(
        {
            "step_card_id": cards_by_step[step]["step_card_id"],
            "step": step,
        }
        for step in sorted(candidate_steps)
    )


def _candidate_catalog_sha256(cards: tuple[dict[str, Any], ...]) -> str:
    body = json.dumps(
        cards,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(body).hexdigest()


def _arbitration_text(value: Any, *, location: str) -> str:
    """Require prose that does not explicitly reveal nomination provenance."""

    text = _required_text(value, location=location)
    if _ARBITRATION_PROVENANCE_RE.search(text):
        raise AgentJudgeValidationError(
            "arbitration_provenance_leak",
            f"{location} explicitly refers to a witness lane or nomination source",
        )
    return text


def _arbitration(
    value: Any,
    *,
    candidate_cards: tuple[dict[str, Any], ...],
    location: str,
) -> tuple[dict[str, Any], Mapping[str, Any], Mapping[str, Any]]:
    """Require an exhaustive, uniform counterfactual assessment of all cards."""

    if not isinstance(value, Mapping) or set(value) != _ARBITRATION_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_arbitration_fields", f"{location} has invalid fields"
        )
    expected_ids = {card["step_card_id"] for card in candidate_cards}
    assessments = value["candidate_assessments"]
    if not isinstance(assessments, list) or not assessments:
        raise AgentJudgeValidationError(
            "invalid_candidate_assessments",
            f"{location}.candidate_assessments must be a non-empty list",
        )
    resolved: list[dict[str, Any]] = []
    assessed_ids: list[str] = []
    for index, assessment in enumerate(assessments):
        item_location = f"{location}.candidate_assessments[{index}]"
        if not isinstance(assessment, Mapping) or set(assessment) != _ASSESSMENT_FIELDS:
            raise AgentJudgeValidationError(
                "invalid_candidate_assessment_fields",
                f"{item_location} has invalid fields",
            )
        step_card_id = assessment["step_card_id"]
        if not isinstance(step_card_id, str) or step_card_id not in expected_ids:
            raise AgentJudgeValidationError(
                "assessment_not_nominated",
                f"{item_location}.step_card_id is not a neutral candidate",
            )
        for field in _ASSESSMENT_FIELDS - {"step_card_id"}:
            _arbitration_text(
                assessment[field], location=f"{item_location}.{field}"
            )
        assessed_ids.append(step_card_id)
        resolved.append(dict(assessment))
    if len(set(assessed_ids)) != len(assessed_ids):
        raise AgentJudgeValidationError(
            "duplicate_candidate_assessment",
            "candidate_assessments must contain each neutral step once",
        )
    if set(assessed_ids) != expected_ids:
        raise AgentJudgeValidationError(
            "incomplete_candidate_assessments",
            "candidate_assessments must exhaust the deduplicated candidate set",
        )
    selected_id = value["selected_step_card_id"]
    if not isinstance(selected_id, str) or selected_id not in expected_ids:
        raise AgentJudgeValidationError(
            "selected_step_not_nominated",
            "arbitration selected a step outside the neutral candidate set",
        )
    _arbitration_text(
        value["selected_step_reason"],
        location=f"{location}.selected_step_reason",
    )
    selected_card = next(
        card for card in candidate_cards if card["step_card_id"] == selected_id
    )
    selected_assessment = next(
        item for item in resolved if item["step_card_id"] == selected_id
    )
    return (
        {**dict(value), "candidate_assessments": resolved},
        selected_card,
        selected_assessment,
    )


def _classification(
    value: Any,
    *,
    selected_step: int,
    atoms_by_id: Mapping[str, Mapping[str, Any]],
    location: str,
) -> tuple[dict[str, Any], Mapping[str, Any]]:
    """Classify only a same-step atom; witness/arbitration data are not inputs."""

    if not isinstance(value, Mapping) or set(value) != _CLASSIFICATION_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_classification_fields", f"{location} has invalid fields"
        )
    owner_atom_id = value["owner_atom_id"]
    if not isinstance(owner_atom_id, str) or owner_atom_id not in atoms_by_id:
        raise AgentJudgeValidationError(
            "unknown_owner_atom", f"{location}.owner_atom_id is not in the catalog"
        )
    owner_atom = atoms_by_id[owner_atom_id]
    if owner_atom["step"] != selected_step:
        raise AgentJudgeValidationError(
            "classification_atom_step_mismatch",
            "classification owner atom must belong to the frozen selected step",
        )
    try:
        error_type = ErrorType(value["predicted_error_type"])
    except (TypeError, ValueError) as error:
        raise AgentJudgeValidationError(
            "invalid_classification_taxonomy", f"{location} has unknown taxonomy"
        ) from error
    module = AgentModule(owner_atom["owner_module"])
    if not is_valid_classification(module, error_type):
        raise AgentJudgeValidationError(
            "invalid_classification_taxonomy",
            f"{location} has an illegal module/error_type pair",
        )
    if error_type.value not in owner_atom["allowed_error_types"]:
        raise AgentJudgeValidationError(
            "invalid_classification_evidence",
            "error type is not admitted by the selected same-step owner atom",
        )
    _required_text(
        value["rejected_adjacent_owner"],
        location=f"{location}.rejected_adjacent_owner",
    )
    return dict(value), owner_atom


def _classification_context_projection(case: Any, step: int) -> dict[str, Any]:
    """Return the source-bound, identity-free local context for one step."""

    item = case.judge_view.steps[step - 1]
    return {
        "step": step,
        "current_input": [
            {"role": observation.role, "text": observation.text}
            for observation in item.current_input
        ],
        "assistant_raw_output": item.assistant_raw_output,
        "tool_calls": [
            {
                "name": call.name,
                "normalized_name": call.normalized_name,
                "arguments": call.arguments,
                "partial_arguments": call.partial_arguments,
                "status": call.status,
                "results": [
                    {
                        "status": result.status,
                        "is_error": result.is_error,
                        "output": result.output,
                        "details": result.details,
                    }
                    for result in call.results
                ],
            }
            for call in item.tool_calls
        ],
        "adjacent_feedback": [
            {"role": observation.role, "text": observation.text}
            for observation in item.adjacent_feedback
        ],
        "stop_reason": item.stop_reason,
        "error_message": item.error_message,
    }


def _classification_context_sha256(case: Any, step: int) -> str:
    body = json.dumps(
        _classification_context_projection(case, step),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    ).encode("utf-8")
    return hashlib.sha256(body).hexdigest()


def _prediction_record(case: Any, candidate: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        **dict(candidate),
    }


def validate_luna_v16_unified_decision(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    decision_path: str | Path,
) -> dict[str, Any]:
    """Validate and mechanically resolve one evidence-grounded v16 decision."""

    manifest_path, cohort_path, _, case, cohort = _validate_one_case_identity(
        prediction_manifest_path,
        cohort_manifest_path,
        role="decision",
    )
    atoms = _evidence_atoms(case)
    atoms_by_id = {atom["evidence_atom_id"]: atom for atom in atoms}
    if len(atoms_by_id) != len(atoms):
        raise AssertionError("v16 evidence atom IDs are not unique")
    cards = _step_cards(case, atoms)
    cards_by_step = {card["step"]: card for card in cards}

    resolved_decision_path = Path(decision_path).expanduser().resolve()
    raw = _load_json(resolved_decision_path, role="decision")
    if not isinstance(raw, Mapping) or set(raw) != _DECISION_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_decision_fields", "decision has invalid top-level fields"
        )

    chronological, chronological_atom = _witness(
        raw["chronological_witness"],
        atoms_by_id=atoms_by_id,
        cards_by_step=cards_by_step,
        location="decision.chronological_witness",
    )
    local, local_atom = _witness(
        raw["local_witness"],
        atoms_by_id=atoms_by_id,
        cards_by_step=cards_by_step,
        location="decision.local_witness",
    )
    strategy, strategy_atom = _witness(
        raw["strategy_witness"],
        atoms_by_id=atoms_by_id,
        cards_by_step=cards_by_step,
        location="decision.strategy_witness",
    )
    if len(cards) > 1 and chronological["step"] == local["step"]:
        raise AgentJudgeValidationError(
            "candidate_steps_not_distinct",
            "multi-step chronological and local witnesses must use different steps",
        )

    candidate_cards = _candidate_cards(
        chronological=chronological,
        local=local,
        strategy=strategy,
        cards_by_step=cards_by_step,
    )
    arbitration, selected_card, selected_assessment = _arbitration(
        raw["arbitration"],
        candidate_cards=candidate_cards,
        location="decision.arbitration",
    )
    classification, owner_atom = _classification(
        raw["classification"],
        selected_step=selected_card["step"],
        atoms_by_id=atoms_by_id,
        location="decision.classification",
    )

    selected_step_atoms = tuple(
        atom for atom in atoms if atom["step"] == selected_card["step"]
    )
    selected_step_owner_atom_ids = [
        atom["evidence_atom_id"] for atom in selected_step_atoms
    ]
    prediction = _prediction_record(
        case,
        {
            "predicted_step": selected_card["step"],
            "predicted_module": owner_atom["owner_module"],
            "predicted_error_type": classification["predicted_error_type"],
            "evidence_quote": owner_atom["quote"],
            "root_cause": arbitration["selected_step_reason"],
            "causal_summary": (
                "Counterfactual correction: "
                f"{selected_assessment['counterfactual_correction']} "
                "Downstream consequence: "
                f"{selected_assessment['downstream_consequence']}"
            ),
            "rejected_adjacent_owner": classification["rejected_adjacent_owner"],
        },
    )
    if set(prediction) != AGENT_JUDGE_PREDICTION_FIELDS:
        raise AssertionError("derived v16 prediction fields changed")

    return {
        "schema_version": _DECISION_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_V16_UNIFIED_VERSION,
        "model": AGENT_JUDGE_LUNA_V16_UNIFIED_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V16_UNIFIED_REASONING_EFFORT,
        "proposal_free": True,
        "historical_predictions_visible": False,
        "same_session_hypothesis_count": 3,
        "step_owner_decoupled": True,
        "step_owner_structurally_decoupled": True,
        "evidence_witness_grounded": True,
        "witness_owner_does_not_bind_final_owner": True,
        "strategy_predecessor_parent_added": True,
        "strategy_predecessor_added": strategy["step"] > 1,
        "candidate_cards_lane_blind": True,
        "candidate_steps_distinct_when_possible": (
            chronological["step"] != local["step"]
        ),
        "classification_validator_independent_of_witness_fields": True,
        "classification_context_isolated": False,
        "classification_context_hidden": False,
        "single_response_autoregressive_visibility": True,
        "evidence_atom_schema_version": _ATOM_SCHEMA_VERSION,
        "evidence_atom_count": len(atoms),
        "evidence_atom_catalog_sha256": _atom_catalog_sha256(atoms),
        "step_card_schema_version": _STEP_SCHEMA_VERSION,
        "step_card_count": len(cards),
        "step_card_catalog_sha256": _step_catalog_sha256(cards),
        "chronological_witness": chronological,
        "local_witness": local,
        "strategy_witness": strategy,
        "witness_evidence_atom_ids": [
            chronological_atom["evidence_atom_id"],
            local_atom["evidence_atom_id"],
            strategy_atom["evidence_atom_id"],
        ],
        "candidate_step_cards": [dict(card) for card in candidate_cards],
        "candidate_step_cards_sha256": _candidate_catalog_sha256(candidate_cards),
        "selected_step_card_id": selected_card["step_card_id"],
        "derived_selection_basis": "neutral_counterfactual_arbitration",
        "arbitration": arbitration,
        "classification": classification,
        "selected_owner_atom_id": owner_atom["evidence_atom_id"],
        "classification_context_step": selected_card["step"],
        "classification_context_owner_atom_ids": selected_step_owner_atom_ids,
        "classification_context_sha256": _classification_context_sha256(
            case, selected_card["step"]
        ),
        "selected_prediction": prediction,
        "prediction_manifest_file_sha256": _file_sha256(manifest_path),
        "cohort_manifest_file_sha256": _file_sha256(cohort_path),
        "cohort_name": cohort["cohort_name"],
        "cohort_sha256": cohort["cohort_sha256"],
        "dataset_manifest_sha256": cohort["dataset_manifest_sha256"],
        "decision_sha256": _file_sha256(resolved_decision_path),
    }


def _decision_contract() -> str:
    return json.dumps(decision_output_schema(), ensure_ascii=False, indent=2)


def build_agent_judge_luna_v16_unified_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Embed one anonymous JudgeView and v16's strict step/atom catalogs."""

    del predictions_path
    _, _, _, case, _ = _validate_one_case_identity(
        prediction_manifest_path,
        cohort_manifest_path,
        role="task",
    )
    timeline = _anonymized_timeline(case)
    atoms = _evidence_atoms(case)
    cards = _step_cards(case, atoms)
    catalogs = json.dumps(
        {
            "step_catalog": _public_step_catalog(cards),
            "evidence_atom_schema_version": _ATOM_SCHEMA_VERSION,
            **_public_atom_catalog(atoms),
        },
        ensure_ascii=False,
        indent=2,
    )
    return f"""\
Run frozen protocol {AGENT_JUDGE_LUNA_V16_UNIFIED_VERSION}.

EXECUTION CONTRACT
- model: {AGENT_JUDGE_LUNA_V16_UNIFIED_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_V16_UNIFIED_REASONING_EFFORT}
- exactly one anonymous trajectory is embedded below
- do not call tools, inspect files, use the network, or use external APIs
- no prior prediction, proposal, label, score, case study, or cross-case state exists
- return exactly one JSON object matching the supplied output schema

This is one autoregressive response in one session.  Text generated for earlier
JSON fields remains visible while later fields are generated; Phase E is a
normative input restriction enforced structurally where possible, not hidden
context and not an independent classifier agent.

Complete the phases in order in this single isolated case session.  Never infer
from an opaque ID, card order, source-model name, environment, expected
distribution, benchmark memory, or an imagined gold answer.

EVIDENCE-WITNESS CONTRACT

The parent assigns deterministic case-local EA IDs to exact owner-bound source
fragments and SC IDs to trajectory steps.  In Phases A-C, selecting an EA is
only a mechanically grounded witness that nominates that EA's Step.  Its
owner_module and defect_basis do not freeze, favor, forbid, or otherwise bind
the final owner/type.  In particular, a strict System witness may anchor a
Step whose true root owner is Memory, Reflection, Planning, or Action, and an
agent witness may anchor a Step whose independently proven root is System.
Never copy or emit evidence text; the parent resolves the raw quote.

Witness-level observable_system_boundary and a System witness atom must agree
bidirectionally.  This only certifies the witness.  Final System classification
is independently legal only through an exact same-step System atom and one of
that atom's allowed_error_types.  Strict System atoms arise only from an
independent typed external failure or an explicit typed execution stop/limit.
Ordinary task text, trace length, an unresolved final step, user-side invalid
parameters, and nested payload prose do not create System evidence.

PHASE A — EVIDENCE-GROUNDED CHRONOLOGICAL WITNESS

Scan from Step 1 and nominate the earliest mature causal error whose correction
materially redirects failure.  Check Memory/Reflection state fidelity,
Planning constraints and prerequisites, Action-plan/interface agreement, and
strict System facts at each step.  A reasonable first probe and one
evidence-motivated confirmation are not mature repetition.  Select an exact EA
at the nominated Step as a literal witness, without freezing final ownership.

PHASE B — EVIDENCE-GROUNDED DIFFERENT-STEP LOCAL WITNESS

Independently find the strongest locally attributable material defect.  Prefer
a literal false state/result/progress claim, task conflict, missing
prerequisite, plan/action contract breach, mechanical invocation defect,
qualified mature repetition, or strict external failure over generic
hindsight.  On a multi-step trace this witness must use a different Step from
Phase A.  Select an exact EA at that Step; its displayed owner remains only the
witness source and does not bind final classification.

PHASE C — STRATEGY WITNESS

Independently locate the strategy decision or execution boundary whose
counterfactual correction most directly changes the failure chain.  Distinguish
a genuinely defective strategy from a downstream retry, answer, or action.
Select an exact EA at that Step as grounding only.  It may coincide with either
earlier witness.  If the strategy Step is C>1, the parent unconditionally adds
Step C-1 as a neutral candidate; you do not decide whether C-1 qualifies and
you do not output a predecessor field.

PHASE D — LANE-BLIND UNIFORM COUNTERFACTUAL ARBITRATION

Construct the union of the three witness Steps and the parent-derived C-1 Step,
then deduplicate equal SC IDs.  candidate_assessments must contain every unique
candidate exactly once.  The cards are neutral: after forming the set, discard
which witness nominated a card, nomination count, witness atom owner/basis,
witness prose, and list order.  Do not mention or use lane/source provenance in
an assessment or selection.

For every candidate, fill all five owner analyses and the same counterfactual
questions.  Each owner analysis must say whether that module has a concrete
same-step defect; absence may be stated plainly but no field may be skipped.
Ask whether correcting only this Step's earliest correctable defect, while
holding prior facts fixed, prevents or materially redirects the downstream
failure.  Compare it with every other card for causal priority, literal
support, and minimal correction.  Select exactly one SC ID.  There is no
root_status eligibility label and no chronological, local, strategy, earlier,
or later default.  Do not output selection_basis or a selected lane; the parent
derives the fixed basis neutral_counterfactual_arbitration.

PHASE E — ISOLATED OWNER/TYPE CLASSIFICATION AT THE FROZEN STEP

After selecting the Step, treat all witness IDs, bases, reasons, corrections,
consequences, nomination paths, and arbitration prose as unavailable.  The
only admissible classification input is (1) that frozen Step's local timeline
record—its current input, assistant output, calls/results, adjacent feedback,
and terminal facts—and (2) EA cards whose printed step equals the frozen Step.
Select one such owner_atom_id and one of that exact atom's
allowed_error_types.  classification may report only owner_atom_id,
predicted_error_type, and rejected_adjacent_owner; never report step, module,
quote, source, witness, basis, lane, or arbitration text.

Memory owns lost/invented state; Reflection owns false feedback, progress, or
cause interpretation; Planning owns strategy/prerequisite defects when
upstream state is sound; Action owns departure from an adequate plan or a
mechanical invocation defect; System owns only strict admitted evidence.  A
faithful action does not steal its plan's defect.  Nested tags use innermost
leaf ownership.  Planning residual is confined to an explicit Planning/think
span after foreign nested owners are removed; top-level residual is never
Planning.  Isolated malformed action blocks remain eligible Action evidence
for every legal Action type without pre-deciding the type.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

OUTPUT CONTRACT
{_decision_contract()}

PARENT-BUILT STEP AND EVIDENCE CATALOGS
{catalogs}

GOLD-FREE ANONYMOUS JUDGEVIEW
{timeline}
"""


def validate_agent_judge_luna_v16_unified_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    """Validate final predictions against exact v16 owner-bound atoms."""

    audit = _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_leaf_and_residual_owner_source_resolver,
    )
    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    output_path = Path(predictions_path).expanduser().resolve()
    _, cases = load_prediction_manifest(manifest_path)
    raw_predictions = _load_json(output_path, role="predictions")
    if not isinstance(raw_predictions, list) or len(raw_predictions) != len(cases):
        raise AssertionError("shared v16 validation did not freeze prediction count")

    catalog_records: list[dict[str, Any]] = []
    for index, (case, prediction) in enumerate(
        zip(cases, raw_predictions, strict=True), 1
    ):
        if not isinstance(prediction, Mapping):
            raise AssertionError("shared v16 validation did not freeze records")
        atoms = _evidence_atoms(case)
        matches = [
            atom
            for atom in atoms
            if atom["step"] == prediction["predicted_step"]
            and atom["owner_module"] == prediction["predicted_module"]
            and atom["quote"] == prediction["evidence_quote"]
            and prediction["predicted_error_type"] in atom["allowed_error_types"]
        ]
        if len(matches) != 1:
            raise AgentJudgeValidationError(
                "invalid_evidence_atom_binding",
                (
                    f"predictions[{index - 1}] does not exactly match one "
                    "v16 owner-bound evidence atom"
                ),
            )
        selected_atom = matches[0]
        cards = _step_cards(case, atoms)
        catalog_records.append(
            {
                "case_index": index,
                "trajectory_id": case.trajectory_id,
                "atom_count": len(atoms),
                "catalog_sha256": _atom_catalog_sha256(atoms),
                "step_catalog_sha256": _step_catalog_sha256(cards),
                "selected_evidence_atom_id": selected_atom["evidence_atom_id"],
                "selected_step_card_id": (
                    f"{_STEP_PREFIX}{selected_atom['step']:04d}"
                ),
            }
        )
    catalog_set_sha256 = hashlib.sha256(
        json.dumps(
            catalog_records,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_V16_UNIFIED_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_V16_UNIFIED_VERSION,
        "model": AGENT_JUDGE_LUNA_V16_UNIFIED_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V16_UNIFIED_REASONING_EFFORT,
        "proposal_free": True,
        "historical_predictions_visible": False,
        "same_session_hypothesis_count": 3,
        "label_pair_routing_used": False,
        "nested_module_spans_supported": True,
        "step_owner_decoupled": True,
        "step_owner_structurally_decoupled": True,
        "evidence_witness_grounded": True,
        "witness_owner_does_not_bind_final_owner": True,
        "strategy_predecessor_parent_added": True,
        "candidate_cards_lane_blind": True,
        "classification_context_hidden": False,
        "evidence_atom_binding": True,
        "all_predictions_match_exact_evidence_atom": True,
        "evidence_atom_catalogs": catalog_records,
        "evidence_atom_catalog_set_sha256": catalog_set_sha256,
        "model_copies_boundary_quote": False,
        "validation_method": (
            "Gold-free exact JSON, cohort/manifest order, trajectory identity, "
            "step range, taxonomy pair, selected-owner evidence, and exact "
            "v16 evidence-witness/neutral-step/owner-atom checks."
        ),
    }


__all__ = [
    "AGENT_JUDGE_LUNA_V16_UNIFIED_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_V16_UNIFIED_MODEL",
    "AGENT_JUDGE_LUNA_V16_UNIFIED_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_V16_UNIFIED_VERSION",
    "DECISION_FILENAME",
    "build_agent_judge_luna_v16_unified_task",
    "build_luna_v16_evidence_atom_catalog",
    "decision_output_schema",
    "runtime_conformance_decision",
    "validate_agent_judge_luna_v16_unified_predictions",
    "validate_luna_v16_unified_decision",
]

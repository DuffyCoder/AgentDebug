"""Luna GAIA v3.65: v3.20 plus one outcome-conditioned global proposal duel."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions
from .taxonomy import AgentModule, taxonomy_prompt


AGENT_JUDGE_LUNA_GAIA_V3_65_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.65-clean-v3.20-"
    "outcome-conditioned-global-boundary-proposal-duel"
)
AGENT_JUDGE_LUNA_GAIA_V3_65_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_65_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_65_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases used only by the generic three-stage orchestration code.
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_65_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_65_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_65_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_65_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_65_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_65_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_65_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
PANEL_FILENAME = "global-causal-proposal.json"
PANELS_FILENAME = "global-causal-proposals.json"
PANEL_AUDIT_FILENAME = "global-causal-proposal-audit.json"
SELECTOR_FILENAME = "anchor-proposal-duel.json"
SELECTORS_FILENAME = "anchor-proposal-duels.json"
SELECTOR_AUDIT_FILENAME = "anchor-proposal-duel-audit.json"

MODULES = tuple(module.value for module in AgentModule)
PANEL_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "reviewed_steps",
    "reviewed_modules",
    "module_local_summary",
    "owner_local_error_count",
    "proposal_status",
    "proposal_step",
    "boundary_class",
    "proposal_prediction",
    "probe_assessment",
    "recovery_assessment",
    "chronology_comparison",
    "critical_boundary_basis",
    "selection_falsifier",
)
PANEL_STATUSES = frozenset({"candidate", "none"})
BOUNDARY_CLASSES = frozenset(
    {
        "none",
        "state_truth",
        "constraint_alignment",
        "capability_commitment",
        "post_feedback_recommitment",
        "terminal_abandonment",
    }
)
SELECTOR_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "anchor_prediction_sha256",
    "anchor_ledger_sha256",
    "anchor_checkpoint_sha256",
    "proposal_sha256",
    "anchor_step",
    "proposal_step",
    "decision",
    "anchor_classification",
    "proposal_classification",
    "anchor_veto_evidence_step",
    "anchor_veto_evidence_quote",
    "anchor_contribution_witness_step",
    "anchor_contribution_witness_quote",
    "frozen_step",
    "selected_prediction_sha256",
    "selected_prediction",
    "anchor_assessment",
    "proposal_assessment",
    "timeline_comparison",
    "decision_basis",
    "rejected_alternative_basis",
    "selection_falsifier",
)
SELECTOR_DECISIONS = frozenset({"keep_anchor", "select_proposal"})
ANCHOR_CLASSES = frozenset(
    {
        "critical_root",
        "contributing_probe",
        "normal_tool_failure",
        "recovered_defect",
        "noncritical_predecessor",
        "faithful_propagation",
        "downstream_symptom",
        "uncertain",
    }
)
OVERRIDE_ANCHOR_CLASSES = ANCHOR_CLASSES - {"critical_root", "uncertain"}
PROPOSAL_CLASSES = frozenset(
    {
        "absent",
        "critical_root",
        "reasonable_probe",
        "normal_tool_failure",
        "recovered_defect",
        "mechanical_defect",
        "faithful_propagation",
        "downstream_symptom",
        "uncertain",
    }
)
PROBE_ASSESSMENT_PREFIX = re.compile(
    r"^proposal_probe_status=(reasonable|material_error|not_applicable); "
    r"task_contribution=(zero|observed|not_applicable); "
    r"continuation_effect=(failed_path|constructive_new_route|not_applicable); "
    r"local_repair=(redirects_owned_path|does_not_redirect|not_applicable);"
)


_PROPOSAL_RULES = """\
ANCHOR-BLIND OUTCOME-CONDITIONED GLOBAL BOUNDARY — ONE CANDIDATE MAXIMUM

The incumbent anchor is intentionally unavailable. Do not infer or reconstruct
it. Work in two internal passes, but export only one bounded proposal.

PASS A — COMPLETE LOCAL OWNER REVIEW

Inspect every Canonical Step in chronology and separately test Memory,
Reflection, Planning, Action, and System. Record the review coverage in
`reviewed_steps`, `reviewed_modules`, and one compact summary per module.
Locally concrete errors include task-material false or lost state, false
outcome/progress interpretation, explicit constraint or target mismatch,
incapable evidence commitments, post-feedback unchanged recommitment, and
eligible external execution failure. A System error requires a well-formed,
task-relevant call defeated by an external execution limit.

PASS B — GLOBAL CRITICAL BOUNDARY

From the local findings freeze at most one complete legal prediction: the first
observable Agent/System-owned error that materially changes the path toward
failure under the benchmark boundary. Do not select the first local error by
default, do not vote by module, and do not prefer Planning, later position,
severity, persistence, repetition count, or forceful prose.

A probe is reasonable only when its concrete target and route are well matched
to an immediate uncertainty and can expose a necessary identifier, fact,
source, page, text, or route. Initial position alone does not protect a probe.
A broad, irrelevant, source-violating, target-mismatched, or intrinsically
incapable first commitment may already be the critical Step; do not require a
prior failure or a later consequence to call its literal defect material.

Conversely, do not project the final proof predicate onto an intermediate
discovery action: a text or search route can be a reasonable probe when it can
actually supply a necessary intermediate even if it cannot prove the final
answer. A merely successful call or hypothetical usefulness is not enough;
judge the literal target, interface, returned content, and immediate subgoal.

OUTCOME-CONDITIONED PROBE MATURITY

Judge probe status twice: first from the decision-time target/route, then from
the observed result and the next task-material state. Ex-ante reasonableness is
not a permanent veto. A probe becomes a mature benchmark boundary when literal
chronology establishes all three relations:

1. `task_contribution=zero`: its actual result supplies no necessary fact,
   identifier, source lead, constraint resolution, or reusable route for the
   immediate subgoal;
2. `continuation_effect=failed_path`: the next Memory/Reflection/Plan either
   drops or misreads required state, repeats the same unresolved predicate, or
   pivots on an unsupported substitute because this probe did not advance it;
3. `local_repair=redirects_owned_path`: repairing only this Step's target,
   route, interpretation, or retained state would redirect that immediate
   failed subpath. It need not guarantee final task completion or erase an
   independent earlier/later error.

Do not apply this rule to an ordinary negative result that nevertheless yields
a reusable lead or is followed by a materially new evidence route using that
lead. Do not call the tool outcome itself an Agent error: select the current
Agent-authored Planning/Action or result-to-Memory/Reflection handoff that owns
the zero-contribution failed-path relation. Compare the immediately preceding
and following plausible boundaries and freeze the earliest mature owner, not
the most explicit later symptom.

Reject normal negative/empty results, recovered defects, mechanical repairs,
faithful propagation, locally improvable but noncritical behavior, and
downstream symptoms. When a repeated strategy is selected, verify that the
prior observation already made the same immediate predicate/evidence family
unproductive and that no earlier material commitment wins. When state is
selected, bind the unsupported/lost/misread fact to the current or next
decision. When terminal abandonment is selected, verify no earlier unrecovered
critical boundary owns the failure.

Emit `none` only if no concrete Agent/System error survives after full review;
uncertainty between plausible Steps is not a reason to emit a candidate pool.
Choose the one better-supported critical boundary and state the strongest
falsifier. Never access gold, labels, old predictions, case reports, or source
identity priors.
"""


_DUEL_RULES = """\
BOUNDED ANCHOR/PROPOSAL DUEL — EXACT COPY, DEFAULT ANCHOR

The two inputs are immutable. Select exactly the clean v3.20 anchor or the one
anchor-blind proposal when present. Never invent a third Step, repair fields,
merge predictions, or use provenance as evidence. When both name the same Step,
keep the anchor because the Step boundary already agrees. Under genuinely
unresolved evidence, keep the anchor.

Compare the two boundaries on literal chronology:

1. protect a direct unrecovered constraint violation, target/Action mismatch,
   task-material false state, incapable commitment, eligible execution impact,
   or earliest failure-causing commitment;
2. reject normal tool failure, recovered defect, mechanical predecessor,
   faithful propagation, and downstream symptom;
3. do not prefer an initial or later Step merely because of position;
4. do not make `initial_probe` an automatic veto. Classify the anchor as
   `contributing_probe` only when a literal observed witness shows that its path
   actually supplied a necessary identifier, fact, source, route, or other
   task-material item. A generic/empty result, successful transport, or
   hypothetical possible usefulness is not a contribution witness;
5. a proposal can displace a contributing probe only if it is independently
   material after that observed contribution. For other noncritical anchor
   classes, quote the literal recovery, failure ownership, predecessor, or
   symptom evidence that vetoes the anchor;
6. reject a proposal that is merely a later repetition, vivid symptom, or local
   defect when the anchor already owns the causal boundary.

For every result begin `anchor_assessment` exactly:
`anchor_status=<class>; contribution_witness=<present|not_applicable>; `
and begin `proposal_assessment` exactly:
`proposal_status=<class>; `.

For `select_proposal`, proposal_status must be `critical_root`; anchor_status
must be an allowed noncritical class; anchor veto evidence is mandatory. If
anchor_status is `contributing_probe`, a separate literal contribution witness
is mandatory and contribution_witness must be `present`. For all other cases
contribution_witness is `not_applicable`. Keep-anchor records have all veto and
contribution witness fields null.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_65_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_65_clean_v3p20_outcome_conditioned_global_boundary_proposal_duel",
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py",
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_65_clean_v3p20_outcome_conditioned_global_boundary_proposal_duel.py",
        )
    )


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_65_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_65_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_65_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one outcome-conditioned global boundary proposal duel",
    }


def _boundary(
    *, manifest: Path, cohort: Path, reads: Sequence[Path], output: Path
) -> str:
    read_lines = "\n".join(f"- {path.name}" for path in reads) or "- none"
    return f"""\
IMMUTABLE EXECUTION CONFIGURATION
- model: {AGENT_JUDGE_LUNA_GAIA_V3_65_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_65_REASONING_EFFORT}
- one isolated case; fresh session; no cross-case state or prior predictions
- external LLM/API/network calls: forbidden
- scoring or gold-label access: forbidden

INPUT/OUTPUT BOUNDARY
- prediction manifest: {manifest.name}
- prediction manifest file sha256: {shared._file_sha256(manifest)}
- cohort manifest: {cohort.name}
- cohort manifest file sha256: {shared._file_sha256(cohort)}
- permitted frozen stage inputs:
{read_lines}
- write the sole stage artifact only to: {output.name}

Read only those exact inputs plus this v3.65 protocol source, the v3.20
protocol source, and `agentdebug/diagnostics/taxonomy.py`. Do not inspect
directories or infer from trajectory/source-model/environment names. Never
read labels, metrics, scored artifacts, experiment documents, proposal files
other than the permitted current input, old predictions, cached replies, case
studies, git history, or external resources.
"""


def build_anchor_task(*paths: str | Path) -> str:
    """Use exactly v3.20 anchor semantics, with identity retagged."""

    resolved = [Path(path).expanduser().resolve() for path in paths]
    attempt_dir = resolved[-1].parent
    task = _rewrite_identity(parent.build_anchor_task(*resolved))
    task = task.replace(f"{attempt_dir}/", "")
    root = Path(__file__).resolve().parents[2]
    task = task.replace(f"cd {root}\nPYTHONPATH=. ", f"PYTHONPATH={root} ")
    return task


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths), policy="unchanged_v3_20_anchor")


def _validate_optional_literal(
    *, case: Any, step: Any, quote: Any, location: str
) -> None:
    if step is None and quote is None:
        return
    if isinstance(step, bool) or not isinstance(step, int):
        shared._fail("invalid_duel_literal_step", location)
    if step < 1 or step > len(case.judge_view.steps):
        shared._fail("invalid_duel_literal_step", location)
    shared._nonempty_text(quote, location=f"{location}.quote", maximum=1800)
    if not any(quote in source for source in shared._packet_sources(case, step)):
        shared._fail("invalid_duel_literal_quote", location)


def _validate_panel_record(raw: Any, *, case: Any, location: str) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != PANEL_FIELDS:
        shared._fail("invalid_global_causal_proposal_schema", location)
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
    ):
        shared._fail("global_causal_proposal_identity_mismatch", location)
    if raw["reviewed_steps"] != list(range(1, len(case.judge_view.steps) + 1)):
        shared._fail("incomplete_global_proposal_step_coverage", location)
    if raw["reviewed_modules"] != list(MODULES):
        shared._fail("incomplete_global_proposal_module_coverage", location)
    summaries = raw["module_local_summary"]
    if not isinstance(summaries, dict) or tuple(summaries) != MODULES:
        shared._fail("invalid_global_proposal_module_summary", location)
    for module, summary in summaries.items():
        shared._nonempty_text(
            summary, location=f"{location}.module_local_summary.{module}", maximum=1800
        )
    count = raw["owner_local_error_count"]
    if isinstance(count, bool) or not isinstance(count, int) or count < 0:
        shared._fail("invalid_global_proposal_local_error_count", location)
    if raw["proposal_status"] not in PANEL_STATUSES:
        shared._fail("invalid_global_proposal_status", location)
    if raw["boundary_class"] not in BOUNDARY_CLASSES:
        shared._fail("invalid_global_proposal_boundary_class", location)
    for field in (
        "probe_assessment",
        "recovery_assessment",
        "chronology_comparison",
        "critical_boundary_basis",
        "selection_falsifier",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3200)
    if raw["proposal_status"] == "none":
        if (
            raw["proposal_step"] is not None
            or raw["proposal_prediction"] is not None
            or raw["boundary_class"] != "none"
            or count != 0
        ):
            shared._fail("nonempty_global_none_proposal", location)
        expected_probe_status = "not_applicable"
    else:
        if raw["boundary_class"] == "none" or count < 1:
            shared._fail("empty_global_candidate_basis", location)
        prediction = shared._validate_prediction_record(
            raw["proposal_prediction"], case=case, location=f"{location}.proposal"
        )
        if raw["proposal_step"] != prediction["predicted_step"]:
            shared._fail("global_proposal_step_mismatch", location)
        expected_probe_status = None
    match = PROBE_ASSESSMENT_PREFIX.match(raw["probe_assessment"])
    if match is None or (
        expected_probe_status is not None and match.group(1) != expected_probe_status
    ):
        shared._fail("missing_global_proposal_probe_prefix", location)
    relation = match.groups()
    allowed_relations = {
        "material_error": (
            "material_error",
            "zero",
            "failed_path",
            "redirects_owned_path",
        ),
        "reasonable": (
            "reasonable",
            "observed",
            "constructive_new_route",
            "does_not_redirect",
        ),
        "not_applicable": (
            "not_applicable",
            "not_applicable",
            "not_applicable",
            "not_applicable",
        ),
    }
    if relation != allowed_relations[relation[0]]:
        shared._fail("invalid_outcome_conditioned_probe_relation", location)
    return raw


def validate_panel(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    panel_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    panel_file, raw = shared._load_artifact(panel_path, role="global causal proposal")
    panel = shared._one_record(raw, role="global causal proposal")
    _validate_panel_record(panel, case=case, location="proposal[0]")
    return _retag(
        {
            "schema_version": "agentdebug.anchor-blind-global-causal-proposal-audit.v1",
            "stage": "anchor_blind_global_causal_proposal",
            "gold_free_validation": True,
            "case_count": 1,
            "anchor_visible": False,
            "complete_step_coverage": True,
            "complete_module_coverage": True,
            "maximum_candidates": 1,
            "proposal_status": panel["proposal_status"],
            "boundary_class": panel["boundary_class"],
            "input_sha256": {
                "prediction_manifest": shared._file_sha256(manifest),
                "cohort": shared._file_sha256(cohort),
            },
            "output_sha256": {PANEL_FILENAME: shared._file_sha256(panel_file)},
        },
        policy="anchor_blind_module_first_global_causal_proposal",
    )


def build_panel_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    panel_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    output = Path(panel_path).expanduser().resolve()
    shared._assert_safe_path(output, role="global proposal output", is_output=True)
    audit = output.parent / PANEL_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_65_clean_v3p20_outcome_conditioned_global_boundary_proposal_duel",
            "--compact-validate",
            "panel",
            manifest.name,
            cohort.name,
            output.name,
            audit.name,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    command = command.replace(
        "PYTHONPATH=. ", f"PYTHONPATH={Path(__file__).resolve().parents[2]} "
    )
    prediction_schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        "predicted_step": "selected Step",
        "predicted_module": "selected module",
        "predicted_error_type": "valid taxonomy type",
        "evidence_quote": "literal evidence owned by selected Step/module",
        "root_cause": "specific local root cause",
        "causal_summary": "why this boundary materially changes the failed path",
        "rejected_adjacent_owner": "strongest adjacent alternative and why rejected",
    }
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "reviewed_steps": list(range(1, len(case.judge_view.steps) + 1)),
        "reviewed_modules": list(MODULES),
        "module_local_summary": {module: "compact complete-review result" for module in MODULES},
        "owner_local_error_count": "number of concrete local errors considered",
        "proposal_status": "candidate or none",
        "proposal_step": "integer Step or null",
        "boundary_class": "one allowed boundary class",
        "proposal_prediction": prediction_schema,
        "probe_assessment": (
            "proposal_probe_status=<reasonable|material_error|not_applicable>; "
            "task_contribution=<zero|observed|not_applicable>; "
            "continuation_effect=<failed_path|constructive_new_route|not_applicable>; "
            "local_repair=<redirects_owned_path|does_not_redirect|not_applicable>; evidence"
        ),
        "recovery_assessment": "explicit recovery/mechanical/propagation/symptom veto audit",
        "chronology_comparison": "proposal versus every plausible earlier/later boundary",
        "critical_boundary_basis": "why this is the single benchmark-critical boundary",
        "selection_falsifier": "strongest concrete argument against this selection",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_65_VERSION} stage 2/3: anchor-blind global proposal.

{_boundary(manifest=manifest, cohort=cohort, reads=(), output=output)}

{_PROPOSAL_RULES}

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

For `none`, set proposal_step/proposal_prediction to null, boundary_class to
`none`, owner_local_error_count to 0, and begin probe_assessment exactly
`proposal_probe_status=not_applicable; task_contribution=not_applicable; `
`continuation_effect=not_applicable; local_repair=not_applicable;`. Every
candidate prediction must use the standard fields in the displayed order and
literal owner evidence.
After writing, run exactly from the current attempt directory:
{command}
Complete only when it exits zero and creates {audit.name}.
"""


def _load_anchor_bundle(
    manifest: Path,
    cohort: Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> tuple[Path, Path, Path, dict[str, Any], dict[str, Any], dict[str, Any]]:
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    anchor, ledger, checkpoint = shared._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    parent._validate_packet_state_ledgers(ledger_file)
    return anchor_file, ledger_file, checkpoint_file, anchor, ledger, checkpoint


def _validate_selector_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    panel: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != SELECTOR_FIELDS:
        shared._fail("invalid_anchor_proposal_duel_schema", location)
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
    ):
        shared._fail("anchor_proposal_duel_identity_mismatch", location)
    bindings = {
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "proposal_sha256": shared._stable_sha256(panel),
    }
    if any(raw[key] != value for key, value in bindings.items()):
        shared._fail("anchor_proposal_duel_hash_mismatch", location)
    proposal = panel["proposal_prediction"]
    proposal_step = panel["proposal_step"]
    if raw["anchor_step"] != anchor["predicted_step"] or raw["proposal_step"] != proposal_step:
        shared._fail("anchor_proposal_duel_step_binding_mismatch", location)
    if raw["decision"] not in SELECTOR_DECISIONS:
        shared._fail("invalid_anchor_proposal_duel_decision", location)
    if raw["anchor_classification"] not in ANCHOR_CLASSES:
        shared._fail("invalid_anchor_duel_classification", location)
    if raw["proposal_classification"] not in PROPOSAL_CLASSES:
        shared._fail("invalid_proposal_duel_classification", location)
    for field in (
        "anchor_assessment",
        "proposal_assessment",
        "timeline_comparison",
        "decision_basis",
        "rejected_alternative_basis",
        "selection_falsifier",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3400)
    anchor_prefix = (
        f"anchor_status={raw['anchor_classification']}; contribution_witness="
    )
    proposal_prefix = f"proposal_status={raw['proposal_classification']}; "
    if not raw["anchor_assessment"].startswith(anchor_prefix):
        shared._fail("missing_anchor_duel_assessment_prefix", location)
    if not raw["proposal_assessment"].startswith(proposal_prefix):
        shared._fail("missing_proposal_duel_assessment_prefix", location)
    selected = shared._validate_prediction_record(
        raw["selected_prediction"], case=case, location=f"{location}.selected"
    )
    if raw["selected_prediction_sha256"] != shared._stable_sha256(selected):
        shared._fail("anchor_proposal_duel_selected_hash_mismatch", location)
    if raw["frozen_step"] != selected["predicted_step"]:
        shared._fail("anchor_proposal_duel_frozen_step_mismatch", location)

    witness_fields = (
        "anchor_veto_evidence_step",
        "anchor_veto_evidence_quote",
        "anchor_contribution_witness_step",
        "anchor_contribution_witness_quote",
    )
    if raw["decision"] == "keep_anchor":
        if selected != anchor or any(raw[field] is not None for field in witness_fields):
            shared._fail("anchor_proposal_duel_keep_copy_mismatch", location)
        expected_witness = "not_applicable"
        if proposal is None and raw["proposal_classification"] != "absent":
            shared._fail("missing_absent_proposal_classification", location)
    else:
        if proposal is None or proposal_step == anchor["predicted_step"]:
            shared._fail("anchor_proposal_duel_selected_absent_or_same_step", location)
        if selected != proposal or raw["proposal_classification"] != "critical_root":
            shared._fail("anchor_proposal_duel_proposal_copy_mismatch", location)
        if raw["anchor_classification"] not in OVERRIDE_ANCHOR_CLASSES:
            shared._fail("anchor_proposal_duel_lacks_anchor_veto", location)
        _validate_optional_literal(
            case=case,
            step=raw["anchor_veto_evidence_step"],
            quote=raw["anchor_veto_evidence_quote"],
            location=f"{location}.anchor_veto",
        )
        if raw["anchor_veto_evidence_step"] is None:
            shared._fail("anchor_proposal_duel_missing_veto_evidence", location)
        if raw["anchor_classification"] == "contributing_probe":
            _validate_optional_literal(
                case=case,
                step=raw["anchor_contribution_witness_step"],
                quote=raw["anchor_contribution_witness_quote"],
                location=f"{location}.contribution_witness",
            )
            if raw["anchor_contribution_witness_step"] is None:
                shared._fail("anchor_probe_missing_positive_contribution_witness", location)
            expected_witness = "present"
        else:
            if (
                raw["anchor_contribution_witness_step"] is not None
                or raw["anchor_contribution_witness_quote"] is not None
            ):
                shared._fail("inactive_anchor_contribution_witness", location)
            expected_witness = "not_applicable"
    expected_anchor_prefix = anchor_prefix + expected_witness + "; "
    if not raw["anchor_assessment"].startswith(expected_anchor_prefix):
        shared._fail("invalid_anchor_contribution_witness_prefix", location)
    return raw


def validate_selector(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    panel_path: str | Path,
    selector_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger, checkpoint = bundle[3:]
    panel_file, panel_raw = shared._load_artifact(panel_path, role="global causal proposal")
    panel = shared._one_record(panel_raw, role="global causal proposal")
    _validate_panel_record(panel, case=case, location="proposal[0]")
    selector_file, selector_raw = shared._load_artifact(
        selector_path, role="anchor proposal duel"
    )
    selector = shared._one_record(selector_raw, role="anchor proposal duel")
    _validate_selector_record(
        selector,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        panel=panel,
        location="duel[0]",
    )
    return _retag(
        {
            "schema_version": "agentdebug.anchor-proposal-duel-audit.v1",
            "stage": "bounded_anchor_proposal_duel",
            "gold_free_validation": True,
            "case_count": 1,
            "decision": selector["decision"],
            "selected_prediction_exact_copy": True,
            "maximum_total_predictions": 2,
            "positive_contribution_witness_binding": True,
            "input_sha256": {
                "anchor": shared._file_sha256(anchor_file),
                "ledger": shared._file_sha256(ledger_file),
                "checkpoint": shared._file_sha256(checkpoint_file),
                "proposal": shared._file_sha256(panel_file),
            },
            "output_sha256": {SELECTOR_FILENAME: shared._file_sha256(selector_file)},
        },
        policy="bounded_anchor_global_proposal_exact_copy_duel",
    )


def build_selector_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    panel_path: str | Path,
    selector_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger, checkpoint = bundle[3:]
    panel_file, panel_raw = shared._load_artifact(panel_path, role="global causal proposal")
    panel = shared._one_record(panel_raw, role="global causal proposal")
    _validate_panel_record(panel, case=case, location="proposal[0]")
    output = Path(selector_path).expanduser().resolve()
    shared._assert_safe_path(output, role="anchor proposal duel output", is_output=True)
    audit = output.parent / SELECTOR_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_65_clean_v3p20_outcome_conditioned_global_boundary_proposal_duel",
            "--compact-validate",
            "selector",
            manifest.name,
            cohort.name,
            anchor_file.name,
            ledger_file.name,
            checkpoint_file.name,
            panel_file.name,
            output.name,
            audit.name,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    command = command.replace(
        "PYTHONPATH=. ", f"PYTHONPATH={Path(__file__).resolve().parents[2]} "
    )
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "proposal_sha256": shared._stable_sha256(panel),
        "anchor_step": anchor["predicted_step"],
        "proposal_step": panel["proposal_step"],
        "decision": "keep_anchor or select_proposal",
        "anchor_classification": "one allowed anchor class",
        "proposal_classification": "one allowed proposal class",
        "anchor_veto_evidence_step": "literal veto Step or null",
        "anchor_veto_evidence_quote": "literal veto quote or null",
        "anchor_contribution_witness_step": "literal contribution Step or null",
        "anchor_contribution_witness_quote": "literal contribution quote or null",
        "frozen_step": "selected prediction Step",
        "selected_prediction_sha256": "stable hash of exact selected prediction",
        "selected_prediction": "exact anchor or proposal prediction object",
        "anchor_assessment": "anchor_status=<class>; contribution_witness=<present|not_applicable>; assessment",
        "proposal_assessment": "proposal_status=<class>; assessment",
        "timeline_comparison": "literal pairwise chronology",
        "decision_basis": "why the exact selected boundary wins",
        "rejected_alternative_basis": "why the other boundary loses",
        "selection_falsifier": "strongest concrete argument against the decision",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_65_VERSION} stage 3/3: bounded proposal duel.

{_boundary(manifest=manifest, cohort=cohort, reads=(anchor_file, ledger_file, checkpoint_file, panel_file), output=output)}

{_DUEL_RULES}

The immutable anchor Step is {anchor['predicted_step']}; the anchor-blind
proposal Step is {panel['proposal_step']}. For keep_anchor, exact-copy the
anchor and set all four veto/contribution witness fields to null. For
select_proposal, exact-copy the proposal and satisfy every witness binding.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

Compute content hashes from sorted compact UTF-8 JSON. After writing, run exactly
from the current attempt directory:
{command}
Complete only when it exits zero and creates {audit.name}.
"""


def _validate_aggregate(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(prediction_manifest_path, cohort_manifest_path)
    root = Path(predictions_path).expanduser().resolve().parent
    names = (
        ANCHOR_PREDICTIONS_FILENAME,
        ANCHOR_LEDGER_AGGREGATE_FILENAME,
        ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        PANELS_FILENAME,
        SELECTORS_FILENAME,
    )
    loaded = {
        name: shared._load_artifact(root / name, role=f"merged {name}")[1]
        for name in names
    }
    if any(
        not isinstance(value, list) or len(value) != len(cases)
        for value in loaded.values()
    ):
        shared._fail("invalid_global_proposal_aggregate_count", "all artifacts need all cases")
    finals = shared._load_artifact(predictions_path, role="merged predictions")[1]
    if not isinstance(finals, list) or len(finals) != len(cases):
        shared._fail("invalid_global_proposal_prediction_count", "predictions need all cases")
    proposal_statuses: Counter[str] = Counter()
    boundary_classes: Counter[str] = Counter()
    decisions: Counter[str] = Counter()
    anchor_classes: Counter[str] = Counter()
    for index, case in enumerate(cases):
        location = f"global_proposal_merged[{index}]"
        anchor = loaded[ANCHOR_PREDICTIONS_FILENAME][index]
        ledger = loaded[ANCHOR_LEDGER_AGGREGATE_FILENAME][index]
        checkpoint = loaded[ANCHOR_CHECKPOINT_AGGREGATE_FILENAME][index]
        panel = loaded[PANELS_FILENAME][index]
        selector = loaded[SELECTORS_FILENAME][index]
        shared._validate_prediction_record(anchor, case=case, location=f"{location}.anchor")
        if (
            ledger.get("trajectory_id") != case.trajectory_id
            or ledger.get("selected_step") != anchor["predicted_step"]
            or checkpoint.get("trajectory_id") != case.trajectory_id
            or checkpoint.get("predicted_step") != anchor["predicted_step"]
        ):
            shared._fail("global_proposal_anchor_sidecar_mismatch", location)
        _validate_panel_record(panel, case=case, location=f"{location}.proposal")
        _validate_selector_record(
            selector,
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            panel=panel,
            location=f"{location}.duel",
        )
        final = shared._validate_prediction_record(
            finals[index], case=case, location=f"{location}.final"
        )
        if final != selector["selected_prediction"]:
            shared._fail("global_proposal_final_copy_mismatch", location)
        proposal_statuses[panel["proposal_status"]] += 1
        boundary_classes[panel["boundary_class"]] += 1
        decisions[selector["decision"]] += 1
        anchor_classes[selector["anchor_classification"]] += 1
    return {
        "required": True,
        "valid": True,
        "anchor_blind_panel": True,
        "complete_step_and_module_coverage": True,
        "maximum_specialist_candidates": 1,
        "maximum_total_predictions": 2,
        "default_anchor_policy": True,
        "positive_contribution_witness_binding": True,
        "all_selected_predictions_exact_copies": True,
        "proposal_status_counts": dict(sorted(proposal_statuses.items())),
        "boundary_class_counts": dict(sorted(boundary_classes.items())),
        "selector_decision_counts": dict(sorted(decisions.items())),
        "anchor_classification_counts": dict(sorted(anchor_classes.items())),
        "packet_state_closure": parent._validate_packet_state_ledgers(
            root / ANCHOR_LEDGER_AGGREGATE_FILENAME
        ),
    }


def validate_agent_judge_luna_gaia_v3_65_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    factorized = _validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_65_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_65_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_65_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_65_REASONING_EFFORT,
        "selection_policy": "clean_v3_20_anchor_blind_global_causal_proposal_exact_copy_duel",
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one outcome-conditioned global boundary proposal duel",
        "anchor_semantics_unchanged_from_v3_20": True,
        "all_selected_predictions_exact_copies": True,
        "factorized_specialist_panel": factorized,
    }


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_panel(*paths[:-1]), paths[-1])


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_selector(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_65_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_65_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_luna_gaia_v3_65_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_selector_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / PANEL_FILENAME,
        prediction.parent / SELECTOR_FILENAME,
    )


# Generic three-stage runner compatibility aliases.
validate_and_write_agent_judge_luna_gaia_v3_37_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_65_audit
)
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_luna_gaia_v3_65_task
build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_65_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_65_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_65_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "panel" and len(paths) == 4:
            audit = validate_and_write_panel_audit(*paths)
        elif stage == "selector" and len(paths) == 8:
            audit = validate_and_write_selector_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_65_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except (shared.AgentJudgeValidationError, json.JSONDecodeError, OSError) as error:
        code = getattr(error, "code", type(error).__name__)
        print(json.dumps({"ok": False, "code": code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "panel", "selector", "prediction"))
    parser.add_argument("paths", nargs="+")
    args = parser.parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

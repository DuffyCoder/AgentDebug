"""GAIA v3.102: clean-v3.83 tournament with three fresh validator attempts."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge_gaia_v3_101_gpt55_stage_local_access_validated_tournament import *  # noqa: F403
from . import agent_judge_gaia_v3_83_clean_v3p20_model_only_gpt55_medium as incumbent
from . import (
    agent_judge_gaia_v3_101_gpt55_stage_local_access_validated_tournament as template,
)


AGENT_JUDGE_GAIA_V3_102_VERSION = (
    "agentdebug.codex-agent-judge.gaia-v3.102-gpt55-three-attempt-access-"
    "validated-predicate-handoff-tournament"
)
AGENT_JUDGE_GAIA_V3_102_MODEL = incumbent.AGENT_JUDGE_GAIA_V3_83_MODEL
AGENT_JUDGE_GAIA_V3_102_REASONING_EFFORT = incumbent.AGENT_JUDGE_GAIA_V3_83_REASONING_EFFORT
AGENT_JUDGE_GAIA_V3_102_AUDIT_SCHEMA_VERSION = incumbent.AGENT_JUDGE_GAIA_V3_83_AUDIT_SCHEMA_VERSION
SEMANTIC_PARENT = incumbent.AGENT_JUDGE_GAIA_V3_83_VERSION

for _suffix in ("101", "100", "99", "98", "97", "96", "95", "93"):
    globals()[f"AGENT_JUDGE_GAIA_V3_{_suffix}_VERSION"] = AGENT_JUDGE_GAIA_V3_102_VERSION
    globals()[f"AGENT_JUDGE_GAIA_V3_{_suffix}_MODEL"] = AGENT_JUDGE_GAIA_V3_102_MODEL
    globals()[f"AGENT_JUDGE_GAIA_V3_{_suffix}_REASONING_EFFORT"] = AGENT_JUDGE_GAIA_V3_102_REASONING_EFFORT
for _suffix in ("80", "79", "67", "37"):
    globals()[f"AGENT_JUDGE_LUNA_GAIA_V3_{_suffix}_VERSION"] = AGENT_JUDGE_GAIA_V3_102_VERSION
    globals()[f"AGENT_JUDGE_LUNA_GAIA_V3_{_suffix}_MODEL"] = AGENT_JUDGE_GAIA_V3_102_MODEL
    globals()[f"AGENT_JUDGE_LUNA_GAIA_V3_{_suffix}_REASONING_EFFORT"] = AGENT_JUDGE_GAIA_V3_102_REASONING_EFFORT


def _retag_task(task: str) -> str:
    return task.replace(template.AGENT_JUDGE_GAIA_V3_101_VERSION, AGENT_JUDGE_GAIA_V3_102_VERSION)


def build_anchor_file_task(prediction_manifest_path: str | Path, cohort_manifest_path: str | Path) -> str:
    return _retag_task(template.build_anchor_file_task(prediction_manifest_path, cohort_manifest_path))


def build_reducer_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> str:
    return _retag_task(
        template.build_reducer_file_task(
            prediction_manifest_path, cohort_manifest_path, anchor_path, ledger_path, checkpoint_path
        )
    )


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_GAIA_V3_102_VERSION,
        "model": AGENT_JUDGE_GAIA_V3_102_MODEL,
        "reasoning_effort": AGENT_JUDGE_GAIA_V3_102_REASONING_EFFORT,
        "selection_policy": policy,
        "semantic_parent": SEMANTIC_PARENT,
        "direct_semantic_parent": SEMANTIC_PARENT,
        "rejected_lineage_inherited": False,
        "single_major_change": (
            "replace accepted v3.83 challenger/arbiter with one outcome-conditioned "
            "predicate-handoff tournament over every native v3.83 ledger Step"
        ),
        "maximum_fresh_attempts_per_stage": 3,
        "stage_local_access_validation_before_materialization": True,
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(template.validate_anchor_predictions(*paths), policy="v3p83_anchor_three_attempt_access")


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])  # noqa: F405


def validate_panel(*paths: str | Path) -> dict[str, Any]:
    return _retag(template.validate_panel(*paths), policy="three_attempt_access_validated_tournament")


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_panel(*paths[:-1]), paths[-1])  # noqa: F405


def validate_selector(*paths: str | Path) -> dict[str, Any]:
    return _retag(template.validate_selector(*paths), policy="three_attempt_exact_selection_copy")


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_selector(*paths[:-1]), paths[-1])  # noqa: F405


def validate_agent_judge_gaia_v3_102_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    return _retag(
        template.validate_agent_judge_gaia_v3_101_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        policy="three_attempt_access_validated_predicate_handoff_tournament",
    )


def validate_and_write_agent_judge_gaia_v3_102_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(  # noqa: F405
        validate_agent_judge_gaia_v3_102_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ), audit_path
    )


def build_agent_judge_gaia_v3_102_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_reducer_file_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,  # noqa: F405
    )


validate_and_write_agent_judge_luna_gaia_v3_37_audit = validate_and_write_agent_judge_gaia_v3_102_audit
validate_and_write_agent_judge_luna_gaia_v3_67_audit = validate_and_write_agent_judge_gaia_v3_102_audit
validate_and_write_agent_judge_luna_gaia_v3_79_audit = validate_and_write_agent_judge_gaia_v3_102_audit
validate_and_write_agent_judge_luna_gaia_v3_80_audit = validate_and_write_agent_judge_gaia_v3_102_audit
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_gaia_v3_102_task
build_agent_judge_luna_gaia_v3_79_task = build_agent_judge_gaia_v3_102_task
build_agent_judge_luna_gaia_v3_80_task = build_agent_judge_gaia_v3_102_task


def __getattr__(name: str) -> Any:
    return getattr(template, name)

"""Luna GAIA v3.7.1: orthogonal strategy state with pre-commit freeze."""

from __future__ import annotations

import argparse
import copy
import json
import os
from pathlib import Path
from typing import Any, Sequence

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
)
from .agent_judge_luna_gaia_v3 import (
    STEP_FREEZE_FIELDS,
    STEP_FREEZE_FILENAME,
    _file_sha256,
)
from .agent_judge_luna_gaia_v3_1 import (
    validate_agent_judge_luna_gaia_v3_1_predictions,
)
from .agent_judge_luna_gaia_v3_4 import (
    STEP_CANDIDATE_LEDGER_FIELDS,
    STEP_CANDIDATE_LEDGER_FILENAME,
    STEP_CANDIDATE_LANES,
    STEP_CANDIDATE_STATUSES,
    _validate_step_candidate_ledger_document,
)
from .agent_judge_luna_gaia_v3_7 import (
    AGENT_JUDGE_LUNA_GAIA_V3_7_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_LUNA_GAIA_V3_7_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_7_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_7_VERSION,
    STRATEGY_DELTA_CLASSES,
    STRATEGY_FEEDBACK_CLASSES,
    STRATEGY_ROUTE_DISPOSITIONS,
    _INITIAL_STRATEGY_STATE as _V3_7_INITIAL_STRATEGY_STATE,
    _NOT_APPLICABLE_STRATEGY_STATE as _V3_7_NOT_APPLICABLE_STRATEGY_STATE,
    _STRUCTURED_STRATEGY_STATE_RULES as _V3_7_STRUCTURED_STRATEGY_STATE_RULES,
    build_agent_judge_luna_gaia_v3_7_task,
)


AGENT_JUDGE_LUNA_GAIA_V3_7_1_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.7.1"
)
AGENT_JUDGE_LUNA_GAIA_V3_7_1_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_7_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_7_1_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_7_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_7_1_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_7_AUDIT_SCHEMA_VERSION
)

STEP_CANDIDATE_LEDGER_DRAFT_FILENAME = "step-candidates.draft.json"
STRATEGY_STATE_FIELD = "strategy_state"
STRATEGY_STATE_FIELDS = (
    "same_route_anchor_step",
    "prior_same_route_attempts",
    "delta_class",
    "same_route_feedback",
    "route_disposition",
)
STEP_CANDIDATE_ROW_FIELDS = (
    "step",
    "lane_a",
    "lane_b",
    "system",
    STRATEGY_STATE_FIELD,
    "lane_c",
    "surviving_lane",
    "evidence_quote",
    "decision_basis",
)
_NEW_ROUTE_DELTAS = frozenset(
    {
        "new_source_or_host",
        "new_modality",
        "new_target_or_constraint",
    }
)
_SAME_ROUTE_DELTAS = frozenset({"same_route", "return_to_route"})
_ROUTE_DELTAS = frozenset({"initial", *_NEW_ROUTE_DELTAS, *_SAME_ROUTE_DELTAS})


_STRUCTURED_STRATEGY_STATE_RULES = """\
STRUCTURED STRATEGY-STATE GATE

Apply this gate only to Lane C.  It changes no Lane-A claim audit, Lane-B
source/prerequisite/capability/Action rule, System packet fence, recovery veto,
same-step owner/type rule, or evidence rule.

Before assigning `lane_c`, record one `strategy_state` object for the current
row.  It must contain, in order: `same_route_anchor_step`,
`prior_same_route_attempts`, `delta_class`, `same_route_feedback`, and
`route_disposition`.

Normalize a route by unresolved subgoal, source/host, modality, explicit
target or constraint, and information route.  Count every earlier attempt of
that normalized route, including attempts separated by a different probe.
Classify the current relation as exactly one of:

- `initial`: the first comparable information-route probe in the chronology;
- `new_source_or_host`: an earlier information route exists, but this probe
  introduces a literal source, host, corpus, or site restriction and has no
  earlier occurrence of the same normalized route;
- `new_modality`: an earlier information route exists, but the operation or
  evidence modality is materially new and has no earlier occurrence of the
  same normalized route;
- `new_target_or_constraint`: an earlier information route exists, but this
  probe adds a literal target, entity, predicate, or constraint and has no
  earlier occurrence of the same normalized route;
- `same_route`: the current route is semantically the same as an earlier
  uninterrupted occurrence;
- `return_to_route`: the current route occurred earlier, a different route
  intervened, and the current action returns to it;
- `not_applicable`: no information-route comparison is relevant.

`initial` does not mean the first occurrence of every newly normalized route.
It is used only once: for the first comparable route in the chronological
ledger.  Every later first-occurrence route uses exactly one `new_*` delta.
Do not infer a new target from capitalization, word order, or a predicate that
was already explicit.  A literal `site:` or host restriction is new.  Exact or
semantic reuse remains the same route even when words are reordered.

The same-route fields have one coordinate only:

- For `same_route` or `return_to_route`, `same_route_anchor_step` is an earlier
  occurrence of that same normalized route, `prior_same_route_attempts` is a
  positive count, and `same_route_feedback` is the feedback from that route.
- For `initial`, every `new_*` delta, and `not_applicable`, the same-route
  anchor is null, the count is zero, and feedback is `not_applicable`.
- Never put feedback from a different preceding route into
  `same_route_feedback`; explain a material transition only with `delta_class`
  and `decision_basis`.

Classify same-route feedback as `productive` when it exposed a relevant
candidate, target, link, or requested partial fact; `uninformative_or_contrary`
when it gave no useful evidence or directly refuted the route's expectation;
or `failed_access` for a demonstrated access/endpoint failure.

Derive exactly one route disposition:

- `initial_probe`: `initial`; Lane C is `veto_initial_probe`.
- `different_probe`: a `new_*` route; Lane C is `veto_different_probe`.
- `not_mature`: the same route has only one prior attempt and that attempt was
  productive, so checking the candidate and then seeking another is not proof
  that the discovery route failed; Lane C is `clear`.
- `mature_repeat`: same/returned route after uninformative, contrary, or failed
  feedback, or after multiple prior same-route attempts have exhausted the
  information route; Lane C is `candidate`.
- `terminal_abandonment`: the agent terminates with required predicates still
  open while a viable route remains; Lane C is `candidate`.
- `not_applicable`: Lane C is `clear`.

Free-text `decision_basis` cannot override this object.  The validator enforces
the coordinate rules and the disposition-to-Lane-C mapping.

"""


_INITIAL_STRATEGY_STATE = """\
      "strategy_state": {
        "same_route_anchor_step": null,
        "prior_same_route_attempts": 0,
        "delta_class": "initial",
        "same_route_feedback": "not_applicable",
        "route_disposition": "initial_probe"
      },
"""

_NOT_APPLICABLE_STRATEGY_STATE = """\
      "strategy_state": {
        "same_route_anchor_step": null,
        "prior_same_route_attempts": 0,
        "delta_class": "not_applicable",
        "same_route_feedback": "not_applicable",
        "route_disposition": "not_applicable"
      },
"""


def _strategy_error(code: str, message: str) -> None:
    raise AgentJudgeValidationError(code, message)


def _validate_strategy_state(
    state: Any,
    *,
    step: int,
    lane_c: str,
) -> None:
    location = f"step ledger row {step}.strategy_state"
    if not isinstance(state, dict) or tuple(state) != STRATEGY_STATE_FIELDS:
        _strategy_error(
            "invalid_strategy_state_schema",
            f"{location} has unexpected fields or field order",
        )
    anchor = state["same_route_anchor_step"]
    attempts = state["prior_same_route_attempts"]
    delta = state["delta_class"]
    feedback = state["same_route_feedback"]
    disposition = state["route_disposition"]
    if delta not in STRATEGY_DELTA_CLASSES:
        _strategy_error("invalid_strategy_delta_class", f"{location}.delta_class")
    if feedback not in STRATEGY_FEEDBACK_CLASSES:
        _strategy_error(
            "invalid_strategy_feedback_class",
            f"{location}.same_route_feedback",
        )
    if disposition not in STRATEGY_ROUTE_DISPOSITIONS:
        _strategy_error(
            "invalid_strategy_route_disposition",
            f"{location}.route_disposition",
        )
    if isinstance(attempts, bool) or not isinstance(attempts, int) or attempts < 0:
        _strategy_error(
            "invalid_strategy_attempt_count",
            f"{location}.prior_same_route_attempts must be a non-negative integer",
        )

    if delta in _SAME_ROUTE_DELTAS:
        if (
            isinstance(anchor, bool)
            or not isinstance(anchor, int)
            or anchor < 1
            or anchor >= step
        ):
            _strategy_error(
                "invalid_same_route_anchor_step",
                f"{location}.same_route_anchor_step must identify an earlier step",
            )
        if attempts < 1 or feedback == "not_applicable":
            _strategy_error(
                "invalid_same_route_state",
                f"{location} same/returned route needs attempts and feedback",
            )
    elif anchor is not None or attempts != 0 or feedback != "not_applicable":
        _strategy_error(
            "invalid_cross_route_state",
            f"{location} non-repeated route cannot carry same-route state",
        )

    if disposition == "initial_probe" and delta != "initial":
        _strategy_error("strategy_disposition_mismatch", location)
    if disposition == "different_probe" and delta not in _NEW_ROUTE_DELTAS:
        _strategy_error("strategy_disposition_mismatch", location)
    if disposition == "not_mature" and not (
        delta in _SAME_ROUTE_DELTAS
        and attempts == 1
        and feedback == "productive"
    ):
        _strategy_error("strategy_disposition_mismatch", location)
    if disposition == "mature_repeat" and not (
        delta in _SAME_ROUTE_DELTAS
        and (
            attempts > 1
            or feedback in {"uninformative_or_contrary", "failed_access"}
        )
    ):
        _strategy_error("strategy_disposition_mismatch", location)
    if disposition == "terminal_abandonment" and delta != "not_applicable":
        _strategy_error("strategy_disposition_mismatch", location)
    if disposition == "not_applicable" and delta != "not_applicable":
        _strategy_error("strategy_disposition_mismatch", location)

    expected_lane_c = {
        "initial_probe": {"veto_initial_probe"},
        "different_probe": {"veto_different_probe"},
        "not_mature": {"clear", "veto_terminal_supersession"},
        "mature_repeat": {"candidate"},
        "terminal_abandonment": {"candidate"},
        "not_applicable": {"clear"},
    }[disposition]
    if lane_c not in expected_lane_c:
        _strategy_error(
            "strategy_lane_c_mismatch",
            f"{location} disposition is inconsistent with lane_c",
        )


def _validate_strategy_ledger_document(
    value: Any,
    *,
    trajectory_id: str,
    step_count: int,
    predicted_step: int,
    selected_packet_sources: Sequence[str],
) -> None:
    """Validate orthogonal strategy state, then the inherited step ledger."""

    if not isinstance(value, dict) or tuple(value) != STEP_CANDIDATE_LEDGER_FIELDS:
        _strategy_error(
            "invalid_step_candidate_ledger_schema",
            "step ledger must contain only trajectory_id, rows, selected_step",
        )
    rows = value.get("rows")
    if not isinstance(rows, list):
        _strategy_error("invalid_step_candidate_ledger_rows", "rows must be a list")

    compatibility = copy.deepcopy(value)
    compatibility_rows = compatibility["rows"]
    seen_information_route = False
    for index, row in enumerate(rows, start=1):
        if not isinstance(row, dict) or tuple(row) != STEP_CANDIDATE_ROW_FIELDS:
            _strategy_error(
                "invalid_step_candidate_row_schema",
                f"step ledger row {index} has unexpected fields or field order",
            )
        if row.get("evidence_quote") is not None:
            _strategy_error(
                "non_null_step_candidate_evidence",
                "step-only ledger evidence_quote must remain null on every row",
            )
        state = row[STRATEGY_STATE_FIELD]
        _validate_strategy_state(state, step=index, lane_c=row["lane_c"])
        delta = state["delta_class"]
        if delta == "initial":
            if seen_information_route:
                _strategy_error(
                    "invalid_repeated_initial_route",
                    f"step ledger row {index} uses initial after an earlier route",
                )
            seen_information_route = True
        elif delta in _NEW_ROUTE_DELTAS:
            if not seen_information_route:
                _strategy_error(
                    "invalid_new_route_without_initial",
                    f"step ledger row {index} uses a new delta before initial route",
                )
            seen_information_route = True
        elif delta in _SAME_ROUTE_DELTAS:
            if not seen_information_route:
                _strategy_error(
                    "invalid_same_route_without_initial",
                    f"step ledger row {index} repeats a route before initial route",
                )
            anchor = state["same_route_anchor_step"]
            anchor_row = rows[anchor - 1]
            anchor_state = anchor_row.get(STRATEGY_STATE_FIELD, {})
            if anchor_state.get("delta_class") not in _ROUTE_DELTAS:
                _strategy_error(
                    "invalid_same_route_anchor_state",
                    f"step ledger row {index} anchor is not an information route",
                )
        del compatibility_rows[index - 1][STRATEGY_STATE_FIELD]

    nonempty_source = next(
        (source for source in selected_packet_sources if source),
        None,
    )
    if nonempty_source is None:
        _strategy_error(
            "missing_selected_step_packet_text",
            "selected step packet has no text for downstream evidence audit",
        )
    if compatibility_rows:
        compatibility_rows[-1]["evidence_quote"] = nonempty_source[:1]
    _validate_step_candidate_ledger_document(
        compatibility,
        trajectory_id=trajectory_id,
        step_count=step_count,
        predicted_step=predicted_step,
        selected_packet_sources=selected_packet_sources,
    )


def _load_single_case(prediction_manifest_path: str | Path) -> Any:
    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    _assert_safe_path(manifest_path, role="prediction manifest")
    from agentdebug.benchmark.prediction_manifest import (  # noqa: PLC0415
        PredictionManifestError,
        load_prediction_manifest,
    )

    try:
        _, cases = load_prediction_manifest(manifest_path)
    except PredictionManifestError as error:
        raise AgentJudgeValidationError(
            "invalid_prediction_manifest",
            str(error),
        ) from error
    if len(cases) != 1:
        _strategy_error(
            "invalid_step_candidate_ledger_scope",
            "step ledger validation requires exactly one manifest case",
        )
    return cases[0]


def _read_ledger(path: Path, *, role: str) -> Any:
    _assert_safe_path(path, role=role)
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise AgentJudgeValidationError(
            "missing_or_invalid_step_candidate_ledger",
            f"{role} requires valid JSON",
        ) from error


def _packet_sources(case: Any, selected_step: Any) -> list[str]:
    if (
        isinstance(selected_step, bool)
        or not isinstance(selected_step, int)
        or selected_step < 1
        or selected_step > len(case.judge_view.steps)
    ):
        _strategy_error(
            "step_candidate_ledger_step_mismatch",
            "ledger selected_step is unavailable or out of range",
        )
    step = case.judge_view.steps[selected_step - 1]
    sources = [step.assistant_raw_output]
    sources.extend(item.text for item in step.adjacent_feedback)
    return sources


def validate_and_freeze_agent_judge_luna_gaia_v3_7_1_ledger(
    prediction_manifest_path: str | Path,
    draft_ledger_path: str | Path,
    final_ledger_path: str | Path,
) -> dict[str, Any]:
    """Validate a mutable draft, then atomically create the immutable ledger."""

    draft = Path(draft_ledger_path).expanduser().resolve()
    final = Path(final_ledger_path).expanduser().resolve()
    _assert_safe_path(draft, role="step candidate ledger draft", is_output=True)
    _assert_safe_path(final, role="step candidate ledger output", is_output=True)
    if draft == final or draft.parent != final.parent:
        _strategy_error(
            "invalid_ledger_freeze_paths",
            "draft and final ledger must be distinct files in the same directory",
        )
    if draft.name != STEP_CANDIDATE_LEDGER_DRAFT_FILENAME:
        _strategy_error(
            "invalid_ledger_draft_name",
            f"draft ledger must be named {STEP_CANDIDATE_LEDGER_DRAFT_FILENAME}",
        )
    if final.name != STEP_CANDIDATE_LEDGER_FILENAME:
        _strategy_error(
            "invalid_ledger_final_name",
            f"final ledger must be named {STEP_CANDIDATE_LEDGER_FILENAME}",
        )
    if final.exists():
        _strategy_error(
            "immutable_ledger_exists",
            "final step candidate ledger already exists and cannot be overwritten",
        )

    case = _load_single_case(prediction_manifest_path)
    ledger = _read_ledger(draft, role="step candidate ledger draft")
    selected_step = ledger.get("selected_step") if isinstance(ledger, dict) else None
    sources = _packet_sources(case, selected_step)
    _validate_strategy_ledger_document(
        ledger,
        trajectory_id=case.trajectory_id,
        step_count=len(case.judge_view.steps),
        predicted_step=selected_step,
        selected_packet_sources=sources,
    )

    try:
        os.link(draft, final)
    except FileExistsError as error:
        raise AgentJudgeValidationError(
            "immutable_ledger_exists",
            "final step candidate ledger appeared during freeze",
        ) from error
    except OSError as error:
        raise AgentJudgeValidationError(
            "ledger_freeze_failed",
            f"could not atomically freeze validated ledger: {error}",
        ) from error
    try:
        draft.unlink()
    except OSError as error:
        raise AgentJudgeValidationError(
            "ledger_draft_cleanup_failed",
            f"ledger froze but draft cleanup failed: {error}",
        ) from error
    return {
        "valid": True,
        "frozen": True,
        "path": str(final),
        "sha256": _file_sha256(final),
        "row_count": len(ledger["rows"]),
        "selected_step": selected_step,
        "surviving_lane": ledger["rows"][-1]["surviving_lane"],
    }


def _validate_strategy_ledger(
    prediction_manifest_path: str | Path,
    predictions_path: Path,
) -> dict[str, Any]:
    case = _load_single_case(prediction_manifest_path)
    try:
        predictions = json.loads(predictions_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise AgentJudgeValidationError(
            "invalid_predictions_json",
            "predictions are unavailable for step ledger validation",
        ) from error
    if not isinstance(predictions, list) or len(predictions) != 1:
        _strategy_error(
            "invalid_step_candidate_ledger_scope",
            "step ledger validation requires exactly one prediction",
        )

    ledger_path = predictions_path.parent / STEP_CANDIDATE_LEDGER_FILENAME
    ledger = _read_ledger(ledger_path, role="step candidate ledger")
    selected_step = predictions[0].get("predicted_step")
    sources = _packet_sources(case, selected_step)
    _validate_strategy_ledger_document(
        ledger,
        trajectory_id=case.trajectory_id,
        step_count=len(case.judge_view.steps),
        predicted_step=selected_step,
        selected_packet_sources=sources,
    )
    return {
        "required": True,
        "valid": True,
        "path": str(ledger_path.resolve()),
        "sha256": _file_sha256(ledger_path),
        "row_count": len(ledger["rows"]),
        "selected_step": ledger["selected_step"],
        "surviving_lane": ledger["rows"][-1]["surviving_lane"],
        "evidence_deferred_to_final_prediction": True,
        "strategy_state_validated": True,
        "precommit_freeze_required": True,
    }


def build_agent_judge_luna_gaia_v3_7_1_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build v3.7 semantics with an orthogonal state and pre-commit freeze."""

    task = build_agent_judge_luna_gaia_v3_7_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    task = task.replace(
        AGENT_JUDGE_LUNA_GAIA_V3_7_VERSION,
        AGENT_JUDGE_LUNA_GAIA_V3_7_1_VERSION,
    )
    task = task.replace(
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_7.py",
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_7_1.py",
    )
    task = task.replace(
        "agentdebug.diagnostics.agent_judge_luna_gaia_v3_7",
        "agentdebug.diagnostics.agent_judge_luna_gaia_v3_7_1",
    )
    task = task.replace(
        _V3_7_STRUCTURED_STRATEGY_STATE_RULES,
        _STRUCTURED_STRATEGY_STATE_RULES,
    )
    task = task.replace(_V3_7_INITIAL_STRATEGY_STATE, _INITIAL_STRATEGY_STATE)
    task = task.replace(
        _V3_7_NOT_APPLICABLE_STRATEGY_STATE,
        _NOT_APPLICABLE_STRATEGY_STATE,
    )

    predictions = Path(predictions_path).expanduser().resolve()
    final_ledger = predictions.parent / STEP_CANDIDATE_LEDGER_FILENAME
    draft_ledger = predictions.parent / STEP_CANDIDATE_LEDGER_DRAFT_FILENAME
    final_line = f"- write immutable step candidate ledger only to: {final_ledger}"
    if task.count(final_line) != 1:
        raise RuntimeError("Luna GAIA v3.7 output boundary changed unexpectedly")
    task = task.replace(
        final_line,
        f"- write revisable pre-commit ledger draft only to: {draft_ledger}\n"
        f"- freeze immutable step candidate ledger only to: {final_ledger}",
        1,
    )
    allow_line = f"- {final_ledger} only after writing the frozen step candidate ledger"
    if task.count(allow_line) != 1:
        raise RuntimeError("Luna GAIA v3.7 ledger allowlist changed unexpectedly")
    task = task.replace(
        allow_line,
        f"- {draft_ledger} only after writing this run's pre-commit draft\n"
        f"- {final_ledger} only after the validator freezes it",
        1,
    )
    old_order = (
        "LANE-ORDERED CHRONOLOGICAL SCAN -> WRITE STEP CANDIDATE LEDGER ->\n"
        "WRITE IMMUTABLE STEP CHECKPOINT -> SAME-STEP OWNER -> TAXONOMY TYPE ->\n"
        "LITERAL EVIDENCE -> FINAL PREDICTION"
    )
    new_order = (
        "LANE-ORDERED CHRONOLOGICAL SCAN -> PRE-COMMIT ROUTE REVIEW ->\n"
        "VALIDATE AND FREEZE STEP CANDIDATE LEDGER -> WRITE IMMUTABLE STEP\n"
        "CHECKPOINT -> SAME-STEP OWNER -> TAXONOMY TYPE -> LITERAL EVIDENCE ->\n"
        "FINAL PREDICTION"
    )
    if task.count(old_order) != 1:
        raise RuntimeError("Luna GAIA v3.7 decision order changed unexpectedly")
    task = task.replace(old_order, new_order, 1)

    old_write = (
        "Write this file once and never edit it.\n"
        "Then derive and write the two-field step checkpoint from its last row before\n"
        "considering owner/type/evidence."
    )
    freeze_command = (
        "PYTHONPATH=. python3 -m "
        "agentdebug.diagnostics.agent_judge_luna_gaia_v3_7_1 "
        f"--compact-ledger-freeze {Path(prediction_manifest_path).expanduser().resolve()} "
        f"{draft_ledger} {final_ledger}"
    )
    new_write = f"""Write the complete ledger first to `{draft_ledger}`.  Before freezing it,
perform one read-only route review of every row: verify the operation modality,
source/host, literal target/constraint, same-route anchor, anchor feedback, and
the selected row's first-surviving status.  Do not assign owner/type during
this review.

Then run exactly:

cd {Path.cwd()}
{freeze_command}

If pre-commit validation fails, correct only the draft field identified by the
compact code/message and rerun.  The command atomically creates
`{final_ledger}` only after the whole draft passes.  Once it succeeds, never
edit or replace the final ledger.  Derive the two-field step checkpoint from
its last row before considering owner/type/evidence."""
    if task.count(old_write) != 1:
        raise RuntimeError("Luna GAIA v3.7 ledger write boundary changed unexpectedly")
    task = task.replace(old_write, new_write, 1)
    return task


def validate_agent_judge_luna_gaia_v3_7_1_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    prediction_path = Path(predictions_path).expanduser().resolve()
    audit = validate_agent_judge_luna_gaia_v3_1_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction_path,
    )
    ledger = (
        _validate_strategy_ledger(prediction_manifest_path, prediction_path)
        if audit["case_count"] == 1
        else {
            "required": False,
            "valid": None,
            "reason": "merged full-cohort validation follows validated shards",
        }
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_7_1_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_7_1_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_7_1_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_7_1_REASONING_EFFORT,
        "selection_policy": (
            "lane_ordered_chronology_validated_step_only_candidate_ledger_"
            "precommit_freeze_limited_recovery_veto_external_exception_packet_"
            "fence_positive_immediate_subgoal_capability_gate_positive_action_"
            "materiality_gate_orthogonal_same_route_strategy_state"
        ),
        "step_candidate_ledger": ledger,
        "positive_capability_admission_gate": (
            "any_necessary_evidence_for_current_immediate_subgoal"
        ),
        "step_ledger_evidence_policy": "deferred_to_final_prediction",
        "positive_action_materiality_gate": (
            "rejection_semantic_change_or_false_state_consumption_required"
        ),
        "strategy_state_gate": (
            "orthogonal_same_route_anchor_feedback_count_and_material_delta"
        ),
    }


def validate_and_write_agent_judge_luna_gaia_v3_7_1_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_7_1_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


def _compact_failure(error: Exception) -> int:
    if isinstance(error, AgentJudgeValidationError):
        code = error.code
        status = 1
    else:  # pragma: no cover - last-resort observability
        code = "unexpected_validation_error"
        status = 2
    print(
        json.dumps(
            {
                "valid": False,
                "error_code": code,
                "error_message": str(error),
            },
            ensure_ascii=False,
        )
    )
    return status


def run_agent_judge_luna_gaia_v3_7_1_compact_validation(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> int:
    try:
        audit = validate_and_write_agent_judge_luna_gaia_v3_7_1_audit(
            prediction_manifest_path,
            cohort_manifest_path,
            predictions_path,
            audit_path,
        )
    except Exception as error:
        return _compact_failure(error)
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    return 0


def run_agent_judge_luna_gaia_v3_7_1_compact_ledger_freeze(
    prediction_manifest_path: str | Path,
    draft_ledger_path: str | Path,
    final_ledger_path: str | Path,
) -> int:
    try:
        result = validate_and_freeze_agent_judge_luna_gaia_v3_7_1_ledger(
            prediction_manifest_path,
            draft_ledger_path,
            final_ledger_path,
        )
    except Exception as error:
        return _compact_failure(error)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--compact-validate", action="store_true")
    mode.add_argument("--compact-ledger-freeze", action="store_true")
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if args.compact_ledger_freeze:
        if len(args.paths) != 3:
            raise SystemExit("--compact-ledger-freeze requires exactly 3 paths")
        return run_agent_judge_luna_gaia_v3_7_1_compact_ledger_freeze(*args.paths)
    if len(args.paths) != 4:
        raise SystemExit("--compact-validate requires exactly 4 paths")
    return run_agent_judge_luna_gaia_v3_7_1_compact_validation(*args.paths)


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "AGENT_JUDGE_LUNA_GAIA_V3_7_1_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_GAIA_V3_7_1_MODEL",
    "AGENT_JUDGE_LUNA_GAIA_V3_7_1_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_GAIA_V3_7_1_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "STEP_CANDIDATE_LEDGER_DRAFT_FILENAME",
    "STEP_CANDIDATE_LEDGER_FIELDS",
    "STEP_CANDIDATE_LEDGER_FILENAME",
    "STEP_CANDIDATE_LANES",
    "STEP_CANDIDATE_ROW_FIELDS",
    "STEP_CANDIDATE_STATUSES",
    "STEP_FREEZE_FIELDS",
    "STEP_FREEZE_FILENAME",
    "STRATEGY_DELTA_CLASSES",
    "STRATEGY_FEEDBACK_CLASSES",
    "STRATEGY_ROUTE_DISPOSITIONS",
    "STRATEGY_STATE_FIELDS",
    "build_agent_judge_luna_gaia_v3_7_1_task",
    "main",
    "run_agent_judge_luna_gaia_v3_7_1_compact_ledger_freeze",
    "run_agent_judge_luna_gaia_v3_7_1_compact_validation",
    "validate_agent_judge_luna_gaia_v3_7_1_predictions",
    "validate_and_freeze_agent_judge_luna_gaia_v3_7_1_ledger",
    "validate_and_write_agent_judge_luna_gaia_v3_7_1_audit",
]

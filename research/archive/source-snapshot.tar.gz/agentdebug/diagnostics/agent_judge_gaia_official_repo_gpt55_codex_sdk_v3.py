"""Public-native AgentDebug taxonomy bridge for the Codex SDK reproduction.

The official detector defines six critical-error modules, including the
native ``others/others`` pair.  The repository-wide Agent Judge taxonomy has
only five modules, so this protocol owns a narrow output-contract bridge.  It
preserves the raw public Step/module/type decision and validates evidence
against observable literals bound to the selected Step.  It does not map a
native value into the internal taxonomy and does not resample Phase 2.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Mapping

from agentdebug.benchmark.prediction_manifest import (
    PredictionManifestError,
    load_prediction_manifest,
)

from . import agent_judge_gaia_official_repo_gpt55_codex_sdk as parent
from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AGENT_JUDGE_AUDIT_SCHEMA_VERSION,
    _SHA256_RE,
    _assert_safe_path,
    _cohort_document,
    _fail,
    _file_sha256,
    _load_json,
)
from .taxonomy import AgentModule, ErrorType


VERSION = "agentdebug.codex-agent-judge.gaia-official-repo-gpt55-codex-sdk-v3"
MODEL = parent.MODEL
REASONING_EFFORT = parent.REASONING_EFFORT
SDK_VERSION = parent.SDK_VERSION
TEMPERATURE = parent.TEMPERATURE
OFFICIAL_REPOSITORY_COMMIT = parent.OFFICIAL_REPOSITORY_COMMIT
OFFICIAL_SOURCE_SHA256 = parent.OFFICIAL_SOURCE_SHA256

# Exact positive critical-error keys returned by the frozen public
# ErrorDefinitionsLoader. ``no_error`` is a Phase-1 verdict, not a critical
# Phase-2 classification, and is therefore intentionally absent.
PUBLIC_NATIVE_TAXONOMY: dict[str, tuple[str, ...]] = {
    "memory": (
        "over_simplification",
        "memory_retrieval_failure",
        "hallucination",
    ),
    "reflection": (
        "progress_misjudge",
        "outcome_misinterpretation",
        "causal_misattribution",
        "hallucination",
    ),
    "planning": (
        "constraint_ignorance",
        "impossible_action",
        "inefficient_plan",
    ),
    "action": (
        "misalignment",
        "invalid_action",
        "format_error",
        "parameter_error",
    ),
    "system": (
        "step_limit",
        "tool_execution_error",
        "llm_limit",
        "environment_error",
    ),
    "others": ("others",),
}
PUBLIC_NATIVE_TAXONOMY_SHA256 = (
    "687d9213f72b069051a926f1f8a35658447474b74b64977b3c505f22ed3c5508"
)
PUBLIC_NATIVE_TAXONOMY_PAIR_COUNT = 19


def _native_taxonomy_sha256(value: Mapping[str, Any]) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode()
    return hashlib.sha256(payload).hexdigest()


if _native_taxonomy_sha256(PUBLIC_NATIVE_TAXONOMY) != PUBLIC_NATIVE_TAXONOMY_SHA256:
    raise RuntimeError("frozen public-native taxonomy hash differs")


def is_public_native_classification(module: str, error_type: str) -> bool:
    return error_type in PUBLIC_NATIVE_TAXONOMY.get(module, ())


def public_phase2_selected_step_literals(
    view: Any,
    predicted_step: int,
) -> tuple[str, ...]:
    """Mirror the public Phase-2 Step summary's literal text fields exactly."""

    if predicted_step < 1 or predicted_step > len(view.steps):
        return ()
    step = view.steps[predicted_step - 1]
    sources: list[str] = []
    if isinstance(step.assistant_raw_output, str) and step.assistant_raw_output.strip():
        sources.append(step.assistant_raw_output)
    for feedback in step.adjacent_feedback[:1]:
        if feedback.role != "user":
            break
        if isinstance(feedback.text, str) and feedback.text.strip():
            sources.append(feedback.text[:500])
    return tuple(dict.fromkeys(item for item in sources if item.strip()))


def public_native_evidence_sources(
    view: Any,
    predicted_step: int,
    module: str,
    error_type: str,
) -> tuple[str, ...]:
    """Keep five parent owner policies; bridge only native others/others."""

    if module == "others" and error_type == "others":
        return public_phase2_selected_step_literals(view, predicted_step)
    try:
        internal_module = AgentModule(module)
        internal_type = ErrorType(error_type)
    except ValueError:
        return ()
    return parent.official_owner_sources(
        view,
        predicted_step,
        internal_module,
        internal_type,
    )


def build_protocol_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    return f"""Public AgentDebug detector topology over Codex SDK, v3.

Protocol: {VERSION}
Semantic parent: {parent.VERSION}
Model: {MODEL}
Reasoning effort: {REASONING_EFFORT}
Codex SDK: {SDK_VERSION}
Temperature: unsupported and not sent
Prediction manifest: {Path(prediction_manifest_path).expanduser().resolve()}
Cohort manifest: {Path(cohort_manifest_path).expanduser().resolve()}
Predictions: {Path(predictions_path).expanduser().resolve()}

The frozen public source, prompts, Phase-1 topology, public Phase-2 analyzer,
model, effort, and audited SDK transport are inherited unchanged.  There is
one public Phase-2 invocation per case, except for the frozen public analyzer's
native Step-1 memory/reflection retry.  There is no runner-level semantic
resample.  Raw public module/type values are preserved and checked against the
exact frozen ErrorDefinitionsLoader taxonomy, including others/others.
The five existing module families keep the parent's exact strict-owner
evidence policy.  Only others/others gains a virtual owner equal to the public
Phase-2 selected-Step projection: full assistant output and at most the first
500 characters of immediate adjacent user feedback.  The separate JudgeView
current_input, tool details, stop/error fields, later feedback messages, and
feedback bytes beyond 500 are excluded.  No
gold, prior prediction, or cross-version inference artifact is visible before
the 50-case tree freezes.
"""


def validate_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    """Validate the unchanged prediction schema with public-native taxonomy."""

    prediction_path = Path(prediction_manifest_path).expanduser().resolve()
    cohort_path = Path(cohort_manifest_path).expanduser().resolve()
    output_path = Path(predictions_path).expanduser().resolve()
    _assert_safe_path(prediction_path, role="prediction manifest")
    _assert_safe_path(cohort_path, role="cohort manifest")
    _assert_safe_path(output_path, role="prediction output")
    try:
        manifest, cases = load_prediction_manifest(prediction_path)
    except PredictionManifestError as error:
        _fail("invalid_prediction_manifest", str(error))
    cohort = _cohort_document(cohort_path)
    manifest_ids = [case.trajectory_id for case in cases]
    cohort_ids = cohort["trajectory_ids"]
    if manifest_ids != cohort_ids:
        _fail(
            "manifest_cohort_order_mismatch",
            "prediction manifest IDs must exactly match cohort order",
        )
    if (
        manifest.get("cohort_name") != cohort.get("cohort_name")
        or manifest.get("cohort_sha256") != cohort.get("cohort_sha256")
        or manifest.get("dataset_manifest_sha256")
        != cohort.get("dataset_manifest_sha256")
    ):
        _fail(
            "manifest_cohort_identity_mismatch",
            "prediction manifest and cohort public identities differ",
        )
    raw_predictions = _load_json(output_path, role="predictions")
    if not isinstance(raw_predictions, list):
        _fail("invalid_prediction_envelope", "predictions must be one JSON array")
    if len(raw_predictions) != len(cases):
        _fail(
            "invalid_prediction_count",
            "prediction count must equal the complete cohort count",
        )
    predicted_ids: list[str] = []
    for index, (raw, case) in enumerate(zip(raw_predictions, cases, strict=True)):
        location = f"predictions[{index}]"
        if not isinstance(raw, dict):
            _fail("invalid_prediction_record", f"{location} must be an object")
        fields = set(raw)
        if fields != AGENT_JUDGE_PREDICTION_FIELDS:
            missing = sorted(AGENT_JUDGE_PREDICTION_FIELDS - fields)
            extra = sorted(fields - AGENT_JUDGE_PREDICTION_FIELDS)
            _fail(
                "invalid_prediction_fields",
                f"{location} fields differ; missing={missing}, extra={extra}",
            )
        for field in AGENT_JUDGE_PREDICTION_FIELDS - {"predicted_step"}:
            if not isinstance(raw[field], str) or not raw[field].strip():
                _fail(
                    "invalid_prediction_value",
                    f"{location}.{field} must be non-empty text",
                )
        if raw["status"] != "success":
            _fail("invalid_status", f"{location}.status must equal 'success'")
        if raw["trajectory_id"] != case.trajectory_id:
            _fail(
                "cohort_order_mismatch",
                f"{location}.trajectory_id is not the expected cohort case",
            )
        predicted_ids.append(raw["trajectory_id"])
        if (
            _SHA256_RE.fullmatch(raw["trajectory_sha256"]) is None
            or raw["trajectory_sha256"] != case.trajectory_sha256
        ):
            _fail(
                "trajectory_sha256_mismatch",
                f"{location}.trajectory_sha256 differs from the manifest",
            )
        step = raw["predicted_step"]
        if (
            isinstance(step, bool)
            or not isinstance(step, int)
            or step < 1
            or step > len(case.judge_view.steps)
        ):
            _fail(
                "predicted_step_out_of_range",
                f"{location}.predicted_step must identify one JudgeView step",
            )
        module = raw["predicted_module"]
        error_type = raw["predicted_error_type"]
        if step == 1 and module in {"memory", "reflection"}:
            _fail(
                "invalid_public_step1_module",
                f"{location} contains an operationally impossible public Step-1 module",
            )
        if not is_public_native_classification(module, error_type):
            _fail(
                "invalid_public_native_taxonomy_pair",
                f"{location} contains an illegal public module/error_type pair",
            )
        sources = public_native_evidence_sources(
            case.judge_view,
            step,
            module,
            error_type,
        )
        quote = raw["evidence_quote"]
        if not sources or not any(quote in source for source in sources):
            _fail(
                "invalid_public_native_owner_evidence",
                f"{location}.evidence_quote is not strict public-native owner evidence",
            )
    if predicted_ids != cohort_ids or len(set(predicted_ids)) != len(predicted_ids):
        _fail(
            "cohort_order_mismatch",
            "prediction IDs must be unique and follow the complete cohort order",
        )
    return {
        "schema_version": AGENT_JUDGE_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": VERSION,
        "semantic_parent": parent.VERSION,
        "model": MODEL,
        "reasoning_effort": REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": len(cases),
        "unique_trajectory_ids": len(set(predicted_ids)),
        "cohort_order_matches": True,
        "manifest_order_matches": True,
        "all_status_success": True,
        "all_predicted_steps_in_range": True,
        "all_taxonomy_pairs_valid": True,
        "all_evidence_quotes_found_in_selected_step_module": True,
        "all_public_native_selected_owner_evidence_valid": True,
        "public_native_taxonomy": {
            module: list(types) for module, types in PUBLIC_NATIVE_TAXONOMY.items()
        },
        "public_native_taxonomy_sha256": PUBLIC_NATIVE_TAXONOMY_SHA256,
        "public_native_taxonomy_pair_count": PUBLIC_NATIVE_TAXONOMY_PAIR_COUNT,
        "raw_public_module_type_preserved": True,
        "native_module_type_case_sensitive": True,
        "public_step1_memory_reflection_final_outputs_rejected": True,
        "public_step1_system_others_final_outputs_allowed": True,
        "legacy_five_module_owner_evidence_policy_unchanged": True,
        "others_virtual_owner_matches_public_phase2_projection": True,
        "current_input_excluded_from_others_owner": True,
        "adjacent_feedback_bounded_to_public_500_chars": True,
        "outer_phase2_resample": False,
        "forbidden_read_occurred": False,
        "input_sha256": {
            "prediction_manifest": _file_sha256(prediction_path),
            "cohort": _file_sha256(cohort_path),
        },
        "output_sha256": {"predictions.json": _file_sha256(output_path)},
        "validation_method": (
            "Gold-free exact JSON, identity/order, Step range, frozen public-native "
            "taxonomy, unchanged legacy owner evidence, and public-projection "
            "others/others virtual-owner checks."
        ),
    }


build_task = build_protocol_task


__all__ = [
    "MODEL",
    "OFFICIAL_REPOSITORY_COMMIT",
    "OFFICIAL_SOURCE_SHA256",
    "PUBLIC_NATIVE_TAXONOMY",
    "PUBLIC_NATIVE_TAXONOMY_PAIR_COUNT",
    "PUBLIC_NATIVE_TAXONOMY_SHA256",
    "REASONING_EFFORT",
    "SDK_VERSION",
    "TEMPERATURE",
    "VERSION",
    "build_protocol_task",
    "build_task",
    "is_public_native_classification",
    "public_native_evidence_sources",
    "public_phase2_selected_step_literals",
    "validate_predictions",
]

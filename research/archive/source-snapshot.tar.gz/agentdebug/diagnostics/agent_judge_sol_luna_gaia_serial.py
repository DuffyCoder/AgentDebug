"""Fresh Sol proposals followed by frozen Luna Step, Module, and Type judges."""

from __future__ import annotations

import json
import shlex
from collections import defaultdict
from pathlib import Path
from typing import Any, Mapping

from . import agent_judge_luna_v3_serial as serial
from .agent_judge import (
    GOLD_ISOLATION_READ_DENYLIST,
    AgentJudgeValidationError,
    _assert_gold_free,
    _assert_safe_path,
    _file_sha256,
    _load_json,
)
from .agent_judge_sol_gaia_two_stage import (
    AGENT_JUDGE_SOL_GAIA_TWO_STAGE_MODEL,
    AGENT_JUDGE_SOL_GAIA_TWO_STAGE_REASONING_EFFORT,
    CANDIDATE_PROPOSALS_FILENAME,
    build_sol_gaia_candidate_task,
    validate_sol_gaia_candidate_proposals,
)


AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_VERSION = (
    "agentdebug.codex-agent-judge.sol-luna-gaia-serial-v1"
)
AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_REASONING_EFFORT = "medium"
PROPOSER_MODEL = AGENT_JUDGE_SOL_GAIA_TWO_STAGE_MODEL
PROPOSER_REASONING_EFFORT = AGENT_JUDGE_SOL_GAIA_TWO_STAGE_REASONING_EFFORT

STEP_CANDIDATES_FILENAME = "step-candidates.json"
STEP_DECISIONS_FILENAME = serial.STEP_DECISIONS_FILENAME
MODULE_DECISIONS_FILENAME = serial.MODULE_DECISIONS_FILENAME
STEP_AUDIT_FILENAME = serial.STEP_AUDIT_FILENAME
MODULE_AUDIT_FILENAME = serial.MODULE_AUDIT_FILENAME

_PROJECTION_ROW_FIELDS = {
    "trajectory_id",
    "trajectory_sha256",
    "status",
    "candidate_steps",
}
_PROJECTION_STEP_FIELDS = {"step", "findings"}
_PROJECTION_FINDING_FIELD_ORDER = (
    "evidence_quote",
    "local_defect",
    "causal_relevance",
    "recovery",
)
_PROJECTION_FINDING_FIELDS = set(_PROJECTION_FINDING_FIELD_ORDER)


def _fail(code: str, message: str) -> None:
    raise AgentJudgeValidationError(code, message)


def _atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    temporary.replace(path)


def _project_rows(proposal_rows: list[Mapping[str, Any]]) -> list[dict[str, Any]]:
    projected: list[dict[str, Any]] = []
    for row in proposal_rows:
        grouped: dict[int, list[dict[str, str]]] = defaultdict(list)
        seen: dict[int, set[tuple[str, str, str, str]]] = defaultdict(set)
        for card in row["candidates"]:
            finding = {
                field: str(card[field]) for field in _PROJECTION_FINDING_FIELD_ORDER
            }
            key = tuple(finding[field] for field in _PROJECTION_FINDING_FIELD_ORDER)
            if key in seen[card["step"]]:
                continue
            seen[card["step"]].add(key)
            grouped[card["step"]].append(finding)
        projected.append(
            {
                "trajectory_id": row["trajectory_id"],
                "trajectory_sha256": row["trajectory_sha256"],
                "status": "success",
                "candidate_steps": [
                    {"step": step, "findings": grouped[step]}
                    for step in sorted(grouped)
                ],
            }
        )
    return projected


def write_sol_luna_step_candidates(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposals_path: str | Path,
    projection_path: str | Path,
) -> dict[str, Any]:
    proposals = Path(proposals_path).expanduser().resolve()
    projection = Path(projection_path).expanduser().resolve()
    validate_sol_gaia_candidate_proposals(
        prediction_manifest_path, cohort_manifest_path, proposals
    )
    rows = _load_json(proposals, role="candidate proposals")
    _atomic_json(projection, _project_rows(rows))
    return validate_sol_luna_step_candidates(
        prediction_manifest_path,
        cohort_manifest_path,
        proposals,
        projection,
    )


def validate_sol_luna_step_candidates(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposals_path: str | Path,
    projection_path: str | Path,
) -> dict[str, Any]:
    proposals = Path(proposals_path).expanduser().resolve()
    projection = Path(projection_path).expanduser().resolve()
    candidate_audit = validate_sol_gaia_candidate_proposals(
        prediction_manifest_path, cohort_manifest_path, proposals
    )
    raw_proposals = _load_json(proposals, role="candidate proposals")
    raw_projection = _load_json(projection, role="step candidate projection")
    _assert_gold_free(raw_projection, location="step candidate projection")
    if raw_projection != _project_rows(raw_proposals):
        _fail(
            "step_candidate_projection_mismatch",
            "step projection is not the deterministic label-free proposal projection",
        )
    for index, row in enumerate(raw_projection):
        if not isinstance(row, Mapping) or set(row) != _PROJECTION_ROW_FIELDS:
            _fail("invalid_step_projection", f"projection row {index} is invalid")
        if not row["candidate_steps"]:
            _fail("empty_step_projection", f"projection row {index} is empty")
        for group in row["candidate_steps"]:
            if not isinstance(group, Mapping) or set(group) != _PROJECTION_STEP_FIELDS:
                _fail("invalid_step_projection", f"projection step {index} is invalid")
            if not group["findings"]:
                _fail("invalid_step_projection", f"projection findings {index} are empty")
            for finding in group["findings"]:
                if (
                    not isinstance(finding, Mapping)
                    or set(finding) != _PROJECTION_FINDING_FIELDS
                ):
                    _fail("invalid_step_projection", "projection finding is invalid")
    return {
        "agent_judge_version": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_VERSION,
        "stage": "deterministic-step-projection",
        "gold_free_validation": True,
        "case_count": candidate_audit["case_count"],
        "candidate_count": candidate_audit["candidate_count"],
        "module_and_type_labels_removed": True,
        "projection_exact": True,
        "input_sha256": {proposals.name: _file_sha256(proposals)},
        "output_sha256": {projection.name: _file_sha256(projection)},
    }


def build_sol_luna_candidate_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposals_path: str | Path,
) -> str:
    task = build_sol_gaia_candidate_task(
        prediction_manifest_path, cohort_manifest_path, proposals_path
    )
    addition = """
TYPE-LATE-BINDING AND NON-EMPTY RULES
- Candidate error_type is a provisional local hypothesis, not a final label.
- If one real local defect has two genuinely plausible legal types, retain both
  (step,module,type) cards; later stages will classify independently.
- Never return an empty list. If no high-confidence defect is available, emit
  the single least-assumptive, directly quoteable local breakpoint as a
  fallback. Do not invent evidence or infer anything from the trajectory ID.
"""
    return task.replace("\nTAXONOMY\n", f"\n{addition}\nTAXONOMY\n")


def _validator_command(function_name: str, *arguments: Path) -> str:
    rendered = ", ".join(repr(str(argument)) for argument in arguments)
    code = (
        "import json; from agentdebug.diagnostics."
        "agent_judge_sol_luna_gaia_serial import "
        f"{function_name} as run; "
        f"print(json.dumps(run({rendered}), ensure_ascii=False, indent=2))"
    )
    return "PYTHONPATH=. python3 -c " + shlex.quote(code)


def _denylist() -> str:
    return "\n".join(f"- {item}" for item in GOLD_ISOLATION_READ_DENYLIST)


def build_sol_luna_step_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
) -> str:
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    output = Path(step_decisions_path).expanduser().resolve()
    projection = output.parent / STEP_CANDIDATES_FILENAME
    proposals = output.parent / CANDIDATE_PROPOSALS_FILENAME
    audit = output.parent / STEP_AUDIT_FILENAME
    for role, path, is_output in (
        ("prediction manifest", prediction, False),
        ("cohort manifest", cohort, False),
        ("candidate proposals", proposals, False),
        ("step candidates", projection, False),
        ("step decisions", output, True),
        ("step audit", audit, True),
    ):
        _assert_safe_path(path, role=role, is_output=is_output)
    validate_sol_luna_step_candidates(prediction, cohort, proposals, projection)
    schema = {
        "trajectory_id": "exact manifest trajectory ID",
        "trajectory_sha256": "exact manifest trajectory SHA-256",
        "status": "success",
        "predicted_step": "one integer present in step-candidates.json",
        "step_rationale": "causal-boundary and recovery analysis",
        "rejected_later_candidate": "strongest temporal challenger and why it loses",
    }
    command = _validator_command(
        "validate_and_write_sol_luna_candidate_bound_step_audit",
        prediction,
        cohort,
        output,
        audit,
    )
    return f"""Run the STEP-ONLY Agent of {AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_VERSION}.

IMMUTABLE CONFIG: model={AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_MODEL}; reasoning_effort={AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_REASONING_EFFORT}; one isolated trajectory; network/API/gold/scoring/prior predictions forbidden.
Read only:
- {prediction}
- {cohort}
- {projection}
- this protocol source
The raw proposal file is validator input only; do not read it. The label-free
projection deliberately hides module and type so they cannot anchor Step.
Trajectory identity fields are never evidence.

YOUR ONLY DECISION IS predicted_step. Select exactly one step present in the
unranked projection. Independently reconstruct the complete JudgeView, then
compare all projected steps as causal boundaries.

Do not default to earliest or latest. A reasonable first probe is normally not
critical. In a failed-strategy chain, prefer the first point after concrete
negative feedback or accumulated evidence makes continued commitment
unsupported. An earlier candidate wins only while its material effect remains
unrecovered; a later candidate wins only after genuine restoration-and-use or
when it introduces an independent failure that would survive correction of the
earlier one. A vivid terminal answer or concrete parameter never wins merely
because its counterfactual is easy to describe.

Do not name or output any module or error type.

GOLD-ISOLATION DENYLIST
{_denylist()}

Write exactly one JSON array to {output} with one record and exact fields:
{json.dumps(schema, ensure_ascii=False, indent=2)}
All text fields must be non-empty. Then run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Fix only this artifact until validation exits zero and writes {audit}.
"""


_MODULE_ADDITION = """
SOL-LUNA OWNER COUNTERFACTUAL
Do not inherit an owner from any proposal: you have not been given proposal
module labels. At the frozen step, ask which single source block would need to
change while the other blocks remained as written. Reflection owns a false
reading of an observation, result, success, or progress even when Planning
acts on it. Planning owns only a new strategy/constraint choice from otherwise
sound state. Action owns a deviation or mechanical argument when the plan was
adequate. Memory owns a false/omitted state only when the proposition is
specific and downstream reasoning actually depends on it. System owns an
external execution boundary of an otherwise reasonable action.
"""


def build_sol_luna_module_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
) -> str:
    task = serial.build_agent_judge_luna_v3_serial_module_task(
        prediction_manifest_path,
        cohort_manifest_path,
        step_decisions_path,
        module_decisions_path,
    )
    task = task.replace(
        serial.AGENT_JUDGE_LUNA_V3_SERIAL_VERSION,
        AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_VERSION,
    )
    return task.replace("\nSTRICT OUTPUT CONTRACT\n", f"\n{_MODULE_ADDITION}\nSTRICT OUTPUT CONTRACT\n")


_TYPE_ADDITION = """
SOL-LUNA LATE-BOUND TYPE RULES
The proposer type hypotheses were intentionally withheld and are nonbinding.
Classify only the frozen source defect. For Planning: impossible_action means
the available interface truly cannot execute the required operation;
inefficient_plan remains feasible but wasteful, repetitive, or poorly chosen;
constraint_ignorance requires an explicit task constraint to be disregarded.
For Action: parameter_error is a mechanically wrong argument, while
misalignment is a concrete action that departs from an otherwise adequate
plan. Do not change Step or Module to obtain an easier taxonomy fit.
"""


def build_sol_luna_type_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
    predictions_path: str | Path,
) -> str:
    task = serial.build_agent_judge_luna_v3_serial_type_task(
        prediction_manifest_path,
        cohort_manifest_path,
        step_decisions_path,
        module_decisions_path,
        predictions_path,
    )
    task = task.replace(
        serial.AGENT_JUDGE_LUNA_V3_SERIAL_VERSION,
        AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_VERSION,
    )
    return task.replace(
        "\nLEGAL ERROR TYPES FOR THE FROZEN MODULE\n",
        f"\n{_TYPE_ADDITION}\nLEGAL ERROR TYPES FOR THE FROZEN MODULE\n",
    )


def build_sol_luna_serial_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    output = Path(predictions_path).expanduser().resolve()
    return build_sol_luna_type_task(
        prediction_manifest_path,
        cohort_manifest_path,
        output.parent / STEP_DECISIONS_FILENAME,
        output.parent / MODULE_DECISIONS_FILENAME,
        output,
    )


def validate_sol_luna_candidate_bound_step_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
) -> dict[str, Any]:
    step_path = Path(step_decisions_path).expanduser().resolve()
    proposals = step_path.parent / CANDIDATE_PROPOSALS_FILENAME
    projection = step_path.parent / STEP_CANDIDATES_FILENAME
    projection_audit = validate_sol_luna_step_candidates(
        prediction_manifest_path, cohort_manifest_path, proposals, projection
    )
    audit = serial.validate_agent_judge_luna_v3_serial_step_predictions(
        prediction_manifest_path, cohort_manifest_path, step_path
    )
    decisions = _load_json(step_path, role="step decisions")
    projected = _load_json(projection, role="step candidates")
    for index, (decision, row) in enumerate(zip(decisions, projected, strict=True)):
        available = {item["step"] for item in row["candidate_steps"]}
        if decision["predicted_step"] not in available:
            _fail("step_not_frozen_candidate", f"case {index} selected an unproposed step")
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_VERSION,
        "stage": "candidate-bound-step",
        "model": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_MODEL,
        "reasoning_effort": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_REASONING_EFFORT,
        "all_steps_from_label_free_projection": True,
        "candidate_count": projection_audit["candidate_count"],
        "projection_sha256": _file_sha256(projection),
    }


def validate_sol_luna_serial_step_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
) -> dict[str, Any]:
    audit = serial.validate_agent_judge_luna_v3_serial_step_predictions(
        prediction_manifest_path, cohort_manifest_path, step_decisions_path
    )
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_VERSION,
        "model": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_MODEL,
        "reasoning_effort": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_REASONING_EFFORT,
    }


def validate_sol_luna_serial_module_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
) -> dict[str, Any]:
    audit = serial.validate_agent_judge_luna_v3_serial_module_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        step_decisions_path,
        module_decisions_path,
    )
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_VERSION,
        "model": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_MODEL,
        "reasoning_effort": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_REASONING_EFFORT,
    }


def validate_sol_luna_serial_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = serial.validate_agent_judge_luna_v3_serial_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_VERSION,
        "model": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_MODEL,
        "reasoning_effort": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_REASONING_EFFORT,
        "serial_stage_count": 4,
        "candidate_type_late_bound": True,
        "step_candidate_labels_hidden": True,
        "stage_models": {
            "candidate-proposer": {
                "model": PROPOSER_MODEL,
                "reasoning_effort": PROPOSER_REASONING_EFFORT,
            },
            "step": {
                "model": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_MODEL,
                "reasoning_effort": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_REASONING_EFFORT,
            },
            "module": {
                "model": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_MODEL,
                "reasoning_effort": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_REASONING_EFFORT,
            },
            "error-type": {
                "model": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_MODEL,
                "reasoning_effort": AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_REASONING_EFFORT,
            },
        },
    }


def validate_and_write_sol_luna_candidate_bound_step_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_sol_luna_candidate_bound_step_predictions(
        prediction_manifest_path, cohort_manifest_path, step_decisions_path
    )
    return serial._write_audit(audit_path, audit)


def validate_and_write_sol_luna_serial_module_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    step_decisions_path: str | Path,
    module_decisions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_sol_luna_serial_module_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        step_decisions_path,
        module_decisions_path,
    )
    return serial._write_audit(audit_path, audit)


def validate_and_write_sol_luna_serial_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_sol_luna_serial_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return serial._write_audit(audit_path, audit)


__all__ = [
    "AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_MODEL",
    "AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_REASONING_EFFORT",
    "AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_VERSION",
    "CANDIDATE_PROPOSALS_FILENAME",
    "MODULE_AUDIT_FILENAME",
    "MODULE_DECISIONS_FILENAME",
    "PROPOSER_MODEL",
    "PROPOSER_REASONING_EFFORT",
    "STEP_AUDIT_FILENAME",
    "STEP_CANDIDATES_FILENAME",
    "STEP_DECISIONS_FILENAME",
    "build_sol_luna_candidate_task",
    "build_sol_luna_module_task",
    "build_sol_luna_serial_task",
    "build_sol_luna_step_task",
    "build_sol_luna_type_task",
    "validate_and_write_sol_luna_candidate_bound_step_audit",
    "validate_and_write_sol_luna_serial_audit",
    "validate_and_write_sol_luna_serial_module_audit",
    "validate_sol_luna_candidate_bound_step_predictions",
    "validate_sol_luna_serial_module_predictions",
    "validate_sol_luna_serial_predictions",
    "validate_sol_luna_serial_step_predictions",
    "validate_sol_luna_step_candidates",
    "write_sol_luna_step_candidates",
]

"""Luna GAIA v3.33: clean v3.20 with anchor-blind census candidate freeze."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger as transport
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from .taxonomy import taxonomy_prompt


AGENT_JUDGE_LUNA_GAIA_V3_33_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.33-clean-v3.20-"
    "anchor-blind-complete-step-census-freeze"
)
AGENT_JUDGE_LUNA_GAIA_V3_33_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_33_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_33_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility names used by the shared scoring/diagnostics code.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_33_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_33_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_33_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_33_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = transport.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = transport.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = transport.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = transport.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = transport.CHALLENGERS_FILENAME
ARBITER_FILENAME = transport.ARBITER_FILENAME
ARBITERS_FILENAME = transport.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = transport.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = transport.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = transport.PREDICTION_AUDIT_FILENAME

CENSUS_FILENAME = "anchor-blind-census.json"
CENSUSES_FILENAME = "anchor-blind-censuses.json"
CENSUS_AUDIT_FILENAME = "anchor-blind-census-audit.json"

CENSUS_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "candidate_status",
    "candidate_step",
    "candidate_prediction",
    "search_summary",
    "candidate_falsifier",
    "candidate_only_repair_counterfactual",
    "timeline_comparison",
)
CANDIDATE_STATUSES = frozenset({"candidate", "none"})
_CENSUS_PREFIX = re.compile(
    r"^step_census=([^;]+); census_candidate_step=(none|[1-9]\d*); "
)
_CENSUS_ENTRY = re.compile(r"^([1-9]\d*):([a-z_]+)$")
_CENSUS_VERDICTS = frozenset(
    {
        "clear",
        "reasonable_probe",
        "normal_failure",
        "recovered_or_mechanical",
        "faithful_propagation",
        "noncritical_local_error",
        "critical_candidate",
    }
)
_COMPARATOR_PREFIX = re.compile(
    r"^independent_census_sha256=([0-9a-f]{64}); "
    r"census_candidate_step=(none|[1-9]\d*); "
    r"census_direction=(none|earlier|same|later); "
)


_ANCHOR_BLIND_CENSUS_RULES = """\
ANCHOR-BLIND COMPLETE-STEP CENSUS — ONE FROZEN CANDIDATE MAXIMUM

The incumbent anchor is intentionally unavailable in this session. Do not
search for it, infer it, or choose a candidate relative to it. Inspect every
Canonical Step exactly once in chronological order and assign exactly one
closed verdict:

- `clear`: no concrete task-material local error is observable.
- `reasonable_probe`: an initial or materially different attempt can expose a
  needed fact, source, identifier, page, or lead.
- `normal_failure`: the action was reasonable and only the tool/site outcome
  failed; an error message alone is not an Agent error.
- `recovered_or_mechanical`: a defect is fully repaired or merely a
  noncritical mechanical predecessor to a later strategy/state decision.
- `faithful_propagation`: the Step only carries an unresolved earlier state or
  evidence gap without creating an independent error.
- `noncritical_local_error`: a real but merely improvable local defect does not
  own the trajectory's critical benchmark boundary.
- `critical_candidate`: the single Step that best owns the observable matured
  critical boundary after comparing the entire timeline.

Freeze at most one critical_candidate. It requires literal local evidence in
its owning module, a still-unresolved task condition, a candidate-only repair
counterfactual that can change the subsequent path or answer, and explicit
comparison against earlier probes/mechanical predecessors and later
propagation/symptoms. Do not prefer earliest position, latest position,
severity, explicit wording, persistence, or Planning ownership by itself.

A repeated strategy matures only after literal prior feedback rules out the
normalized route and the new Step adds no material target, corpus, interface,
or extraction change. A static interface is a capability error only when
visible evidence proves it cannot expose the required predicate; otherwise it
may be an informative probe. Successful execution vetoes a parameter-format
error unless literal feedback rejects or misparses the field. If the evidence
cannot distinguish critical ownership, freeze none.

Begin search_summary exactly:
`step_census=1:<verdict>,2:<verdict>,...; census_candidate_step=<none|Step>; `

The certificate must list every observable Step exactly once and in order.
Exactly one row is critical_candidate when a candidate exists; zero rows use
that verdict for none. The frozen candidate_prediction must be a complete legal
prediction owned by exactly candidate_step. Never emit a second candidate.
"""


_FROZEN_CANDIDATE_COMPARATOR_RULES = """\
FROZEN ANCHOR VERSUS ANCHOR-BLIND CENSUS CANDIDATE

Both inputs are immutable. The census candidate was generated without seeing
the anchor. You may either keep the anchor or emit the exact frozen census
prediction as the sole proposal. Never create, repair, or select a third
prediction. The anchor remains the default under uncertainty.

- When census status is none or its Step equals the anchor, emit no_challenge.
- For an earlier census candidate, challenge only when literal chronology
  proves the anchor is a downstream symptom and repairing only the anchor
  cannot remove the earlier defect.
- For a later census candidate, challenge only when the anchor is a reasonable
  probe or noncritical predecessor and the later candidate remains
  independently failure-causing after anchor-only repair.
- Reject reasonable probes, normal failures, recovered/mechanical defects,
  faithful propagation, noncritical predecessors, and downstream symptoms.
- Do not prefer either input because it is earlier, later, more severe, more
  explicit, more persistent, or has a longer explanation.

Use both repair counterfactuals and direct_timeline_comparison to compare the
anchor, the frozen candidate, and every intervening plausible boundary. A
challenge proposal must be a field-for-field exact copy of
candidate_prediction. When uncertain, emit no_challenge.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_33_VERSION,
        )
        .replace(
            transport.AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_33_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_33_clean_v3p20_anchor_blind_complete_step_census_freeze",
        )
        .replace(
            "agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger",
            "agent_judge_luna_gaia_v3_33_clean_v3p20_anchor_blind_complete_step_census_freeze",
        )
    )


def _retag(audit: dict[str, Any]) -> dict[str, Any]:
    result = dict(audit)
    result["agent_judge_version"] = AGENT_JUDGE_LUNA_GAIA_V3_33_VERSION
    result["model"] = AGENT_JUDGE_LUNA_GAIA_V3_33_MODEL
    result["reasoning_effort"] = AGENT_JUDGE_LUNA_GAIA_V3_33_REASONING_EFFORT
    return result


def _boundary(
    *, manifest: Path, cohort: Path, reads: Sequence[Path], output: Path
) -> str:
    read_lines = "\n".join(f"- {path}" for path in reads) or "- none"
    return f"""\
IMMUTABLE EXECUTION CONFIGURATION
- model: {AGENT_JUDGE_LUNA_GAIA_V3_33_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_33_REASONING_EFFORT}
- one isolated case; fresh session; no cross-case state or prior predictions
- external LLM/API/network calls: forbidden
- scoring or gold-label access: forbidden

INPUT/OUTPUT BOUNDARY
- prediction manifest: {manifest}
- prediction manifest file sha256: {shared._file_sha256(manifest)}
- cohort manifest: {cohort}
- cohort manifest file sha256: {shared._file_sha256(cohort)}
- permitted frozen stage inputs:
{read_lines}
- write the sole stage artifact only to: {output}

Read only those exact inputs plus this v3.33 protocol source, the v3.20
protocol source, and `agentdebug/diagnostics/taxonomy.py`. Do not inspect
directories or infer from trajectory/source-model/environment names. Never
read labels, metrics, scored artifacts, promotion files, experiment documents,
old predictions, cached replies, case studies, git history, or external resources.
"""


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_anchor_task(*paths)).replace(
        "stage 1/3", "stage 1/4"
    )


def _validate_census_record(raw: Any, *, case: Any, location: str) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != CENSUS_FIELDS:
        shared._fail("invalid_anchor_blind_census_schema", f"{location} fields/order differ")
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
    ):
        shared._fail("anchor_blind_census_identity_mismatch", location)
    if raw["candidate_status"] not in CANDIDATE_STATUSES:
        shared._fail("invalid_anchor_blind_candidate_status", location)
    for field in (
        "search_summary",
        "candidate_falsifier",
        "candidate_only_repair_counterfactual",
        "timeline_comparison",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3000)
    match = _CENSUS_PREFIX.match(raw["search_summary"])
    if match is None:
        shared._fail("missing_anchor_blind_complete_census_prefix", location)
    census_text, candidate_text = match.groups()
    entries: list[tuple[int, str]] = []
    for entry_text in census_text.split(","):
        entry_match = _CENSUS_ENTRY.match(entry_text)
        if entry_match is None:
            shared._fail("invalid_anchor_blind_census_entry", f"{location}:{entry_text}")
        step_text, verdict = entry_match.groups()
        if verdict not in _CENSUS_VERDICTS:
            shared._fail("invalid_anchor_blind_census_verdict", f"{location}:{verdict}")
        entries.append((int(step_text), verdict))
    expected_steps = [step.step for step in case.judge_view.steps]
    if [step for step, _ in entries] != expected_steps:
        shared._fail("anchor_blind_census_step_list_mismatch", location)
    critical_steps = [step for step, verdict in entries if verdict == "critical_candidate"]
    certificate_step = None if candidate_text == "none" else int(candidate_text)
    candidate_step = raw["candidate_step"]
    if raw["candidate_status"] == "none":
        if (
            candidate_step is not None
            or raw["candidate_prediction"] is not None
            or certificate_step is not None
            or critical_steps
        ):
            shared._fail("invalid_empty_anchor_blind_candidate", location)
    else:
        if (
            isinstance(candidate_step, bool)
            or not isinstance(candidate_step, int)
            or candidate_step not in expected_steps
            or certificate_step != candidate_step
            or critical_steps != [candidate_step]
        ):
            shared._fail("anchor_blind_candidate_binding_mismatch", location)
        prediction = shared._validate_prediction_record(
            raw["candidate_prediction"],
            case=case,
            location=f"{location}.candidate_prediction",
        )
        if prediction["predicted_step"] != candidate_step:
            shared._fail("anchor_blind_candidate_prediction_step_mismatch", location)
    return raw


def _load_census(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    census_path: str | Path,
) -> tuple[Path, Path, Any, Path, dict[str, Any]]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    census_file, raw = shared._load_artifact(census_path, role="anchor-blind census")
    record = shared._one_record(raw, role="anchor-blind census")
    _validate_census_record(record, case=case, location="anchor_blind_census[0]")
    return manifest, cohort, case, census_file, record


def validate_census(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    census_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, _case, census_file, record = _load_census(
        prediction_manifest_path, cohort_manifest_path, census_path
    )
    return {
        "schema_version": "agentdebug.anchor-blind-complete-step-census-audit.v1",
        "stage": "anchor_blind_census",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_33_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_33_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_33_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": 1,
        "anchor_visible": False,
        "historical_prediction_visible": False,
        "complete_step_enumeration": True,
        "one_candidate_maximum": True,
        "candidate_status": record["candidate_status"],
        "candidate_step": record["candidate_step"],
        "input_sha256": {
            "prediction_manifest": shared._file_sha256(manifest),
            "cohort": shared._file_sha256(cohort),
        },
        "output_sha256": {CENSUS_FILENAME: shared._file_sha256(census_file)},
    }


def build_census_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    census_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    output = Path(census_path).expanduser().resolve()
    shared._assert_safe_path(output, role="anchor-blind census output", is_output=True)
    audit = output.parent / CENSUS_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_33_clean_v3p20_anchor_blind_complete_step_census_freeze",
            "--compact-validate",
            "census",
            manifest,
            cohort,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    candidate_schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        "predicted_step": "candidate Step integer",
        "predicted_module": "taxonomy module",
        "predicted_error_type": "taxonomy error type",
        "evidence_quote": "literal substring owned by predicted Step/module",
        "root_cause": "specific local Judge-visible error",
        "causal_summary": "repair counterfactual and path effect",
        "rejected_adjacent_owner": "strongest adjacent alternative and veto",
    }
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "candidate_status": "candidate or none",
        "candidate_step": "integer or null",
        "candidate_prediction": candidate_schema,
        "search_summary": "step_census=1:clear,...; census_candidate_step=none; complete certificate",
        "candidate_falsifier": "literal admission and veto evidence, or why none survives",
        "candidate_only_repair_counterfactual": "candidate-only path intervention",
        "timeline_comparison": "complete earlier/later boundary comparison",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_33_VERSION} stage 2/4: anchor-blind census freeze.

{_boundary(manifest=manifest, cohort=cohort, reads=(), output=output)}

The anchor prediction, anchor ledger, anchor checkpoint, incumbent per-case
prediction, and all historical predictions are absent by construction. Do not
inspect the output directory or other task artifacts.

{_ANCHOR_BLIND_CENSUS_RULES}

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

For candidate_status=none, set candidate_step and candidate_prediction to null.
For candidate_status=candidate, replace every placeholder in candidate_prediction
with a complete legal value. After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _load_anchor_and_census(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    census_path: str | Path,
) -> tuple[
    Path,
    Path,
    Any,
    Path,
    Path,
    Path,
    dict[str, Any],
    dict[str, Any],
    dict[str, Any],
    Path,
    dict[str, Any],
]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    anchor, ledger, checkpoint = shared._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    parent._validate_packet_state_ledgers(ledger_file)
    census_file, census_raw = shared._load_artifact(
        census_path, role="anchor-blind census"
    )
    census = shared._one_record(census_raw, role="anchor-blind census")
    _validate_census_record(census, case=case, location="anchor_blind_census[0]")
    return (
        manifest,
        cohort,
        case,
        anchor_file,
        ledger_file,
        checkpoint_file,
        anchor,
        ledger,
        checkpoint,
        census_file,
        census,
    )


def _validate_comparator_binding(
    challenger: dict[str, Any],
    *,
    anchor: dict[str, Any],
    census: dict[str, Any],
    location: str,
) -> str:
    match = _COMPARATOR_PREFIX.match(challenger["search_summary"])
    if match is None:
        shared._fail("missing_independent_census_comparator_prefix", location)
    census_sha, candidate_text, direction = match.groups()
    if census_sha != shared._stable_sha256(census):
        shared._fail("comparator_census_hash_mismatch", location)
    candidate_step = census["candidate_step"]
    expected_text = "none" if candidate_step is None else str(candidate_step)
    if candidate_text != expected_text:
        shared._fail("comparator_census_step_mismatch", location)
    anchor_step = anchor["predicted_step"]
    expected_direction = (
        "none"
        if candidate_step is None
        else "earlier"
        if candidate_step < anchor_step
        else "later"
        if candidate_step > anchor_step
        else "same"
    )
    if direction != expected_direction:
        shared._fail("comparator_census_direction_mismatch", location)
    if candidate_step is None or candidate_step == anchor_step:
        if challenger["challenge_status"] != "no_challenge":
            shared._fail("non_distinct_census_must_not_challenge", location)
    elif challenger["challenge_status"] == "challenge":
        if challenger["proposed_prediction"] != census["candidate_prediction"]:
            shared._fail("proposal_not_exact_census_copy", location)
    return direction


def validate_challenger(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    census_path: str | Path,
    challenger_path: str | Path,
) -> dict[str, Any]:
    values = _load_anchor_and_census(
        prediction_manifest_path,
        cohort_manifest_path,
        anchor_path,
        ledger_path,
        checkpoint_path,
        census_path,
    )
    (
        _manifest,
        _cohort,
        case,
        anchor_file,
        ledger_file,
        checkpoint_file,
        anchor,
        ledger,
        checkpoint,
        census_file,
        census,
    ) = values
    challenger_file, raw = shared._load_artifact(challenger_path, role="comparator")
    challenger = shared._one_record(raw, role="comparator")
    transport._validate_challenger_record(
        challenger,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        location="comparator[0]",
    )
    direction = _validate_comparator_binding(
        challenger, anchor=anchor, census=census, location="comparator[0]"
    )
    return {
        "schema_version": "agentdebug.frozen-anchor-blind-census-comparator-audit.v1",
        "stage": "frozen_candidate_comparator",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_33_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_33_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_33_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": 1,
        "challenge_status": challenger["challenge_status"],
        "census_direction": direction,
        "one_census_candidate_maximum": True,
        "proposal_exact_census_copy": challenger["challenge_status"] != "challenge"
        or challenger["proposed_prediction"] == census["candidate_prediction"],
        "third_prediction_forbidden": True,
        "input_sha256": {
            ANCHOR_PREDICTIONS_FILENAME: shared._file_sha256(anchor_file),
            "step-candidates.json": shared._file_sha256(ledger_file),
            "step-freeze.json": shared._file_sha256(checkpoint_file),
            CENSUS_FILENAME: shared._file_sha256(census_file),
        },
        "output_sha256": {CHALLENGER_FILENAME: shared._file_sha256(challenger_file)},
    }


def build_challenger_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    census_path: str | Path,
    challenger_path: str | Path,
) -> str:
    values = _load_anchor_and_census(
        prediction_manifest_path,
        cohort_manifest_path,
        anchor_path,
        ledger_path,
        checkpoint_path,
        census_path,
    )
    (
        manifest,
        cohort,
        case,
        anchor_file,
        ledger_file,
        checkpoint_file,
        anchor,
        ledger,
        checkpoint,
        census_file,
        census,
    ) = values
    output = Path(challenger_path).expanduser().resolve()
    shared._assert_safe_path(output, role="comparator output", is_output=True)
    audit = output.parent / CHALLENGER_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_33_clean_v3p20_anchor_blind_complete_step_census_freeze",
            "--compact-validate",
            "challenger",
            manifest,
            cohort,
            anchor_file,
            ledger_file,
            checkpoint_file,
            census_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    candidate_step = census["candidate_step"]
    direction = (
        "none"
        if candidate_step is None
        else "earlier"
        if candidate_step < anchor["predicted_step"]
        else "later"
        if candidate_step > anchor["predicted_step"]
        else "same"
    )
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "anchor_step": anchor["predicted_step"],
        "challenge_status": "no_challenge or challenge",
        "anchor_classification": "critical_root/reasonable_probe/noncritical_predecessor/downstream_symptom/uncertain",
        "anchor_veto_evidence_step": "integer or null",
        "anchor_veto_evidence_quote": "literal packet substring or null",
        "proposed_prediction": "exact candidate_prediction copy or null",
        "anchor_falsifier": "compact literal-evidence explanation",
        "anchor_only_repair_counterfactual": "compact path intervention",
        "proposal_only_repair_counterfactual": "compact path intervention",
        "direct_timeline_comparison": "anchor/candidate/intervening comparison",
        "search_summary": (
            f"independent_census_sha256={shared._stable_sha256(census)}; "
            f"census_candidate_step={candidate_step if candidate_step is not None else 'none'}; "
            f"census_direction={direction}; compact comparison"
        ),
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_33_VERSION} stage 3/4: frozen-candidate comparator.

{_boundary(manifest=manifest, cohort=cohort, reads=(anchor_file, ledger_file, checkpoint_file, census_file), output=output)}

The frozen anchor Step is {anchor['predicted_step']}. The independently frozen
census status is {census['candidate_status']} and candidate Step is
{candidate_step}. Neither frozen artifact may be changed.

{_FROZEN_CANDIDATE_COMPARATOR_RULES}

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

Begin search_summary with the exact certificate shown in the schema. For
no_challenge set both veto fields and proposed_prediction to null. For challenge,
proposed_prediction must be an exact copy of the census candidate_prediction.
After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def build_arbiter_task(*paths: str | Path) -> str:
    task = transport.build_arbiter_task(*paths)
    if task.count(transport._BOUNDED_BIDIRECTIONAL_RULES) != 1:
        raise RuntimeError("bidirectional arbiter rule marker changed unexpectedly")
    task = task.replace(
        transport._BOUNDED_BIDIRECTIONAL_RULES,
        _FROZEN_CANDIDATE_COMPARATOR_RULES,
        1,
    )
    return _rewrite_identity(task).replace("stage 3/3", "stage 4/4")


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths))


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    return _retag(transport.validate_arbiter(*paths))


def _validate_census_collection(
    path: str | Path, cases: Sequence[Any]
) -> tuple[Path, list[dict[str, Any]], dict[str, Any]]:
    census_file, raw = shared._load_artifact(path, role="merged anchor-blind censuses")
    if (
        not isinstance(raw, list)
        or len(raw) != len(cases)
        or any(not isinstance(item, dict) for item in raw)
    ):
        shared._fail("invalid_anchor_blind_census_record_count", "case/record count differs")
    status_counts: Counter[str] = Counter()
    verdict_counts: Counter[str] = Counter()
    for index, (record, case) in enumerate(zip(raw, cases, strict=True)):
        _validate_census_record(
            record, case=case, location=f"anchor_blind_census[{index}]"
        )
        status_counts[record["candidate_status"]] += 1
        match = _CENSUS_PREFIX.match(record["search_summary"])
        assert match is not None
        for entry_text in match.group(1).split(","):
            entry_match = _CENSUS_ENTRY.match(entry_text)
            assert entry_match is not None
            verdict_counts[entry_match.group(2)] += 1
    return census_file, raw, {
        "required": True,
        "valid": True,
        "path": str(census_file),
        "record_count": len(raw),
        "anchor_visible": False,
        "exact_complete_step_enumeration": True,
        "one_candidate_maximum": True,
        "candidate_status_counts": dict(sorted(status_counts.items())),
        "verdict_counts": dict(sorted(verdict_counts.items())),
    }


def validate_agent_judge_luna_gaia_v3_33_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = _retag(
        transport.validate_agent_judge_luna_gaia_v3_16_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        )
    )
    _, _, cases = shared._load_cases(prediction_manifest_path, cohort_manifest_path)
    root = Path(predictions_path).expanduser().resolve().parent
    census_file, censuses, census_audit = _validate_census_collection(
        root / CENSUSES_FILENAME, cases
    )
    _, anchors = shared._load_artifact(
        root / ANCHOR_PREDICTIONS_FILENAME, role="merged anchors"
    )
    _, challengers = shared._load_artifact(
        root / CHALLENGERS_FILENAME, role="merged comparators"
    )
    direction_counts: Counter[str] = Counter()
    exact_copy_count = 0
    for index, (anchor, census, challenger) in enumerate(
        zip(anchors, censuses, challengers, strict=True)
    ):
        direction = _validate_comparator_binding(
            challenger,
            anchor=anchor,
            census=census,
            location=f"merged_comparator[{index}]",
        )
        direction_counts[direction] += 1
        if (
            challenger["challenge_status"] != "challenge"
            or challenger["proposed_prediction"] == census["candidate_prediction"]
        ):
            exact_copy_count += 1
    audit["schema_version"] = AGENT_JUDGE_LUNA_GAIA_V3_33_AUDIT_SCHEMA_VERSION
    audit["selection_policy"] = (
        "clean_v3_20_packet_state_anchor_anchor_blind_complete_step_census_"
        "freeze_then_exact_candidate_comparator_default_keep_arbiter"
    )
    audit["direct_semantic_parent"] = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION
    audit["rejected_lineage_inherited"] = False
    audit["anchor_semantics_unchanged_from_v3_20"] = True
    audit["packet_state_closure"] = parent._validate_packet_state_ledgers(
        root / ANCHOR_LEDGER_AGGREGATE_FILENAME
    )
    audit["anchor_blind_complete_step_census"] = census_audit
    audit["comparator_census_direction_counts"] = dict(sorted(direction_counts.items()))
    audit["all_comparator_proposals_exact_census_copies"] = (
        exact_copy_count == len(cases)
    )
    audit["input_sidecar_sha256"] = {
        **audit["input_sidecar_sha256"],
        CENSUSES_FILENAME: shared._file_sha256(census_file),
    }
    return audit


def build_agent_judge_luna_gaia_v3_33_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_census_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_census(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_33_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_33_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_33_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_33_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_33_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "census" and len(paths) == 4:
            audit = validate_and_write_census_audit(*paths)
        elif stage == "challenger" and len(paths) == 8:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_33_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument(
        "stage", choices=("anchor", "census", "challenger", "arbiter", "prediction")
    )
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

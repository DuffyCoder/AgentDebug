"""Luna Agent Judge v2: upstream-introduction causal ownership.

This is a frozen successor to :mod:`agent_judge_luna_v1`.  It keeps the
v2.4 evidence policy and strict ten-field validator, while replacing the
whole-episode late-root preference with one uniform, gold-free upstream
ownership ledger.  Historical Luna v1 source and artifacts remain immutable.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_v2_4 import (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_V2_4_MODEL,
    AGENT_JUDGE_V2_4_VERSION,
    _v2_4_owner_source_resolver,
    build_agent_judge_v2_4_task,
)


AGENT_JUDGE_LUNA_V2_VERSION = "agentdebug.codex-agent-judge.luna-v2"
AGENT_JUDGE_LUNA_V2_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_V2_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_V2_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)

_BASE_HEADER = f"Run the frozen Codex Agent Judge protocol {AGENT_JUDGE_V2_4_VERSION}."
_LUNA_HEADER = (
    "Run the frozen Codex Agent Judge protocol "
    f"{AGENT_JUDGE_LUNA_V2_VERSION}."
)
_BASE_MODEL = f"- model: {AGENT_JUDGE_V2_4_MODEL}"
_LUNA_MODEL = f"- model: {AGENT_JUDGE_LUNA_V2_MODEL}"
_BASE_ALLOWLIST = "agentdebug/diagnostics/agent_judge_v2_4.py"
_LUNA_ALLOWLIST = "agentdebug/diagnostics/agent_judge_luna_v2.py"
_BASE_VALIDATOR_IMPORT = "agentdebug.diagnostics.agent_judge_v2_4"
_LUNA_VALIDATOR_IMPORT = "agentdebug.diagnostics.agent_judge_luna_v2"
_BASE_VALIDATOR_ENTRY = "validate_and_write_agent_judge_v2_4_audit"
_LUNA_VALIDATOR_ENTRY = "validate_and_write_agent_judge_luna_v2_audit"
_TAXONOMY_MARKER = "\nAGENT ERROR TAXONOMY\n"

_LUNA_V2_DELTA = """
LUNA V2 UPSTREAM-INTRODUCTION LEDGER

This protocol is optimized only on the complete frozen tuning-v1 cohort.  The
rules below are identical for every case.  Never use a case ID, environment
name, cross-case distribution, target step, target module, or prior prediction
to choose a diagnosis.

CRITICAL STEP MEANS ERROR INTRODUCTION, NOT FAILURE MANIFESTATION

Keep two chronological clocks separate:
- introduction clock: the first assistant output whose selected module already
  contains a concrete, locally mature error under information available then;
- manifestation clock: later repetition, exhaustion, bad final state, or
  termination that makes the consequence conspicuous.

The critical step follows the introduction clock.  Select the earliest
non-redundant error introduction on the causal branch that explains the
failure.  Do not select a later output merely because its isolated correction
would help more immediately, it is closer to termination, it repeats the error
many times, or it supplies an easier taxonomy label or evidence quote.

MANDATORY UPSTREAM OWNERSHIP LEDGER

Before selecting, internally record the earliest locally mature candidate for
each of Memory, Reflection, Planning, Action, and System, when one exists.  For
every later candidate, trace the belief, assessment, target, query, strategy,
or parameter it uses to the first earlier assistant source that introduced it.
Classify the later candidate as exactly one of:
- PROPAGATION: repeats, executes, paginates, or continues an already defective
  upstream state or branch;
- RECOVERY: explicitly corrects the upstream proposition and restores the
  task-relevant state;
- NOVEL ERROR: introduces a distinct defect not inherited from upstream.

A PROPAGATION candidate cannot displace its upstream owner.  Repeated search,
continued pagination, another attempt at the same target, and a final answer
carrying the same mistaken derivation are presumptively propagation; promote
one only when its own source makes a new decision after the previous defect was
fully repaired or when every earlier probe was reasonable and new feedback
first makes this recommitment erroneous.

Recovery is strict.  A strategy reset, changed query, or temporary local
success is not recovery unless it retracts or corrects the original false
memory/assessment/decision and later behavior no longer depends on it.  A new
independent error after complete recovery may win on its own introduction
clock.  Otherwise the earlier unrepaired owner remains the critical step even
if the later symptom is more severe.

SAME-STEP MODULE HANDOFF

Within one assistant step, apply the same introduction test across the actual
module sources rather than preferring Planning or Action:
- if Memory drops, fails to retrieve, or invents state and later blocks accept
  it, Memory introduces the error;
- if accurate memory/result evidence is followed by a false progress, outcome,
  or causal assessment and the plan adopts it, Reflection introduces it;
- if Memory and Reflection are adequate but the strategy, constraint handling,
  prerequisite, target, or query choice is newly defective, Planning owns it;
- if the plan is adequate and the concrete invocation or final emission
  deviates, is malformed, uses an unavailable operation, or mechanically
  misfills a parameter, Action owns it.

Faithful downstream text never takes ownership.  In particular, a plan that
merely operationalizes a false reflection is not a new Planning error, and an
action that faithfully executes a defective plan is not a new Action error.

FIRST MATURE COMMITMENT, WITHOUT HINDSIGHT

Initial exploration is not erroneous only because it later fails.  A search or
probe becomes a mature error at the first output where then-available evidence
shows that its query cannot supply the requested information, it violates a
known constraint, it repeats an exhausted branch, or it ignores direct
feedback.  Once such a commitment is mature, later copies stay downstream.
When two candidates belong to the same causal chain, prefer this first mature
commitment.  A later candidate wins only with a clearly stated NOVEL ERROR or
complete recovery of the earlier one.

SYSTEM IS AN INDEPENDENT BOUNDARY CANDIDATE

Always compare the final provenance-backed execution facts.  Select System
when an observable step limit, tool failure, model limit, or environment fault
independently prevents completion while the agent's preceding behavior is
reasonable.  Do not replace such a boundary with a merely suboptimal plan.
Conversely, ordinary task failure or exhaustion after agent error is not a
System diagnosis.

TAXONOMY IS APPLIED LAST

Only after freezing step and owner, choose the legal type that the literal
owner evidence satisfies.  In particular:
- planning/inefficient_plan is admitted for the first unnecessarily wasteful,
  repetitive, or illogical strategy commitment, never as a generic label for
  a later failed trajectory;
- action/parameter_error requires a mechanically missing, malformed,
  wrong-typed, or misfilled concrete argument, not a strategy-level query;
- action/format_error requires interface syntax that is unparseable, not a
  merely incomplete or wrong natural-language answer;
- action/invalid_action requires an operation outside the available action
  space;
- planning/impossible_action requires a genuinely impossible state,
  prerequisite, or operation, not a poor but executable search.

If the frozen candidate has no legal type supported by its own evidence, reject
that candidate and resume the upstream comparison.  Never let type convenience
move the step or owner downstream.  In rejected_adjacent_owner, name the
strongest later or adjacent competitor and state whether it loses as
PROPAGATION, complete recovery, lack of a novel defect, or lack of independent
causal force.
"""


def build_agent_judge_luna_v2_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build v2.4's canonical task with the frozen Luna v2 decision delta."""

    task = build_agent_judge_v2_4_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    expected_once = {
        _BASE_HEADER: _LUNA_HEADER,
        _BASE_MODEL: _LUNA_MODEL,
        _BASE_ALLOWLIST: _LUNA_ALLOWLIST,
        _BASE_VALIDATOR_IMPORT: _LUNA_VALIDATOR_IMPORT,
        _BASE_VALIDATOR_ENTRY: _LUNA_VALIDATOR_ENTRY,
        _TAXONOMY_MARKER: f"\n{_LUNA_V2_DELTA.strip()}\n{_TAXONOMY_MARKER}",
    }
    for old, new in expected_once.items():
        if task.count(old) != 1:
            raise RuntimeError(
                "Agent Judge v2.4 task changed at a frozen Luna v2 marker"
            )
        task = task.replace(old, new, 1)
    task = task.replace(
        "v2.4\nprotocol/taxonomy source",
        "Luna v2\nprotocol/taxonomy source",
    )
    return task


def validate_agent_judge_luna_v2_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    """Validate with v2.4 evidence semantics and Luna v2 audit identity."""

    audit = _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_v2_4_owner_source_resolver,
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_V2_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_V2_VERSION,
        "model": AGENT_JUDGE_LUNA_V2_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V2_REASONING_EFFORT,
    }


def validate_and_write_agent_judge_luna_v2_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    """Validate first and atomically persist a Luna v2 audit on success."""

    audit = validate_agent_judge_luna_v2_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


__all__ = [
    "AGENT_JUDGE_LUNA_V2_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_V2_MODEL",
    "AGENT_JUDGE_LUNA_V2_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_V2_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "build_agent_judge_luna_v2_task",
    "validate_agent_judge_luna_v2_predictions",
    "validate_and_write_agent_judge_luna_v2_audit",
]

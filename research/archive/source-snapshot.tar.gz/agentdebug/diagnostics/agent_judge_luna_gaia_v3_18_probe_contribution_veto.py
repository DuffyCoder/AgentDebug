"""Luna GAIA v3.18: validator-audited acquisition probe contribution veto."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_14_earliest_causal_challenger as parent
from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from .agent_judge_luna_gaia_v3_4 import (
    STEP_CANDIDATE_LEDGER_FILENAME,
    validate_agent_judge_luna_gaia_v3_4_predictions,
)


AGENT_JUDGE_LUNA_GAIA_V3_18_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.18-probe-contribution-veto"
)
AGENT_JUDGE_LUNA_GAIA_V3_18_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_14_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_18_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_14_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_18_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_14_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases used by the shared three-stage runner.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_18_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_18_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_18_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_18_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = parent.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = parent.CHALLENGERS_FILENAME
ARBITER_FILENAME = parent.ARBITER_FILENAME
ARBITERS_FILENAME = parent.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = parent.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = parent.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
CHALLENGER_FIELDS = parent.CHALLENGER_FIELDS
ARBITER_FIELDS = parent.ARBITER_FIELDS


_CONTRIBUTION_PREFIX = re.compile(
    r"^boundary_kind=(acquisition_probe|other); "
    r"contribution=(possible|observed|zero|not_applicable); "
)

_PROBE_CONTRIBUTION_GATE = """\
PROBE-CONTRIBUTION GATE — BINDING BEFORE LANE-B CAPABILITY ADMISSION

An acquisition route is any plan or Action intended to retrieve external
content, a source, identifier, page, title, text, transcript lead, numerical
input, or other evidence for the current unresolved subgoal. Do not project the
final proof requirement backward onto such a route.

For every inspected Step, begin decision_basis with exactly one of:

- `boundary_kind=other; contribution=not_applicable; ` when the Step is not an
  acquisition route;
- `boundary_kind=acquisition_probe; contribution=observed; ` when this Step's
  packet actually supplies task-relevant intermediate evidence;
- `boundary_kind=acquisition_probe; contribution=possible; ` when no literal
  interface fact or prior outcome rules out supplying a necessary identifier,
  page, text, source, transcript lead, numerical input, or immediate-subgoal
  clue;
- `boundary_kind=acquisition_probe; contribution=zero; ` only when literal
  interface/corpus and chronology evidence proves the route cannot expose even
  a necessary intermediate for the current unresolved subgoal.

`possible` and `observed` are binding vetoes on a Lane-B capability candidate:
use `veto_initial_probe` for the first reasonable route or
`veto_different_probe` for a materially different/refined route. They do not
veto an independently false Memory/Reflection state, an eligible literal System
exception, or a Lane-C repeat after direct feedback has exhausted the normalized
strategy.

An exact dynamic-video frame/narration predicate assigned to a static page-text
extractor, or an exact dynamic UI flag assigned to a static corpus interface,
may remain a direct capability root only when the immediate unresolved predicate
is already identified and contribution is literally `zero`. Merely being unable
to prove the final answer is never sufficient for `zero`.

"""


def _rewrite_parent_task(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_14_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_18_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_14_earliest_causal_challenger",
            "agent_judge_luna_gaia_v3_18_probe_contribution_veto",
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_14_earliest_causal_challenger.py",
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_18_probe_contribution_veto.py",
        )
    )


def _rewrite_anchor_validator(task: str) -> str:
    task = task.replace(
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_4.py",
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_18_probe_contribution_veto.py",
    )
    task = task.replace(
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_4 import "
        "validate_and_write_agent_judge_luna_gaia_v3_4_audit as run",
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_18_probe_contribution_veto "
        "import validate_and_write_anchor_audit as run",
    )
    return task


def build_anchor_task(*paths: str | Path) -> str:
    task = _rewrite_anchor_validator(_rewrite_parent_task(parent.build_anchor_task(*paths)))
    marker = "Tool availability is not capability.  If a tool description/corpus cannot\n"
    if task.count(marker) != 1:
        raise RuntimeError("v3.14 Lane-B capability boundary changed unexpectedly")
    task = task.replace(marker, _PROBE_CONTRIBUTION_GATE + marker, 1)
    task = task.replace(
        '"decision_basis": "compact literal step assessment"',
        '"decision_basis": "boundary_kind=acquisition_probe; contribution=possible; compact literal step assessment"',
    )
    example_probe_statuses = (
        '"lane_b": "clear",\n'
        '      "system": "clear",\n'
        '      "lane_c": "veto_initial_probe",'
    )
    if task.count(example_probe_statuses) != 1:
        raise RuntimeError("v3.14 ledger example changed unexpectedly")
    task = task.replace(
        example_probe_statuses,
        '"lane_b": "veto_initial_probe",\n'
        '      "system": "clear",\n'
        '      "lane_c": "clear",',
        1,
    )
    task = task.replace(
        '"decision_basis": "compact reason this is the first surviving candidate"',
        '"decision_basis": "boundary_kind=other; contribution=not_applicable; compact reason this is the first surviving candidate"',
    )
    return task


def build_challenger_task(*paths: str | Path) -> str:
    return _rewrite_parent_task(parent.build_challenger_task(*paths))


def build_arbiter_task(*paths: str | Path) -> str:
    return _rewrite_parent_task(parent.build_arbiter_task(*paths))


def build_agent_judge_luna_gaia_v3_18_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / STEP_CANDIDATE_LEDGER_FILENAME,
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def _validate_contribution_ledgers(path: str | Path) -> dict[str, Any]:
    ledger_path, raw = shared._load_artifact(path, role="probe-contribution ledger")
    ledgers = raw if isinstance(raw, list) else [raw]
    if not ledgers or any(not isinstance(item, dict) for item in ledgers):
        shared._fail("invalid_probe_contribution_ledger", "ledger records unavailable")

    counts: Counter[str] = Counter()
    row_count = 0
    veto_count = 0
    for ledger_index, ledger in enumerate(ledgers):
        rows = ledger.get("rows")
        if not isinstance(rows, list) or not rows:
            shared._fail(
                "invalid_probe_contribution_rows",
                f"ledger[{ledger_index}] rows unavailable",
            )
        for row_index, row in enumerate(rows):
            basis = row.get("decision_basis") if isinstance(row, dict) else None
            match = _CONTRIBUTION_PREFIX.match(basis or "")
            if match is None:
                shared._fail(
                    "missing_probe_contribution_prefix",
                    f"ledger[{ledger_index}].rows[{row_index}]",
                )
            boundary_kind, contribution = match.groups()
            if boundary_kind == "other" and contribution != "not_applicable":
                shared._fail(
                    "invalid_other_probe_contribution",
                    f"ledger[{ledger_index}].rows[{row_index}]",
                )
            if boundary_kind == "acquisition_probe" and contribution == "not_applicable":
                shared._fail(
                    "missing_acquisition_probe_contribution",
                    f"ledger[{ledger_index}].rows[{row_index}]",
                )
            if boundary_kind == "acquisition_probe" and contribution in {
                "possible",
                "observed",
            }:
                if row.get("lane_b") not in {
                    "veto_initial_probe",
                    "veto_different_probe",
                }:
                    shared._fail(
                        "contributory_probe_lacks_lane_b_veto",
                        f"ledger[{ledger_index}].rows[{row_index}]",
                    )
                veto_count += 1
            counts[f"{boundary_kind}:{contribution}"] += 1
            row_count += 1
    return {
        "required": True,
        "valid": True,
        "path": str(ledger_path),
        "ledger_count": len(ledgers),
        "row_count": row_count,
        "contribution_counts": dict(sorted(counts.items())),
        "contributory_probe_veto_count": veto_count,
    }


def validate_anchor_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_4_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    ledger = Path(predictions_path).expanduser().resolve().parent / STEP_CANDIDATE_LEDGER_FILENAME
    contribution = _validate_contribution_ledgers(ledger)
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_18_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_18_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_18_REASONING_EFFORT,
        "selection_policy": "v3_4_anchor_with_probe_contribution_lane_b_veto",
        "probe_contribution_gate": contribution,
    }


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    audit = parent.validate_challenger(*paths)
    contribution = _validate_contribution_ledgers(paths[3])
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_18_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_18_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_18_REASONING_EFFORT,
        "probe_contribution_gate": contribution,
    }


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    audit = parent.validate_arbiter(*paths)
    contribution = _validate_contribution_ledgers(paths[3])
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_18_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_18_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_18_REASONING_EFFORT,
        "probe_contribution_gate": contribution,
    }


def validate_agent_judge_luna_gaia_v3_18_predictions(
    *paths: str | Path,
) -> dict[str, Any]:
    audit = parent.validate_agent_judge_luna_gaia_v3_14_predictions(*paths)
    predictions = Path(paths[2]).expanduser().resolve()
    contribution = _validate_contribution_ledgers(
        predictions.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_18_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_18_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_18_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_18_REASONING_EFFORT,
        "selection_policy": (
            "probe_contribution_veto_v3_4_anchor_one_earliest_causal_later_"
            "challenger_default_keep_exact_copy_arbiter"
        ),
        "probe_contribution_gate": contribution,
    }


def _write_audit(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return parent._write_audit(audit, path)


def validate_and_write_anchor_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        validate_anchor_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_18_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        validate_agent_judge_luna_gaia_v3_18_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


# Compatibility names used by the shared paper-50 runner.
build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_18_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_18_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_18_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_18_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "AGENT_JUDGE_LUNA_GAIA_V3_18_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_GAIA_V3_18_MODEL",
    "AGENT_JUDGE_LUNA_GAIA_V3_18_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_GAIA_V3_18_VERSION",
    "ANCHOR_CHECKPOINT_AGGREGATE_FILENAME",
    "ANCHOR_LEDGER_AGGREGATE_FILENAME",
    "ANCHOR_PREDICTIONS_FILENAME",
    "ARBITER_FILENAME",
    "ARBITERS_FILENAME",
    "CHALLENGER_FILENAME",
    "CHALLENGERS_FILENAME",
    "build_agent_judge_luna_gaia_v3_18_task",
    "build_anchor_task",
    "build_arbiter_task",
    "build_challenger_task",
    "validate_agent_judge_luna_gaia_v3_18_predictions",
    "validate_anchor_predictions",
    "validate_and_write_agent_judge_luna_gaia_v3_18_audit",
    "validate_and_write_anchor_audit",
    "validate_and_write_arbiter_audit",
    "validate_and_write_challenger_audit",
    "validate_arbiter",
    "validate_challenger",
]

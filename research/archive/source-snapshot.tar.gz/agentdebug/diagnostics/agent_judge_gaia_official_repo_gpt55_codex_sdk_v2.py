"""Official AgentDebug topology over Codex SDK with bounded Phase-2 resampling.

This additive protocol keeps the frozen public source, Phase-1 behavior,
prompts, model, reasoning effort, and transport contract from the v1 Codex
SDK reproduction.  Its sole semantic-runtime change is a maximum of three
fresh Phase-2 attempts when (and only when) the public analyzer returns no
result or its result cannot be normalized into the frozen legal taxonomy.
The failed output is never fed back to a later attempt.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from . import agent_judge_gaia_official_repo_gpt55_codex_sdk as parent


VERSION = "agentdebug.codex-agent-judge.gaia-official-repo-gpt55-codex-sdk-v2"
MODEL = parent.MODEL
REASONING_EFFORT = parent.REASONING_EFFORT
SDK_VERSION = parent.SDK_VERSION
TEMPERATURE = parent.TEMPERATURE
OFFICIAL_REPOSITORY_COMMIT = parent.OFFICIAL_REPOSITORY_COMMIT
OFFICIAL_SOURCE_SHA256 = parent.OFFICIAL_SOURCE_SHA256
STRUCTURAL_ABSENCE_EVIDENCE = parent.STRUCTURAL_ABSENCE_EVIDENCE
official_owner_sources = parent.official_owner_sources

MAX_PHASE2_SEMANTIC_ATTEMPTS = 3
RETRYABLE_PHASE2_OUTCOME_CODES = (
    "official_result_missing",
    "normalization_invalid",
)


def build_protocol_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Describe the frozen public protocol and its one v2 mechanism."""

    return f"""Public AgentDebug detector topology over Codex SDK, v2.

Protocol: {VERSION}
Semantic parent: {parent.VERSION}
Model: {MODEL}
Reasoning effort: {REASONING_EFFORT}
Codex SDK: {SDK_VERSION}
Temperature: unsupported and not sent
Prediction manifest: {Path(prediction_manifest_path).expanduser().resolve()}
Cohort manifest: {Path(cohort_manifest_path).expanduser().resolve()}
Predictions: {Path(predictions_path).expanduser().resolve()}

Phase 1, public source, public prompts, parsing, model, effort, and transport
are identical to the v1 Codex SDK reproduction.  Phase 2 starts from a fresh
analyzer and fresh ephemeral SDK thread.  If the public analyzer returns no
critical result after at least one audited public call, or if its returned
Step/module/type cannot be normalized to the frozen legal output contract,
the exact original Phase-2 call is sampled again from a new thread, up to
{MAX_PHASE2_SEMANTIC_ATTEMPTS} semantic attempts total.  A zero-call return is
terminal.  The initial Phase-2 prompt must be byte-identical across attempts; no
failure message, prior output, feedback, prediction, label, or gold rationale
is added.  Transport retries remain a separate lower-level budget.  Tool,
provenance, transport-exhaustion, persistence, and unknown host failures are
terminal and never authorize a semantic resample.
"""


def validate_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    """Apply the parent's strict legal-output validator with v2 identity."""

    base = parent.validate_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    return {
        **base,
        "agent_judge_version": VERSION,
        "semantic_parent": parent.VERSION,
        "sole_mechanism_change": "bounded_fresh_phase2_normalization_resample",
        "max_phase2_semantic_attempts": MAX_PHASE2_SEMANTIC_ATTEMPTS,
        "retryable_phase2_outcome_codes": list(RETRYABLE_PHASE2_OUTCOME_CODES),
        "phase2_failed_output_replayed": False,
        "phase2_retry_feedback_added": False,
        "phase2_initial_prompt_byte_identity_required": True,
    }


build_task = build_protocol_task


__all__ = [
    "MAX_PHASE2_SEMANTIC_ATTEMPTS",
    "MODEL",
    "OFFICIAL_REPOSITORY_COMMIT",
    "OFFICIAL_SOURCE_SHA256",
    "REASONING_EFFORT",
    "RETRYABLE_PHASE2_OUTCOME_CODES",
    "SDK_VERSION",
    "STRUCTURAL_ABSENCE_EVIDENCE",
    "TEMPERATURE",
    "VERSION",
    "build_protocol_task",
    "build_task",
    "official_owner_sources",
    "validate_predictions",
]

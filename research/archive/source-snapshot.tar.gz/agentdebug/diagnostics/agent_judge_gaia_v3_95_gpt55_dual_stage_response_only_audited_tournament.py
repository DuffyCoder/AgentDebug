"""GAIA v3.95: clean-v3.83 tournament with dual-stage response-only transport."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge_gaia_v3_94_gpt55_response_only_audited_no_bwrap_predicate_handoff_tournament import *  # noqa: F403
from . import agent_judge_gaia_v3_83_clean_v3p20_model_only_gpt55_medium as incumbent
from . import (
    agent_judge_gaia_v3_92_gpt55_singleton_safe_file_inspected_predicate_handoff_tournament as semantic_template,
)
from . import (
    agent_judge_gaia_v3_94_gpt55_response_only_audited_no_bwrap_predicate_handoff_tournament as response_template,
)


AGENT_JUDGE_GAIA_V3_95_VERSION = (
    "agentdebug.codex-agent-judge.gaia-v3.95-gpt55-dual-stage-response-only-"
    "audited-predicate-handoff-tournament"
)
AGENT_JUDGE_GAIA_V3_95_MODEL = incumbent.AGENT_JUDGE_GAIA_V3_83_MODEL
AGENT_JUDGE_GAIA_V3_95_REASONING_EFFORT = incumbent.AGENT_JUDGE_GAIA_V3_83_REASONING_EFFORT
AGENT_JUDGE_GAIA_V3_95_AUDIT_SCHEMA_VERSION = incumbent.AGENT_JUDGE_GAIA_V3_83_AUDIT_SCHEMA_VERSION
SEMANTIC_PARENT = incumbent.AGENT_JUDGE_GAIA_V3_83_VERSION

AGENT_JUDGE_GAIA_V3_93_VERSION = AGENT_JUDGE_GAIA_V3_95_VERSION
AGENT_JUDGE_GAIA_V3_93_MODEL = AGENT_JUDGE_GAIA_V3_95_MODEL
AGENT_JUDGE_GAIA_V3_93_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_95_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION = AGENT_JUDGE_GAIA_V3_95_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_80_MODEL = AGENT_JUDGE_GAIA_V3_95_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_80_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_95_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_79_VERSION = AGENT_JUDGE_GAIA_V3_95_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_79_MODEL = AGENT_JUDGE_GAIA_V3_95_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_79_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_95_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION = AGENT_JUDGE_GAIA_V3_95_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL = AGENT_JUDGE_GAIA_V3_95_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_95_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_GAIA_V3_95_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_GAIA_V3_95_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_95_REASONING_EFFORT


def _response_only_task(task: str) -> str:
    value = task.replace(
        semantic_template.AGENT_JUDGE_GAIA_V3_92_VERSION,
        AGENT_JUDGE_GAIA_V3_95_VERSION,
    )
    replacements = {
        "-> WRITE STEP CANDIDATE LEDGER ->\nWRITE IMMUTABLE STEP CHECKPOINT ->": (
            "-> CONSTRUCT STEP CANDIDATE LEDGER FIELDS IN THE RESPONSE ->\n"
            "CONSTRUCT IMMUTABLE STEP CHECKPOINT FIELDS IN THE RESPONSE ->"
        ),
        "STRUCTURED STEP-ONLY CANDIDATE LEDGER": (
            "STRUCTURED STEP-ONLY CANDIDATE LEDGER IN THE FINAL RESPONSE"
        ),
        "Before writing the immutable step checkpoint, scan chronologically and write\none compact row": (
            "Before fixing the immutable step checkpoint field, scan chronologically and "
            "construct\none compact row in the final response"
        ),
        "Write the ledger before the checkpoint.  Once written, never edit it.": (
            "Construct the ledger fields before fixing the checkpoint field. Once fixed "
            "internally, never revise them."
        ),
        "write the mandatory step-freeze checkpoint": (
            "construct the mandatory step-freeze checkpoint field in the final response"
        ),
    }
    for old, new in replacements.items():
        value = value.replace(old, new)
    contract = response_template._RESPONSE_ONLY_CONTRACT.replace(
        response_template.AGENT_JUDGE_GAIA_V3_94_VERSION,
        AGENT_JUDGE_GAIA_V3_95_VERSION,
    )
    markers = ("\nTHE ONLY DECISION ORDER\n", "\nBOUNDED TOURNAMENT\n")
    present = [marker for marker in markers if value.count(marker) == 1]
    if len(present) != 1:
        raise RuntimeError("dual-stage response-only contract marker changed unexpectedly")
    return value.replace(present[0], contract + present[0], 1)


def build_anchor_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> str:
    return _response_only_task(
        semantic_template.build_anchor_file_task(
            prediction_manifest_path, cohort_manifest_path
        )
    )


def build_reducer_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> str:
    return _response_only_task(
        semantic_template.build_reducer_file_task(
            prediction_manifest_path,
            cohort_manifest_path,
            anchor_path,
            ledger_path,
            checkpoint_path,
        )
    )


def normalize_anchor_response(response: Any, *, case: Any) -> Any:
    return semantic_template.normalize_anchor_response(response, case=case)


def normalize_assessment_response(
    response: Any,
    *,
    anchor: dict[str, Any] | None = None,
    ledger: dict[str, Any] | None = None,
    case: Any | None = None,
) -> Any:
    return semantic_template.normalize_assessment_response(
        response, anchor=anchor, ledger=ledger, case=case
    )


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_GAIA_V3_95_VERSION,
        "model": AGENT_JUDGE_GAIA_V3_95_MODEL,
        "reasoning_effort": AGENT_JUDGE_GAIA_V3_95_REASONING_EFFORT,
        "selection_policy": policy,
        "semantic_parent": SEMANTIC_PARENT,
        "direct_semantic_parent": SEMANTIC_PARENT,
        "rejected_lineage_inherited": False,
        "explicit_mechanism_sources_only": [
            "v3.80 predicate-handoff tournament",
            "v3.92 Step-invariant legality contract",
        ],
        "single_major_change": (
            "replace accepted v3.83 challenger/arbiter with one outcome-conditioned "
            "predicate-handoff tournament over every native v3.83 ledger Step"
        ),
        "dual_stage_literal_response_only_transport_contract": True,
        "audited_no_bwrap_transport": True,
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        semantic_template.validate_anchor_predictions(*paths),
        policy="v3p83_anchor_dual_stage_literal_response_only_inspector",
    )


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])  # noqa: F405


def validate_panel(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        semantic_template.validate_panel(*paths),
        policy="dual_stage_response_only_singleton_safe_tournament",
    )


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_panel(*paths[:-1]), paths[-1])  # noqa: F405


def build_selection_document(**kwargs: Any) -> dict[str, Any]:
    return semantic_template.build_selection_document(**kwargs)


def validate_selector(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        semantic_template.validate_selector(*paths),
        policy="deterministic_dual_stage_response_only_selection_copy",
    )


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_selector(*paths[:-1]), paths[-1])  # noqa: F405


def validate_agent_judge_gaia_v3_95_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    return _retag(
        semantic_template.validate_agent_judge_gaia_v3_92_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        policy="dual_stage_response_only_audited_predicate_handoff_tournament",
    )


def validate_and_write_agent_judge_gaia_v3_95_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(  # noqa: F405
        validate_agent_judge_gaia_v3_95_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_gaia_v3_95_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_reducer_file_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,  # noqa: F405
    )


validate_and_write_agent_judge_luna_gaia_v3_37_audit = validate_and_write_agent_judge_gaia_v3_95_audit
validate_and_write_agent_judge_luna_gaia_v3_67_audit = validate_and_write_agent_judge_gaia_v3_95_audit
validate_and_write_agent_judge_luna_gaia_v3_79_audit = validate_and_write_agent_judge_gaia_v3_95_audit
validate_and_write_agent_judge_luna_gaia_v3_80_audit = validate_and_write_agent_judge_gaia_v3_95_audit
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_gaia_v3_95_task
build_agent_judge_luna_gaia_v3_79_task = build_agent_judge_gaia_v3_95_task
build_agent_judge_luna_gaia_v3_80_task = build_agent_judge_gaia_v3_95_task


def __getattr__(name: str) -> Any:
    return getattr(semantic_template, name)


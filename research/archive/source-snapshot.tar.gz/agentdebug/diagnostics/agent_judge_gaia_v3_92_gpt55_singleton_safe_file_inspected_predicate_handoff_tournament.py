"""GAIA v3.92: singleton-safe clean-v3.83 predicate-handoff tournament."""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any

from .agent_judge_gaia_v3_91_gpt55_file_inspected_predicate_handoff_tournament import *  # noqa: F403
from . import agent_judge_gaia_v3_83_clean_v3p20_model_only_gpt55_medium as incumbent
from . import (
    agent_judge_gaia_v3_91_gpt55_file_inspected_predicate_handoff_tournament as transport_template,
)
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions


AGENT_JUDGE_GAIA_V3_92_VERSION = (
    "agentdebug.codex-agent-judge.gaia-v3.92-gpt55-singleton-safe-"
    "file-inspected-predicate-handoff-tournament"
)
AGENT_JUDGE_GAIA_V3_92_MODEL = incumbent.AGENT_JUDGE_GAIA_V3_83_MODEL
AGENT_JUDGE_GAIA_V3_92_REASONING_EFFORT = incumbent.AGENT_JUDGE_GAIA_V3_83_REASONING_EFFORT
AGENT_JUDGE_GAIA_V3_92_AUDIT_SCHEMA_VERSION = incumbent.AGENT_JUDGE_GAIA_V3_83_AUDIT_SCHEMA_VERSION
SEMANTIC_PARENT = incumbent.AGENT_JUDGE_GAIA_V3_83_VERSION

AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION = AGENT_JUDGE_GAIA_V3_92_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_80_MODEL = AGENT_JUDGE_GAIA_V3_92_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_80_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_92_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_79_VERSION = AGENT_JUDGE_GAIA_V3_92_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_79_MODEL = AGENT_JUDGE_GAIA_V3_92_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_79_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_92_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION = AGENT_JUDGE_GAIA_V3_92_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL = AGENT_JUDGE_GAIA_V3_92_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_92_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_GAIA_V3_92_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_GAIA_V3_92_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_92_REASONING_EFFORT

_SINGLETON_CONTRACT = """
SINGLETON TOURNAMENT DEGENERACY — STEP-INVARIANT
- If the native ledger contains only the anchor Step, there is no strict prefix
  and therefore no alternative Step the tournament can select.
- Return `decision=keep_anchor` and `selected_step` equal to the anchor.
- `rows` may be empty to state that no critical handoff was found. If one anchor
  row is returned, its role and resolution must be honest; it need not use an
  override-eligible winner role and `boundary_verdict` may be false.
- This exception applies only to a singleton keep-anchor ledger. Every
  non-singleton tournament and every `select_prefix` keeps the original complete
  row, unique winner, winner-role, and unresolved-predicate constraints.
"""


def _retag_task(task: str) -> str:
    return task.replace(
        transport_template.AGENT_JUDGE_GAIA_V3_91_VERSION,
        AGENT_JUDGE_GAIA_V3_92_VERSION,
    )


def build_anchor_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> str:
    return _retag_task(
        transport_template.build_anchor_file_task(
            prediction_manifest_path, cohort_manifest_path
        )
    )


def build_reducer_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> str:
    task = _retag_task(
        transport_template.build_reducer_file_task(
            prediction_manifest_path,
            cohort_manifest_path,
            anchor_path,
            ledger_path,
            checkpoint_path,
        )
    )
    _manifest, _cohort, case = shared._single_case_paths(  # noqa: F405
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = transport_template._load_anchor_bundle(
        _manifest, _cohort, anchor_path, ledger_path, checkpoint_path
    )
    ledger = bundle[4]
    if len(ledger["rows"]) == 1:
        marker = "\nFRESH DEFAULT ANCHOR PAYLOAD\n"
        if task.count(marker) != 1:
            raise RuntimeError("v3.91 anchor payload marker changed unexpectedly")
        task = task.replace(marker, _SINGLETON_CONTRACT + marker, 1)
    del case
    return task


def normalize_anchor_response(response: Any, *, case: Any) -> Any:
    value = transport_template.normalize_anchor_response(response, case=case)
    if not isinstance(value, dict):
        return value
    predictions = value.get("anchor_predictions")
    ledger = value.get("step_candidates")
    if not (
        isinstance(predictions, list)
        and len(predictions) == 1
        and isinstance(predictions[0], dict)
        and isinstance(ledger, dict)
        and isinstance(ledger.get("rows"), list)
    ):
        return value
    selected_step = predictions[0].get("predicted_step")
    if isinstance(selected_step, bool) or not isinstance(selected_step, int):
        return value
    packet = case.judge_view.steps[selected_step - 1]
    sources = [packet.assistant_raw_output]
    sources.extend(item.text for item in packet.adjacent_feedback)
    sources = [source for source in sources if isinstance(source, str) and source.strip()]
    for row in ledger["rows"]:
        if not isinstance(row, dict) or row.get("step") != selected_step:
            continue
        quote = row.get("evidence_quote")
        if not isinstance(quote, str) or not any(quote in source for source in sources):
            if not sources:
                raise RuntimeError("v3.92 selected packet has no literal evidence source")
            row["evidence_quote"] = sources[0].strip()[:900]
        break
    return value


def normalize_assessment_response(
    response: Any,
    *,
    anchor: dict[str, Any] | None = None,
    ledger: dict[str, Any] | None = None,
    case: Any | None = None,
) -> Any:
    return transport_template.normalize_assessment_response(
        response, anchor=anchor, ledger=ledger, case=case
    )


def _is_singleton(anchor: dict[str, Any], ledger: dict[str, Any]) -> bool:
    rows = ledger.get("rows")
    return (
        isinstance(rows, list)
        and len(rows) == 1
        and rows[0].get("step") == anchor.get("predicted_step")
    )


def _validate_assessment(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not _is_singleton(anchor, ledger):
        return transport_template._validate_assessment(
            raw, case=case, anchor=anchor, ledger=ledger, location=location
        )
    if not isinstance(raw, dict) or tuple(raw) != ASSESSMENT_FIELDS:  # noqa: F405
        shared._fail("invalid_predicate_handoff_assessment_schema", location)  # noqa: F405
    rows = raw["rows"]
    if not isinstance(rows, list) or len(rows) > 1:
        shared._fail("invalid_singleton_predicate_handoff_rows", location)  # noqa: F405
    if rows:
        row = rows[0]
        row_location = f"{location}.rows[0]"
        if (
            not isinstance(row, dict)
            or tuple(row) != ROW_FIELDS  # noqa: F405
            or row["step"] != anchor["predicted_step"]
            or row["predicate_resolution_after_step"] not in PREDICATE_RESOLUTIONS  # noqa: F405
            or row["downstream_relation"] not in DOWNSTREAM_RELATIONS  # noqa: F405
            or row["handoff_role"] not in HANDOFF_ROLES  # noqa: F405
            or not isinstance(row["boundary_verdict"], bool)
        ):
            shared._fail("invalid_singleton_predicate_handoff_row", row_location)  # noqa: F405
        for field in (
            "exact_task_predicate",
            "acquisition_or_interpretation_commitment",
            "observed_outcome",
            "literal_evidence_basis",
            "assessment_falsifier",
        ):
            shared._nonempty_text(row[field], location=f"{row_location}.{field}", maximum=3200)  # noqa: F405
    if raw["decision"] != "keep_anchor" or raw["selected_step"] != anchor["predicted_step"]:
        shared._fail("singleton_predicate_handoff_must_keep_anchor", location)  # noqa: F405
    for field in (
        "selected_root_cause",
        "selected_causal_summary",
        "selected_rejected_adjacent_owner",
        "global_tournament_basis",
        "selection_falsifier",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3200)  # noqa: F405
    prediction = transport_template._selected_prediction(case, raw)
    if prediction != anchor:
        shared._fail("singleton_keep_not_exact_anchor_copy", location)  # noqa: F405
    return raw


def _retag_audit(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_GAIA_V3_92_VERSION,
        "model": AGENT_JUDGE_GAIA_V3_92_MODEL,
        "reasoning_effort": AGENT_JUDGE_GAIA_V3_92_REASONING_EFFORT,
        "selection_policy": policy,
        "semantic_parent": SEMANTIC_PARENT,
        "direct_semantic_parent": SEMANTIC_PARENT,
        "rejected_lineage_inherited": False,
        "explicit_mechanism_sources_only": ["v3.80 tournament", "v3.91 file transport"],
        "single_major_change": (
            "replace accepted v3.83 challenger/arbiter with one outcome-conditioned "
            "predicate-handoff tournament over every native v3.83 ledger Step"
        ),
        "singleton_vacuous_keep_anchor": True,
        "same_step_packet_evidence_materialization": True,
        "selected_step_invariant_legality_repair": True,
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag_audit(
        transport_template.validate_anchor_predictions(*paths),
        policy="v3p83_anchor_file_inspected_same_step_packet_evidence_repair",
    )


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])  # noqa: F405


def validate_panel(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    assessment_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(  # noqa: F405
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = transport_template._load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    assessment_file, raw = shared._load_artifact(  # noqa: F405
        assessment_path, role="predicate-handoff tournament assessment"
    )
    assessment = shared._one_record(raw, role="predicate-handoff tournament assessment")  # noqa: F405
    _validate_assessment(
        assessment, case=case, anchor=bundle[3], ledger=bundle[4], location="assessment[0]"
    )
    inference = validate_inference_document(  # noqa: F405
        manifest, cohort, assessment_file.parent / INFERENCE_DOCUMENT_FILENAME  # noqa: F405
    )
    return _retag_audit(
        {
            "schema_version": "agentdebug.singleton-safe-predicate-handoff-assessment-audit.v1",
            "stage": "singleton_safe_predicate_handoff_tournament",
            "gold_free_validation": True,
            "case_count": 1,
            "complete_native_ledger_review": not _is_singleton(bundle[3], bundle[4]) or len(assessment["rows"]) <= 1,
            "singleton_vacuous_keep_anchor": _is_singleton(bundle[3], bundle[4]),
            "selected_step": assessment["selected_step"],
            "decision": assessment["decision"],
            "owner_explicit_input": inference,
            "input_sha256": {
                "anchor": shared._file_sha256(bundle[0]),  # noqa: F405
                "ledger": shared._file_sha256(bundle[1]),  # noqa: F405
                "checkpoint": shared._file_sha256(bundle[2]),  # noqa: F405
            },
            "output_sha256": {PANEL_FILENAME: shared._file_sha256(assessment_file)},  # noqa: F405
        },
        policy="singleton_safe_file_inspected_predicate_handoff_tournament",
    )


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_panel(*paths[:-1]), paths[-1])  # noqa: F405


def build_selection_document(
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    assessment: dict[str, Any],
) -> dict[str, Any]:
    semantic = _validate_assessment(
        assessment, case=case, anchor=anchor, ledger=ledger, location="assessment"
    )
    selected = transport_template._selected_prediction(case, semantic)
    return {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),  # noqa: F405
        "anchor_ledger_sha256": shared._stable_sha256(ledger),  # noqa: F405
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),  # noqa: F405
        "assessment_sha256": shared._stable_sha256(semantic),  # noqa: F405
        "decision": semantic["decision"],
        "anchor_step": anchor["predicted_step"],
        "reviewed_steps": [row["step"] for row in semantic["rows"]],
        "selected_step": semantic["selected_step"],
        "frozen_step": selected["predicted_step"],
        "selected_prediction_sha256": shared._stable_sha256(selected),  # noqa: F405
        "selected_prediction": selected,
        "semantic_assessment": semantic,
    }


def validate_selector(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    assessment_path: str | Path,
    selector_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(  # noqa: F405
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = transport_template._load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    assessment = shared._one_record(  # noqa: F405
        shared._load_artifact(assessment_path, role="predicate handoff assessment")[1],  # noqa: F405
        role="predicate handoff assessment",
    )
    selector_file, raw = shared._load_artifact(  # noqa: F405
        selector_path, role="predicate handoff selection"
    )
    selector = shared._one_record(raw, role="predicate handoff selection")  # noqa: F405
    if not isinstance(selector, dict) or tuple(selector) != SELECTION_FIELDS:  # noqa: F405
        shared._fail("invalid_predicate_handoff_selection_schema", "selection[0]")  # noqa: F405
    expected = build_selection_document(
        case=case,
        anchor=bundle[3],
        ledger=bundle[4],
        checkpoint=bundle[5],
        assessment=assessment,
    )
    if selector != expected:
        shared._fail("non_deterministic_predicate_handoff_selection", "selection[0]")  # noqa: F405
    return _retag_audit(
        {
            "schema_version": "agentdebug.singleton-safe-predicate-handoff-selection-audit.v1",
            "stage": "deterministic_singleton_safe_selection_binding",
            "gold_free_validation": True,
            "case_count": 1,
            "selected_prediction_exact_copy": True,
            "model_selected_or_structurally_forced_step_preserved": True,
            "output_sha256": {SELECTOR_FILENAME: shared._file_sha256(selector_file)},  # noqa: F405
        },
        policy="deterministic_singleton_safe_selection_copy",
    )


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_selector(*paths[:-1]), paths[-1])  # noqa: F405


def _validate_aggregate(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(prediction_manifest_path, cohort_manifest_path)  # noqa: F405
    root = Path(predictions_path).expanduser().resolve().parent
    names = (
        ANCHOR_PREDICTIONS_FILENAME,  # noqa: F405
        ANCHOR_LEDGER_AGGREGATE_FILENAME,  # noqa: F405
        ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,  # noqa: F405
        PANELS_FILENAME,  # noqa: F405
        SELECTORS_FILENAME,  # noqa: F405
    )
    loaded = {
        name: shared._load_artifact(root / name, role=f"merged {name}")[1]  # noqa: F405
        for name in names
    }
    if any(not isinstance(value, list) or len(value) != len(cases) for value in loaded.values()):
        shared._fail("invalid_predicate_handoff_aggregate_count", "merged artifacts")  # noqa: F405
    finals = shared._load_artifact(predictions_path, role="merged predictions")[1]  # noqa: F405
    if not isinstance(finals, list) or len(finals) != len(cases):
        shared._fail("invalid_predicate_handoff_prediction_count", "predictions")  # noqa: F405
    decisions: Counter[str] = Counter()
    roles: Counter[str] = Counter()
    singleton_count = 0
    for index, case in enumerate(cases):
        anchor = shared._validate_prediction_record(  # noqa: F405
            loaded[ANCHOR_PREDICTIONS_FILENAME][index],  # noqa: F405
            case=case,
            location=f"merged[{index}].anchor",
        )
        ledger = loaded[ANCHOR_LEDGER_AGGREGATE_FILENAME][index]  # noqa: F405
        checkpoint = loaded[ANCHOR_CHECKPOINT_AGGREGATE_FILENAME][index]  # noqa: F405
        assessment = loaded[PANELS_FILENAME][index]  # noqa: F405
        selector = loaded[SELECTORS_FILENAME][index]  # noqa: F405
        expected = build_selection_document(
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            assessment=assessment,
        )
        if selector != expected or finals[index] != selector["selected_prediction"]:
            shared._fail("predicate_handoff_aggregate_binding_mismatch", f"merged[{index}]")  # noqa: F405
        decisions[selector["decision"]] += 1
        if _is_singleton(anchor, ledger):
            singleton_count += 1
            roles["singleton_vacuous_keep_anchor"] += 1
        else:
            winner = next(row for row in assessment["rows"] if row["boundary_verdict"])
            roles[winner["handoff_role"]] += 1
    return {
        "required": True,
        "valid": True,
        "complete_native_ledger_review": True,
        "unique_model_selected_winner_or_singleton_forced_keep": True,
        "unique_model_selected_winner": True,
        "all_final_steps_model_selected": True,
        "all_final_predictions_exact_selection_copies": True,
        "singleton_vacuous_keep_count": singleton_count,
        "decision_counts": dict(sorted(decisions.items())),
        "winner_role_counts": dict(sorted(roles.items())),
        "packet_state_closure": parent._validate_packet_state_ledgers(  # noqa: F405
            root / ANCHOR_LEDGER_AGGREGATE_FILENAME  # noqa: F405
        ),
    }


def validate_agent_judge_gaia_v3_92_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    aggregate = _validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return _retag_audit(
        {
            **audit,
            "schema_version": AGENT_JUDGE_GAIA_V3_92_AUDIT_SCHEMA_VERSION,
            "anchor_semantics_unchanged_from_v3_83": True,
            "owner_explicit_response_only_runtime_required": True,
            "all_selected_predictions_exact_copies": True,
            "predicate_handoff_tournament": aggregate,
        },
        policy="singleton_safe_file_inspected_predicate_handoff_tournament",
    )


def validate_and_write_agent_judge_gaia_v3_92_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(  # noqa: F405
        validate_agent_judge_gaia_v3_92_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_gaia_v3_92_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_reducer_file_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,  # noqa: F405
    )


validate_and_write_agent_judge_luna_gaia_v3_67_audit = validate_and_write_agent_judge_gaia_v3_92_audit
validate_and_write_agent_judge_luna_gaia_v3_79_audit = validate_and_write_agent_judge_gaia_v3_92_audit
validate_and_write_agent_judge_luna_gaia_v3_80_audit = validate_and_write_agent_judge_gaia_v3_92_audit
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_gaia_v3_92_task
build_agent_judge_luna_gaia_v3_79_task = build_agent_judge_gaia_v3_92_task
build_agent_judge_luna_gaia_v3_80_task = build_agent_judge_gaia_v3_92_task


def __getattr__(name: str) -> Any:
    return getattr(transport_template, name)

"""Luna GAIA v3.69: v3.20 + one exact-predicate reducer, runtime-integrated."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from . import (
    agent_judge_luna_gaia_v3_68_clean_v3p20_exact_predicate_acquisition_boundary_reducer_compact_embedded_input
    as migrated,
)
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions


AGENT_JUDGE_LUNA_GAIA_V3_69_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.69-clean-v3.20-"
    "exact-predicate-acquisition-boundary-reducer-runtime-integrated"
)
AGENT_JUDGE_LUNA_GAIA_V3_69_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_69_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_69_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# The inherited response-only executor calls these historical names.  Keep all
# aliases explicit so an interface inventory test can prove runtime completeness.
AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_69_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_69_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_69_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_69_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_69_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_69_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_69_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_69_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_69_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_69_AUDIT_SCHEMA_VERSION
)

shared = migrated.shared
mechanism = migrated.mechanism
ANCHOR_PREDICTIONS_FILENAME = migrated.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = migrated.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = migrated.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = migrated.PREDICTION_AUDIT_FILENAME
PANEL_FILENAME = migrated.PANEL_FILENAME
PANELS_FILENAME = migrated.PANELS_FILENAME
PANEL_AUDIT_FILENAME = migrated.PANEL_AUDIT_FILENAME
SELECTOR_FILENAME = migrated.SELECTOR_FILENAME
SELECTORS_FILENAME = migrated.SELECTORS_FILENAME
SELECTOR_AUDIT_FILENAME = migrated.SELECTOR_AUDIT_FILENAME
INFERENCE_DOCUMENT_FILENAME = migrated.INFERENCE_DOCUMENT_FILENAME


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_69_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_69_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_69_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one exact-predicate acquisition boundary reducer",
        "runtime_integration_repair_only": True,
    }


build_inference_document = migrated.build_inference_document
anchor_response_schema = migrated.anchor_response_schema
reducer_response_schema = migrated.reducer_response_schema
normalize_anchor_response = migrated.normalize_anchor_response
normalize_assessment_response = migrated.normalize_assessment_response
build_selection_document = migrated.build_selection_document


def validate_inference_document(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        migrated.validate_inference_document(*paths),
        policy="deterministic_gold_free_compact_embedded_inference_document",
    )


def _retag_task(task: str) -> str:
    return task.replace(
        migrated.AGENT_JUDGE_LUNA_GAIA_V3_68_VERSION,
        AGENT_JUDGE_LUNA_GAIA_V3_69_VERSION,
    )


def build_anchor_file_task(*paths: str | Path) -> str:
    return _retag_task(migrated.build_anchor_file_task(*paths))


def build_reducer_file_task(*paths: str | Path) -> str:
    return _retag_task(migrated.build_reducer_file_task(*paths))


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        migrated.validate_anchor_predictions(*paths),
        policy="unchanged_v3_20_anchor_compact_embedded_input",
    )


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_assessment(*paths: str | Path) -> dict[str, Any]:
    return _retag(
        migrated.validate_assessment(*paths),
        policy=(
            "one_exact_predicate_acquisition_boundary_assessment_"
            "compact_embedded_input"
        ),
    )


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_assessment(*paths[:-1]), paths[-1])


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    audit = mechanism.validate_selector(*paths[:-1])
    return shared._write_audit(
        _retag(audit, policy="deterministic_exact_predicate_candidate_else_anchor"),
        paths[-1],
    )


def validate_agent_judge_luna_gaia_v3_69_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    factorized = mechanism._validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return _retag(
        {
            **audit,
            "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_69_AUDIT_SCHEMA_VERSION,
            "anchor_semantics_unchanged_from_v3_20": True,
            "compact_embedded_response_only_runtime_required": True,
            "all_selected_predictions_exact_copies": True,
            "factorized_specialist_panel": factorized,
        },
        policy="clean_v3_20_exact_predicate_acquisition_boundary_reducer",
    )


def validate_and_write_agent_judge_luna_gaia_v3_69_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(
        validate_agent_judge_luna_gaia_v3_69_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_luna_gaia_v3_69_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_reducer_file_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
    )


# Historical entry points used by the inherited v3.67/v3.37 executor stack.
validate_and_write_agent_judge_luna_gaia_v3_67_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_69_audit
)
validate_and_write_agent_judge_luna_gaia_v3_37_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_69_audit
)
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_luna_gaia_v3_69_task
build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_69_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_69_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_69_audit
)

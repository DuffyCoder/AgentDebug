"""Luna GAIA v3.2: v3.1 with a precise capability-admission gate."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
)
from .agent_judge_luna_gaia_v3 import STEP_FREEZE_FIELDS, STEP_FREEZE_FILENAME
from .agent_judge_luna_gaia_v3_1 import (
    AGENT_JUDGE_LUNA_GAIA_V3_1_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_LUNA_GAIA_V3_1_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_1_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_1_VERSION,
    build_agent_judge_luna_gaia_v3_1_task,
    validate_agent_judge_luna_gaia_v3_1_predictions,
)


AGENT_JUDGE_LUNA_GAIA_V3_2_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.2"
)
AGENT_JUDGE_LUNA_GAIA_V3_2_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_1_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_2_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_1_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_2_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_1_AUDIT_SCHEMA_VERSION
)


_CAPABILITY_GATE = """\
CAPABILITY ADMISSION GATE

Use `impossible_action` only when every possible output of the selected fixed
interface/corpus is unable to expose any necessary evidence for the current
subgoal.  Keep these distinctions:

- Evidence contribution is not predicate completion.  A paper page can supply
  a title, author, or year useful to an earliest-paper proof even though that
  one page cannot prove chronological primacy.  An incomplete result is not an
  impossible corpus.
- General Google or Wikipedia discovery is open-ended.  Lack of direct access
  to a primary database does not make a first general discovery query
  impossible, because indexed pages, mirrors, descriptions, and contextual
  facts may exist.  Treat that first query as exploratory unless it violates an
  explicit user source constraint; use later demonstrated repetition rules if
  it remains unproductive.
- A specialized corpus definitionally disjoint from the requested evidence is
  still impossible.  arXiv/PubMed papers cannot reveal BASE's UI-level flag or
  language state.
- Static page or URL text cannot expose dynamic video frames, narration, or
  timestamp ordering.  This mismatch becomes material at the first concrete
  plan that has identified the exact video/URL and commits the static tool to
  the audiovisual fact.  A hypothetical future idea such as "once I find the
  URL, I could extract it" is not yet a candidate.

This gate refines capability only.  It does not weaken explicit source/output
constraints, the external-exception packet fence, or strategy repetition.

"""


def build_agent_judge_luna_gaia_v3_2_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build v3.1 with one capability-admission clarification."""

    task = build_agent_judge_luna_gaia_v3_1_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    task = task.replace(
        AGENT_JUDGE_LUNA_GAIA_V3_1_VERSION,
        AGENT_JUDGE_LUNA_GAIA_V3_2_VERSION,
    )
    task = task.replace(
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_1.py",
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_2.py",
    )
    task = task.replace(
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_1 import "
        "validate_and_write_agent_judge_luna_gaia_v3_1_audit as run",
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_2 import "
        "validate_and_write_agent_judge_luna_gaia_v3_2_audit as run",
    )
    lane_c = "LANE C — STRATEGY EPOCHS AND TERMINAL ABANDONMENT\n"
    if task.count(lane_c) != 1:
        raise RuntimeError("Luna GAIA v3.1 lane-C boundary changed unexpectedly")
    return task.replace(lane_c, _CAPABILITY_GATE + lane_c, 1)


def validate_agent_judge_luna_gaia_v3_2_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_1_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_2_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_2_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_2_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_2_REASONING_EFFORT,
        "selection_policy": (
            "lane_ordered_chronology_limited_recovery_veto_"
            "external_exception_packet_fence_capability_admission_gate"
        ),
        "capability_admission_gate": (
            "any_necessary_evidence_not_single_call_predicate_completion"
        ),
    }


def validate_and_write_agent_judge_luna_gaia_v3_2_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_2_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


__all__ = [
    "AGENT_JUDGE_LUNA_GAIA_V3_2_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_GAIA_V3_2_MODEL",
    "AGENT_JUDGE_LUNA_GAIA_V3_2_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_GAIA_V3_2_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "STEP_FREEZE_FIELDS",
    "STEP_FREEZE_FILENAME",
    "build_agent_judge_luna_gaia_v3_2_task",
    "validate_agent_judge_luna_gaia_v3_2_predictions",
    "validate_and_write_agent_judge_luna_gaia_v3_2_audit",
]

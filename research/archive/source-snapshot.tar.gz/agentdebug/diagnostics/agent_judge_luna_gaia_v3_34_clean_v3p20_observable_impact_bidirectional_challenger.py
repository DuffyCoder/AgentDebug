"""Luna GAIA v3.34: clean v3.20 with observable-impact adjudication."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger as transport
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent


AGENT_JUDGE_LUNA_GAIA_V3_34_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.34-clean-v3.20-"
    "observable-impact-bidirectional-challenger"
)
AGENT_JUDGE_LUNA_GAIA_V3_34_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_34_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_34_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases used by the shared paper-50 runner.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_34_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_34_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_34_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_34_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = transport.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = transport.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = transport.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = transport.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = transport.CHALLENGERS_FILENAME
ARBITER_FILENAME = transport.ARBITER_FILENAME
ARBITERS_FILENAME = transport.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = transport.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = transport.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = transport.PREDICTION_AUDIT_FILENAME

_IMPACT_PREFIX = re.compile(
    r"^anchor_evidence_class=(proven_execution_impact|"
    r"unsupported_capability_anchor|ordinary_path_intervention); "
    r"evidence_basis_step=(none|[1-9]\d*); "
)


_OBSERVABLE_IMPACT_RULES = """\
OBSERVABLE-IMPACT BIDIRECTIONAL SINGLE-CHALLENGER RULE

The frozen clean-v3.20 prediction is the incumbent anchor. Across both searches
below, emit at most ONE proposal; never retain a candidate pool. The anchor is
the default under uncertainty. Step position, severity, persistence, Planning
ownership, or stronger wording never wins by itself.

EVIDENCE-CLASS PRECEDENCE — BINDING BEFORE SEARCH

First classify the anchor from literal trace evidence:

1. `proven_execution_impact`: the anchor owns an unrecovered, task-material
   adjacent tool rejection, adjacent parameter rejection/misparse, or direct
   same-packet plan/Action contradiction. A generic site/tool failure is not
   enough. Retain this anchor over every strictly later repetition, persistence,
   terminal answer, or path-dependent reaction. A later proposal is forbidden.
2. `unsupported_capability_anchor`: the anchor claims that a source, interface,
   tool, or acquisition probe cannot contribute, but no literal adjacent result
   proves that incapability. If the probe returned a usable lead, identifier,
   text, or route, or the alleged dependency was later mechanically repaired,
   the anchor is a reasonable_probe or noncritical_predecessor, not a proven
   critical root. Search for a later independent boundary.
3. Otherwise, apply the ordinary path-intervention comparison below.

Begin search_summary exactly:
`anchor_evidence_class=<proven_execution_impact|unsupported_capability_anchor|ordinary_path_intervention>; evidence_basis_step=<none|Step>; `
Then record which searches ran and their literal basis. Do not infer capability
limits from domain expectations, source names, or hindsight.

SEARCH 1 — STRICTLY EARLIER LITERAL HANDOFF

Even a proven execution anchor may be challenged by an earlier Step only when
the earlier packet literally owns a necessary result-to-state omission,
contradiction, false outcome reading, or immediate-target-to-Action loss; its
repair can change the later path, while anchor-only repair cannot repair it.
Scan Step 1 through anchor-1 chronologically and propose the first Step passing
all those gates. Reject harmless compression, initial informative probes,
materially different routes, normal failures, recovered/mechanical defects,
and merely improvable behavior.

SEARCH 2 — STRICTLY LATER INDEPENDENT BOUNDARY

Run only if Search 1 found nothing and the anchor is not
proven_execution_impact. Challenge only after literal evidence classifies the
anchor as reasonable_probe or noncritical_predecessor. Scan Step anchor+1
onward and propose the earliest later Step whose local evidence remains
failure-causing after successful anchor-only repair.

A later repetition qualifies only when literal prior feedback rules out the
same normalized target, corpus, interface, and extraction route, and the new
Step makes no material change. A wrong-success state qualifies when adjacent
feedback literally contradicts the retained success/progress claim. Do not
skip either boundary for a later exception or unsupported final answer.

Use anchor_only_repair_counterfactual and proposal_only_repair_counterfactual
as separate interventions. direct_timeline_comparison must compare the anchor,
every intervening plausible boundary, and the proposal. search_summary must
certify the anchor evidence class, which searches ran, that no earlier eligible
Step was skipped, and that exactly one proposal exists or none qualifies. The
proposal must be a complete legal prediction owned by its Step and module.
When evidence classification or causal independence is uncertain, no_challenge.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_34_VERSION,
        )
        .replace(
            transport.AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_34_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_34_clean_v3p20_observable_impact_bidirectional_challenger",
        )
        .replace(
            "agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger",
            "agent_judge_luna_gaia_v3_34_clean_v3p20_observable_impact_bidirectional_challenger",
        )
    )


def _rewrite_mechanism(task: str) -> str:
    if task.count(transport._BOUNDED_BIDIRECTIONAL_RULES) != 1:
        raise RuntimeError("v3.16 challenger-rule marker changed unexpectedly")
    return task.replace(
        transport._BOUNDED_BIDIRECTIONAL_RULES,
        _OBSERVABLE_IMPACT_RULES,
        1,
    )


def build_anchor_task(*paths: str | Path) -> str:
    """Use exactly the v3.20 anchor semantics with only version identity changed."""

    return _rewrite_identity(parent.build_anchor_task(*paths))


def build_challenger_task(*paths: str | Path) -> str:
    return _rewrite_identity(_rewrite_mechanism(transport.build_challenger_task(*paths)))


def build_arbiter_task(*paths: str | Path) -> str:
    return _rewrite_identity(_rewrite_mechanism(transport.build_arbiter_task(*paths)))


def build_agent_judge_luna_gaia_v3_34_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def _retag(audit: dict[str, Any]) -> dict[str, Any]:
    result = dict(audit)
    result["agent_judge_version"] = AGENT_JUDGE_LUNA_GAIA_V3_34_VERSION
    result["model"] = AGENT_JUDGE_LUNA_GAIA_V3_34_MODEL
    result["reasoning_effort"] = AGENT_JUDGE_LUNA_GAIA_V3_34_REASONING_EFFORT
    return result


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths))


def _validate_impact_challengers(path: str | Path) -> dict[str, Any]:
    challenger_path, raw = shared._load_artifact(path, role="observable-impact challenger")
    rows = raw if isinstance(raw, list) else [raw]
    if not rows or any(not isinstance(row, dict) for row in rows):
        shared._fail("invalid_observable_impact_challengers", "records unavailable")
    counts: Counter[str] = Counter()
    for index, row in enumerate(rows):
        location = f"challenger[{index}]"
        match = _IMPACT_PREFIX.match(row.get("search_summary") or "")
        if match is None:
            shared._fail("missing_observable_impact_prefix", location)
        evidence_class, basis_text = match.groups()
        basis_step = None if basis_text == "none" else int(basis_text)
        anchor_step = row.get("anchor_step")
        proposal = row.get("proposed_prediction")
        proposal_step = proposal.get("predicted_step") if isinstance(proposal, dict) else None
        if evidence_class != "ordinary_path_intervention" and basis_step != anchor_step:
            shared._fail("impact_basis_not_anchor_step", location)
        if (
            evidence_class == "proven_execution_impact"
            and row.get("challenge_status") == "challenge"
            and isinstance(proposal_step, int)
            and proposal_step > anchor_step
        ):
            shared._fail("proven_impact_later_override", location)
        if (
            evidence_class == "unsupported_capability_anchor"
            and row.get("challenge_status") == "challenge"
            and row.get("anchor_classification")
            not in {"reasonable_probe", "noncritical_predecessor"}
        ):
            shared._fail("capability_override_without_anchor_veto", location)
        counts[evidence_class] += 1
    return {
        "required": True,
        "valid": True,
        "path": str(challenger_path),
        "record_count": len(rows),
        "evidence_class_counts": dict(sorted(counts.items())),
    }


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    audit = _retag(transport.validate_challenger(*paths))
    audit["observable_execution_impact_precedence"] = _validate_impact_challengers(
        paths[-1]
    )
    return audit


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    return _retag(transport.validate_arbiter(*paths))


def validate_agent_judge_luna_gaia_v3_34_predictions(
    *paths: str | Path,
) -> dict[str, Any]:
    audit = _retag(transport.validate_agent_judge_luna_gaia_v3_16_predictions(*paths))
    predictions = Path(paths[2]).expanduser().resolve()
    audit["schema_version"] = AGENT_JUDGE_LUNA_GAIA_V3_34_AUDIT_SCHEMA_VERSION
    audit["selection_policy"] = (
        "clean_v3_20_packet_state_anchor_one_observable_impact_"
        "bidirectional_challenger_default_keep_exact_copy_arbiter"
    )
    audit["direct_semantic_parent"] = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION
    audit["rejected_lineage_inherited"] = False
    audit["packet_state_closure"] = parent._validate_packet_state_ledgers(
        predictions.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME
    )
    audit["anchor_semantics_unchanged_from_v3_20"] = True
    audit["observable_execution_impact_precedence"] = True
    audit["observable_execution_impact_audit"] = _validate_impact_challengers(
        predictions.parent / CHALLENGERS_FILENAME
    )
    return audit


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_34_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_34_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_34_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_34_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_34_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_34_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

"""GAIA v3.86: accepted v3.83 plus one bounded typed-boundary challenger."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_gaia_v3_83_clean_v3p20_model_only_gpt55_medium as parent
from . import (
    agent_judge_luna_gaia_v3_39_clean_v3p20_bounded_typed_boundary_challenger
    as mechanism,
)


AGENT_JUDGE_GAIA_V3_86_VERSION = (
    "agentdebug.codex-agent-judge.gaia-v3.86-gpt55-bounded-typed-boundary-challenger"
)
AGENT_JUDGE_GAIA_V3_86_MODEL = "gpt-5.5"
AGENT_JUDGE_GAIA_V3_86_REASONING_EFFORT = "medium"
AGENT_JUDGE_GAIA_V3_86_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_GAIA_V3_83_AUDIT_SCHEMA_VERSION
)
SEMANTIC_PARENT = parent.AGENT_JUDGE_GAIA_V3_83_VERSION

AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_GAIA_V3_86_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_GAIA_V3_86_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_86_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_GAIA_V3_86_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = parent.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = parent.CHALLENGERS_FILENAME
ARBITER_FILENAME = parent.ARBITER_FILENAME
ARBITERS_FILENAME = parent.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = parent.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = parent.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME


def _retag_task(task: str) -> str:
    result = task.replace(
        mechanism.AGENT_JUDGE_LUNA_GAIA_V3_39_VERSION,
        AGENT_JUDGE_GAIA_V3_86_VERSION,
    ).replace(
        f"- model: {mechanism.AGENT_JUDGE_LUNA_GAIA_V3_39_MODEL}",
        f"- model: {AGENT_JUDGE_GAIA_V3_86_MODEL}",
    )
    old_module = "agent_judge_luna_gaia_v3_39_clean_v3p20_bounded_typed_boundary_challenger"
    new_module = "agent_judge_gaia_v3_86_gpt55_bounded_typed_boundary_challenger"
    return result.replace(old_module, new_module)


def _retag_parent_task(task: str) -> str:
    marker = parent.AGENT_JUDGE_GAIA_V3_83_VERSION
    if task.count(marker) != 1:
        raise RuntimeError("v3.83 task identity marker changed unexpectedly")
    return task.replace(marker, AGENT_JUDGE_GAIA_V3_86_VERSION, 1)


def build_anchor_task(*paths: str | Path) -> str:
    return _retag_parent_task(parent.build_anchor_task(*paths))


def build_challenger_task(*paths: str | Path) -> str:
    return _retag_task(mechanism.build_challenger_task(*paths))


def build_arbiter_task(*paths: str | Path) -> str:
    return _retag_parent_task(parent.build_arbiter_task(*paths))


def build_agent_judge_gaia_v3_86_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def _retag(audit: dict[str, Any]) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_GAIA_V3_86_VERSION,
        "model": AGENT_JUDGE_GAIA_V3_86_MODEL,
        "reasoning_effort": AGENT_JUDGE_GAIA_V3_86_REASONING_EFFORT,
        "semantic_parent": SEMANTIC_PARENT,
        "direct_semantic_parent": SEMANTIC_PARENT,
        "rejected_lineage_inherited": False,
        "single_major_change": "one bounded typed-boundary later challenger",
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(mechanism.validate_anchor_predictions(*paths))


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    return _retag(mechanism.validate_challenger(*paths))


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    return _retag(mechanism.validate_arbiter(*paths))


def validate_agent_judge_gaia_v3_86_predictions(*paths: str | Path) -> dict[str, Any]:
    audit = _retag(mechanism.validate_agent_judge_luna_gaia_v3_39_predictions(*paths))
    audit["anchor_semantics_unchanged_from_v3_83"] = True
    audit["arbiter_semantics_unchanged_from_v3_83"] = True
    return audit


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return mechanism._write(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_gaia_v3_86_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_agent_judge_gaia_v3_86_predictions(*paths[:-1]), paths[-1])


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_gaia_v3_86_task
validate_agent_judge_luna_gaia_v3_13_predictions = validate_agent_judge_gaia_v3_86_predictions
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_gaia_v3_86_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_gaia_v3_86_audit(*paths)
        else:
            mechanism.shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except mechanism.shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    args = parser.parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

"""Gold-free three-agent debate with a structured causal tournament.

The first two agents produce fresh, different-step proposals.  The third agent
does not freely invent a new answer: it writes an explicit pairwise causal
comparison and then copies exactly one of the two proposals.  The parent-side
validator checks both the comparison contract and the exact-copy decision.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
    _file_sha256,
    _load_json,
)
from .agent_judge_luna_debate_v1 import (
    AGENT_JUDGE_LUNA_DEBATE_V1_VERSION,
    PROPOSAL_A_FILENAME,
    PROPOSAL_B_FILENAME,
    _write_audit,
    build_luna_clean_debate_arbiter_task as _build_v1_arbiter_task,
    build_luna_clean_debate_challenger_task as _build_v1_challenger_task,
    build_luna_clean_debate_draft_task as _build_v1_draft_task,
    validate_luna_clean_debate_challenger_predictions as _validate_v1_challenger,
    validate_luna_clean_debate_draft_predictions as _validate_v1_draft,
)
from .agent_judge_luna_v3_serial_v2 import _nested_owner_source_resolver
from .agent_judge import _validate_agent_judge_predictions_with_owner_sources
from .agent_judge_v2_4 import AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION


AGENT_JUDGE_LUNA_DEBATE_V2_VERSION = (
    "agentdebug.codex-agent-judge.luna-clean-debate-v2"
)
AGENT_JUDGE_LUNA_DEBATE_V2_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_DEBATE_V2_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_DEBATE_V2_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)

COMPARISON_FILENAME = "causal-ledger.json"
COMPARISON_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "status",
    "proposal_a_step",
    "proposal_b_step",
    "proposal_a_maturity",
    "proposal_b_maturity",
    "causal_relation",
    "proposal_a_counterfactual",
    "proposal_b_counterfactual",
    "information_bottleneck_candidate",
    "terminal_boundary_candidate",
    "selected_proposal",
    "selection_rule",
    "selection_rationale",
)
MATURITY_VALUES = ("demonstrated", "uncertain", "reasonable")
CAUSAL_RELATION_VALUES = (
    "a_upstream_of_b",
    "b_upstream_of_a",
    "independent",
    "neither_mature",
)
CANDIDATE_VALUES = ("A", "B", "neither")
SELECTION_RULE_VALUES = (
    "causal_predecessor",
    "demonstrated_contradiction",
    "terminal_boundary",
    "stronger_counterfactual",
)


def _upgrade_v1_task(task: str) -> str:
    task = task.replace(
        AGENT_JUDGE_LUNA_DEBATE_V1_VERSION,
        AGENT_JUDGE_LUNA_DEBATE_V2_VERSION,
    )
    task = task.replace(
        "agentdebug/diagnostics/agent_judge_luna_debate_v1.py",
        "agentdebug/diagnostics/agent_judge_luna_debate_v2.py",
    )
    task = task.replace(
        "agentdebug.diagnostics.agent_judge_luna_debate_v1",
        "agentdebug.diagnostics.agent_judge_luna_debate_v2",
    )
    return task


def _uniform_causal_rules() -> str:
    return """\
UNIFORM CAUSAL-BOUNDARY CLARIFICATIONS

- A task-defining entity, filter, relation, or prerequisite omitted by a plan
  is a mature information bottleneck when the following action faithfully
  narrows or queries the wrong evidence space and the later failure flows from
  that missing distinction.  Do not move ownership to a later unsupported
  conclusion merely because its error is easier to describe.
- Repeating an operation class is not itself repetition.  Distinct, previously
  untested targets remain distinct probes when each is plausible under the
  evidence then.  Prefer a terminal external boundary over inefficient_plan
  when progress was otherwise reasonable and the only demonstrated blocker is
  the provenance-backed limit.
- These rules apply to every trajectory.  They do not establish an earlier-step
  prior: reject an early omission that is speculative, immaterial, or repaired
  before consequence, and prefer a later directly demonstrated defect then.

"""


def _insert_uniform_rules(task: str) -> str:
    marker = "AGENT ERROR TAXONOMY\n"
    if task.count(marker) != 1:
        raise RuntimeError("frozen debate v2 taxonomy marker changed")
    return task.replace(marker, _uniform_causal_rules() + marker, 1)


def build_luna_clean_debate_v2_draft_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
) -> str:
    return _insert_uniform_rules(
        _upgrade_v1_task(
            _build_v1_draft_task(
                prediction_manifest_path, cohort_manifest_path, proposal_a_path
            )
        )
    )


def build_luna_clean_debate_v2_challenger_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
    proposal_b_path: str | Path,
) -> str:
    return _insert_uniform_rules(
        _upgrade_v1_task(
            _build_v1_challenger_task(
                prediction_manifest_path,
                cohort_manifest_path,
                proposal_a_path,
                proposal_b_path,
            )
        )
    )


def _comparison_schema() -> dict[str, str]:
    return {
        "trajectory_id": "exact manifest trajectory ID",
        "trajectory_sha256": "exact manifest trajectory SHA-256",
        "status": "success",
        "proposal_a_step": "exact proposal A predicted_step integer",
        "proposal_b_step": "exact proposal B predicted_step integer",
        "proposal_a_maturity": "demonstrated | uncertain | reasonable",
        "proposal_b_maturity": "demonstrated | uncertain | reasonable",
        "causal_relation": (
            "a_upstream_of_b | b_upstream_of_a | independent | neither_mature"
        ),
        "proposal_a_counterfactual": "non-empty source-grounded counterfactual",
        "proposal_b_counterfactual": "non-empty source-grounded counterfactual",
        "information_bottleneck_candidate": "A | B | neither",
        "terminal_boundary_candidate": "A | B | neither",
        "selected_proposal": "A | B",
        "selection_rule": (
            "causal_predecessor | demonstrated_contradiction | "
            "terminal_boundary | stronger_counterfactual"
        ),
        "selection_rationale": "non-empty pairwise decision explanation",
    }


def build_luna_clean_debate_v2_arbiter_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
    proposal_b_path: str | Path,
    predictions_path: str | Path,
) -> str:
    output = Path(predictions_path).expanduser().resolve()
    comparison = output.parent / COMPARISON_FILENAME
    _assert_safe_path(comparison, role="candidate comparison output", is_output=True)
    task = _upgrade_v1_task(
        _build_v1_arbiter_task(
            prediction_manifest_path,
            cohort_manifest_path,
            proposal_a_path,
            proposal_b_path,
            predictions_path,
        )
    )
    start = task.index("NEUTRAL BLIND ARBITER ROLE\n")
    end = task.index("STANDALONE SINGLE-LOCAL-FAILURE ADJUDICATION\n", start)
    tournament = f"""\
STRUCTURED BLIND CAUSAL TOURNAMENT

Reconstruct the complete JudgeView before treating anonymous A and B as two
untrusted hypotheses.  Neither proposal is an incumbent, default, label, or
evidence.  Use no historical prediction and no module/error-type routing.

Run this exact pairwise decision procedure:

1. CONTEMPORANEOUS MATURITY.  For each proposal separately, decide whether its
   alleged defect was demonstrably wrong from information available at that
   step (demonstrated), remains speculative (uncertain), or was a reasonable
   probe/decision then (reasonable).  Later failure alone proves nothing.
2. LOCAL COUNTERFACTUAL.  State what correcting each candidate at its own step
   would change before the other candidate.  A counterfactual must name the
   task constraint, evidence gap, feedback, interface fact, or external limit
   that makes the change causal.
3. CAUSAL DOMINANCE.  Mark X upstream of Y only when correcting X would prevent
   or materially redirect Y.  A faithful later conclusion, reflection, action,
   or repeated copy loses to its demonstrated predecessor.  Chronology alone
   is not dominance: an early speculative or recovered idea loses to a later
   directly demonstrated defect.
4. INFORMATION BOTTLENECK.  A plan/query that omits a task-defining entity,
   filter, relation, or prerequisite is mature when its faithful execution
   makes the required evidence unobtainable or non-discriminating and causes
   the later guess.  Prefer that introduction over the downstream guess.
5. TERMINAL BOUNDARY.  Repeating an operation class across distinct untested
   plausible targets is not a demonstrated inefficient plan.  Select a final
   provenance-backed System boundary when prior probes remain distinct and
   reasonable and no earlier agent candidate has a concrete contradiction.
6. SELECT.  Choose exactly A or B.  Prefer a demonstrated causal predecessor;
   otherwise the more directly contradicted candidate; otherwise a qualifying
   terminal boundary; otherwise the candidate with the stronger local
   counterfactual.  Do not reconstruct a third step.

First write one JSON object with exactly this schema to:
{comparison}

{json.dumps(_comparison_schema(), ensure_ascii=False, indent=2)}

Then write {output} by copying the selected proposal's entire ten-field record
exactly, byte values unchanged, inside a one-record JSON array.  Do not rewrite
its rationale or taxonomy.  The parent validator rejects a final record that
is not exactly proposal A or proposal B and rejects any missing comparison.

"""
    task = task[:start] + tournament + task[end:]
    task = task.replace(
        f"- write predictions only to: {output}",
        f"- write candidate comparison only to: {comparison}\n"
        f"- write predictions only to: {output}",
        1,
    )
    return _insert_uniform_rules(task)


def build_luna_clean_debate_v2_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    output = Path(predictions_path).expanduser().resolve()
    return build_luna_clean_debate_v2_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        output.parent / PROPOSAL_A_FILENAME,
        output.parent / PROPOSAL_B_FILENAME,
        output,
    )


def _validate_prediction(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    return _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_nested_owner_source_resolver,
    )


def validate_luna_clean_debate_v2_draft_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
) -> dict[str, Any]:
    audit = _validate_v1_draft(
        prediction_manifest_path, cohort_manifest_path, proposal_a_path
    )
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_DEBATE_V2_VERSION,
        "structured_causal_tournament": True,
    }


def validate_luna_clean_debate_v2_challenger_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
    proposal_b_path: str | Path,
) -> dict[str, Any]:
    audit = _validate_v1_challenger(
        prediction_manifest_path,
        cohort_manifest_path,
        proposal_a_path,
        proposal_b_path,
    )
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_DEBATE_V2_VERSION,
        "structured_causal_tournament": True,
    }


def _validate_comparison_record(
    value: Any,
    proposal_a: Mapping[str, Any],
    proposal_b: Mapping[str, Any],
) -> dict[str, Any]:
    if not isinstance(value, dict) or tuple(value) != COMPARISON_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_candidate_comparison_schema",
            "candidate comparison must be one exact ordered-field JSON object",
        )
    for field in (
        "proposal_a_counterfactual",
        "proposal_b_counterfactual",
        "selection_rationale",
    ):
        if not isinstance(value[field], str) or not value[field].strip():
            raise AgentJudgeValidationError(
                "invalid_candidate_comparison_text", f"{field} must be non-empty"
            )
    if value["trajectory_id"] != proposal_a["trajectory_id"] or value[
        "trajectory_id"
    ] != proposal_b["trajectory_id"]:
        raise AgentJudgeValidationError(
            "candidate_comparison_identity_mismatch", "trajectory ID mismatch"
        )
    if value["trajectory_sha256"] != proposal_a["trajectory_sha256"] or value[
        "trajectory_sha256"
    ] != proposal_b["trajectory_sha256"]:
        raise AgentJudgeValidationError(
            "candidate_comparison_identity_mismatch", "trajectory hash mismatch"
        )
    if value["status"] != "success":
        raise AgentJudgeValidationError(
            "invalid_candidate_comparison_status", "status must be success"
        )
    if value["proposal_a_step"] != proposal_a["predicted_step"] or value[
        "proposal_b_step"
    ] != proposal_b["predicted_step"]:
        raise AgentJudgeValidationError(
            "candidate_comparison_step_mismatch", "proposal step mismatch"
        )
    enums = {
        "proposal_a_maturity": MATURITY_VALUES,
        "proposal_b_maturity": MATURITY_VALUES,
        "causal_relation": CAUSAL_RELATION_VALUES,
        "information_bottleneck_candidate": CANDIDATE_VALUES,
        "terminal_boundary_candidate": CANDIDATE_VALUES,
        "selected_proposal": ("A", "B"),
        "selection_rule": SELECTION_RULE_VALUES,
    }
    for field, allowed in enums.items():
        if value[field] not in allowed:
            raise AgentJudgeValidationError(
                "invalid_candidate_comparison_enum",
                f"{field} must be one of {allowed}",
            )
    return value


def validate_luna_clean_debate_v2_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    output = Path(predictions_path).expanduser().resolve()
    proposal_a_path = output.parent / PROPOSAL_A_FILENAME
    proposal_b_path = output.parent / PROPOSAL_B_FILENAME
    comparison_path = output.parent / COMPARISON_FILENAME
    challenger = validate_luna_clean_debate_v2_challenger_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        proposal_a_path,
        proposal_b_path,
    )
    audit = _validate_prediction(
        prediction_manifest_path, cohort_manifest_path, output
    )
    a_records = _load_json(proposal_a_path, role="proposal A")
    b_records = _load_json(proposal_b_path, role="proposal B")
    final_records = _load_json(output, role="predictions")
    if not (
        isinstance(a_records, list)
        and isinstance(b_records, list)
        and isinstance(final_records, list)
        and len(a_records) == len(b_records) == len(final_records)
    ):
        raise AgentJudgeValidationError(
            "candidate_final_cardinality_mismatch", "candidate cardinality mismatch"
        )
    comparison_value = _load_json(comparison_path, role="candidate comparison")
    if len(final_records) == 1 and isinstance(comparison_value, dict):
        comparison_records = [comparison_value]
    elif isinstance(comparison_value, list):
        comparison_records = comparison_value
    else:
        raise AgentJudgeValidationError(
            "invalid_candidate_comparison_schema",
            "comparison must be one isolated object or a merged object array",
        )
    if len(comparison_records) != len(final_records):
        raise AgentJudgeValidationError(
            "candidate_comparison_cardinality_mismatch",
            "comparison and predictions cardinality mismatch",
        )
    comparisons: list[dict[str, Any]] = []
    for index, (proposal_a, proposal_b, final, comparison_value) in enumerate(
        zip(
            a_records,
            b_records,
            final_records,
            comparison_records,
            strict=True,
        )
    ):
        comparison = _validate_comparison_record(
            comparison_value, proposal_a, proposal_b
        )
        selected = (
            proposal_a if comparison["selected_proposal"] == "A" else proposal_b
        )
        if final != selected or set(final) != AGENT_JUDGE_PREDICTION_FIELDS:
            raise AgentJudgeValidationError(
                "final_not_exact_selected_proposal",
                f"final prediction at index {index} must exactly copy the selection",
            )
        comparisons.append(comparison)
    selected_counts = {
        candidate: sum(
            comparison["selected_proposal"] == candidate
            for comparison in comparisons
        )
        for candidate in ("A", "B")
    }
    selection_rule_counts = {
        rule: sum(comparison["selection_rule"] == rule for comparison in comparisons)
        for rule in SELECTION_RULE_VALUES
    }
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_DEBATE_V2_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_DEBATE_V2_VERSION,
        "model": AGENT_JUDGE_LUNA_DEBATE_V2_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_DEBATE_V2_REASONING_EFFORT,
        "proposal_free_of_historical_predictions": True,
        "label_pair_routing_used": False,
        "fresh_same_case_proposal_count": 2,
        "structured_causal_tournament": True,
        "final_exactly_selected_proposal": True,
        "challenger_multi_step_difference_count": challenger[
            "multi_step_different_proposal_count"
        ],
        "selected_proposal_counts": selected_counts,
        "selection_rule_counts": selection_rule_counts,
        "output_sha256": {
            "predictions.json": _file_sha256(output),
            PROPOSAL_A_FILENAME: _file_sha256(proposal_a_path),
            PROPOSAL_B_FILENAME: _file_sha256(proposal_b_path),
            COMPARISON_FILENAME: _file_sha256(comparison_path),
        },
    }


def validate_and_write_luna_clean_debate_draft_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_a_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        audit_path,
        validate_luna_clean_debate_v2_draft_predictions(
            prediction_manifest_path, cohort_manifest_path, proposal_a_path
        ),
    )


def validate_and_write_luna_clean_debate_challenger_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    proposal_b_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    output = Path(proposal_b_path).expanduser().resolve()
    return _write_audit(
        audit_path,
        validate_luna_clean_debate_v2_challenger_predictions(
            prediction_manifest_path,
            cohort_manifest_path,
            output.parent / PROPOSAL_A_FILENAME,
            output,
        ),
    )


def validate_and_write_luna_clean_debate_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        audit_path,
        validate_luna_clean_debate_v2_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
    )


__all__ = [
    "AGENT_JUDGE_LUNA_DEBATE_V2_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_DEBATE_V2_MODEL",
    "AGENT_JUDGE_LUNA_DEBATE_V2_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_DEBATE_V2_VERSION",
    "COMPARISON_FILENAME",
    "PROPOSAL_A_FILENAME",
    "PROPOSAL_B_FILENAME",
    "build_luna_clean_debate_v2_arbiter_task",
    "build_luna_clean_debate_v2_challenger_task",
    "build_luna_clean_debate_v2_draft_task",
    "build_luna_clean_debate_v2_task",
    "validate_luna_clean_debate_v2_challenger_predictions",
    "validate_luna_clean_debate_v2_draft_predictions",
    "validate_luna_clean_debate_v2_predictions",
]

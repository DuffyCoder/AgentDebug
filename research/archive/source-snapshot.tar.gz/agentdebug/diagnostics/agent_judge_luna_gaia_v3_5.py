"""Luna GAIA v3.5: v3.4 plus immediate-subgoal capability admission."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
)
from .agent_judge_luna_gaia_v3 import STEP_FREEZE_FIELDS, STEP_FREEZE_FILENAME
from .agent_judge_luna_gaia_v3_4 import (
    AGENT_JUDGE_LUNA_GAIA_V3_4_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_LUNA_GAIA_V3_4_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_4_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_4_VERSION,
    STEP_CANDIDATE_LEDGER_FIELDS,
    STEP_CANDIDATE_LEDGER_FILENAME,
    STEP_CANDIDATE_LANES,
    STEP_CANDIDATE_ROW_FIELDS,
    STEP_CANDIDATE_STATUSES,
    build_agent_judge_luna_gaia_v3_4_task,
    validate_agent_judge_luna_gaia_v3_4_predictions,
)


AGENT_JUDGE_LUNA_GAIA_V3_5_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.5"
)
AGENT_JUDGE_LUNA_GAIA_V3_5_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_4_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_5_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_4_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_5_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_4_AUDIT_SCHEMA_VERSION
)


_POSITIVE_CAPABILITY_GATE = """\
POSITIVE IMMEDIATE-SUBGOAL CAPABILITY GATE

Apply this gate only to the Lane-B tool/corpus capability subcheck.  It changes
no Lane-A fact audit, explicit source or output constraint, prerequisite check,
Action validation, System packet ordering, recovery veto, or Lane-C strategy
decision.

Before marking Planning `impossible_action`, identify the evidence that the
current plan assigns to the current immediate subgoal.  Admit the candidate
only when even a successful invocation of the selected tool/corpus cannot
expose any necessary evidence for that immediate subgoal.

Use these rules:

- Evidence contribution is not full-task completion.  A probe can contribute
  a title, target, year, citation, context, formula, or other necessary fact
  even when more sources or a missing value are still required later.
- Decide capability from the plan and documented interface, not from the
  observed outcome.  Raw PDF bytes, normal 403/access-denied text, an empty
  result, or an uninformative page cannot retroactively turn a capable plan
  into `impossible_action`; audit any later false reading in Lane A.
- General web discovery can expose indexed pages, snippets, mirrors, targets,
  or citations.  A URL text extractor can in principle expose static HTML or
  PDF text.  An arithmetic tool can derive or test a method even before the
  final task-specific numeric input is known.  These are capable when that is
  the immediate evidence assigned by the plan.
- Preserve hard negative controls.  After the exact video/URL is identified, a
  static page-text extractor cannot expose dynamic frames, narration, or
  timestamp ordering.  arXiv/PubMed cannot expose another database's UI-level
  flag or language state.  These remain immediate Lane-B candidates when the
  plan assigns that unavailable evidence to them.
- Do not project the ultimate task predicate backward onto an earlier discovery
  action.  A search that identifies the exact video is capable even though a
  later tool is needed to inspect its timestamp; a context search is capable
  even though it cannot alone establish a database UI flag.

Record the immediate evidence assignment and this positive capability test in
the row's `decision_basis`.  A capability rejection affects only `lane_b`; it
cannot make another lane clear or vetoed.

"""


def build_agent_judge_luna_gaia_v3_5_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build v3.4 with one Lane-B positive capability clarification."""

    task = build_agent_judge_luna_gaia_v3_4_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    task = task.replace(
        AGENT_JUDGE_LUNA_GAIA_V3_4_VERSION,
        AGENT_JUDGE_LUNA_GAIA_V3_5_VERSION,
    )
    task = task.replace(
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_4.py",
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_5.py",
    )
    task = task.replace(
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_4 import "
        "validate_and_write_agent_judge_luna_gaia_v3_4_audit as run",
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_5 import "
        "validate_and_write_agent_judge_luna_gaia_v3_5_audit as run",
    )
    lane_c = "LANE C — STRATEGY EPOCHS AND TERMINAL ABANDONMENT\n"
    if task.count(lane_c) != 1:
        raise RuntimeError("Luna GAIA v3.4 lane-C boundary changed unexpectedly")
    return task.replace(lane_c, _POSITIVE_CAPABILITY_GATE + lane_c, 1)


def validate_agent_judge_luna_gaia_v3_5_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_4_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_5_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_5_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_5_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_5_REASONING_EFFORT,
        "selection_policy": (
            "lane_ordered_chronology_validated_step_candidate_ledger_"
            "limited_recovery_veto_external_exception_packet_fence_"
            "positive_immediate_subgoal_capability_gate"
        ),
        "positive_capability_admission_gate": (
            "any_necessary_evidence_for_current_immediate_subgoal"
        ),
    }


def validate_and_write_agent_judge_luna_gaia_v3_5_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_5_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


__all__ = [
    "AGENT_JUDGE_LUNA_GAIA_V3_5_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_GAIA_V3_5_MODEL",
    "AGENT_JUDGE_LUNA_GAIA_V3_5_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_GAIA_V3_5_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "STEP_CANDIDATE_LEDGER_FIELDS",
    "STEP_CANDIDATE_LEDGER_FILENAME",
    "STEP_CANDIDATE_LANES",
    "STEP_CANDIDATE_ROW_FIELDS",
    "STEP_CANDIDATE_STATUSES",
    "STEP_FREEZE_FIELDS",
    "STEP_FREEZE_FILENAME",
    "build_agent_judge_luna_gaia_v3_5_task",
    "validate_agent_judge_luna_gaia_v3_5_predictions",
    "validate_and_write_agent_judge_luna_gaia_v3_5_audit",
]

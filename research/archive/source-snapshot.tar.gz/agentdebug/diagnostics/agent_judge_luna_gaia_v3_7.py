"""Luna GAIA v3.7: v3.6 with validated strategy state before Lane C."""

from __future__ import annotations

import argparse
import copy
import json
import os
from pathlib import Path
from typing import Any, Sequence

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
)
from .agent_judge_luna_gaia_v3 import (
    STEP_FREEZE_FIELDS,
    STEP_FREEZE_FILENAME,
    _file_sha256,
)
from .agent_judge_luna_gaia_v3_1 import (
    validate_agent_judge_luna_gaia_v3_1_predictions,
)
from .agent_judge_luna_gaia_v3_4 import (
    STEP_CANDIDATE_LEDGER_FIELDS,
    STEP_CANDIDATE_LEDGER_FILENAME,
    STEP_CANDIDATE_LANES,
    STEP_CANDIDATE_STATUSES,
    _validate_step_candidate_ledger_document,
)
from .agent_judge_luna_gaia_v3_6 import (
    AGENT_JUDGE_LUNA_GAIA_V3_6_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_LUNA_GAIA_V3_6_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_6_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_6_VERSION,
    build_agent_judge_luna_gaia_v3_6_task,
)


AGENT_JUDGE_LUNA_GAIA_V3_7_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.7"
)
AGENT_JUDGE_LUNA_GAIA_V3_7_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_6_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_7_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_6_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_7_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_6_AUDIT_SCHEMA_VERSION
)

STRATEGY_STATE_FIELD = "strategy_state"
STRATEGY_STATE_FIELDS = (
    "anchor_step",
    "prior_route_attempts",
    "delta_class",
    "anchor_feedback",
    "route_disposition",
)
STRATEGY_DELTA_CLASSES = frozenset(
    {
        "initial",
        "same_route",
        "new_source_or_host",
        "new_modality",
        "new_target_or_constraint",
        "return_to_route",
        "not_applicable",
    }
)
STRATEGY_FEEDBACK_CLASSES = frozenset(
    {
        "productive",
        "uninformative_or_contrary",
        "failed_access",
        "not_applicable",
    }
)
STRATEGY_ROUTE_DISPOSITIONS = frozenset(
    {
        "initial_probe",
        "different_probe",
        "not_mature",
        "mature_repeat",
        "terminal_abandonment",
        "not_applicable",
    }
)
STEP_CANDIDATE_ROW_FIELDS = (
    "step",
    "lane_a",
    "lane_b",
    "system",
    STRATEGY_STATE_FIELD,
    "lane_c",
    "surviving_lane",
    "evidence_quote",
    "decision_basis",
)


_STRUCTURED_STRATEGY_STATE_RULES = """\
STRUCTURED STRATEGY-STATE GATE

Apply this gate only to Lane C.  It changes no Lane-A claim audit, Lane-B
source/prerequisite/capability/Action rule, System packet fence, recovery veto,
same-step owner/type rule, or evidence rule.

Before assigning `lane_c`, record one `strategy_state` object for the current
row.  It must contain, in order: `anchor_step`, `prior_route_attempts`,
`delta_class`, `anchor_feedback`, and `route_disposition`.

Normalize a route by unresolved subgoal, source/host, modality, explicit
target or constraint, and information route.  Count every earlier attempt of
that normalized route, including attempts separated by a different probe.
Classify the current delta as exactly one of:

- `initial`: no earlier attempt of this route;
- `same_route`: the current route is semantically the same as its anchor;
- `new_source_or_host`: a literal source, host, corpus, or site restriction is
  new;
- `new_modality`: the operation/evidence modality is materially new;
- `new_target_or_constraint`: the action adds a literal target, entity,
  predicate, or constraint not already explicit in the anchor route;
- `return_to_route`: the route was tried earlier, another route intervened,
  and the current action returns to it;
- `not_applicable`: no information-route comparison is relevant.

Do not infer a new target from capitalization, word order, or a predicate that
was already explicit.  A literal `site:`/host restriction is new.  Exact or
semantic reuse remains the same route even when words are reordered.

Classify the anchor feedback as `productive` when it exposed a relevant
candidate, target, link, or requested partial fact; `uninformative_or_contrary`
when it gave no useful evidence or directly refuted the route's expectation;
`failed_access` for a demonstrated access/endpoint failure; otherwise
`not_applicable`.

Derive exactly one route disposition:

- `initial_probe`: `initial`; Lane C is `veto_initial_probe`.
- `different_probe`: a new source/host, modality, target, or constraint; Lane
  C is `veto_different_probe`.
- `not_mature`: the same route has only one prior attempt and that attempt was
  productive, so checking the candidate and then seeking another is not proof
  that the discovery route failed; Lane C is `clear`.
- `mature_repeat`: same/returned route after uninformative, contrary, or failed
  feedback, or after multiple prior route attempts have exhausted the
  information route; Lane C is `candidate`.
- `terminal_abandonment`: the agent terminates with required predicates still
  open while a viable route remains; Lane C is `candidate`.
- `not_applicable`: Lane C is `clear`.

`prior_route_attempts` is zero for an initial/different/not-applicable route
and a positive integer for same-route or return-to-route comparisons.  An
anchor is null only for initial or not-applicable state; otherwise it is an
earlier chronological step.  Free-text `decision_basis` cannot override this
object.  The validator enforces the state-to-Lane-C mapping.

"""


_INITIAL_STRATEGY_STATE = """\
      "strategy_state": {
        "anchor_step": null,
        "prior_route_attempts": 0,
        "delta_class": "initial",
        "anchor_feedback": "not_applicable",
        "route_disposition": "initial_probe"
      },
"""

_NOT_APPLICABLE_STRATEGY_STATE = """\
      "strategy_state": {
        "anchor_step": null,
        "prior_route_attempts": 0,
        "delta_class": "not_applicable",
        "anchor_feedback": "not_applicable",
        "route_disposition": "not_applicable"
      },
"""


def _strategy_error(code: str, message: str) -> None:
    raise AgentJudgeValidationError(code, message)


def _validate_strategy_state(
    state: Any,
    *,
    step: int,
    lane_c: str,
) -> None:
    location = f"step ledger row {step}.strategy_state"
    if not isinstance(state, dict) or tuple(state) != STRATEGY_STATE_FIELDS:
        _strategy_error(
            "invalid_strategy_state_schema",
            f"{location} has unexpected fields or field order",
        )
    anchor = state["anchor_step"]
    attempts = state["prior_route_attempts"]
    delta = state["delta_class"]
    feedback = state["anchor_feedback"]
    disposition = state["route_disposition"]
    if delta not in STRATEGY_DELTA_CLASSES:
        _strategy_error("invalid_strategy_delta_class", f"{location}.delta_class")
    if feedback not in STRATEGY_FEEDBACK_CLASSES:
        _strategy_error(
            "invalid_strategy_feedback_class",
            f"{location}.anchor_feedback",
        )
    if disposition not in STRATEGY_ROUTE_DISPOSITIONS:
        _strategy_error(
            "invalid_strategy_route_disposition",
            f"{location}.route_disposition",
        )
    if isinstance(attempts, bool) or not isinstance(attempts, int) or attempts < 0:
        _strategy_error(
            "invalid_strategy_attempt_count",
            f"{location}.prior_route_attempts must be a non-negative integer",
        )

    no_anchor = delta in {"initial", "not_applicable"}
    if no_anchor:
        if anchor is not None or attempts != 0 or feedback != "not_applicable":
            _strategy_error(
                "invalid_strategy_initial_state",
                f"{location} initial/not-applicable state must have no anchor",
            )
    elif (
        isinstance(anchor, bool)
        or not isinstance(anchor, int)
        or anchor < 1
        or anchor >= step
    ):
        _strategy_error(
            "invalid_strategy_anchor_step",
            f"{location}.anchor_step must identify an earlier step",
        )

    if delta in {"same_route", "return_to_route"}:
        if attempts < 1 or feedback == "not_applicable":
            _strategy_error(
                "invalid_strategy_comparison_state",
                f"{location} same/returned route needs attempts and feedback",
            )
    elif delta not in {"initial", "not_applicable"} and (
        attempts != 0 or feedback != "not_applicable"
    ):
        _strategy_error(
            "invalid_new_strategy_state",
            f"{location} materially new route must reset attempts and feedback",
        )

    if disposition == "initial_probe" and delta != "initial":
        _strategy_error("strategy_disposition_mismatch", location)
    if disposition == "different_probe" and delta not in {
        "new_source_or_host",
        "new_modality",
        "new_target_or_constraint",
    }:
        _strategy_error("strategy_disposition_mismatch", location)
    if disposition == "not_mature" and not (
        delta in {"same_route", "return_to_route"}
        and attempts == 1
        and feedback == "productive"
    ):
        _strategy_error("strategy_disposition_mismatch", location)
    if disposition == "mature_repeat" and not (
        delta in {"same_route", "return_to_route"}
        and (
            attempts > 1
            or feedback in {"uninformative_or_contrary", "failed_access"}
        )
    ):
        _strategy_error("strategy_disposition_mismatch", location)
    if disposition == "terminal_abandonment" and delta != "not_applicable":
        _strategy_error("strategy_disposition_mismatch", location)
    if disposition == "not_applicable" and delta != "not_applicable":
        _strategy_error("strategy_disposition_mismatch", location)

    expected_lane_c = {
        "initial_probe": {"veto_initial_probe"},
        "different_probe": {"veto_different_probe"},
        "not_mature": {"clear", "veto_terminal_supersession"},
        "mature_repeat": {"candidate"},
        "terminal_abandonment": {"candidate"},
        "not_applicable": {"clear"},
    }[disposition]
    if lane_c not in expected_lane_c:
        _strategy_error(
            "strategy_lane_c_mismatch",
            f"{location} disposition is inconsistent with lane_c",
        )


def _validate_strategy_ledger_document(
    value: Any,
    *,
    trajectory_id: str,
    step_count: int,
    predicted_step: int,
    selected_packet_sources: Sequence[str],
) -> None:
    """Validate v3.7 state, then reuse the v3.5.1-compatible ledger checks."""

    if not isinstance(value, dict) or tuple(value) != STEP_CANDIDATE_LEDGER_FIELDS:
        _strategy_error(
            "invalid_step_candidate_ledger_schema",
            "step ledger must contain only trajectory_id, rows, selected_step",
        )
    rows = value.get("rows")
    if not isinstance(rows, list):
        _strategy_error("invalid_step_candidate_ledger_rows", "rows must be a list")

    compatibility = copy.deepcopy(value)
    compatibility_rows = compatibility["rows"]
    for index, row in enumerate(rows, start=1):
        if not isinstance(row, dict) or tuple(row) != STEP_CANDIDATE_ROW_FIELDS:
            _strategy_error(
                "invalid_step_candidate_row_schema",
                f"step ledger row {index} has unexpected fields or field order",
            )
        if row.get("evidence_quote") is not None:
            _strategy_error(
                "non_null_step_candidate_evidence",
                "step-only ledger evidence_quote must remain null on every row",
            )
        _validate_strategy_state(
            row[STRATEGY_STATE_FIELD],
            step=index,
            lane_c=row["lane_c"],
        )
        del compatibility_rows[index - 1][STRATEGY_STATE_FIELD]

    nonempty_source = next(
        (source for source in selected_packet_sources if source),
        None,
    )
    if nonempty_source is None:
        _strategy_error(
            "missing_selected_step_packet_text",
            "selected step packet has no text for downstream evidence audit",
        )
    if compatibility_rows:
        compatibility_rows[-1]["evidence_quote"] = nonempty_source[:1]
    _validate_step_candidate_ledger_document(
        compatibility,
        trajectory_id=trajectory_id,
        step_count=step_count,
        predicted_step=predicted_step,
        selected_packet_sources=selected_packet_sources,
    )


def _validate_strategy_ledger(
    prediction_manifest_path: str | Path,
    predictions_path: Path,
) -> dict[str, Any]:
    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    _assert_safe_path(manifest_path, role="prediction manifest")
    from agentdebug.benchmark.prediction_manifest import (  # noqa: PLC0415
        PredictionManifestError,
        load_prediction_manifest,
    )

    try:
        _, cases = load_prediction_manifest(manifest_path)
    except PredictionManifestError as error:
        raise AgentJudgeValidationError(
            "invalid_prediction_manifest",
            str(error),
        ) from error
    if len(cases) != 1:
        _strategy_error(
            "invalid_step_candidate_ledger_scope",
            "step ledger validation requires exactly one manifest case",
        )
    try:
        predictions = json.loads(predictions_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise AgentJudgeValidationError(
            "invalid_predictions_json",
            "predictions are unavailable for step ledger validation",
        ) from error
    if not isinstance(predictions, list) or len(predictions) != 1:
        _strategy_error(
            "invalid_step_candidate_ledger_scope",
            "step ledger validation requires exactly one prediction",
        )

    ledger_path = predictions_path.parent / STEP_CANDIDATE_LEDGER_FILENAME
    _assert_safe_path(ledger_path, role="step candidate ledger")
    try:
        ledger = json.loads(ledger_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise AgentJudgeValidationError(
            "missing_or_invalid_step_candidate_ledger",
            "single-case prediction requires a valid step-candidates.json",
        ) from error

    case = cases[0]
    selected_step = predictions[0].get("predicted_step")
    if isinstance(selected_step, bool) or not isinstance(selected_step, int):
        _strategy_error(
            "step_candidate_ledger_step_mismatch",
            "prediction step is unavailable for ledger validation",
        )
    step = case.judge_view.steps[selected_step - 1]
    packet_sources = [step.assistant_raw_output]
    packet_sources.extend(item.text for item in step.adjacent_feedback)
    _validate_strategy_ledger_document(
        ledger,
        trajectory_id=case.trajectory_id,
        step_count=len(case.judge_view.steps),
        predicted_step=selected_step,
        selected_packet_sources=packet_sources,
    )
    return {
        "required": True,
        "valid": True,
        "path": str(ledger_path.resolve()),
        "sha256": _file_sha256(ledger_path),
        "row_count": len(ledger["rows"]),
        "selected_step": ledger["selected_step"],
        "surviving_lane": ledger["rows"][-1]["surviving_lane"],
        "evidence_deferred_to_final_prediction": True,
        "strategy_state_validated": True,
    }


def build_agent_judge_luna_gaia_v3_7_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build v3.6 with one structured strategy-state change."""

    task = build_agent_judge_luna_gaia_v3_6_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    task = task.replace(
        AGENT_JUDGE_LUNA_GAIA_V3_6_VERSION,
        AGENT_JUDGE_LUNA_GAIA_V3_7_VERSION,
    )
    task = task.replace(
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_6.py",
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_7.py",
    )
    task = task.replace(
        "agentdebug.diagnostics.agent_judge_luna_gaia_v3_6",
        "agentdebug.diagnostics.agent_judge_luna_gaia_v3_7",
    )

    lane_c = "LANE C — STRATEGY EPOCHS AND TERMINAL ABANDONMENT\n"
    if task.count(lane_c) != 1:
        raise RuntimeError("Luna GAIA v3.6 lane-C boundary changed unexpectedly")
    task = task.replace(lane_c, _STRUCTURED_STRATEGY_STATE_RULES + lane_c, 1)

    first_shape = (
        '      "system": "clear",\n'
        '      "lane_c": "veto_initial_probe",\n'
    )
    second_shape = (
        '      "system": "clear",\n'
        '      "lane_c": "clear",\n'
    )
    if task.count(first_shape) != 1 or task.count(second_shape) != 1:
        raise RuntimeError("Luna GAIA v3.6 ledger example changed unexpectedly")
    task = task.replace(
        first_shape,
        '      "system": "clear",\n'
        + _INITIAL_STRATEGY_STATE
        + '      "lane_c": "veto_initial_probe",\n',
        1,
    )
    task = task.replace(
        second_shape,
        '      "system": "clear",\n'
        + _NOT_APPLICABLE_STRATEGY_STATE
        + '      "lane_c": "clear",\n',
        1,
    )
    return task


def validate_agent_judge_luna_gaia_v3_7_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    prediction_path = Path(predictions_path).expanduser().resolve()
    audit = validate_agent_judge_luna_gaia_v3_1_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction_path,
    )
    ledger = (
        _validate_strategy_ledger(prediction_manifest_path, prediction_path)
        if audit["case_count"] == 1
        else {
            "required": False,
            "valid": None,
            "reason": "merged full-cohort validation follows validated shards",
        }
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_7_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_7_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_7_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_7_REASONING_EFFORT,
        "selection_policy": (
            "lane_ordered_chronology_validated_step_only_candidate_ledger_"
            "limited_recovery_veto_external_exception_packet_fence_"
            "positive_immediate_subgoal_capability_gate_"
            "positive_action_materiality_gate_validated_strategy_state"
        ),
        "step_candidate_ledger": ledger,
        "positive_capability_admission_gate": (
            "any_necessary_evidence_for_current_immediate_subgoal"
        ),
        "step_ledger_evidence_policy": "deferred_to_final_prediction",
        "positive_action_materiality_gate": (
            "rejection_semantic_change_or_false_state_consumption_required"
        ),
        "strategy_state_gate": (
            "delta_anchor_feedback_attempt_count_and_route_disposition"
        ),
    }


def validate_and_write_agent_judge_luna_gaia_v3_7_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_7_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


def run_agent_judge_luna_gaia_v3_7_compact_validation(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> int:
    try:
        audit = validate_and_write_agent_judge_luna_gaia_v3_7_audit(
            prediction_manifest_path,
            cohort_manifest_path,
            predictions_path,
            audit_path,
        )
    except AgentJudgeValidationError as error:
        print(
            json.dumps(
                {
                    "valid": False,
                    "error_code": error.code,
                    "error_message": str(error),
                },
                ensure_ascii=False,
            )
        )
        return 1
    except Exception as error:  # pragma: no cover - last-resort observability
        print(
            json.dumps(
                {
                    "valid": False,
                    "error_code": "unexpected_validation_error",
                    "error_message": f"{type(error).__name__}: {error}",
                },
                ensure_ascii=False,
            )
        )
        return 2
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("paths", nargs=4)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("--compact-validate is required")
    return run_agent_judge_luna_gaia_v3_7_compact_validation(*args.paths)


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "AGENT_JUDGE_LUNA_GAIA_V3_7_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_GAIA_V3_7_MODEL",
    "AGENT_JUDGE_LUNA_GAIA_V3_7_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_GAIA_V3_7_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "STEP_CANDIDATE_LEDGER_FIELDS",
    "STEP_CANDIDATE_LEDGER_FILENAME",
    "STEP_CANDIDATE_LANES",
    "STEP_CANDIDATE_ROW_FIELDS",
    "STEP_CANDIDATE_STATUSES",
    "STEP_FREEZE_FIELDS",
    "STEP_FREEZE_FILENAME",
    "STRATEGY_DELTA_CLASSES",
    "STRATEGY_FEEDBACK_CLASSES",
    "STRATEGY_ROUTE_DISPOSITIONS",
    "STRATEGY_STATE_FIELDS",
    "build_agent_judge_luna_gaia_v3_7_task",
    "main",
    "run_agent_judge_luna_gaia_v3_7_compact_validation",
    "validate_agent_judge_luna_gaia_v3_7_predictions",
    "validate_and_write_agent_judge_luna_gaia_v3_7_audit",
]

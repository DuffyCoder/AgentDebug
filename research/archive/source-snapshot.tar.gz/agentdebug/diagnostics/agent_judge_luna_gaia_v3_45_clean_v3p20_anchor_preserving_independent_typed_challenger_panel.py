"""Luna GAIA v3.45: clean v3.20 plus an anchor-preserving typed panel."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_14_earliest_causal_challenger as challenger_parent
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions
from .taxonomy import taxonomy_prompt


AGENT_JUDGE_LUNA_GAIA_V3_45_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.45-clean-v3.20-"
    "anchor-preserving-independent-typed-challenger-panel"
)
AGENT_JUDGE_LUNA_GAIA_V3_45_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_45_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_45_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases consumed by the shared full-GAIA runner.
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_45_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_45_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_45_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_45_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_45_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_45_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_45_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
CHALLENGER_FILENAME = "independent-typed-challenger.json"
CHALLENGER_AUDIT_FILENAME = "independent-typed-challenger-audit.json"
PANEL_FILENAME = "anchor-preserving-typed-challenger-pool.json"
PANELS_FILENAME = "anchor-preserving-typed-challenger-pools.json"
SELECTOR_FILENAME = "anchor-preserving-selector.json"
SELECTORS_FILENAME = "anchor-preserving-selectors.json"
SELECTOR_AUDIT_FILENAME = "anchor-preserving-selector-audit.json"
CHALLENGER_COUNT = 4
MAXIMUM_PROPOSAL_STEPS = CHALLENGER_COUNT

_TYPED_PREFIX = re.compile(
    r"^typed_boundary=(none|state_truth|post_feedback_maturity|alignment); "
    r"boundary_step=(none|[1-9]\d*); "
    r"maturity_witness_step=(none|[1-9]\d*); "
)

POOL_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "anchor_prediction_sha256",
    "anchor_prediction",
    "challenger_count",
    "challenger_set_sha256",
    "challengers",
    "proposal_candidate_count",
    "candidates",
)
CHALLENGER_WRAPPER_FIELDS = (
    "challenger_index",
    "challenger_sha256",
    "challenger",
)
CANDIDATE_FIELDS = (
    "candidate_id",
    "step",
    "support_count",
    "supporter_indices",
    "representative_prediction_sha256",
    "representative_prediction",
)
ASSESSMENT_FIELDS = (
    "candidate_id",
    "step",
    "support_count",
    "anchor_falsification_status",
    "literal_evidence_assessment",
    "anchor_repair_assessment",
    "proposal_repair_assessment",
    "timeline_assessment",
)
SELECTOR_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "pool_sha256",
    "anchor_step",
    "proposal_candidate_count",
    "compared_candidate_ids",
    "candidate_assessments",
    "decision",
    "frozen_step",
    "selected_prediction_sha256",
    "selected_prediction",
    "anchor_falsification_certificate",
    "decision_basis",
    "rejected_alternative_basis",
    "selection_falsifier",
)
ANCHOR_FALSIFICATION_STATUSES = frozenset({"proven", "not_proven"})


_BOUNDED_TYPED_BOUNDARY_RULES = """\
INDEPENDENT BOUNDED TYPED-BOUNDARY CHALLENGER — ZERO OR ONE PROPOSAL

The frozen clean-v3.20 prediction is the incumbent anchor. Its ledger and
checkpoint are immutable. Search only for literal evidence that this specific
anchor is a reasonable probe or noncritical predecessor and that one strictly
later typed boundary is independently failure-causing. Emit at most ONE
proposal and never enumerate a candidate pool. The anchor is the default and
wins under any uncertainty. You cannot see another challenger and must make a fully
independent chronology judgment.

ANCHOR FALSIFICATION GATE

A challenge is permitted only when literal chronology establishes that the
anchor is a reasonable information-producing probe or a noncritical
predecessor whose local repair does not avert the later failure. A normal tool
or site failure, low-probability but informative first probe, productive
specialized-resource change, and mechanically repairable request are not
critical roots. Keep an anchor that already owns an unrecovered direct
plan/Action contradiction, explicit constraint violation, task-material
unsupported state, or proven execution impact. A later Step that merely sounds
more severe, persistent, or explicit never falsifies the anchor.

TYPED LATER SEARCH

Only after the anchor gate passes, scan Step anchor+1 onward in strict
chronology. Test exactly these boundary types and stop at the earliest mature
one across all types:

1. `state_truth`: Memory/Reflection drops or distorts a concrete adjacent-
   feedback fact necessary to the next decision, retains an unsupported task-
   material entity/value/relation, or literally contradicts observed outcome
   or progress. The state must feed a decision and local repair must alter the
   later path.
2. `post_feedback_maturity`: after literal prior failure or zero task
   contribution, the Agent recommits to the same unresolved immediate
   predicate and evidence modality/extraction family without a new evidence
   dimension. An identical URL is unnecessary. A new source is different only
   when it can expose a different kind of evidence. The owner is the later
   Agent Step, not the raw failure.
3. `alignment`: the Step owns a direct plan-to-Action target/tool mismatch or
   literal user/source/constraint contradiction whose exact local repair can
   change the path.

VETOES AND CERTIFICATE

Reject initial/different probes, productive specialized routes, normal failure
results, recovered defects, mechanical/local defects, faithful propagation,
and downstream symptoms. A challenge must close literal owner, failed
predicate, evidence, path effect, maturity witness, veto comparison, anchor-
only repair, and proposal-only repair. If any component is uncertain, emit
no_challenge.

Begin search_summary exactly:
`typed_boundary=<none|state_truth|post_feedback_maturity|alignment>; boundary_step=<none|Step>; maturity_witness_step=<none|Step>; `

For no_challenge all three values are `none`. For a challenge, boundary_step
equals the proposed Step. state_truth/alignment use the proposed Step as
witness. post_feedback_maturity names a strictly earlier literal feedback Step.
The remainder must compare the anchor, every intervening plausible boundary,
and the proposal. The proposal is one complete legal prediction owned by its
Step/module.
"""

_SELECTOR_RULES = """\
ANCHOR-PRESERVING MULTI-CHALLENGER SELECTOR

The clean-v3.20 anchor is explicit and is the default. The four challenger
records were generated in mutually isolated sessions from the same frozen
anchor. Support count is corroboration only; it never proves correctness.

Assess every distinct proposal. An override requires one proposal to prove all
of the following with literal chronology:

1. the anchor is a reasonable probe or noncritical predecessor, not a critical
   root, and anchor-only repair cannot avert the proposal's independent defect;
2. the proposal owns one closed state_truth, post_feedback_maturity, or
   alignment boundary with a valid witness and no probe/recovery/mechanical/
   propagation/normal-failure veto;
3. proposal-only repair changes the task-material path;
4. it is the earliest mature proposal and directly dominates every competing
   proposal under the same repair test.

If any claim is absent, contradictory, or uncertain, keep_anchor. Do not
override for salience, persistence, later position, majority support, or more
forceful prose. Select only the exact anchor or one exact representative
proposal; never rewrite or combine predictions.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_45_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_45_clean_v3p20_anchor_preserving_independent_typed_challenger_panel",
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py",
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_45_clean_v3p20_anchor_preserving_independent_typed_challenger_panel.py",
        )
    )


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_45_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_45_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_45_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one anchor-preserving independent typed-challenger panel",
    }


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_anchor_task(*paths))


def build_challenger_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    challenger_index: int,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    challenger_path: str | Path,
) -> str:
    if challenger_index < 1 or challenger_index > CHALLENGER_COUNT:
        shared._fail("invalid_independent_challenger_index", str(challenger_index))
    task = parent.build_challenger_task(
        prediction_manifest_path,
        cohort_manifest_path,
        anchor_path,
        ledger_path,
        checkpoint_path,
        challenger_path,
    )
    marker = challenger_parent._EARLIEST_CAUSAL_RULES
    if task.count(marker) != 1:
        raise RuntimeError("v3.20 challenger-rule marker changed unexpectedly")
    task = task.replace(marker, _BOUNDED_TYPED_BOUNDARY_RULES, 1)
    task = task.replace(
        "stage 2/3: challenger.",
        f"independent typed challenger {challenger_index}/{CHALLENGER_COUNT}.",
        1,
    )
    return _rewrite_identity(task)


def _validate_typed_record(row: dict[str, Any], *, challenger_index: int) -> str:
    match = _TYPED_PREFIX.match(row.get("search_summary") or "")
    if match is None:
        shared._fail("missing_typed_boundary_prefix", f"challenger[{challenger_index}]")
    boundary, step_text, witness_text = match.groups()
    boundary_step = None if step_text == "none" else int(step_text)
    witness_step = None if witness_text == "none" else int(witness_text)
    challenged = row.get("challenge_status") == "challenge"
    proposal = row.get("proposed_prediction")
    proposal_step = proposal.get("predicted_step") if isinstance(proposal, dict) else None
    if not challenged:
        if boundary != "none" or boundary_step is not None or witness_step is not None:
            shared._fail("nonempty_typed_boundary_without_challenge", str(challenger_index))
    else:
        if boundary == "none" or boundary_step != proposal_step or witness_step is None:
            shared._fail("incomplete_typed_boundary_for_challenge", str(challenger_index))
        if boundary in {"state_truth", "alignment"} and witness_step != proposal_step:
            shared._fail("same_step_typed_boundary_witness_mismatch", str(challenger_index))
        if boundary == "post_feedback_maturity" and witness_step >= proposal_step:
            shared._fail("post_feedback_witness_not_prior", str(challenger_index))
    return boundary


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths), policy="unchanged_v3_20_anchor")


def validate_challenger(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    challenger_index: int,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    challenger_path: str | Path,
) -> dict[str, Any]:
    audit = parent.validate_challenger(
        prediction_manifest_path,
        cohort_manifest_path,
        anchor_path,
        ledger_path,
        checkpoint_path,
        challenger_path,
    )
    _, raw = shared._load_artifact(challenger_path, role="independent typed challenger")
    row = shared._one_record(raw, role="independent typed challenger")
    boundary = _validate_typed_record(row, challenger_index=challenger_index)
    return _retag(
        {
            **audit,
            "challenger_index": challenger_index,
            "typed_boundary": boundary,
            "anchor_visible": True,
            "prior_challengers_visible": False,
            "maximum_proposals": 1,
        },
        policy="independent_anchor_aware_bounded_typed_challenger",
    )


def _candidate_groups(wrappers: list[dict[str, Any]]) -> list[dict[str, Any]]:
    groups: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for wrapper in wrappers:
        challenger = wrapper["challenger"]
        if challenger["challenge_status"] != "challenge":
            continue
        groups[int(challenger["proposed_prediction"]["predicted_step"])].append(wrapper)
    sortable: list[tuple[str, int, list[dict[str, Any]]]] = []
    for step, members in groups.items():
        hashes = sorted(item["challenger_sha256"] for item in members)
        fingerprint = shared._stable_sha256(
            {"step": step, "support_count": len(members), "hashes": hashes}
        )
        sortable.append((fingerprint, step, members))
    result: list[dict[str, Any]] = []
    for candidate_index, (_, step, members) in enumerate(sorted(sortable), start=1):
        predictions = [item["challenger"]["proposed_prediction"] for item in members]
        representative = min(predictions, key=shared._stable_sha256)
        result.append(
            {
                "candidate_id": f"proposal-{candidate_index:02d}",
                "step": step,
                "support_count": len(members),
                "supporter_indices": sorted(item["challenger_index"] for item in members),
                "representative_prediction_sha256": shared._stable_sha256(representative),
                "representative_prediction": representative,
            }
        )
    return result


def build_candidate_pool(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    challenger_paths: Sequence[str | Path],
    pool_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    anchor, ledger, checkpoint = shared._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    parent._validate_packet_state_ledgers(ledger_file)
    if len(challenger_paths) != CHALLENGER_COUNT:
        shared._fail("invalid_independent_challenger_count", str(len(challenger_paths)))
    wrappers: list[dict[str, Any]] = []
    for index, value in enumerate(challenger_paths, start=1):
        file, raw = shared._load_artifact(value, role=f"independent challenger {index}")
        challenger = shared._one_record(raw, role=f"independent challenger {index}")
        shared._validate_challenger_record(
            challenger,
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            location=f"challenger[{index}]",
        )
        _validate_typed_record(challenger, challenger_index=index)
        wrappers.append(
            {
                "challenger_index": index,
                "challenger_sha256": shared._stable_sha256(challenger),
                "challenger": challenger,
            }
        )
    candidates = _candidate_groups(wrappers)
    pool = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_prediction": anchor,
        "challenger_count": CHALLENGER_COUNT,
        "challenger_set_sha256": shared._stable_sha256(
            sorted(item["challenger_sha256"] for item in wrappers)
        ),
        "challengers": wrappers,
        "proposal_candidate_count": len(candidates),
        "candidates": candidates,
    }
    _validate_pool_record(pool, case=case, location="typed_pool[0]")
    output = Path(pool_path).expanduser().resolve()
    shared._assert_safe_path(output, role="typed challenger pool output", is_output=True)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps([pool], ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return pool


def _validate_pool_record(raw: Any, *, case: Any, location: str) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != POOL_FIELDS:
        shared._fail("invalid_typed_challenger_pool_schema", location)
    if raw["trajectory_id"] != case.trajectory_id or raw["trajectory_sha256"] != case.trajectory_sha256:
        shared._fail("typed_challenger_pool_identity_mismatch", location)
    anchor = shared._validate_prediction_record(
        raw["anchor_prediction"], case=case, location=f"{location}.anchor"
    )
    if raw["anchor_prediction_sha256"] != shared._stable_sha256(anchor):
        shared._fail("typed_challenger_pool_anchor_hash_mismatch", location)
    wrappers = raw["challengers"]
    if raw["challenger_count"] != CHALLENGER_COUNT or not isinstance(wrappers, list) or len(wrappers) != CHALLENGER_COUNT:
        shared._fail("invalid_typed_challenger_pool_count", location)
    hashes: list[str] = []
    for index, wrapper in enumerate(wrappers, start=1):
        if not isinstance(wrapper, dict) or tuple(wrapper) != CHALLENGER_WRAPPER_FIELDS:
            shared._fail("invalid_typed_challenger_wrapper", f"{location}[{index}]")
        if wrapper["challenger_index"] != index:
            shared._fail("typed_challenger_index_mismatch", f"{location}[{index}]")
        challenger = wrapper["challenger"]
        if wrapper["challenger_sha256"] != shared._stable_sha256(challenger):
            shared._fail("typed_challenger_hash_mismatch", f"{location}[{index}]")
        if challenger.get("anchor_prediction_sha256") != raw["anchor_prediction_sha256"]:
            shared._fail("typed_challenger_anchor_binding_mismatch", f"{location}[{index}]")
        _validate_typed_record(challenger, challenger_index=index)
        hashes.append(wrapper["challenger_sha256"])
    if raw["challenger_set_sha256"] != shared._stable_sha256(sorted(hashes)):
        shared._fail("typed_challenger_set_hash_mismatch", location)
    expected = _candidate_groups(wrappers)
    if raw["candidates"] != expected or raw["proposal_candidate_count"] != len(expected):
        shared._fail("typed_challenger_candidate_group_mismatch", location)
    if len(expected) > MAXIMUM_PROPOSAL_STEPS:
        shared._fail("typed_challenger_candidate_flood", location)
    for candidate in expected:
        if tuple(candidate) != CANDIDATE_FIELDS:
            shared._fail("invalid_typed_challenger_candidate_schema", location)
    return raw


def build_selector_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    pool_path: str | Path,
    selector_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    pool_file, raw = shared._load_artifact(pool_path, role="typed challenger pool")
    pool = shared._one_record(raw, role="typed challenger pool")
    _validate_pool_record(pool, case=case, location="typed_pool[0]")
    output = Path(selector_path).expanduser().resolve()
    shared._assert_safe_path(output, role="anchor-preserving selector output", is_output=True)
    audit = output.parent / SELECTOR_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_45_clean_v3p20_anchor_preserving_independent_typed_challenger_panel",
            "--compact-validate",
            "selector",
            manifest,
            cohort,
            pool_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    assessment_schema = {
        "candidate_id": "proposal ID",
        "step": "proposal Step",
        "support_count": "exact frozen support count",
        "anchor_falsification_status": "proven or not_proven",
        "literal_evidence_assessment": "literal owner/predicate/evidence check",
        "anchor_repair_assessment": "whether anchor-only repair averts later failure",
        "proposal_repair_assessment": "whether proposal-only repair changes path",
        "timeline_assessment": "anchor/intervening/proposal comparison",
    }
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "pool_sha256": shared._stable_sha256(pool),
        "anchor_step": pool["anchor_prediction"]["predicted_step"],
        "proposal_candidate_count": pool["proposal_candidate_count"],
        "compared_candidate_ids": [item["candidate_id"] for item in pool["candidates"]],
        "candidate_assessments": [assessment_schema],
        "decision": "keep_anchor or exact proposal ID",
        "frozen_step": "selected Step",
        "selected_prediction_sha256": "stable hash of exact selected prediction",
        "selected_prediction": "exact anchor or representative proposal",
        "anchor_falsification_certificate": "literal complete certificate or why none is proven",
        "decision_basis": "default-keep threshold decision",
        "rejected_alternative_basis": "why every unselected proposal loses",
        "selection_falsifier": "strongest concrete argument against the decision",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_45_VERSION} anchor-preserving selector.

{shared._boundary(manifest=manifest, cohort=cohort, reads=(pool_file,), output=output)}

{_SELECTOR_RULES}

The frozen anchor Step is {pool['anchor_prediction']['predicted_step']}. The
pool contains {pool['proposal_candidate_count']} distinct proposal Steps.
candidate_assessments must contain exactly one record for every proposal in
compared_candidate_ids order, copying candidate_id, Step, and support_count.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

Copy the selected prediction field-for-field and compute its stable sorted
compact JSON hash. After writing, run:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _validate_selector_record(raw: Any, *, case: Any, pool: dict[str, Any], location: str) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != SELECTOR_FIELDS:
        shared._fail("invalid_anchor_preserving_selector_schema", location)
    if raw["trajectory_id"] != case.trajectory_id or raw["trajectory_sha256"] != case.trajectory_sha256:
        shared._fail("anchor_preserving_selector_identity_mismatch", location)
    if raw["pool_sha256"] != shared._stable_sha256(pool):
        shared._fail("anchor_preserving_selector_pool_hash_mismatch", location)
    anchor = pool["anchor_prediction"]
    if raw["anchor_step"] != anchor["predicted_step"] or raw["proposal_candidate_count"] != pool["proposal_candidate_count"]:
        shared._fail("anchor_preserving_selector_count_mismatch", location)
    candidate_ids = [item["candidate_id"] for item in pool["candidates"]]
    if raw["compared_candidate_ids"] != candidate_ids:
        shared._fail("anchor_preserving_selector_skipped_candidate", location)
    assessments = raw["candidate_assessments"]
    if not isinstance(assessments, list) or len(assessments) != len(pool["candidates"]):
        shared._fail("invalid_anchor_preserving_assessment_count", location)
    for assessment, candidate in zip(assessments, pool["candidates"], strict=True):
        if not isinstance(assessment, dict) or tuple(assessment) != ASSESSMENT_FIELDS:
            shared._fail("invalid_anchor_preserving_assessment_schema", location)
        if (
            assessment["candidate_id"] != candidate["candidate_id"]
            or assessment["step"] != candidate["step"]
            or assessment["support_count"] != candidate["support_count"]
            or assessment["anchor_falsification_status"] not in ANCHOR_FALSIFICATION_STATUSES
        ):
            shared._fail("anchor_preserving_assessment_binding_mismatch", location)
        for field in ASSESSMENT_FIELDS[4:]:
            shared._nonempty_text(assessment[field], location=f"{location}.{field}", maximum=2600)
    decision = raw["decision"]
    if decision != "keep_anchor" and decision not in candidate_ids:
        shared._fail("invalid_anchor_preserving_selector_decision", location)
    selected = shared._validate_prediction_record(
        raw["selected_prediction"], case=case, location=f"{location}.selected"
    )
    if raw["selected_prediction_sha256"] != shared._stable_sha256(selected) or raw["frozen_step"] != selected["predicted_step"]:
        shared._fail("anchor_preserving_selector_selected_hash_mismatch", location)
    if decision == "keep_anchor":
        if selected != anchor:
            shared._fail("anchor_preserving_selector_anchor_copy_mismatch", location)
    else:
        chosen = next(item for item in pool["candidates"] if item["candidate_id"] == decision)
        assessment = next(item for item in assessments if item["candidate_id"] == decision)
        if assessment["anchor_falsification_status"] != "proven":
            shared._fail("selector_override_without_anchor_falsification", location)
        if selected != chosen["representative_prediction"] or selected["predicted_step"] <= anchor["predicted_step"]:
            shared._fail("anchor_preserving_selector_proposal_copy_mismatch", location)
    for field in (
        "anchor_falsification_certificate",
        "decision_basis",
        "rejected_alternative_basis",
        "selection_falsifier",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3000)
    return raw


def validate_selector(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    pool_path: str | Path,
    selector_path: str | Path,
) -> dict[str, Any]:
    _, _, case = shared._single_case_paths(prediction_manifest_path, cohort_manifest_path)
    pool_file, pool_raw = shared._load_artifact(pool_path, role="typed challenger pool")
    selector_file, selector_raw = shared._load_artifact(selector_path, role="anchor-preserving selector")
    pool = shared._one_record(pool_raw, role="typed challenger pool")
    selector = shared._one_record(selector_raw, role="anchor-preserving selector")
    _validate_pool_record(pool, case=case, location="typed_pool[0]")
    _validate_selector_record(selector, case=case, pool=pool, location="selector[0]")
    return _retag(
        {
            "schema_version": "agentdebug.anchor-preserving-typed-selector-audit.v1",
            "stage": "anchor_preserving_selector",
            "gold_free_validation": True,
            "case_count": 1,
            "proposal_candidate_count": pool["proposal_candidate_count"],
            "decision": selector["decision"],
            "default_anchor_policy": True,
            "all_candidates_compared": True,
            "selected_prediction_exact_copy": True,
            "input_sha256": {PANEL_FILENAME: shared._file_sha256(pool_file)},
            "output_sha256": {SELECTOR_FILENAME: shared._file_sha256(selector_file)},
        },
        policy="anchor_preserving_exact_copy_multi_challenger_selector",
    )


def _validate_aggregate(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(prediction_manifest_path, cohort_manifest_path)
    root = Path(predictions_path).expanduser().resolve().parent
    names = (
        ANCHOR_PREDICTIONS_FILENAME,
        ANCHOR_LEDGER_AGGREGATE_FILENAME,
        ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        PANELS_FILENAME,
        SELECTORS_FILENAME,
    )
    loaded = {name: shared._load_artifact(root / name, role=f"merged {name}")[1] for name in names}
    if any(not isinstance(value, list) or len(value) != len(cases) for value in loaded.values()):
        shared._fail("invalid_typed_panel_aggregate_count", "all artifacts need all cases")
    finals = shared._load_artifact(predictions_path, role="merged predictions")[1]
    if not isinstance(finals, list) or len(finals) != len(cases):
        shared._fail("invalid_typed_panel_prediction_count", "predictions need all cases")
    candidate_counts: Counter[int] = Counter()
    decision_counts: Counter[str] = Counter()
    proposal_count = 0
    for index, case in enumerate(cases):
        anchor = loaded[ANCHOR_PREDICTIONS_FILENAME][index]
        ledger = loaded[ANCHOR_LEDGER_AGGREGATE_FILENAME][index]
        checkpoint = loaded[ANCHOR_CHECKPOINT_AGGREGATE_FILENAME][index]
        pool = loaded[PANELS_FILENAME][index]
        selector = loaded[SELECTORS_FILENAME][index]
        location = f"typed_panel_merged[{index}]"
        shared._validate_prediction_record(anchor, case=case, location=f"{location}.anchor")
        if (
            ledger.get("trajectory_id") != case.trajectory_id
            or ledger.get("selected_step") != anchor["predicted_step"]
            or checkpoint.get("trajectory_id") != case.trajectory_id
            or checkpoint.get("predicted_step") != anchor["predicted_step"]
        ):
            shared._fail("typed_panel_anchor_sidecar_mismatch", location)
        _validate_pool_record(pool, case=case, location=f"{location}.pool")
        if pool["anchor_prediction"] != anchor:
            shared._fail("typed_panel_pool_anchor_mismatch", location)
        _validate_selector_record(selector, case=case, pool=pool, location=f"{location}.selector")
        final = shared._validate_prediction_record(finals[index], case=case, location=f"{location}.final")
        if final != selector["selected_prediction"]:
            shared._fail("typed_panel_final_copy_mismatch", location)
        candidate_counts[pool["proposal_candidate_count"]] += 1
        decision_counts[selector["decision"]] += 1
        proposal_count += sum(
            item["challenger"]["challenge_status"] == "challenge"
            for item in pool["challengers"]
        )
    return {
        "required": True,
        "valid": True,
        "anchor_aware_panel": True,
        "anchor_blind_panel": False,
        "independent_challenger_count": CHALLENGER_COUNT,
        "maximum_specialist_candidates": MAXIMUM_PROPOSAL_STEPS,
        "maximum_total_predictions": MAXIMUM_PROPOSAL_STEPS + 1,
        "candidate_provenance_visible_to_selector": True,
        "default_anchor_policy": True,
        "all_candidates_compared": True,
        "all_selected_predictions_exact_copies": True,
        "proposal_candidate_count_distribution": dict(sorted(candidate_counts.items())),
        "selector_decision_counts": dict(sorted(decision_counts.items())),
        "proposal_record_count": proposal_count,
        "packet_state_closure": parent._validate_packet_state_ledgers(
            root / ANCHOR_LEDGER_AGGREGATE_FILENAME
        ),
    }


def validate_agent_judge_luna_gaia_v3_45_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    panel = _validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_45_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_45_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_45_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_45_REASONING_EFFORT,
        "selection_policy": "clean_v3_20_anchor_preserving_independent_typed_challenger_panel",
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one anchor-preserving independent typed-challenger panel",
        "anchor_semantics_unchanged_from_v3_20": True,
        "all_selected_predictions_exact_copies": True,
        "factorized_specialist_panel": panel,
    }


def build_agent_judge_luna_gaia_v3_45_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_selector_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / PANEL_FILENAME,
        prediction.parent / SELECTOR_FILENAME,
    )


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: Any) -> dict[str, Any]:
    return _write(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_selector(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_45_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_45_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


validate_and_write_agent_judge_luna_gaia_v3_37_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_45_audit
)
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_luna_gaia_v3_45_task


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 8:
            manifest, cohort, index, anchor, ledger, checkpoint, challenger, audit_path = paths
            audit = validate_and_write_challenger_audit(
                manifest,
                cohort,
                int(index),
                anchor,
                ledger,
                checkpoint,
                challenger,
                audit_path,
            )
        elif stage == "selector" and len(paths) == 5:
            audit = validate_and_write_selector_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_45_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "selector", "prediction"))
    parser.add_argument("paths", nargs="+")
    args = parser.parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

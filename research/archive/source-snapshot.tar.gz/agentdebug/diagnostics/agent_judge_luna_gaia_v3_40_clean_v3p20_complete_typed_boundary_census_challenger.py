"""Luna GAIA v3.40: clean v3.20 with one complete typed boundary census."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger as transport
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent


AGENT_JUDGE_LUNA_GAIA_V3_40_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.40-clean-v3.20-"
    "complete-typed-boundary-census-challenger"
)
AGENT_JUDGE_LUNA_GAIA_V3_40_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_40_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_40_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases used by the shared three-stage paper runner.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_40_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_40_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_40_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_40_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = transport.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = transport.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = transport.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = transport.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = transport.CHALLENGERS_FILENAME
ARBITER_FILENAME = transport.ARBITER_FILENAME
ARBITERS_FILENAME = transport.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = transport.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = transport.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = transport.PREDICTION_AUDIT_FILENAME
CHALLENGER_FIELDS = transport.CHALLENGER_FIELDS
ARBITER_FIELDS = transport.ARBITER_FIELDS


_CENSUS_PREFIX = re.compile(
    r"^typed_step_census=([^;]+); "
    r"census_candidate_step=(none|[1-9]\d*); "
    r"census_direction=(none|earlier|same|later); "
)
_CENSUS_ENTRY = re.compile(
    r"^([1-9]\d*):([a-z_]+):([a-z_]+):(none|[1-9]\d*)$"
)
_CENSUS_VERDICTS = frozenset(
    {
        "clear",
        "reasonable_probe",
        "normal_failure",
        "recovered_or_mechanical",
        "faithful_propagation",
        "noncritical_local_error",
        "critical_candidate",
    }
)
_BOUNDARY_TYPES = frozenset(
    {"none", "state_truth", "post_feedback_maturity", "alignment"}
)
_UNTYPED_VERDICTS = frozenset(
    {"clear", "reasonable_probe", "normal_failure", "faithful_propagation"}
)


_COMPLETE_TYPED_BOUNDARY_CENSUS_RULES = """\
COMPLETE TYPED-BOUNDARY CENSUS — ONE BIDIRECTIONAL PROPOSAL MAXIMUM

The frozen clean-v3.20 packet-state prediction is the incumbent anchor. Do not
change or rerun its ledger or checkpoint. Before classifying the anchor,
inspect every Canonical Step exactly once in chronology, including Steps before,
at, and after it. Do not stop at the first plausible defect. The anchor remains
the default under uncertainty.

PER-STEP CLOSED TUPLE

For every observable Step close exactly four values:

1. VERDICT: `clear`, `reasonable_probe`, `normal_failure`,
   `recovered_or_mechanical`, `faithful_propagation`,
   `noncritical_local_error`, or `critical_candidate`.
2. BOUNDARY TYPE: `none`, `state_truth`, `post_feedback_maturity`, or
   `alignment`.
3. MATURITY WITNESS STEP: `none` or the literal Step that closes maturity.
4. LITERAL BASIS: explain the owner, immediate predicate, witness, repair
   counterfactual, and any veto in the compact timeline fields.

The three boundary types are mutually exclusive:

- `state_truth`: this Step's Memory/Reflection drops or distorts a concrete
  adjacent-feedback fact needed by the next decision, retains an unsupported
  task-material entity/value/relation, or contradicts observed outcome or
  progress. The owner and witness are this same Step; the false state must feed
  the current or next decision.
- `post_feedback_maturity`: this Agent Step recommits after a strictly earlier
  literal failure or zero-contribution result to the same unresolved immediate
  predicate and evidence modality/extraction family without a genuinely new
  evidence dimension. Exact query, URL, or source identity is not required.
  A cosmetic refinement is not new evidence; a route capable of exposing a
  different kind of needed fact is. The witness is the strictly earlier Step.
- `alignment`: this Step owns a direct plan-to-Action target/tool mismatch or a
  literal explicit user/source/constraint contradiction whose exact local
  repair can change the path. The owner and witness are this same Step.

BINDING VETOES

Use type `none` for `clear`, `reasonable_probe`, `normal_failure`, and
`faithful_propagation`. A first or materially different acquisition probe is
reasonable when success can contribute a necessary identifier, source, page,
text, route, or lead. A tool/site error alone is normal failure. A parameter or
local defect is recovered_or_mechanical when a later valid same-subgoal action
repairs it without consuming false state. A later repetition, stronger wording,
terminal answer, persistence, or downstream reaction is faithful propagation
when repairing the earlier owner can avert it. Productive specialized-resource
changes are not same-family repetition. Do not infer capability or source
limits from entity names, domain expectations, or final-answer hindsight.

FULL-TIMELINE FREEZE

After all rows are closed, mark at most ONE `critical_candidate`. It must own
literal task-material error, a still-unresolved condition, a closed maturity
witness, and a repair that can change the path. Compare it with every earlier
probe/mechanical defect and later symptom. Freeze the benchmark-style matured
critical boundary, not automatically the earliest local defect or latest
salient symptom. If no row closes or ownership is ambiguous, freeze none.

Begin search_summary exactly with every Step tuple in order:

`typed_step_census=1:<verdict>:<boundary_type>:<none|witness_step>,2:<verdict>:<boundary_type>:<none|witness_step>,...; census_candidate_step=<none|Step>; census_direction=<none|earlier|same|later>; `

The certificate must enumerate every observable Step exactly once and no extra
Step. Exactly one row is `critical_candidate` when candidate_step is a Step;
zero rows use it when candidate_step is none. state_truth and alignment bind
witness_step to their own Step. post_feedback_maturity binds it to a strictly
earlier Step. Direction is relative to the frozen anchor.

ANCHOR COMPARISON AND OUTPUT

- No candidate or candidate equal to anchor: emit no_challenge.
- Earlier candidate: challenge only when the anchor is a downstream symptom
  and anchor-only repair cannot remove the earlier defect.
- Later candidate: challenge only when the anchor is a reasonable probe or
  noncritical predecessor and the candidate survives anchor-only repair.
- If a distinct candidate loses this comparison, emit no_challenge but retain
  its tuple and direction in the certificate.

A proposal must exactly use the one frozen candidate and literal evidence owned
by its Step/module. Use separate anchor-only and proposal-only interventions.
direct_timeline_comparison must cover the anchor, candidate, and every
intervening plausible boundary. The independent arbiter may copy only the
anchor or proposal, defaults to anchor under uncertainty, and must reject a
candidate whose tuple, witness, veto, or counterfactual is unsupported. Never
invent a pool or third prediction.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_40_VERSION,
        )
        .replace(
            transport.AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_40_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_40_clean_v3p20_complete_typed_boundary_census_challenger",
        )
        .replace(
            "agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger",
            "agent_judge_luna_gaia_v3_40_clean_v3p20_complete_typed_boundary_census_challenger",
        )
    )


def _rewrite_mechanism(task: str) -> str:
    if task.count(transport._BOUNDED_BIDIRECTIONAL_RULES) != 1:
        raise RuntimeError("bounded challenger-rule marker changed unexpectedly")
    return task.replace(
        transport._BOUNDED_BIDIRECTIONAL_RULES,
        _COMPLETE_TYPED_BOUNDARY_CENSUS_RULES,
        1,
    ).replace(
        '"which direction was searched and why one proposal exists or none qualifies"',
        '"typed_step_census=1:clear:none:none,...; '
        'census_candidate_step=none; census_direction=none; complete typed census"',
    )


def build_anchor_task(*paths: str | Path) -> str:
    """Use exactly the v3.20 anchor semantics, with only identity retagged."""

    return _rewrite_identity(parent.build_anchor_task(*paths))


def build_challenger_task(*paths: str | Path) -> str:
    return _rewrite_identity(_rewrite_mechanism(transport.build_challenger_task(*paths)))


def _validate_census_records(path: str | Path, cases: Sequence[Any]) -> dict[str, Any]:
    challenger_path, raw = shared._load_artifact(
        path, role="complete typed-boundary census"
    )
    records = raw if isinstance(raw, list) else [raw]
    if len(records) != len(cases) or any(not isinstance(item, dict) for item in records):
        shared._fail("invalid_typed_census_record_count", "case/record count differs")

    verdict_counts: Counter[str] = Counter()
    boundary_counts: Counter[str] = Counter()
    direction_counts: Counter[str] = Counter()
    candidate_count = 0
    challenge_count = 0
    for index, (record, case) in enumerate(zip(records, cases, strict=True)):
        location = f"typed_census[{index}]"
        match = _CENSUS_PREFIX.match(str(record.get("search_summary") or ""))
        if match is None:
            shared._fail("missing_complete_typed_census_prefix", location)
        census_text, candidate_text, direction = match.groups()
        entries: list[tuple[int, str, str, int | None]] = []
        for entry_text in census_text.split(","):
            entry_match = _CENSUS_ENTRY.match(entry_text)
            if entry_match is None:
                shared._fail("invalid_typed_census_entry", f"{location}:{entry_text}")
            step_text, verdict, boundary, witness_text = entry_match.groups()
            step = int(step_text)
            witness = None if witness_text == "none" else int(witness_text)
            if verdict not in _CENSUS_VERDICTS:
                shared._fail("invalid_typed_census_verdict", f"{location}:{verdict}")
            if boundary not in _BOUNDARY_TYPES:
                shared._fail("invalid_typed_census_boundary", f"{location}:{boundary}")
            if boundary == "none" and witness is not None:
                shared._fail("untyped_census_row_has_witness", f"{location}:{step}")
            if boundary != "none" and witness is None:
                shared._fail("typed_census_row_lacks_witness", f"{location}:{step}")
            if verdict in _UNTYPED_VERDICTS and boundary != "none":
                shared._fail("vetoed_census_row_is_typed", f"{location}:{step}")
            if verdict == "critical_candidate" and boundary == "none":
                shared._fail("critical_census_row_is_untyped", f"{location}:{step}")
            if boundary in {"state_truth", "alignment"} and witness != step:
                shared._fail("same_step_census_witness_mismatch", f"{location}:{step}")
            if boundary == "post_feedback_maturity" and (
                witness is None or witness >= step
            ):
                shared._fail("post_feedback_census_witness_not_prior", f"{location}:{step}")
            entries.append((step, verdict, boundary, witness))
            verdict_counts[verdict] += 1
            boundary_counts[boundary] += 1

        expected_steps = [step.step for step in case.judge_view.steps]
        if [step for step, _, _, _ in entries] != expected_steps:
            shared._fail("typed_census_step_list_mismatch", location)

        critical_steps = [
            step for step, verdict, _, _ in entries if verdict == "critical_candidate"
        ]
        candidate_step = None if candidate_text == "none" else int(candidate_text)
        if candidate_step is None:
            if critical_steps or direction != "none":
                shared._fail("invalid_empty_typed_census_candidate", location)
        else:
            if critical_steps != [candidate_step]:
                shared._fail("typed_census_candidate_binding_mismatch", location)
            anchor_step = record.get("anchor_step")
            expected_direction = (
                "earlier"
                if candidate_step < anchor_step
                else "later"
                if candidate_step > anchor_step
                else "same"
            )
            if direction != expected_direction:
                shared._fail("typed_census_candidate_direction_mismatch", location)
            candidate_count += 1

        if record.get("challenge_status") == "challenge":
            proposal = record.get("proposed_prediction")
            if (
                candidate_step is None
                or direction not in {"earlier", "later"}
                or not isinstance(proposal, dict)
                or proposal.get("predicted_step") != candidate_step
            ):
                shared._fail("proposal_differs_from_typed_census_candidate", location)
            challenge_count += 1
        direction_counts[direction] += 1

    return {
        "required": True,
        "valid": True,
        "path": str(challenger_path),
        "record_count": len(records),
        "exact_complete_step_enumeration": True,
        "mutually_exclusive_boundary_type": True,
        "maturity_witness_binding": True,
        "one_candidate_maximum": True,
        "candidate_count": candidate_count,
        "challenge_count": challenge_count,
        "verdict_counts": dict(sorted(verdict_counts.items())),
        "boundary_counts": dict(sorted(boundary_counts.items())),
        "direction_counts": dict(sorted(direction_counts.items())),
    }


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_40_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_40_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_40_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one complete typed-boundary census challenger/adjudication contract",
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths), policy="unchanged_v3_20_anchor")


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    audit = _retag(
        transport.validate_challenger(*paths),
        policy="complete_typed_boundary_census_bidirectional_challenger",
    )
    _, _, case = shared._single_case_paths(paths[0], paths[1])
    audit["schema_version"] = "agentdebug.complete-typed-census-challenger-audit.v1"
    audit["complete_typed_boundary_census"] = _validate_census_records(
        paths[5], [case]
    )
    return audit


def build_arbiter_task(*paths: str | Path) -> str:
    validate_challenger(*paths[:6])
    return _rewrite_identity(_rewrite_mechanism(transport.build_arbiter_task(*paths)))


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    audit = _retag(
        transport.validate_arbiter(*paths),
        policy="default_keep_typed_census_exact_copy_arbiter",
    )
    _, _, case = shared._single_case_paths(paths[0], paths[1])
    audit["schema_version"] = "agentdebug.complete-typed-census-arbiter-audit.v1"
    audit["complete_typed_boundary_census"] = _validate_census_records(
        paths[5], [case]
    )
    return audit


def build_agent_judge_luna_gaia_v3_40_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def validate_agent_judge_luna_gaia_v3_40_predictions(
    *paths: str | Path,
) -> dict[str, Any]:
    audit = _retag(
        transport.validate_agent_judge_luna_gaia_v3_16_predictions(*paths),
        policy=(
            "clean_v3_20_anchor_complete_typed_boundary_census_one_"
            "bidirectional_proposal_default_keep_exact_copy_arbiter"
        ),
    )
    _, _, cases = shared._load_cases(paths[0], paths[1])
    predictions = Path(paths[2]).expanduser().resolve()
    audit["schema_version"] = AGENT_JUDGE_LUNA_GAIA_V3_40_AUDIT_SCHEMA_VERSION
    audit["anchor_semantics_unchanged_from_v3_20"] = True
    audit["packet_state_closure"] = parent._validate_packet_state_ledgers(
        predictions.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME
    )
    audit["complete_typed_boundary_census"] = _validate_census_records(
        predictions.parent / CHALLENGERS_FILENAME,
        cases,
    )
    return audit


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_40_audit(
    *paths: str | Path,
) -> dict[str, Any]:
    return _write(validate_agent_judge_luna_gaia_v3_40_predictions(*paths[:-1]), paths[-1])


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_40_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_40_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_40_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_40_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    args = parser.parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

"""Faithful official-style joint Phase-2 critical-error analyzer for GAIA."""

from __future__ import annotations

import json
import shlex
from pathlib import Path
from typing import Any, Mapping, Sequence

from agentdebug.benchmark.prediction_manifest import load_prediction_manifest

from .agent_judge import (
    GOLD_ISOLATION_READ_DENYLIST,
    _assert_gold_free,
    _assert_safe_path,
    _file_sha256,
    _load_json,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_sol_gaia_forced_census import (
    SPECIALIST_MODULES,
    VERSION as PHASE1_VERSION,
    _write_audit,
    _write_json,
    segmented_owner_sources,
    validate_specialist_census,
)
from .taxonomy import AgentModule, TAXONOMY


VERSION = "agentdebug.codex-agent-judge.gaia-official-phase2-v1"
MODEL = "gpt-5.5"
REASONING_EFFORT = "xhigh"
PHASE1_SUMMARY_FILENAME = "phase1-analysis.json"


def _cohort_ids(path: Path) -> list[str]:
    value = _load_json(path, role="cohort manifest")
    ids = value.get("trajectory_ids") if isinstance(value, Mapping) else None
    if not isinstance(ids, list) or any(not isinstance(x, str) for x in ids):
        raise ValueError("invalid cohort trajectory_ids")
    return ids


def _feedback(step: Any) -> str:
    values = [item.incremental_text for item in step.adjacent_feedback]
    return "\n".join(value for value in values if value.strip())


def _phase1_projection(
    loaded: Sequence[list[Mapping[str, Any]]], cases: list[Any]
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for case_index, case in enumerate(cases):
        steps: list[dict[str, Any]] = []
        for step_number, step in enumerate(case.judge_view.steps, 1):
            errors: dict[str, dict[str, Any]] = {}
            for module, rows in zip(SPECIALIST_MODULES, loaded, strict=True):
                review = rows[case_index]["reviews"][step_number - 1]
                detected = review["verdict"] == "error"
                errors[module.value] = {
                    "error_detected": detected,
                    "error_type": review["error_type"] if detected else "no_error",
                    "evidence": review["evidence_quote"] if detected else None,
                    "reasoning": review["local_analysis"],
                    "causal_relevance": (
                        review["causal_relevance"] if detected else None
                    ),
                    "recovery": review["recovery"] if detected else None,
                }
            steps.append(
                {
                    "step": step_number,
                    "agent_output": step.assistant_raw_output,
                    "environment_response": _feedback(step),
                    "errors": errors,
                }
            )
        result.append(
            {
                "trajectory_id": case.trajectory_id,
                "trajectory_sha256": case.trajectory_sha256,
                "status": "success",
                "phase1_protocol": PHASE1_VERSION,
                "steps": steps,
            }
        )
    return result


def validate_phase1_summary(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    census_paths: Sequence[str | Path],
    summary_path: str | Path,
) -> dict[str, Any]:
    if len(census_paths) != len(SPECIALIST_MODULES):
        raise ValueError("exactly five phase1 census paths are required")
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    summary = Path(summary_path).expanduser().resolve()
    _, cases = load_prediction_manifest(prediction)
    if _cohort_ids(cohort) != [case.trajectory_id for case in cases]:
        raise ValueError("manifest/cohort order differs")
    loaded: list[list[Mapping[str, Any]]] = []
    source_hashes: dict[str, str] = {}
    for module, raw in zip(SPECIALIST_MODULES, census_paths, strict=True):
        path = Path(raw).expanduser().resolve()
        validate_specialist_census(prediction, cohort, path, module)
        loaded.append(_load_json(path, role=f"{module.value} phase1 census"))
        source_hashes[module.value] = _file_sha256(path)
    value = _load_json(summary, role="phase1 analysis")
    _assert_gold_free(value, location="phase1 analysis")
    if value != _phase1_projection(loaded, cases):
        raise ValueError("phase1 analysis is not the exact deterministic projection")
    return {
        "agent_judge_version": VERSION,
        "stage": "official-style-phase1-projection",
        "gold_free_validation": True,
        "case_count": len(cases),
        "all_agent_outputs_complete": True,
        "all_following_feedback_complete": True,
        "all_module_type_labels_preserved": True,
        "source_sha256": source_hashes,
        "output_sha256": {summary.name: _file_sha256(summary)},
    }


def write_phase1_summary(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    census_paths: Sequence[str | Path],
    summary_path: str | Path,
) -> dict[str, Any]:
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    loaded: list[list[Mapping[str, Any]]] = []
    for module, raw in zip(SPECIALIST_MODULES, census_paths, strict=True):
        path = Path(raw).expanduser().resolve()
        validate_specialist_census(
            prediction, cohort_manifest_path, path, module
        )
        loaded.append(_load_json(path, role=f"{module.value} phase1 census"))
    _, cases = load_prediction_manifest(prediction)
    output = Path(summary_path).expanduser().resolve()
    _write_json(output, _phase1_projection(loaded, cases))
    return validate_phase1_summary(
        prediction, cohort_manifest_path, census_paths, output
    )


def validate_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    base = _validate_agent_judge_predictions_with_owner_sources(
        Path(prediction_manifest_path).expanduser().resolve(),
        Path(cohort_manifest_path).expanduser().resolve(),
        Path(predictions_path).expanduser().resolve(),
        owner_source_resolver=segmented_owner_sources,
    )
    return {
        **base,
        "agent_judge_version": VERSION,
        "model": MODEL,
        "reasoning_effort": REASONING_EFFORT,
        "stage": "official-style-joint-phase2",
        "joint_step_module_type_decision": True,
        "phase1_candidate_bound": False,
        "prior_final_prediction_visible": False,
        "segmented_nested_owner_sources": True,
    }


def validate_and_write_prediction_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        audit_path,
        validate_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
    )


def _validator_command(function: str, *arguments: Path) -> str:
    rendered = ", ".join(repr(str(item)) for item in arguments)
    code = (
        "import json; from agentdebug.diagnostics."
        "agent_judge_gaia_official_phase2 import "
        f"{function} as run; print(json.dumps(run({rendered}), "
        "ensure_ascii=False, indent=2))"
    )
    return "PYTHONPATH=. python3 -c " + shlex.quote(code)


def _taxonomy_text() -> str:
    lines: list[str] = []
    for module in AgentModule:
        lines.append(f"{module.value.upper()} ERROR TYPES")
        for error_type, definition in TAXONOMY[module].items():
            lines.append(f"- {error_type.value}: {definition}")
    return "\n".join(lines)


def build_phase2_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    output = Path(predictions_path).expanduser().resolve()
    summary = output.parent / PHASE1_SUMMARY_FILENAME
    audit = output.parent / "prediction-audit.json"
    for role, path, is_output in (
        ("prediction manifest", prediction, False),
        ("cohort manifest", cohort, False),
        ("phase1 analysis", summary, False),
        ("predictions", output, True),
    ):
        _assert_safe_path(path, role=role, is_output=is_output)
    _, cases = load_prediction_manifest(prediction)
    if len(cases) != 1:
        raise ValueError("joint Phase2 requires exactly one trajectory")
    schema = {
        "trajectory_id": "exact opaque manifest ID",
        "trajectory_sha256": "exact manifest hash",
        "status": "success",
        "predicted_step": "any integer 1..N",
        "predicted_module": "memory|reflection|planning|action|system",
        "predicted_error_type": "legal type for selected module",
        "evidence_quote": "exact selected-owner source substring",
        "root_cause": "why this error caused failure",
        "causal_summary": "counterfactual and cascading effects",
        "rejected_adjacent_owner": "strongest alternative and why it loses",
    }
    command = _validator_command(
        "validate_and_write_prediction_audit",
        prediction, cohort, output, audit,
    )
    deny = "\n".join(f"- {item}" for item in GOLD_ISOLATION_READ_DENYLIST)
    return f"""Run {VERSION}, the official-style JOINT PHASE-2 critical-error analyzer.

IMMUTABLE CONFIG: model={MODEL}; reasoning_effort={REASONING_EFFORT}; one fresh isolated trajectory; network/API/gold/labels/scores/prior final predictions forbidden.

Read only:
- prediction manifest: {prediction}
- cohort manifest: {cohort}
- complete frozen Phase-1 analysis: {summary}
- this protocol source and taxonomy.py

The Phase-1 file contains, for EVERY step, the complete Agent Output, the
following incremental Environment Response, and all five module reviews with
error type, evidence, reasoning, causal relevance, and recovery. It was frozen
before gold access. Phase-1 findings are diagnostic suggestions, not votes and
not a candidate restriction. You may select any step 1..N and any legal pair,
including a defect Phase 1 missed or classified differently.

Your job is to identify the CRITICAL ERROR: the earliest and most important
error that led to task failure.

CRITICAL ERROR IDENTIFICATION APPROACH
1. Take a holistic, global perspective: understand the task goal and how the
   complete path diverged from success.
2. Find the earliest point where a concrete decision or error set the agent on
   the material failed branch. Early exploration (especially steps 1-3) is
   often normal, but it can be critical when a clear fundamental error exists.
3. A critical error is a root cause, caused cascading effects, and has this
   counterfactual: correcting this specific error would fundamentally redirect
   the trajectory toward success.
4. Trace backward from the final failure. Do not select the latest vivid
   symptom merely because it independently prevented the released answer.
5. Do not select a weak early imperfection merely because it came first. The
   chosen boundary must be demonstrably material in the full output/feedback
   chain.
6. Step 1 cannot be Memory or Reflection because no prior action exists.
7. System is valid only for a provenance-backed independent execution failure;
   a normal unsuccessful episode is not System.
8. Decide Step, Module, and Type JOINTLY. Preserve information-flow ownership:
   false recalled state -> Memory; false feedback/progress interpretation ->
   Reflection; new defective strategy from otherwise sound state -> Planning;
   deviation/mechanical emission from an adequate plan -> Action.

COMPLETE TAXONOMY
{_taxonomy_text()}

EVIDENCE CONTRACT
evidence_quote must be a literal contiguous substring owned by the selected
step/module. Planning may quote its segmented deliberative residual; nested
Action text is excluded. Action may quote its tag/tool name/string arguments.
System may quote only a validator-recognized execution fact at the final step.

GOLD-ISOLATION READ DENYLIST
{deny}

Write exactly one JSON array with one ten-field record to {output}:
{json.dumps(schema, ensure_ascii=False, indent=2)}

Then run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Fix only this artifact until validation exits zero and writes {audit}.
"""


def build_protocol_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    return build_phase2_task(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )


__all__ = [
    "MODEL", "PHASE1_SUMMARY_FILENAME", "REASONING_EFFORT", "VERSION",
    "build_phase2_task", "build_protocol_task", "validate_phase1_summary",
    "validate_predictions", "write_phase1_summary",
]

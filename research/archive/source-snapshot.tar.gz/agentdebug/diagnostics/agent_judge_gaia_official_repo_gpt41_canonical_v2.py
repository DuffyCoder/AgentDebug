"""Validation policy for the canonical-input public-repository GPT-4.1 judge."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge import _validate_agent_judge_predictions_with_owner_sources
from .agent_judge_sol_gaia_forced_census import segmented_owner_sources
from .judge_view import JudgeObservation, JudgeView
from .taxonomy import AgentModule, ErrorType


VERSION = "agentdebug.llm-judge.gaia-official-repo-gpt4.1-canonical-v2"
MODEL = "gpt-4.1"
TEMPERATURE = 0.0
REASONING_EFFORT = "not_applicable"


def observation_text(observation: JudgeObservation) -> str:
    """Return the actual current observation from a cumulative GAIA prompt."""

    projection = observation.benchmark_input
    if projection is not None:
        return observation.text[
            projection.observation_start_char : projection.observation_end_char
        ].strip()
    return observation.incremental_text.strip()


def canonical_owner_sources(
    view: JudgeView,
    predicted_step: int,
    module: AgentModule,
    error_type: ErrorType,
) -> tuple[str, ...]:
    """Resolve owner evidence, including step-local observable system output."""

    if module != AgentModule.SYSTEM:
        return segmented_owner_sources(view, predicted_step, module, error_type)
    step = view.steps[predicted_step - 1]
    sources: list[str] = []
    for feedback in step.adjacent_feedback:
        text = observation_text(feedback)
        if text:
            sources.append(text)
    for call in step.tool_calls:
        for result in call.results:
            if result.output.strip():
                sources.append(result.output)
    if step.error_message and step.error_message.strip():
        sources.append(step.error_message)
    if step.stop_reason and step.stop_reason.strip():
        sources.append(step.stop_reason)
    action_spans = [span for span in step.module_spans if span.module == "action"]
    if len(step.assistant_raw_output) >= 20_000 and len(action_spans) > 1:
        sources.append(step.assistant_raw_output)
    return tuple(dict.fromkeys(sources))


def build_protocol_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    return f"""Canonical-input GAIA diagnostic judge.

Protocol: {VERSION}
Model: {MODEL}
Temperature: {TEMPERATURE}
Prediction manifest: {Path(prediction_manifest_path).expanduser().resolve()}
Cohort manifest: {Path(cohort_manifest_path).expanduser().resolve()}
Predictions: {Path(predictions_path).expanduser().resolve()}

The public repository prompts and two-stage decision topology are retained.
Before Phase 1, the gold-free canonical JudgeView maps observable module spans,
including GAIA <think> as planning, extracts the actual current observation,
omits structurally absent modules, and preserves step-local system failures.
"""


def validate_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    base = _validate_agent_judge_predictions_with_owner_sources(
        Path(prediction_manifest_path).expanduser().resolve(),
        Path(cohort_manifest_path).expanduser().resolve(),
        Path(predictions_path).expanduser().resolve(),
        owner_source_resolver=canonical_owner_sources,
    )
    return {
        **base,
        "agent_judge_version": VERSION,
        "model": MODEL,
        "reasoning_effort": REASONING_EFFORT,
        "temperature": TEMPERATURE,
        "stage": "canonical-input-official-repository-phase1-then-joint-phase2",
        "canonical_module_spans": True,
        "gaia_think_maps_to_planning": True,
        "absent_modules_are_not_applicable": True,
        "step_local_system_evidence": True,
        "external_llm_api": True,
    }


build_task = build_protocol_task

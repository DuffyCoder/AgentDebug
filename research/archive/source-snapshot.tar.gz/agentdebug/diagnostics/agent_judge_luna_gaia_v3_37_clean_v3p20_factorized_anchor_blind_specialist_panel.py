"""Luna GAIA v3.37: clean v3.20 with a factorized anchor-blind specialist panel."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from .agent_judge_luna_gaia_v2_1 import (
    validate_agent_judge_luna_gaia_v2_1_predictions,
)
from .taxonomy import taxonomy_prompt


AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.37-clean-v3.20-"
    "factorized-anchor-blind-specialist-panel"
)
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_37_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_37_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
PANEL_FILENAME = "factorized-specialist-panel.json"
PANELS_FILENAME = "factorized-specialist-panels.json"
PANEL_AUDIT_FILENAME = "factorized-specialist-panel-audit.json"
SELECTOR_FILENAME = "factorized-selector.json"
SELECTORS_FILENAME = "factorized-selectors.json"
SELECTOR_AUDIT_FILENAME = "factorized-selector-audit.json"

PANEL_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "state_status",
    "state_step",
    "state_prediction",
    "state_search_summary",
    "state_falsifier",
    "strategy_status",
    "strategy_step",
    "strategy_prediction",
    "strategy_search_summary",
    "strategy_falsifier",
    "cross_lane_comparison",
)
PANEL_STATUSES = frozenset({"candidate", "none"})
SELECTOR_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "anchor_prediction_sha256",
    "anchor_ledger_sha256",
    "anchor_checkpoint_sha256",
    "panel_sha256",
    "anchor_step",
    "state_step",
    "strategy_step",
    "decision",
    "frozen_step",
    "selected_prediction_sha256",
    "selected_prediction",
    "anchor_assessment",
    "state_assessment",
    "strategy_assessment",
    "decision_basis",
    "rejected_alternative_basis",
)
SELECTOR_DECISIONS = frozenset({"keep_anchor", "select_state", "select_strategy"})


_PANEL_RULES = """\
FACTORIZED ANCHOR-BLIND SPECIALIST PANEL — TWO MUTUALLY EXCLUSIVE LANES

The incumbent anchor is intentionally unavailable. Do not search for it,
infer it, or choose a candidate relative to it. Inspect every Canonical Step in
chronological order. The lanes are independent and each may emit at most ONE
complete legal prediction or `none`. They must not nominate the same Step.

STATE_HANDOFF LANE

Use only literal packet/history evidence. Freeze the earliest task-material
Agent-owned boundary satisfying one of these:

- adjacent result/history contains a concrete fact, value, entity relation, or
  provenance link necessary for the unresolved subgoal or next decision, but
  Memory/Reflection drops or materially distorts it;
- Memory/Reflection retains a new task-material fact unsupported by visible
  observations and that fact feeds the current or next decision;
- Memory/Reflection makes a success, failure, progress, or constraint claim
  literally contradicted by adjacent feedback;
- an immediate concrete target/predicate is lost or contradicted between the
  plan and Action.

Reject harmless compression, facts still visible to the next decision,
unconsumed speculation, normal tool failure, recovered/local defects, style,
and downstream restatements. Require a candidate-only local repair that can
change the retained state, next action, or answer. If none qualifies, emit
state_status `none`.

STRATEGY_CAPABILITY LANE

Use only Agent-owned plan/Action commitments. Freeze the earliest task-material
boundary satisfying one of these:

- the selected interface/route intrinsically cannot expose the immediate
  required content or state, and visible returned content lacks it;
- an explicit user/source/constraint requirement is contradicted by the
  chosen target, corpus, interface, or Action;
- literal prior feedback has failed or ruled out a normalized target, corpus,
  interface, and extraction route, then the Agent recommits without a material
  change.

The raw failure result never owns the candidate. A first or materially
different route that can contribute a needed identifier, source, page, text,
or lead is a reasonable probe. Successful transport alone does not prove that
the route can expose the immediate predicate. Repetition maturity is
prefix-closed: test the earlier repeated commitment before a later recurrence.
Reject recovered/mechanical defects, faithful propagation, merely local
inefficiency, and terminal symptoms. If none qualifies, emit strategy_status
`none`.

For each candidate search_summary begin exactly:
- `lane=state_handoff; candidate_step=<none|Step>; `
- `lane=strategy_capability; candidate_step=<none|Step>; `

Each summary must certify chronological coverage, literal ownership, the
unresolved immediate predicate, and why no earlier lane candidate survives.
Each falsifier must state the strongest concrete reason the candidate might be
only local/noncritical. cross_lane_comparison must explain lane separation and
chronology without selecting a winner. Never access gold, old predictions, or
case-level reports.
"""


_SELECTOR_RULES = """\
BOUNDED EXACT-COPY SELECTOR — CLEAN ANCHOR PLUS TWO SPECIALISTS

The three inputs are immutable. Select exactly one existing complete
prediction: the clean v3.20 anchor, the state_handoff candidate if present, or
the strategy_capability candidate if present. Never invent, repair, merge, or
splice a prediction. Candidate absence is binding. Uncertainty keeps anchor.

Reconstruct literal chronology around every available Step:

1. Select the state candidate only when its concrete necessary-fact loss,
   unsupported retained fact, false outcome reading, or target-to-Action loss
   feeds the later path; anchor-only repair cannot restore that earlier state.
2. Select the strategy candidate only when it is the first mature Agent-owned
   incapability, explicit constraint mismatch, or post-feedback unchanged
   recommitment, while the anchor is a reasonable probe, noncritical
   predecessor, faithful propagation, or downstream symptom.
3. Protect the anchor when it owns a direct unrecovered execution impact,
   explicit critical constraint, literal task-material state contradiction, or
   causal root whose repair can avert the specialist symptom.
4. Reject harmless state compression, unconsumed speculation, initial or
   materially different probes, raw normal failures, recovery, mechanical
   defects, and downstream symptoms.
5. Do not prefer earlier/later position, Planning ownership, stronger wording,
   severity, persistence, or specialist provenance by itself.

selected_prediction must be a field-for-field exact copy of the chosen input.
Assess every present alternative and state why the rejected candidate is not
the benchmark's critical boundary.
"""


def _rewrite_identity(task: str) -> str:
    return task.replace(
        parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION,
    ).replace(
        "agent_judge_luna_gaia_v3_20_packet_state_closure",
        "agent_judge_luna_gaia_v3_37_clean_v3p20_factorized_anchor_blind_specialist_panel",
    )


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_anchor_task(*paths))


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    audit = dict(parent.validate_anchor_predictions(*paths))
    audit["agent_judge_version"] = AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION
    audit["model"] = AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL
    audit["reasoning_effort"] = AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT
    return audit


def _boundary(
    *, manifest: Path, cohort: Path, reads: Sequence[Path], output: Path
) -> str:
    read_lines = "\n".join(f"- {path}" for path in reads) or "- none"
    return f"""\
IMMUTABLE EXECUTION CONFIGURATION
- model: {AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT}
- one isolated case; fresh session; no cross-case state or prior predictions
- external LLM/API/network calls: forbidden
- scoring or gold-label access: forbidden

INPUT/OUTPUT BOUNDARY
- prediction manifest: {manifest}
- prediction manifest file sha256: {shared._file_sha256(manifest)}
- cohort manifest: {cohort}
- cohort manifest file sha256: {shared._file_sha256(cohort)}
- permitted frozen stage inputs:
{read_lines}
- write the sole stage artifact only to: {output}

Read only those exact inputs plus this v3.37 protocol source, the v3.20
protocol source, and `agentdebug/diagnostics/taxonomy.py`. Do not inspect
directories or infer from trajectory/source-model/environment names. Never
read labels, metrics, scored artifacts, promotion files, experiment documents,
old predictions, cached replies, case studies, git history, or external resources.
"""


def _validate_panel_record(raw: Any, *, case: Any, location: str) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != PANEL_FIELDS:
        shared._fail("invalid_factorized_panel_schema", f"{location} fields/order differ")
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
    ):
        shared._fail("factorized_panel_identity_mismatch", location)
    candidate_steps: list[int] = []
    for lane in ("state", "strategy"):
        status = raw[f"{lane}_status"]
        step = raw[f"{lane}_step"]
        prediction = raw[f"{lane}_prediction"]
        summary = raw[f"{lane}_search_summary"]
        falsifier = raw[f"{lane}_falsifier"]
        if status not in PANEL_STATUSES:
            shared._fail("invalid_factorized_lane_status", f"{location}.{lane}")
        expected_prefix = (
            "lane=state_handoff; " if lane == "state" else "lane=strategy_capability; "
        ) + f"candidate_step={step if status == 'candidate' else 'none'}; "
        if not isinstance(summary, str) or not summary.startswith(expected_prefix):
            shared._fail("invalid_factorized_lane_summary", f"{location}.{lane}")
        shared._nonempty_text(falsifier, location=f"{location}.{lane}_falsifier", maximum=2400)
        if status == "none":
            if step is not None or prediction is not None:
                shared._fail("nonempty_factorized_none_lane", f"{location}.{lane}")
        else:
            if isinstance(step, bool) or not isinstance(step, int):
                shared._fail("invalid_factorized_candidate_step", f"{location}.{lane}")
            validated = shared._validate_prediction_record(
                prediction, case=case, location=f"{location}.{lane}_prediction"
            )
            if validated["predicted_step"] != step:
                shared._fail("factorized_candidate_step_mismatch", f"{location}.{lane}")
            candidate_steps.append(step)
    if len(candidate_steps) != len(set(candidate_steps)):
        shared._fail("factorized_lanes_overlap", location)
    shared._nonempty_text(
        raw["cross_lane_comparison"],
        location=f"{location}.cross_lane_comparison",
        maximum=2400,
    )
    return raw


def validate_panel(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    panel_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    panel_file, raw = shared._load_artifact(panel_path, role="factorized panel")
    record = shared._one_record(raw, role="factorized panel")
    _validate_panel_record(record, case=case, location="factorized_panel[0]")
    return {
        "schema_version": "agentdebug.factorized-specialist-panel-audit.v1",
        "stage": "factorized_anchor_blind_panel",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": 1,
        "anchor_visible": False,
        "state_status": record["state_status"],
        "strategy_status": record["strategy_status"],
        "maximum_candidates": 2,
        "lanes_mutually_exclusive": True,
        "input_sha256": {
            "prediction_manifest": shared._file_sha256(manifest),
            "cohort": shared._file_sha256(cohort),
        },
        "output_sha256": {PANEL_FILENAME: shared._file_sha256(panel_file)},
    }


def build_panel_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    panel_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    output = Path(panel_path).expanduser().resolve()
    shared._assert_safe_path(output, role="factorized panel output", is_output=True)
    audit = output.parent / PANEL_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_37_clean_v3p20_factorized_anchor_blind_specialist_panel",
            "--compact-validate",
            "panel",
            manifest,
            cohort,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "state_status": "candidate or none",
        "state_step": "integer Step or null",
        "state_prediction": "complete legal prediction object or null",
        "state_search_summary": "lane=state_handoff; candidate_step=<none|Step>; certificate",
        "state_falsifier": "strongest literal counterargument or why none qualifies",
        "strategy_status": "candidate or none",
        "strategy_step": "integer Step or null",
        "strategy_prediction": "complete legal prediction object or null",
        "strategy_search_summary": "lane=strategy_capability; candidate_step=<none|Step>; certificate",
        "strategy_falsifier": "strongest literal counterargument or why none qualifies",
        "cross_lane_comparison": "lane separation and chronology without winner selection",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION} stage 2/3: anchor-blind specialist panel.

{_boundary(manifest=manifest, cohort=cohort, reads=(), output=output)}

{_PANEL_RULES}

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

Every non-null prediction must use the standard complete prediction fields in
their exact order and must quote literal evidence owned by its Step/module.
After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _load_anchor_bundle(
    manifest: Path,
    cohort: Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> tuple[Path, Path, Path, dict[str, Any], dict[str, Any], dict[str, Any]]:
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    anchor, ledger, checkpoint = shared._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    parent._validate_packet_state_ledgers(ledger_file)
    return anchor_file, ledger_file, checkpoint_file, anchor, ledger, checkpoint


def _validate_selector_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    panel: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != SELECTOR_FIELDS:
        shared._fail("invalid_factorized_selector_schema", f"{location} fields/order differ")
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
    ):
        shared._fail("factorized_selector_identity_mismatch", location)
    bindings = {
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "panel_sha256": shared._stable_sha256(panel),
    }
    if any(raw[key] != value for key, value in bindings.items()):
        shared._fail("factorized_selector_hash_mismatch", location)
    if raw["anchor_step"] != anchor["predicted_step"]:
        shared._fail("factorized_selector_anchor_step_mismatch", location)
    if raw["state_step"] != panel["state_step"] or raw["strategy_step"] != panel["strategy_step"]:
        shared._fail("factorized_selector_candidate_step_mismatch", location)
    decision = raw["decision"]
    if decision not in SELECTOR_DECISIONS:
        shared._fail("invalid_factorized_selector_decision", location)
    options = {
        "keep_anchor": anchor,
        "select_state": panel["state_prediction"],
        "select_strategy": panel["strategy_prediction"],
    }
    expected = options[decision]
    if expected is None:
        shared._fail("factorized_selector_selected_absent_candidate", location)
    selected = shared._validate_prediction_record(
        raw["selected_prediction"], case=case, location=f"{location}.selected"
    )
    if selected != expected:
        shared._fail("factorized_selector_prediction_copy_mismatch", location)
    if raw["selected_prediction_sha256"] != shared._stable_sha256(selected):
        shared._fail("factorized_selector_selected_hash_mismatch", location)
    if raw["frozen_step"] != selected["predicted_step"]:
        shared._fail("factorized_selector_frozen_step_mismatch", location)
    for field in (
        "anchor_assessment",
        "state_assessment",
        "strategy_assessment",
        "decision_basis",
        "rejected_alternative_basis",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=2600)
    return raw


def validate_selector(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    panel_path: str | Path,
    selector_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger, checkpoint = bundle[3:]
    panel_file, panel_raw = shared._load_artifact(panel_path, role="factorized panel")
    panel = shared._one_record(panel_raw, role="factorized panel")
    _validate_panel_record(panel, case=case, location="factorized_panel[0]")
    selector_file, selector_raw = shared._load_artifact(
        selector_path, role="factorized selector"
    )
    selector = shared._one_record(selector_raw, role="factorized selector")
    _validate_selector_record(
        selector,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        panel=panel,
        location="factorized_selector[0]",
    )
    return {
        "schema_version": "agentdebug.factorized-selector-audit.v1",
        "stage": "factorized_exact_copy_selector",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": 1,
        "decision": selector["decision"],
        "selected_prediction_exact_copy": True,
        "candidate_count_maximum": 3,
        "input_sha256": {
            "anchor": shared._file_sha256(anchor_file),
            "ledger": shared._file_sha256(ledger_file),
            "checkpoint": shared._file_sha256(checkpoint_file),
            "panel": shared._file_sha256(panel_file),
        },
        "output_sha256": {SELECTOR_FILENAME: shared._file_sha256(selector_file)},
    }


def build_selector_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    panel_path: str | Path,
    selector_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger, checkpoint = bundle[3:]
    panel_file, panel_raw = shared._load_artifact(panel_path, role="factorized panel")
    panel = shared._one_record(panel_raw, role="factorized panel")
    _validate_panel_record(panel, case=case, location="factorized_panel[0]")
    output = Path(selector_path).expanduser().resolve()
    shared._assert_safe_path(output, role="factorized selector output", is_output=True)
    audit = output.parent / SELECTOR_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_37_clean_v3p20_factorized_anchor_blind_specialist_panel",
            "--compact-validate",
            "selector",
            manifest,
            cohort,
            anchor_file,
            ledger_file,
            checkpoint_file,
            panel_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "panel_sha256": shared._stable_sha256(panel),
        "anchor_step": anchor["predicted_step"],
        "state_step": panel["state_step"],
        "strategy_step": panel["strategy_step"],
        "decision": "keep_anchor or select_state or select_strategy",
        "frozen_step": "selected prediction Step",
        "selected_prediction_sha256": "stable JSON hash of exact selected prediction",
        "selected_prediction": "exact unchanged chosen prediction object",
        "anchor_assessment": "literal causal-boundary assessment",
        "state_assessment": "literal assessment or explicit absent-candidate note",
        "strategy_assessment": "literal assessment or explicit absent-candidate note",
        "decision_basis": "why the chosen exact boundary wins",
        "rejected_alternative_basis": "why every present alternative loses",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION} stage 3/3: bounded selector.

{_boundary(manifest=manifest, cohort=cohort, reads=(anchor_file, ledger_file, checkpoint_file, panel_file), output=output)}

{_SELECTOR_RULES}

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

Compute content hashes as stable sorted compact JSON. After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _validate_factorized_aggregate(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(prediction_manifest_path, cohort_manifest_path)
    root = Path(predictions_path).expanduser().resolve().parent
    names = (
        ANCHOR_PREDICTIONS_FILENAME,
        ANCHOR_LEDGER_AGGREGATE_FILENAME,
        ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        PANELS_FILENAME,
        SELECTORS_FILENAME,
    )
    loaded = {name: shared._load_artifact(root / name, role=f"merged {name}")[1] for name in names}
    if any(not isinstance(value, list) or len(value) != len(cases) for value in loaded.values()):
        shared._fail("invalid_factorized_aggregate_count", "all artifacts need all cases")
    finals = shared._load_artifact(predictions_path, role="merged predictions")[1]
    if not isinstance(finals, list) or len(finals) != len(cases):
        shared._fail("invalid_factorized_prediction_count", "predictions need all cases")
    state_counts: Counter[str] = Counter()
    strategy_counts: Counter[str] = Counter()
    decisions: Counter[str] = Counter()
    for index, case in enumerate(cases):
        anchor = loaded[ANCHOR_PREDICTIONS_FILENAME][index]
        ledger = loaded[ANCHOR_LEDGER_AGGREGATE_FILENAME][index]
        checkpoint = loaded[ANCHOR_CHECKPOINT_AGGREGATE_FILENAME][index]
        panel = loaded[PANELS_FILENAME][index]
        selector = loaded[SELECTORS_FILENAME][index]
        location = f"factorized_merged[{index}]"
        shared._validate_prediction_record(anchor, case=case, location=f"{location}.anchor")
        if (
            ledger.get("trajectory_id") != case.trajectory_id
            or ledger.get("selected_step") != anchor["predicted_step"]
            or checkpoint.get("trajectory_id") != case.trajectory_id
            or checkpoint.get("predicted_step") != anchor["predicted_step"]
        ):
            shared._fail("factorized_anchor_sidecar_mismatch", location)
        _validate_panel_record(panel, case=case, location=f"{location}.panel")
        _validate_selector_record(
            selector,
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            panel=panel,
            location=f"{location}.selector",
        )
        final = shared._validate_prediction_record(
            finals[index], case=case, location=f"{location}.final"
        )
        if final != selector["selected_prediction"]:
            shared._fail("factorized_final_copy_mismatch", location)
        state_counts[panel["state_status"]] += 1
        strategy_counts[panel["strategy_status"]] += 1
        decisions[selector["decision"]] += 1
    packet_state = parent._validate_packet_state_ledgers(
        root / ANCHOR_LEDGER_AGGREGATE_FILENAME
    )
    return {
        "required": True,
        "valid": True,
        "anchor_blind_panel": True,
        "maximum_specialist_candidates": 2,
        "maximum_total_predictions": 3,
        "lanes_mutually_exclusive": True,
        "all_selected_predictions_exact_copies": True,
        "state_status_counts": dict(sorted(state_counts.items())),
        "strategy_status_counts": dict(sorted(strategy_counts.items())),
        "selector_decision_counts": dict(sorted(decisions.items())),
        "packet_state_closure": packet_state,
    }


def validate_agent_judge_luna_gaia_v3_37_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    factorized = _validate_factorized_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_37_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT,
        "selection_policy": "clean_v3_20_anchor_factorized_anchor_blind_two_specialists_exact_copy_selector",
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "anchor_semantics_unchanged_from_v3_20": True,
        "all_selected_predictions_exact_copies": True,
        "factorized_specialist_panel": factorized,
    }


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_panel(*paths[:-1]), paths[-1])


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_selector(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_37_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_37_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_luna_gaia_v3_37_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_selector_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / PANEL_FILENAME,
        prediction.parent / SELECTOR_FILENAME,
    )


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_37_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_37_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_37_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "panel" and len(paths) == 4:
            audit = validate_and_write_panel_audit(*paths)
        elif stage == "selector" and len(paths) == 8:
            audit = validate_and_write_selector_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_37_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "panel", "selector", "prediction"))
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

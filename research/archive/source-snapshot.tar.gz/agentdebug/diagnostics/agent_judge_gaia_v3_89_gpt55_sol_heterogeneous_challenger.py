"""GAIA v3.89: accepted v3.83 with a heterogeneous Sol challenger.

Anchor, challenger contract, arbiter, and validators are exact v3.83 semantics.
Only the fresh challenger session's executing model changes from GPT-5.5 to
GPT-5.6 Sol; task metadata is retagged truthfully for each stage.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from . import agent_judge_gaia_v3_83_clean_v3p20_model_only_gpt55_medium as parent


AGENT_JUDGE_GAIA_V3_89_VERSION = (
    "agentdebug.codex-agent-judge.gaia-v3.89-gpt55-sol-heterogeneous-challenger"
)
AGENT_JUDGE_GAIA_V3_89_MODEL = "gpt-5.5"
AGENT_JUDGE_GAIA_V3_89_REASONING_EFFORT = "medium"
AGENT_JUDGE_GAIA_V3_89_CHALLENGER_MODEL = "gpt-5.6-sol"
AGENT_JUDGE_GAIA_V3_89_CHALLENGER_REASONING_EFFORT = "medium"
AGENT_JUDGE_GAIA_V3_89_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_GAIA_V3_83_AUDIT_SCHEMA_VERSION
)
SEMANTIC_PARENT = parent.AGENT_JUDGE_GAIA_V3_83_VERSION
STAGE_MODELS = {
    "anchor": {
        "model": AGENT_JUDGE_GAIA_V3_89_MODEL,
        "reasoning_effort": AGENT_JUDGE_GAIA_V3_89_REASONING_EFFORT,
    },
    "challenger": {
        "model": AGENT_JUDGE_GAIA_V3_89_CHALLENGER_MODEL,
        "reasoning_effort": AGENT_JUDGE_GAIA_V3_89_CHALLENGER_REASONING_EFFORT,
    },
    "arbiter": {
        "model": AGENT_JUDGE_GAIA_V3_89_MODEL,
        "reasoning_effort": AGENT_JUDGE_GAIA_V3_89_REASONING_EFFORT,
    },
}

# Compatibility names used by the shared three-stage runner.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_GAIA_V3_89_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_GAIA_V3_89_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_GAIA_V3_89_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_GAIA_V3_89_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = parent.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = parent.CHALLENGERS_FILENAME
ARBITER_FILENAME = parent.ARBITER_FILENAME
ARBITERS_FILENAME = parent.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = parent.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = parent.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME


def _retag_identity(task: str) -> str:
    marker = parent.AGENT_JUDGE_GAIA_V3_83_VERSION
    if task.count(marker) != 1:
        raise RuntimeError("v3.83 task identity marker changed unexpectedly")
    return task.replace(marker, AGENT_JUDGE_GAIA_V3_89_VERSION, 1)


def build_anchor_task(*paths: str | Path) -> str:
    return _retag_identity(parent.build_anchor_task(*paths))


def build_challenger_task(*paths: str | Path) -> str:
    task = _retag_identity(parent.build_challenger_task(*paths))
    marker = f"- model: {parent.AGENT_JUDGE_GAIA_V3_83_MODEL}"
    if task.count(marker) != 1:
        raise RuntimeError("v3.83 challenger model marker changed unexpectedly")
    return task.replace(
        marker,
        f"- model: {AGENT_JUDGE_GAIA_V3_89_CHALLENGER_MODEL}",
        1,
    )


def build_arbiter_task(*paths: str | Path) -> str:
    return _retag_identity(parent.build_arbiter_task(*paths))


def build_agent_judge_gaia_v3_89_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def _retag_audit(audit: dict[str, Any], *, stage: str) -> dict[str, Any]:
    result = dict(audit)
    result.pop("model_only_swap", None)
    stage_profile = STAGE_MODELS.get(stage, STAGE_MODELS["arbiter"])
    result.update(
        {
            "agent_judge_version": AGENT_JUDGE_GAIA_V3_89_VERSION,
            "model": stage_profile["model"],
            "reasoning_effort": stage_profile["reasoning_effort"],
            "stage": stage,
            "stage_models": STAGE_MODELS,
            "semantic_parent": SEMANTIC_PARENT,
            "direct_semantic_parent": SEMANTIC_PARENT,
            "rejected_lineage_inherited": False,
            "single_major_change": (
                "challenger executor only: gpt-5.5 to gpt-5.6-sol"
            ),
            "anchor_challenger_arbiter_contracts_unchanged_from_v3_83": True,
        }
    )
    return result


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag_audit(parent.validate_anchor_predictions(*paths), stage="anchor")


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    return _retag_audit(parent.validate_challenger(*paths), stage="challenger")


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    return _retag_audit(parent.validate_arbiter(*paths), stage="arbiter")


def validate_agent_judge_gaia_v3_89_predictions(
    *paths: str | Path,
) -> dict[str, Any]:
    return _retag_audit(
        parent.validate_agent_judge_gaia_v3_83_predictions(*paths),
        stage="final",
    )


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return parent._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_gaia_v3_89_audit(
    *paths: str | Path,
) -> dict[str, Any]:
    return _write(validate_agent_judge_gaia_v3_89_predictions(*paths[:-1]), paths[-1])


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_gaia_v3_89_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_gaia_v3_89_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_gaia_v3_89_audit
)


__all__ = [
    "AGENT_JUDGE_GAIA_V3_89_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_GAIA_V3_89_CHALLENGER_MODEL",
    "AGENT_JUDGE_GAIA_V3_89_CHALLENGER_REASONING_EFFORT",
    "AGENT_JUDGE_GAIA_V3_89_MODEL",
    "AGENT_JUDGE_GAIA_V3_89_REASONING_EFFORT",
    "AGENT_JUDGE_GAIA_V3_89_VERSION",
    "SEMANTIC_PARENT",
    "STAGE_MODELS",
    "build_agent_judge_gaia_v3_89_task",
    "build_anchor_task",
    "build_arbiter_task",
    "build_challenger_task",
    "validate_agent_judge_gaia_v3_89_predictions",
    "validate_and_write_agent_judge_gaia_v3_89_audit",
]

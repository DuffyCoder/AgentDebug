"""Luna GAIA v3.15: task-material packet-handoff closure for the anchor."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_14_earliest_causal_challenger as parent


AGENT_JUDGE_LUNA_GAIA_V3_15_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.15-packet-handoff-closure"
)
AGENT_JUDGE_LUNA_GAIA_V3_15_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_14_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_15_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_14_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_15_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_14_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases let the proven v3.13 paper-50 runner execute this
# protocol without changing the three-stage artifact topology.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_15_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_15_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_15_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_15_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = parent.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = parent.CHALLENGERS_FILENAME
ARBITER_FILENAME = parent.ARBITER_FILENAME
ARBITERS_FILENAME = parent.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = parent.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = parent.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
CHALLENGER_FIELDS = parent.CHALLENGER_FIELDS
ARBITER_FIELDS = parent.ARBITER_FIELDS


_PACKET_HANDOFF_CLOSURE = """\
TASK-MATERIAL PACKET-HANDOFF CLOSURE

Before marking any chronological ledger row clear, close these two literal
handoff contracts when they exist:

1. RESULT -> RETAINED STATE. Compare the preceding Step's adjacent result with
   this Step's Memory and Reflection. Admit Lane A at this Step when a task-
   necessary observed entity, value, source/provenance link, success state, or
   failure state is omitted, contradicted, attached to the wrong entity, or
   read as false progress/outcome.
2. IMMEDIATE TARGET -> ACTION. Compare this Step's unresolved subgoal and
   discriminating target with its Action. Admit Lane B when Action drops or
   contradicts a task-necessary entity, predicate, source constraint, evidence
   route, or value. Admit Lane C when a purportedly different acquisition
   attempt preserves the unresolved predicate and adds no credible evidence
   route or discriminating target.

Admission under this closure requires all three materiality gates:

- CHECKLIST NECESSITY: the lost or contradicted fact/target is necessary for a
  still-open task condition, not merely interesting detail;
- LITERAL MISMATCH: the contradiction, omission, or target loss is observable
  from the task and adjacent packets without recalled domain knowledge; and
- PATH EFFECT: repairing this one handoff can change the next retained state or
  action path rather than merely improve wording.

A faithful compact summary may omit nonessential detail. Harmless naming or
wording imprecision remains clear unless consumed into a wrong task-relevant
state or decision. A first broad discovery/acquisition probe remains reasonable
when successful use can contribute a needed identifier, page, citation,
transcript lead, source, or context, even if it cannot itself prove the final
answer. A materially different evidence route also remains a different probe.

For every cleared row, decision_basis must compactly certify that both
applicable handoffs pass or that a named handoff is not applicable. Do not call
a row clear merely because a later error is more explicit. This closure adds no
new lane, candidate pool, or permission to compare past the first surviving
candidate.

"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_14_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_15_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_14_earliest_causal_challenger",
            "agent_judge_luna_gaia_v3_15_packet_handoff_closure",
        )
        .replace(
            "v3.14 earliest-causal challenger",
            "v3.15 packet-handoff closure",
        )
    )


def build_anchor_task(*paths: str | Path) -> str:
    task = _rewrite_identity(parent.build_anchor_task(*paths))
    task = task.replace(
        "frozen v3.4 anchor. The following v3.4 task is the complete anchor "
        "contract",
        "packet-handoff-closed v3.4-derived anchor. The following task is the "
        "complete anchor contract",
        1,
    )
    task = task.replace(
        "Run the frozen Codex Agent Judge protocol "
        "agentdebug.codex-agent-judge.luna-gaia-v3.4.",
        "Run the v3.15 packet-handoff-closed anchor contract derived from "
        "agentdebug.codex-agent-judge.luna-gaia-v3.4.",
        1,
    )
    boundary = "LANE B — HARD TASK, INTERFACE, AND EXECUTION CONDITIONS\n"
    if task.count(boundary) != 1:
        raise RuntimeError("Luna GAIA v3.14 anchor lane-B boundary changed")
    return task.replace(boundary, _PACKET_HANDOFF_CLOSURE + boundary, 1)


def build_challenger_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_challenger_task(*paths))


def build_arbiter_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_arbiter_task(*paths))


def build_agent_judge_luna_gaia_v3_15_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    audit = parent.validate_challenger(*paths)
    return {
        **audit,
        "schema_version": "agentdebug.packet-handoff-challenger-audit.v1",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_15_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_15_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_15_REASONING_EFFORT,
        "anchor_packet_handoff_closure_required": True,
        "challenger_semantics_unchanged_from_v3_14": True,
    }


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    audit = parent.validate_arbiter(*paths)
    return {
        **audit,
        "schema_version": "agentdebug.packet-handoff-arbiter-audit.v1",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_15_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_15_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_15_REASONING_EFFORT,
        "anchor_packet_handoff_closure_required": True,
        "arbiter_semantics_unchanged_from_v3_14": True,
    }


def validate_agent_judge_luna_gaia_v3_15_predictions(
    *paths: str | Path,
) -> dict[str, Any]:
    audit = parent.validate_agent_judge_luna_gaia_v3_14_predictions(*paths)
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_15_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_15_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_15_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_15_REASONING_EFFORT,
        "selection_policy": (
            "packet_handoff_closed_v3_4_anchor_one_earliest_causal_later_"
            "challenger_independent_default_keep_arbiter"
        ),
        "anchor_packet_handoff_closure_required": True,
        "result_to_state_handoff_required": True,
        "target_to_action_handoff_required": True,
        "task_materiality_gate_required": True,
    }


def _write_audit(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return parent._write_audit(audit, path)


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_15_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        validate_agent_judge_luna_gaia_v3_15_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


# Compatibility names used by the shared paper-50 runner.
build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_15_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_15_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_15_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_15_audit(*paths)
        else:
            parent.parent._fail(
                "invalid_compact_validation_arguments", "stage/path count differs"
            )
    except parent.parent.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "AGENT_JUDGE_LUNA_GAIA_V3_15_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_GAIA_V3_15_MODEL",
    "AGENT_JUDGE_LUNA_GAIA_V3_15_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_GAIA_V3_15_VERSION",
    "ANCHOR_CHECKPOINT_AGGREGATE_FILENAME",
    "ANCHOR_LEDGER_AGGREGATE_FILENAME",
    "ANCHOR_PREDICTIONS_FILENAME",
    "ARBITER_FILENAME",
    "ARBITERS_FILENAME",
    "CHALLENGER_FILENAME",
    "CHALLENGERS_FILENAME",
    "build_agent_judge_luna_gaia_v3_15_task",
    "build_anchor_task",
    "build_arbiter_task",
    "build_challenger_task",
    "validate_agent_judge_luna_gaia_v3_15_predictions",
    "validate_and_write_agent_judge_luna_gaia_v3_15_audit",
    "validate_and_write_arbiter_audit",
    "validate_and_write_challenger_audit",
    "validate_arbiter",
    "validate_challenger",
]

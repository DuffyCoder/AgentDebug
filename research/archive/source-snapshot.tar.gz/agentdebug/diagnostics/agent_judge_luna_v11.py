"""Luna Agent Judge v11: isolate re-adjudication to the Planning sink."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_v2_4 import (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION,
    _v2_4_owner_source_resolver,
)
from .agent_judge_luna_v3 import validate_agent_judge_luna_v3_predictions
from .agent_judge_luna_v7 import (
    AGENT_JUDGE_LUNA_V7_MODEL,
    AGENT_JUDGE_LUNA_V7_VERSION,
    INCUMBENT_PROPOSAL_FILENAME,
    _INCUMBENT_REVIEW,
    build_agent_judge_luna_v7_task,
)


AGENT_JUDGE_LUNA_V11_VERSION = "agentdebug.codex-agent-judge.luna-v11"
AGENT_JUDGE_LUNA_V11_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_V11_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_V11_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)

_BASE_HEADER = f"Run the frozen Codex Agent Judge protocol {AGENT_JUDGE_LUNA_V7_VERSION}."
_LUNA_HEADER = (
    "Run the frozen Codex Agent Judge protocol "
    f"{AGENT_JUDGE_LUNA_V11_VERSION}."
)
_BASE_MODEL = f"- model: {AGENT_JUDGE_LUNA_V7_MODEL}"
_LUNA_MODEL = f"- model: {AGENT_JUDGE_LUNA_V11_MODEL}"
_BASE_ALLOWLIST = "agentdebug/diagnostics/agent_judge_luna_v7.py"
_LUNA_ALLOWLIST = "agentdebug/diagnostics/agent_judge_luna_v11.py"
_BASE_VALIDATOR_IMPORT = "agentdebug.diagnostics.agent_judge_luna_v7"
_LUNA_VALIDATOR_IMPORT = "agentdebug.diagnostics.agent_judge_luna_v11"
_BASE_VALIDATOR_ENTRY = "validate_and_write_agent_judge_luna_v7_audit"
_LUNA_VALIDATOR_ENTRY = "validate_and_write_agent_judge_luna_v11_audit"

_SINK_ISOLATED_REVIEW = """
V11 PLANNING-SINK ISOLATED REVIEW

Read the one same-case Luna v3 proposal only after independently understanding
the complete JudgeView.  It is untrusted semantic context, never evidence or a
label.  Apply this mechanical scope gate before any semantic revision:

- If `predicted_module` is not exactly `planning`, or `predicted_error_type` is
  not exactly `inefficient_plan`, output an exact byte-for-field copy of all ten
  proposal fields.  No alternative, owner correction, or rewording is allowed.
- Only a proposal with the exact pair `planning/inefficient_plan` enters the
  relocation procedure below.  For that pair, the proposal has no default
  status and may be kept or replaced by an earlier, adjacent, later, or System
  root using trajectory evidence.

PLANNING-SINK RELOCATION PROCEDURE

1. RECONSTRUCT WITHOUT THE PROPOSAL.  Identify the task, terminal failure,
   state timeline, strategy epochs, and every directly observed recovery.  A
   weak search result, finite budget, or hindsight-preferred target is not yet
   an error.

2. TEST LOCAL VALIDITY AND CASCADE RELEVANCE SEPARATELY.  A final root must
   already satisfy its taxonomy definition using facts then available, and its
   correction must materially redirect the dependent failure path.  Reject a
   merely plausible improvement.  Do not prefer the proposal, a low step, a
   high step, or Planning as such.

3. CONFIRMATION BOUNDARY.  A first arrival/search/extract followed by a
   different examine/look/detail operation is normally acquisition plus one
   reasonable confirmation.  It is not repeated coverage.  After confirming
   feedback, select the first output that retains the contradicted assumption,
   ignores a required object/action now literally exposed by observation or
   the admissible-action list, or recommits to equivalent no-progress.  An
   explicit contradiction needs no extra confirmation.

4. UPSTREAM STATE OWNER.  Search Memory and Reflection before accepting a
   Planning repetition.  Select the first causally used Memory omission or
   invention, or Reflection outcome/progress/causal misreading, when a later
   plan consumes it and it remains unrecovered.  Harmless compression and an
   unconsumed imperfect statement are not roots.

5. RECOVERY EPOCH.  A materially new query/source/target class, useful product
   candidate, restored fact, or successful equivalent operation begins a new
   epoch and vetoes an earlier generic search complaint.  Diagnose the first
   unrecovered defect after recovery.  If a same-step plan explicitly requires
   verifying an attribute, prerequisite, or fact before commit, but Action
   buys, answers, or mutates state without it, select Action/misalignment at
   that handoff.

6. SYSTEM BOUNDARY.  Select final-step System when provenance-backed limits or
   environment failure stop an otherwise coherent sequence of genuinely new,
   feasible exploration.  The existence of another unvisited target or a
   preferred target category is not enough to defeat System.  Reject System
   only for an explicit constraint violation, impossible prerequisite, known
   repeated coverage, state loss, or contradicted assumption that already
   controls failure.

7. PLANNING REMAINDER.  Use Planning/inefficient_plan only at the first plan
   after contemporaneous state recognizes no progress or equivalent completed
   coverage and still treats it as novel.  Prefer a later literal same-step
   state contradiction over an earlier generic continuation when the earlier
   operation was still reasonable.  A faithful concrete action remains
   downstream of that plan.

8. ADJACENT CHECK.  Inspect predecessor, chosen step, and successor.  The
   predecessor must still be reasonable or not yet mature; the chosen output
   must introduce/commit the mature causal defect; the successor must be
   propagation or too late.  Correct an off-by-one proposal rather than copy it.

Freeze the relocated step first, then apply the existing v3 same-step owner,
taxonomy, and literal-evidence rules.  Never infer from case ID, source model,
environment name, distributions, other predictions, or gold.  Return only the
strict ten-field record with no scope/verdict field, confidence, score, rank,
vote, or extra field.
"""


def _proposal_path(predictions_path: str | Path) -> Path:
    return Path(predictions_path).expanduser().resolve().parent / INCUMBENT_PROPOSAL_FILENAME


def build_agent_judge_luna_v11_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build a v3 review restricted to Planning/inefficient_plan sinks."""

    task = build_agent_judge_luna_v7_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    replacements = {
        _BASE_HEADER: _LUNA_HEADER,
        _BASE_MODEL: _LUNA_MODEL,
        _BASE_ALLOWLIST: _LUNA_ALLOWLIST,
        _BASE_VALIDATOR_IMPORT: _LUNA_VALIDATOR_IMPORT,
        _BASE_VALIDATOR_ENTRY: _LUNA_VALIDATOR_ENTRY,
        _INCUMBENT_REVIEW.strip(): _SINK_ISOLATED_REVIEW.strip(),
    }
    for old, new in replacements.items():
        if task.count(old) != 1:
            raise RuntimeError(
                "Agent Judge Luna v7 task changed at a frozen v11 marker"
            )
        task = task.replace(old, new, 1)
    return task


def validate_agent_judge_luna_v11_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    proposal_path = _proposal_path(predictions_path)
    incumbent_audit = validate_agent_judge_luna_v3_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        proposal_path,
    )
    audit = _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_v2_4_owner_source_resolver,
    )
    incumbent_records = json.loads(proposal_path.read_text(encoding="utf-8"))
    prediction_records = json.loads(
        Path(predictions_path).expanduser().resolve().read_text(encoding="utf-8")
    )
    revisable_count = 0
    immutable_count = 0
    for incumbent, prediction in zip(
        incumbent_records,
        prediction_records,
        strict=True,
    ):
        is_sink = (
            incumbent["predicted_module"] == "planning"
            and incumbent["predicted_error_type"] == "inefficient_plan"
        )
        if is_sink:
            revisable_count += 1
            continue
        immutable_count += 1
        if prediction != incumbent:
            raise AgentJudgeValidationError(
                "out_of_scope_revision",
                "Luna v11 changed a non-planning/inefficient_plan incumbent "
                f"for trajectory {incumbent['trajectory_id']}",
            )
    proposal_sha256 = hashlib.sha256(proposal_path.read_bytes()).hexdigest()
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_V11_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_V11_VERSION,
        "model": AGENT_JUDGE_LUNA_V11_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V11_REASONING_EFFORT,
        "incumbent_protocol": "agentdebug.codex-agent-judge.luna-v3",
        "incumbent_proposal_sha256": proposal_sha256,
        "incumbent_proposal_case_count": incumbent_audit["case_count"],
        "revision_scope": "planning/inefficient_plan only",
        "revision_scope_revisable_count": revisable_count,
        "revision_scope_immutable_count": immutable_count,
    }


def validate_and_write_agent_judge_luna_v11_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_v11_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


__all__ = [
    "AGENT_JUDGE_LUNA_V11_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_V11_MODEL",
    "AGENT_JUDGE_LUNA_V11_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_V11_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "INCUMBENT_PROPOSAL_FILENAME",
    "build_agent_judge_luna_v11_task",
    "validate_agent_judge_luna_v11_predictions",
    "validate_and_write_agent_judge_luna_v11_audit",
]

"""GAIA v3.90: clean v3.83 outcome-conditioned predicate-handoff tournament.

The accepted v3.83 GPT-5.5 anchor/ledger semantics are preserved.  The single
semantic change is to replace its challenger/arbiter tail with the v3.80
outcome-conditioned tournament over every native ledger Step.  v3.80 is a
mechanism source only and is not the semantic parent.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge_luna_gaia_v3_80_clean_v3p20_outcome_conditioned_predicate_handoff_tournament_taxonomy_repair import *  # noqa: F403
from . import (
    agent_judge_gaia_v3_83_clean_v3p20_model_only_gpt55_medium as incumbent,
)
from . import (
    agent_judge_luna_gaia_v3_80_clean_v3p20_outcome_conditioned_predicate_handoff_tournament_taxonomy_repair as mechanism,
)


AGENT_JUDGE_GAIA_V3_90_VERSION = (
    "agentdebug.codex-agent-judge.gaia-v3.90-gpt55-"
    "outcome-conditioned-predicate-handoff-tournament"
)
AGENT_JUDGE_GAIA_V3_90_MODEL = incumbent.AGENT_JUDGE_GAIA_V3_83_MODEL
AGENT_JUDGE_GAIA_V3_90_REASONING_EFFORT = (
    incumbent.AGENT_JUDGE_GAIA_V3_83_REASONING_EFFORT
)
AGENT_JUDGE_GAIA_V3_90_AUDIT_SCHEMA_VERSION = (
    incumbent.AGENT_JUDGE_GAIA_V3_83_AUDIT_SCHEMA_VERSION
)
SEMANTIC_PARENT = incumbent.AGENT_JUDGE_GAIA_V3_83_VERSION

# Compatibility aliases consumed by the frozen two-stage aggregation runtime.
AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION = AGENT_JUDGE_GAIA_V3_90_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_80_MODEL = AGENT_JUDGE_GAIA_V3_90_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_80_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_90_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_79_VERSION = AGENT_JUDGE_GAIA_V3_90_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_79_MODEL = AGENT_JUDGE_GAIA_V3_90_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_79_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_90_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION = AGENT_JUDGE_GAIA_V3_90_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL = AGENT_JUDGE_GAIA_V3_90_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_90_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_GAIA_V3_90_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_GAIA_V3_90_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_90_REASONING_EFFORT


def _retag_task(task: str) -> str:
    """Retag only experiment identity and truthful executor metadata."""

    value = task.replace(
        mechanism.AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION,
        AGENT_JUDGE_GAIA_V3_90_VERSION,
    )
    value = value.replace(
        mechanism.parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        SEMANTIC_PARENT,
    )
    old_model = f"- model: {mechanism.AGENT_JUDGE_LUNA_GAIA_V3_80_MODEL}"
    new_model = f"- model: {AGENT_JUDGE_GAIA_V3_90_MODEL}"
    if value.count(old_model) != 1:
        raise RuntimeError("v3.80 task model marker changed unexpectedly")
    return value.replace(old_model, new_model, 1)


def build_anchor_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> str:
    return _retag_task(
        mechanism.build_anchor_file_task(
            prediction_manifest_path, cohort_manifest_path
        )
    )


def build_reducer_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> str:
    return _retag_task(
        mechanism.build_reducer_file_task(
            prediction_manifest_path,
            cohort_manifest_path,
            anchor_path,
            ledger_path,
            checkpoint_path,
        )
    )


def _retag_audit(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    value = dict(audit)
    value.pop("model_only_swap", None)
    return {
        **value,
        "agent_judge_version": AGENT_JUDGE_GAIA_V3_90_VERSION,
        "model": AGENT_JUDGE_GAIA_V3_90_MODEL,
        "reasoning_effort": AGENT_JUDGE_GAIA_V3_90_REASONING_EFFORT,
        "selection_policy": policy,
        "semantic_parent": SEMANTIC_PARENT,
        "direct_semantic_parent": SEMANTIC_PARENT,
        "rejected_lineage_inherited": False,
        "rejected_lineage_mechanism_source_only": mechanism.AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION,
        "single_major_change": (
            "replace the accepted v3.83 challenger/arbiter tail with one "
            "outcome-conditioned exact-predicate handoff tournament over every "
            "native v3.83 ledger Step"
        ),
        "accepted_v3p83_anchor_ledger_semantics_preserved": True,
        "selected_step_invariant_taxonomy_materialization": True,
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag_audit(
        mechanism.validate_anchor_predictions(*paths),
        policy="unchanged_v3_83_gpt55_anchor_owner_explicit_response_only",
    )


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])  # noqa: F405


def validate_panel(*paths: str | Path) -> dict[str, Any]:
    return _retag_audit(
        mechanism.validate_panel(*paths),
        policy="outcome_conditioned_predicate_handoff_tournament",
    )


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_panel(*paths[:-1]), paths[-1])  # noqa: F405


def validate_selector(*paths: str | Path) -> dict[str, Any]:
    return _retag_audit(
        mechanism.validate_selector(*paths),
        policy="deterministic_predicate_handoff_tournament_selection_copy",
    )


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_selector(*paths[:-1]), paths[-1])  # noqa: F405


def validate_agent_judge_gaia_v3_90_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    return _retag_audit(
        mechanism.validate_agent_judge_luna_gaia_v3_80_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        policy=(
            "accepted_v3p83_anchor_outcome_conditioned_exact_predicate_handoff_"
            "tournament_with_step_invariant_taxonomy_repair"
        ),
    )


def validate_and_write_agent_judge_gaia_v3_90_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(  # noqa: F405
        validate_agent_judge_gaia_v3_90_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_gaia_v3_90_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_reducer_file_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,  # noqa: F405
    )


# Compatibility names consumed by the shared two-stage runner.
validate_and_write_agent_judge_luna_gaia_v3_67_audit = (
    validate_and_write_agent_judge_gaia_v3_90_audit
)
validate_and_write_agent_judge_luna_gaia_v3_79_audit = (
    validate_and_write_agent_judge_gaia_v3_90_audit
)
validate_and_write_agent_judge_luna_gaia_v3_80_audit = (
    validate_and_write_agent_judge_gaia_v3_90_audit
)
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_gaia_v3_90_task
build_agent_judge_luna_gaia_v3_79_task = build_agent_judge_gaia_v3_90_task
build_agent_judge_luna_gaia_v3_80_task = build_agent_judge_gaia_v3_90_task


def __getattr__(name: str) -> Any:
    return getattr(mechanism, name)


"""Luna-backed Agent Judge protocol for full tuning-v1 optimization.

The historical Terra protocols remain immutable.  Luna v1 reuses v2.4's
canonical local-census/global-root semantics and evidence resolver, changes
the frozen execution model, and adds a small set of definition-level guards
found necessary by gold-free failure analysis.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_v2_4 import (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_V2_4_MODEL,
    AGENT_JUDGE_V2_4_VERSION,
    _v2_4_owner_source_resolver,
    build_agent_judge_v2_4_task,
)


AGENT_JUDGE_LUNA_V1_VERSION = "agentdebug.codex-agent-judge.luna-v1"
AGENT_JUDGE_LUNA_V1_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_V1_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_V1_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)

_BASE_HEADER = f"Run the frozen Codex Agent Judge protocol {AGENT_JUDGE_V2_4_VERSION}."
_LUNA_HEADER = (
    "Run the frozen Codex Agent Judge protocol "
    f"{AGENT_JUDGE_LUNA_V1_VERSION}."
)
_BASE_MODEL = f"- model: {AGENT_JUDGE_V2_4_MODEL}"
_LUNA_MODEL = f"- model: {AGENT_JUDGE_LUNA_V1_MODEL}"
_BASE_ALLOWLIST = "agentdebug/diagnostics/agent_judge_v2_4.py"
_LUNA_ALLOWLIST = "agentdebug/diagnostics/agent_judge_luna_v1.py"
_BASE_VALIDATOR_IMPORT = "agentdebug.diagnostics.agent_judge_v2_4"
_LUNA_VALIDATOR_IMPORT = "agentdebug.diagnostics.agent_judge_luna_v1"
_BASE_VALIDATOR_ENTRY = "validate_and_write_agent_judge_v2_4_audit"
_LUNA_VALIDATOR_ENTRY = "validate_and_write_agent_judge_luna_v1_audit"
_TAXONOMY_MARKER = "\nAGENT ERROR TAXONOMY\n"

_LUNA_V1_DELTA = """
LUNA V1 FULL-TUNING CAUSAL AND TAXONOMY GUARDS

This protocol is optimized only on the complete frozen tuning-v1 cohort.  Do
not use a cross-case module distribution, a target step distribution, a case
identity, or an environment identity to choose any diagnosis.

LOCAL ERROR IS NOT AUTOMATICALLY THE GLOBAL ROOT

A visible local syntax error, no-op, weak query, or incomplete final turn is
only a Phase 1 candidate.  It wins Phase 2 only if correcting that single
output leaves a concrete feasible continuation that could plausibly complete
the task and removes a cause that remains material to the observed failure.
Reject a one-turn defect that is later repaired, superseded by a strategy
reset, or too late for its isolated correction to redirect the episode.  Do
not justify global criticality merely by saying that the correction would
make one action execute or would save one turn.

TYPE DEFINITIONS ARE ADMISSION TESTS

A module/error-type pair being present in the taxonomy is necessary but not
sufficient.  The selected literal evidence and root-cause explanation must
satisfy the chosen type's definition:
- action/format_error requires concrete interface syntax that is unparseable;
  a natural-language answer that is incomplete, non-numeric, unsupported, or
  wrong is not a format error merely because it fails the requested format;
- action/invalid_action requires an operation absent from the available action
  space, not an ineffective available operation;
- action/parameter_error requires an otherwise available concrete operation
  whose argument is mechanically missing, malformed, wrong-typed, or misfilled;
  a strategy-level query choice or repeated search belongs to Planning when
  the plan selected it;
- planning/impossible_action requires a genuinely impossible state,
  prerequisite, or operation; a poor but executable search is not impossible.

If the strongest semantic candidate has no legal type whose definition its
own evidence satisfies, do not force it into Action or Planning.  Continue the
global comparison among other genuinely defect-bearing candidates, including
Memory and Reflection candidates already present in the complete local census.
Evidence representation and quote convenience never break the tie.
"""


def build_agent_judge_luna_v1_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build v2.4's canonical task with the frozen Luna execution delta."""

    task = build_agent_judge_v2_4_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    expected_once = {
        _BASE_HEADER: _LUNA_HEADER,
        _BASE_MODEL: _LUNA_MODEL,
        _BASE_ALLOWLIST: _LUNA_ALLOWLIST,
        _BASE_VALIDATOR_IMPORT: _LUNA_VALIDATOR_IMPORT,
        _BASE_VALIDATOR_ENTRY: _LUNA_VALIDATOR_ENTRY,
        _TAXONOMY_MARKER: f"\n{_LUNA_V1_DELTA.strip()}\n{_TAXONOMY_MARKER}",
    }
    for old, new in expected_once.items():
        if task.count(old) != 1:
            raise RuntimeError(
                "Agent Judge v2.4 task changed at a frozen Luna migration marker"
            )
        task = task.replace(old, new, 1)
    # This remaining phrase is user-facing recovery guidance, not a module or
    # import path.  Rebind it so the generated task is internally versioned.
    task = task.replace(
        "v2.4\nprotocol/taxonomy source",
        "Luna v1\nprotocol/taxonomy source",
    )
    return task


def validate_agent_judge_luna_v1_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    """Validate with v2.4 evidence semantics and Luna audit identity."""

    audit = _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_v2_4_owner_source_resolver,
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_V1_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_V1_VERSION,
        "model": AGENT_JUDGE_LUNA_V1_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V1_REASONING_EFFORT,
    }


def validate_and_write_agent_judge_luna_v1_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    """Validate first and atomically persist a Luna v1 audit on success."""

    audit = validate_agent_judge_luna_v1_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


__all__ = [
    "AGENT_JUDGE_LUNA_V1_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_V1_MODEL",
    "AGENT_JUDGE_LUNA_V1_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_V1_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "build_agent_judge_luna_v1_task",
    "validate_agent_judge_luna_v1_predictions",
    "validate_and_write_agent_judge_luna_v1_audit",
]

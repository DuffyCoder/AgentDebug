"""Luna GAIA v3.50: clean v3.20 plus factorized local-to-global proposal duel."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions
from .taxonomy import AgentModule, ErrorType, is_valid_classification, taxonomy_prompt


AGENT_JUDGE_LUNA_GAIA_V3_50_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.50-clean-v3.20-"
    "factorized-local-inventory-global-proposal-duel"
)
AGENT_JUDGE_LUNA_GAIA_V3_50_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_50_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_50_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases for the neutral full-cohort orchestration shell.
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_50_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_50_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_50_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_50_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_50_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_50_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_50_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
LOCAL_PROFILE_FILENAME = "local-error-inventory.json"
LOCAL_PROFILE_AUDIT_FILENAME = "local-error-inventory-audit.json"
PANEL_FILENAME = "factorized-local-inventory-bundle.json"
PANELS_FILENAME = "factorized-local-inventory-bundles.json"
PROPOSAL_FILENAME = "global-causal-proposal.json"
PROPOSAL_AUDIT_FILENAME = "global-causal-proposal-audit.json"
SELECTOR_FILENAME = "factorized-proposal-duel.json"
SELECTORS_FILENAME = "factorized-proposal-duels.json"
SELECTOR_AUDIT_FILENAME = "factorized-proposal-duel-audit.json"

PROFILE_MODULES = tuple(module.value for module in AgentModule)
PROFILE_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "profile_module",
    "reviewed_steps",
    "local_errors",
    "profile_summary",
)
LOCAL_ERROR_FIELDS = (
    "step",
    "module",
    "error_type",
    "evidence_quote",
    "adjacent_fact_step",
    "adjacent_fact_quote",
    "recovery_status",
    "recovery_step",
    "recovery_quote",
    "local_reasoning",
)
RECOVERY_STATUSES = frozenset({"unrecovered", "recovered", "uncertain"})
PROFILE_WRAPPER_FIELDS = ("profile_module", "profile_sha256", "profile")
INVENTORY_ERROR_FIELDS = (
    "error_key",
    "profile_module",
    "profile_sha256",
    "local_error",
)
BUNDLE_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "profile_count",
    "profile_set_sha256",
    "profiles",
    "local_error_count",
    "local_errors",
)
PROPOSAL_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "inventory_sha256",
    "compared_error_keys",
    "proposal_status",
    "proposal_error_key",
    "proposal_step",
    "boundary_class",
    "proposal_prediction",
    "probe_assessment",
    "recovery_assessment",
    "chronology_comparison",
    "critical_boundary_basis",
    "selection_falsifier",
)
PROPOSAL_STATUSES = frozenset({"candidate", "none"})
BOUNDARY_CLASSES = frozenset(
    {
        "none",
        "state_truth",
        "constraint_alignment",
        "capability_commitment",
        "post_feedback_recommitment",
        "terminal_abandonment",
    }
)
DUEL_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "anchor_prediction_sha256",
    "anchor_ledger_sha256",
    "anchor_checkpoint_sha256",
    "inventory_sha256",
    "proposal_sha256",
    "proposal",
    "anchor_step",
    "proposal_step",
    "decision",
    "anchor_classification",
    "proposal_classification",
    "anchor_veto_evidence_step",
    "anchor_veto_evidence_quote",
    "anchor_contribution_witness_step",
    "anchor_contribution_witness_quote",
    "frozen_step",
    "selected_prediction_sha256",
    "selected_prediction",
    "anchor_assessment",
    "proposal_assessment",
    "timeline_comparison",
    "decision_basis",
    "rejected_alternative_basis",
    "selection_falsifier",
)
DUEL_DECISIONS = frozenset({"keep_anchor", "select_proposal"})
ANCHOR_CLASSES = frozenset(
    {
        "critical_root",
        "contributing_probe",
        "normal_tool_failure",
        "recovered_defect",
        "noncritical_predecessor",
        "faithful_propagation",
        "downstream_symptom",
        "uncertain",
    }
)
OVERRIDE_ANCHOR_CLASSES = ANCHOR_CLASSES - {"critical_root", "uncertain"}
PROPOSAL_CLASSES = frozenset(
    {
        "absent",
        "critical_root",
        "reasonable_probe",
        "normal_tool_failure",
        "recovered_defect",
        "mechanical_defect",
        "faithful_propagation",
        "downstream_symptom",
        "uncertain",
    }
)


_LOCAL_RULES = """\
MODULE-LOCAL ERROR INVENTORY — COMPLETE COVERAGE, NO GLOBAL SELECTION

You are one isolated owner reviewer. Inspect the assigned module at every
observable Step. Preserve concrete local defects and the literal adjacent and
recovery facts needed for later comparison. You cannot see an anchor and must
not nominate, rank, or predict the benchmark-critical Step.

Admit a row only for a concrete owner-local defect: task-material false/lost
state, false outcome or progress interpretation, explicit constraint/target
mismatch, intrinsically incapable evidence commitment, post-feedback unchanged
recommitment, or eligible external execution failure. System requires a
well-formed task-relevant call defeated by an external execution limit.

Exclude reasonable information-producing probes, genuinely different evidence
probes, normal empty/negative results, merely improvable behavior, faithful
propagation, and visible downstream symptoms. Mark recovered only when a later
literal Step fully retires that exact defect. Inventory rows are evidence, not
votes or candidates. Never access labels, gold, historical predictions, scored
artifacts, case reports, source identity priors, or external resources.
"""


_GLOBAL_RULES = """\
ANCHOR-BLIND GLOBAL COMPRESSION OF FROZEN LOCAL INVENTORIES — MAX ONE PROPOSAL

The five inventories are immutable evidence, never votes. Compare every row
against the complete chronology and list every error_key in compared_error_keys
in its frozen order. Export at most one proposal. The anchor is unavailable;
do not infer or reconstruct it.

Select the first observable Agent/System-owned error that materially changes
the failed path under the benchmark boundary. Do not prefer majority, module,
row count, Planning, earlier/later position alone, repetition, severity, or
forceful prose. Veto a reasonable/different probe, normal negative result,
recovered defect, mechanical predecessor/repair, faithful propagation, and
downstream symptom.

A concrete commitment can already be material from its literal current target,
interface, constraint, state, or capability mismatch; do not require a later
consequence conjunct. Conversely, do not project the final proof predicate onto
an intermediate route that can actually supply a necessary fact. For repeated
strategies, verify prior feedback already made the same immediate evidence
family unproductive. For state, bind the false/lost/misread fact to the current
or next decision. For terminal abandonment, verify no earlier unrecovered root.

The proposal must be grounded in exactly one inventoried row: Step, module,
error type, and evidence quote must exact-copy that row. Emit none only when no
row survives. State the strongest concrete falsifier. Never read labels, gold,
old predictions, scores, case reports, source identities, or external data.
"""


_DUEL_RULES = """\
BOUNDED ANCHOR/PROPOSAL COMPARISON — EXACT COPY, DEFAULT ANCHOR

Select exactly the immutable clean-v3.20 anchor or the one factorized proposal.
Never invent a third Step, repair fields, merge predictions, or use provenance
as evidence. If Steps agree or evidence is unresolved, keep the anchor.

Protect a direct unrecovered constraint/target mismatch, task-material false
state, incapable commitment, eligible execution impact, or earliest causal
commitment. Reject normal tool failure, recovered/mechanical predecessor,
faithful propagation, and downstream symptom. A later proposal cannot displace
an earlier anchor merely by being clearer, repeated, or more severe; quote the
literal evidence that removes the anchor's causal ownership.

Initial-probe status is not an automatic veto. Classify an anchor as
contributing_probe only with a literal observed witness that its route actually
supplied a necessary task fact, identifier, source, or route. Successful
transport, generic/empty output, or hypothetical usefulness is insufficient.
For select_proposal, the proposal must be critical_root and the anchor must have
a validator-bound noncritical veto. Default keep under uncertainty.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_50_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_50_clean_v3p20_factorized_local_inventory_global_proposal_duel",
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py",
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_50_clean_v3p20_factorized_local_inventory_global_proposal_duel.py",
        )
    )


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_50_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_50_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_50_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one factorized local-inventory global proposal duel",
    }


def _boundary(
    *, manifest: Path, cohort: Path, reads: Sequence[Path], output: Path
) -> str:
    read_lines = "\n".join(f"- {path}" for path in reads) or "- none"
    return f"""\
IMMUTABLE EXECUTION CONFIGURATION
- model: {AGENT_JUDGE_LUNA_GAIA_V3_50_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_50_REASONING_EFFORT}
- one isolated case; fresh session; no cross-case state or prior predictions
- external LLM/API/network calls: forbidden
- scoring or gold-label access: forbidden

INPUT/OUTPUT BOUNDARY
- prediction manifest: {manifest}
- prediction manifest file sha256: {shared._file_sha256(manifest)}
- cohort manifest: {cohort}
- cohort manifest file sha256: {shared._file_sha256(cohort)}
- permitted frozen stage inputs:
{read_lines}
- write the sole stage artifact only to: {output}

Read only those exact inputs plus this v3.50 protocol source, the accepted
v3.20 protocol source, and taxonomy.py. Do not inspect directories or infer
from trajectory/source-model/environment names. Never read labels, metrics,
scored artifacts, experiment documents, rejected protocol sources, historical
predictions, cached replies, case studies, git history, or external resources.
"""


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_anchor_task(*paths))


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths), policy="unchanged_v3_20_anchor")


def _validate_optional_quote_pair(
    *, case: Any, step: Any, quote: Any, location: str
) -> None:
    if step is None and quote is None:
        return
    if isinstance(step, bool) or not isinstance(step, int):
        shared._fail("invalid_local_inventory_fact_step", location)
    if step < 1 or step > len(case.judge_view.steps):
        shared._fail("invalid_local_inventory_fact_step", location)
    shared._nonempty_text(quote, location=f"{location}.quote", maximum=2400)
    if not any(quote in source for source in shared._packet_sources(case, step)):
        shared._fail("invalid_local_inventory_fact_quote", location)


def _validate_local_error(
    raw: Any, *, case: Any, profile_module: str, location: str
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != LOCAL_ERROR_FIELDS:
        shared._fail("invalid_local_inventory_error_schema", location)
    step = raw["step"]
    if (
        isinstance(step, bool)
        or not isinstance(step, int)
        or step < 1
        or step > len(case.judge_view.steps)
    ):
        shared._fail("invalid_local_inventory_error_step", location)
    if raw["module"] != profile_module:
        shared._fail("local_inventory_module_binding_mismatch", location)
    try:
        module = AgentModule(raw["module"])
        error_type = ErrorType(raw["error_type"])
    except ValueError:
        shared._fail("invalid_local_inventory_taxonomy", location)
    if not is_valid_classification(module, error_type):
        shared._fail("invalid_local_inventory_taxonomy", location)
    shared._nonempty_text(
        raw["evidence_quote"], location=f"{location}.evidence_quote", maximum=2400
    )
    owner_sources = shared._luna_gaia_v2_owner_source_resolver(
        case.judge_view, step, module, error_type
    )
    if not owner_sources or not any(
        raw["evidence_quote"] in source for source in owner_sources
    ):
        shared._fail("invalid_local_inventory_owner_evidence", location)
    _validate_optional_quote_pair(
        case=case,
        step=raw["adjacent_fact_step"],
        quote=raw["adjacent_fact_quote"],
        location=f"{location}.adjacent_fact",
    )
    if raw["recovery_status"] not in RECOVERY_STATUSES:
        shared._fail("invalid_local_inventory_recovery_status", location)
    if raw["recovery_status"] == "recovered":
        recovery_step = raw["recovery_step"]
        if (
            isinstance(recovery_step, bool)
            or not isinstance(recovery_step, int)
            or recovery_step <= step
        ):
            shared._fail("invalid_local_inventory_recovery_step", location)
        _validate_optional_quote_pair(
            case=case,
            step=recovery_step,
            quote=raw["recovery_quote"],
            location=f"{location}.recovery",
        )
    elif raw["recovery_step"] is not None or raw["recovery_quote"] is not None:
        shared._fail("inactive_local_inventory_recovery_fields", location)
    shared._nonempty_text(
        raw["local_reasoning"], location=f"{location}.local_reasoning", maximum=3000
    )
    return raw


def _validate_profile_record(
    raw: Any, *, case: Any, profile_module: str, location: str
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != PROFILE_FIELDS:
        shared._fail("invalid_local_inventory_schema", location)
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
        or raw["profile_module"] != profile_module
    ):
        shared._fail("local_inventory_identity_or_owner_mismatch", location)
    if raw["reviewed_steps"] != list(range(1, len(case.judge_view.steps) + 1)):
        shared._fail("incomplete_local_inventory_step_coverage", location)
    if not isinstance(raw["local_errors"], list):
        shared._fail("invalid_local_inventory_errors", location)
    observed: list[int] = []
    for index, error in enumerate(raw["local_errors"]):
        observed.append(
            _validate_local_error(
                error,
                case=case,
                profile_module=profile_module,
                location=f"{location}.local_errors[{index}]",
            )["step"]
        )
    if observed != sorted(set(observed)):
        shared._fail("unsorted_or_duplicate_local_inventory_errors", location)
    shared._nonempty_text(
        raw["profile_summary"], location=f"{location}.profile_summary", maximum=3000
    )
    return raw


def validate_profile(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    profile_module: str,
    profile_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    profile_file, raw = shared._load_artifact(profile_path, role="local inventory")
    profile = shared._one_record(raw, role="local inventory")
    _validate_profile_record(
        profile, case=case, profile_module=profile_module, location="profile[0]"
    )
    return _retag(
        {
            "schema_version": "agentdebug.module-local-error-inventory-audit.v1",
            "stage": "anchor_blind_local_inventory",
            "gold_free_validation": True,
            "case_count": 1,
            "profile_module": profile_module,
            "complete_step_coverage": True,
            "local_error_count": len(profile["local_errors"]),
            "makes_critical_step_prediction": False,
            "anchor_visible": False,
            "input_sha256": {
                "prediction_manifest": shared._file_sha256(manifest),
                "cohort": shared._file_sha256(cohort),
            },
            "output_sha256": {LOCAL_PROFILE_FILENAME: shared._file_sha256(profile_file)},
        },
        policy="anchor_blind_module_local_error_inventory",
    )


def build_profile_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    profile_module: str,
    profile_path: str | Path,
) -> str:
    if profile_module not in PROFILE_MODULES:
        shared._fail("invalid_local_inventory_module", profile_module)
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    output = Path(profile_path).expanduser().resolve()
    shared._assert_safe_path(output, role="local inventory output", is_output=True)
    audit = output.parent / LOCAL_PROFILE_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_50_clean_v3p20_factorized_local_inventory_global_proposal_duel",
            "--compact-validate",
            "profile",
            manifest,
            cohort,
            profile_module,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    error_schema = {
        "step": "integer Step",
        "module": profile_module,
        "error_type": "taxonomy-valid type",
        "evidence_quote": "literal same-Step owner evidence",
        "adjacent_fact_step": "literal context Step or null",
        "adjacent_fact_quote": "literal context quote or null",
        "recovery_status": "unrecovered, recovered, or uncertain",
        "recovery_step": "later recovery Step or null",
        "recovery_quote": "literal recovery quote or null",
        "local_reasoning": "why this is a concrete owner-local defect",
    }
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "profile_module": profile_module,
        "reviewed_steps": list(range(1, len(case.judge_view.steps) + 1)),
        "local_errors": [error_schema],
        "profile_summary": "complete owner review summary",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_50_VERSION}: local inventory for {profile_module}.

{_boundary(manifest=manifest, cohort=cohort, reads=(), output=output)}

{_LOCAL_RULES}

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

local_errors may be empty. Sort rows by Step and emit at most one row per Step.
After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _error_key(profile_module: str, row: dict[str, Any]) -> str:
    return f"{profile_module}:S{row['step']}:{row['error_type']}"


def _flatten_local_errors(wrappers: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for wrapper in wrappers:
        for row in wrapper["profile"]["local_errors"]:
            result.append(
                {
                    "error_key": _error_key(wrapper["profile_module"], row),
                    "profile_module": wrapper["profile_module"],
                    "profile_sha256": wrapper["profile_sha256"],
                    "local_error": row,
                }
            )
    return result


def _validate_bundle_record(raw: Any, *, case: Any, location: str) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != BUNDLE_FIELDS:
        shared._fail("invalid_factorized_inventory_bundle_schema", location)
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
    ):
        shared._fail("factorized_inventory_bundle_identity_mismatch", location)
    wrappers = raw["profiles"]
    if (
        raw["profile_count"] != len(PROFILE_MODULES)
        or not isinstance(wrappers, list)
        or len(wrappers) != len(PROFILE_MODULES)
    ):
        shared._fail("invalid_factorized_inventory_profile_count", location)
    hashes: list[str] = []
    for index, (profile_module, wrapper) in enumerate(
        zip(PROFILE_MODULES, wrappers, strict=True)
    ):
        item_location = f"{location}.profiles[{index}]"
        if not isinstance(wrapper, dict) or tuple(wrapper) != PROFILE_WRAPPER_FIELDS:
            shared._fail("invalid_factorized_inventory_wrapper", item_location)
        if wrapper["profile_module"] != profile_module:
            shared._fail("factorized_inventory_wrapper_order_mismatch", item_location)
        profile = _validate_profile_record(
            wrapper["profile"],
            case=case,
            profile_module=profile_module,
            location=f"{item_location}.profile",
        )
        if wrapper["profile_sha256"] != shared._stable_sha256(profile):
            shared._fail("factorized_inventory_profile_hash_mismatch", item_location)
        hashes.append(wrapper["profile_sha256"])
    if raw["profile_set_sha256"] != shared._stable_sha256(hashes):
        shared._fail("factorized_inventory_set_hash_mismatch", location)
    expected = _flatten_local_errors(wrappers)
    if raw["local_errors"] != expected or raw["local_error_count"] != len(expected):
        shared._fail("factorized_inventory_error_inventory_mismatch", location)
    keys: list[str] = []
    for error in expected:
        if tuple(error) != INVENTORY_ERROR_FIELDS:
            shared._fail("invalid_factorized_inventory_error_schema", location)
        keys.append(error["error_key"])
    if len(keys) != len(set(keys)):
        shared._fail("duplicate_factorized_inventory_error_key", location)
    return raw


def build_inventory_bundle(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    profile_paths: Sequence[str | Path],
    bundle_path: str | Path,
) -> dict[str, Any]:
    _, _, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    if len(profile_paths) != len(PROFILE_MODULES):
        shared._fail("invalid_factorized_inventory_profile_count", str(len(profile_paths)))
    wrappers: list[dict[str, Any]] = []
    for profile_module, value in zip(PROFILE_MODULES, profile_paths, strict=True):
        _, raw = shared._load_artifact(value, role=f"{profile_module} inventory")
        profile = shared._one_record(raw, role=f"{profile_module} inventory")
        _validate_profile_record(
            profile,
            case=case,
            profile_module=profile_module,
            location=f"profiles.{profile_module}",
        )
        wrappers.append(
            {
                "profile_module": profile_module,
                "profile_sha256": shared._stable_sha256(profile),
                "profile": profile,
            }
        )
    local_errors = _flatten_local_errors(wrappers)
    bundle = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "profile_count": len(wrappers),
        "profile_set_sha256": shared._stable_sha256(
            [wrapper["profile_sha256"] for wrapper in wrappers]
        ),
        "profiles": wrappers,
        "local_error_count": len(local_errors),
        "local_errors": local_errors,
    }
    _validate_bundle_record(bundle, case=case, location="inventory_bundle[0]")
    output = Path(bundle_path).expanduser().resolve()
    shared._assert_safe_path(output, role="inventory bundle output", is_output=True)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps([bundle], ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return bundle


def _validate_proposal_record(
    raw: Any, *, case: Any, bundle: dict[str, Any], location: str
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != PROPOSAL_FIELDS:
        shared._fail("invalid_factorized_global_proposal_schema", location)
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
        or raw["inventory_sha256"] != shared._stable_sha256(bundle)
    ):
        shared._fail("factorized_global_proposal_identity_or_hash_mismatch", location)
    expected_keys = [item["error_key"] for item in bundle["local_errors"]]
    if raw["compared_error_keys"] != expected_keys:
        shared._fail("incomplete_factorized_global_proposal_comparison", location)
    if raw["proposal_status"] not in PROPOSAL_STATUSES:
        shared._fail("invalid_factorized_global_proposal_status", location)
    if raw["boundary_class"] not in BOUNDARY_CLASSES:
        shared._fail("invalid_factorized_global_boundary_class", location)
    for field in (
        "probe_assessment",
        "recovery_assessment",
        "chronology_comparison",
        "critical_boundary_basis",
        "selection_falsifier",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3400)
    if raw["proposal_status"] == "none":
        if any(
            raw[field] is not None
            for field in ("proposal_error_key", "proposal_step", "proposal_prediction")
        ) or raw["boundary_class"] != "none":
            shared._fail("nonempty_factorized_global_none_proposal", location)
        return raw
    if raw["boundary_class"] == "none" or raw["proposal_error_key"] not in expected_keys:
        shared._fail("invalid_factorized_global_candidate_binding", location)
    selected_row = next(
        item
        for item in bundle["local_errors"]
        if item["error_key"] == raw["proposal_error_key"]
    )["local_error"]
    prediction = shared._validate_prediction_record(
        raw["proposal_prediction"], case=case, location=f"{location}.proposal"
    )
    if raw["proposal_step"] != prediction["predicted_step"]:
        shared._fail("factorized_global_proposal_step_mismatch", location)
    for field, prediction_field in (
        ("step", "predicted_step"),
        ("module", "predicted_module"),
        ("error_type", "predicted_error_type"),
        ("evidence_quote", "evidence_quote"),
    ):
        if selected_row[field] != prediction[prediction_field]:
            shared._fail("factorized_global_proposal_inventory_copy_mismatch", location)
    return raw


def validate_global_proposal(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    bundle_path: str | Path,
    proposal_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle_file, bundle_raw = shared._load_artifact(bundle_path, role="inventory bundle")
    bundle = shared._one_record(bundle_raw, role="inventory bundle")
    _validate_bundle_record(bundle, case=case, location="inventory_bundle[0]")
    proposal_file, proposal_raw = shared._load_artifact(
        proposal_path, role="global proposal"
    )
    proposal = shared._one_record(proposal_raw, role="global proposal")
    _validate_proposal_record(
        proposal, case=case, bundle=bundle, location="proposal[0]"
    )
    return _retag(
        {
            "schema_version": "agentdebug.factorized-global-causal-proposal-audit.v1",
            "stage": "anchor_blind_global_inventory_compression",
            "gold_free_validation": True,
            "case_count": 1,
            "anchor_visible": False,
            "complete_inventory_comparison": True,
            "maximum_candidates": 1,
            "proposal_status": proposal["proposal_status"],
            "input_sha256": {
                "prediction_manifest": shared._file_sha256(manifest),
                "cohort": shared._file_sha256(cohort),
                "inventory": shared._file_sha256(bundle_file),
            },
            "output_sha256": {PROPOSAL_FILENAME: shared._file_sha256(proposal_file)},
        },
        policy="anchor_blind_factorized_inventory_global_compression",
    )


def build_global_proposal_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    bundle_path: str | Path,
    proposal_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle_file, bundle_raw = shared._load_artifact(bundle_path, role="inventory bundle")
    bundle = shared._one_record(bundle_raw, role="inventory bundle")
    _validate_bundle_record(bundle, case=case, location="inventory_bundle[0]")
    output = Path(proposal_path).expanduser().resolve()
    shared._assert_safe_path(output, role="global proposal output", is_output=True)
    audit = output.parent / PROPOSAL_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_50_clean_v3p20_factorized_local_inventory_global_proposal_duel",
            "--compact-validate",
            "proposal",
            manifest,
            cohort,
            bundle_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    prediction_schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        "predicted_step": "exact inventoried Step",
        "predicted_module": "exact inventoried module",
        "predicted_error_type": "exact inventoried error type",
        "evidence_quote": "exact inventoried evidence quote",
        "root_cause": "specific local root cause",
        "causal_summary": "why this boundary materially changes the failed path",
        "rejected_adjacent_owner": "strongest adjacent alternative and why rejected",
    }
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "inventory_sha256": shared._stable_sha256(bundle),
        "compared_error_keys": [item["error_key"] for item in bundle["local_errors"]],
        "proposal_status": "candidate or none",
        "proposal_error_key": "one exact compared key or null",
        "proposal_step": "integer Step or null",
        "boundary_class": "one allowed boundary class",
        "proposal_prediction": prediction_schema,
        "probe_assessment": "explicit probe/materiality audit",
        "recovery_assessment": "explicit recovery/mechanical/propagation/symptom audit",
        "chronology_comparison": "selected row versus plausible earlier/later rows",
        "critical_boundary_basis": "why this is the single benchmark boundary",
        "selection_falsifier": "strongest concrete argument against selection",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_50_VERSION}: factorized global proposal.

{_boundary(manifest=manifest, cohort=cohort, reads=(bundle_file,), output=output)}

{_GLOBAL_RULES}

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

For none, set proposal_error_key/proposal_step/proposal_prediction null and
boundary_class none. For candidate, exact-copy Step/module/type/evidence from
the selected inventory row. After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _load_anchor_bundle(
    manifest: Path,
    cohort: Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> tuple[Path, Path, Path, dict[str, Any], dict[str, Any], dict[str, Any]]:
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    anchor, ledger, checkpoint = shared._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    parent._validate_packet_state_ledgers(ledger_file)
    return anchor_file, ledger_file, checkpoint_file, anchor, ledger, checkpoint


def _validate_optional_duel_literal(
    *, case: Any, step: Any, quote: Any, location: str
) -> None:
    if step is None and quote is None:
        return
    if isinstance(step, bool) or not isinstance(step, int):
        shared._fail("invalid_factorized_duel_literal_step", location)
    if step < 1 or step > len(case.judge_view.steps):
        shared._fail("invalid_factorized_duel_literal_step", location)
    shared._nonempty_text(quote, location=f"{location}.quote", maximum=1800)
    if not any(quote in source for source in shared._packet_sources(case, step)):
        shared._fail("invalid_factorized_duel_literal_quote", location)


def _validate_duel_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    bundle: dict[str, Any],
    proposal: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != DUEL_FIELDS:
        shared._fail("invalid_factorized_proposal_duel_schema", location)
    if (
        raw["trajectory_id"] != case.trajectory_id
        or raw["trajectory_sha256"] != case.trajectory_sha256
    ):
        shared._fail("factorized_proposal_duel_identity_mismatch", location)
    bindings = {
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "inventory_sha256": shared._stable_sha256(bundle),
        "proposal_sha256": shared._stable_sha256(proposal),
    }
    if any(raw[key] != value for key, value in bindings.items()):
        shared._fail("factorized_proposal_duel_hash_mismatch", location)
    if raw["proposal"] != proposal:
        shared._fail("factorized_proposal_duel_snapshot_mismatch", location)
    proposal_prediction = proposal["proposal_prediction"]
    proposal_step = proposal["proposal_step"]
    if (
        raw["anchor_step"] != anchor["predicted_step"]
        or raw["proposal_step"] != proposal_step
    ):
        shared._fail("factorized_proposal_duel_step_binding_mismatch", location)
    if raw["decision"] not in DUEL_DECISIONS:
        shared._fail("invalid_factorized_proposal_duel_decision", location)
    if raw["anchor_classification"] not in ANCHOR_CLASSES:
        shared._fail("invalid_factorized_anchor_classification", location)
    if raw["proposal_classification"] not in PROPOSAL_CLASSES:
        shared._fail("invalid_factorized_proposal_classification", location)
    for field in (
        "anchor_assessment",
        "proposal_assessment",
        "timeline_comparison",
        "decision_basis",
        "rejected_alternative_basis",
        "selection_falsifier",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3400)
    anchor_prefix = (
        f"anchor_status={raw['anchor_classification']}; contribution_witness="
    )
    proposal_prefix = f"proposal_status={raw['proposal_classification']}; "
    if not raw["anchor_assessment"].startswith(anchor_prefix):
        shared._fail("missing_factorized_anchor_assessment_prefix", location)
    if not raw["proposal_assessment"].startswith(proposal_prefix):
        shared._fail("missing_factorized_proposal_assessment_prefix", location)
    selected = shared._validate_prediction_record(
        raw["selected_prediction"], case=case, location=f"{location}.selected"
    )
    if raw["selected_prediction_sha256"] != shared._stable_sha256(selected):
        shared._fail("factorized_duel_selected_hash_mismatch", location)
    if raw["frozen_step"] != selected["predicted_step"]:
        shared._fail("factorized_duel_frozen_step_mismatch", location)
    witness_fields = (
        "anchor_veto_evidence_step",
        "anchor_veto_evidence_quote",
        "anchor_contribution_witness_step",
        "anchor_contribution_witness_quote",
    )
    if raw["decision"] == "keep_anchor":
        if selected != anchor or any(raw[field] is not None for field in witness_fields):
            shared._fail("factorized_duel_keep_copy_mismatch", location)
        expected_witness = "not_applicable"
        if proposal_prediction is None and raw["proposal_classification"] != "absent":
            shared._fail("factorized_duel_missing_absent_classification", location)
    else:
        if (
            proposal_prediction is None
            or proposal_step == anchor["predicted_step"]
            or selected != proposal_prediction
            or raw["proposal_classification"] != "critical_root"
        ):
            shared._fail("factorized_duel_proposal_copy_mismatch", location)
        if raw["anchor_classification"] not in OVERRIDE_ANCHOR_CLASSES:
            shared._fail("factorized_duel_lacks_anchor_veto", location)
        _validate_optional_duel_literal(
            case=case,
            step=raw["anchor_veto_evidence_step"],
            quote=raw["anchor_veto_evidence_quote"],
            location=f"{location}.anchor_veto",
        )
        if raw["anchor_veto_evidence_step"] is None:
            shared._fail("factorized_duel_missing_veto_evidence", location)
        if raw["anchor_classification"] == "contributing_probe":
            _validate_optional_duel_literal(
                case=case,
                step=raw["anchor_contribution_witness_step"],
                quote=raw["anchor_contribution_witness_quote"],
                location=f"{location}.contribution_witness",
            )
            if raw["anchor_contribution_witness_step"] is None:
                shared._fail("factorized_duel_missing_contribution_witness", location)
            expected_witness = "present"
        else:
            if (
                raw["anchor_contribution_witness_step"] is not None
                or raw["anchor_contribution_witness_quote"] is not None
            ):
                shared._fail("inactive_factorized_contribution_witness", location)
            expected_witness = "not_applicable"
    if not raw["anchor_assessment"].startswith(
        anchor_prefix + expected_witness + "; "
    ):
        shared._fail("invalid_factorized_contribution_prefix", location)
    return raw


def validate_duel(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    bundle_path: str | Path,
    proposal_path: str | Path,
    duel_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    anchor_bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = anchor_bundle[:3]
    anchor, ledger, checkpoint = anchor_bundle[3:]
    bundle_file, bundle_raw = shared._load_artifact(bundle_path, role="inventory bundle")
    bundle = shared._one_record(bundle_raw, role="inventory bundle")
    _validate_bundle_record(bundle, case=case, location="inventory_bundle[0]")
    proposal_file, proposal_raw = shared._load_artifact(
        proposal_path, role="global proposal"
    )
    proposal = shared._one_record(proposal_raw, role="global proposal")
    _validate_proposal_record(
        proposal, case=case, bundle=bundle, location="proposal[0]"
    )
    duel_file, duel_raw = shared._load_artifact(duel_path, role="proposal duel")
    duel = shared._one_record(duel_raw, role="proposal duel")
    _validate_duel_record(
        duel,
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        bundle=bundle,
        proposal=proposal,
        location="duel[0]",
    )
    return _retag(
        {
            "schema_version": "agentdebug.factorized-proposal-duel-audit.v1",
            "stage": "bounded_factorized_proposal_duel",
            "gold_free_validation": True,
            "case_count": 1,
            "decision": duel["decision"],
            "selected_prediction_exact_copy": True,
            "maximum_total_predictions": 2,
            "positive_contribution_witness_binding": True,
            "input_sha256": {
                "anchor": shared._file_sha256(anchor_file),
                "ledger": shared._file_sha256(ledger_file),
                "checkpoint": shared._file_sha256(checkpoint_file),
                "inventory": shared._file_sha256(bundle_file),
                "proposal": shared._file_sha256(proposal_file),
            },
            "output_sha256": {SELECTOR_FILENAME: shared._file_sha256(duel_file)},
        },
        policy="bounded_factorized_global_proposal_exact_copy_duel",
    )


def build_duel_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    bundle_path: str | Path,
    proposal_path: str | Path,
    duel_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    anchor_bundle = _load_anchor_bundle(
        manifest, cohort, anchor_path, ledger_path, checkpoint_path
    )
    anchor_file, ledger_file, checkpoint_file = anchor_bundle[:3]
    anchor, ledger, checkpoint = anchor_bundle[3:]
    bundle_file, bundle_raw = shared._load_artifact(bundle_path, role="inventory bundle")
    bundle = shared._one_record(bundle_raw, role="inventory bundle")
    _validate_bundle_record(bundle, case=case, location="inventory_bundle[0]")
    proposal_file, proposal_raw = shared._load_artifact(
        proposal_path, role="global proposal"
    )
    proposal = shared._one_record(proposal_raw, role="global proposal")
    _validate_proposal_record(
        proposal, case=case, bundle=bundle, location="proposal[0]"
    )
    output = Path(duel_path).expanduser().resolve()
    shared._assert_safe_path(output, role="factorized proposal duel output", is_output=True)
    audit = output.parent / SELECTOR_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_50_clean_v3p20_factorized_local_inventory_global_proposal_duel",
            "--compact-validate",
            "duel",
            manifest,
            cohort,
            anchor_file,
            ledger_file,
            checkpoint_file,
            bundle_file,
            proposal_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "inventory_sha256": shared._stable_sha256(bundle),
        "proposal_sha256": shared._stable_sha256(proposal),
        "proposal": proposal,
        "anchor_step": anchor["predicted_step"],
        "proposal_step": proposal["proposal_step"],
        "decision": "keep_anchor or select_proposal",
        "anchor_classification": "one allowed anchor class",
        "proposal_classification": "one allowed proposal class",
        "anchor_veto_evidence_step": "literal veto Step or null",
        "anchor_veto_evidence_quote": "literal veto quote or null",
        "anchor_contribution_witness_step": "literal contribution Step or null",
        "anchor_contribution_witness_quote": "literal contribution quote or null",
        "frozen_step": "selected prediction Step",
        "selected_prediction_sha256": "stable hash of exact selected prediction",
        "selected_prediction": "exact anchor or proposal prediction object",
        "anchor_assessment": "anchor_status=<class>; contribution_witness=<present|not_applicable>; assessment",
        "proposal_assessment": "proposal_status=<class>; assessment",
        "timeline_comparison": "literal pairwise chronology",
        "decision_basis": "why selected boundary wins",
        "rejected_alternative_basis": "why the other boundary loses",
        "selection_falsifier": "strongest concrete argument against decision",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_50_VERSION}: bounded proposal duel.

{_boundary(manifest=manifest, cohort=cohort, reads=(anchor_file, ledger_file, checkpoint_file, bundle_file, proposal_file), output=output)}

{_DUEL_RULES}

The immutable anchor Step is {anchor['predicted_step']}; the proposal Step is
{proposal['proposal_step']}. Exact-copy the displayed proposal object into the
proposal field. For keep_anchor exact-copy anchor into selected_prediction and
set all four veto/contribution witness fields null. For select_proposal
exact-copy proposal_prediction and satisfy every witness binding.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

Compute hashes from sorted compact UTF-8 JSON. After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _validate_aggregate(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(prediction_manifest_path, cohort_manifest_path)
    root = Path(predictions_path).expanduser().resolve().parent
    names = (
        ANCHOR_PREDICTIONS_FILENAME,
        ANCHOR_LEDGER_AGGREGATE_FILENAME,
        ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        PANELS_FILENAME,
        SELECTORS_FILENAME,
    )
    loaded = {
        name: shared._load_artifact(root / name, role=f"merged {name}")[1]
        for name in names
    }
    if any(
        not isinstance(value, list) or len(value) != len(cases)
        for value in loaded.values()
    ):
        shared._fail("invalid_factorized_aggregate_count", "all artifacts need all cases")
    finals = shared._load_artifact(predictions_path, role="merged predictions")[1]
    if not isinstance(finals, list) or len(finals) != len(cases):
        shared._fail("invalid_factorized_prediction_count", "predictions need all cases")
    local_error_counts: list[int] = []
    statuses: Counter[str] = Counter()
    boundaries: Counter[str] = Counter()
    decisions: Counter[str] = Counter()
    anchor_classes: Counter[str] = Counter()
    for index, case in enumerate(cases):
        location = f"factorized_merged[{index}]"
        anchor = loaded[ANCHOR_PREDICTIONS_FILENAME][index]
        ledger = loaded[ANCHOR_LEDGER_AGGREGATE_FILENAME][index]
        checkpoint = loaded[ANCHOR_CHECKPOINT_AGGREGATE_FILENAME][index]
        bundle = loaded[PANELS_FILENAME][index]
        duel = loaded[SELECTORS_FILENAME][index]
        shared._validate_prediction_record(anchor, case=case, location=f"{location}.anchor")
        if (
            ledger.get("trajectory_id") != case.trajectory_id
            or ledger.get("selected_step") != anchor["predicted_step"]
            or checkpoint.get("trajectory_id") != case.trajectory_id
            or checkpoint.get("predicted_step") != anchor["predicted_step"]
        ):
            shared._fail("factorized_anchor_sidecar_mismatch", location)
        _validate_bundle_record(bundle, case=case, location=f"{location}.inventory")
        proposal = duel.get("proposal") if isinstance(duel, dict) else None
        _validate_proposal_record(
            proposal, case=case, bundle=bundle, location=f"{location}.proposal"
        )
        _validate_duel_record(
            duel,
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            bundle=bundle,
            proposal=proposal,
            location=f"{location}.duel",
        )
        final = shared._validate_prediction_record(
            finals[index], case=case, location=f"{location}.final"
        )
        if final != duel["selected_prediction"]:
            shared._fail("factorized_final_copy_mismatch", location)
        local_error_counts.append(bundle["local_error_count"])
        statuses[proposal["proposal_status"]] += 1
        boundaries[proposal["boundary_class"]] += 1
        decisions[duel["decision"]] += 1
        anchor_classes[duel["anchor_classification"]] += 1
    return {
        "required": True,
        "valid": True,
        "anchor_blind_local_inventories": True,
        "complete_module_and_step_coverage": True,
        "profiles_are_evidence_inventory_not_votes": True,
        "anchor_blind_global_compression": True,
        "maximum_specialist_candidates": 1,
        "maximum_total_predictions": 2,
        "default_anchor_policy": True,
        "positive_contribution_witness_binding": True,
        "all_selected_predictions_exact_copies": True,
        "total_local_error_rows": sum(local_error_counts),
        "nonempty_inventory_case_count": sum(count > 0 for count in local_error_counts),
        "proposal_status_counts": dict(sorted(statuses.items())),
        "boundary_class_counts": dict(sorted(boundaries.items())),
        "selector_decision_counts": dict(sorted(decisions.items())),
        "anchor_classification_counts": dict(sorted(anchor_classes.items())),
        "packet_state_closure": parent._validate_packet_state_ledgers(
            root / ANCHOR_LEDGER_AGGREGATE_FILENAME
        ),
    }


def validate_agent_judge_luna_gaia_v3_50_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    factorized = _validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_50_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_50_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_50_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_50_REASONING_EFFORT,
        "selection_policy": "clean_v3_20_factorized_local_inventory_global_proposal_duel",
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one factorized local-inventory global proposal duel",
        "anchor_semantics_unchanged_from_v3_20": True,
        "all_selected_predictions_exact_copies": True,
        "factorized_specialist_panel": factorized,
    }


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_profile_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_profile(*paths[:-1]), paths[-1])


def validate_and_write_global_proposal_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_global_proposal(*paths[:-1]), paths[-1])


def validate_and_write_duel_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_duel(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_50_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_50_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_luna_gaia_v3_50_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_duel_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / PANEL_FILENAME,
        prediction.parent / PROPOSAL_FILENAME,
        prediction.parent / SELECTOR_FILENAME,
    )


validate_and_write_agent_judge_luna_gaia_v3_37_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_50_audit
)
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_luna_gaia_v3_50_task
build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_50_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_50_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_50_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "profile" and len(paths) == 5:
            audit = validate_and_write_profile_audit(*paths)
        elif stage == "proposal" and len(paths) == 5:
            audit = validate_and_write_global_proposal_audit(*paths)
        elif stage == "duel" and len(paths) == 9:
            audit = validate_and_write_duel_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_50_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except (shared.AgentJudgeValidationError, json.JSONDecodeError, OSError) as error:
        code = getattr(error, "code", type(error).__name__)
        print(json.dumps({"ok": False, "code": code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument(
        "stage", choices=("anchor", "profile", "proposal", "duel", "prediction")
    )
    parser.add_argument("paths", nargs="+")
    args = parser.parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

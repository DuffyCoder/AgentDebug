"""Official-faithful local Phase 1 followed by positive-only joint Phase 2."""

from __future__ import annotations

import json
import shlex
from pathlib import Path
from typing import Any, Mapping, Sequence

from agentdebug.benchmark.prediction_manifest import load_prediction_manifest

from .agent_judge import (
    AgentJudgeValidationError,
    _assert_gold_free,
    _file_sha256,
    _load_json,
)
from .agent_judge_gaia_official_phase2 import (
    build_phase2_task as _build_phase2_task,
    validate_predictions as _validate_predictions,
)
from .agent_judge_sol_gaia_forced_census import (
    _write_audit,
    _write_json,
    segmented_owner_sources,
)
from .taxonomy import AgentModule, TAXONOMY


VERSION = "agentdebug.codex-agent-judge.gaia-faithful-local-v1"
PHASE1_MODEL = "gpt-5.6-luna"
PHASE1_REASONING_EFFORT = "medium"
PHASE2_MODEL = "gpt-5.5"
PHASE2_REASONING_EFFORT = "xhigh"
PHASE1_MODULES = (
    AgentModule.MEMORY,
    AgentModule.REFLECTION,
    AgentModule.PLANNING,
    AgentModule.ACTION,
)
LOCAL_INPUT_FILENAME = "official-local-input.json"
LOCAL_REVIEW_FILENAME = "official-local-reviews.json"
PHASE1_SUMMARY_FILENAME = "phase1-analysis.json"


def _texts(values: Sequence[Any]) -> str:
    return "\n".join(
        value.text for value in values if isinstance(value.text, str) and value.text
    )


def _sources(case: Any, step_number: int, module: AgentModule) -> str:
    error_type = next(iter(TAXONOMY[module]))
    return "\n".join(
        segmented_owner_sources(case.judge_view, step_number, module, error_type)
    )


def _local_projection(case: Any) -> list[dict[str, Any]]:
    steps: list[dict[str, Any]] = []
    for number, step in enumerate(case.judge_view.steps, 1):
        current = _texts(step.current_input)
        feedback = "\n".join(
            item.incremental_text for item in step.adjacent_feedback
            if item.incremental_text
        )[:500]
        outputs = {
            module.value: _sources(case, number, module)
            for module in PHASE1_MODULES
        }
        steps.append(
            {
                "step": number,
                "current_step_input": current,
                "same_step_outputs": outputs,
                "environment_response": feedback,
            }
        )
    return steps


def write_local_input(
    prediction_manifest_path: str | Path, output_path: str | Path
) -> dict[str, Any]:
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    _, cases = load_prediction_manifest(prediction)
    if len(cases) != 1:
        raise ValueError("faithful local input requires one case")
    case = cases[0]
    value = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "task_description": case.judge_view.task.user_request,
        "environment": "gaia",
        "steps": _local_projection(case),
    }
    output = Path(output_path).expanduser().resolve()
    _write_json(output, value)
    return validate_local_input(prediction, output)


def validate_local_input(
    prediction_manifest_path: str | Path, input_path: str | Path
) -> dict[str, Any]:
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    local = Path(input_path).expanduser().resolve()
    _, cases = load_prediction_manifest(prediction)
    value = _load_json(local, role="official local input")
    expected = {
        "trajectory_id": cases[0].trajectory_id,
        "trajectory_sha256": cases[0].trajectory_sha256,
        "task_description": cases[0].judge_view.task.user_request,
        "environment": "gaia",
        "steps": _local_projection(cases[0]),
    }
    _assert_gold_free(value, location="official local input")
    if len(cases) != 1 or value != expected:
        raise ValueError("official local input is not the exact projection")
    return {
        "agent_judge_version": VERSION,
        "stage": "deterministic-official-local-input",
        "gold_free_validation": True,
        "case_count": 1,
        "future_step_fields_excluded_from_each_step": True,
        "environment_response_max_chars": 500,
        "output_sha256": {local.name: _file_sha256(local)},
    }


def validate_local_reviews(
    prediction_manifest_path: str | Path,
    local_input_path: str | Path,
    reviews_path: str | Path,
    module: AgentModule | str,
) -> dict[str, Any]:
    selected = AgentModule(module)
    if selected not in PHASE1_MODULES:
        raise ValueError("official Phase1 uses four assistant modules")
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    local = Path(local_input_path).expanduser().resolve()
    output = Path(reviews_path).expanduser().resolve()
    validate_local_input(prediction, local)
    _, cases = load_prediction_manifest(prediction)
    case = cases[0]
    value = _load_json(output, role="official local reviews")
    _assert_gold_free(value, location="official local reviews")
    if not isinstance(value, list) or len(value) != 1:
        raise ValueError("one local review row required")
    row = value[0]
    if not isinstance(row, Mapping) or set(row) != {
        "trajectory_id", "trajectory_sha256", "status", "module", "reviews"
    }:
        raise ValueError("invalid local review row")
    if (
        row["trajectory_id"] != case.trajectory_id
        or row["trajectory_sha256"] != case.trajectory_sha256
        or row["status"] != "success"
        or row["module"] != selected.value
    ):
        raise ValueError("invalid local review identity")
    reviews = row["reviews"]
    if not isinstance(reviews, list) or len(reviews) != len(case.judge_view.steps):
        raise ValueError("every step must have one local review")
    errors = 0
    for number, review in enumerate(reviews, 1):
        if not isinstance(review, Mapping) or set(review) != {
            "step", "error_detected", "error_type", "evidence_quote", "reasoning"
        } or review["step"] != number:
            raise ValueError("invalid local review schema/order")
        if not isinstance(review["reasoning"], str) or not review["reasoning"].strip():
            raise ValueError("local review reasoning is required")
        if number == 1 and selected in {AgentModule.MEMORY, AgentModule.REFLECTION}:
            if review["error_detected"] or review["error_type"] != "no_error" or review["evidence_quote"] is not None:
                raise ValueError("Step1 memory/reflection must be skipped")
            continue
        if review["error_detected"] is False:
            if review["error_type"] != "no_error" or review["evidence_quote"] is not None:
                raise ValueError("negative review fields are invalid")
            continue
        if review["error_detected"] is not True:
            raise ValueError("error_detected must be boolean")
        if review["error_type"] not in {item.value for item in TAXONOMY[selected]}:
            raise ValueError("illegal module/type pair")
        quote = review["evidence_quote"]
        sources = segmented_owner_sources(
            case.judge_view, number, selected, next(iter(TAXONOMY[selected]))
        )
        if not isinstance(quote, str) or not quote.strip() or not any(quote in source for source in sources):
            raise ValueError("positive evidence must be literal selected-module text")
        errors += 1
    return {
        "agent_judge_version": VERSION,
        "stage": f"official-local-{selected.value}",
        "model": PHASE1_MODEL,
        "reasoning_effort": PHASE1_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": 1,
        "review_count": len(reviews),
        "positive_error_count": errors,
        "local_temporal_information_contract": True,
        "output_sha256": {output.name: _file_sha256(output)},
    }


def validate_and_write_local_review_audit(*args: Any) -> dict[str, Any]:
    try:
        audit = validate_local_reviews(*args[:-1])
    except ValueError as error:
        raise AgentJudgeValidationError(
            "invalid_official_local_review", str(error)
        ) from error
    return _write_audit(args[-1], audit)


def _taxonomy(module: AgentModule) -> str:
    return "\n".join(
        f"- {kind.value}: {definition}"
        for kind, definition in TAXONOMY[module].items()
    )


def _command(function: str, *args: Any) -> str:
    rendered = ", ".join(repr(str(item)) for item in args)
    code = (
        "import json; from agentdebug.diagnostics.agent_judge_gaia_faithful_local "
        f"import {function} as run; print(json.dumps(run({rendered}), "
        "ensure_ascii=False, indent=2))"
    )
    return "PYTHONPATH=. python3 -c " + shlex.quote(code)


def build_local_review_task(
    prediction_manifest_path: str | Path,
    local_input_path: str | Path,
    reviews_path: str | Path,
    module: AgentModule | str,
) -> str:
    selected = AgentModule(module)
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    local = Path(local_input_path).expanduser().resolve()
    output = Path(reviews_path).expanduser().resolve()
    audit = output.parent / "official-local-review-audit.json"
    validate_local_input(prediction, local)
    schema = [{
        "trajectory_id": "exact local input ID",
        "trajectory_sha256": "exact local input hash",
        "status": "success",
        "module": selected.value,
        "reviews": [{
            "step": "every integer 1..N in order",
            "error_detected": "boolean",
            "error_type": "legal type or no_error",
            "evidence_quote": "literal module output substring or null",
            "reasoning": "official-definition local reasoning",
        }],
    }]
    upstream = {
        AgentModule.MEMORY: "current_step_input only",
        AgentModule.REFLECTION: "current_step_input + same_step_outputs.memory",
        AgentModule.PLANNING: "current_step_input + same_step_outputs.memory and reflection",
        AgentModule.ACTION: "current_step_input + same_step_outputs.planning",
    }[selected]
    command = _command(
        "validate_and_write_local_review_audit",
        prediction, local, output, selected.value, audit,
    )
    return f"""Run the official-faithful local Phase1 {selected.value} reviewer.

CONFIG: protocol={VERSION}; model={PHASE1_MODEL}; reasoning_effort={PHASE1_REASONING_EFFORT}; one isolated trajectory; no network, gold, scores, prior predictions, future-step inference, or cross-case state.

Read the deterministic local input only: {local}
Write only: {output}

For EACH step, make an independent local judgment using only that step object's fields. Never use a later step when reviewing an earlier one.
MODULE TO ANALYZE: {selected.value}
MODULE OUTPUT: same_step_outputs.{selected.value}
ALLOWED CONTEXT: {upstream}
FOLLOWING RESPONSE: environment_response (already truncated to official 500 characters)

Evaluate whether the module output matches one exact definition:
{_taxonomy(selected)}

Official rules: same-step modules build in information-flow order; an absent module is no_error; Step1 Memory/Reflection must be no_error; evidence for a positive must be a literal substring of this module's output. Do not judge global criticality, recovery, cascading effects, or future outcomes. Negative reasoning is still required but will not be shown to Phase2.

Write exactly:
{json.dumps(schema, ensure_ascii=False, indent=2)}

Then run:
cd {Path(__file__).resolve().parents[2]}
{command}
"""


def write_positive_phase1_summary(
    prediction_manifest_path: str | Path,
    review_paths: Sequence[str | Path],
    summary_path: str | Path,
) -> dict[str, Any]:
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    _, cases = load_prediction_manifest(prediction)
    case = cases[0]
    if len(review_paths) != 4:
        raise ValueError("four official local review paths required")
    loaded: dict[AgentModule, list[Mapping[str, Any]]] = {}
    for module, raw in zip(PHASE1_MODULES, review_paths, strict=True):
        path = Path(raw).expanduser().resolve()
        validate_local_reviews(prediction, path.parent / LOCAL_INPUT_FILENAME, path, module)
        loaded[module] = _load_json(path, role="official local reviews")[0]["reviews"]
    steps = []
    for number, step in enumerate(case.judge_view.steps, 1):
        errors = {}
        for module in PHASE1_MODULES:
            review = loaded[module][number - 1]
            if review["error_detected"]:
                errors[module.value] = {
                    "error_detected": True,
                    "error_type": review["error_type"],
                    "evidence": review["evidence_quote"],
                    "reasoning": review["reasoning"],
                }
        steps.append({
            "step": number,
            "agent_output": step.assistant_raw_output,
            "environment_response": "\n".join(
                item.incremental_text for item in step.adjacent_feedback if item.incremental_text
            )[:500],
            "errors": errors,
        })
    value = [{
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        "phase1_protocol": VERSION,
        "steps": steps,
    }]
    output = Path(summary_path).expanduser().resolve()
    _write_json(output, value)
    _assert_gold_free(value, location="positive-only Phase1 summary")
    return {
        "agent_judge_version": VERSION,
        "stage": "positive-only-official-phase1-merge",
        "gold_free_validation": True,
        "case_count": 1,
        "positive_error_count": sum(len(item["errors"]) for item in steps),
        "negative_reviews_visible_to_phase2": False,
        "environment_response_max_chars": 500,
        "output_sha256": {output.name: _file_sha256(output)},
    }


def validate_predictions(*args: str | Path) -> dict[str, Any]:
    value = _validate_predictions(*args)
    return {
        **value,
        "agent_judge_version": VERSION,
        "model": PHASE2_MODEL,
        "reasoning_effort": PHASE2_REASONING_EFFORT,
        "stage": "faithful-local-positive-only-joint-phase2",
    }


def validate_and_write_prediction_audit(*args: str | Path) -> dict[str, Any]:
    return _write_audit(args[-1], validate_predictions(*args[:-1]))


def build_phase2_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    task = _build_phase2_task(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    prediction = Path(prediction_manifest_path).expanduser().resolve()
    cohort = Path(cohort_manifest_path).expanduser().resolve()
    output = Path(predictions_path).expanduser().resolve()
    audit = output.parent / "prediction-audit.json"
    task = (
        task.replace("agentdebug.codex-agent-judge.gaia-official-phase2-v1", VERSION)
        .replace("model=gpt-5.5", f"model={PHASE2_MODEL}")
        .replace("reasoning_effort=xhigh", f"reasoning_effort={PHASE2_REASONING_EFFORT}")
        .replace(
            "and all five module reviews with\nerror type, evidence, reasoning, causal relevance, and recovery.",
            "and only the positive official-local module reviews with error type, evidence, and reasoning. Negative reviews are intentionally omitted.",
        )
    )
    old = "PYTHONPATH=. python3 -c " + shlex.quote(
        "import json; from agentdebug.diagnostics.agent_judge_gaia_official_phase2 import "
        "validate_and_write_prediction_audit as run; print(json.dumps(run("
        + ", ".join(repr(str(x)) for x in (prediction, cohort, output, audit))
        + "), ensure_ascii=False, indent=2))"
    )
    new = _command(
        "validate_and_write_prediction_audit", prediction, cohort, output, audit
    )
    return task.replace(old, new)


build_protocol_task = build_phase2_task

"""Luna GAIA v3.6: v3.5.1 plus positive Action materiality."""

from __future__ import annotations

import argparse
import json
import os
import shlex
from pathlib import Path
from typing import Any, Sequence

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
)
from .agent_judge_luna_gaia_v3 import STEP_FREEZE_FIELDS, STEP_FREEZE_FILENAME
from .agent_judge_luna_gaia_v3_4 import (
    STEP_CANDIDATE_LEDGER_FIELDS,
    STEP_CANDIDATE_LEDGER_FILENAME,
    STEP_CANDIDATE_LANES,
    STEP_CANDIDATE_ROW_FIELDS,
    STEP_CANDIDATE_STATUSES,
)
from .agent_judge_luna_gaia_v3_5_1 import (
    AGENT_JUDGE_LUNA_GAIA_V3_5_1_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_LUNA_GAIA_V3_5_1_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_5_1_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_5_1_VERSION,
    build_agent_judge_luna_gaia_v3_5_1_task,
    validate_agent_judge_luna_gaia_v3_5_1_predictions,
)


AGENT_JUDGE_LUNA_GAIA_V3_6_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.6"
)
AGENT_JUDGE_LUNA_GAIA_V3_6_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_5_1_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_6_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_5_1_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_6_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_5_1_AUDIT_SCHEMA_VERSION
)


_POSITIVE_ACTION_MATERIALITY_GATE = """\
POSITIVE ACTION MATERIALITY GATE

Apply this gate only to the Lane-B Action operation/argument/type subcheck.  It
does not change source constraints, prerequisites, plan capability or target,
Lane A, the System packet fence, Lane C, owner/type assignment, or any existing
recovery veto.

When an Action value is serialized with a type different from the documented
schema, close the action's adjacent result before deciding materiality.  Admit
an Action candidate only if at least one of these is literal:

- the tool rejects the operation or argument because of the mismatch;
- coercion would change the requested operation or the semantic value; or
- a false state later consumes a malformed value or corrupted result.

A normal successful invocation with an expected-shape, semantically usable
result demonstrates that a safely coercible serialization mismatch was
tolerated.  In that situation the type spelling alone is not a concrete
material breakpoint and Lane B must remain clear for that reason.  In
particular, a numeric string accepted as the intended integer is not a
`parameter_error` merely because the documented schema says `int`.

If the tool literally rejects the mismatched argument, retain the existing
narrow `veto_mechanical_repair` rule when a successful alternate route fully
replaces it before false state consumes it.  Do not use successful coercion to
excuse an invalid operation name, a missing required argument, a non-coercible
semantic value, or an Action that fails to pursue an otherwise adequate plan.

Whenever a type mismatch is considered, state in the ledger row's
`decision_basis` whether adjacent execution rejected it, tolerated it with a
normal result, changed its semantics, or allowed false-state consumption.

"""


def _replace_validation_command_with_cli(
    task: str,
    *,
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    lines = task.splitlines()
    indexes = [
        index
        for index, line in enumerate(lines)
        if line.startswith("PYTHONPATH=. python3 -c ")
        and "run_agent_judge_luna_gaia_v3_5_1_compact_validation" in line
    ]
    if len(indexes) != 1:
        raise RuntimeError("Luna GAIA v3.5.1 validation command changed unexpectedly")
    prediction = Path(predictions_path).expanduser().resolve()
    paths = (
        Path(prediction_manifest_path).expanduser().resolve(),
        Path(cohort_manifest_path).expanduser().resolve(),
        prediction,
        prediction.parent / "prediction-audit.json",
    )
    arguments = " ".join(shlex.quote(str(path)) for path in paths)
    lines[indexes[0]] = (
        "PYTHONPATH=. python3 -m "
        "agentdebug.diagnostics.agent_judge_luna_gaia_v3_6 "
        f"--compact-validate {arguments}"
    )
    return "\n".join(lines) + ("\n" if task.endswith("\n") else "")


def build_agent_judge_luna_gaia_v3_6_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build v3.5.1 with one Action-materiality semantic gate."""

    task = build_agent_judge_luna_gaia_v3_5_1_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    task = task.replace(
        AGENT_JUDGE_LUNA_GAIA_V3_5_1_VERSION,
        AGENT_JUDGE_LUNA_GAIA_V3_6_VERSION,
    )
    task = task.replace(
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_5_1.py",
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_6.py",
    )
    lane_c = "LANE C — STRATEGY EPOCHS AND TERMINAL ABANDONMENT\n"
    if task.count(lane_c) != 1:
        raise RuntimeError("Luna GAIA v3.5.1 lane-C boundary changed unexpectedly")
    task = task.replace(
        lane_c,
        _POSITIVE_ACTION_MATERIALITY_GATE + lane_c,
        1,
    )
    return _replace_validation_command_with_cli(
        task,
        prediction_manifest_path=prediction_manifest_path,
        cohort_manifest_path=cohort_manifest_path,
        predictions_path=predictions_path,
    )


def validate_agent_judge_luna_gaia_v3_6_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_5_1_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_6_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_6_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_6_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_6_REASONING_EFFORT,
        "selection_policy": (
            "lane_ordered_chronology_validated_step_only_candidate_ledger_"
            "limited_recovery_veto_external_exception_packet_fence_"
            "positive_immediate_subgoal_capability_gate_"
            "positive_action_materiality_gate"
        ),
        "positive_action_materiality_gate": (
            "rejection_semantic_change_or_false_state_consumption_required"
        ),
    }


def validate_and_write_agent_judge_luna_gaia_v3_6_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_6_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


def run_agent_judge_luna_gaia_v3_6_compact_validation(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> int:
    try:
        audit = validate_and_write_agent_judge_luna_gaia_v3_6_audit(
            prediction_manifest_path,
            cohort_manifest_path,
            predictions_path,
            audit_path,
        )
    except AgentJudgeValidationError as error:
        print(
            json.dumps(
                {
                    "valid": False,
                    "error_code": error.code,
                    "error_message": str(error),
                },
                ensure_ascii=False,
            )
        )
        return 1
    except Exception as error:  # pragma: no cover - last-resort observability
        print(
            json.dumps(
                {
                    "valid": False,
                    "error_code": "unexpected_validation_error",
                    "error_message": f"{type(error).__name__}: {error}",
                },
                ensure_ascii=False,
            )
        )
        return 2
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("paths", nargs=4)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("--compact-validate is required")
    return run_agent_judge_luna_gaia_v3_6_compact_validation(*args.paths)


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "AGENT_JUDGE_LUNA_GAIA_V3_6_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_GAIA_V3_6_MODEL",
    "AGENT_JUDGE_LUNA_GAIA_V3_6_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_GAIA_V3_6_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "STEP_CANDIDATE_LEDGER_FIELDS",
    "STEP_CANDIDATE_LEDGER_FILENAME",
    "STEP_CANDIDATE_LANES",
    "STEP_CANDIDATE_ROW_FIELDS",
    "STEP_CANDIDATE_STATUSES",
    "STEP_FREEZE_FIELDS",
    "STEP_FREEZE_FILENAME",
    "build_agent_judge_luna_gaia_v3_6_task",
    "main",
    "run_agent_judge_luna_gaia_v3_6_compact_validation",
    "validate_agent_judge_luna_gaia_v3_6_predictions",
    "validate_and_write_agent_judge_luna_gaia_v3_6_audit",
]

"""GAIA v3.93: clean-v3.83 tournament with audited no-bwrap transport."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent_judge_gaia_v3_92_gpt55_singleton_safe_file_inspected_predicate_handoff_tournament import *  # noqa: F403
from . import agent_judge_gaia_v3_83_clean_v3p20_model_only_gpt55_medium as incumbent
from . import (
    agent_judge_gaia_v3_92_gpt55_singleton_safe_file_inspected_predicate_handoff_tournament as template,
)


AGENT_JUDGE_GAIA_V3_93_VERSION = (
    "agentdebug.codex-agent-judge.gaia-v3.93-gpt55-audited-no-bwrap-"
    "predicate-handoff-tournament"
)
AGENT_JUDGE_GAIA_V3_93_MODEL = incumbent.AGENT_JUDGE_GAIA_V3_83_MODEL
AGENT_JUDGE_GAIA_V3_93_REASONING_EFFORT = incumbent.AGENT_JUDGE_GAIA_V3_83_REASONING_EFFORT
AGENT_JUDGE_GAIA_V3_93_AUDIT_SCHEMA_VERSION = incumbent.AGENT_JUDGE_GAIA_V3_83_AUDIT_SCHEMA_VERSION
SEMANTIC_PARENT = incumbent.AGENT_JUDGE_GAIA_V3_83_VERSION

AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION = AGENT_JUDGE_GAIA_V3_93_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_80_MODEL = AGENT_JUDGE_GAIA_V3_93_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_80_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_93_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_79_VERSION = AGENT_JUDGE_GAIA_V3_93_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_79_MODEL = AGENT_JUDGE_GAIA_V3_93_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_79_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_93_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION = AGENT_JUDGE_GAIA_V3_93_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL = AGENT_JUDGE_GAIA_V3_93_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_93_REASONING_EFFORT
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_GAIA_V3_93_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_GAIA_V3_93_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = AGENT_JUDGE_GAIA_V3_93_REASONING_EFFORT


def _retag_task(task: str) -> str:
    return task.replace(template.AGENT_JUDGE_GAIA_V3_92_VERSION, AGENT_JUDGE_GAIA_V3_93_VERSION)


def build_anchor_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> str:
    return _retag_task(
        template.build_anchor_file_task(prediction_manifest_path, cohort_manifest_path)
    )


def build_reducer_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> str:
    return _retag_task(
        template.build_reducer_file_task(
            prediction_manifest_path,
            cohort_manifest_path,
            anchor_path,
            ledger_path,
            checkpoint_path,
        )
    )


def normalize_anchor_response(response: Any, *, case: Any) -> Any:
    return template.normalize_anchor_response(response, case=case)


def normalize_assessment_response(
    response: Any,
    *,
    anchor: dict[str, Any] | None = None,
    ledger: dict[str, Any] | None = None,
    case: Any | None = None,
) -> Any:
    return template.normalize_assessment_response(
        response, anchor=anchor, ledger=ledger, case=case
    )


def _retag_audit(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_GAIA_V3_93_VERSION,
        "model": AGENT_JUDGE_GAIA_V3_93_MODEL,
        "reasoning_effort": AGENT_JUDGE_GAIA_V3_93_REASONING_EFFORT,
        "selection_policy": policy,
        "semantic_parent": SEMANTIC_PARENT,
        "direct_semantic_parent": SEMANTIC_PARENT,
        "rejected_lineage_inherited": False,
        "explicit_mechanism_sources_only": [
            "v3.80 predicate-handoff tournament",
            "v3.92 Step-invariant legality contract",
        ],
        "single_major_change": (
            "replace accepted v3.83 challenger/arbiter with one outcome-conditioned "
            "predicate-handoff tournament over every native v3.83 ledger Step"
        ),
        "audited_no_bwrap_transport": True,
        "inspector_command_success_required": True,
        "selected_step_invariant_legality_repair": True,
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag_audit(
        template.validate_anchor_predictions(*paths),
        policy="v3p83_anchor_audited_no_bwrap_file_inspected_input",
    )


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])  # noqa: F405


def validate_panel(*paths: str | Path) -> dict[str, Any]:
    return _retag_audit(
        template.validate_panel(*paths),
        policy="audited_no_bwrap_singleton_safe_predicate_handoff_tournament",
    )


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_panel(*paths[:-1]), paths[-1])  # noqa: F405


def build_selection_document(**kwargs: Any) -> dict[str, Any]:
    return template.build_selection_document(**kwargs)


def validate_selector(*paths: str | Path) -> dict[str, Any]:
    return _retag_audit(
        template.validate_selector(*paths),
        policy="deterministic_audited_no_bwrap_tournament_selection_copy",
    )


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_selector(*paths[:-1]), paths[-1])  # noqa: F405


def validate_agent_judge_gaia_v3_93_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    return _retag_audit(
        template.validate_agent_judge_gaia_v3_92_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        policy="audited_no_bwrap_singleton_safe_predicate_handoff_tournament",
    )


def validate_and_write_agent_judge_gaia_v3_93_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(  # noqa: F405
        validate_agent_judge_gaia_v3_93_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_gaia_v3_93_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_reducer_file_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME,  # noqa: F405
        prediction.parent / ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,  # noqa: F405
    )


validate_and_write_agent_judge_luna_gaia_v3_37_audit = validate_and_write_agent_judge_gaia_v3_93_audit
validate_and_write_agent_judge_luna_gaia_v3_67_audit = validate_and_write_agent_judge_gaia_v3_93_audit
validate_and_write_agent_judge_luna_gaia_v3_79_audit = validate_and_write_agent_judge_gaia_v3_93_audit
validate_and_write_agent_judge_luna_gaia_v3_80_audit = validate_and_write_agent_judge_gaia_v3_93_audit
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_gaia_v3_93_task
build_agent_judge_luna_gaia_v3_79_task = build_agent_judge_gaia_v3_93_task
build_agent_judge_luna_gaia_v3_80_task = build_agent_judge_gaia_v3_93_task


def __getattr__(name: str) -> Any:
    return getattr(template, name)


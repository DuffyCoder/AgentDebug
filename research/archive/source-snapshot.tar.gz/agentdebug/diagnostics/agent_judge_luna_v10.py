"""Luna Agent Judge v10: v3 incumbent with three narrow hard vetoes."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_v2_4 import (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION,
    _v2_4_owner_source_resolver,
)
from .agent_judge_luna_v3 import validate_agent_judge_luna_v3_predictions
from .agent_judge_luna_v7 import (
    AGENT_JUDGE_LUNA_V7_MODEL,
    AGENT_JUDGE_LUNA_V7_VERSION,
    INCUMBENT_PROPOSAL_FILENAME,
    _INCUMBENT_REVIEW,
    build_agent_judge_luna_v7_task,
)


AGENT_JUDGE_LUNA_V10_VERSION = "agentdebug.codex-agent-judge.luna-v10"
AGENT_JUDGE_LUNA_V10_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_V10_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_V10_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)

_BASE_HEADER = f"Run the frozen Codex Agent Judge protocol {AGENT_JUDGE_LUNA_V7_VERSION}."
_LUNA_HEADER = (
    "Run the frozen Codex Agent Judge protocol "
    f"{AGENT_JUDGE_LUNA_V10_VERSION}."
)
_BASE_MODEL = f"- model: {AGENT_JUDGE_LUNA_V7_MODEL}"
_LUNA_MODEL = f"- model: {AGENT_JUDGE_LUNA_V10_MODEL}"
_BASE_ALLOWLIST = "agentdebug/diagnostics/agent_judge_luna_v7.py"
_LUNA_ALLOWLIST = "agentdebug/diagnostics/agent_judge_luna_v10.py"
_BASE_VALIDATOR_IMPORT = "agentdebug.diagnostics.agent_judge_luna_v7"
_LUNA_VALIDATOR_IMPORT = "agentdebug.diagnostics.agent_judge_luna_v10"
_BASE_VALIDATOR_ENTRY = "validate_and_write_agent_judge_luna_v7_audit"
_LUNA_VALIDATOR_ENTRY = "validate_and_write_agent_judge_luna_v10_audit"

_HARD_VETO_REVIEW = """
V10 CONSERVATIVE INCUMBENT HARD-VETO REVIEW

The one proposal is a fallible gold-free Luna v3 diagnosis for this trajectory,
not evidence or a label.  Independently verify it against the complete
JudgeView.  Default to KEEP and copy all ten fields exactly.  REPLACE only when
one of the three named hard vetoes below is literally proven.  Do not conduct a
new whole-episode candidate competition.  Step-1 proposals are mandatory KEEP.

HARD VETO A — DISTINCT CONFIRMATION IS NOT REPETITION

A go/open/search/extract operation followed by a different examine/look/detail
operation is not the same repeated action.  One such confirmation is reasonable
when the first result is incomplete or ambiguous.  If the proposal calls this
distinct confirmation `inefficient_plan`, it is invalid and MUST be replaced.
Inspect the output immediately after the confirming feedback.  Select that
next output when it first retains the disproven belief, ignores a task-relevant
object/action newly exposed by the current observation or admissible-action
list, or recommits to a now-known no-progress operation.  Otherwise continue
chronologically to the first mature post-confirmation defect.

HARD VETO B — DISPLAY WRAPPERS ARE NOT PARSER FAILURES

Quotes, explanatory prose, missing/extra visual action tags, or a human-readable
`Choose the action:` wrapper in assistant text do not by themselves prove
`format_error` or `parameter_error`.  They are presentation artifacts unless
the trajectory contains an explicit parser/interface rejection, unavailable
operation, malformed concrete tool argument, or execution error attributable
to that form.  `Nothing happens` alone is not an explicit parser rejection.
If the proposal relies only on display form, it is invalid and MUST be
replaced.  First try SAME-STEP REPAIR: retain its step if another same-step
owner contains the mature causal defect.  Otherwise scan forward for the first
unrecovered Memory/Reflection/Planning/Action error.  Do not select another
display-only syntax complaint.

HARD VETO C — USEFUL RECOVERY VETOES THE EARLY SEARCH COMPLAINT

If the allegedly defective query, pagination, navigation, or recovery action
later yields a genuinely relevant candidate, required evidence, useful detail
page, restored state, or successful equivalent operation, that earlier
search-strategy proposal is fully recovered and MUST be replaced.  Begin the
replacement scan after the useful recovery.  A decisive later boundary is a
PLAN-ACTION HANDOFF: when an adequate same-step plan explicitly says a required
attribute, prerequisite, or fact must be verified before commit, but Action
buys, answers, or changes state without that verification, choose that Action.
Otherwise choose the first mature unrecovered defect in the new epoch.

FINAL SAFETY RAILS

Name exactly KEEP, VETO_A, VETO_B, or VETO_C internally.  If no veto is proven,
KEEP every field.  If a veto is proven, replacement may be earlier, same-step,
or later only as the named rule directs; it may not arise from an unrelated
imperfection.  Reapply v3 ownership, taxonomy, and literal evidence rules after
freezing the replacement.  Never use identifiers, environment names, expected
distributions, other predictions, or gold.  Return only the strict ten-field
record with no verdict or extra field.
"""


def _proposal_path(predictions_path: str | Path) -> Path:
    return Path(predictions_path).expanduser().resolve().parent / INCUMBENT_PROPOSAL_FILENAME


def build_agent_judge_luna_v10_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build the single-v3-incumbent hard-veto review task."""

    task = build_agent_judge_luna_v7_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    replacements = {
        _BASE_HEADER: _LUNA_HEADER,
        _BASE_MODEL: _LUNA_MODEL,
        _BASE_ALLOWLIST: _LUNA_ALLOWLIST,
        _BASE_VALIDATOR_IMPORT: _LUNA_VALIDATOR_IMPORT,
        _BASE_VALIDATOR_ENTRY: _LUNA_VALIDATOR_ENTRY,
        _INCUMBENT_REVIEW.strip(): _HARD_VETO_REVIEW.strip(),
    }
    for old, new in replacements.items():
        if task.count(old) != 1:
            raise RuntimeError(
                "Agent Judge Luna v7 task changed at a frozen v10 marker"
            )
        task = task.replace(old, new, 1)
    return task


def validate_agent_judge_luna_v10_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    proposal_path = _proposal_path(predictions_path)
    incumbent_audit = validate_agent_judge_luna_v3_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        proposal_path,
    )
    audit = _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_v2_4_owner_source_resolver,
    )
    proposal_sha256 = hashlib.sha256(proposal_path.read_bytes()).hexdigest()
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_V10_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_V10_VERSION,
        "model": AGENT_JUDGE_LUNA_V10_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V10_REASONING_EFFORT,
        "incumbent_protocol": "agentdebug.codex-agent-judge.luna-v3",
        "incumbent_proposal_sha256": proposal_sha256,
        "incumbent_proposal_case_count": incumbent_audit["case_count"],
    }


def validate_and_write_agent_judge_luna_v10_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_v10_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


__all__ = [
    "AGENT_JUDGE_LUNA_V10_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_V10_MODEL",
    "AGENT_JUDGE_LUNA_V10_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_V10_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "INCUMBENT_PROPOSAL_FILENAME",
    "build_agent_judge_luna_v10_task",
    "validate_agent_judge_luna_v10_predictions",
    "validate_and_write_agent_judge_luna_v10_audit",
]

"""Luna GAIA v3.42: clean v3.20 with one three-specialist tournament."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions
from .taxonomy import taxonomy_prompt


AGENT_JUDGE_LUNA_GAIA_V3_42_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.42-clean-v3.20-"
    "anchor-blind-three-specialist-tournament"
)
AGENT_JUDGE_LUNA_GAIA_V3_42_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_42_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_42_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases for the shared factorized three-stage execution runner.
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_42_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_42_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_42_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_42_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_42_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_42_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_42_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
PANEL_FILENAME = "three-specialist-panel.json"
PANELS_FILENAME = "three-specialist-panels.json"
PANEL_AUDIT_FILENAME = "three-specialist-panel-audit.json"
SELECTOR_FILENAME = "three-specialist-selector.json"
SELECTORS_FILENAME = "three-specialist-selectors.json"
SELECTOR_AUDIT_FILENAME = "three-specialist-selector-audit.json"

LANES = ("state", "maturity", "alignment")
LANE_PREFIX = {
    "state": "lane=state_truth; candidate_step=",
    "maturity": "lane=post_feedback_maturity; candidate_step=",
    "alignment": "lane=direct_alignment; candidate_step=",
}
PANEL_STATUSES = frozenset({"candidate", "none"})
PANEL_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    *(
        field
        for lane in LANES
        for field in (
            f"{lane}_status",
            f"{lane}_step",
            f"{lane}_prediction",
            f"{lane}_search_summary",
            f"{lane}_falsifier",
        )
    ),
    "cross_lane_comparison",
)
SELECTOR_DECISIONS = frozenset({"keep_anchor", *(f"select_{lane}" for lane in LANES)})
SELECTOR_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "anchor_prediction_sha256",
    "anchor_ledger_sha256",
    "anchor_checkpoint_sha256",
    "panel_sha256",
    "anchor_step",
    *(f"{lane}_step" for lane in LANES),
    "decision",
    "frozen_step",
    "selected_prediction_sha256",
    "selected_prediction",
    "anchor_assessment",
    *(f"{lane}_assessment" for lane in LANES),
    "decision_basis",
    "rejected_alternative_basis",
)


_PANEL_RULES = """\
ANCHOR-BLIND THREE-SPECIALIST RECALL — THREE MUTUALLY EXCLUSIVE LANES

The incumbent anchor is unavailable. Do not infer or optimize relative to it.
Inspect every Canonical Step in chronology. Each evidence specialist works
independently and may freeze at most ONE complete legal prediction or `none`.
No two lanes may nominate the same Step. Never select a winner in this stage.

STATE_TRUTH LANE

Freeze the earliest Agent-owned Memory/Reflection/state-handoff boundary with
literal task-material impact: a concrete adjacent result fact is dropped or
distorted; an unsupported entity/value/relation is retained and consumed; an
observable success/failure/progress claim is contradicted; or a necessary
target is lost between a plan and the next decision. Require a candidate-only
repair that changes retained state, the next action, or answer. Reject harmless
compression, still-visible facts, unconsumed speculation, normal failure,
recovery, style, and downstream restatement.

POST_FEEDBACK_MATURITY LANE

Freeze the earliest Agent-owned commitment that follows a strictly earlier
literal failure or zero-contribution result and recommits to the same unresolved
immediate predicate plus evidence modality/extraction family without a genuinely
new evidence dimension. Exact query, URL, and source identity are not required;
cosmetic refinements are not new evidence. A different route capable of exposing
a different needed fact is a reasonable probe. The raw tool outcome cannot own
the candidate. Repetition maturity is prefix-closed: test the earliest mature
recommitment before later recurrence. Reject first probes, normal failure,
recovery, productive specialization, faithful propagation, and terminal symptoms.

DIRECT_ALIGNMENT LANE

Freeze the earliest Agent-owned literal contradiction that is independent of
state truth and repetition: an interface whose documented output intrinsically
cannot expose the explicit immediate predicate; a direct plan-to-Action target/
tool mismatch; an explicit user/source/constraint contradiction; or substitution
of a different predicate as task completion. Require same-Step or literal route
evidence and a local repair that changes the path. A route that can provide a
necessary identifier, page, source, text, or lead remains a reasonable probe.
Successful transport alone is not capability proof. Reject domain/entity-name
heuristics, final-answer hindsight, mechanical defects, normal failures, and
later symptoms.

CERTIFICATES AND SEPARATION

Each lane summary must begin exactly:
- `lane=state_truth; candidate_step=<none|Step>; `
- `lane=post_feedback_maturity; candidate_step=<none|Step>; `
- `lane=direct_alignment; candidate_step=<none|Step>; `

Each summary certifies full chronological coverage, literal owner and immediate
predicate, witness/repair, and why no earlier lane candidate survives. Each
falsifier states the strongest concrete counterargument or why none qualifies.
cross_lane_comparison explains evidence-class separation and duplicate-Step
avoidance without selecting a winner. Never access gold, prior predictions,
case reports, entity routers, or fixed Steps.
"""


_SELECTOR_RULES = """\
BOUNDED CAUSAL TOURNAMENT — CLEAN ANCHOR PLUS THREE SPECIALISTS

All inputs are immutable. Select exactly one existing complete prediction: the
clean v3.20 anchor or one present state, maturity, or alignment specialist.
Never invent, repair, merge, splice, or majority-vote fields. Candidate absence
is binding. Uncertainty keeps anchor.

Reconstruct literal chronology and apply these precedence tests:

1. Protect an anchor with direct unrecovered execution impact, literal explicit
   constraint contradiction, task-material state contradiction, or a causal
   root whose repair removes the specialist symptom.
2. State wins only when its literal false/dropped retained fact is consumed and
   anchor-only repair cannot restore the earlier state.
3. Maturity wins only when a strictly prior negative witness and unchanged
   predicate/evidence family are literal, and the anchor is a probe,
   noncritical predecessor, propagation, or later symptom.
4. Alignment wins only for a literal immediate predicate/interface, target,
   source, constraint, or plan/Action contradiction; success that can yield a
   necessary lead preserves a probe anchor.
5. Reject initial/different probes, normal failures, recovery, mechanical
   defects, harmless state compression, downstream symptoms, and terminal
   wording. Do not prefer position, Planning ownership, severity, persistence,
   or specialist provenance by itself.
6. If two specialists remain plausible, choose only the earlier independently
   mature causal owner; if independence cannot be proven, keep anchor.

selected_prediction must be a field-for-field exact copy of the chosen input.
Assess every available alternative and explain why each rejected boundary loses.
"""


def _rewrite_identity(task: str) -> str:
    return task.replace(
        parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        AGENT_JUDGE_LUNA_GAIA_V3_42_VERSION,
    ).replace(
        "agent_judge_luna_gaia_v3_20_packet_state_closure",
        "agent_judge_luna_gaia_v3_42_clean_v3p20_anchor_blind_three_specialist_tournament",
    )


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_anchor_task(*paths))


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    audit = dict(parent.validate_anchor_predictions(*paths))
    audit.update(
        agent_judge_version=AGENT_JUDGE_LUNA_GAIA_V3_42_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_42_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_42_REASONING_EFFORT,
    )
    return audit


def _boundary(*, manifest: Path, cohort: Path, reads: Sequence[Path], output: Path) -> str:
    read_lines = "\n".join(f"- {path}" for path in reads) or "- none"
    return f"""\
IMMUTABLE EXECUTION CONFIGURATION
- model: {AGENT_JUDGE_LUNA_GAIA_V3_42_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_42_REASONING_EFFORT}
- one isolated case; fresh session; no cross-case state or prior predictions
- external LLM/API/network calls: forbidden
- scoring or gold-label access: forbidden

INPUT/OUTPUT BOUNDARY
- prediction manifest: {manifest}
- prediction manifest file sha256: {shared._file_sha256(manifest)}
- cohort manifest: {cohort}
- cohort manifest file sha256: {shared._file_sha256(cohort)}
- permitted frozen stage inputs:
{read_lines}
- write the sole stage artifact only to: {output}

Read only those inputs plus this protocol source, the v3.20 protocol source,
and taxonomy.py. Do not inspect directories, names, labels, metrics, scored
artifacts, promotion files, experiments, old predictions, cached replies, case
studies, git history, or external resources.
"""


def _validate_panel_record(raw: Any, *, case: Any, location: str) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != PANEL_FIELDS:
        shared._fail("invalid_three_specialist_panel_schema", location)
    if raw["trajectory_id"] != case.trajectory_id or raw["trajectory_sha256"] != case.trajectory_sha256:
        shared._fail("three_specialist_panel_identity_mismatch", location)
    steps: list[int] = []
    for lane in LANES:
        status = raw[f"{lane}_status"]
        step = raw[f"{lane}_step"]
        prediction = raw[f"{lane}_prediction"]
        summary = raw[f"{lane}_search_summary"]
        falsifier = raw[f"{lane}_falsifier"]
        if status not in PANEL_STATUSES:
            shared._fail("invalid_three_specialist_lane_status", f"{location}.{lane}")
        prefix = LANE_PREFIX[lane] + f"{step if status == 'candidate' else 'none'}; "
        if not isinstance(summary, str) or not summary.startswith(prefix):
            shared._fail("invalid_three_specialist_lane_summary", f"{location}.{lane}")
        shared._nonempty_text(falsifier, location=f"{location}.{lane}_falsifier", maximum=2400)
        if status == "none":
            if step is not None or prediction is not None:
                shared._fail("nonempty_three_specialist_none_lane", f"{location}.{lane}")
        else:
            if isinstance(step, bool) or not isinstance(step, int):
                shared._fail("invalid_three_specialist_candidate_step", f"{location}.{lane}")
            validated = shared._validate_prediction_record(
                prediction, case=case, location=f"{location}.{lane}_prediction"
            )
            if validated["predicted_step"] != step:
                shared._fail("three_specialist_candidate_step_mismatch", f"{location}.{lane}")
            steps.append(step)
    if len(steps) != len(set(steps)):
        shared._fail("three_specialist_lanes_overlap", location)
    shared._nonempty_text(raw["cross_lane_comparison"], location=f"{location}.cross", maximum=2600)
    return raw


def validate_panel(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    panel_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    panel_file, raw = shared._load_artifact(panel_path, role="three specialist panel")
    record = shared._one_record(raw, role="three specialist panel")
    _validate_panel_record(record, case=case, location="three_specialist_panel[0]")
    return {
        "schema_version": "agentdebug.three-specialist-panel-audit.v1",
        "stage": "anchor_blind_three_specialist_panel",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_42_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_42_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_42_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": 1,
        "anchor_visible": False,
        "maximum_candidates": 3,
        "lanes_mutually_exclusive": True,
        "lane_status": {lane: record[f"{lane}_status"] for lane in LANES},
        "input_sha256": {
            "prediction_manifest": shared._file_sha256(manifest),
            "cohort": shared._file_sha256(cohort),
        },
        "output_sha256": {PANEL_FILENAME: shared._file_sha256(panel_file)},
    }


def build_panel_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    panel_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    output = Path(panel_path).expanduser().resolve()
    shared._assert_safe_path(output, role="three specialist panel output", is_output=True)
    audit = output.parent / PANEL_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_42_clean_v3p20_anchor_blind_three_specialist_tournament",
            "--compact-validate", "panel", manifest, cohort, output, audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    schema: dict[str, Any] = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
    }
    for lane in LANES:
        schema.update(
            {
                f"{lane}_status": "candidate or none",
                f"{lane}_step": "integer Step or null",
                f"{lane}_prediction": "complete legal prediction object or null",
                f"{lane}_search_summary": LANE_PREFIX[lane] + "<none|Step>; certificate",
                f"{lane}_falsifier": "strongest literal counterargument or why none qualifies",
            }
        )
    schema["cross_lane_comparison"] = "class separation and chronology without winner selection"
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_42_VERSION} stage 2/3: anchor-blind specialist panel.

{_boundary(manifest=manifest, cohort=cohort, reads=(), output=output)}

{_PANEL_RULES}

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

Every non-null prediction must use standard complete prediction fields in exact
order and quote literal evidence owned by its Step/module. After writing, run:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _load_anchor_bundle(
    manifest: Path,
    cohort: Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> tuple[Path, Path, Path, dict[str, Any], dict[str, Any], dict[str, Any]]:
    anchor_file = Path(anchor_path).expanduser().resolve()
    ledger_file = Path(ledger_path).expanduser().resolve()
    checkpoint_file = Path(checkpoint_path).expanduser().resolve()
    anchor, ledger, checkpoint = shared._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    parent._validate_packet_state_ledgers(ledger_file)
    return anchor_file, ledger_file, checkpoint_file, anchor, ledger, checkpoint


def _validate_selector_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    panel: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != SELECTOR_FIELDS:
        shared._fail("invalid_three_specialist_selector_schema", location)
    if raw["trajectory_id"] != case.trajectory_id or raw["trajectory_sha256"] != case.trajectory_sha256:
        shared._fail("three_specialist_selector_identity_mismatch", location)
    bindings = {
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "panel_sha256": shared._stable_sha256(panel),
    }
    if any(raw[key] != value for key, value in bindings.items()):
        shared._fail("three_specialist_selector_hash_mismatch", location)
    if raw["anchor_step"] != anchor["predicted_step"]:
        shared._fail("three_specialist_selector_anchor_step_mismatch", location)
    if any(raw[f"{lane}_step"] != panel[f"{lane}_step"] for lane in LANES):
        shared._fail("three_specialist_selector_candidate_step_mismatch", location)
    decision = raw["decision"]
    if decision not in SELECTOR_DECISIONS:
        shared._fail("invalid_three_specialist_selector_decision", location)
    options = {"keep_anchor": anchor} | {
        f"select_{lane}": panel[f"{lane}_prediction"] for lane in LANES
    }
    expected = options[decision]
    if expected is None:
        shared._fail("three_specialist_selector_selected_absent", location)
    selected = shared._validate_prediction_record(
        raw["selected_prediction"], case=case, location=f"{location}.selected"
    )
    if selected != expected:
        shared._fail("three_specialist_selector_copy_mismatch", location)
    if raw["selected_prediction_sha256"] != shared._stable_sha256(selected):
        shared._fail("three_specialist_selector_hash_selected_mismatch", location)
    if raw["frozen_step"] != selected["predicted_step"]:
        shared._fail("three_specialist_selector_frozen_step_mismatch", location)
    for field in (
        "anchor_assessment",
        *(f"{lane}_assessment" for lane in LANES),
        "decision_basis",
        "rejected_alternative_basis",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=2800)
    return raw


def validate_selector(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    panel_path: str | Path,
    selector_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(manifest, cohort, anchor_path, ledger_path, checkpoint_path)
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger, checkpoint = bundle[3:]
    panel_file, panel_raw = shared._load_artifact(panel_path, role="three specialist panel")
    panel = shared._one_record(panel_raw, role="three specialist panel")
    _validate_panel_record(panel, case=case, location="three_specialist_panel[0]")
    selector_file, selector_raw = shared._load_artifact(selector_path, role="three specialist selector")
    selector = shared._one_record(selector_raw, role="three specialist selector")
    _validate_selector_record(
        selector, case=case, anchor=anchor, ledger=ledger, checkpoint=checkpoint,
        panel=panel, location="three_specialist_selector[0]",
    )
    return {
        "schema_version": "agentdebug.three-specialist-selector-audit.v1",
        "stage": "bounded_three_specialist_exact_copy_selector",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_42_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_42_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_42_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": 1,
        "decision": selector["decision"],
        "selected_prediction_exact_copy": True,
        "candidate_count_maximum": 4,
        "input_sha256": {
            "anchor": shared._file_sha256(anchor_file),
            "ledger": shared._file_sha256(ledger_file),
            "checkpoint": shared._file_sha256(checkpoint_file),
            "panel": shared._file_sha256(panel_file),
        },
        "output_sha256": {SELECTOR_FILENAME: shared._file_sha256(selector_file)},
    }


def build_selector_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    panel_path: str | Path,
    selector_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle = _load_anchor_bundle(manifest, cohort, anchor_path, ledger_path, checkpoint_path)
    anchor_file, ledger_file, checkpoint_file = bundle[:3]
    anchor, ledger, checkpoint = bundle[3:]
    panel_file, panel_raw = shared._load_artifact(panel_path, role="three specialist panel")
    panel = shared._one_record(panel_raw, role="three specialist panel")
    _validate_panel_record(panel, case=case, location="three_specialist_panel[0]")
    output = Path(selector_path).expanduser().resolve()
    shared._assert_safe_path(output, role="three specialist selector output", is_output=True)
    audit = output.parent / SELECTOR_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_42_clean_v3p20_anchor_blind_three_specialist_tournament",
            "--compact-validate", "selector", manifest, cohort, anchor_file,
            ledger_file, checkpoint_file, panel_file, output, audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    schema: dict[str, Any] = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "panel_sha256": shared._stable_sha256(panel),
        "anchor_step": anchor["predicted_step"],
    }
    for lane in LANES:
        schema[f"{lane}_step"] = panel[f"{lane}_step"]
    schema.update(
        decision="keep_anchor or select_state or select_maturity or select_alignment",
        frozen_step="selected prediction Step",
        selected_prediction_sha256="stable JSON hash of exact selected prediction",
        selected_prediction="exact unchanged chosen prediction object",
        anchor_assessment="literal causal-boundary assessment",
    )
    for lane in LANES:
        schema[f"{lane}_assessment"] = "literal assessment or explicit absent-candidate note"
    schema["decision_basis"] = "why the chosen exact boundary wins"
    schema["rejected_alternative_basis"] = "why every present alternative loses"
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_42_VERSION} stage 3/3: bounded causal tournament.

{_boundary(manifest=manifest, cohort=cohort, reads=(anchor_file, ledger_file, checkpoint_file, panel_file), output=output)}

{_SELECTOR_RULES}

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

Compute hashes as stable sorted compact JSON. After writing, run:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _validate_aggregate(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(prediction_manifest_path, cohort_manifest_path)
    root = Path(predictions_path).expanduser().resolve().parent
    names = (
        ANCHOR_PREDICTIONS_FILENAME,
        ANCHOR_LEDGER_AGGREGATE_FILENAME,
        ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        PANELS_FILENAME,
        SELECTORS_FILENAME,
    )
    loaded = {name: shared._load_artifact(root / name, role=f"merged {name}")[1] for name in names}
    if any(not isinstance(value, list) or len(value) != len(cases) for value in loaded.values()):
        shared._fail("invalid_three_specialist_aggregate_count", "all artifacts need all cases")
    finals = shared._load_artifact(predictions_path, role="merged predictions")[1]
    if not isinstance(finals, list) or len(finals) != len(cases):
        shared._fail("invalid_three_specialist_prediction_count", "predictions need all cases")
    lane_counts = {lane: Counter() for lane in LANES}
    decisions: Counter[str] = Counter()
    for index, case in enumerate(cases):
        anchor = loaded[ANCHOR_PREDICTIONS_FILENAME][index]
        ledger = loaded[ANCHOR_LEDGER_AGGREGATE_FILENAME][index]
        checkpoint = loaded[ANCHOR_CHECKPOINT_AGGREGATE_FILENAME][index]
        panel = loaded[PANELS_FILENAME][index]
        selector = loaded[SELECTORS_FILENAME][index]
        location = f"three_specialist_merged[{index}]"
        shared._validate_prediction_record(anchor, case=case, location=f"{location}.anchor")
        if (
            ledger.get("trajectory_id") != case.trajectory_id
            or ledger.get("selected_step") != anchor["predicted_step"]
            or checkpoint.get("trajectory_id") != case.trajectory_id
            or checkpoint.get("predicted_step") != anchor["predicted_step"]
        ):
            shared._fail("three_specialist_anchor_sidecar_mismatch", location)
        _validate_panel_record(panel, case=case, location=f"{location}.panel")
        _validate_selector_record(
            selector, case=case, anchor=anchor, ledger=ledger, checkpoint=checkpoint,
            panel=panel, location=f"{location}.selector",
        )
        final = shared._validate_prediction_record(finals[index], case=case, location=f"{location}.final")
        if final != selector["selected_prediction"]:
            shared._fail("three_specialist_final_copy_mismatch", location)
        for lane in LANES:
            lane_counts[lane][panel[f"{lane}_status"]] += 1
        decisions[selector["decision"]] += 1
    return {
        "required": True,
        "valid": True,
        "anchor_blind_panel": True,
        "maximum_specialist_candidates": 3,
        "maximum_total_predictions": 4,
        "lanes_mutually_exclusive": True,
        "all_selected_predictions_exact_copies": True,
        "lane_status_counts": {
            lane: dict(sorted(counts.items())) for lane, counts in lane_counts.items()
        },
        "selector_decision_counts": dict(sorted(decisions.items())),
        "packet_state_closure": parent._validate_packet_state_ledgers(
            root / ANCHOR_LEDGER_AGGREGATE_FILENAME
        ),
    }


def validate_agent_judge_luna_gaia_v3_42_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    panel = _validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_42_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_42_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_42_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_42_REASONING_EFFORT,
        "selection_policy": "clean_v3_20_anchor_three_anchor_blind_specialists_exact_copy_tournament",
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one anchor-blind three-specialist exact-copy tournament",
        "anchor_semantics_unchanged_from_v3_20": True,
        "all_selected_predictions_exact_copies": True,
        "factorized_specialist_panel": panel,
    }


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_panel(*paths[:-1]), paths[-1])


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_selector(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_42_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_42_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


# Shared runner compatibility.
validate_and_write_agent_judge_luna_gaia_v3_37_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_42_audit
)


def build_agent_judge_luna_gaia_v3_42_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_selector_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / PANEL_FILENAME,
        prediction.parent / SELECTOR_FILENAME,
    )


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_42_task
validate_agent_judge_luna_gaia_v3_13_predictions = validate_agent_judge_luna_gaia_v3_42_predictions
validate_and_write_agent_judge_luna_gaia_v3_13_audit = validate_and_write_agent_judge_luna_gaia_v3_42_audit


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "panel" and len(paths) == 4:
            audit = validate_and_write_panel_audit(*paths)
        elif stage == "selector" and len(paths) == 8:
            audit = validate_and_write_selector_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_42_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "panel", "selector", "prediction"))
    parser.add_argument("paths", nargs="+")
    args = parser.parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

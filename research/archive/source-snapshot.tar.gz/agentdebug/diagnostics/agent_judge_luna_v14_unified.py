"""Evidence-ID form of proposal-free, one-session Luna adjudication.

V14 keeps v13's anonymous JudgeView, dual-hypothesis semantics, strict owner
geometry, and gold-free boundary.  The material interface change is that the
model never copies literal evidence.  The parent builds a deterministic
catalog of step-local admissible evidence atoms, the model selects an opaque
``evidence_atom_id``, and validation derives step, owner, and final quote from the
catalog.
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Mapping

from agentdebug.benchmark.prediction_manifest import load_prediction_manifest

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _cohort_document,
    _file_sha256,
    _load_json,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_luna_v13_unified import (
    _anonymized_timeline,
    _leaf_and_residual_owner_source_resolver,
    _prompt_identity_values,
)
from .agent_judge_v2_4 import AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
from .taxonomy import (
    TAXONOMY,
    AgentModule,
    ErrorType,
    is_valid_classification,
    taxonomy_prompt,
)


AGENT_JUDGE_LUNA_V14_UNIFIED_VERSION = (
    "agentdebug.codex-agent-judge.luna-v14-unified-v1"
)
AGENT_JUDGE_LUNA_V14_UNIFIED_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_V14_UNIFIED_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_V14_UNIFIED_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)

DECISION_FILENAME = "decision.json"

_LOCATOR_FIELDS = frozenset(
    {
        "defect_basis",
        "evidence_atom_id",
        "boundary_reason",
        "smallest_correction",
        "downstream_consequence",
    }
)
_CLASSIFICATION_FIELDS = frozenset(
    {
        "predicted_error_type",
        "rejected_adjacent_owner",
    }
)
_ARBITRATION_FIELDS = frozenset(
    {
        "selected_lane",
        "selection_basis",
        "selected_candidate_reason",
        "rejected_candidate_reason",
    }
)
_DECISION_FIELDS = frozenset(
    {"chronological_locator", "local_locator", "arbitration", "classification"}
)

_DEFECT_BASES = frozenset(
    {
        "literal_state_contradiction",
        "literal_task_constraint",
        "plan_action_contract",
        "mechanical_interface_defect",
        "mature_repetition",
        "observable_system_boundary",
        "causal_inference",
    }
)
_SELECTION_BASES = frozenset(
    {
        "direct_root",
        "mature_repetition",
        "observable_system_boundary",
        "causal_predecessor",
        "stronger_material_root",
    }
)
_LANES = frozenset({"chronological", "local"})

_ATOM_SCHEMA_VERSION = "agentdebug.luna-v14-evidence-atoms.v1"
_ATOM_PREFIX = "EA-"
_ATOM_FRAGMENT_MAX_CHARS = 960
_ATOM_DISPLAY_MAX_CHARS = 180


def _required_text(value: Any, *, location: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise AgentJudgeValidationError(
            "invalid_decision_text", f"{location} must be non-empty text"
        )
    return value


def _validate_one_case_identity(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    *,
    role: str,
) -> tuple[Path, Path, Mapping[str, Any], Any, Mapping[str, Any]]:
    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    manifest, cases = load_prediction_manifest(manifest_path)
    if len(cases) != 1:
        raise AgentJudgeValidationError(
            f"invalid_{role}_case_count",
            f"a v14 {role} requires exactly one case",
        )
    case = cases[0]
    cohort_path = Path(cohort_manifest_path).expanduser().resolve()
    cohort = _cohort_document(cohort_path)
    if (
        cohort["trajectory_ids"] != [case.trajectory_id]
        or manifest.get("cohort_name") != cohort.get("cohort_name")
        or manifest.get("cohort_sha256") != cohort.get("cohort_sha256")
        or manifest.get("dataset_manifest_sha256")
        != cohort.get("dataset_manifest_sha256")
    ):
        raise AgentJudgeValidationError(
            f"{role}_cohort_mismatch",
            "the one-case cohort identity does not match the prediction manifest",
        )
    return manifest_path, cohort_path, manifest, case, cohort


def _anonymize_atom_text(case: Any, text: str) -> str:
    """Apply v13's identity policy to a catalog fragment.

    The private atom retains the original quote used by the final prediction.
    Only this display form is sent to the model.
    """

    replacements: dict[str, str] = {
        case.trajectory_id: "ANONYMOUS-TRACE",
        case.trajectory_sha256: "ANONYMOUS-CONTENT-HASH",
        case.trajectory_sha256[:16]: "ANONYMOUS-CONTENT-HASH",
    }
    remaining = sorted(
        (
            value
            for value in _prompt_identity_values(case)
            if value not in replacements
        ),
        key=lambda value: (-len(value), value),
    )
    replacements.update(
        {
            value: f"ANONYMOUS-ID-{index:04d}"
            for index, value in enumerate(remaining, 1)
        }
    )
    anonymized = text
    for original in sorted(replacements, key=lambda value: (-len(value), value)):
        anonymized = anonymized.replace(original, replacements[original])
    source_model = case.trajectory_id.split("_", 1)[0]
    if len(source_model) >= 4:
        anonymized = re.sub(
            re.escape(source_model),
            "ANONYMOUS-SOURCE-MODEL",
            anonymized,
            flags=re.IGNORECASE,
        )
    return re.sub(
        r"(?m)^(?P<indent>[ \t]*)/(?:root|home|tmp|workspace)/[^\r\n]+$",
        r"\g<indent>ANONYMOUS-SOURCE-PATH",
        anonymized,
    )


def _source_fragments(source: str) -> tuple[str, ...]:
    """Return bounded, non-overlapping literal fragments of one admitted source."""

    start = 0
    stop = len(source)
    while start < stop and source[start].isspace():
        start += 1
    while stop > start and source[stop - 1].isspace():
        stop -= 1
    if start == stop:
        return ()
    if stop - start <= _ATOM_FRAGMENT_MAX_CHARS:
        return (source[start:stop],)

    fragments: list[str] = []
    cursor = start
    while cursor < stop:
        end = min(cursor + _ATOM_FRAGMENT_MAX_CHARS, stop)
        if end < stop:
            minimum_break = cursor + (_ATOM_FRAGMENT_MAX_CHARS // 2)
            candidates = [
                source.rfind(separator, minimum_break, end)
                for separator in ("\n\n", "\n", ". ", "; ", ", ", " ")
            ]
            boundary = max(candidates)
            if boundary >= minimum_break:
                end = boundary + (2 if source[boundary : boundary + 2] == ". " else 0)
        fragment_start = cursor
        fragment_end = end
        while fragment_start < fragment_end and source[fragment_start].isspace():
            fragment_start += 1
        while fragment_end > fragment_start and source[fragment_end - 1].isspace():
            fragment_end -= 1
        if fragment_start < fragment_end:
            fragments.append(source[fragment_start:fragment_end])
        if end >= stop:
            break
        cursor = end
    return tuple(dict.fromkeys(fragments))


def _evidence_atoms(case: Any) -> tuple[dict[str, Any], ...]:
    """Build the private, deterministic evidence catalog for one case.

    Equal step/owner/text fragments are merged across the owner's legal types.
    If identical raw text is admissible for multiple owners, it deliberately
    produces distinct owner-bound atoms.  Selecting an atom therefore freezes
    step, owner module, and literal quote before type classification.
    """

    merged: dict[tuple[int, str, str], set[str]] = {}
    for step in range(1, len(case.judge_view.steps) + 1):
        for module, definitions in TAXONOMY.items():
            if module == AgentModule.SYSTEM:
                for error_type in definitions:
                    sources = _leaf_and_residual_owner_source_resolver(
                        case.judge_view,
                        step,
                        module,
                        error_type,
                    )
                    for source in sources:
                        for fragment in _source_fragments(source):
                            merged.setdefault(
                                (step, module.value, fragment), set()
                            ).add(error_type.value)
                continue
            representative = next(iter(definitions))
            sources = _leaf_and_residual_owner_source_resolver(
                case.judge_view,
                step,
                module,
                representative,
            )
            allowed = {error_type.value for error_type in definitions}
            for source in sources:
                for fragment in _source_fragments(source):
                    merged.setdefault((step, module.value, fragment), set()).update(
                        allowed
                    )

    module_order = {module.value: index for index, module in enumerate(AgentModule)}
    text_keys = sorted(
        {(step, quote) for step, _, quote in merged},
        key=lambda item: (
            item[0],
            hashlib.sha256(item[1].encode("utf-8")).hexdigest(),
            item[1],
        ),
    )
    if len(text_keys) > 9999:
        raise AgentJudgeValidationError(
            "evidence_catalog_too_large", "v14 supports at most 9999 text atoms"
        )
    text_ids = {
        key: f"ET-{index:04d}" for index, key in enumerate(text_keys, 1)
    }
    entries = sorted(
        merged.items(),
        key=lambda item: (
            item[0][0],
            module_order[item[0][1]],
            hashlib.sha256(item[0][2].encode("utf-8")).hexdigest(),
            item[0][2],
        ),
    )
    if len(entries) > 9999:
        raise AgentJudgeValidationError(
            "evidence_catalog_too_large", "v14 supports at most 9999 evidence atoms"
        )
    atoms: list[dict[str, Any]] = []
    for index, ((step, owner_module, quote), allowed_error_types) in enumerate(
        entries, 1
    ):
        atoms.append(
            {
                "evidence_atom_id": f"{_ATOM_PREFIX}{index:04d}",
                "text_id": text_ids[(step, quote)],
                "step": step,
                "owner_module": owner_module,
                "display_text": _anonymize_atom_text(case, quote),
                "quote": quote,
                "raw_sha256": hashlib.sha256(quote.encode("utf-8")).hexdigest(),
                "allowed_error_types": tuple(sorted(allowed_error_types)),
            }
        )
    return tuple(atoms)


def _public_atom_catalog(atoms: tuple[dict[str, Any], ...]) -> dict[str, Any]:
    """Share display text while retaining distinct owner-bound atom cards."""

    texts: dict[str, tuple[int, str]] = {}
    cards: list[dict[str, Any]] = []
    for atom in atoms:
        text_id = atom["text_id"]
        text_identity = (atom["step"], atom["display_text"])
        if text_id in texts and texts[text_id] != text_identity:
            raise AssertionError("v14 display text IDs are not unique")
        texts[text_id] = text_identity
        cards.append(
            {
                "evidence_atom_id": atom["evidence_atom_id"],
                "step": atom["step"],
                "owner_module": atom["owner_module"],
                "text_id": text_id,
                "allowed_error_types": list(atom["allowed_error_types"]),
            }
        )
    def display_projection(text: str) -> dict[str, Any]:
        if len(text) <= _ATOM_DISPLAY_MAX_CHARS:
            return {"text": text}
        side = (_ATOM_DISPLAY_MAX_CHARS - 4) // 2
        return {
            "text_prefix": text[:side],
            "text_suffix": text[-side:],
            "elided_char_count": len(text) - (2 * side),
        }

    return {
        "texts": [
            {
                "text_id": text_id,
                "step": step,
                **display_projection(text),
            }
            for text_id, (step, text) in sorted(texts.items())
        ],
        "atoms": cards,
    }


def _atom_catalog_sha256(atoms: tuple[dict[str, Any], ...]) -> str:
    private_projection: list[dict[str, Any]] = []
    for atom in atoms:
        quote = atom.get("quote")
        claimed_raw_sha256 = atom.get("raw_sha256")
        if not isinstance(quote, str) or not isinstance(claimed_raw_sha256, str):
            raise AgentJudgeValidationError(
                "invalid_evidence_atom",
                "evidence atom quote and raw SHA-256 must be text",
            )
        recomputed_raw_sha256 = hashlib.sha256(quote.encode("utf-8")).hexdigest()
        if claimed_raw_sha256 != recomputed_raw_sha256:
            raise AgentJudgeValidationError(
                "evidence_atom_hash_mismatch",
                "evidence atom raw text does not match its frozen SHA-256",
            )
        private_projection.append(
            {
                "evidence_atom_id": atom["evidence_atom_id"],
                "text_id": atom["text_id"],
                "step": atom["step"],
                "owner_module": atom["owner_module"],
                "raw_sha256": recomputed_raw_sha256,
                "allowed_error_types": list(atom["allowed_error_types"]),
            }
        )
    body = json.dumps(
        private_projection,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(body).hexdigest()


def build_luna_v14_evidence_atom_catalog(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> dict[str, Any]:
    """Return the exact anonymized evidence catalog embedded in the prompt."""

    _, _, _, case, _ = _validate_one_case_identity(
        prediction_manifest_path,
        cohort_manifest_path,
        role="task",
    )
    atoms = _evidence_atoms(case)
    return {
        "schema_version": _ATOM_SCHEMA_VERSION,
        "atom_count": len(atoms),
        "catalog_sha256": _atom_catalog_sha256(atoms),
        **_public_atom_catalog(atoms),
    }


def decision_output_schema() -> dict[str, Any]:
    """Return the exact JSON schema supplied to ``codex exec``."""

    locator = {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_LOCATOR_FIELDS),
        "properties": {
            "defect_basis": {"type": "string", "enum": sorted(_DEFECT_BASES)},
            "evidence_atom_id": {
                "type": "string",
                "pattern": rf"^{re.escape(_ATOM_PREFIX)}[0-9]{{4}}$",
            },
            "boundary_reason": {"type": "string", "minLength": 1},
            "smallest_correction": {"type": "string", "minLength": 1},
            "downstream_consequence": {"type": "string", "minLength": 1},
        },
    }
    classification = {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_CLASSIFICATION_FIELDS),
        "properties": {
            "predicted_error_type": {
                "type": "string",
                "enum": [item.value for item in ErrorType],
            },
            "rejected_adjacent_owner": {"type": "string", "minLength": 1},
        },
    }
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_DECISION_FIELDS),
        "properties": {
            "chronological_locator": locator,
            "local_locator": locator,
            "arbitration": {
                "type": "object",
                "additionalProperties": False,
                "required": sorted(_ARBITRATION_FIELDS),
                "properties": {
                    "selected_lane": {"type": "string", "enum": sorted(_LANES)},
                    "selection_basis": {
                        "type": "string",
                        "enum": sorted(_SELECTION_BASES),
                    },
                    "selected_candidate_reason": {
                        "type": "string",
                        "minLength": 1,
                    },
                    "rejected_candidate_reason": {
                        "type": "string",
                        "minLength": 1,
                    },
                },
            },
            "classification": classification,
        },
    }


def _locator(
    case: Any,
    atoms_by_id: Mapping[str, Mapping[str, Any]],
    value: Any,
    *,
    location: str,
) -> tuple[dict[str, Any], Mapping[str, Any]]:
    if not isinstance(value, Mapping) or set(value) != _LOCATOR_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_locator_fields", f"{location} has invalid fields"
        )
    basis = value["defect_basis"]
    if not isinstance(basis, str) or basis not in _DEFECT_BASES:
        raise AgentJudgeValidationError(
            "invalid_defect_basis", f"{location}.defect_basis is invalid"
        )
    atom_id = value["evidence_atom_id"]
    if not isinstance(atom_id, str) or atom_id not in atoms_by_id:
        raise AgentJudgeValidationError(
            "unknown_evidence_atom",
            f"{location}.evidence_atom_id is not in the catalog",
        )
    atom = atoms_by_id[atom_id]
    system_basis = basis == "observable_system_boundary"
    system_atom = atom["owner_module"] == AgentModule.SYSTEM.value
    if system_basis != system_atom:
        raise AgentJudgeValidationError(
            "evidence_atom_system_mismatch",
            "observable_system_boundary and a System evidence atom must agree",
        )
    for field in _LOCATOR_FIELDS - {"defect_basis", "evidence_atom_id"}:
        _required_text(value[field], location=f"{location}.{field}")
    resolved = {
        **dict(value),
        "step": atom["step"],
        "owner_module": atom["owner_module"],
        "boundary_quote": atom["quote"],
    }
    return resolved, atom


def _classification(
    value: Any,
    *,
    selected: Mapping[str, Any],
    selected_atom: Mapping[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(value, Mapping) or set(value) != _CLASSIFICATION_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_classification_fields", f"{location} has invalid fields"
        )
    try:
        error_type = ErrorType(value["predicted_error_type"])
    except (TypeError, ValueError) as error:
        raise AgentJudgeValidationError(
            "invalid_classification_taxonomy", f"{location} has unknown taxonomy"
        ) from error
    module = AgentModule(selected_atom["owner_module"])
    if not is_valid_classification(module, error_type):
        raise AgentJudgeValidationError(
            "invalid_classification_taxonomy",
            f"{location} has an illegal module/error_type pair",
        )
    if error_type.value not in selected_atom["allowed_error_types"]:
        raise AgentJudgeValidationError(
            "invalid_classification_evidence",
            "error type is not legal for the selected owner-bound evidence atom",
        )
    _required_text(
        value["rejected_adjacent_owner"],
        location=f"{location}.rejected_adjacent_owner",
    )
    return dict(value)


def _prediction_record(case: Any, candidate: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        **dict(candidate),
    }


def validate_luna_v14_unified_decision(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    decision_path: str | Path,
) -> dict[str, Any]:
    """Validate and deterministically resolve one current-session decision."""

    manifest_path, cohort_path, _, case, cohort = _validate_one_case_identity(
        prediction_manifest_path,
        cohort_manifest_path,
        role="decision",
    )
    atoms = _evidence_atoms(case)
    atoms_by_id = {atom["evidence_atom_id"]: atom for atom in atoms}
    if len(atoms_by_id) != len(atoms):
        raise AssertionError("v14 evidence atom IDs are not unique")

    resolved_decision_path = Path(decision_path).expanduser().resolve()
    raw = _load_json(resolved_decision_path, role="decision")
    if not isinstance(raw, Mapping) or set(raw) != _DECISION_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_decision_fields", "decision has invalid top-level fields"
        )
    chronological, chronological_atom = _locator(
        case,
        atoms_by_id,
        raw["chronological_locator"],
        location="decision.chronological_locator",
    )
    local, local_atom = _locator(
        case,
        atoms_by_id,
        raw["local_locator"],
        location="decision.local_locator",
    )
    if len(case.judge_view.steps) > 1 and chronological["step"] == local["step"]:
        raise AgentJudgeValidationError(
            "candidate_steps_not_distinct",
            "multi-step chronological and local candidates must differ",
        )

    arbitration = raw["arbitration"]
    if not isinstance(arbitration, Mapping) or set(arbitration) != _ARBITRATION_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_arbitration_fields", "decision.arbitration has invalid fields"
        )
    lane = arbitration["selected_lane"]
    selection_basis = arbitration["selection_basis"]
    if (
        not isinstance(lane, str)
        or lane not in _LANES
        or not isinstance(selection_basis, str)
        or selection_basis not in _SELECTION_BASES
    ):
        raise AgentJudgeValidationError(
            "invalid_arbitration_choice", "selected lane or basis is invalid"
        )
    selected_reason = _required_text(
        arbitration["selected_candidate_reason"],
        location="decision.arbitration.selected_candidate_reason",
    )
    rejected_reason = _required_text(
        arbitration["rejected_candidate_reason"],
        location="decision.arbitration.rejected_candidate_reason",
    )
    selected = chronological if lane == "chronological" else local
    rejected = local if lane == "chronological" else chronological
    selected_atom = chronological_atom if lane == "chronological" else local_atom
    selected_basis = selected["defect_basis"]
    direct_bases = {
        "literal_state_contradiction",
        "literal_task_constraint",
        "plan_action_contract",
        "mechanical_interface_defect",
    }
    inconsistent = (
        (selection_basis == "direct_root" and selected_basis not in direct_bases)
        or (
            selection_basis == "mature_repetition"
            and selected_basis != "mature_repetition"
        )
        or (
            selection_basis == "observable_system_boundary"
            and selected_basis != "observable_system_boundary"
        )
        or (
            selection_basis == "causal_predecessor"
            and selected["step"] >= rejected["step"]
        )
    )
    if inconsistent:
        raise AgentJudgeValidationError(
            "inconsistent_arbitration_basis",
            "selection_basis is inconsistent with the selected locator",
        )

    classification = _classification(
        raw["classification"],
        selected=selected,
        selected_atom=selected_atom,
        location="decision.classification",
    )
    prediction = _prediction_record(
        case,
        {
            "predicted_step": selected["step"],
            "predicted_module": selected_atom["owner_module"],
            "predicted_error_type": classification["predicted_error_type"],
            "evidence_quote": selected["boundary_quote"],
            "root_cause": selected["boundary_reason"],
            "causal_summary": (
                f"Smallest correction: {selected['smallest_correction']} "
                "Downstream consequence: "
                f"{selected['downstream_consequence']}"
            ),
            "rejected_adjacent_owner": classification["rejected_adjacent_owner"],
        },
    )
    if set(prediction) != AGENT_JUDGE_PREDICTION_FIELDS:
        raise AssertionError("derived v14 prediction fields changed")
    return {
        "schema_version": "agentdebug.codex-agent-judge-luna-v14-decision-audit.v1",
        "agent_judge_version": AGENT_JUDGE_LUNA_V14_UNIFIED_VERSION,
        "model": AGENT_JUDGE_LUNA_V14_UNIFIED_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V14_UNIFIED_REASONING_EFFORT,
        "proposal_free": True,
        "historical_predictions_visible": False,
        "same_session_hypothesis_count": 2,
        "candidate_steps_distinct_when_possible": True,
        "evidence_atom_schema_version": _ATOM_SCHEMA_VERSION,
        "evidence_atom_count": len(atoms),
        "evidence_atom_catalog_sha256": _atom_catalog_sha256(atoms),
        "selected_lane": lane,
        "selection_basis": selection_basis,
        "selected_candidate_reason": selected_reason,
        "rejected_candidate_reason": rejected_reason,
        "chronological_locator": chronological,
        "local_locator": local,
        "classification": classification,
        "selected_prediction": prediction,
        "prediction_manifest_file_sha256": _file_sha256(manifest_path),
        "cohort_manifest_file_sha256": _file_sha256(cohort_path),
        "cohort_name": cohort["cohort_name"],
        "cohort_sha256": cohort["cohort_sha256"],
        "dataset_manifest_sha256": cohort["dataset_manifest_sha256"],
        "decision_sha256": _file_sha256(resolved_decision_path),
    }


def _decision_contract() -> str:
    return json.dumps(decision_output_schema(), ensure_ascii=False, indent=2)


def build_agent_judge_luna_v14_unified_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Embed one anonymous JudgeView and its parent-built evidence catalog."""

    del predictions_path
    _, _, _, case, _ = _validate_one_case_identity(
        prediction_manifest_path,
        cohort_manifest_path,
        role="task",
    )
    timeline = _anonymized_timeline(case)
    atoms = _evidence_atoms(case)
    atom_catalog = json.dumps(
        {
            "schema_version": _ATOM_SCHEMA_VERSION,
            **_public_atom_catalog(atoms),
        },
        ensure_ascii=False,
        indent=2,
    )
    return f"""\
Run frozen protocol {AGENT_JUDGE_LUNA_V14_UNIFIED_VERSION}.

EXECUTION CONTRACT
- model: {AGENT_JUDGE_LUNA_V14_UNIFIED_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_V14_UNIFIED_REASONING_EFFORT}
- exactly one anonymous trajectory is embedded below
- do not call tools, inspect files, use the network, or use external APIs
- no prior prediction, proposal, label, score, case study, or cross-case state exists
- return exactly one JSON object matching the supplied output schema

Every trajectory follows the same three phases.  Complete both locators before
arbitration.  Do not infer from opaque IDs, list position, source-model name,
environment, expected distribution, or benchmark familiarity.

EVIDENCE ATOM CONTRACT

The parent generated every card from validator-admitted owner evidence.  The
``texts`` table stores each short text in full and gives deterministic
prefix/suffix previews for a long fragment; the complete anonymous source is
already visible in the JudgeView.  Every ``atoms`` card binds an opaque
evidence_atom_id to one text_id, its real trajectory step, and one owner_module.
Select evidence_atom_id; never copy, paraphrase, or emit evidence text.  The
parent maps the selected ID back to its complete original literal
evidence_quote and mechanically derives predicted_step and predicted_module.
After arbitration, classification.predicted_error_type must be one of the
selected atom card's sorted allowed_error_types; do not infer a type outside
that per-atom list.

- owner_module=system requires defect_basis=observable_system_boundary, and
  that basis requires owner_module=system.  This is bidirectional for both
  locators.
- On a multi-step trace, the two locators must use different steps.
- Classification occurs only after arbitration and reports error type, not
  step, module, quote, or source.  It must classify the defect already frozen
  by the selected owner-bound atom and cannot replace its atom, step, module,
  basis, reason, correction, or consequence.
- Agent atoms come only from selected-step assistant/operation sources admitted
  by at least one legal owner/type.  System atoms come only from Step-1 task
  contradictions, independent structured external failures, or typed final
  execution limits admitted by the validator.

PHASE A — CHRONOLOGICAL LOCATOR

Scan Step 1 onward.  At every step test Memory against already observed facts,
Reflection against the immediately preceding result and progress, Planning
against task constraints/prerequisites/information goals, Action against the
same-step plan/interface, and narrowly observable System facts.  Select the
first mature causal error whose local correction materially redirects failure.
A reasonable first probe or one ambiguous confirmation is not automatically
inefficient.  Choose an atom at that same step which literally instantiates
the nominated defect; do not choose an observation merely because it describes
a consequence.

PHASE B — DIFFERENT-STEP LOCAL LOCATOR

Independently find the strongest locally attributable error at a different
step.  Prefer a literal false state/result/progress claim, explicit task
conflict, impossible prerequisite, Plan/Action contract breach, mechanical
interface defect, qualified mature repetition, or narrowly observable System
boundary over generic strategy aesthetics.  A normal empty result, rejected
bad parameter, merely failed valid probe, vague hindsight improvement, and
later symptom are not System failures.

PHASE C — UNIFORM CAUSAL ARBITRATION

Neither lane is a default.  A causally used earlier false premise outranks its
later repetition or unsupported answer, but chronology alone is insufficient.
A direct literal breach outranks generic inefficiency.  A System boundary wins
only when it independently prevents otherwise coherent progress; it loses to a
concrete causally prior agent error.

For repetition, require all four gates: prior feedback already proves no
progress for the same information goal; the selected output literally
recommits to an equivalent operation; no new target/source/constraint/fact or
restored capability opens a new epoch; and this is the first output in the
epoch satisfying those conditions.  Initial acquisition plus one
evidence-motivated confirmation is normally allowed.

Set arbitration.selection_basis from the selected locator: direct_root only
for literal state/task/Plan-Action/mechanical bases; mature_repetition only for
that basis; observable_system_boundary only for that basis;
causal_predecessor only when the selected candidate is earlier and supplies
the rejected defect; otherwise stronger_material_root.

After selection, resolve only owner/type.  Memory owns lost or invented state;
Reflection owns false interpretation of feedback/progress/cause; Planning owns
defective strategy/prerequisite when upstream state is sound; Action owns a
departure from an adequate plan or mechanical invocation defect; System owns
only an admitted observable boundary.  A faithful action does not steal its
plan's error, and a final answer does not steal an earlier false premise.
Nested tags use innermost leaf ownership.  Planning residual is confined inside
an explicit Planning/think span after foreign nested owners are removed;
top-level residual is never Planning.  An isolated malformed action block is
Action evidence for any legal Action type; malformed syntax alone does not
pre-decide which Action type applies.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

OUTPUT CONTRACT
{_decision_contract()}

PARENT-BUILT EVIDENCE ATOM CATALOG
{atom_catalog}

GOLD-FREE ANONYMOUS JUDGEVIEW
{timeline}
"""


def validate_agent_judge_luna_v14_unified_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    """Validate final predictions against their exact private evidence atoms.

    The shared validator establishes the complete cohort, identity, taxonomy,
    and owner-source contract first.  V14 then strengthens its substring
    evidence check: every persisted prediction must equal one deterministic
    atom on step, owner module, error type admission, and complete raw quote.
    This keeps the registry-level validator equivalent to the decision path,
    even when it is called independently of the dedicated runner lineage.
    """

    audit = _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_leaf_and_residual_owner_source_resolver,
    )
    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    output_path = Path(predictions_path).expanduser().resolve()
    _, cases = load_prediction_manifest(manifest_path)
    raw_predictions = _load_json(output_path, role="predictions")
    if not isinstance(raw_predictions, list) or len(raw_predictions) != len(cases):
        raise AssertionError("shared v14 validation did not freeze prediction count")

    catalog_records: list[dict[str, Any]] = []
    for index, (case, prediction) in enumerate(
        zip(cases, raw_predictions, strict=True), 1
    ):
        if not isinstance(prediction, Mapping):
            raise AssertionError("shared v14 validation did not freeze records")
        atoms = _evidence_atoms(case)
        matches = [
            atom
            for atom in atoms
            if atom["step"] == prediction["predicted_step"]
            and atom["owner_module"] == prediction["predicted_module"]
            and atom["quote"] == prediction["evidence_quote"]
            and prediction["predicted_error_type"] in atom["allowed_error_types"]
        ]
        if len(matches) != 1:
            raise AgentJudgeValidationError(
                "invalid_evidence_atom_binding",
                (
                    f"predictions[{index - 1}] does not exactly match one "
                    "v14 owner-bound evidence atom"
                ),
            )
        selected_atom = matches[0]
        catalog_records.append(
            {
                "case_index": index,
                "trajectory_id": case.trajectory_id,
                "atom_count": len(atoms),
                "catalog_sha256": _atom_catalog_sha256(atoms),
                "selected_evidence_atom_id": selected_atom["evidence_atom_id"],
            }
        )
    catalog_set_sha256 = hashlib.sha256(
        json.dumps(
            catalog_records,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_V14_UNIFIED_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_V14_UNIFIED_VERSION,
        "model": AGENT_JUDGE_LUNA_V14_UNIFIED_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V14_UNIFIED_REASONING_EFFORT,
        "proposal_free": True,
        "historical_predictions_visible": False,
        "same_session_dual_hypothesis": True,
        "label_pair_routing_used": False,
        "nested_module_spans_supported": True,
        "evidence_atom_binding": True,
        "all_predictions_match_exact_evidence_atom": True,
        "evidence_atom_catalogs": catalog_records,
        "evidence_atom_catalog_set_sha256": catalog_set_sha256,
        "model_copies_boundary_quote": False,
        "validation_method": (
            "Gold-free exact JSON, cohort/manifest order, trajectory identity, "
            "step range, taxonomy pair, selected-owner evidence, and exact "
            "v14 owner-bound evidence-atom checks."
        ),
    }


__all__ = [
    "AGENT_JUDGE_LUNA_V14_UNIFIED_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_V14_UNIFIED_MODEL",
    "AGENT_JUDGE_LUNA_V14_UNIFIED_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_V14_UNIFIED_VERSION",
    "DECISION_FILENAME",
    "build_agent_judge_luna_v14_unified_task",
    "build_luna_v14_evidence_atom_catalog",
    "decision_output_schema",
    "validate_agent_judge_luna_v14_unified_predictions",
    "validate_luna_v14_unified_decision",
]

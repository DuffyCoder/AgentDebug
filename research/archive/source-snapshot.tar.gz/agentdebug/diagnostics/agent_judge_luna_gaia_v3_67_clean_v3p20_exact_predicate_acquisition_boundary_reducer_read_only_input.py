"""Luna GAIA v3.67: clean-v3.20 exact-predicate reducer with file input."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from . import agent_judge_luna_gaia_v3_66_clean_v3p20_exact_predicate_acquisition_boundary_reducer as mechanism
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions
from .taxonomy import AgentModule, ErrorType


AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.67-clean-v3.20-"
    "exact-predicate-acquisition-boundary-reducer-read-only-input"
)
AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_67_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_67_AUDIT_SCHEMA_VERSION
)

shared = mechanism.shared
ANCHOR_PREDICTIONS_FILENAME = mechanism.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = mechanism.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = mechanism.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = mechanism.PREDICTION_AUDIT_FILENAME
PANEL_FILENAME = mechanism.PANEL_FILENAME
PANELS_FILENAME = mechanism.PANELS_FILENAME
PANEL_AUDIT_FILENAME = mechanism.PANEL_AUDIT_FILENAME
SELECTOR_FILENAME = mechanism.SELECTOR_FILENAME
SELECTORS_FILENAME = mechanism.SELECTORS_FILENAME
SELECTOR_AUDIT_FILENAME = mechanism.SELECTOR_AUDIT_FILENAME
INFERENCE_DOCUMENT_FILENAME = "inference-document.json"


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one exact-predicate acquisition boundary reducer",
    }


def _observation_excerpt(observation: Any) -> str:
    projection = observation.benchmark_input
    if projection is not None:
        pieces = (
            observation.text[
                projection.step_marker_start_char : projection.step_marker_end_char
            ],
            observation.text[
                projection.observation_start_char : projection.observation_end_char
            ],
            observation.text[projection.suffix_start_char : projection.suffix_end_char],
        )
        return "\n".join(piece.strip() for piece in pieces if piece.strip())
    if observation.repeated_prefix_chars > 0:
        return observation.incremental_text.strip()
    return observation.text.strip()


def build_inference_document(case: Any) -> dict[str, Any]:
    """Project the full JudgeView while removing only cumulative wrapper duplication."""

    steps: list[dict[str, Any]] = []
    for step in case.judge_view.steps:
        owner_sources: dict[str, list[str]] = {
            module.value: [] for module in AgentModule
        }
        spans: list[dict[str, Any]] = []
        for span in step.module_spans:
            text = step.assistant_raw_output[
                span.content_start_char : span.content_end_char
            ]
            spans.append(
                {
                    "module": span.module,
                    "content_start_char": span.content_start_char,
                    "content_end_char": span.content_end_char,
                    "literal_text": text,
                }
            )
            if span.module in owner_sources and text.strip():
                owner_sources[span.module].append(text.strip())
        owner_sources[AgentModule.SYSTEM.value] = list(
            shared._luna_gaia_v2_owner_source_resolver(
                case.judge_view,
                step.step,
                AgentModule.SYSTEM,
                ErrorType.TOOL_EXECUTION_ERROR,
            )
        )
        steps.append(
            {
                "step": step.step,
                "current_input": [
                    value
                    for item in step.current_input
                    if (value := _observation_excerpt(item))
                ],
                "assistant_raw_output": step.assistant_raw_output,
                "module_spans": spans,
                "owner_sources": owner_sources,
                "adjacent_feedback": [
                    value
                    for item in step.adjacent_feedback
                    if (value := _observation_excerpt(item))
                ],
                "stop_reason": step.stop_reason,
                "error_message": step.error_message,
            }
        )
    facts = case.judge_view.execution_facts
    return {
        "schema_version": "agentdebug.v3p67-deduplicated-full-judge-view.v1",
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "task": {"user_request": case.judge_view.task.user_request},
        "execution_facts": {
            "metadata_steps": facts.metadata_steps,
            "metadata_won": facts.metadata_won,
            "metadata_success": facts.metadata_success,
            "canonical_turn_count": facts.canonical_turn_count,
            "final_stop_reason": facts.final_stop_reason,
            "final_error_message": facts.final_error_message,
        },
        "step_count": len(steps),
        "steps": steps,
    }


def validate_inference_document(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    document_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    document_file, document = shared._load_artifact(
        document_path, role="v3.67 inference document"
    )
    if document != build_inference_document(case):
        shared._fail("non_deterministic_v3p67_inference_document", "inference_document")
    return _retag(
        {
            "schema_version": "agentdebug.v3p67-inference-document-audit.v1",
            "stage": "deterministic_deduplicated_full_judge_view",
            "gold_free_validation": True,
            "case_count": 1,
            "complete_step_coverage": True,
            "cumulative_wrapper_history_deduplicated": True,
            "input_sha256": {
                "prediction_manifest": shared._file_sha256(manifest),
                "cohort": shared._file_sha256(cohort),
            },
            "output_sha256": {
                INFERENCE_DOCUMENT_FILENAME: shared._file_sha256(document_file)
            },
        },
        policy="deterministic_gold_free_read_only_inference_document",
    )


def _file_input_contract() -> str:
    return f"""\
TRACE INPUT ACCESS
- The sole trace input is `{INFERENCE_DOCUMENT_FILENAME}` in the current directory.
- You must inspect that file before deciding.
- You may use read-only shell commands solely to read or search that exact file.
- Do not run `ls`, `find`, `tree`, `rg --files`, `git`, network commands, or validators.
- Do not read protocol source, any other file/path, parent directory, or absolute path.
- Do not create, edit, rename, or delete any file; the sandbox is read-only.
- Return only the JSON response. The parent process owns all artifact writes.
"""


def _replace_embedded_runtime_contract(task: str) -> str:
    return (
        task.replace(
            "- do not call shell, filesystem, network, or any other tool\n"
            "- do not inspect paths or directories; every permitted input is embedded below",
            "- only read-only shell access to the exact staged inference document is permitted\n"
            "- do not inspect directories or any other path",
        )
        .replace(mechanism.AGENT_JUDGE_LUNA_GAIA_V3_66_VERSION, AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION)
    )


def build_anchor_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> str:
    task = mechanism.build_anchor_response_task(
        prediction_manifest_path, cohort_manifest_path
    )
    task = task.split("EMBEDDED PREDICTION MANIFEST", 1)[0].rstrip()
    return _replace_embedded_runtime_contract(task) + "\n\n" + _file_input_contract()


def build_reducer_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> str:
    task = mechanism.build_reducer_task(
        prediction_manifest_path,
        cohort_manifest_path,
        anchor_path,
        ledger_path,
        checkpoint_path,
    )
    task = task.split("EMBEDDED CURRENT PREDICTION MANIFEST", 1)[0].rstrip()
    anchor = json.loads(Path(anchor_path).read_text(encoding="utf-8"))[0]
    ledger = json.loads(Path(ledger_path).read_text(encoding="utf-8"))
    checkpoint = json.loads(Path(checkpoint_path).read_text(encoding="utf-8"))
    return f"""{_replace_embedded_runtime_contract(task)}

{_file_input_contract()}

EMBEDDED FRESH V3.20 ANCHOR
{json.dumps(anchor, ensure_ascii=False, separators=(",", ":"))}

EMBEDDED FRESH V3.20 SPARSE LEDGER
{json.dumps(ledger, ensure_ascii=False, separators=(",", ":"))}

EMBEDDED FRESH V3.20 CHECKPOINT
{json.dumps(checkpoint, ensure_ascii=False, separators=(",", ":"))}
"""


def anchor_response_schema() -> dict[str, Any]:
    return mechanism.anchor_response_schema()


def reducer_response_schema() -> dict[str, Any]:
    return mechanism.reducer_response_schema()


def normalize_anchor_response(response: Any, *, case: Any) -> Any:
    if not isinstance(response, dict):
        return response
    value = json.loads(json.dumps(response))
    predictions = value.get("anchor_predictions")
    if isinstance(predictions, list) and len(predictions) == 1 and isinstance(predictions[0], dict):
        predictions[0]["trajectory_id"] = case.trajectory_id
        predictions[0]["trajectory_sha256"] = case.trajectory_sha256
        predictions[0]["status"] = "success"
    for field in ("step_candidates", "step_freeze"):
        if isinstance(value.get(field), dict):
            value[field]["trajectory_id"] = case.trajectory_id
    return value


def normalize_assessment_response(response: Any) -> Any:
    if not isinstance(response, dict) or response.get("candidate_status") != "none":
        return response
    value = json.loads(json.dumps(response))
    value.update(
        {
            "candidate_origin": "none",
            "candidate_step": None,
            "candidate_boundary_class": "none",
            "candidate_module": None,
            "candidate_error_type": None,
            "candidate_evidence_quote": None,
            "candidate_root_cause": None,
            "candidate_causal_summary": None,
            "candidate_rejected_adjacent_owner": None,
            "decision_time_capability": "not_applicable",
            "actual_exact_predicate_status": "not_applicable",
            "task_contribution": "not_applicable",
            "later_relation": "not_applicable",
            "local_repair_effect": "not_applicable",
            "recovery_status": "not_applicable",
            "qualifies_as_critical_boundary": False,
        }
    )
    return value


def materialize_anchor_response(*args: Any, **kwargs: Any) -> Any:
    return mechanism.materialize_anchor_response(*args, **kwargs)


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    audit = parent.validate_anchor_predictions(*paths)
    document = Path(paths[2]).expanduser().resolve().parent / INFERENCE_DOCUMENT_FILENAME
    inference = validate_inference_document(paths[0], paths[1], document)
    return _retag(
        {**audit, "response_only_read_only_input": inference},
        policy="unchanged_v3_20_anchor_response_only_read_only_input",
    )


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_assessment(*paths: str | Path) -> dict[str, Any]:
    audit = mechanism.validate_assessment(*paths)
    document = Path(paths[5]).expanduser().resolve().parent / INFERENCE_DOCUMENT_FILENAME
    inference = validate_inference_document(paths[0], paths[1], document)
    return _retag(
        {**audit, "response_only_read_only_input": inference},
        policy="one_exact_predicate_acquisition_boundary_assessment_read_only_input",
    )


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_assessment(*paths[:-1]), paths[-1])


build_selection_document = mechanism.build_selection_document
validate_selector = mechanism.validate_selector


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    audit = mechanism.validate_selector(*paths[:-1])
    return shared._write_audit(
        _retag(audit, policy="deterministic_exact_predicate_candidate_else_anchor"),
        paths[-1],
    )


def validate_agent_judge_luna_gaia_v3_67_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    factorized = mechanism._validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_67_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT,
        "selection_policy": "clean_v3_20_exact_predicate_acquisition_boundary_reducer",
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one exact-predicate acquisition boundary reducer",
        "anchor_semantics_unchanged_from_v3_20": True,
        "response_only_read_only_runtime_required": True,
        "all_selected_predictions_exact_copies": True,
        "factorized_specialist_panel": factorized,
    }


def validate_and_write_agent_judge_luna_gaia_v3_67_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(
        validate_agent_judge_luna_gaia_v3_67_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_luna_gaia_v3_67_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_reducer_file_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
    )


validate_and_write_agent_judge_luna_gaia_v3_37_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_67_audit
)
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_luna_gaia_v3_67_task
build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_67_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_67_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_67_audit
)


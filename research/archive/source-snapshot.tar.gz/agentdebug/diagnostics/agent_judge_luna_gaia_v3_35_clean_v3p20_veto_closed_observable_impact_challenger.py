"""Luna GAIA v3.35: clean v3.20 with veto-closed observable-impact adjudication."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger as transport
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent


AGENT_JUDGE_LUNA_GAIA_V3_35_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.35-clean-v3.20-"
    "veto-closed-observable-impact-challenger"
)
AGENT_JUDGE_LUNA_GAIA_V3_35_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_35_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_35_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases used by the shared paper-50 runner.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_35_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_35_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_35_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_35_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = transport.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = transport.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = transport.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = transport.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = transport.CHALLENGERS_FILENAME
ARBITER_FILENAME = transport.ARBITER_FILENAME
ARBITERS_FILENAME = transport.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = transport.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = transport.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = transport.PREDICTION_AUDIT_FILENAME

_VETO_PREFIX = re.compile(
    r"^anchor_evidence_class=(proven_execution_impact|"
    r"unsupported_capability_anchor|ordinary_path_intervention); "
    r"evidence_basis_step=(none|[1-9]\d*); "
    r"veto_counterfactual=(identity|ordinary_repair); "
)
_IDENTITY_REPAIR_PREFIX = (
    "veto_counterfactual=identity; observed_anchor_outcome_preserved=true; "
)
_ORDINARY_REPAIR_PREFIX = (
    "veto_counterfactual=ordinary_repair; observed_anchor_outcome_preserved=false; "
)


_VETO_CLOSED_RULES = """\
VETO-CLOSED OBSERVABLE-IMPACT SINGLE-CHALLENGER RULE

The frozen clean-v3.20 prediction is the incumbent anchor. Emit at most ONE
proposal across both chronological searches. Never retain a candidate pool.
The anchor remains the default under uncertainty. Step position, severity,
persistence, Planning ownership, or stronger wording never wins by itself.

ANCHOR EVIDENCE CLASS

Classify the anchor using literal adjacent trace evidence:

1. `proven_execution_impact`: an unrecovered task-material adjacent tool
   rejection, parameter rejection/misparse, or direct same-packet plan/Action
   contradiction is owned by the anchor. Generic site/tool failure is not
   enough. No strictly later proposal may override this anchor.
2. `unsupported_capability_anchor`: the anchor claims that an acquisition
   source, interface, tool, or probe cannot contribute, but no literal adjacent
   result proves incapability. A usable lead/result, normal empty result, or
   later mechanical recovery can make it a reasonable_probe or
   noncritical_predecessor.
3. `ordinary_path_intervention`: neither evidence class above applies.

VETO CLOSURE — BINDING COUNTERFACTUAL CONTRACT

If the anchor is classified reasonable_probe or noncritical_predecessor, that
veto is final. It is not a critical error to repair. Its counterfactual MUST be
identity: preserve the observed anchor action and adjacent feedback exactly,
close it as a non-error, and evaluate later Steps on the observed continuation.
Never replace the vetoed probe with a better tool, source, query, interface, or
route, and never use such a hypothetical reroute to erase later defects.

Begin anchor_only_repair_counterfactual exactly:
- identity after a veto: `veto_counterfactual=identity; observed_anchor_outcome_preserved=true; `
- ordinary critical-anchor comparison: `veto_counterfactual=ordinary_repair; observed_anchor_outcome_preserved=false; `

SEARCH 1 — STRICTLY EARLIER LITERAL HANDOFF

Scan Step 1 through anchor-1 chronologically. Propose only the first earlier
Step that literally owns a necessary result-to-state omission, contradiction,
false outcome reading, or immediate-target-to-Action loss; repairing that Step
can change the later path while anchor-only repair cannot remove it. Reject
harmless compression, informative probes, materially different routes, normal
failures, recovered/mechanical defects, and merely improvable behavior.

SEARCH 2 — STRICTLY LATER AFTER VETO CLOSURE

Run only when Search 1 found nothing and the anchor is a reasonable_probe or
noncritical_predecessor. Because its counterfactual is identity, scan Step
anchor+1 onward on the literal observed continuation. Propose the EARLIEST Step
whose local evidence is task-material, independently repairable, and can change
the subsequent path or answer while the observed probe/outcome is preserved.

A repeated strategy matures only after literal prior feedback rules out the
same normalized target, corpus, interface, and extraction route and the new
Step makes no material change. A wrong-success state requires literal adjacent
contradiction. Reject normal tool/site failures, recovered defects, faithful
propagation, merely local inefficiency, and unsupported terminal symptoms that
do not independently supply or repair the missing task fact. Do not skip an
eligible earlier plan/source mismatch or matured repetition for a later error.

Begin search_summary exactly:
`anchor_evidence_class=<proven_execution_impact|unsupported_capability_anchor|ordinary_path_intervention>; evidence_basis_step=<none|Step>; veto_counterfactual=<identity|ordinary_repair>; `

Use proposal_only_repair_counterfactual independently. direct_timeline_comparison
must compare the anchor, every intervening plausible boundary, and the proposal.
search_summary must certify which searches ran, that no earlier eligible Step
was skipped, and that one proposal exists or none qualifies. A proposal must be
a complete legal prediction owned by its Step and module. When uncertain,
no_challenge.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_35_VERSION,
        )
        .replace(
            transport.AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_35_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_35_clean_v3p20_veto_closed_observable_impact_challenger",
        )
        .replace(
            "agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger",
            "agent_judge_luna_gaia_v3_35_clean_v3p20_veto_closed_observable_impact_challenger",
        )
    )


def _rewrite_mechanism(task: str) -> str:
    if task.count(transport._BOUNDED_BIDIRECTIONAL_RULES) != 1:
        raise RuntimeError("v3.16 challenger-rule marker changed unexpectedly")
    return task.replace(transport._BOUNDED_BIDIRECTIONAL_RULES, _VETO_CLOSED_RULES, 1)


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_anchor_task(*paths))


def build_challenger_task(*paths: str | Path) -> str:
    return _rewrite_identity(_rewrite_mechanism(transport.build_challenger_task(*paths)))


def build_arbiter_task(*paths: str | Path) -> str:
    return _rewrite_identity(_rewrite_mechanism(transport.build_arbiter_task(*paths)))


def build_agent_judge_luna_gaia_v3_35_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def _retag(audit: dict[str, Any]) -> dict[str, Any]:
    result = dict(audit)
    result["agent_judge_version"] = AGENT_JUDGE_LUNA_GAIA_V3_35_VERSION
    result["model"] = AGENT_JUDGE_LUNA_GAIA_V3_35_MODEL
    result["reasoning_effort"] = AGENT_JUDGE_LUNA_GAIA_V3_35_REASONING_EFFORT
    return result


def _validate_veto_closed_challengers(path: str | Path) -> dict[str, Any]:
    challenger_path, raw = shared._load_artifact(path, role="veto-closed challenger")
    rows = raw if isinstance(raw, list) else [raw]
    if not rows or any(not isinstance(row, dict) for row in rows):
        shared._fail("invalid_veto_closed_challengers", "records unavailable")
    class_counts: Counter[str] = Counter()
    counterfactual_counts: Counter[str] = Counter()
    for index, row in enumerate(rows):
        location = f"challenger[{index}]"
        match = _VETO_PREFIX.match(row.get("search_summary") or "")
        if match is None:
            shared._fail("missing_veto_closed_prefix", location)
        evidence_class, basis_text, counterfactual = match.groups()
        basis_step = None if basis_text == "none" else int(basis_text)
        anchor_step = row.get("anchor_step")
        classification = row.get("anchor_classification")
        proposal = row.get("proposed_prediction")
        proposal_step = proposal.get("predicted_step") if isinstance(proposal, dict) else None
        if evidence_class != "ordinary_path_intervention" and basis_step != anchor_step:
            shared._fail("veto_basis_not_anchor_step", location)
        vetoed = classification in {"reasonable_probe", "noncritical_predecessor"}
        expected_counterfactual = "identity" if vetoed else "ordinary_repair"
        if counterfactual != expected_counterfactual:
            shared._fail("veto_counterfactual_inconsistent", location)
        repair_text = row.get("anchor_only_repair_counterfactual") or ""
        required_repair_prefix = (
            _IDENTITY_REPAIR_PREFIX if vetoed else _ORDINARY_REPAIR_PREFIX
        )
        if not repair_text.startswith(required_repair_prefix):
            shared._fail("anchor_repair_prefix_inconsistent", location)
        if (
            evidence_class == "proven_execution_impact"
            and row.get("challenge_status") == "challenge"
            and isinstance(proposal_step, int)
            and proposal_step > anchor_step
        ):
            shared._fail("proven_impact_later_override", location)
        if (
            evidence_class == "unsupported_capability_anchor"
            and row.get("challenge_status") == "challenge"
            and not vetoed
        ):
            shared._fail("capability_override_without_closed_veto", location)
        class_counts[evidence_class] += 1
        counterfactual_counts[counterfactual] += 1
    return {
        "required": True,
        "valid": True,
        "path": str(challenger_path),
        "record_count": len(rows),
        "evidence_class_counts": dict(sorted(class_counts.items())),
        "veto_counterfactual_counts": dict(sorted(counterfactual_counts.items())),
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths))


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    audit = _retag(transport.validate_challenger(*paths))
    audit["veto_closed_observable_impact"] = _validate_veto_closed_challengers(
        paths[-1]
    )
    return audit


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    return _retag(transport.validate_arbiter(*paths))


def validate_agent_judge_luna_gaia_v3_35_predictions(
    *paths: str | Path,
) -> dict[str, Any]:
    audit = _retag(transport.validate_agent_judge_luna_gaia_v3_16_predictions(*paths))
    predictions = Path(paths[2]).expanduser().resolve()
    audit["schema_version"] = AGENT_JUDGE_LUNA_GAIA_V3_35_AUDIT_SCHEMA_VERSION
    audit["selection_policy"] = (
        "clean_v3_20_packet_state_anchor_one_veto_closed_observable_impact_"
        "challenger_default_keep_exact_copy_arbiter"
    )
    audit["direct_semantic_parent"] = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION
    audit["rejected_lineage_inherited"] = False
    audit["packet_state_closure"] = parent._validate_packet_state_ledgers(
        predictions.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME
    )
    audit["anchor_semantics_unchanged_from_v3_20"] = True
    audit["veto_closed_observable_impact"] = _validate_veto_closed_challengers(
        predictions.parent / CHALLENGERS_FILENAME
    )
    return audit


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_35_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_35_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_35_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_35_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_35_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_35_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

"""Luna Agent Judge v12: forced local-boundary replacement of the sink."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _assert_safe_path,
)
from .agent_judge_luna_v3 import validate_agent_judge_luna_v3_predictions
from .agent_judge_luna_v7 import INCUMBENT_PROPOSAL_FILENAME
from .agent_judge_luna_v11 import (
    AGENT_JUDGE_LUNA_V11_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_LUNA_V11_VERSION,
    _SINK_ISOLATED_REVIEW,
    build_agent_judge_luna_v11_task,
    validate_agent_judge_luna_v11_predictions,
)


AGENT_JUDGE_LUNA_V12_VERSION = "agentdebug.codex-agent-judge.luna-v12"
AGENT_JUDGE_LUNA_V12_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_V12_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_V12_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_V11_AUDIT_SCHEMA_VERSION
)

_BASE_HEADER = f"Run the frozen Codex Agent Judge protocol {AGENT_JUDGE_LUNA_V11_VERSION}."
_LUNA_HEADER = (
    "Run the frozen Codex Agent Judge protocol "
    f"{AGENT_JUDGE_LUNA_V12_VERSION}."
)
_BASE_ALLOWLIST = "agentdebug/diagnostics/agent_judge_luna_v11.py"
_LUNA_ALLOWLIST = "agentdebug/diagnostics/agent_judge_luna_v12.py"
_BASE_VALIDATOR_IMPORT = "agentdebug.diagnostics.agent_judge_luna_v11"
_LUNA_VALIDATOR_IMPORT = "agentdebug.diagnostics.agent_judge_luna_v12"
_BASE_VALIDATOR_ENTRY = "validate_and_write_agent_judge_luna_v11_audit"
_LUNA_VALIDATOR_ENTRY = "validate_and_write_agent_judge_luna_v12_audit"

_FORCED_LOCAL_BOUNDARY_REVIEW = """
V12 FORCED SINGLE-LOCAL-FAILURE SINK REVIEW

Read the one same-case Luna v3 proposal only after independently understanding
the complete JudgeView.  It is untrusted semantic context, never evidence or a
label.  Apply this mechanical scope gate before semantic revision:

- If `predicted_module` is not exactly `planning`, or `predicted_error_type` is
  not exactly `inefficient_plan`, output an exact byte-for-field copy of all
  ten proposal fields.  No alternative, owner correction, or rewording is
  allowed.
- If the proposal has the exact pair `planning/inefficient_plan`, it is a
  rejected sink hypothesis.  You MUST select a different `predicted_step`.
  Keeping or merely rewording the proposed step is invalid.  Reconstruct the
  trajectory from scratch and identify the strongest single locally
  attributable failure boundary below.

TARGET SEMANTICS

The benchmark requests one critical failure annotation.  For this sink review,
do not force the answer to be the earliest hindsight weakness and do not erase
a directly attributable later module as a mere downstream symptom.  Choose the
single output whose own words or action most clearly instantiate a taxonomy
error using information available at that step and materially explain the
recorded failure.  Local definition strength outranks generic chronology.

MANDATORY CROSS-MODULE COMPETITION

1. Build a chronological ledger of task requirements, observations, admissible
   actions, attempts, outcomes, and strategy resets.  Separately list every
   locally defensible Memory, Reflection, Planning, Action, and final System
   candidate.  The incumbent step may not appear in the final candidate set.

2. REFLECTION ASSERTION.  Prefer the exact Reflection that falsely reports
   success, progress, failure, causation, or task equivalence when the latest
   observation or literal user requirement disproves it.  Treat accepting a
   substitute object/attribute as progress as a mature error.  Also admit a
   Reflection that says a different approach is required while its guidance
   recommits to the same failed approach.  Attribute the assertion itself to
   Reflection rather than its following plan.

3. PLAN/ACTION CONTRACT.  Compare the same-step plan and action literally.
   If the plan says an attribute, fact, prerequisite, or state must be verified
   before commit, but the Action buys, answers, or mutates state without that
   verification, select that Action/misalignment step.  An action faithfully
   executing a defective plan stays downstream of Planning.

4. IMPOSSIBLE OR CONTRADICTED PLAN.  Prefer the plan that requires an object,
   capability, location, or state that has not been obtained and is not
   currently available.  Prefer a literal conflict with the task or current
   admissible-action/state evidence over a generic inefficiency complaint.

5. REPETITION MATURITY.  Do not mark initial acquisition plus one distinct
   confirmation as repetition.  For repeated searches, compare normalized
   query intent, returned product/source set, and the plan's claimed refinement.
   Select the later plan where the text itself acknowledges poor or repeated
   results yet proposes an almost identical query or operation.  A truly new
   target class, source, or materially changed constraint begins a new epoch.
   Within an epoch, select the clearest self-contradictory recommitment, not
   automatically the first or last repetition.

6. TERMINAL SYSTEM.  If the complete trajectory reaches an enforced step/tool
   limit while successive actions remain feasible, distinct, and responsive to
   observations, select the final System/step_limit boundary.  An unvisited
   target or hindsight-better strategy does not defeat System.  Reject System
   only when a locally explicit contradiction, false Reflection, impossible
   plan, or plan/action breach already dominates the failure.

7. PLANNING REMAINDER.  Select Planning/inefficient_plan only when its exact
   text recommits to known no-progress or makes a purported refinement that is
   materially equivalent to a failed attempt.  Quote the plan's own
   self-defeating commitment.  Do not use generic slow progress as evidence.

8. DECISION AUDIT.  Compare the strongest candidates by (a) literal taxonomy
   fit in the output itself, (b) contemporaneous contradiction, and (c) causal
   materiality.  Recheck predecessor and successor to avoid off-by-one
   ownership.  The final step must differ from the rejected proposal step.

Freeze the step first, then select its actual owner and taxonomy type.  Never
infer from case ID, source model, environment name, distributions, other
predictions, or gold.  Return only the strict ten-field record with no
scope/verdict field, confidence, score, rank, vote, or extra field.
"""


def _proposal_path(predictions_path: str | Path) -> Path:
    return Path(predictions_path).expanduser().resolve().parent / INCUMBENT_PROPOSAL_FILENAME


def build_agent_judge_luna_v12_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Build a forced replacement review for v3 Planning sinks."""

    task = build_agent_judge_luna_v11_task(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    replacements = {
        _BASE_HEADER: _LUNA_HEADER,
        _BASE_ALLOWLIST: _LUNA_ALLOWLIST,
        _BASE_VALIDATOR_IMPORT: _LUNA_VALIDATOR_IMPORT,
        _BASE_VALIDATOR_ENTRY: _LUNA_VALIDATOR_ENTRY,
        _SINK_ISOLATED_REVIEW.strip(): _FORCED_LOCAL_BOUNDARY_REVIEW.strip(),
    }
    for old, new in replacements.items():
        if task.count(old) != 1:
            raise RuntimeError(
                "Agent Judge Luna v11 task changed at a frozen v12 marker"
            )
        task = task.replace(old, new, 1)
    return task


def validate_agent_judge_luna_v12_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    proposal_path = _proposal_path(predictions_path)
    incumbent_audit = validate_agent_judge_luna_v3_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        proposal_path,
    )
    audit = validate_agent_judge_luna_v11_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    incumbent_records = json.loads(proposal_path.read_text(encoding="utf-8"))
    prediction_records = json.loads(
        Path(predictions_path).expanduser().resolve().read_text(encoding="utf-8")
    )
    forced_replacement_count = 0
    for incumbent, prediction in zip(
        incumbent_records,
        prediction_records,
        strict=True,
    ):
        is_sink = (
            incumbent["predicted_module"] == "planning"
            and incumbent["predicted_error_type"] == "inefficient_plan"
        )
        if not is_sink:
            continue
        forced_replacement_count += 1
        if prediction["predicted_step"] == incumbent["predicted_step"]:
            raise AgentJudgeValidationError(
                "sink_step_not_replaced",
                "Luna v12 retained the rejected sink step for trajectory "
                f"{incumbent['trajectory_id']}",
            )
    proposal_sha256 = hashlib.sha256(proposal_path.read_bytes()).hexdigest()
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_V12_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_V12_VERSION,
        "model": AGENT_JUDGE_LUNA_V12_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V12_REASONING_EFFORT,
        "incumbent_protocol": "agentdebug.codex-agent-judge.luna-v3",
        "incumbent_proposal_sha256": proposal_sha256,
        "incumbent_proposal_case_count": incumbent_audit["case_count"],
        "revision_scope": "planning/inefficient_plan forced step replacement",
        "forced_replacement_count": forced_replacement_count,
    }


def validate_and_write_agent_judge_luna_v12_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_v12_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    target = Path(audit_path).expanduser().resolve()
    _assert_safe_path(target, role="prediction audit output", is_output=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(f"{target.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(target)
    return audit


__all__ = [
    "AGENT_JUDGE_LUNA_V12_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_V12_MODEL",
    "AGENT_JUDGE_LUNA_V12_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_V12_VERSION",
    "AGENT_JUDGE_PREDICTION_FIELDS",
    "AgentJudgeValidationError",
    "INCUMBENT_PROPOSAL_FILENAME",
    "build_agent_judge_luna_v12_task",
    "validate_agent_judge_luna_v12_predictions",
    "validate_and_write_agent_judge_luna_v12_audit",
]

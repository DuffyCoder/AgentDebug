"""Luna GAIA v3.24: isolated per-state evidence ledger."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger as bidirectional
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as anchor_parent
from . import agent_judge_luna_gaia_v3_23_mandatory_state_scan_before_veto as parent
from .agent_judge_luna_gaia_v3_4 import STEP_CANDIDATE_LEDGER_FILENAME


AGENT_JUDGE_LUNA_GAIA_V3_24_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.24-isolated-state-evidence-ledger"
)
AGENT_JUDGE_LUNA_GAIA_V3_24_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_23_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_24_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_23_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_24_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_23_AUDIT_SCHEMA_VERSION
)

AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_24_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_24_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_24_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_24_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = parent.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = parent.CHALLENGERS_FILENAME
ARBITER_FILENAME = parent.ARBITER_FILENAME
ARBITERS_FILENAME = parent.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = parent.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = parent.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
CHALLENGER_FIELDS = parent.CHALLENGER_FIELDS
ARBITER_FIELDS = parent.ARBITER_FIELDS


_ROW_FIELDS = (
    "step",
    "state_quote",
    "feedback_quote",
    "candidate_kind",
    "candidate_relation",
    "downstream_consumer_step",
    "verdict",
)
_CANDIDATE_PAIRS = {
    "necessary_fact": "omitted",
    "entity_relation": "unsupported",
    "outcome_claim": "contradicted",
}
_SUMMARY_SUFFIX = re.compile(
    r"^; state_candidate_kind=(none|necessary_fact|entity_relation|outcome_claim); "
    r"state_candidate_relation=(not_applicable|omitted|unsupported|contradicted); "
    r"state_candidate_step=(none|[1-9]\d*); "
    r"state_direction=(none|earlier|same|later); comparison=(.+)$",
    re.DOTALL,
)


_EVIDENCE_LEDGER_RULES = """\
ISOLATED STATE EVIDENCE LEDGER — LOCAL PROOF BEFORE CANDIDATE FREEZE

The frozen packet-state prediction is the incumbent anchor. Do not change,
repair, or re-run it. This remains a state-only challenger: Planning, Action,
System, source, mechanical, acquisition, and terminal-answer errors cannot be
proposed unless a Memory/Reflection state Step independently owns one of the
three closed pairs below.

PHASE 1 — EMIT ONE LOCAL ROW FOR EVERY STATE STEP

List every Step containing Memory or Reflection, in exact chronology.
Emit exactly one ledger row for every listed Step; do not omit, merge, or stop early. Every row
must have fields in exactly this order:

`step`, `state_quote`, `feedback_quote`, `candidate_kind`,
`candidate_relation`, `downstream_consumer_step`, `verdict`.

- state_quote: a short literal excerpt from that Step's Memory/Reflection;
  use null only when its state spans are empty.
- feedback_quote: a short literal excerpt from that Step's adjacent feedback;
  use null only when no adjacent feedback exists.
- A clear row is exactly `none/not_applicable/null/clear`.
- A candidate row must use exactly one closed pair, name the later Step that
  consumes the defective state, and use verdict `candidate`.

Closed pairs:

1. `necessary_fact/omitted`: adjacent feedback contains a concrete title,
   value, constraint, source fact, provenance link, or discriminating result
   necessary for the unresolved subgoal or next decision, while this Step's
   state loses or materially distorts it.
2. `entity_relation/unsupported`: state asserts a concrete task-answer entity,
   value, credential, or relation unsupported by visible evidence and a later
   plan consumes that exact assertion.
3. `outcome_claim/contradicted`: state claims success, failure, progress, or a
   constraint that literal adjacent feedback contradicts and a later Step
   consumes the false outcome.

Harmless compression, details still available to the next decision, wording
polish, non-consumed speculation, and locally false but causally irrelevant
text are clear. An explicitly provisional explanation of irrelevant retrieval
is a query hypothesis, not an unsupported answer relation.

Begin search_summary exactly with a compact JSON array containing those rows:

`state_ledger=<JSON array>; state_candidate_kind=<none|necessary_fact|entity_relation|outcome_claim>; state_candidate_relation=<not_applicable|omitted|unsupported|contradicted>; state_candidate_step=<none|Step>; state_direction=<none|earlier|same|later>; comparison=<literal comparison>`

The EARLIEST ledger row with verdict candidate mechanically freezes all four
state_candidate fields. If every row is clear, use
`none/not_applicable/none/none`. Do not choose a more salient later row.

PHASE 2 — COMPARE THAT FROZEN CANDIDATE WITH THE ANCHOR

- If candidate Step equals anchor, no_challenge: the anchor already owns it.
- If candidate is earlier, challenge only when repairing that state can change
  the later path and repairing only the anchor leaves the earlier state defect;
  classify the anchor downstream_symptom.
- If candidate is later, challenge only when the anchor is a reasonable probe
  or noncritical predecessor and the candidate remains independently failure-
  causing after anchor-only repair.
- If the candidate loses comparison, emit no_challenge but keep the ledger and
  frozen candidate fields unchanged.
- If no candidate exists, emit no_challenge with the none fields.

A proposal must exactly use state_candidate_step, be owned by Memory or
Reflection, quote literal evidence, feed a current/later decision, and be the
only proposal. The independent arbiter still defaults to the anchor.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_23_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_24_VERSION,
        )
        .replace(
            bidirectional.AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_24_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_23_mandatory_state_scan_before_veto",
            "agent_judge_luna_gaia_v3_24_isolated_state_evidence_ledger",
        )
        .replace(
            "agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger",
            "agent_judge_luna_gaia_v3_24_isolated_state_evidence_ledger",
        )
    )


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_anchor_task(*paths))


def build_challenger_task(*paths: str | Path) -> str:
    task = parent.build_challenger_task(*paths)
    task = task.replace(parent._MANDATORY_SCAN_RULES, _EVIDENCE_LEDGER_RULES)
    task = task.replace(
        '"search_summary": "state_scan_steps=...; state_candidate_kind=...; state_candidate_relation=...; state_candidate_step=...; state_direction=...; literal scan and comparison summary"',
        '"search_summary": "state_ledger=[...]; state_candidate_kind=...; state_candidate_relation=...; state_candidate_step=...; state_direction=...; comparison=..."',
    )
    return _rewrite_identity(task)


def _state_steps(case: Any) -> list[int]:
    return [
        step.step
        for step in case.judge_view.steps
        if any(span.module in {"memory", "reflection"} for span in step.module_spans)
    ]


def _state_sources(step: Any) -> list[str]:
    raw = step.assistant_raw_output
    return [
        raw[span.content_start_char : span.content_end_char]
        for span in step.module_spans
        if span.module in {"memory", "reflection"}
        and raw[span.content_start_char : span.content_end_char].strip()
    ]


def _feedback_sources(step: Any) -> list[str]:
    return [item.text for item in step.adjacent_feedback if item.text.strip()]


def _literal_quote(
    value: Any,
    sources: Sequence[str],
    *,
    location: str,
    empty_code: str,
    literal_code: str,
) -> None:
    if not sources:
        if value is not None:
            shared._fail(empty_code, location)
        return
    if (
        not isinstance(value, str)
        or not value.strip()
        or len(value) > 600
        or not any(value in source for source in sources)
    ):
        shared._fail(literal_code, location)


def _parse_summary(value: Any, *, location: str) -> tuple[list[Any], tuple[str, ...]]:
    if not isinstance(value, str) or not value.startswith("state_ledger="):
        shared._fail("missing_state_evidence_ledger", location)
    start = len("state_ledger=")
    try:
        ledger, end = json.JSONDecoder().raw_decode(value, start)
    except (json.JSONDecodeError, TypeError):
        shared._fail("invalid_state_evidence_ledger_json", location)
    match = _SUMMARY_SUFFIX.fullmatch(value[end:])
    if match is None:
        shared._fail("invalid_state_evidence_ledger_suffix", location)
    if not isinstance(ledger, list):
        shared._fail("state_evidence_ledger_not_array", location)
    return ledger, match.groups()


def _validate_ledger_records(path: str | Path, cases: Sequence[Any]) -> dict[str, Any]:
    challenger_path, raw = shared._load_artifact(path, role="state evidence ledger")
    records = raw if isinstance(raw, list) else [raw]
    if len(records) != len(cases) or any(not isinstance(item, dict) for item in records):
        shared._fail("invalid_state_evidence_record_count", "case/record count differs")

    pair_counts: Counter[str] = Counter()
    direction_counts: Counter[str] = Counter()
    total_rows = 0
    candidate_rows = 0
    candidate_cases = 0
    earlier_candidate_cases = 0
    challenge_count = 0
    for index, (record, case) in enumerate(zip(records, cases, strict=True)):
        location = f"state_evidence[{index}]"
        ledger, suffix = _parse_summary(record.get("search_summary"), location=location)
        frozen_kind, frozen_relation, candidate_text, direction, _comparison = suffix
        expected_steps = _state_steps(case)
        if len(ledger) != len(expected_steps):
            shared._fail("state_evidence_ledger_row_count_mismatch", location)

        found_candidates: list[tuple[int, str, str]] = []
        for row_index, (row, expected_step) in enumerate(
            zip(ledger, expected_steps, strict=True)
        ):
            row_location = f"{location}.ledger[{row_index}]"
            if not isinstance(row, dict) or tuple(row) != _ROW_FIELDS:
                shared._fail("invalid_state_evidence_row_schema", row_location)
            if row["step"] != expected_step:
                shared._fail("state_evidence_ledger_step_order_mismatch", row_location)
            step = case.judge_view.steps[expected_step - 1]
            _literal_quote(
                row["state_quote"],
                _state_sources(step),
                location=f"{row_location}.state_quote",
                empty_code="nonempty_quote_for_empty_state",
                literal_code="nonliteral_state_quote",
            )
            _literal_quote(
                row["feedback_quote"],
                _feedback_sources(step),
                location=f"{row_location}.feedback_quote",
                empty_code="nonempty_quote_without_feedback",
                literal_code="nonliteral_feedback_quote",
            )
            kind = row["candidate_kind"]
            relation = row["candidate_relation"]
            consumer = row["downstream_consumer_step"]
            verdict = row["verdict"]
            if verdict == "clear":
                if (kind, relation, consumer) != ("none", "not_applicable", None):
                    shared._fail("invalid_clear_state_evidence_row", row_location)
            elif verdict == "candidate":
                if kind not in _CANDIDATE_PAIRS or relation != _CANDIDATE_PAIRS[kind]:
                    shared._fail("invalid_candidate_state_evidence_pair", row_location)
                if (
                    isinstance(consumer, bool)
                    or not isinstance(consumer, int)
                    or consumer <= expected_step
                    or consumer > len(case.judge_view.steps)
                ):
                    shared._fail("invalid_state_downstream_consumer", row_location)
                found_candidates.append((expected_step, kind, relation))
                candidate_rows += 1
            else:
                shared._fail("invalid_state_evidence_verdict", row_location)
            pair_counts[f"{kind}:{relation}"] += 1
            total_rows += 1

        candidate_step = None if candidate_text == "none" else int(candidate_text)
        if not found_candidates:
            if (
                candidate_step is not None
                or (frozen_kind, frozen_relation, direction)
                != ("none", "not_applicable", "none")
            ):
                shared._fail("empty_ledger_candidate_fields_mismatch", location)
        else:
            earliest_step, earliest_kind, earliest_relation = found_candidates[0]
            anchor_step = record.get("anchor_step")
            expected_direction = (
                "earlier"
                if earliest_step < anchor_step
                else "later"
                if earliest_step > anchor_step
                else "same"
            )
            if (
                (candidate_step, frozen_kind, frozen_relation, direction)
                != (earliest_step, earliest_kind, earliest_relation, expected_direction)
            ):
                shared._fail("earliest_state_candidate_derivation_mismatch", location)
            candidate_cases += 1
            if direction == "earlier":
                earlier_candidate_cases += 1

        status = record.get("challenge_status")
        proposal = record.get("proposed_prediction")
        if status == "challenge":
            if (
                candidate_step is None
                or direction not in {"earlier", "later"}
                or not isinstance(proposal, dict)
                or proposal.get("predicted_step") != candidate_step
                or proposal.get("predicted_module") not in {"memory", "reflection"}
            ):
                shared._fail("proposal_differs_from_ledger_candidate", location)
            challenge_count += 1
        elif status != "no_challenge":
            shared._fail("invalid_state_evidence_challenge_status", location)
        direction_counts[direction] += 1

    return {
        "required": True,
        "valid": True,
        "path": str(challenger_path),
        "record_count": len(records),
        "exact_state_row_coverage": True,
        "state_ledger_row_count": total_rows,
        "candidate_row_count": candidate_rows,
        "candidate_case_count": candidate_cases,
        "earlier_candidate_case_count": earlier_candidate_cases,
        "challenge_count": challenge_count,
        "row_pair_counts": dict(sorted(pair_counts.items())),
        "direction_counts": dict(sorted(direction_counts.items())),
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    audit = anchor_parent.validate_anchor_predictions(*paths)
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_24_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_24_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_24_REASONING_EFFORT,
        "anchor_semantics": "v3.20_packet_state_closure",
    }


def _validate_challenger_bundle(*paths: str | Path) -> tuple[Any, ...]:
    manifest, cohort, case = shared._single_case_paths(paths[0], paths[1])
    anchor_file = Path(paths[2]).expanduser().resolve()
    ledger_file = Path(paths[3]).expanduser().resolve()
    checkpoint_file = Path(paths[4]).expanduser().resolve()
    challenger_file, raw = shared._load_artifact(paths[5], role="challenger")
    anchor, anchor_ledger, checkpoint = shared._validate_anchor_bundle(
        manifest, cohort, anchor_file, ledger_file, checkpoint_file
    )
    challenger = shared._one_record(raw, role="challenger")
    # v3.16's semantic validator caps free text at 1800 characters. Validate a
    # compact in-memory view there, then validate the full ledger-bearing value
    # below without mutating the frozen artifact.
    compact = dict(challenger)
    compact["search_summary"] = "state evidence ledger validated separately"
    bidirectional._validate_challenger_record(
        compact,
        case=case,
        anchor=anchor,
        ledger=anchor_ledger,
        checkpoint=checkpoint,
        location="challenger[0]",
    )
    state_ledger = _validate_ledger_records(challenger_file, [case])
    return (
        manifest,
        cohort,
        case,
        anchor_file,
        ledger_file,
        checkpoint_file,
        challenger_file,
        anchor,
        anchor_ledger,
        checkpoint,
        challenger,
        state_ledger,
    )


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    (
        _manifest,
        _cohort,
        _case,
        anchor_file,
        ledger_file,
        checkpoint_file,
        challenger_file,
        _anchor,
        _anchor_ledger,
        _checkpoint,
        challenger,
        ledger,
    ) = _validate_challenger_bundle(*paths)
    proposal = challenger.get("proposed_prediction")
    direction = "none"
    if proposal is not None:
        direction = (
            "earlier"
            if proposal["predicted_step"] < challenger["anchor_step"]
            else "later"
        )
    return {
        "schema_version": "agentdebug.isolated-state-evidence-ledger-challenger-audit.v1",
        "stage": "challenger",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_24_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_24_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_24_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": 1,
        "challenge_status": challenger["challenge_status"],
        "challenge_direction": direction,
        "earlier_first": True,
        "single_challenger_maximum": True,
        "input_sha256": {
            ANCHOR_PREDICTIONS_FILENAME: shared._file_sha256(anchor_file),
            STEP_CANDIDATE_LEDGER_FILENAME: shared._file_sha256(ledger_file),
            "step-freeze.json": shared._file_sha256(checkpoint_file),
        },
        "output_sha256": {CHALLENGER_FILENAME: shared._file_sha256(challenger_file)},
        "isolated_state_evidence_ledger": ledger,
    }


def build_arbiter_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    challenger_path: str | Path,
    arbiter_path: str | Path,
) -> str:
    (
        manifest,
        cohort,
        case,
        anchor_file,
        ledger_file,
        checkpoint_file,
        challenger_file,
        anchor,
        _anchor_ledger,
        _checkpoint,
        challenger,
        _state_ledger,
    ) = _validate_challenger_bundle(
        prediction_manifest_path,
        cohort_manifest_path,
        anchor_path,
        ledger_path,
        checkpoint_path,
        challenger_path,
    )
    output = Path(arbiter_path).expanduser().resolve()
    shared._assert_safe_path(output, role="arbiter output", is_output=True)
    audit = output.parent / ARBITER_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_24_isolated_state_evidence_ledger",
            "--compact-validate",
            "arbiter",
            manifest,
            cohort,
            anchor_file,
            ledger_file,
            checkpoint_file,
            challenger_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "challenger_sha256": shared._stable_sha256(challenger),
        "anchor_step": anchor["predicted_step"],
        "decision": "keep_anchor or accept_challenger",
        "frozen_step": "selected prediction Step",
        "selected_prediction_sha256": "stable JSON hash of exact selected prediction",
        "selected_prediction": "exact unchanged anchor or challenger prediction object",
        "decision_basis": "literal-evidence threshold decision",
        "rejected_alternative_basis": "why the other exact prediction loses",
    }
    boundary = shared._boundary(
        manifest=manifest,
        cohort=cohort,
        reads=(anchor_file, ledger_file, checkpoint_file, challenger_file),
        output=output,
    ).replace(
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_13_conservative_challenger.py",
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_24_isolated_state_evidence_ledger.py",
    )
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_24_VERSION} stage 3/3: independent arbiter.

{boundary}

{_EVIDENCE_LEDGER_RULES}

The anchor is the default. Re-read the complete trace, every state evidence
ledger row, and the one frozen challenger. Accept it only if row-local literal
evidence, typed pair, downstream consumer, direction-specific repair tests,
and earliest-candidate derivation all hold. If there is no challenge, keep_anchor.

selected_prediction must be an exact field-for-field copy of the anchor when
keeping it, or the proposed_prediction when accepting. Do not repair, rewrite,
or invent a third prediction. Compute selected_prediction_sha256 as stable
sorted compact JSON content hash of that exact object.

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    (
        _manifest,
        _cohort,
        case,
        anchor_file,
        _ledger_file,
        _checkpoint_file,
        challenger_file,
        anchor,
        _anchor_ledger,
        _checkpoint,
        challenger,
        ledger,
    ) = _validate_challenger_bundle(*paths[:6])
    arbiter_file, arbiter_raw = shared._load_artifact(paths[6], role="arbiter")
    arbiter = shared._one_record(arbiter_raw, role="arbiter")
    bidirectional._validate_arbiter_record(
        arbiter,
        case=case,
        anchor=anchor,
        challenger=challenger,
        location="arbiter[0]",
    )
    return {
        "schema_version": "agentdebug.isolated-state-evidence-ledger-arbiter-audit.v1",
        "stage": "arbiter",
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_24_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_24_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_24_REASONING_EFFORT,
        "gold_free_validation": True,
        "case_count": 1,
        "decision": arbiter["decision"],
        "default_anchor_policy": True,
        "selected_prediction_exact_copy": True,
        "input_sha256": {
            ANCHOR_PREDICTIONS_FILENAME: shared._file_sha256(anchor_file),
            CHALLENGER_FILENAME: shared._file_sha256(challenger_file),
        },
        "output_sha256": {ARBITER_FILENAME: shared._file_sha256(arbiter_file)},
        "isolated_state_evidence_ledger": ledger,
    }


def build_agent_judge_luna_gaia_v3_24_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / STEP_CANDIDATE_LEDGER_FILENAME,
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def validate_agent_judge_luna_gaia_v3_24_predictions(*paths: str | Path) -> dict[str, Any]:
    manifest, cohort, cases = shared._load_cases(paths[0], paths[1])
    predictions = Path(paths[2]).expanduser().resolve()
    audit = shared._validate_agent_judge_predictions_with_owner_sources(
        manifest,
        cohort,
        predictions,
        owner_source_resolver=shared._luna_gaia_v2_owner_source_resolver,
    )
    anchor_file, anchors = shared._load_artifact(
        predictions.parent / ANCHOR_PREDICTIONS_FILENAME, role="merged anchors"
    )
    ledger_file, anchor_ledgers = shared._load_artifact(
        predictions.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME,
        role="merged anchor ledgers",
    )
    checkpoint_file, checkpoints = shared._load_artifact(
        predictions.parent / ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        role="merged anchor checkpoints",
    )
    challenger_file, challengers = shared._load_artifact(
        predictions.parent / CHALLENGERS_FILENAME, role="merged challengers"
    )
    arbiter_file, arbiters = shared._load_artifact(
        predictions.parent / ARBITERS_FILENAME, role="merged arbiters"
    )
    final_predictions = shared._load_json(predictions, role="predictions")
    values = (
        anchors,
        anchor_ledgers,
        checkpoints,
        challengers,
        arbiters,
        final_predictions,
    )
    if any(not isinstance(value, list) or len(value) != len(cases) for value in values):
        shared._fail(
            "invalid_merged_state_evidence_count", "all merged artifacts need all cases"
        )
    decisions: list[str] = []
    directions: list[str] = []
    for index, (
        case,
        anchor,
        anchor_ledger,
        checkpoint,
        challenger,
        arbiter,
        prediction,
    ) in enumerate(
        zip(
            cases,
            anchors,
            anchor_ledgers,
            checkpoints,
            challengers,
            arbiters,
            final_predictions,
            strict=True,
        )
    ):
        location = f"merged[{index}]"
        shared._validate_prediction_record(anchor, case=case, location=f"{location}.anchor")
        if (
            not isinstance(anchor_ledger, dict)
            or anchor_ledger.get("trajectory_id") != case.trajectory_id
            or anchor_ledger.get("selected_step") != anchor["predicted_step"]
            or not isinstance(checkpoint, dict)
            or checkpoint.get("trajectory_id") != case.trajectory_id
            or checkpoint.get("predicted_step") != anchor["predicted_step"]
        ):
            shared._fail("merged_anchor_sidecar_mismatch", location)
        compact = dict(challenger)
        compact["search_summary"] = "state evidence ledger validated separately"
        bidirectional._validate_challenger_record(
            compact,
            case=case,
            anchor=anchor,
            ledger=anchor_ledger,
            checkpoint=checkpoint,
            location=f"{location}.challenger",
        )
        bidirectional._validate_arbiter_record(
            arbiter,
            case=case,
            anchor=anchor,
            challenger=challenger,
            location=f"{location}.arbiter",
        )
        if prediction != arbiter["selected_prediction"]:
            shared._fail("final_prediction_differs_from_arbiter", location)
        decisions.append(arbiter["decision"])
        proposal = challenger.get("proposed_prediction")
        directions.append(
            "none"
            if proposal is None
            else (
                "earlier"
                if proposal["predicted_step"] < anchor["predicted_step"]
                else "later"
            )
        )
    packet_state = anchor_parent._validate_packet_state_ledgers(
        predictions.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME
    )
    ledger = _validate_ledger_records(predictions.parent / CHALLENGERS_FILENAME, cases)
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_24_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_24_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_24_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_24_REASONING_EFFORT,
        "selection_policy": (
            "v3_20_packet_state_anchor_isolated_state_evidence_ledger_"
            "earliest_candidate_one_bidirectional_challenger_default_keep_arbiter"
        ),
        "anchor_semantics_unchanged_from_v3_20": True,
        "single_challenger_maximum": True,
        "all_selected_predictions_exact_copies": True,
        "arbiter_decision_counts": dict(sorted(Counter(decisions).items())),
        "challenger_direction_counts": dict(sorted(Counter(directions).items())),
        "input_sidecar_sha256": {
            ANCHOR_PREDICTIONS_FILENAME: shared._file_sha256(anchor_file),
            ANCHOR_LEDGER_AGGREGATE_FILENAME: shared._file_sha256(ledger_file),
            ANCHOR_CHECKPOINT_AGGREGATE_FILENAME: shared._file_sha256(checkpoint_file),
            CHALLENGERS_FILENAME: shared._file_sha256(challenger_file),
            ARBITERS_FILENAME: shared._file_sha256(arbiter_file),
        },
        "packet_state_closure": packet_state,
        "isolated_state_evidence_ledger": ledger,
    }


def _write_audit(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_24_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        validate_agent_judge_luna_gaia_v3_24_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_24_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_24_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_24_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_24_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

"""Pairwise boundary adjudication with classification precommitment.

V17 keeps v16's anonymous JudgeView, strict evidence atoms, and one fresh
session per case.  The model serializes a complete per-step owner/type bank
before it emits any locator or arbitration fields.  Three complementary,
owner-neutral anchors then nominate Steps: a contract/affordance boundary, an
optional two-evidence state-fidelity boundary, and an optional recurrence
boundary.  The parent deduplicates equal anchor Steps, constructs only the
bounded pairs ``{X-1, X}``, and derives final owner/type exclusively from the
already serialized bank entry at the selected Step.

This remains one autoregressive response.  Serialization order is auditable,
but earlier and later fields are not hidden from the model and this is not an
independent classifier-agent topology.
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Iterable, Mapping

from agentdebug.benchmark.prediction_manifest import load_prediction_manifest

from . import agent_judge_luna_v16_unified as _v16
from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _file_sha256,
    _load_json,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_luna_v13_unified import (
    _anonymized_timeline,
    _leaf_and_residual_owner_source_resolver,
)
from .agent_judge_luna_v14_unified import (
    _anonymize_atom_text,
    _atom_catalog_sha256,
    _public_atom_catalog,
    _required_text,
    _validate_one_case_identity,
)
from .agent_judge_v2_4 import AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
from .taxonomy import AgentModule, ErrorType, is_valid_classification, taxonomy_prompt


AGENT_JUDGE_LUNA_V17_UNIFIED_VERSION = (
    "agentdebug.codex-agent-judge.luna-v17-unified-v1"
)
AGENT_JUDGE_LUNA_V17_UNIFIED_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_V17_UNIFIED_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_V17_UNIFIED_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)

DECISION_FILENAME = "decision.json"

_ATOM_SCHEMA_VERSION = "agentdebug.luna-v17-evidence-atoms.v1"
_NEUTRAL_TEXT_SCHEMA_VERSION = "agentdebug.luna-v17-neutral-texts.v1"
_REFERENCE_SCHEMA_VERSION = "agentdebug.luna-v17-reference-atoms.v1"
_STEP_SCHEMA_VERSION = "agentdebug.luna-v17-step-cards.v1"
_DECISION_AUDIT_SCHEMA_VERSION = (
    "agentdebug.codex-agent-judge-luna-v17-decision-audit.v1"
)

_STEP_PREFIX = "SC-"
_ATOM_PREFIX = "EA-"
_TEXT_PREFIX = "ET-"
_REFERENCE_PREFIX = "RA-"
_NEUTRAL_TEXT_DISPLAY_MAX_CHARS = 240
_REFERENCE_PREVIEW_MAX_CHARS = 960

_PHASE_NAMES = (
    "classification_precommit",
    "anchor_discovery",
    "pairwise_boundaries",
    "global_arbitration",
)

_PRECOMMIT_FIELDS = frozenset(
    {
        "step_card_id",
        "owner_atom_id",
        "predicted_error_type",
        "rejected_adjacent_owner",
    }
)
_CONTRACT_FIELDS = frozenset(
    {
        "current_text_id",
        "supporting_reference_id",
        "contract_kind",
        "boundary_reason",
        "counterfactual",
    }
)
_STATE_CANDIDATE_FIELDS = frozenset(
    {
        "status",
        "claim_text_id",
        "prior_reference_id",
        "relation",
        "boundary_reason",
        "counterfactual",
    }
)
_RECURRENCE_CANDIDATE_FIELDS = frozenset(
    {
        "status",
        "current_text_id",
        "prior_action_text_id",
        "prior_result_reference_id",
        "recommitment_kind",
        "constraint_delta",
        "boundary_reason",
        "counterfactual",
    }
)
_NO_CANDIDATE_FIELDS = frozenset({"status", "reason"})
_PAIR_MEMBER_FIELDS = frozenset(
    {
        "step_card_id",
        "evidence_text_id",
        "defect_strength",
        "producer_consumer",
        "counterfactual",
    }
)
_PAIR_REVIEW_FIELDS = frozenset(
    {"members", "winner_step_card_id", "winner_reason"}
)
_GLOBAL_ASSESSMENT_FIELDS = frozenset(
    {"step_card_id", "comparative_judgment"}
)
_GLOBAL_FIELDS = frozenset(
    {
        "phase",
        "candidate_assessments",
        "selected_step_card_id",
        "selected_step_reason",
    }
)

_CONTRACT_KINDS = frozenset(
    {
        "literal_task_constraint",
        "missing_prerequisite",
        "plan_action_contract",
        "tool_target_contract",
        "unverified_hypothesis_condition",
        "observable_system_boundary",
    }
)
_STATE_RELATIONS = frozenset(
    {
        "contradicts",
        "materially_omits",
        "unsupported_completion",
        "causal_mismatch",
    }
)
_RECOMMITMENT_KINDS = frozenset(
    {
        "exact_action_arguments",
        "equivalent_action_same_target",
        "repeated_query_same_constraints",
        "repeated_tool_same_goal",
        "failed_family_return",
    }
)
_DEFECT_STRENGTHS = frozenset({"none", "weak", "material", "decisive"})
_WINNING_STRENGTHS = frozenset({"material", "decisive"})
_STATE_OWNER_VALUES = frozenset(
    {AgentModule.MEMORY.value, AgentModule.REFLECTION.value}
)
_CONTRACT_OWNER_VALUES = frozenset(
    {AgentModule.PLANNING.value, AgentModule.ACTION.value}
)
_REFERENCE_STATE_KINDS = frozenset({"observation", "tool_result"})

_PROVENANCE_RE = re.compile(
    r"(?:"
    r"contract[_ -](?:anchor|witness|lane|source)|"
    r"state[_ -](?:anchor|witness|lane|source)|"
    r"recurrence[_ -](?:anchor|witness|lane|source)|"
    r"chronological[_ -]witness|local[_ -]witness|strategy[_ -]witness|"
    r"\bnominated\s+by\b|\bbecause\s+(?:it\s+was\s+)?nominated\b|"
    r"\bnomination\s+count\b|\banchor\s+source\b|"
    r"\b(?:won|selected\s+by)\s+(?:its\s+)?(?:boundary\s+)?pair\b|"
    r"\bpair\s+winner\b|"
    r"\b(?:candidate|card|pair)\s+(?:order|position)\b|"
    r"\blist\s+order\b|"
    r"\b(?:first|second|third|fourth|fifth|sixth)\s+"
    r"(?:card|candidate|entry|item|pair)\b"
    r")",
    flags=re.IGNORECASE,
)
_OWNER_ATOM_ID_RE = re.compile(r"\bEA-[0-9]{4}\b")


def _evidence_atoms(case: Any) -> tuple[dict[str, Any], ...]:
    """Reuse v16's strict owner-bound atom geometry unchanged."""

    return _v16._evidence_atoms(case)


def _step_cards(
    case: Any,
    atoms: tuple[dict[str, Any], ...],
) -> tuple[dict[str, Any], ...]:
    return _v16._step_cards(case, atoms)


def _step_catalog_sha256(cards: tuple[dict[str, Any], ...]) -> str:
    return _v16._step_catalog_sha256(cards)


def _public_step_catalog(cards: tuple[dict[str, Any], ...]) -> dict[str, Any]:
    return {
        "schema_version": _STEP_SCHEMA_VERSION,
        "step_count": len(cards),
        "cards": [dict(card) for card in cards],
    }


def _json_sha256(value: Any) -> str:
    body = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(body).hexdigest()


def _display_projection(text: str, *, max_chars: int) -> dict[str, Any]:
    if len(text) <= max_chars:
        return {"text": text}
    side = (max_chars - 4) // 2
    return {
        "text_prefix": text[:side],
        "text_suffix": text[-side:],
        "elided_char_count": len(text) - (2 * side),
    }


def _neutral_text_records(
    atoms: tuple[dict[str, Any], ...],
) -> tuple[dict[str, Any], ...]:
    merged: dict[str, dict[str, Any]] = {}
    for atom in atoms:
        text_id = atom["text_id"]
        record = merged.setdefault(
            text_id,
            {
                "text_id": text_id,
                "step": atom["step"],
                "step_card_id": f"{_STEP_PREFIX}{atom['step']:04d}",
                "display_text": atom["display_text"],
                "quote": atom["quote"],
                "raw_sha256": atom["raw_sha256"],
                "admissible_owner_modules": [],
            },
        )
        if any(
            record[field] != atom[field]
            for field in ("step", "display_text", "quote", "raw_sha256")
        ):
            raise AssertionError("v17 neutral text ID maps to multiple sources")
        record["admissible_owner_modules"].append(atom["owner_module"])
    records: list[dict[str, Any]] = []
    for text_id in sorted(merged):
        record = merged[text_id]
        records.append(
            {
                **record,
                "admissible_owner_modules": sorted(
                    set(record["admissible_owner_modules"])
                ),
            }
        )
    return tuple(records)


def _public_neutral_text_catalog(
    records: tuple[dict[str, Any], ...],
) -> dict[str, Any]:
    return {
        "schema_version": _NEUTRAL_TEXT_SCHEMA_VERSION,
        "text_count": len(records),
        "texts": [
            {
                "text_id": record["text_id"],
                "step_card_id": record["step_card_id"],
                **_display_projection(
                    record["display_text"],
                    max_chars=_NEUTRAL_TEXT_DISPLAY_MAX_CHARS,
                ),
            }
            for record in records
        ],
    }


def _neutral_text_catalog_sha256(
    records: tuple[dict[str, Any], ...],
) -> str:
    return _json_sha256(
        [
            {
                "text_id": record["text_id"],
                "step": record["step"],
                "raw_sha256": record["raw_sha256"],
            }
            for record in records
        ]
    )


def _reference_atoms(case: Any) -> tuple[dict[str, Any], ...]:
    """Build compact, exact, owner-neutral task/observation/result references."""

    sources: dict[tuple[int, int, str, str], str] = {}

    def add(
        text: Any,
        *,
        producer_step: int,
        available_before_step: int,
        source_kind: str,
        locator: str,
    ) -> None:
        if text is None:
            return
        if not isinstance(text, str):
            text = json.dumps(
                text,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
                default=str,
            )
        source = text.strip()
        if not source:
            return
        key = (producer_step, available_before_step, source_kind, source)
        prior = sources.get(key)
        if prior is None or locator < prior:
            sources[key] = locator

    task = case.judge_view.task
    if task is not None:
        for field in ("title", "description", "user_request"):
            add(
                getattr(task, field),
                producer_step=0,
                available_before_step=1,
                source_kind="task",
                locator=f"task.{field}",
            )

    step_count = len(case.judge_view.steps)
    for item in case.judge_view.steps:
        for input_index, observation in enumerate(item.current_input):
            projection = observation.benchmark_input
            if projection is not None and projection.declared_step == item.step:
                text = observation.text[
                    projection.observation_start_char : projection.observation_end_char
                ]
                locator = (
                    f"step[{item.step}].current_input[{input_index}]"
                    ".current_observation"
                )
            else:
                text = observation.incremental_text
                locator = f"step[{item.step}].current_input[{input_index}].incremental"
            add(
                text,
                producer_step=max(0, item.step - 1),
                available_before_step=item.step,
                source_kind="observation",
                locator=locator,
            )
        for call_index, call in enumerate(item.tool_calls):
            for result_index, result in enumerate(call.results):
                base = (
                    f"step[{item.step}].tool_calls[{call_index}]"
                    f".results[{result_index}]"
                )
                add(
                    result.output,
                    producer_step=item.step,
                    available_before_step=item.step + 1,
                    source_kind="tool_result",
                    locator=f"{base}.output",
                )
                add(
                    result.details,
                    producer_step=item.step,
                    available_before_step=item.step + 1,
                    source_kind="tool_result",
                    locator=f"{base}.details",
                )
        for feedback_index, observation in enumerate(item.adjacent_feedback):
            projection = observation.benchmark_input
            if (
                projection is not None
                and projection.declared_step == item.step + 1
            ):
                text = observation.text[
                    projection.observation_start_char : projection.observation_end_char
                ]
                locator = (
                    f"step[{item.step}].adjacent_feedback[{feedback_index}]"
                    ".next_observation"
                )
            else:
                text = observation.incremental_text
                locator = (
                    f"step[{item.step}].adjacent_feedback[{feedback_index}]"
                    ".incremental"
                )
            add(
                text,
                producer_step=item.step,
                available_before_step=item.step + 1,
                source_kind="observation",
                locator=locator,
            )

    ordered = sorted(
        sources.items(),
        key=lambda item: (
            item[0][1],
            item[0][0],
            item[0][2],
            hashlib.sha256(item[0][3].encode("utf-8")).hexdigest(),
            item[0][3],
            item[1],
        ),
    )
    if len(ordered) > 9999:
        raise AgentJudgeValidationError(
            "reference_catalog_too_large",
            "v17 supports at most 9999 compact reference atoms",
        )
    records: list[dict[str, Any]] = []
    for index, ((producer, available, kind, quote), locator) in enumerate(
        ordered, 1
    ):
        records.append(
            {
                "reference_id": f"{_REFERENCE_PREFIX}{index:04d}",
                "producer_step": producer,
                "available_before_step": available,
                "source_kind": kind,
                "source_locator": locator,
                "display_text": _anonymize_atom_text(case, quote),
                "quote": quote,
                "raw_sha256": hashlib.sha256(quote.encode("utf-8")).hexdigest(),
            }
        )
    return tuple(records)


def _public_reference_catalog(
    records: tuple[dict[str, Any], ...],
) -> dict[str, Any]:
    return {
        "schema_version": _REFERENCE_SCHEMA_VERSION,
        "reference_count": len(records),
        "references": [
            {
                "reference_id": record["reference_id"],
                "producer_step": record["producer_step"],
                "available_before_step": record["available_before_step"],
                "source_kind": record["source_kind"],
                "source_locator": record["source_locator"],
                **_display_projection(
                    record["display_text"],
                    max_chars=_REFERENCE_PREVIEW_MAX_CHARS,
                ),
            }
            for record in records
        ],
    }


def _reference_catalog_sha256(records: tuple[dict[str, Any], ...]) -> str:
    return _json_sha256(
        [
            {
                "reference_id": record["reference_id"],
                "producer_step": record["producer_step"],
                "available_before_step": record["available_before_step"],
                "source_kind": record["source_kind"],
                "source_locator": record["source_locator"],
                "raw_sha256": record["raw_sha256"],
            }
            for record in records
        ]
    )


def build_luna_v17_evidence_atom_catalog(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> dict[str, Any]:
    """Return the anonymous v17 owner, neutral-text, reference, and step catalogs."""

    _, _, _, case, _ = _validate_one_case_identity(
        prediction_manifest_path,
        cohort_manifest_path,
        role="task",
    )
    atoms = _evidence_atoms(case)
    cards = _step_cards(case, atoms)
    texts = _neutral_text_records(atoms)
    references = _reference_atoms(case)
    return {
        "schema_version": _ATOM_SCHEMA_VERSION,
        "atom_count": len(atoms),
        "catalog_sha256": _atom_catalog_sha256(atoms),
        "step_catalog_sha256": _step_catalog_sha256(cards),
        "neutral_text_catalog_sha256": _neutral_text_catalog_sha256(texts),
        "reference_catalog_sha256": _reference_catalog_sha256(references),
        "step_catalog": _public_step_catalog(cards),
        "neutral_text_catalog": _public_neutral_text_catalog(texts),
        "reference_catalog": _public_reference_catalog(references),
        **_public_atom_catalog(atoms),
    }


def decision_output_schema() -> dict[str, Any]:
    """Return the exact ordered-phase JSON schema supplied to the model."""

    nonempty = {"type": "string", "minLength": 1}
    step_id = {"type": "string", "pattern": r"^SC-[0-9]{4}$"}
    atom_id = {"type": "string", "pattern": r"^EA-[0-9]{4}$"}
    text_id = {"type": "string", "pattern": r"^ET-[0-9]{4}$"}
    reference_id = {"type": "string", "pattern": r"^RA-[0-9]{4}$"}

    classified_entry = {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_PRECOMMIT_FIELDS),
        "properties": {
            "step_card_id": step_id,
            "owner_atom_id": atom_id,
            "predicted_error_type": {
                "type": "string",
                "enum": [item.value for item in ErrorType],
            },
            "rejected_adjacent_owner": nonempty,
        },
    }
    null_entry = {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_PRECOMMIT_FIELDS),
        "properties": {
            "step_card_id": step_id,
            "owner_atom_id": {"type": "null"},
            "predicted_error_type": {"type": "null"},
            "rejected_adjacent_owner": {"type": "null"},
        },
    }
    no_candidate = {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_NO_CANDIDATE_FIELDS),
        "properties": {
            "status": {"const": "no_candidate"},
            "reason": nonempty,
        },
    }
    state_candidate = {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_STATE_CANDIDATE_FIELDS),
        "properties": {
            "status": {"const": "candidate"},
            "claim_text_id": text_id,
            "prior_reference_id": reference_id,
            "relation": {"type": "string", "enum": sorted(_STATE_RELATIONS)},
            "boundary_reason": nonempty,
            "counterfactual": nonempty,
        },
    }
    recurrence_candidate = {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_RECURRENCE_CANDIDATE_FIELDS),
        "properties": {
            "status": {"const": "candidate"},
            "current_text_id": text_id,
            "prior_action_text_id": text_id,
            "prior_result_reference_id": reference_id,
            "recommitment_kind": {
                "type": "string",
                "enum": sorted(_RECOMMITMENT_KINDS),
            },
            "constraint_delta": nonempty,
            "boundary_reason": nonempty,
            "counterfactual": nonempty,
        },
    }
    pair_member_properties = {
        "step_card_id": step_id,
        "evidence_text_id": text_id,
        "defect_strength": {
            "type": "string",
            "enum": sorted(_DEFECT_STRENGTHS),
        },
        "producer_consumer": nonempty,
        "counterfactual": nonempty,
    }
    pair_member = {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_PAIR_MEMBER_FIELDS),
        "properties": pair_member_properties,
    }
    global_assessment = {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_GLOBAL_ASSESSMENT_FIELDS),
        "properties": {
            "step_card_id": step_id,
            "comparative_judgment": nonempty,
        },
    }

    classification_phase = {
        "type": "object",
        "additionalProperties": False,
        "required": ["phase", "classification_bank"],
        "properties": {
            "phase": {"const": _PHASE_NAMES[0]},
            "classification_bank": {
                "type": "array",
                "minItems": 1,
                "maxItems": 9999,
                "items": {"oneOf": [classified_entry, null_entry]},
            },
        },
    }
    anchor_phase = {
        "type": "object",
        "additionalProperties": False,
        "required": [
            "phase",
            "contract_anchor",
            "state_anchor",
            "recurrence_anchor",
        ],
        "properties": {
            "phase": {"const": _PHASE_NAMES[1]},
            "contract_anchor": {
                "type": "object",
                "additionalProperties": False,
                "required": sorted(_CONTRACT_FIELDS),
                "properties": {
                    "current_text_id": text_id,
                    "supporting_reference_id": {
                        "oneOf": [reference_id, {"type": "null"}]
                    },
                    "contract_kind": {
                        "type": "string",
                        "enum": sorted(_CONTRACT_KINDS),
                    },
                    "boundary_reason": nonempty,
                    "counterfactual": nonempty,
                },
            },
            "state_anchor": {"oneOf": [state_candidate, no_candidate]},
            "recurrence_anchor": {
                "oneOf": [recurrence_candidate, no_candidate]
            },
        },
    }
    pair_phase = {
        "type": "object",
        "additionalProperties": False,
        "required": ["phase", "pair_reviews"],
        "properties": {
            "phase": {"const": _PHASE_NAMES[2]},
            "pair_reviews": {
                "type": "array",
                "minItems": 1,
                "maxItems": 3,
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "required": sorted(_PAIR_REVIEW_FIELDS),
                    "properties": {
                        "members": {
                            "type": "array",
                            "minItems": 1,
                            "maxItems": 2,
                            "items": pair_member,
                        },
                        "winner_step_card_id": step_id,
                        "winner_reason": nonempty,
                    },
                },
            },
        },
    }
    global_phase = {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_GLOBAL_FIELDS),
        "properties": {
            "phase": {"const": _PHASE_NAMES[3]},
            "candidate_assessments": {
                "type": "array",
                "minItems": 1,
                "maxItems": 3,
                "items": global_assessment,
            },
            "selected_step_card_id": step_id,
            "selected_step_reason": nonempty,
        },
    }
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "additionalProperties": False,
        "required": ["phases"],
        "properties": {
            "phases": {
                "type": "array",
                "minItems": 4,
                "maxItems": 4,
                "prefixItems": [
                    classification_phase,
                    anchor_phase,
                    pair_phase,
                    global_phase,
                ],
                "items": False,
            }
        },
    }


def _runtime_pair_member(step_card_id: str, text_id: str) -> dict[str, str]:
    return {
        "step_card_id": step_card_id,
        "evidence_text_id": text_id,
        "defect_strength": "material",
        "producer_consumer": "This decision produces the downstream failure.",
        "counterfactual": "Correcting it redirects the later failure chain.",
    }


def runtime_conformance_decision() -> dict[str, Any]:
    """Return a case-independent ordered-phase schema probe."""

    member = _runtime_pair_member("SC-0001", "ET-0001")
    return {
        "phases": [
            {
                "phase": "classification_precommit",
                "classification_bank": [
                    {
                        "step_card_id": "SC-0001",
                        "owner_atom_id": "EA-0001",
                        "predicted_error_type": ErrorType.INEFFICIENT_PLAN.value,
                        "rejected_adjacent_owner": (
                            "The adjacent ownership account lacks direct support."
                        ),
                    }
                ],
            },
            {
                "phase": "anchor_discovery",
                "contract_anchor": {
                    "current_text_id": "ET-0001",
                    "supporting_reference_id": None,
                    "contract_kind": "literal_task_constraint",
                    "boundary_reason": "The decision violates a literal constraint.",
                    "counterfactual": "Respecting the constraint redirects failure.",
                },
                "state_anchor": {
                    "status": "no_candidate",
                    "reason": "No exact two-evidence state discrepancy exists.",
                },
                "recurrence_anchor": {
                    "status": "no_candidate",
                    "reason": "No prior failed episode supports recommitment.",
                },
            },
            {
                "phase": "pairwise_boundaries",
                "pair_reviews": [
                    {
                        "members": [dict(member)],
                        "winner_step_card_id": "SC-0001",
                        "winner_reason": "The literal defect is material.",
                    }
                ],
            },
            {
                "phase": "global_arbitration",
                "candidate_assessments": [
                    {
                        "step_card_id": "SC-0001",
                        "comparative_judgment": (
                            "It is the strongest grounded counterfactual root."
                        ),
                    }
                ],
                "selected_step_card_id": "SC-0001",
                "selected_step_reason": (
                    "The selected decision is the strongest material root."
                ),
            },
        ]
    }


def _phase(value: Any, *, name: str, fields: frozenset[str]) -> Mapping[str, Any]:
    if not isinstance(value, Mapping) or set(value) != fields:
        raise AgentJudgeValidationError(
            "invalid_phase_fields", f"{name} has invalid fields"
        )
    if value.get("phase") != name:
        raise AgentJudgeValidationError(
            "invalid_phase_order", f"expected serialized phase {name}"
        )
    return value


def _resolve_step_id(
    value: Any,
    *,
    cards_by_id: Mapping[str, Mapping[str, Any]],
    location: str,
) -> Mapping[str, Any]:
    if not isinstance(value, str) or value not in cards_by_id:
        raise AgentJudgeValidationError(
            "unknown_step_card", f"{location} is not in the step catalog"
        )
    return cards_by_id[value]


def _resolve_text_id(
    value: Any,
    *,
    texts_by_id: Mapping[str, Mapping[str, Any]],
    location: str,
) -> Mapping[str, Any]:
    if not isinstance(value, str) or value not in texts_by_id:
        raise AgentJudgeValidationError(
            "unknown_neutral_text", f"{location} is not in the neutral text catalog"
        )
    return texts_by_id[value]


def _resolve_reference_id(
    value: Any,
    *,
    references_by_id: Mapping[str, Mapping[str, Any]],
    location: str,
) -> Mapping[str, Any]:
    if not isinstance(value, str) or value not in references_by_id:
        raise AgentJudgeValidationError(
            "unknown_reference_atom", f"{location} is not in the reference catalog"
        )
    return references_by_id[value]


def _precommit_bank(
    value: Any,
    *,
    cards: tuple[dict[str, Any], ...],
    atoms_by_id: Mapping[str, Mapping[str, Any]],
    location: str,
) -> tuple[list[dict[str, Any]], dict[int, tuple[dict[str, Any], Mapping[str, Any]]]]:
    if not isinstance(value, list) or len(value) != len(cards):
        raise AgentJudgeValidationError(
            "invalid_precommit_bank_coverage",
            "classification bank must contain every Step exactly once",
        )
    canonical: list[dict[str, Any]] = []
    classified_by_step: dict[
        int, tuple[dict[str, Any], Mapping[str, Any]]
    ] = {}
    for index, (item, card) in enumerate(zip(value, cards, strict=True)):
        item_location = f"{location}[{index}]"
        if not isinstance(item, Mapping) or set(item) != _PRECOMMIT_FIELDS:
            raise AgentJudgeValidationError(
                "invalid_precommit_fields", f"{item_location} has invalid fields"
            )
        if item["step_card_id"] != card["step_card_id"]:
            raise AgentJudgeValidationError(
                "invalid_precommit_bank_order",
                "classification bank must follow the complete ascending SC order",
            )
        nullable = (
            item["owner_atom_id"],
            item["predicted_error_type"],
            item["rejected_adjacent_owner"],
        )
        if all(part is None for part in nullable):
            canonical.append({**dict(item), "status": "unclassified"})
            continue
        if any(part is None for part in nullable):
            raise AgentJudgeValidationError(
                "partial_null_precommit",
                "owner atom, error type, and rejected owner must be all null or all non-null",
            )
        atom_id = item["owner_atom_id"]
        if not isinstance(atom_id, str) or atom_id not in atoms_by_id:
            raise AgentJudgeValidationError(
                "unknown_owner_atom", f"{item_location}.owner_atom_id is unknown"
            )
        atom = atoms_by_id[atom_id]
        if atom["step"] != card["step"]:
            raise AgentJudgeValidationError(
                "precommit_atom_step_mismatch",
                "precommit owner atom must belong to its declared Step",
            )
        try:
            error_type = ErrorType(item["predicted_error_type"])
        except (TypeError, ValueError) as error:
            raise AgentJudgeValidationError(
                "invalid_precommit_taxonomy", f"{item_location} has unknown taxonomy"
            ) from error
        module = AgentModule(atom["owner_module"])
        if not is_valid_classification(module, error_type):
            raise AgentJudgeValidationError(
                "invalid_precommit_taxonomy",
                f"{item_location} has an illegal module/error_type pair",
            )
        if error_type.value not in atom["allowed_error_types"]:
            raise AgentJudgeValidationError(
                "invalid_precommit_evidence",
                "precommit error type is not admitted by its exact owner atom",
            )
        _required_text(
            item["rejected_adjacent_owner"],
            location=f"{item_location}.rejected_adjacent_owner",
        )
        resolved = {
            **dict(item),
            "status": "classified",
            "step": card["step"],
            "predicted_module": atom["owner_module"],
            "evidence_quote": atom["quote"],
        }
        canonical.append(resolved)
        classified_by_step[card["step"]] = (resolved, atom)
    return canonical, classified_by_step


def _require_precommit(
    step: int,
    *,
    classified_by_step: Mapping[int, Any],
    location: str,
) -> None:
    if step not in classified_by_step:
        raise AgentJudgeValidationError(
            "anchor_step_not_precommitted",
            f"{location} resolves to an unclassified precommit Step",
        )


def _contract_anchor(
    value: Any,
    *,
    texts_by_id: Mapping[str, Mapping[str, Any]],
    references_by_id: Mapping[str, Mapping[str, Any]],
    classified_by_step: Mapping[int, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(value, Mapping) or set(value) != _CONTRACT_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_contract_anchor_fields", f"{location} has invalid fields"
        )
    text = _resolve_text_id(
        value["current_text_id"],
        texts_by_id=texts_by_id,
        location=f"{location}.current_text_id",
    )
    admits_agent_contract = bool(
        _CONTRACT_OWNER_VALUES.intersection(text["admissible_owner_modules"])
    )
    admits_strict_system = AgentModule.SYSTEM.value in text[
        "admissible_owner_modules"
    ]
    if not (admits_agent_contract or admits_strict_system):
        raise AgentJudgeValidationError(
            "contract_anchor_not_admissible",
            "contract anchor text must admit Planning, Action, or strict System source",
        )
    if value["contract_kind"] not in _CONTRACT_KINDS:
        raise AgentJudgeValidationError(
            "invalid_contract_kind", f"{location}.contract_kind is invalid"
        )
    if (
        value["contract_kind"] == "observable_system_boundary"
        and not admits_strict_system
    ):
        raise AgentJudgeValidationError(
            "contract_system_evidence_mismatch",
            "observable_system_boundary requires a privately admitted strict System atom",
        )
    if not admits_agent_contract and value["contract_kind"] != "observable_system_boundary":
        raise AgentJudgeValidationError(
            "contract_system_evidence_mismatch",
            "a System-only ET requires observable_system_boundary",
        )
    supporting = None
    reference_id = value["supporting_reference_id"]
    if reference_id is not None:
        supporting = _resolve_reference_id(
            reference_id,
            references_by_id=references_by_id,
            location=f"{location}.supporting_reference_id",
        )
        if supporting["available_before_step"] > text["step"]:
            raise AgentJudgeValidationError(
                "future_contract_reference",
                "contract support must have been available before the anchor decision",
            )
    _require_precommit(
        text["step"], classified_by_step=classified_by_step, location=location
    )
    for field in ("boundary_reason", "counterfactual"):
        _required_text(value[field], location=f"{location}.{field}")
    return {
        **dict(value),
        "step": text["step"],
        "step_card_id": text["step_card_id"],
        "evidence_quote": text["quote"],
        "supporting_reference_quote": (
            None if supporting is None else supporting["quote"]
        ),
    }


def _state_anchor(
    value: Any,
    *,
    texts_by_id: Mapping[str, Mapping[str, Any]],
    references_by_id: Mapping[str, Mapping[str, Any]],
    classified_by_step: Mapping[int, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise AgentJudgeValidationError(
            "invalid_state_anchor_fields", f"{location} must be an object"
        )
    if value.get("status") == "no_candidate":
        if set(value) != _NO_CANDIDATE_FIELDS:
            raise AgentJudgeValidationError(
                "invalid_state_anchor_fields", f"{location} has invalid fields"
            )
        _required_text(value["reason"], location=f"{location}.reason")
        return dict(value)
    if value.get("status") != "candidate" or set(value) != _STATE_CANDIDATE_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_state_anchor_fields", f"{location} has invalid fields"
        )
    claim = _resolve_text_id(
        value["claim_text_id"],
        texts_by_id=texts_by_id,
        location=f"{location}.claim_text_id",
    )
    if not _STATE_OWNER_VALUES.intersection(claim["admissible_owner_modules"]):
        raise AgentJudgeValidationError(
            "state_claim_not_admissible",
            "state claim ET must privately admit Memory or Reflection ownership",
        )
    prior = _resolve_reference_id(
        value["prior_reference_id"],
        references_by_id=references_by_id,
        location=f"{location}.prior_reference_id",
    )
    if prior["source_kind"] not in _REFERENCE_STATE_KINDS:
        raise AgentJudgeValidationError(
            "state_prior_not_observation",
            "state prior must be an exact observation or tool-result reference",
        )
    if prior["available_before_step"] > claim["step"]:
        raise AgentJudgeValidationError(
            "future_state_reference",
            "state prior must have been available before the current claim",
        )
    if value["relation"] not in _STATE_RELATIONS:
        raise AgentJudgeValidationError(
            "invalid_state_relation", f"{location}.relation is invalid"
        )
    _require_precommit(
        claim["step"], classified_by_step=classified_by_step, location=location
    )
    for field in ("boundary_reason", "counterfactual"):
        _required_text(value[field], location=f"{location}.{field}")
    return {
        **dict(value),
        "step": claim["step"],
        "step_card_id": claim["step_card_id"],
        "claim_quote": claim["quote"],
        "prior_reference_quote": prior["quote"],
        "prior_available_before_step": prior["available_before_step"],
        "prior_producer_step": prior["producer_step"],
        "prior_source_kind": prior["source_kind"],
    }


def _recurrence_anchor(
    value: Any,
    *,
    earlier_steps: set[int],
    texts_by_id: Mapping[str, Mapping[str, Any]],
    references_by_id: Mapping[str, Mapping[str, Any]],
    classified_by_step: Mapping[int, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise AgentJudgeValidationError(
            "invalid_recurrence_anchor_fields", f"{location} must be an object"
        )
    if value.get("status") == "no_candidate":
        if set(value) != _NO_CANDIDATE_FIELDS:
            raise AgentJudgeValidationError(
                "invalid_recurrence_anchor_fields", f"{location} has invalid fields"
            )
        _required_text(value["reason"], location=f"{location}.reason")
        return dict(value)
    if (
        value.get("status") != "candidate"
        or set(value) != _RECURRENCE_CANDIDATE_FIELDS
    ):
        raise AgentJudgeValidationError(
            "invalid_recurrence_anchor_fields", f"{location} has invalid fields"
        )
    current = _resolve_text_id(
        value["current_text_id"],
        texts_by_id=texts_by_id,
        location=f"{location}.current_text_id",
    )
    if not _CONTRACT_OWNER_VALUES.intersection(current["admissible_owner_modules"]):
        raise AgentJudgeValidationError(
            "recurrence_current_not_admissible",
            "recurrence current ET must admit a Planning or Action source",
        )
    if current["step"] in earlier_steps:
        raise AgentJudgeValidationError(
            "duplicate_recurrence_anchor_step",
            "recurrence must use a new Step or report no_candidate",
        )
    prior_action = _resolve_text_id(
        value["prior_action_text_id"],
        texts_by_id=texts_by_id,
        location=f"{location}.prior_action_text_id",
    )
    if AgentModule.ACTION.value not in prior_action["admissible_owner_modules"]:
        raise AgentJudgeValidationError(
            "recurrence_prior_not_action",
            "recurrence prior ET must admit Action source ownership",
        )
    if prior_action["step"] >= current["step"]:
        raise AgentJudgeValidationError(
            "recurrence_prior_not_earlier",
            "recurrence prior action must be earlier than current recommitment",
        )
    prior_result = _resolve_reference_id(
        value["prior_result_reference_id"],
        references_by_id=references_by_id,
        location=f"{location}.prior_result_reference_id",
    )
    if prior_result["source_kind"] not in _REFERENCE_STATE_KINDS:
        raise AgentJudgeValidationError(
            "recurrence_prior_result_invalid",
            "recurrence prior result must be an observation or tool result",
        )
    if prior_result["producer_step"] != prior_action["step"]:
        raise AgentJudgeValidationError(
            "recurrence_episode_mismatch",
            "prior result must be produced by the selected prior action Step",
        )
    if prior_result["available_before_step"] > current["step"]:
        raise AgentJudgeValidationError(
            "future_recurrence_result",
            "prior failure result must be available before recommitment",
        )
    if value["recommitment_kind"] not in _RECOMMITMENT_KINDS:
        raise AgentJudgeValidationError(
            "invalid_recommitment_kind", f"{location}.recommitment_kind is invalid"
        )
    _require_precommit(
        current["step"], classified_by_step=classified_by_step, location=location
    )
    for field in ("constraint_delta", "boundary_reason", "counterfactual"):
        _required_text(value[field], location=f"{location}.{field}")
    return {
        **dict(value),
        "step": current["step"],
        "step_card_id": current["step_card_id"],
        "current_quote": current["quote"],
        "prior_action_step": prior_action["step"],
        "prior_action_quote": prior_action["quote"],
        "prior_result_quote": prior_result["quote"],
        "prior_result_available_before_step": prior_result[
            "available_before_step"
        ],
    }


def _forbid_owner_atom_after_precommit(value: Any, *, location: str) -> None:
    if isinstance(value, Mapping):
        for key, item in value.items():
            if key in {"owner_atom_id", "predicted_module", "predicted_error_type"}:
                raise AgentJudgeValidationError(
                    "post_precommit_classification_leak",
                    f"{location} contains forbidden classification field {key}",
                )
            _forbid_owner_atom_after_precommit(item, location=f"{location}.{key}")
        return
    if isinstance(value, list):
        for index, item in enumerate(value):
            _forbid_owner_atom_after_precommit(
                item, location=f"{location}[{index}]"
            )
        return
    if isinstance(value, str) and _OWNER_ATOM_ID_RE.search(value):
        raise AgentJudgeValidationError(
            "post_precommit_owner_atom_id",
            f"{location} contains an owner atom ID after precommit",
        )


def _neutral_reason(value: Any, *, location: str) -> str:
    text = _required_text(value, location=location)
    if _PROVENANCE_RE.search(text):
        raise AgentJudgeValidationError(
            "arbitration_provenance_leak",
            f"{location} explicitly refers to anchor, pair, nomination, or order provenance",
        )
    return text


def _expected_pairs(anchor_steps: Iterable[int]) -> tuple[tuple[int, ...], ...]:
    return tuple(
        tuple(range(max(1, step - 1), step + 1))
        for step in sorted(set(anchor_steps))
    )


def _pair_member(
    value: Any,
    *,
    expected_step: int,
    cards_by_id: Mapping[str, Mapping[str, Any]],
    texts_by_id: Mapping[str, Mapping[str, Any]],
    classified_by_step: Mapping[int, Any],
    case: Any,
    location: str,
) -> dict[str, Any]:
    if not isinstance(value, Mapping) or set(value) != _PAIR_MEMBER_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_pair_member_fields", f"{location} has invalid fields"
        )
    card = _resolve_step_id(
        value["step_card_id"],
        cards_by_id=cards_by_id,
        location=f"{location}.step_card_id",
    )
    if card["step"] != expected_step:
        raise AgentJudgeValidationError(
            "pair_member_step_mismatch", f"{location} is not the expected pair Step"
        )
    _require_precommit(
        expected_step, classified_by_step=classified_by_step, location=location
    )
    text = _resolve_text_id(
        value["evidence_text_id"],
        texts_by_id=texts_by_id,
        location=f"{location}.evidence_text_id",
    )
    if text["step"] != expected_step:
        raise AgentJudgeValidationError(
            "pair_evidence_step_mismatch",
            "pair evidence ET must bind the exact assessed Step",
        )
    if value["defect_strength"] not in _DEFECT_STRENGTHS:
        raise AgentJudgeValidationError(
            "invalid_defect_strength", f"{location}.defect_strength is invalid"
        )
    for field in ("producer_consumer", "counterfactual"):
        _neutral_reason(value[field], location=f"{location}.{field}")
    return {
        **dict(value),
        "step": expected_step,
        "evidence_quote": text["quote"],
        "local_context_sha256": _v16._classification_context_sha256(
            case, expected_step
        ),
    }


def _pair_reviews(
    value: Any,
    *,
    expected_pairs: tuple[tuple[int, ...], ...],
    cards_by_id: Mapping[str, Mapping[str, Any]],
    texts_by_id: Mapping[str, Mapping[str, Any]],
    classified_by_step: Mapping[int, Any],
    case: Any,
    location: str,
) -> tuple[list[dict[str, Any]], list[int], dict[int, dict[str, Any]]]:
    if not isinstance(value, list) or len(value) != len(expected_pairs):
        raise AgentJudgeValidationError(
            "invalid_pair_review_coverage",
            "pair reviews must cover every deduplicated anchor pair exactly once",
        )
    expected_by_ids = {
        tuple(f"{_STEP_PREFIX}{step:04d}" for step in pair): pair
        for pair in expected_pairs
    }
    resolved_by_pair: dict[tuple[int, ...], dict[str, Any]] = {}
    winner_assessments: dict[int, dict[str, Any]] = {}
    for index, review in enumerate(value):
        item_location = f"{location}[{index}]"
        if not isinstance(review, Mapping) or set(review) != _PAIR_REVIEW_FIELDS:
            raise AgentJudgeValidationError(
                "invalid_pair_review_fields", f"{item_location} has invalid fields"
            )
        members = review["members"]
        if not isinstance(members, list):
            raise AgentJudgeValidationError(
                "invalid_pair_members", f"{item_location}.members must be a list"
            )
        member_ids = tuple(
            item.get("step_card_id") if isinstance(item, Mapping) else None
            for item in members
        )
        if member_ids not in expected_by_ids:
            raise AgentJudgeValidationError(
                "invalid_pair_geometry",
                "pair members must be the exact ascending parent-built {X-1,X} geometry",
            )
        pair = expected_by_ids[member_ids]
        if pair in resolved_by_pair:
            raise AgentJudgeValidationError(
                "duplicate_pair_review", "each parent-built pair must appear once"
            )
        resolved_members = [
            _pair_member(
                member,
                expected_step=step,
                cards_by_id=cards_by_id,
                texts_by_id=texts_by_id,
                classified_by_step=classified_by_step,
                case=case,
                location=f"{item_location}.members[{member_index}]",
            )
            for member_index, (member, step) in enumerate(zip(members, pair, strict=True))
        ]
        winner_id = review["winner_step_card_id"]
        if winner_id not in member_ids:
            raise AgentJudgeValidationError(
                "pair_winner_not_member", "pair winner must be one exact pair member"
            )
        winner = next(
            member for member in resolved_members if member["step_card_id"] == winner_id
        )
        if winner["defect_strength"] not in _WINNING_STRENGTHS:
            raise AgentJudgeValidationError(
                "weak_pair_winner", "pair winner must have material or decisive strength"
            )
        frozen_winner = {
            field: winner[field]
            for field in (
                "step_card_id",
                "evidence_text_id",
                "defect_strength",
                "producer_consumer",
                "counterfactual",
                "step",
                "evidence_quote",
                "local_context_sha256",
            )
        }
        prior_winner = winner_assessments.get(winner["step"])
        if prior_winner is not None and prior_winner != frozen_winner:
            raise AgentJudgeValidationError(
                "conflicting_duplicate_pair_winner",
                "the same Step won multiple pairs with different local evidence or analysis",
            )
        winner_assessments[winner["step"]] = frozen_winner
        _neutral_reason(
            review["winner_reason"], location=f"{item_location}.winner_reason"
        )
        resolved = {
            "anchor_step": max(pair),
            "members": resolved_members,
            "winner_step_card_id": winner_id,
            "winner_step": winner["step"],
            "winner_reason": review["winner_reason"],
        }
        resolved_by_pair[pair] = resolved
    if set(resolved_by_pair) != set(expected_pairs):
        raise AgentJudgeValidationError(
            "incomplete_pair_reviews", "pair reviews do not exhaust expected pairs"
        )
    canonical = [resolved_by_pair[pair] for pair in expected_pairs]
    winners = [review["winner_step"] for review in canonical]
    return canonical, winners, winner_assessments


def _global_arbitration(
    value: Mapping[str, Any],
    *,
    frozen_winner_assessments: Mapping[int, Mapping[str, Any]],
    location: str,
) -> tuple[dict[str, Any], int, dict[str, Any]]:
    expected_steps = tuple(sorted(frozen_winner_assessments))
    if not expected_steps:
        raise AssertionError("v17 global arbitration has no frozen pair winner")
    for step in expected_steps:
        frozen = frozen_winner_assessments[step]
        if (
            frozen.get("step") != step
            or frozen.get("step_card_id") != f"{_STEP_PREFIX}{step:04d}"
        ):
            raise AssertionError("v17 frozen pair-winner map is internally inconsistent")
    assessments = value["candidate_assessments"]
    if not isinstance(assessments, list) or len(assessments) != len(expected_steps):
        raise AgentJudgeValidationError(
            "invalid_global_candidate_coverage",
            "global arbitration must assess every deduplicated pair winner once",
        )
    expected_ids = {f"{_STEP_PREFIX}{step:04d}": step for step in expected_steps}
    resolved_by_step: dict[int, dict[str, Any]] = {}
    for index, assessment in enumerate(assessments):
        item_location = f"{location}.candidate_assessments[{index}]"
        if (
            not isinstance(assessment, Mapping)
            or set(assessment) != _GLOBAL_ASSESSMENT_FIELDS
        ):
            raise AgentJudgeValidationError(
                "invalid_global_assessment_fields", f"{item_location} has invalid fields"
            )
        step_id = assessment["step_card_id"]
        if step_id not in expected_ids:
            raise AgentJudgeValidationError(
                "global_candidate_not_pair_winner",
                "global candidate must be a deduplicated pair winner",
            )
        step = expected_ids[step_id]
        if step in resolved_by_step:
            raise AgentJudgeValidationError(
                "duplicate_global_candidate",
                "duplicate pair winners cannot create additional votes",
            )
        _neutral_reason(
            assessment["comparative_judgment"],
            location=f"{item_location}.comparative_judgment",
        )
        resolved_by_step[step] = {
            **dict(frozen_winner_assessments[step]),
            "comparative_judgment": assessment["comparative_judgment"],
        }
    if set(resolved_by_step) != set(expected_steps):
        raise AgentJudgeValidationError(
            "incomplete_global_candidates",
            "global assessments do not exhaust deduplicated pair winners",
        )
    selected_id = value["selected_step_card_id"]
    if selected_id not in expected_ids:
        raise AgentJudgeValidationError(
            "selected_step_not_pair_winner",
            "global selection must be one deduplicated pair winner",
        )
    selected_step = expected_ids[selected_id]
    selected_assessment = resolved_by_step[selected_step]
    if selected_assessment["defect_strength"] not in _WINNING_STRENGTHS:
        raise AgentJudgeValidationError(
            "weak_global_winner",
            "global winner must have material or decisive strength",
        )
    _neutral_reason(
        value["selected_step_reason"],
        location=f"{location}.selected_step_reason",
    )
    canonical_assessments = [resolved_by_step[step] for step in expected_steps]
    return (
        {**dict(value), "candidate_assessments": canonical_assessments},
        selected_step,
        selected_assessment,
    )


def _prediction_record(case: Any, candidate: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        **dict(candidate),
    }


def validate_luna_v17_unified_decision(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    decision_path: str | Path,
) -> dict[str, Any]:
    """Validate and mechanically resolve one ordered v17 decision."""

    manifest_path, cohort_path, _, case, cohort = _validate_one_case_identity(
        prediction_manifest_path,
        cohort_manifest_path,
        role="decision",
    )
    atoms = _evidence_atoms(case)
    atoms_by_id = {atom["evidence_atom_id"]: atom for atom in atoms}
    texts = _neutral_text_records(atoms)
    texts_by_id = {record["text_id"]: record for record in texts}
    references = _reference_atoms(case)
    references_by_id = {record["reference_id"]: record for record in references}
    cards = _step_cards(case, atoms)
    cards_by_id = {card["step_card_id"]: card for card in cards}
    if len(atoms_by_id) != len(atoms) or len(texts_by_id) != len(texts):
        raise AssertionError("v17 evidence IDs are not unique")
    if len(references_by_id) != len(references):
        raise AssertionError("v17 reference IDs are not unique")

    resolved_decision_path = Path(decision_path).expanduser().resolve()
    raw = _load_json(resolved_decision_path, role="decision")
    if not isinstance(raw, Mapping) or set(raw) != {"phases"}:
        raise AgentJudgeValidationError(
            "invalid_decision_fields", "decision must contain only ordered phases"
        )
    phases = raw["phases"]
    if not isinstance(phases, list) or len(phases) != len(_PHASE_NAMES):
        raise AgentJudgeValidationError(
            "invalid_phase_count", "decision must contain exactly four ordered phases"
        )

    precommit_phase = _phase(
        phases[0],
        name=_PHASE_NAMES[0],
        fields=frozenset({"phase", "classification_bank"}),
    )
    precommit_bank, classified_by_step = _precommit_bank(
        precommit_phase["classification_bank"],
        cards=cards,
        atoms_by_id=atoms_by_id,
        location="decision.phases[0].classification_bank",
    )

    anchor_phase = _phase(
        phases[1],
        name=_PHASE_NAMES[1],
        fields=frozenset(
            {"phase", "contract_anchor", "state_anchor", "recurrence_anchor"}
        ),
    )
    _forbid_owner_atom_after_precommit(anchor_phase, location="decision.phases[1]")
    contract = _contract_anchor(
        anchor_phase["contract_anchor"],
        texts_by_id=texts_by_id,
        references_by_id=references_by_id,
        classified_by_step=classified_by_step,
        location="decision.phases[1].contract_anchor",
    )
    state = _state_anchor(
        anchor_phase["state_anchor"],
        texts_by_id=texts_by_id,
        references_by_id=references_by_id,
        classified_by_step=classified_by_step,
        location="decision.phases[1].state_anchor",
    )
    earlier_steps = {contract["step"]}
    if state["status"] == "candidate":
        earlier_steps.add(state["step"])
    recurrence = _recurrence_anchor(
        anchor_phase["recurrence_anchor"],
        earlier_steps=earlier_steps,
        texts_by_id=texts_by_id,
        references_by_id=references_by_id,
        classified_by_step=classified_by_step,
        location="decision.phases[1].recurrence_anchor",
    )
    anchor_steps = set(earlier_steps)
    if recurrence["status"] == "candidate":
        anchor_steps.add(recurrence["step"])
    expected_pairs = _expected_pairs(anchor_steps)
    for pair in expected_pairs:
        for step in pair:
            _require_precommit(
                step,
                classified_by_step=classified_by_step,
                location=f"parent pair {pair}",
            )
            if not any(text["step"] == step for text in texts):
                raise AgentJudgeValidationError(
                    "pair_step_has_no_neutral_evidence",
                    f"parent pair Step {step} has no exact neutral evidence",
                )

    pair_phase = _phase(
        phases[2],
        name=_PHASE_NAMES[2],
        fields=frozenset({"phase", "pair_reviews"}),
    )
    _forbid_owner_atom_after_precommit(pair_phase, location="decision.phases[2]")
    boundary_pairs, pair_winners, frozen_winner_assessments = _pair_reviews(
        pair_phase["pair_reviews"],
        expected_pairs=expected_pairs,
        cards_by_id=cards_by_id,
        texts_by_id=texts_by_id,
        classified_by_step=classified_by_step,
        case=case,
        location="decision.phases[2].pair_reviews",
    )
    global_candidate_steps = tuple(sorted(set(pair_winners)))
    if set(frozen_winner_assessments) != set(global_candidate_steps):
        raise AssertionError("v17 frozen pair-winner map does not match pair winners")

    global_phase = _phase(
        phases[3],
        name=_PHASE_NAMES[3],
        fields=_GLOBAL_FIELDS,
    )
    _forbid_owner_atom_after_precommit(global_phase, location="decision.phases[3]")
    global_arbitration, selected_step, selected_assessment = _global_arbitration(
        global_phase,
        frozen_winner_assessments=frozen_winner_assessments,
        location="decision.phases[3]",
    )
    selected_precommit, selected_atom = classified_by_step[selected_step]
    prediction = _prediction_record(
        case,
        {
            "predicted_step": selected_step,
            "predicted_module": selected_atom["owner_module"],
            "predicted_error_type": selected_precommit["predicted_error_type"],
            "evidence_quote": selected_atom["quote"],
            "root_cause": global_arbitration["selected_step_reason"],
            "causal_summary": (
                "Producer-consumer relation: "
                f"{selected_assessment['producer_consumer']} "
                f"Counterfactual: {selected_assessment['counterfactual']}"
            ),
            "rejected_adjacent_owner": selected_precommit[
                "rejected_adjacent_owner"
            ],
        },
    )
    if set(prediction) != AGENT_JUDGE_PREDICTION_FIELDS:
        raise AssertionError("derived v17 prediction fields changed")

    selected_step_atoms = [atom for atom in atoms if atom["step"] == selected_step]
    anchor_ids = [f"{_STEP_PREFIX}{step:04d}" for step in sorted(anchor_steps)]
    winner_ids = [f"{_STEP_PREFIX}{step:04d}" for step in pair_winners]
    global_ids = [f"{_STEP_PREFIX}{step:04d}" for step in global_candidate_steps]
    return {
        "schema_version": _DECISION_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_V17_UNIFIED_VERSION,
        "model": AGENT_JUDGE_LUNA_V17_UNIFIED_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V17_UNIFIED_REASONING_EFFORT,
        "proposal_free": True,
        "historical_predictions_visible": False,
        "same_session_hypothesis_count": 3,
        "classification_precommit_serialized_before_anchors": True,
        "classification_precommit_context_hidden": False,
        "classification_context_isolated": False,
        "single_response_autoregressive_visibility": True,
        "final_classification_derived_from_precommit": True,
        "post_selection_classification_present": False,
        "anchor_evidence_owner_neutral": True,
        "post_precommit_owner_atom_ids_absent": True,
        "contract_anchor_evidence_grounded": True,
        "state_anchor_requires_dual_evidence": True,
        "recurrence_anchor_requires_prior_failed_episode": True,
        "recurrence_anchor_distinct_or_null": True,
        "anchor_steps_deduplicated": True,
        "all_anchor_predecessors_considered": True,
        "boundary_pairs_exact": True,
        "boundary_pair_sides_evidence_grounded": True,
        "pair_winners_deduplicated": True,
        "global_analysis_derived_from_pair_winners": True,
        "global_candidate_cards_source_blind": True,
        "strict_system_anchor_supported": True,
        "evidence_atom_schema_version": _ATOM_SCHEMA_VERSION,
        "evidence_atom_count": len(atoms),
        "evidence_atom_catalog_sha256": _atom_catalog_sha256(atoms),
        "neutral_text_schema_version": _NEUTRAL_TEXT_SCHEMA_VERSION,
        "neutral_text_count": len(texts),
        "neutral_text_catalog_sha256": _neutral_text_catalog_sha256(texts),
        "reference_atom_schema_version": _REFERENCE_SCHEMA_VERSION,
        "reference_atom_count": len(references),
        "reference_atom_catalog_sha256": _reference_catalog_sha256(references),
        "step_card_schema_version": _STEP_SCHEMA_VERSION,
        "step_card_count": len(cards),
        "step_card_catalog_sha256": _step_catalog_sha256(cards),
        "classification_precommit_bank": precommit_bank,
        "classification_precommit_non_null_count": len(classified_by_step),
        "classification_precommit_bank_sha256": _json_sha256(precommit_bank),
        "contract_anchor": contract,
        "state_anchor": state,
        "recurrence_anchor": recurrence,
        "non_null_anchor_count": len(anchor_steps),
        "deduplicated_anchor_step_card_ids": anchor_ids,
        "anchor_set_sha256": _json_sha256(anchor_ids),
        "boundary_pairs": boundary_pairs,
        "boundary_pairs_sha256": _json_sha256(boundary_pairs),
        "pair_winner_step_card_ids": winner_ids,
        "global_candidate_step_card_ids": global_ids,
        "global_candidates_sha256": _json_sha256(global_ids),
        "global_arbitration": global_arbitration,
        "selected_step_card_id": f"{_STEP_PREFIX}{selected_step:04d}",
        "selected_precommit_entry": selected_precommit,
        "selected_owner_atom_id": selected_atom["evidence_atom_id"],
        "classification_context_step": selected_step,
        "classification_context_owner_atom_ids": [
            atom["evidence_atom_id"] for atom in selected_step_atoms
        ],
        "classification_context_sha256": _v16._classification_context_sha256(
            case, selected_step
        ),
        "selected_prediction": prediction,
        "prediction_manifest_file_sha256": _file_sha256(manifest_path),
        "cohort_manifest_file_sha256": _file_sha256(cohort_path),
        "cohort_name": cohort["cohort_name"],
        "cohort_sha256": cohort["cohort_sha256"],
        "dataset_manifest_sha256": cohort["dataset_manifest_sha256"],
        "decision_sha256": _file_sha256(resolved_decision_path),
    }


def _decision_contract() -> str:
    return json.dumps(decision_output_schema(), ensure_ascii=False, indent=2)


def build_agent_judge_luna_v17_unified_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Embed one anonymous JudgeView and v17's gold-free catalogs."""

    del predictions_path
    _, _, _, case, _ = _validate_one_case_identity(
        prediction_manifest_path,
        cohort_manifest_path,
        role="task",
    )
    timeline = _anonymized_timeline(case)
    atoms = _evidence_atoms(case)
    cards = _step_cards(case, atoms)
    texts = _neutral_text_records(atoms)
    references = _reference_atoms(case)
    catalogs = json.dumps(
        {
            "step_catalog": _public_step_catalog(cards),
            "classification_evidence_atom_schema_version": _ATOM_SCHEMA_VERSION,
            **_public_atom_catalog(atoms),
            "owner_neutral_text_catalog": _public_neutral_text_catalog(texts),
            "owner_neutral_reference_catalog": _public_reference_catalog(references),
        },
        ensure_ascii=False,
        indent=2,
    )
    return f"""\
Run frozen protocol {AGENT_JUDGE_LUNA_V17_UNIFIED_VERSION}.

EXECUTION CONTRACT
- model: {AGENT_JUDGE_LUNA_V17_UNIFIED_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_V17_UNIFIED_REASONING_EFFORT}
- exactly one anonymous trajectory is embedded below
- do not call tools, inspect files, use the network, or use external APIs
- no prior prediction, proposal, label, score, case study, or cross-case state exists
- return exactly one JSON object matching the supplied output schema

This is one autoregressive response in one isolated case session.  All prompt
text and already generated JSON remain visible.  The ordered phase array makes
classification a serialized precommitment; it does not hide context and is not
an independent classifier agent.  Never infer from opaque IDs, array order,
source-model name, environment, expected distributions, benchmark memory, or
an imagined gold answer.

PHASE 1 — COMPLETE OWNER/TYPE PRECOMMIT BANK

This must be phases[0].  Emit exactly one entry for every SC card, in ascending
SC order.  Before nominating or comparing any boundary, independently inspect
each Step's local timeline record and same-Step EA cards.  Either precommit one
exact same-Step owner_atom_id, one of that atom's allowed_error_types, and a
short rejected_adjacent_owner explanation, or set all three values to null.
Partial null entries are forbidden.  Later anchors may use only non-null Steps;
every mechanical predecessor in a boundary pair must also be non-null.  Final
module/type/quote will be copied mechanically from the selected Step's bank
entry.  There is no post-selection classification field.

Strict System classification remains evidence-bound.  A System EA exists only
for an independent typed external failure or explicit typed execution
stop/limit.  Ordinary task text, trace length, unresolved final status,
user-side invalid parameters, and nested payload prose do not establish System.

PHASE 2 — THREE COMPLEMENTARY OWNER-NEUTRAL ANCHORS

After Phase 1, do not output or cite any EA ID, module, or error type.  ET IDs
are owner-neutral exact assistant-source fragments; RA IDs are separate exact
task/observation/result references.  An ET nominates only its Step.

A. contract_anchor is mandatory.  Find the earliest literal task constraint,
missing prerequisite, plan/action or tool-target contract breach, decision
conditioned on an unverified hypothesis, or strict observable System boundary.
Use one current ET and optionally one RA that was already available.  An
observable_system_boundary kind is legal only when that ET privately has a
strict System atom.  Prefer the producer of the bad commitment over the later
consumer that merely exposes it.

B. state_anchor is candidate only with two exact sources: a current ET that
privately admits a Memory/Reflection claim, and an earlier-available observation
or tool-result RA that the claim contradicts, materially omits, falsely marks
complete, or causally misreads.  If both exact sources do not exist, emit
no_candidate.  Generic state-fidelity prose without two sources is forbidden.

C. recurrence_anchor is candidate only with an exact prior Action ET, an exact
observation/result RA produced by that prior action, and a current ET for the
first qualified recommitment.  Compare query/tool/arguments/result and
constraint_delta to distinguish epochs.  A new target, changed constraint,
evidence-motivated confirmation, or ordinary pagination is not automatically
the same failed family.  Its Step must differ from both earlier anchor Steps;
otherwise emit no_candidate.  This prevents repeat nominations from becoming
votes.

PHASE 3 — PARENT-GEOMETRY BOUNDARY PAIRS

Deduplicate the non-null anchor Steps.  For every unique anchor X, construct
exactly the ascending member set {{X-1,X}}; X=1 degenerates to {{1}}.  Emit one
pair review for every such set.  Both members have the identical schema and
must bind one exact same-Step ET plus its local timeline context.  Give both a
defect_strength, producer_consumer analysis, and counterfactual.  Select X-1
when it already produces a false state/commitment/action consumed at X; select
X when X-1 is a reasonable probe and X is the first defective recommitment
after contrary feedback.  The winner must be material or decisive.  Do not use
anchor role, nomination count, pair/list order, module/type, or EA provenance.

PHASE 4 — GLOBAL ARBITRATION OVER DEDUPLICATED PAIR WINNERS ONLY

Deduplicate equal pair-winner SC IDs before assessment: repeated appearance is
never an extra vote.  For every unique winner output only its step_card_id and
one neutral comparative_judgment.  The parent mechanically carries forward the
exact ET, defect_strength, producer_consumer, and counterfactual frozen in the
pair review; Phase 4 cannot rewrite them.  If one Step wins multiple overlapping
pairs, its local evidence and three analysis fields must be identical in those
pairs.  Candidate array order, anchor source, number of nominations, and the
fact that a Step won a particular pair are inadmissible.  Select the strongest
literal, earliest-causal, minimal-correction root—not the latest or most verbose
symptom.  Do not emit owner/module/type/EA fields; the parent reads the frozen
Phase-1 bank mechanically.

OWNER TAXONOMY USED ONLY IN PHASE 1
{taxonomy_prompt()}

OUTPUT CONTRACT
{_decision_contract()}

PARENT-BUILT STEP, CLASSIFICATION, NEUTRAL-TEXT, AND REFERENCE CATALOGS
{catalogs}

GOLD-FREE ANONYMOUS JUDGEVIEW
{timeline}
"""


def validate_agent_judge_luna_v17_unified_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    """Validate final predictions against exact v17 owner-bound atoms."""

    audit = _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_leaf_and_residual_owner_source_resolver,
    )
    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    output_path = Path(predictions_path).expanduser().resolve()
    _, cases = load_prediction_manifest(manifest_path)
    raw_predictions = _load_json(output_path, role="predictions")
    if not isinstance(raw_predictions, list) or len(raw_predictions) != len(cases):
        raise AssertionError("shared v17 validation did not freeze prediction count")

    catalog_records: list[dict[str, Any]] = []
    for index, (case, prediction) in enumerate(
        zip(cases, raw_predictions, strict=True), 1
    ):
        if not isinstance(prediction, Mapping):
            raise AssertionError("shared v17 validation did not freeze records")
        atoms = _evidence_atoms(case)
        matches = [
            atom
            for atom in atoms
            if atom["step"] == prediction["predicted_step"]
            and atom["owner_module"] == prediction["predicted_module"]
            and atom["quote"] == prediction["evidence_quote"]
            and prediction["predicted_error_type"] in atom["allowed_error_types"]
        ]
        if len(matches) != 1:
            raise AgentJudgeValidationError(
                "invalid_evidence_atom_binding",
                (
                    f"predictions[{index - 1}] does not exactly match one "
                    "v17 owner-bound evidence atom"
                ),
            )
        selected_atom = matches[0]
        cards = _step_cards(case, atoms)
        texts = _neutral_text_records(atoms)
        references = _reference_atoms(case)
        catalog_records.append(
            {
                "case_index": index,
                "trajectory_id": case.trajectory_id,
                "atom_count": len(atoms),
                "catalog_sha256": _atom_catalog_sha256(atoms),
                "neutral_text_catalog_sha256": _neutral_text_catalog_sha256(texts),
                "reference_atom_catalog_sha256": _reference_catalog_sha256(
                    references
                ),
                "step_catalog_sha256": _step_catalog_sha256(cards),
                "selected_evidence_atom_id": selected_atom["evidence_atom_id"],
                "selected_step_card_id": (
                    f"{_STEP_PREFIX}{selected_atom['step']:04d}"
                ),
            }
        )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_V17_UNIFIED_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_V17_UNIFIED_VERSION,
        "model": AGENT_JUDGE_LUNA_V17_UNIFIED_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V17_UNIFIED_REASONING_EFFORT,
        "proposal_free": True,
        "historical_predictions_visible": False,
        "same_session_hypothesis_count": 3,
        "label_pair_routing_used": False,
        "nested_module_spans_supported": True,
        "classification_precommit_serialized_before_anchors": True,
        "classification_precommit_context_hidden": False,
        "final_classification_derived_from_precommit": True,
        "post_selection_classification_present": False,
        "anchor_evidence_owner_neutral": True,
        "state_anchor_requires_dual_evidence": True,
        "recurrence_anchor_requires_prior_failed_episode": True,
        "all_anchor_predecessors_considered": True,
        "boundary_pairs_exact": True,
        "pair_winners_deduplicated": True,
        "global_analysis_derived_from_pair_winners": True,
        "strict_system_anchor_supported": True,
        "evidence_atom_binding": True,
        "all_predictions_match_exact_evidence_atom": True,
        "evidence_atom_catalogs": catalog_records,
        "evidence_atom_catalog_set_sha256": _json_sha256(catalog_records),
        "model_copies_boundary_quote": False,
        "validation_method": (
            "Gold-free exact JSON, ordered classification precommit, exact "
            "owner-neutral anchor/reference evidence, parent-built X-1/X pairs, "
            "deduplicated pair-winner arbitration, cohort identity, taxonomy, "
            "and final exact owner-atom binding."
        ),
    }


__all__ = [
    "AGENT_JUDGE_LUNA_V17_UNIFIED_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_V17_UNIFIED_MODEL",
    "AGENT_JUDGE_LUNA_V17_UNIFIED_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_V17_UNIFIED_VERSION",
    "DECISION_FILENAME",
    "build_agent_judge_luna_v17_unified_task",
    "build_luna_v17_evidence_atom_catalog",
    "decision_output_schema",
    "runtime_conformance_decision",
    "validate_agent_judge_luna_v17_unified_predictions",
    "validate_luna_v17_unified_decision",
]

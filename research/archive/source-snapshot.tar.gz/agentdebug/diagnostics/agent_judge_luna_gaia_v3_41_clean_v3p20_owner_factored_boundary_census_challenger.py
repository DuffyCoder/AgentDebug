"""Luna GAIA v3.41: clean v3.20 with one owner-factored boundary census."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger as transport
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent


AGENT_JUDGE_LUNA_GAIA_V3_41_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.41-clean-v3.20-"
    "owner-factored-boundary-census-challenger"
)
AGENT_JUDGE_LUNA_GAIA_V3_41_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_41_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_41_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases used by the shared three-stage paper runner.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_41_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_41_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_41_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_41_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = transport.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = transport.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = transport.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = transport.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = transport.CHALLENGERS_FILENAME
ARBITER_FILENAME = transport.ARBITER_FILENAME
ARBITERS_FILENAME = transport.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = transport.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = transport.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = transport.PREDICTION_AUDIT_FILENAME
CHALLENGER_FIELDS = transport.CHALLENGER_FIELDS
ARBITER_FIELDS = transport.ARBITER_FIELDS


_OWNER_PREFIX = re.compile(
    r"^owner_census=([^;]+); "
    r"owner_candidate=(none|[1-9]\d*[pamr][1-9]\d*); "
    r"candidate_step=(none|[1-9]\d*); "
    r"census_direction=(none|earlier|same|later); "
)
_OWNER_ENTRY = re.compile(
    r"^([1-9]\d*)([pamr])([1-9]\d*):([cpnrflx]):([nsma]):(0|[1-9]\d*)$"
)
_MODULE_TO_CODE = {
    "planning": "p",
    "action": "a",
    "memory": "m",
    "reflection": "r",
}
_CODE_TO_MODULE = {value: key for key, value in _MODULE_TO_CODE.items()}
_VERDICT_CODES = {
    "c": "clear",
    "p": "reasonable_probe",
    "n": "normal_failure",
    "r": "recovered_or_mechanical",
    "f": "faithful_propagation",
    "l": "noncritical_local_error",
    "x": "critical_candidate",
}
_BOUNDARY_CODES = {
    "n": "none",
    "s": "state_truth",
    "m": "post_feedback_maturity",
    "a": "alignment",
}
_UNTYPED_VERDICT_CODES = frozenset({"c", "p", "n", "f"})


_OWNER_FACTORED_BOUNDARY_CENSUS_RULES = """\
COMPLETE OWNER-FACTORED BOUNDARY CENSUS — ONE STEP PROPOSAL MAXIMUM

The frozen clean-v3.20 packet-state prediction is the incumbent anchor. Do not
change or rerun its ledger or checkpoint. Inspect every observable Agent-owned
module span in exact chronology, before, at, and after the anchor. Never assign
one verdict to a whole Step. Planning, Action, Memory, and Reflection owners in
the same Step are separate decisions; a tool/site outcome cannot erase a
same-Step Agent commitment. The anchor remains the default under uncertainty.

EXACT OWNER ENUMERATION

Enumerate the observable module spans in their literal order. Owner keys are
`<Step><module-code><occurrence>` where module codes are p=Planning, a=Action,
m=Memory, r=Reflection, and occurrence is 1-based within that Step/module.
Examples: the first Planning owner in Step 2 is `2p1`; a second Planning span is
`2p2`; the first Action owner is `2a1`. Include every observable p/a/m/r span
exactly once and no System row.

For every owner close three compact values:

1. VERDICT CODE: c=clear, p=reasonable_probe, n=normal_failure,
   r=recovered_or_mechanical, f=faithful_propagation,
   l=noncritical_local_error, x=critical_candidate.
2. BOUNDARY CODE: n=none, s=state_truth, m=post_feedback_maturity,
   a=alignment.
3. WITNESS STEP: 0 for none, otherwise the literal maturity Step.

OWNER-LOCAL BOUNDARIES

- state_truth (`s`) applies only to Memory or Reflection that drops or distorts
  a concrete observed fact, retains an unsupported task-material entity/value/
  relation, or contradicts observable progress and feeds the current or next
  decision. Its witness is its own Step.
- post_feedback_maturity (`m`) applies to an Agent owner that, after a strictly
  earlier literal failure or zero-contribution result, recommits to the same
  unresolved immediate predicate and evidence modality/extraction family
  without a genuinely new evidence dimension. The witness is strictly earlier.
  Exact query, URL, or source identity is not required.
- alignment (`a`) applies to Planning or Action that owns a direct plan/Action
  target-tool mismatch or literal explicit user/source/constraint contradiction
  whose exact local repair can change the path. Its witness is its own Step.

OWNER-LOCAL VETOES

A first or materially different acquisition plan/action is a reasonable probe
when success can contribute a necessary identifier, page, text, source, route,
or lead. A well-formed Action whose tool/site returns an error is normal failure;
that verdict does not decide any Planning, Memory, or Reflection owner in the
same Step. A parameter or local defect is recovered_or_mechanical when a later
valid same-subgoal owner repairs it without consuming false state. A later
owner is faithful propagation only if it contains no independent local
commitment and repairing the earlier owner can avert it. Productive specialized
resource changes are not same-family repetition. Returned transport success is
not capability proof, but entity/domain expectations and final-answer hindsight
are not capability evidence either.

OWNER-FACTORED FREEZE

After every owner row is closed, mark at most one owner `x`. It must own literal
task-material error, a still-unresolved condition, a valid witness, and a local
repair that can change the path after owner-local vetoes. Prefer the earliest
mature owner that survives repair comparison, not the earliest surface defect
or latest symptom. If no owner closes or ownership is ambiguous, freeze none.

Begin search_summary exactly with this compact certificate:

`owner_census=1p1:p:n:0,1a1:n:n:0,2p1:x:m:1,...; owner_candidate=<none|owner-key>; candidate_step=<none|Step>; census_direction=<none|earlier|same|later>; `

The owner list must exactly match the observable p/a/m/r spans and their order.
Exactly one row uses x when owner_candidate is present; its Step must equal
candidate_step. State/alignment witnesses equal the owner Step;
post_feedback_maturity witnesses are strictly earlier. Direction is relative
to the frozen anchor Step. After the required certificate prefix, use at most
300 additional characters; put detailed literal analysis in the other required
timeline and counterfactual fields, not in search_summary.

ANCHOR COMPARISON AND OUTPUT

- No candidate or candidate Step equal to anchor: emit no_challenge.
- Earlier candidate: challenge only when the anchor is downstream and the
  earlier owner survives its own repair comparison.
- Later candidate: challenge only when the anchor is a reasonable probe or
  noncritical predecessor and the later owner survives anchor-only repair.
- If a distinct candidate loses, emit no_challenge but retain its owner tuple.

A proposal must exactly use the one frozen candidate Step and its owner module;
literal evidence must come from that owner span. Use separate anchor-only and
proposal-only interventions. direct_timeline_comparison must cover anchor,
candidate, and intervening plausible owners. The independent arbiter may copy
only the anchor or proposal, defaults to anchor under uncertainty, and must
reject unsupported owner, witness, veto, or repair claims. Never invent a pool
or third prediction.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_41_VERSION,
        )
        .replace(
            transport.AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_41_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_41_clean_v3p20_owner_factored_boundary_census_challenger",
        )
        .replace(
            "agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger",
            "agent_judge_luna_gaia_v3_41_clean_v3p20_owner_factored_boundary_census_challenger",
        )
    )


def _rewrite_mechanism(task: str) -> str:
    if task.count(transport._BOUNDED_BIDIRECTIONAL_RULES) != 1:
        raise RuntimeError("bounded challenger-rule marker changed unexpectedly")
    return task.replace(
        transport._BOUNDED_BIDIRECTIONAL_RULES,
        _OWNER_FACTORED_BOUNDARY_CENSUS_RULES,
        1,
    ).replace(
        '"which direction was searched and why one proposal exists or none qualifies"',
        '"owner_census=1p1:p:n:0,1a1:n:n:0,...; owner_candidate=none; '
        'candidate_step=none; census_direction=none; complete owner census"',
    )


def build_anchor_task(*paths: str | Path) -> str:
    """Use exactly the v3.20 anchor semantics, with only identity retagged."""

    return _rewrite_identity(parent.build_anchor_task(*paths))


def build_challenger_task(*paths: str | Path) -> str:
    return _rewrite_identity(_rewrite_mechanism(transport.build_challenger_task(*paths)))


def _expected_owner_keys(case: Any) -> list[str]:
    keys: list[str] = []
    for step in case.judge_view.steps:
        occurrences: Counter[str] = Counter()
        for span in step.module_spans:
            code = _MODULE_TO_CODE.get(span.module)
            if code is None:
                continue
            occurrences[span.module] += 1
            keys.append(f"{step.step}{code}{occurrences[span.module]}")
    return keys


def _validate_owner_census_records(
    path: str | Path, cases: Sequence[Any]
) -> dict[str, Any]:
    challenger_path, raw = shared._load_artifact(path, role="owner-factored census")
    records = raw if isinstance(raw, list) else [raw]
    if len(records) != len(cases) or any(not isinstance(item, dict) for item in records):
        shared._fail("invalid_owner_census_record_count", "case/record count differs")

    verdict_counts: Counter[str] = Counter()
    boundary_counts: Counter[str] = Counter()
    owner_module_counts: Counter[str] = Counter()
    direction_counts: Counter[str] = Counter()
    candidate_count = 0
    challenge_count = 0
    owner_row_count = 0
    for index, (record, case) in enumerate(zip(records, cases, strict=True)):
        location = f"owner_census[{index}]"
        match = _OWNER_PREFIX.match(str(record.get("search_summary") or ""))
        if match is None:
            shared._fail("missing_complete_owner_census_prefix", location)
        census_text, candidate_owner, candidate_step_text, direction = match.groups()
        entries: list[tuple[str, int, str, int, str, str, int | None]] = []
        for entry_text in census_text.split(","):
            entry_match = _OWNER_ENTRY.match(entry_text)
            if entry_match is None:
                shared._fail("invalid_owner_census_entry", f"{location}:{entry_text}")
            step_text, module_code, occurrence_text, verdict, boundary, witness_text = (
                entry_match.groups()
            )
            step = int(step_text)
            occurrence = int(occurrence_text)
            owner_key = f"{step}{module_code}{occurrence}"
            witness = None if witness_text == "0" else int(witness_text)
            module = _CODE_TO_MODULE[module_code]
            if boundary == "n" and witness is not None:
                shared._fail("untyped_owner_row_has_witness", f"{location}:{owner_key}")
            if boundary != "n" and witness is None:
                shared._fail("typed_owner_row_lacks_witness", f"{location}:{owner_key}")
            if verdict in _UNTYPED_VERDICT_CODES and boundary != "n":
                shared._fail("vetoed_owner_row_is_typed", f"{location}:{owner_key}")
            if verdict == "x" and boundary == "n":
                shared._fail("critical_owner_row_is_untyped", f"{location}:{owner_key}")
            if boundary == "s" and module not in {"memory", "reflection"}:
                shared._fail("state_owner_has_invalid_module", f"{location}:{owner_key}")
            if boundary == "a" and module not in {"planning", "action"}:
                shared._fail("alignment_owner_has_invalid_module", f"{location}:{owner_key}")
            if boundary in {"s", "a"} and witness != step:
                shared._fail("same_step_owner_witness_mismatch", f"{location}:{owner_key}")
            if boundary == "m" and (witness is None or witness >= step):
                shared._fail("owner_maturity_witness_not_prior", f"{location}:{owner_key}")
            entries.append(
                (owner_key, step, module, occurrence, verdict, boundary, witness)
            )
            verdict_counts[_VERDICT_CODES[verdict]] += 1
            boundary_counts[_BOUNDARY_CODES[boundary]] += 1
            owner_module_counts[module] += 1

        expected_keys = _expected_owner_keys(case)
        if [owner_key for owner_key, *_ in entries] != expected_keys:
            shared._fail("owner_census_exact_list_mismatch", location)
        owner_row_count += len(entries)

        critical_owners = [
            owner_key for owner_key, _, _, _, verdict, _, _ in entries if verdict == "x"
        ]
        candidate_step = (
            None if candidate_step_text == "none" else int(candidate_step_text)
        )
        if candidate_owner == "none":
            if critical_owners or candidate_step is not None or direction != "none":
                shared._fail("invalid_empty_owner_candidate", location)
        else:
            if critical_owners != [candidate_owner]:
                shared._fail("owner_candidate_binding_mismatch", location)
            candidate_entry = next(
                (entry for entry in entries if entry[0] == candidate_owner), None
            )
            if candidate_entry is None or candidate_step != candidate_entry[1]:
                shared._fail("owner_candidate_step_mismatch", location)
            anchor_step = record.get("anchor_step")
            expected_direction = (
                "earlier"
                if candidate_step < anchor_step
                else "later"
                if candidate_step > anchor_step
                else "same"
            )
            if direction != expected_direction:
                shared._fail("owner_candidate_direction_mismatch", location)
            candidate_count += 1

        if record.get("challenge_status") == "challenge":
            proposal = record.get("proposed_prediction")
            candidate_entry = next(
                (entry for entry in entries if entry[0] == candidate_owner), None
            )
            if (
                candidate_entry is None
                or direction not in {"earlier", "later"}
                or not isinstance(proposal, dict)
                or proposal.get("predicted_step") != candidate_step
                or proposal.get("predicted_module") != candidate_entry[2]
            ):
                shared._fail("proposal_differs_from_owner_candidate", location)
            challenge_count += 1
        direction_counts[direction] += 1

    return {
        "required": True,
        "valid": True,
        "path": str(challenger_path),
        "record_count": len(records),
        "owner_row_count": owner_row_count,
        "exact_complete_owner_enumeration": True,
        "owner_local_mutual_exclusivity": True,
        "tool_outcome_cannot_mask_agent_owner": True,
        "maturity_witness_binding": True,
        "one_candidate_maximum": True,
        "candidate_count": candidate_count,
        "challenge_count": challenge_count,
        "owner_module_counts": dict(sorted(owner_module_counts.items())),
        "verdict_counts": dict(sorted(verdict_counts.items())),
        "boundary_counts": dict(sorted(boundary_counts.items())),
        "direction_counts": dict(sorted(direction_counts.items())),
    }


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_41_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_41_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_41_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one owner-factored boundary census challenger/adjudication contract",
    }


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths), policy="unchanged_v3_20_anchor")


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    audit = _retag(
        transport.validate_challenger(*paths),
        policy="owner_factored_boundary_census_bidirectional_challenger",
    )
    _, _, case = shared._single_case_paths(paths[0], paths[1])
    audit["schema_version"] = "agentdebug.owner-factored-census-challenger-audit.v1"
    audit["owner_factored_boundary_census"] = _validate_owner_census_records(
        paths[5], [case]
    )
    return audit


def build_arbiter_task(*paths: str | Path) -> str:
    validate_challenger(*paths[:6])
    return _rewrite_identity(_rewrite_mechanism(transport.build_arbiter_task(*paths)))


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    audit = _retag(
        transport.validate_arbiter(*paths),
        policy="default_keep_owner_factored_census_exact_copy_arbiter",
    )
    _, _, case = shared._single_case_paths(paths[0], paths[1])
    audit["schema_version"] = "agentdebug.owner-factored-census-arbiter-audit.v1"
    audit["owner_factored_boundary_census"] = _validate_owner_census_records(
        paths[5], [case]
    )
    return audit


def build_agent_judge_luna_gaia_v3_41_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def validate_agent_judge_luna_gaia_v3_41_predictions(
    *paths: str | Path,
) -> dict[str, Any]:
    audit = _retag(
        transport.validate_agent_judge_luna_gaia_v3_16_predictions(*paths),
        policy=(
            "clean_v3_20_anchor_complete_owner_factored_boundary_census_one_"
            "bidirectional_proposal_default_keep_exact_copy_arbiter"
        ),
    )
    _, _, cases = shared._load_cases(paths[0], paths[1])
    predictions = Path(paths[2]).expanduser().resolve()
    audit["schema_version"] = AGENT_JUDGE_LUNA_GAIA_V3_41_AUDIT_SCHEMA_VERSION
    audit["anchor_semantics_unchanged_from_v3_20"] = True
    audit["packet_state_closure"] = parent._validate_packet_state_ledgers(
        predictions.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME
    )
    audit["owner_factored_boundary_census"] = _validate_owner_census_records(
        predictions.parent / CHALLENGERS_FILENAME,
        cases,
    )
    return audit


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_41_audit(
    *paths: str | Path,
) -> dict[str, Any]:
    return _write(validate_agent_judge_luna_gaia_v3_41_predictions(*paths[:-1]), paths[-1])


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_41_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_41_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_41_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_41_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    args = parser.parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

"""Luna GAIA v3.21: typed Memory/Reflection claim entailment."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from . import agent_judge_luna_gaia_v3_14_earliest_causal_challenger as semantic_base
from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from .agent_judge_luna_gaia_v3_4 import (
    STEP_CANDIDATE_LEDGER_FILENAME,
    validate_agent_judge_luna_gaia_v3_4_predictions,
)


AGENT_JUDGE_LUNA_GAIA_V3_21_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.21-typed-state-claim-entailment"
)
AGENT_JUDGE_LUNA_GAIA_V3_21_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_21_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_21_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases used by the shared three-stage runner.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_21_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_21_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_21_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_21_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = parent.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = parent.CHALLENGERS_FILENAME
ARBITER_FILENAME = parent.ARBITER_FILENAME
ARBITERS_FILENAME = parent.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = parent.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = parent.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
CHALLENGER_FIELDS = parent.CHALLENGER_FIELDS
ARBITER_FIELDS = parent.ARBITER_FIELDS


_STATE_PREFIX = re.compile(
    r"^state_claim_kind=(none|necessary_fact|entity_relation|outcome_claim|query_hypothesis); "
    r"state_relation=(not_applicable|entailed|omitted|unsupported|contradicted|compatible); "
)

_VALID_RELATIONS = {
    "none": {"not_applicable"},
    "necessary_fact": {"entailed", "omitted"},
    "entity_relation": {"entailed", "unsupported"},
    "outcome_claim": {"entailed", "contradicted"},
    "query_hypothesis": {"compatible", "contradicted"},
}
_NONCLEAR_RELATIONS = {"omitted", "unsupported", "contradicted"}
_CLEAR_RELATIONS = {"not_applicable", "entailed", "compatible"}

_TYPED_STATE_GATE = """\
TYPED PACKET-STATE CLAIM ENTAILMENT — BINDING BEFORE ALL LANE DECISIONS

For every inspected Step, compare the packet's Memory/Reflection literally with
the adjacent observation and visible history before applying probe, capability,
System, repetition, or terminal rules. Begin decision_basis exactly:

`state_claim_kind=<none|necessary_fact|entity_relation|outcome_claim|query_hypothesis>; state_relation=<not_applicable|entailed|omitted|unsupported|contradicted|compatible>; `

Classify the single task-material state claim with the greatest ability to
change the current or next decision. Do not classify by tone or by whether a
statement is merely unproven; identify its semantic role first:

- `none` + `not_applicable`: no Memory/Reflection claim in this packet is
  task-material. Lane A MUST be clear.
- `necessary_fact` + `entailed|omitted`: the adjacent result contains a
  concrete title, value, constraint, source fact, or provenance fact necessary
  for the unresolved subgoal or next decision. Use `omitted` only when the
  retained state loses or materially distorts that fact, not for harmless
  compression or a fact still available to the next decision. Omitted MUST make
  Lane A candidate; entailed MUST make it clear.
- `entity_relation` + `entailed|unsupported`: Memory/Reflection asserts a
  concrete answer-state entity/value/credential/relation that is consumed by
  the later plan. Use `unsupported` when visible evidence does not support that
  asserted relation. Unsupported MUST make Lane A candidate; entailed MUST make
  it clear.
- `outcome_claim` + `entailed|contradicted`: Memory/Reflection claims success,
  failure, progress, or a constraint about the adjacent result. Use
  `contradicted` only when the literal result contradicts it. Contradicted MUST
  make Lane A candidate; entailed MUST make it clear.
- `query_hypothesis` + `compatible|contradicted`: an explicitly provisional
  explanation of why retrieval was irrelevant or failed, offered to choose a
  better query rather than as answer evidence. A hypothesis compatible with the
  result is clear even if unproved; never relabel it as an unsupported
  entity_relation. Only literal contradiction makes Lane A candidate.

For `omitted`, `unsupported`, or `contradicted`, also require that the affected
state feeds the current/next plan and that repairing it can change the later
path. Otherwise use the corresponding clear relation. After this typed pair,
all existing lanes and vetoes run unchanged.

"""


def _rewrite_parent_task(task: str) -> str:
    return (
        task.replace(parent._PACKET_STATE_GATE, _TYPED_STATE_GATE)
        .replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_21_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_21_typed_state_claim_entailment",
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py",
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_21_typed_state_claim_entailment.py",
        )
        .replace(
            "state_scope=memory_reflection; state_fidelity=faithful; ",
            "state_claim_kind=necessary_fact; state_relation=entailed; ",
        )
        .replace(
            "state_scope=memory_reflection; state_fidelity=unsupported_fact; ",
            "state_claim_kind=entity_relation; state_relation=unsupported; ",
        )
    )


def _rewrite_anchor_validator(task: str) -> str:
    task = task.replace(
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py",
        "agentdebug/diagnostics/agent_judge_luna_gaia_v3_21_typed_state_claim_entailment.py",
    )
    return task.replace(
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_20_packet_state_closure "
        "import validate_and_write_anchor_audit as run",
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_21_typed_state_claim_entailment "
        "import validate_and_write_anchor_audit as run",
    )


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_anchor_validator(_rewrite_parent_task(parent.build_anchor_task(*paths)))


def build_challenger_task(*paths: str | Path) -> str:
    return _rewrite_parent_task(parent.build_challenger_task(*paths))


def build_arbiter_task(*paths: str | Path) -> str:
    return _rewrite_parent_task(parent.build_arbiter_task(*paths))


def build_agent_judge_luna_gaia_v3_21_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / STEP_CANDIDATE_LEDGER_FILENAME,
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def _validate_typed_state_ledgers(path: str | Path) -> dict[str, Any]:
    ledger_path, raw = shared._load_artifact(path, role="typed-state ledger")
    ledgers = raw if isinstance(raw, list) else [raw]
    if not ledgers or any(not isinstance(item, dict) for item in ledgers):
        shared._fail("invalid_typed_state_ledger", "ledger records unavailable")

    kind_counts: Counter[str] = Counter()
    relation_counts: Counter[str] = Counter()
    pair_counts: Counter[str] = Counter()
    row_count = 0
    nonclear_count = 0
    for ledger_index, ledger in enumerate(ledgers):
        rows = ledger.get("rows")
        if not isinstance(rows, list) or not rows:
            shared._fail(
                "invalid_typed_state_rows",
                f"ledger[{ledger_index}] rows unavailable",
            )
        for row_index, row in enumerate(rows):
            basis = row.get("decision_basis") if isinstance(row, dict) else None
            match = _STATE_PREFIX.match(basis or "")
            location = f"ledger[{ledger_index}].rows[{row_index}]"
            if match is None:
                shared._fail("missing_typed_state_prefix", location)
            kind, relation = match.groups()
            if relation not in _VALID_RELATIONS[kind]:
                shared._fail("invalid_typed_state_pairing", location)
            if relation in _NONCLEAR_RELATIONS:
                if row.get("lane_a") != "candidate":
                    shared._fail("nonclear_state_lacks_lane_a_candidate", location)
                nonclear_count += 1
            elif relation in _CLEAR_RELATIONS and row.get("lane_a") != "clear":
                shared._fail("clear_state_lacks_lane_a_clear", location)
            kind_counts[kind] += 1
            relation_counts[relation] += 1
            pair_counts[f"{kind}:{relation}"] += 1
            row_count += 1
    return {
        "required": True,
        "valid": True,
        "path": str(ledger_path),
        "ledger_count": len(ledgers),
        "row_count": row_count,
        "claim_kind_counts": dict(sorted(kind_counts.items())),
        "relation_counts": dict(sorted(relation_counts.items())),
        "claim_relation_counts": dict(sorted(pair_counts.items())),
        "nonclear_state_admission_count": nonclear_count,
    }


def validate_anchor_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_4_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    ledger = Path(predictions_path).expanduser().resolve().parent / STEP_CANDIDATE_LEDGER_FILENAME
    state = _validate_typed_state_ledgers(ledger)
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_21_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_21_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_21_REASONING_EFFORT,
        "selection_policy": "v3_4_anchor_with_typed_state_claim_entailment",
        "typed_state_claim_entailment": state,
    }


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    audit = semantic_base.validate_challenger(*paths)
    state = _validate_typed_state_ledgers(paths[3])
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_21_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_21_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_21_REASONING_EFFORT,
        "typed_state_claim_entailment": state,
    }


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    audit = semantic_base.validate_arbiter(*paths)
    state = _validate_typed_state_ledgers(paths[3])
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_21_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_21_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_21_REASONING_EFFORT,
        "typed_state_claim_entailment": state,
    }


def validate_agent_judge_luna_gaia_v3_21_predictions(*paths: str | Path) -> dict[str, Any]:
    audit = semantic_base.validate_agent_judge_luna_gaia_v3_14_predictions(*paths)
    predictions = Path(paths[2]).expanduser().resolve()
    state = _validate_typed_state_ledgers(
        predictions.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_21_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_21_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_21_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_21_REASONING_EFFORT,
        "selection_policy": (
            "typed_state_claim_entailment_v3_4_anchor_one_earliest_causal_later_"
            "challenger_default_keep_exact_copy_arbiter"
        ),
        "typed_state_claim_entailment": state,
    }


def _write_audit(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return semantic_base._write_audit(audit, path)


def validate_and_write_anchor_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        validate_anchor_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_21_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        validate_agent_judge_luna_gaia_v3_21_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


# Compatibility names used by the shared paper-50 runner.
build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_21_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_21_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_21_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_21_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "AGENT_JUDGE_LUNA_GAIA_V3_21_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_GAIA_V3_21_MODEL",
    "AGENT_JUDGE_LUNA_GAIA_V3_21_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_GAIA_V3_21_VERSION",
    "ANCHOR_CHECKPOINT_AGGREGATE_FILENAME",
    "ANCHOR_LEDGER_AGGREGATE_FILENAME",
    "ANCHOR_PREDICTIONS_FILENAME",
    "ARBITER_FILENAME",
    "ARBITERS_FILENAME",
    "CHALLENGER_FILENAME",
    "CHALLENGERS_FILENAME",
    "build_agent_judge_luna_gaia_v3_21_task",
    "build_anchor_task",
    "build_arbiter_task",
    "build_challenger_task",
    "validate_agent_judge_luna_gaia_v3_21_predictions",
    "validate_anchor_predictions",
    "validate_and_write_agent_judge_luna_gaia_v3_21_audit",
    "validate_and_write_anchor_audit",
    "validate_and_write_arbiter_audit",
    "validate_and_write_challenger_audit",
    "validate_arbiter",
    "validate_challenger",
]

"""Proposal-free, one-session dual-hypothesis Luna adjudication.

This protocol deliberately does not accept a prediction or proposal from any
earlier run.  One fresh session receives one complete gold-free JudgeView,
constructs both hypotheses under the same frozen prompt, and selects between
them.  Identity fields are added by the parent after the semantic decision so
the model cannot use trajectory identifiers as diagnostic evidence.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Mapping

from agentdebug.benchmark.prediction_manifest import load_prediction_manifest

from .agent_judge import (
    AGENT_JUDGE_PREDICTION_FIELDS,
    AgentJudgeValidationError,
    _cohort_document,
    _file_sha256,
    _load_json,
    _string_leaves,
    _validate_agent_judge_predictions_with_owner_sources,
)
from .agent_judge_v2_4 import AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
from .taxonomy import AgentModule, ErrorType, is_valid_classification, taxonomy_prompt


AGENT_JUDGE_LUNA_V13_UNIFIED_VERSION = (
    "agentdebug.codex-agent-judge.luna-v13-unified-v1"
)
AGENT_JUDGE_LUNA_V13_UNIFIED_MODEL = "gpt-5.6-luna"
AGENT_JUDGE_LUNA_V13_UNIFIED_REASONING_EFFORT = "medium"
AGENT_JUDGE_LUNA_V13_UNIFIED_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_V2_4_AUDIT_SCHEMA_VERSION
)

DECISION_FILENAME = "decision.json"

_LOCATOR_FIELDS = frozenset(
    {
        "step",
        "defect_basis",
        "boundary_quote",
        "boundary_reason",
        "smallest_correction",
        "downstream_consequence",
    }
)
_CLASSIFICATION_FIELDS = frozenset(
    {
        "predicted_module",
        "predicted_error_type",
        "rejected_adjacent_owner",
    }
)
_ARBITRATION_FIELDS = frozenset(
    {
        "selected_lane",
        "selection_basis",
        "selected_candidate_reason",
        "rejected_candidate_reason",
    }
)
_DECISION_FIELDS = frozenset(
    {"chronological_locator", "local_locator", "arbitration", "classification"}
)

_DEFECT_BASES = frozenset(
    {
        "literal_state_contradiction",
        "literal_task_constraint",
        "plan_action_contract",
        "mechanical_interface_defect",
        "mature_repetition",
        "observable_system_boundary",
        "causal_inference",
    }
)
_SELECTION_BASES = frozenset(
    {
        "direct_root",
        "mature_repetition",
        "observable_system_boundary",
        "causal_predecessor",
        "stronger_material_root",
    }
)
_LANES = frozenset({"chronological", "local"})

_RECOGNIZED_TAG_RE = re.compile(
    r"(?:<|\[)\s*/?\s*"
    r"(?:memory|reflection|plan|action|memory_recall|tool_call|answer|think)\b",
    flags=re.IGNORECASE,
)
_FOREIGN_TO_PLANNING_TAG_RE = re.compile(
    r"(?:<|\[)\s*/?\s*"
    r"(?:memory|reflection|action|memory_recall|tool_call|answer)\b",
    flags=re.IGNORECASE,
)
_ACTION_TAG_RE = re.compile(
    r"(?:<|\[)\s*/?\s*(?:action|tool_call|answer)\b",
    flags=re.IGNORECASE,
)
_ACTION_OPEN_TAG_RE = re.compile(
    r"(?:<|\[)\s*(?:action|tool_call|answer)\b",
    flags=re.IGNORECASE,
)
_ACTION_CLOSE_TAG_RE = re.compile(
    r"(?:<|\[)\s*/\s*(?:action|tool_call|answer)\b[^>\]]*(?:>|\])",
    flags=re.IGNORECASE,
)
_PSEUDO_TOOL_RESULT_RE = re.compile(
    r"^\s*Tool\s+'[^']+'\s+executed\.\s*Result:\s*(?P<result>[\s\S]*?)\s*$",
    flags=re.IGNORECASE,
)
_EXTERNAL_FAILURE_RE = re.compile(
    r"(?:\berror\b|\bexception\b|\btimeout\b|timed\s+out|rate[ -]?limit|"
    r"model[_ -]?not[_ -]?found|invalid\s+model|connection\s+(?:failed|reset)|"
    r"service\s+unavailable|internal\s+server|\bcrash(?:ed)?\b|"
    r"failed\s+to\s+(?:execute|run|load|connect))",
    flags=re.IGNORECASE,
)
_USER_CALL_ERROR_RE = re.compile(
    r"(?:missing|required|invalid|malformed|unknown)\s+"
    r"(?:argument|parameter|field|tool)|validation\s+error|"
    r"unsupported\s+operand\s+type",
    flags=re.IGNORECASE,
)
_LLM_LIMIT_RE = re.compile(
    r"(?:token|context|length|model|llm).{0,32}(?:limit|timeout|refusal|truncat)|"
    r"(?:timeout|refusal|truncat).{0,32}(?:token|context|model|llm)",
    flags=re.IGNORECASE,
)
_STEP_LIMIT_RE = re.compile(
    r"(?:step|turn|interaction).{0,32}(?:limit|budget|maximum|exhaust)|"
    r"(?:limit|budget|maximum|exhaust).{0,32}(?:step|turn|interaction)",
    flags=re.IGNORECASE,
)


def _observation_text(observation: Any) -> str:
    projection = observation.benchmark_input
    if projection is not None:
        return observation.text[
            projection.observation_start_char : projection.observation_end_char
        ].strip()
    return observation.incremental_text.strip()


def _pseudo_tool_error_sources(step: Any) -> tuple[str, ...]:
    """Extract only explicit result-level errors from benchmark wrappers.

    AgentErrorBench represents many GAIA calls as cumulative user messages
    rather than structured ``JudgeToolResult`` objects.  Parsing the projected
    current observation and then the fixed ``Tool ... Result:`` envelope keeps
    ordinary search/page text out of System ownership even when that text
    happens to contain words such as "error".
    """

    sources: list[str] = []
    for feedback in step.adjacent_feedback:
        match = _PSEUDO_TOOL_RESULT_RE.fullmatch(_observation_text(feedback))
        if match is None:
            continue
        result_text = match.group("result").strip()
        if not result_text:
            continue
        atoms: list[str] = []
        try:
            parsed = json.loads(result_text)
        except json.JSONDecodeError:
            parsed = None
        if isinstance(parsed, Mapping):
            if "error" in parsed:
                atoms.extend(_string_leaves(parsed["error"]))
            extracted_text = parsed.get("extracted_text")
            if (
                isinstance(extracted_text, str)
                and extracted_text.lstrip().casefold().startswith(
                    "error fetching url"
                )
            ):
                atoms.append(extracted_text)
        elif (
            re.match(
                r"^(?:error\s+executing\s+tool|exception\b|timeout\b|"
                r"timed\s+out\b|rate[ -]?limit\b|invalid\s+model\b|"
                r"model[_ -]?not[_ -]?found\b|connection\s+(?:failed|reset)\b|"
                r"service\s+unavailable\b|internal\s+server\s+error\b)",
                result_text,
                flags=re.IGNORECASE,
            )
            is not None
        ):
            atoms.append(result_text)
        sources.extend(
            atom
            for atom in atoms
            if atom.strip()
            and _EXTERNAL_FAILURE_RE.search(atom)
            and _USER_CALL_ERROR_RE.search(atom) is None
        )
    return tuple(dict.fromkeys(sources))


def decision_output_schema() -> dict[str, Any]:
    """Return the exact JSON schema supplied to ``codex exec``."""

    locator = {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_LOCATOR_FIELDS),
        "properties": {
            "step": {"type": "integer", "minimum": 1},
            "defect_basis": {
                "type": "string",
                "enum": sorted(_DEFECT_BASES),
            },
            "boundary_quote": {"type": "string", "minLength": 1},
            "boundary_reason": {"type": "string", "minLength": 1},
            "smallest_correction": {"type": "string", "minLength": 1},
            "downstream_consequence": {"type": "string", "minLength": 1},
        },
    }
    classification = {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_CLASSIFICATION_FIELDS),
        "properties": {
            "predicted_module": {
                "type": "string",
                "enum": [item.value for item in AgentModule],
            },
            "predicted_error_type": {
                "type": "string",
                "enum": [item.value for item in ErrorType],
            },
            "rejected_adjacent_owner": {"type": "string", "minLength": 1},
        },
    }
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_DECISION_FIELDS),
        "properties": {
            "chronological_locator": locator,
            "local_locator": locator,
            "arbitration": {
                "type": "object",
                "additionalProperties": False,
                "required": sorted(_ARBITRATION_FIELDS),
                "properties": {
                    "selected_lane": {
                        "type": "string",
                        "enum": sorted(_LANES),
                    },
                    "selection_basis": {
                        "type": "string",
                        "enum": sorted(_SELECTION_BASES),
                    },
                    "selected_candidate_reason": {
                        "type": "string",
                        "minLength": 1,
                    },
                    "rejected_candidate_reason": {
                        "type": "string",
                        "minLength": 1,
                    },
                },
            },
            "classification": classification,
        },
    }


def _required_text(value: Any, *, location: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise AgentJudgeValidationError(
            "invalid_decision_text", f"{location} must be non-empty text"
        )
    return value


_IDENTITY_FIELD_NAMES = frozenset(
    {
        "path",
        "trace_id",
        "task_id",
        "source_id",
        "source_event_id",
    }
)


def _prompt_identity_values(case: Any) -> tuple[str, ...]:
    """Return stable identity strings that must not reach the model prompt."""

    values: set[str] = {
        case.trajectory_id,
        case.trajectory_sha256,
        case.trajectory_sha256[:16],
    }

    def add_strings(value: Any) -> None:
        if isinstance(value, str) and len(value) >= 8:
            values.add(value)
            if re.fullmatch(r"[0-9a-fA-F]{64}", value):
                values.add(value[:16])
        elif isinstance(value, Mapping):
            for nested in value.values():
                add_strings(nested)
        elif isinstance(value, (list, tuple)):
            for nested in value:
                add_strings(nested)

    def walk(value: Any) -> None:
        if isinstance(value, Mapping):
            for raw_key, nested in value.items():
                key = str(raw_key)
                if (
                    key in _IDENTITY_FIELD_NAMES
                    or key.endswith("_id")
                    or key.endswith("_ids")
                    or key.endswith("_sha256")
                ):
                    add_strings(nested)
                walk(nested)
        elif isinstance(value, (list, tuple)):
            for nested in value:
                walk(nested)

    walk(case.judge_view.to_dict())
    return tuple(sorted(value for value in values if value))


def _anonymized_timeline(case: Any) -> str:
    timeline = case.judge_view.render_timeline(compact=True)
    special = {
        case.trajectory_id: "ANONYMOUS-TRACE",
        case.trajectory_sha256: "ANONYMOUS-CONTENT-HASH",
        case.trajectory_sha256[:16]: "ANONYMOUS-CONTENT-HASH",
    }
    remaining = sorted(
        (value for value in _prompt_identity_values(case) if value not in special),
        key=lambda value: (-len(value), value),
    )
    replacements = {
        **special,
        **{
            value: f"ANONYMOUS-ID-{index:04d}"
            for index, value in enumerate(remaining, 1)
        },
    }
    for original in sorted(replacements, key=lambda value: (-len(value), value)):
        timeline = timeline.replace(original, replacements[original])

    # Source-model names are identity metadata, not task evidence.  They may
    # also occur case-insensitively in an injected runner path.
    source_model = case.trajectory_id.split("_", 1)[0]
    if len(source_model) >= 4:
        timeline = re.sub(
            re.escape(source_model),
            "ANONYMOUS-SOURCE-MODEL",
            timeline,
            flags=re.IGNORECASE,
        )
    timeline = re.sub(
        r"(?m)^(?P<indent>[ \t]*)/(?:root|home|tmp|workspace)/[^\r\n]+$",
        r"\g<indent>ANONYMOUS-SOURCE-PATH",
        timeline,
    )
    return timeline


def _locator_sources(case: Any, step: int) -> tuple[str, ...]:
    judge_step = case.judge_view.steps[step - 1]
    sources = [judge_step.assistant_raw_output]
    for call in judge_step.tool_calls:
        sources.append(call.name)
        sources.extend(_string_leaves(call.arguments))
        sources.extend(_string_leaves(call.partial_arguments))
    return tuple(dict.fromkeys(source for source in sources if source.strip()))


def _system_owner_sources(
    view: Any,
    predicted_step: int,
    error_type: ErrorType,
) -> tuple[str, ...]:
    """Return observable input, execution, and terminal System evidence."""

    step = view.steps[predicted_step - 1]
    sources: list[str] = []
    if (
        error_type == ErrorType.ENVIRONMENT_ERROR
        and predicted_step == 1
        and view.task is not None
    ):
        sources.append(view.task.display_text)
    if error_type in {
        ErrorType.TOOL_EXECUTION_ERROR,
        ErrorType.ENVIRONMENT_ERROR,
    }:
        sources.extend(_pseudo_tool_error_sources(step))
        for call in step.tool_calls:
            for result in call.results:
                detail_sources = (result.output, *_string_leaves(result.details))
                explicit_error = result.is_error is True or result.status.casefold() in {
                    "error",
                    "failed",
                    "failure",
                }
                sources.extend(
                    source
                    for source in detail_sources
                    if (
                        explicit_error or _EXTERNAL_FAILURE_RE.search(source)
                    )
                    and _USER_CALL_ERROR_RE.search(source) is None
                )
    if predicted_step == len(view.steps):
        facts = view.execution_facts
        if facts is not None and error_type == ErrorType.STEP_LIMIT:
            limit_signals = [
                source
                for source in (
                    facts.final_stop_reason or "",
                    facts.final_error_message or "",
                )
                if _STEP_LIMIT_RE.search(source)
            ]
            if limit_signals:
                sources.extend(limit_signals)
                if facts.metadata_steps is not None:
                    sources.append(
                        f"benchmark.metadata.steps={facts.metadata_steps}"
                    )
                sources.append(
                    f"canonical.turn_count={facts.canonical_turn_count}"
                )
        elif facts is not None and error_type == ErrorType.LLM_LIMIT:
            for source in (
                facts.final_stop_reason or "",
                facts.final_error_message or "",
            ):
                if _LLM_LIMIT_RE.search(source):
                    sources.append(source)
        elif facts is not None and error_type in {
            ErrorType.TOOL_EXECUTION_ERROR,
            ErrorType.ENVIRONMENT_ERROR,
        }:
            source = facts.final_error_message or ""
            if (
                _EXTERNAL_FAILURE_RE.search(source)
                and _USER_CALL_ERROR_RE.search(source) is None
            ):
                sources.append(source)
    return tuple(dict.fromkeys(source for source in sources if source.strip()))


def _system_locator_sources(view: Any, predicted_step: int) -> tuple[str, ...]:
    return tuple(
        dict.fromkeys(
            source
            for error_type in (
                ErrorType.STEP_LIMIT,
                ErrorType.TOOL_EXECUTION_ERROR,
                ErrorType.LLM_LIMIT,
                ErrorType.ENVIRONMENT_ERROR,
            )
            for source in _system_owner_sources(
                view, predicted_step, error_type
            )
        )
    )


def _locator(
    case: Any,
    value: Any,
    *,
    location: str,
) -> dict[str, Any]:
    if not isinstance(value, Mapping) or set(value) != _LOCATOR_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_locator_fields", f"{location} has invalid fields"
        )
    step = value["step"]
    if (
        isinstance(step, bool)
        or not isinstance(step, int)
        or step < 1
        or step > len(case.judge_view.steps)
    ):
        raise AgentJudgeValidationError(
            "candidate_step_out_of_range",
            f"{location}.step is not a JudgeView step",
        )
    basis = value["defect_basis"]
    if not isinstance(basis, str) or basis not in _DEFECT_BASES:
        raise AgentJudgeValidationError(
            "invalid_defect_basis", f"{location}.defect_basis is invalid"
        )
    for field in _LOCATOR_FIELDS - {"step", "defect_basis"}:
        _required_text(value[field], location=f"{location}.{field}")
    sources = (
        _system_locator_sources(case.judge_view, step)
        if basis == "observable_system_boundary"
        else _locator_sources(case, step)
    )
    if not any(value["boundary_quote"] in source for source in sources):
        raise AgentJudgeValidationError(
            "invalid_locator_evidence",
            f"{location}.boundary_quote is not literal at its step",
        )
    return dict(value)


def _leaf_and_residual_owner_source_resolver(
    view: Any,
    predicted_step: int,
    module: AgentModule,
    error_type: ErrorType,
) -> tuple[str, ...]:
    """Combine nested leaf isolation with carefully bounded residual support."""

    if module == AgentModule.SYSTEM:
        return _system_owner_sources(view, predicted_step, error_type)
    step = view.steps[predicted_step - 1]
    raw = step.assistant_raw_output
    text_blocks = {block.block_index: block for block in step.text_blocks}
    valid_spans_list: list[Any] = []
    seen_intervals: set[tuple[int, int]] = set()
    for span in sorted(
        step.module_spans,
        key=lambda item: (item.tag_start_char, item.tag_end_char),
    ):
        block = text_blocks.get(span.block_index)
        interval = (span.tag_start_char, span.tag_end_char)
        if (
            block is None
            or interval in seen_intervals
            or span.tag_start_char < block.start_char
            or span.tag_end_char > block.end_char
            or span.tag_end_char <= span.tag_start_char
            or span.content_start_char < span.tag_start_char
            or span.content_end_char > span.tag_end_char
            or span.content_end_char < span.content_start_char
            or span.module not in {item.value for item in AgentModule}
        ):
            return ()
        seen_intervals.add(interval)
        valid_spans_list.append(span)
    valid_spans = tuple(valid_spans_list)
    for index, left in enumerate(valid_spans):
        for right in valid_spans[index + 1 :]:
            overlap = (
                left.tag_start_char < right.tag_end_char
                and right.tag_start_char < left.tag_end_char
            )
            left_contains = (
                left.tag_start_char <= right.tag_start_char
                and left.tag_end_char >= right.tag_end_char
            )
            right_contains = (
                right.tag_start_char <= left.tag_start_char
                and right.tag_end_char >= left.tag_end_char
            )
            if overlap and not (left_contains or right_contains):
                return ()
    leaf_spans = tuple(
        span
        for span in valid_spans
        if not any(
            other is not span
            and other.tag_start_char >= span.tag_start_char
            and other.tag_end_char <= span.tag_end_char
            and (
                other.tag_start_char > span.tag_start_char
                or other.tag_end_char < span.tag_end_char
            )
            for other in valid_spans
        )
    )
    sources: list[str] = []
    for span in leaf_spans:
        if span.module != module.value:
            continue
        source = raw[span.tag_start_char : span.tag_end_char]
        if (
            module == AgentModule.PLANNING
            and _FOREIGN_TO_PLANNING_TAG_RE.search(source)
        ):
            continue
        sources.append(source)
    if not valid_spans and raw.strip():
        if _RECOGNIZED_TAG_RE.search(raw) is None:
            sources.append(raw)
    if module == AgentModule.ACTION:
        for call in step.tool_calls:
            sources.append(call.name)
            sources.extend(_string_leaves(call.arguments))
            sources.extend(_string_leaves(call.partial_arguments))
    if valid_spans and module == AgentModule.PLANNING:
        # Planning residual exists only *inside* an explicit Planning/think
        # span.  Never grant arbitrary top-level text to Planning: benchmark
        # traces contain malformed action markers such as ``[action>`` that
        # are deliberately absent from ``module_spans``.
        for parent in valid_spans:
            if parent.module != AgentModule.PLANNING.value:
                continue
            contained = [
                child
                for child in valid_spans
                if child is not parent
                and child.tag_start_char >= parent.tag_start_char
                and child.tag_end_char <= parent.tag_end_char
                and (
                    child.tag_start_char > parent.tag_start_char
                    or child.tag_end_char < parent.tag_end_char
                )
            ]
            outermost_children = [
                child
                for child in contained
                if not any(
                    other is not child
                    and other.tag_start_char <= child.tag_start_char
                    and other.tag_end_char >= child.tag_end_char
                    and (
                        other.tag_start_char < child.tag_start_char
                        or other.tag_end_char > child.tag_end_char
                    )
                    for other in contained
                )
            ]
            if not outermost_children:
                continue
            cursor = parent.tag_start_char
            for child in sorted(
                outermost_children,
                key=lambda item: (item.tag_start_char, item.tag_end_char),
            ):
                if child.tag_start_char > cursor:
                    residual = raw[cursor : child.tag_start_char]
                    if (
                        residual.strip()
                        and _FOREIGN_TO_PLANNING_TAG_RE.search(residual) is None
                    ):
                        sources.append(residual)
                cursor = max(cursor, child.tag_end_char)
            if cursor < parent.tag_end_char:
                residual = raw[cursor : parent.tag_end_char]
                if (
                    residual.strip()
                    and _FOREIGN_TO_PLANNING_TAG_RE.search(residual) is None
                ):
                    sources.append(residual)
    if module == AgentModule.ACTION:
        # Unparsed action blocks may sit outside all valid spans even when the
        # environment accepted and executed them.  Isolate the action-looking
        # block for every legal Action type; parser geometry establishes the
        # owner, not whether the semantic defect is format, parameters, or
        # plan/action misalignment.
        top_level = [
            span
            for span in valid_spans
            if not any(
                other is not span
                and other.tag_start_char <= span.tag_start_char
                and other.tag_end_char >= span.tag_end_char
                and (
                    other.tag_start_char < span.tag_start_char
                    or other.tag_end_char > span.tag_end_char
                )
                for other in valid_spans
            )
        ]
        intervals = sorted(
            (span.tag_start_char, span.tag_end_char) for span in top_level
        )
        cursor = 0
        residuals: list[str] = []
        for start, end in intervals:
            if start > cursor:
                residuals.append(raw[cursor:start])
            cursor = max(cursor, end)
        if cursor < len(raw):
            residuals.append(raw[cursor:])
        for residual in residuals:
            opening = _ACTION_OPEN_TAG_RE.search(residual)
            if opening is None:
                continue
            closing = _ACTION_CLOSE_TAG_RE.search(residual, opening.end())
            end = closing.end() if closing is not None else len(residual)
            source = residual[opening.start() : end]
            if source.strip():
                sources.append(source)
    return tuple(dict.fromkeys(source for source in sources if source.strip()))


def _classification(
    case: Any,
    value: Any,
    *,
    selected: Mapping[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(value, Mapping) or set(value) != _CLASSIFICATION_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_classification_fields", f"{location} has invalid fields"
        )
    try:
        module = AgentModule(value["predicted_module"])
        error_type = ErrorType(value["predicted_error_type"])
    except (TypeError, ValueError) as error:
        raise AgentJudgeValidationError(
            "invalid_classification_taxonomy", f"{location} has unknown taxonomy"
        ) from error
    if not is_valid_classification(module, error_type):
        raise AgentJudgeValidationError(
            "invalid_classification_taxonomy",
            f"{location} has an illegal module/error_type pair",
        )
    if (module == AgentModule.SYSTEM) != (
        selected["defect_basis"] == "observable_system_boundary"
    ):
        raise AgentJudgeValidationError(
            "invalid_system_admission",
            "System classification and observable_system_boundary must agree",
        )
    _required_text(
        value["rejected_adjacent_owner"],
        location=f"{location}.rejected_adjacent_owner",
    )
    sources = _leaf_and_residual_owner_source_resolver(
        case.judge_view, selected["step"], module, error_type
    )
    if not sources or not any(
        selected["boundary_quote"] in source for source in sources
    ):
        raise AgentJudgeValidationError(
            "invalid_classification_evidence",
            "the selected locator boundary_quote is not owned by the frozen "
            f"step and {location}.predicted_module",
        )
    return dict(value)


def _prediction_record(case: Any, candidate: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        **dict(candidate),
    }


def validate_luna_v13_unified_decision(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    decision_path: str | Path,
) -> dict[str, Any]:
    """Validate and deterministically resolve one current-session decision."""

    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    manifest, cases = load_prediction_manifest(manifest_path)
    if len(cases) != 1:
        raise AgentJudgeValidationError(
            "invalid_decision_case_count", "a v13 decision requires one case"
        )
    case = cases[0]
    cohort_path = Path(cohort_manifest_path).expanduser().resolve()
    cohort = _cohort_document(cohort_path)
    if (
        cohort["trajectory_ids"] != [case.trajectory_id]
        or manifest.get("cohort_name") != cohort.get("cohort_name")
        or manifest.get("cohort_sha256") != cohort.get("cohort_sha256")
        or manifest.get("dataset_manifest_sha256")
        != cohort.get("dataset_manifest_sha256")
    ):
        raise AgentJudgeValidationError(
            "decision_cohort_mismatch",
            "the one-case cohort identity does not match the prediction manifest",
        )
    resolved_decision_path = Path(decision_path).expanduser().resolve()
    raw = _load_json(resolved_decision_path, role="decision")
    if not isinstance(raw, Mapping) or set(raw) != _DECISION_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_decision_fields", "decision has invalid top-level fields"
        )
    chronological = _locator(
        case,
        raw["chronological_locator"],
        location="decision.chronological_locator",
    )
    local = _locator(
        case,
        raw["local_locator"],
        location="decision.local_locator",
    )
    if (
        len(case.judge_view.steps) > 1
        and chronological["step"] == local["step"]
    ):
        raise AgentJudgeValidationError(
            "candidate_steps_not_distinct",
            "multi-step chronological and local candidates must differ",
        )
    arbitration = raw["arbitration"]
    if not isinstance(arbitration, Mapping) or set(arbitration) != _ARBITRATION_FIELDS:
        raise AgentJudgeValidationError(
            "invalid_arbitration_fields", "decision.arbitration has invalid fields"
        )
    lane = arbitration["selected_lane"]
    basis = arbitration["selection_basis"]
    if (
        not isinstance(lane, str)
        or lane not in _LANES
        or not isinstance(basis, str)
        or basis not in _SELECTION_BASES
    ):
        raise AgentJudgeValidationError(
            "invalid_arbitration_choice", "selected lane or basis is invalid"
        )
    selected_reason = _required_text(
        arbitration["selected_candidate_reason"],
        location="decision.arbitration.selected_candidate_reason",
    )
    rejected_reason = _required_text(
        arbitration["rejected_candidate_reason"],
        location="decision.arbitration.rejected_candidate_reason",
    )
    selected = chronological if lane == "chronological" else local
    rejected = local if lane == "chronological" else chronological
    selected_basis = selected["defect_basis"]
    direct_bases = {
        "literal_state_contradiction",
        "literal_task_constraint",
        "plan_action_contract",
        "mechanical_interface_defect",
    }
    inconsistent = (
        (basis == "direct_root" and selected_basis not in direct_bases)
        or (basis == "mature_repetition" and selected_basis != "mature_repetition")
        or (
            basis == "observable_system_boundary"
            and selected_basis != "observable_system_boundary"
        )
        or (
            basis == "causal_predecessor"
            and selected["step"] >= rejected["step"]
        )
    )
    if inconsistent:
        raise AgentJudgeValidationError(
            "inconsistent_arbitration_basis",
            "selection_basis is inconsistent with the selected locator",
        )
    classification = _classification(
        case,
        raw["classification"],
        selected=selected,
        location="decision.classification",
    )
    prediction = _prediction_record(
        case,
        {
            "predicted_step": selected["step"],
            "predicted_module": classification["predicted_module"],
            "predicted_error_type": classification["predicted_error_type"],
            "evidence_quote": selected["boundary_quote"],
            "root_cause": selected["boundary_reason"],
            "causal_summary": (
                f"Smallest correction: {selected['smallest_correction']} "
                "Downstream consequence: "
                f"{selected['downstream_consequence']}"
            ),
            "rejected_adjacent_owner": classification[
                "rejected_adjacent_owner"
            ],
        },
    )
    if set(prediction) != AGENT_JUDGE_PREDICTION_FIELDS:
        raise AssertionError("derived v13 prediction fields changed")
    return {
        "schema_version": "agentdebug.codex-agent-judge-luna-v13-decision-audit.v1",
        "agent_judge_version": AGENT_JUDGE_LUNA_V13_UNIFIED_VERSION,
        "model": AGENT_JUDGE_LUNA_V13_UNIFIED_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V13_UNIFIED_REASONING_EFFORT,
        "proposal_free": True,
        "historical_predictions_visible": False,
        "same_session_hypothesis_count": 2,
        "candidate_steps_distinct_when_possible": True,
        "selected_lane": lane,
        "selection_basis": basis,
        "selected_candidate_reason": selected_reason,
        "rejected_candidate_reason": rejected_reason,
        "chronological_locator": chronological,
        "local_locator": local,
        "classification": classification,
        "selected_prediction": prediction,
        "prediction_manifest_file_sha256": _file_sha256(manifest_path),
        "cohort_manifest_file_sha256": _file_sha256(cohort_path),
        "cohort_name": cohort["cohort_name"],
        "cohort_sha256": cohort["cohort_sha256"],
        "dataset_manifest_sha256": cohort["dataset_manifest_sha256"],
        "decision_sha256": _file_sha256(resolved_decision_path),
    }


def _decision_contract() -> str:
    return json.dumps(decision_output_schema(), ensure_ascii=False, indent=2)


def build_agent_judge_luna_v13_unified_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    """Embed one anonymous JudgeView into a no-tool, one-session prompt."""

    del predictions_path
    manifest, cases = load_prediction_manifest(prediction_manifest_path)
    if len(cases) != 1:
        raise AgentJudgeValidationError(
            "invalid_task_case_count", "a v13 task requires exactly one case"
        )
    cohort = _cohort_document(
        Path(cohort_manifest_path).expanduser().resolve()
    )
    if (
        cohort["trajectory_ids"] != [cases[0].trajectory_id]
        or manifest.get("cohort_name") != cohort.get("cohort_name")
        or manifest.get("cohort_sha256") != cohort.get("cohort_sha256")
        or manifest.get("dataset_manifest_sha256")
        != cohort.get("dataset_manifest_sha256")
    ):
        raise AgentJudgeValidationError(
            "task_cohort_mismatch",
            "the one-case cohort identity does not match the prediction manifest",
        )
    case = cases[0]
    timeline = _anonymized_timeline(case)
    return f"""\
Run frozen protocol {AGENT_JUDGE_LUNA_V13_UNIFIED_VERSION}.

EXECUTION CONTRACT
- model: {AGENT_JUDGE_LUNA_V13_UNIFIED_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_V13_UNIFIED_REASONING_EFFORT}
- exactly one anonymous trajectory is embedded below
- do not call tools, inspect files, use the network, or use external APIs
- no prior prediction, proposal, label, score, case study, or cross-case state exists
- return exactly one JSON object matching the supplied output schema

Every trajectory follows the identical three-phase procedure.  Complete both
hypotheses before arbitration.  Do not infer from an identifier, source-model
name, environment name, expected distribution, or benchmark familiarity.

PHASE A — CHRONOLOGICAL STEP LOCATOR

Scan Step 1 onward.  At each step test Memory, Reflection, Planning, Action,
and observable System facts.  Select the first mature causal step: it must be
demonstrably wrong with information available then, and its smallest local
correction must materially redirect the failure.  Do not call a reasonable
first probe or one ambiguous confirmation inefficient.  Use only the neutral
defect_basis enum; do not decide module or taxonomy type yet.  Freeze this
locator before constructing Phase B.

Maintain a chronological evidence ledger while scanning.  For every step,
compare Memory to concrete facts already observed; Reflection to the immediately
preceding result and actual task progress; Planning to literal constraints,
available prerequisites, and the unresolved information goal; and Action to the
current plan plus supplied interface.  Test universal claims such as “none”,
“all”, “no relevant result”, “complete”, or “matches” against the evidence
actually inspected.  A broad discovery query is not yet a critical error when
it can still return useful candidates.  A later malformed action is downstream
when the current plan already selected the defective operation.

PHASE B — DIFFERENT-STEP LOCAL LOCATOR

Independently find the strongest locally attributable error at a different
step whenever the trajectory has multiple steps.  Prefer a literal false
Memory/Reflection assertion, a task-constraint conflict, an impossible
prerequisite, a same-step Plan/Action contract breach, a mechanical interface
defect, a mature self-defeating repetition, or a narrowly observable System
boundary.  System is admissible at Step 1 for mutually unsatisfiable literal
task/interface requirements, at an action step for an independent external
failure after a valid available well-formed call, or at the final step for a
provenance-backed execution limit.  A normal empty result, rejected bad
parameter, merely failed valid probe, vague hindsight improvement, or later
symptom is not a System or locally attributable error.

PHASE C — UNIFORM CAUSAL ARBITRATION

Apply these rules to every case; neither lane is a default or prior answer.

1. A direct false state/result/progress claim, explicit constraint conflict,
   mechanically defective Action, or literal Plan/Action breach outranks a
   candidate supported only by generic strategy aesthetics.
2. A causally used earlier premise outranks its later repetition, unsupported
   conclusion, or failed final answer.  Chronology alone is not proof: the
   earlier output must already be materially defective.
3. For repetition, compare operational objective, evidence channel, query or
   action arguments, returned evidence, and intervening recovery.  Initial
   acquisition plus one evidence-motivated confirmation is normally allowed.
   A repetition candidate is legal only when all four gates hold: prior
   feedback already proves no progress for the same information goal; the
   selected output literally recommits to an equivalent operation; no new
   target, source, constraint, observation, or restored capability opens a new
   epoch; and this is the first output in the epoch satisfying those gates.
   A useful new fact, target class, source, or successful equivalent operation
   resets the epoch.
4. An observed System boundary wins when mutually inconsistent input
   requirements or a step/tool/model/environment fault independently prevents
   otherwise coherent progress.  A tool outcome is System only when the tool
   is available, the call is mechanically well formed, and the returned fault
   is external rather than a bad parameter or ordinary no-result response.  A
   final provenance-backed limit wins over an untried hindsight alternative.
   A final step number or turn count alone is not a typed limit signal and
   cannot establish System/step_limit.
   Any System candidate loses to a concrete causally prior agent error.
5. Preserve the chronological candidate when it has a direct, material source
   defect and the local candidate is only clearer or later.  Select the local
   candidate when it supplies the stronger direct contradiction, the correct
   maturity boundary, the terminal System boundary, or a causal predecessor.
   For independent candidates, use this precedence: literal local breach or
   Plan/Action contract, then qualified mature recurrence, then terminal
   System, then generic inferred inefficiency.  Within one class choose the
   first step where its complete admission test becomes true.

Set arbitration.selection_basis to describe the selected locator itself:
direct_root only for a literal state/task/Plan-Action/mechanical defect;
mature_repetition only when the selected locator has that defect_basis;
observable_system_boundary only for that System basis; causal_predecessor only
when the selected step is earlier than and supplies the rejected defect;
otherwise use stronger_material_root.  Never select by lane name, list order,
quote length, or because a candidate is later and easier to see.

After arbitration, the complete selected locator is immutable: step,
defect_basis, boundary_quote, boundary_reason, correction, and consequence.
Only then resolve the actual same-step owner and type in classification.  A
taxonomy or evidence problem may never move the selected step or replace the
selected defect with another same-step problem.  The parent derives final
evidence_quote, root_cause, and causal_summary from the selected locator; the
classification object therefore must not repeat or rewrite them.

Resolve ownership by information flow.  Memory owns newly lost/invented state;
Reflection owns a false reading of feedback/progress/cause; Planning owns a
defective strategy or prerequisite when earlier state is sound; Action owns a
concrete departure from an adequate plan or a mechanical invocation defect.  A
faithful action does not steal its plan's error.  A final answer is downstream
when it merely emits an earlier false premise.  System owns mutually
unsatisfiable task/interface input at Step 1, an independent external failure
returned by a valid call at that action step, or a provenance-backed final
execution boundary.

Each locator boundary_quote must be one exact contiguous, case-sensitive
substring of selected-step assistant text, a selected-step tool-call name or
string argument, or—only when defect_basis is observable_system_boundary—a
validator-admitted System source: Step 1 task text for mutually inconsistent
input, an explicit structured external-call error, or a typed final execution
fact.  Non-System locators must quote the agent output or concrete operation
that introduces the defect, never task or observation text.  The selected
quote must also be owned by
classification.predicted_module at that step.  Nested
module tags use the innermost leaf span.  Planning may also use deliberative
residual text inside an explicit Planning/think span after nested foreign
owners are removed; top-level residual is never Planning evidence.  Action may
use an isolated unparsed action block for any legal Action type; imperfect tag
geometry does not itself decide whether the defect is format, parameters, or
plan/action misalignment.  System quotes an observable execution fact.
Choose the taxonomy type only after the full locator is frozen.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

OUTPUT CONTRACT
{_decision_contract()}

GOLD-FREE JUDGEVIEW
{timeline}
"""


def validate_agent_judge_luna_v13_unified_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = _validate_agent_judge_predictions_with_owner_sources(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
        owner_source_resolver=_leaf_and_residual_owner_source_resolver,
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_V13_UNIFIED_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_V13_UNIFIED_VERSION,
        "model": AGENT_JUDGE_LUNA_V13_UNIFIED_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_V13_UNIFIED_REASONING_EFFORT,
        "proposal_free": True,
        "historical_predictions_visible": False,
        "same_session_dual_hypothesis": True,
        "label_pair_routing_used": False,
        "nested_module_spans_supported": True,
    }


__all__ = [
    "AGENT_JUDGE_LUNA_V13_UNIFIED_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_V13_UNIFIED_MODEL",
    "AGENT_JUDGE_LUNA_V13_UNIFIED_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_V13_UNIFIED_VERSION",
    "DECISION_FILENAME",
    "build_agent_judge_luna_v13_unified_task",
    "decision_output_schema",
    "validate_agent_judge_luna_v13_unified_predictions",
    "validate_luna_v13_unified_decision",
]

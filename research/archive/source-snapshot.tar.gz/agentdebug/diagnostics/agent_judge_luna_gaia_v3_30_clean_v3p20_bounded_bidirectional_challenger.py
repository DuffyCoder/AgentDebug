"""Luna GAIA v3.30: clean v3.20 with one bounded bidirectional challenger."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger as mechanism
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent


AGENT_JUDGE_LUNA_GAIA_V3_30_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.30-clean-v3.20-"
    "bounded-bidirectional-challenger"
)
AGENT_JUDGE_LUNA_GAIA_V3_30_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_30_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_30_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_30_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_30_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_30_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_30_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = mechanism.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = mechanism.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = mechanism.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = mechanism.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = mechanism.CHALLENGERS_FILENAME
ARBITER_FILENAME = mechanism.ARBITER_FILENAME
ARBITERS_FILENAME = mechanism.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = mechanism.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = mechanism.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = mechanism.PREDICTION_AUDIT_FILENAME


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_30_VERSION,
        )
        .replace(
            mechanism.AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_30_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_30_clean_v3p20_bounded_bidirectional_challenger",
        )
        .replace(
            "agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger",
            "agent_judge_luna_gaia_v3_30_clean_v3p20_bounded_bidirectional_challenger",
        )
    )


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_anchor_task(*paths))


def build_challenger_task(*paths: str | Path) -> str:
    return _rewrite_identity(mechanism.build_challenger_task(*paths))


def build_arbiter_task(*paths: str | Path) -> str:
    return _rewrite_identity(mechanism.build_arbiter_task(*paths))


def build_agent_judge_luna_gaia_v3_30_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def _retag(audit: dict[str, Any]) -> dict[str, Any]:
    result = dict(audit)
    result["agent_judge_version"] = AGENT_JUDGE_LUNA_GAIA_V3_30_VERSION
    result["model"] = AGENT_JUDGE_LUNA_GAIA_V3_30_MODEL
    result["reasoning_effort"] = AGENT_JUDGE_LUNA_GAIA_V3_30_REASONING_EFFORT
    return result


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths))


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    return _retag(mechanism.validate_challenger(*paths))


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    return _retag(mechanism.validate_arbiter(*paths))


def validate_agent_judge_luna_gaia_v3_30_predictions(
    *paths: str | Path,
) -> dict[str, Any]:
    audit = _retag(mechanism.validate_agent_judge_luna_gaia_v3_16_predictions(*paths))
    predictions = Path(paths[2]).expanduser().resolve()
    audit["schema_version"] = AGENT_JUDGE_LUNA_GAIA_V3_30_AUDIT_SCHEMA_VERSION
    audit["selection_policy"] = (
        "clean_v3_20_packet_state_anchor_one_bounded_earlier_first_"
        "bidirectional_challenger_default_keep_exact_copy_arbiter"
    )
    audit["direct_semantic_parent"] = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION
    audit["rejected_lineage_inherited"] = False
    audit["packet_state_closure"] = parent._validate_packet_state_ledgers(
        predictions.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME
    )
    audit["anchor_semantics_unchanged_from_v3_20"] = True
    return audit


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_30_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_30_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_30_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_30_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_30_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_30_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

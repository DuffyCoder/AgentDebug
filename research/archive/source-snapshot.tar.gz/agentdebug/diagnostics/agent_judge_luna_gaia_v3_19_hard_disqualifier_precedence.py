"""Luna GAIA v3.19: literal hard-disqualifier precedence over probe veto."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_18_probe_contribution_veto as parent
from . import agent_judge_luna_gaia_v3_14_earliest_causal_challenger as semantic_base
from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from .agent_judge_luna_gaia_v3_4 import (
    STEP_CANDIDATE_LEDGER_FILENAME,
    validate_agent_judge_luna_gaia_v3_4_predictions,
)


AGENT_JUDGE_LUNA_GAIA_V3_19_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia-v3.19-hard-disqualifier-precedence"
)
AGENT_JUDGE_LUNA_GAIA_V3_19_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_18_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_19_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_18_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_19_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_18_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases used by the shared three-stage runner.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_19_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_19_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_19_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_19_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = parent.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = parent.CHALLENGERS_FILENAME
ARBITER_FILENAME = parent.ARBITER_FILENAME
ARBITERS_FILENAME = parent.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = parent.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = parent.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
CHALLENGER_FIELDS = parent.CHALLENGER_FIELDS
ARBITER_FIELDS = parent.ARBITER_FIELDS


_HARD_PREFIX = re.compile(
    r"^boundary_kind=(acquisition_probe|other); "
    r"contribution=(possible|observed|zero|not_applicable); "
    r"hard_disqualifier=(none|wrong_target|invalid_argument|source_constraint|malformed_query); "
)

_HARD_DISQUALIFIER_GATE = """\
HARD-DISQUALIFIER PRECEDENCE — BINDING BEFORE THE CONTRIBUTION VETO

The v3.19 row contract extends the contribution prefix. Every decision_basis
must begin exactly:

`boundary_kind=<acquisition_probe|other>; contribution=<possible|observed|zero|not_applicable>; hard_disqualifier=<none|wrong_target|invalid_argument|source_constraint|malformed_query>; `

Evaluate hard_disqualifier before using possible/observed as a Lane-B veto:

- `wrong_target` requires a literally bound URL, entity, or document unrelated
  to the task target. A low-recall or merely indirect source is not enough.
- `invalid_argument` requires a value/type contradicted by the declared tool
  schema or rejected by adjacent feedback. Do not infer hidden API constraints,
  and do not convert an external service exception into an argument defect.
- `source_constraint` requires a committed corpus/source explicitly excluded by
  the task-defined predicate. A different corpus that can supply a useful lead
  is not task-forbidden.
- `malformed_query` requires a literal semantic contradiction, incompatible
  title/entity composition, or wrong target inside the query. Broad, vague, or
  low-probability wording is not malformed.
- Use `none` when no listed literal contradiction exists.

On an acquisition row with possible/observed contribution and a non-none hard
disqualifier, Lane B MUST be `candidate`; hypothetical contribution cannot erase
the same-packet contradiction. With hard_disqualifier=none, the existing
possible/observed initial/different-probe veto remains binding.

Static-page versus dynamic-video/UI capability is NOT a hard-disqualifier
category here. Keep evaluating it through the existing contribution=zero rule.
For boundary_kind=other, require contribution=not_applicable and
hard_disqualifier=none.

"""


def _rewrite_parent_task(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_18_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_19_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_18_probe_contribution_veto",
            "agent_judge_luna_gaia_v3_19_hard_disqualifier_precedence",
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_18_probe_contribution_veto.py",
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_19_hard_disqualifier_precedence.py",
        )
    )


def _rewrite_anchor_validator(task: str) -> str:
    task = task.replace(
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_18_probe_contribution_veto "
        "import validate_and_write_anchor_audit as run",
        "from agentdebug.diagnostics.agent_judge_luna_gaia_v3_19_hard_disqualifier_precedence "
        "import validate_and_write_anchor_audit as run",
    )
    return task


def build_anchor_task(*paths: str | Path) -> str:
    task = _rewrite_anchor_validator(_rewrite_parent_task(parent.build_anchor_task(*paths)))
    marker = "`possible` and `observed` are binding vetoes on a Lane-B capability candidate:"
    if task.count(marker) != 1:
        raise RuntimeError("v3.18 contribution gate changed unexpectedly")
    task = task.replace(marker, _HARD_DISQUALIFIER_GATE + marker, 1)
    task = task.replace(
        '"decision_basis": "boundary_kind=acquisition_probe; contribution=possible; compact literal step assessment"',
        '"decision_basis": "boundary_kind=acquisition_probe; contribution=possible; hard_disqualifier=none; compact literal step assessment"',
    )
    task = task.replace(
        '"decision_basis": "boundary_kind=other; contribution=not_applicable; compact reason this is the first surviving candidate"',
        '"decision_basis": "boundary_kind=other; contribution=not_applicable; hard_disqualifier=none; compact reason this is the first surviving candidate"',
    )
    return task


def build_challenger_task(*paths: str | Path) -> str:
    return _rewrite_parent_task(parent.build_challenger_task(*paths))


def build_arbiter_task(*paths: str | Path) -> str:
    return _rewrite_parent_task(parent.build_arbiter_task(*paths))


def build_agent_judge_luna_gaia_v3_19_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / STEP_CANDIDATE_LEDGER_FILENAME,
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def _validate_hard_disqualifier_ledgers(path: str | Path) -> dict[str, Any]:
    ledger_path, raw = shared._load_artifact(path, role="hard-disqualifier ledger")
    ledgers = raw if isinstance(raw, list) else [raw]
    if not ledgers or any(not isinstance(item, dict) for item in ledgers):
        shared._fail("invalid_hard_disqualifier_ledger", "ledger records unavailable")

    counts: Counter[str] = Counter()
    row_count = 0
    precedence_count = 0
    ordinary_veto_count = 0
    for ledger_index, ledger in enumerate(ledgers):
        rows = ledger.get("rows")
        if not isinstance(rows, list) or not rows:
            shared._fail(
                "invalid_hard_disqualifier_rows",
                f"ledger[{ledger_index}] rows unavailable",
            )
        for row_index, row in enumerate(rows):
            basis = row.get("decision_basis") if isinstance(row, dict) else None
            match = _HARD_PREFIX.match(basis or "")
            if match is None:
                shared._fail(
                    "missing_hard_disqualifier_prefix",
                    f"ledger[{ledger_index}].rows[{row_index}]",
                )
            boundary_kind, contribution, hard = match.groups()
            location = f"ledger[{ledger_index}].rows[{row_index}]"
            if boundary_kind == "other":
                if contribution != "not_applicable" or hard != "none":
                    shared._fail("invalid_other_hard_disqualifier_pairing", location)
            elif contribution == "not_applicable":
                shared._fail("missing_acquisition_probe_contribution", location)

            if boundary_kind == "acquisition_probe" and contribution in {
                "possible",
                "observed",
            }:
                if hard == "none":
                    if row.get("lane_b") not in {
                        "veto_initial_probe",
                        "veto_different_probe",
                    }:
                        shared._fail("ordinary_probe_lacks_lane_b_veto", location)
                    ordinary_veto_count += 1
                else:
                    if row.get("lane_b") != "candidate":
                        shared._fail("hard_disqualifier_lacks_lane_b_candidate", location)
                    precedence_count += 1
            counts[f"{boundary_kind}:{contribution}:{hard}"] += 1
            row_count += 1
    return {
        "required": True,
        "valid": True,
        "path": str(ledger_path),
        "ledger_count": len(ledgers),
        "row_count": row_count,
        "status_counts": dict(sorted(counts.items())),
        "hard_disqualifier_precedence_count": precedence_count,
        "ordinary_contribution_veto_count": ordinary_veto_count,
    }


def validate_anchor_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v3_4_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    ledger = Path(predictions_path).expanduser().resolve().parent / STEP_CANDIDATE_LEDGER_FILENAME
    hard = _validate_hard_disqualifier_ledgers(ledger)
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_19_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_19_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_19_REASONING_EFFORT,
        "selection_policy": "v3_18_probe_gate_with_hard_disqualifier_precedence",
        "hard_disqualifier_gate": hard,
    }


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    audit = semantic_base.validate_challenger(*paths)
    hard = _validate_hard_disqualifier_ledgers(paths[3])
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_19_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_19_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_19_REASONING_EFFORT,
        "hard_disqualifier_gate": hard,
    }


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    audit = semantic_base.validate_arbiter(*paths)
    hard = _validate_hard_disqualifier_ledgers(paths[3])
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_19_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_19_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_19_REASONING_EFFORT,
        "hard_disqualifier_gate": hard,
    }


def validate_agent_judge_luna_gaia_v3_19_predictions(*paths: str | Path) -> dict[str, Any]:
    audit = semantic_base.validate_agent_judge_luna_gaia_v3_14_predictions(*paths)
    predictions = Path(paths[2]).expanduser().resolve()
    hard = _validate_hard_disqualifier_ledgers(
        predictions.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_19_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_19_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_19_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_19_REASONING_EFFORT,
        "selection_policy": (
            "hard_disqualifier_precedence_probe_veto_v3_4_anchor_one_earliest_"
            "causal_later_challenger_default_keep_exact_copy_arbiter"
        ),
        "hard_disqualifier_gate": hard,
    }


def _write_audit(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return semantic_base._write_audit(audit, path)


def validate_and_write_anchor_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        validate_anchor_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write_audit(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_19_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write_audit(
        validate_agent_judge_luna_gaia_v3_19_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


# Compatibility names used by the shared paper-50 runner.
build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_19_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_19_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_19_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_19_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "AGENT_JUDGE_LUNA_GAIA_V3_19_AUDIT_SCHEMA_VERSION",
    "AGENT_JUDGE_LUNA_GAIA_V3_19_MODEL",
    "AGENT_JUDGE_LUNA_GAIA_V3_19_REASONING_EFFORT",
    "AGENT_JUDGE_LUNA_GAIA_V3_19_VERSION",
    "ANCHOR_CHECKPOINT_AGGREGATE_FILENAME",
    "ANCHOR_LEDGER_AGGREGATE_FILENAME",
    "ANCHOR_PREDICTIONS_FILENAME",
    "ARBITER_FILENAME",
    "ARBITERS_FILENAME",
    "CHALLENGER_FILENAME",
    "CHALLENGERS_FILENAME",
    "build_agent_judge_luna_gaia_v3_19_task",
    "build_anchor_task",
    "build_arbiter_task",
    "build_challenger_task",
    "validate_agent_judge_luna_gaia_v3_19_predictions",
    "validate_anchor_predictions",
    "validate_and_write_agent_judge_luna_gaia_v3_19_audit",
    "validate_and_write_anchor_audit",
    "validate_and_write_arbiter_audit",
    "validate_and_write_challenger_audit",
    "validate_arbiter",
    "validate_challenger",
]

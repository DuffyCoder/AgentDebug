"""Luna GAIA v3.68: exact-predicate reducer with compact embedded JudgeView."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from . import agent_judge_luna_gaia_v3_66_clean_v3p20_exact_predicate_acquisition_boundary_reducer as mechanism
from . import agent_judge_luna_gaia_v3_67_clean_v3p20_exact_predicate_acquisition_boundary_reducer_read_only_input as file_runtime
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions


AGENT_JUDGE_LUNA_GAIA_V3_68_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.68-clean-v3.20-"
    "exact-predicate-acquisition-boundary-reducer-compact-embedded-input"
)
AGENT_JUDGE_LUNA_GAIA_V3_68_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_68_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_68_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases for the v3.67 response-only runtime implementation.
AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_68_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_68_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_68_REASONING_EFFORT
)

AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_68_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_68_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_68_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_68_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_68_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_68_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_68_AUDIT_SCHEMA_VERSION
)

shared = mechanism.shared
ANCHOR_PREDICTIONS_FILENAME = mechanism.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = mechanism.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = mechanism.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = mechanism.PREDICTION_AUDIT_FILENAME
PANEL_FILENAME = mechanism.PANEL_FILENAME
PANELS_FILENAME = mechanism.PANELS_FILENAME
PANEL_AUDIT_FILENAME = mechanism.PANEL_AUDIT_FILENAME
SELECTOR_FILENAME = mechanism.SELECTOR_FILENAME
SELECTORS_FILENAME = mechanism.SELECTORS_FILENAME
SELECTOR_AUDIT_FILENAME = mechanism.SELECTOR_AUDIT_FILENAME
INFERENCE_DOCUMENT_FILENAME = "compact-inference-document.json"


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_68_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_68_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_68_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one exact-predicate acquisition boundary reducer",
    }


def build_inference_document(case: Any) -> dict[str, Any]:
    """Create a lossless single-copy chronology below the CLI input limit."""

    expanded = file_runtime.build_inference_document(case)
    steps = expanded["steps"]
    compact_steps: list[dict[str, Any]] = []
    for index, row in enumerate(steps):
        if index > 0 and row["current_input"] != steps[index - 1]["adjacent_feedback"]:
            shared._fail(
                "nonduplicated_step_input_in_compact_projection",
                f"step {row['step']} current input differs from prior feedback",
            )
        compact_steps.append(
            {
                "step": row["step"],
                "assistant_raw_output": row["assistant_raw_output"],
                "module_spans": [
                    {
                        "module": span["module"],
                        "content_start_char": span["content_start_char"],
                        "content_end_char": span["content_end_char"],
                    }
                    for span in row["module_spans"]
                ],
                "feedback_after_step": row["adjacent_feedback"],
                "system_evidence_sources": row["owner_sources"]["system"],
                "stop_reason": row["stop_reason"],
                "error_message": row["error_message"],
            }
        )
    return {
        "schema_version": "agentdebug.v3p68-single-copy-full-judge-view.v1",
        "trajectory_id": expanded["trajectory_id"],
        "trajectory_sha256": expanded["trajectory_sha256"],
        "task": expanded["task"],
        "execution_facts": expanded["execution_facts"],
        "input_before_first_step": steps[0]["current_input"],
        "step_count": expanded["step_count"],
        "steps": compact_steps,
        "deduplication_contract": (
            "For every Step after 1, input_before_step equals the prior Step's "
            "feedback_after_step byte-for-byte. Owner text is obtained by slicing "
            "assistant_raw_output with module_spans; System evidence is listed explicitly."
        ),
    }


def validate_inference_document(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    document_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    document_file, document = shared._load_artifact(
        document_path, role="v3.68 compact inference document"
    )
    if document != build_inference_document(case):
        shared._fail("non_deterministic_v3p68_inference_document", "inference_document")
    return _retag(
        {
            "schema_version": "agentdebug.v3p68-compact-inference-document-audit.v1",
            "stage": "deterministic_single_copy_full_judge_view",
            "gold_free_validation": True,
            "case_count": 1,
            "complete_step_coverage": True,
            "all_current_inputs_equal_prior_feedback": True,
            "all_owner_text_reconstructable": True,
            "input_sha256": {
                "prediction_manifest": shared._file_sha256(manifest),
                "cohort": shared._file_sha256(cohort),
            },
            "output_sha256": {
                INFERENCE_DOCUMENT_FILENAME: shared._file_sha256(document_file)
            },
        },
        policy="deterministic_gold_free_compact_embedded_inference_document",
    )


def _document_for_paths(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> dict[str, Any]:
    _, _, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    return build_inference_document(case)


def _retag_task(task: str) -> str:
    return task.replace(
        mechanism.AGENT_JUDGE_LUNA_GAIA_V3_66_VERSION,
        AGENT_JUDGE_LUNA_GAIA_V3_68_VERSION,
    )


def build_anchor_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> str:
    task = mechanism.build_anchor_response_task(
        prediction_manifest_path, cohort_manifest_path
    )
    task = task.split("EMBEDDED PREDICTION MANIFEST", 1)[0].rstrip()
    document = _document_for_paths(prediction_manifest_path, cohort_manifest_path)
    return f"""{_retag_task(task)}

COMPACT EMBEDDED JUDGEVIEW CONTRACT
- The JSON below is the complete chronological JudgeView with cumulative wrapper duplication removed.
- Every post-Step feedback is present once; it is exactly the next Step's input.
- Slice assistant_raw_output with module_spans for literal owner evidence.
- System evidence sources are explicit.
- Do not call shell, filesystem, network, validator, or any other tool.

EMBEDDED SINGLE-COPY JUDGEVIEW
{json.dumps(document, ensure_ascii=False, separators=(",", ":"))}
"""


def build_reducer_file_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
) -> str:
    task = mechanism.build_reducer_task(
        prediction_manifest_path,
        cohort_manifest_path,
        anchor_path,
        ledger_path,
        checkpoint_path,
    )
    task = task.split("EMBEDDED CURRENT PREDICTION MANIFEST", 1)[0].rstrip()
    document = _document_for_paths(prediction_manifest_path, cohort_manifest_path)
    anchor = json.loads(Path(anchor_path).read_text(encoding="utf-8"))[0]
    ledger = json.loads(Path(ledger_path).read_text(encoding="utf-8"))
    checkpoint = json.loads(Path(checkpoint_path).read_text(encoding="utf-8"))
    return f"""{_retag_task(task)}

COMPACT EMBEDDED JUDGEVIEW CONTRACT
- The JSON below is the complete chronological JudgeView with cumulative wrapper duplication removed.
- Every post-Step feedback is present once; it is exactly the next Step's input.
- Slice assistant_raw_output with module_spans for literal owner evidence.
- System evidence sources are explicit.
- Do not call shell, filesystem, network, validator, or any other tool.

EMBEDDED SINGLE-COPY JUDGEVIEW
{json.dumps(document, ensure_ascii=False, separators=(",", ":"))}

EMBEDDED FRESH V3.20 ANCHOR
{json.dumps(anchor, ensure_ascii=False, separators=(",", ":"))}

EMBEDDED FRESH V3.20 SPARSE LEDGER
{json.dumps(ledger, ensure_ascii=False, separators=(",", ":"))}

EMBEDDED FRESH V3.20 CHECKPOINT
{json.dumps(checkpoint, ensure_ascii=False, separators=(",", ":"))}
"""


anchor_response_schema = mechanism.anchor_response_schema
reducer_response_schema = mechanism.reducer_response_schema
normalize_anchor_response = file_runtime.normalize_anchor_response
normalize_assessment_response = file_runtime.normalize_assessment_response
build_selection_document = mechanism.build_selection_document


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    audit = parent.validate_anchor_predictions(*paths)
    document = Path(paths[2]).expanduser().resolve().parent / INFERENCE_DOCUMENT_FILENAME
    inference = validate_inference_document(paths[0], paths[1], document)
    return _retag(
        {**audit, "compact_embedded_input": inference},
        policy="unchanged_v3_20_anchor_compact_embedded_input",
    )


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_assessment(*paths: str | Path) -> dict[str, Any]:
    audit = mechanism.validate_assessment(*paths)
    document = Path(paths[5]).expanduser().resolve().parent / INFERENCE_DOCUMENT_FILENAME
    inference = validate_inference_document(paths[0], paths[1], document)
    return _retag(
        {**audit, "compact_embedded_input": inference},
        policy="one_exact_predicate_acquisition_boundary_assessment_compact_embedded_input",
    )


def validate_and_write_panel_audit(*paths: str | Path) -> dict[str, Any]:
    return shared._write_audit(validate_assessment(*paths[:-1]), paths[-1])


def validate_and_write_selector_audit(*paths: str | Path) -> dict[str, Any]:
    audit = mechanism.validate_selector(*paths[:-1])
    return shared._write_audit(
        _retag(audit, policy="deterministic_exact_predicate_candidate_else_anchor"),
        paths[-1],
    )


def validate_agent_judge_luna_gaia_v3_68_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    factorized = mechanism._validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_68_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_68_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_68_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_68_REASONING_EFFORT,
        "selection_policy": "clean_v3_20_exact_predicate_acquisition_boundary_reducer",
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one exact-predicate acquisition boundary reducer",
        "anchor_semantics_unchanged_from_v3_20": True,
        "compact_embedded_response_only_runtime_required": True,
        "all_selected_predictions_exact_copies": True,
        "factorized_specialist_panel": factorized,
    }


def validate_and_write_agent_judge_luna_gaia_v3_68_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return shared._write_audit(
        validate_agent_judge_luna_gaia_v3_68_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


def build_agent_judge_luna_gaia_v3_68_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_reducer_file_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
    )


validate_and_write_agent_judge_luna_gaia_v3_37_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_68_audit
)
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_luna_gaia_v3_68_task
build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_68_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_68_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_68_audit
)

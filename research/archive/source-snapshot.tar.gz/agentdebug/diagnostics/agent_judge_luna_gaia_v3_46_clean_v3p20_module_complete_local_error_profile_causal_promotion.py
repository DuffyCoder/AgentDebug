"""Luna GAIA v3.46: clean v3.20 plus local profiles and causal promotion."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions
from .taxonomy import AgentModule, ErrorType, is_valid_classification, taxonomy_prompt


AGENT_JUDGE_LUNA_GAIA_V3_46_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.46-clean-v3.20-"
    "module-complete-local-error-profile-causal-promotion"
)
AGENT_JUDGE_LUNA_GAIA_V3_46_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_46_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_46_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases used by the shared full-GAIA runner.
AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_46_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_46_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_46_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_46_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_46_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_46_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_46_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
LOCAL_PROFILE_FILENAME = "local-error-profile.json"
LOCAL_PROFILE_AUDIT_FILENAME = "local-error-profile-audit.json"
PROFILE_BUNDLE_FILENAME = "module-complete-local-error-profile.json"
PROFILE_BUNDLES_FILENAME = "module-complete-local-error-profiles.json"
PROMOTION_FILENAME = "causal-promotion.json"
PROMOTIONS_FILENAME = "causal-promotions.json"
PROMOTION_AUDIT_FILENAME = "causal-promotion-audit.json"

# Compatibility aliases for the generic factorized runner.
PANEL_FILENAME = PROFILE_BUNDLE_FILENAME
PANELS_FILENAME = PROFILE_BUNDLES_FILENAME
SELECTOR_FILENAME = PROMOTION_FILENAME
SELECTORS_FILENAME = PROMOTIONS_FILENAME
SELECTOR_AUDIT_FILENAME = PROMOTION_AUDIT_FILENAME

PROFILE_MODULES = tuple(module.value for module in AgentModule)
PROFILE_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "profile_module",
    "reviewed_steps",
    "local_errors",
    "profile_summary",
)
LOCAL_ERROR_FIELDS = (
    "step",
    "module",
    "error_type",
    "evidence_quote",
    "adjacent_fact_step",
    "adjacent_fact_quote",
    "recovery_status",
    "recovery_step",
    "recovery_quote",
    "local_reasoning",
)
RECOVERY_STATUSES = frozenset({"unrecovered", "recovered", "uncertain"})
PROFILE_WRAPPER_FIELDS = ("profile_module", "profile_sha256", "profile")
POSITIVE_ERROR_FIELDS = (
    "error_key",
    "profile_module",
    "profile_sha256",
    "local_error",
)
PROFILE_BUNDLE_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "anchor_prediction_sha256",
    "anchor_prediction",
    "profile_count",
    "profile_set_sha256",
    "profiles",
    "positive_error_count",
    "positive_errors",
)
PROMOTION_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "profile_bundle_sha256",
    "anchor_step",
    "positive_error_count",
    "compared_error_keys",
    "decision",
    "anchor_classification",
    "promoted_error_key",
    "anchor_veto_evidence_step",
    "anchor_veto_evidence_quote",
    "selected_prediction_sha256",
    "selected_prediction",
    "anchor_only_repair_counterfactual",
    "candidate_only_repair_counterfactual",
    "veto_assessment",
    "timeline_comparison",
    "decision_basis",
    "selection_falsifier",
)
PROMOTION_DECISIONS = frozenset({"keep_anchor", "promote_profile_error"})
KEEP_CLASSIFICATIONS = frozenset({"critical_root", "uncertain"})
OVERRIDE_CLASSIFICATIONS = frozenset(
    {"reasonable_probe", "noncritical_predecessor", "recovered_defect"}
)


_LOCAL_PROFILE_RULES = """\
MODULE-COMPLETE LOCAL ERROR PROFILE — EVIDENCE INVENTORY ONLY

You are one isolated local profiler. Inspect the assigned module at every Step
in the current Canonical Trace. You cannot see an anchor and must not choose,
rank, nominate, or predict a critical Step. A local error is not automatically
a critical error. Record all and only literal local defects owned by the
assigned module, including defects later recovered, with one row at most per
Step. `reviewed_steps` must list every Step in order even when the module is
absent or has no error.

Judge from information observable at that Step, not from the released answer
or hindsight. The owner quote must be literal evidence from that module at the
same Step. Use an adjacent-fact quote only when a concrete observation or
earlier/later Step fact supports the local diagnosis. Mark `recovered` only
when a later literal Step fully retires that defect and quote the recovery;
otherwise use `unrecovered` or `uncertain` and null recovery fields.

Do not label a reasonable information-producing probe, a different evidence
probe, a normal negative tool result, a merely improvable action, faithful
propagation, or a downstream symptom as a local error. System errors require a
well-formed call defeated by an external execution/runtime/model limit; an
ordinary empty or negative result is not a System error.
"""

_PROMOTION_RULES = """\
ANCHOR-PRESERVING CAUSAL PROMOTION — ZERO OR ONE STEP CHANGE

The clean-v3.20 anchor is the incumbent and wins under uncertainty. The five
profiles are a local evidence inventory, not candidates or votes. Compare
every positive_error row. Do not prefer majority, earliest positive, latest
symptom, persistence, or stronger prose. Emit either an exact field-for-field
copy of the anchor or one complete prediction grounded in exactly one profile
row. A proposal may be earlier or later than the anchor.

Promotion requires all of these literal chronology findings:

1. the profile row owns a concrete local defect at its Step/module/type;
2. the row is not an initial/different probe, normal failure, mechanical
   repair, faithful propagation, recovered defect, or downstream symptom;
3. candidate-only repair changes the task-material failure path;
4. the anchor is proven to be a reasonable probe, noncritical predecessor, or
   recovered defect, and anchor-only repair does not avert the proposed
   defect;
5. no other positive row establishes an earlier mature critical boundary
   under the same symmetric repair test.

For promotion, prefix the three certificate fields exactly with
`anchor_only_repair=does_not_avert;`,
`candidate_only_repair=changes_path;`, and `veto=passed;`. For keep_anchor use
`anchor_only_repair=not_proven;`, `candidate_only_repair=not_proven;`, and
`veto=not_passed;`. A keep decision must copy the anchor exactly. Never splice
old predictions or rewrite an anchor that remains selected.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_46_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_46_clean_v3p20_module_complete_local_error_profile_causal_promotion",
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py",
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_46_clean_v3p20_module_complete_local_error_profile_causal_promotion.py",
        )
    )


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_46_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_46_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_46_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": (
            "one module-complete local-error profile with causal promotion"
        ),
    }


def _boundary(
    *, manifest: Path, cohort: Path, reads: Sequence[Path], output: Path
) -> str:
    read_lines = "\n".join(f"- {path}" for path in reads) or "- none"
    return f"""\
IMMUTABLE EXECUTION CONFIGURATION
- model: {AGENT_JUDGE_LUNA_GAIA_V3_46_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_46_REASONING_EFFORT}
- one isolated case; fresh session; no cross-case state or prior predictions
- external LLM/API/network calls: forbidden
- scoring or gold-label access: forbidden

INPUT/OUTPUT BOUNDARY
- prediction manifest: {manifest}
- prediction manifest file sha256: {shared._file_sha256(manifest)}
- cohort manifest: {cohort}
- cohort manifest file sha256: {shared._file_sha256(cohort)}
- permitted frozen stage inputs:
{read_lines}
- write the sole stage artifact only to: {output}

Read only those exact inputs plus
`agentdebug/diagnostics/agent_judge_luna_gaia_v3_46_clean_v3p20_module_complete_local_error_profile_causal_promotion.py`
and `agentdebug/diagnostics/taxonomy.py`. Do not inspect directories or infer
from trajectory/source-model/environment names. Never read labels, metrics,
scored artifacts, promotion files other than the permitted current input,
docs/experiments, old predictions, cached replies, case studies, git history,
or external resources.
"""


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_anchor_task(*paths))


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths), policy="unchanged_v3_20_anchor")


def build_profile_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    profile_module: str,
    profile_path: str | Path,
) -> str:
    if profile_module not in PROFILE_MODULES:
        shared._fail("invalid_local_profile_module", profile_module)
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    output = Path(profile_path).expanduser().resolve()
    shared._assert_safe_path(output, role="local profile output", is_output=True)
    audit = output.parent / LOCAL_PROFILE_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_46_clean_v3p20_module_complete_local_error_profile_causal_promotion",
            "--compact-validate",
            "profile",
            profile_module,
            manifest,
            cohort,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    local_error_schema = {
        "step": "owner Step",
        "module": profile_module,
        "error_type": "one taxonomy type valid for the assigned module",
        "evidence_quote": "literal same-Step owner quote",
        "adjacent_fact_step": "supporting Step or null",
        "adjacent_fact_quote": "literal supporting quote or null",
        "recovery_status": "unrecovered, recovered, or uncertain",
        "recovery_step": "strictly later recovery Step or null",
        "recovery_quote": "literal recovery quote or null",
        "local_reasoning": "compact local diagnosis without critical-Step selection",
    }
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "profile_module": profile_module,
        "reviewed_steps": list(range(1, len(case.judge_view.steps) + 1)),
        "local_errors": [local_error_schema],
        "profile_summary": "coverage and local-error summary; no ranking or prediction",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_46_VERSION} local profile for `{profile_module}`.

{_boundary(manifest=manifest, cohort=cohort, reads=(), output=output)}

{_LOCAL_PROFILE_RULES}

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

`local_errors` may be empty. Sort it by Step and use at most one row per Step.
After writing, run:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _validate_optional_quote_pair(
    *, case: Any, step: Any, quote: Any, location: str
) -> None:
    if step is None and quote is None:
        return
    if isinstance(step, bool) or not isinstance(step, int):
        shared._fail("invalid_local_profile_fact_step", location)
    if step < 1 or step > len(case.judge_view.steps):
        shared._fail("invalid_local_profile_fact_step", location)
    shared._nonempty_text(quote, location=f"{location}.quote", maximum=2400)
    if not any(quote in source for source in shared._packet_sources(case, step)):
        shared._fail("invalid_local_profile_fact_quote", location)


def _validate_local_error(
    raw: Any, *, case: Any, profile_module: str, location: str
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != LOCAL_ERROR_FIELDS:
        shared._fail("invalid_local_profile_error_schema", location)
    step = raw["step"]
    if (
        isinstance(step, bool)
        or not isinstance(step, int)
        or step < 1
        or step > len(case.judge_view.steps)
    ):
        shared._fail("invalid_local_profile_error_step", location)
    if raw["module"] != profile_module:
        shared._fail("local_profile_module_binding_mismatch", location)
    try:
        module = AgentModule(raw["module"])
        error_type = ErrorType(raw["error_type"])
    except ValueError:
        shared._fail("invalid_local_profile_taxonomy", location)
    if not is_valid_classification(module, error_type):
        shared._fail("invalid_local_profile_taxonomy", location)
    shared._nonempty_text(raw["evidence_quote"], location=f"{location}.evidence_quote", maximum=2400)
    owner_sources = shared._luna_gaia_v2_owner_source_resolver(
        case.judge_view, step, module, error_type
    )
    if not owner_sources or not any(raw["evidence_quote"] in source for source in owner_sources):
        shared._fail("invalid_local_profile_owner_evidence", location)
    _validate_optional_quote_pair(
        case=case,
        step=raw["adjacent_fact_step"],
        quote=raw["adjacent_fact_quote"],
        location=f"{location}.adjacent_fact",
    )
    recovery = raw["recovery_status"]
    if recovery not in RECOVERY_STATUSES:
        shared._fail("invalid_local_profile_recovery_status", location)
    if recovery == "recovered":
        recovery_step = raw["recovery_step"]
        if isinstance(recovery_step, bool) or not isinstance(recovery_step, int) or recovery_step <= step:
            shared._fail("invalid_local_profile_recovery_step", location)
        _validate_optional_quote_pair(
            case=case,
            step=recovery_step,
            quote=raw["recovery_quote"],
            location=f"{location}.recovery",
        )
    elif raw["recovery_step"] is not None or raw["recovery_quote"] is not None:
        shared._fail("inactive_local_profile_recovery_fields", location)
    shared._nonempty_text(raw["local_reasoning"], location=f"{location}.local_reasoning", maximum=3000)
    return raw


def _validate_profile_record(
    raw: Any, *, case: Any, profile_module: str, location: str
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != PROFILE_FIELDS:
        shared._fail("invalid_local_profile_schema", location)
    if raw["trajectory_id"] != case.trajectory_id or raw["trajectory_sha256"] != case.trajectory_sha256:
        shared._fail("local_profile_identity_mismatch", location)
    if raw["profile_module"] != profile_module:
        shared._fail("local_profile_assignment_mismatch", location)
    expected_steps = list(range(1, len(case.judge_view.steps) + 1))
    if raw["reviewed_steps"] != expected_steps:
        shared._fail("incomplete_local_profile_step_coverage", location)
    errors = raw["local_errors"]
    if not isinstance(errors, list):
        shared._fail("invalid_local_profile_errors", location)
    observed_steps: list[int] = []
    for index, error in enumerate(errors):
        validated = _validate_local_error(
            error,
            case=case,
            profile_module=profile_module,
            location=f"{location}.local_errors[{index}]",
        )
        observed_steps.append(validated["step"])
    if observed_steps != sorted(set(observed_steps)):
        shared._fail("unsorted_or_duplicate_local_profile_errors", location)
    shared._nonempty_text(raw["profile_summary"], location=f"{location}.profile_summary", maximum=3000)
    return raw


def validate_profile(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    profile_module: str,
    profile_path: str | Path,
) -> dict[str, Any]:
    _, _, case = shared._single_case_paths(prediction_manifest_path, cohort_manifest_path)
    profile_file, raw = shared._load_artifact(profile_path, role="local error profile")
    profile = shared._one_record(raw, role="local error profile")
    _validate_profile_record(
        profile, case=case, profile_module=profile_module, location="profile[0]"
    )
    return _retag(
        {
            "schema_version": "agentdebug.module-local-error-profile-audit.v1",
            "stage": "anchor_blind_local_profile",
            "gold_free_validation": True,
            "case_count": 1,
            "profile_module": profile_module,
            "complete_step_coverage": True,
            "local_error_count": len(profile["local_errors"]),
            "makes_critical_step_prediction": False,
            "anchor_visible": False,
            "input_sha256": {},
            "output_sha256": {LOCAL_PROFILE_FILENAME: shared._file_sha256(profile_file)},
        },
        policy="anchor_blind_module_local_evidence_inventory",
    )


def _error_key(profile_module: str, row: dict[str, Any]) -> str:
    return f"{profile_module}:S{row['step']}:{row['error_type']}"


def _flatten_positive_errors(wrappers: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for wrapper in wrappers:
        for row in wrapper["profile"]["local_errors"]:
            result.append(
                {
                    "error_key": _error_key(wrapper["profile_module"], row),
                    "profile_module": wrapper["profile_module"],
                    "profile_sha256": wrapper["profile_sha256"],
                    "local_error": row,
                }
            )
    return result


def build_profile_bundle(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    profile_paths: Sequence[str | Path],
    bundle_path: str | Path,
) -> dict[str, Any]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    anchor, _, _ = shared._validate_anchor_bundle(
        manifest,
        cohort,
        Path(anchor_path).expanduser().resolve(),
        Path(ledger_path).expanduser().resolve(),
        Path(checkpoint_path).expanduser().resolve(),
    )
    parent._validate_packet_state_ledgers(Path(ledger_path).expanduser().resolve())
    if len(profile_paths) != len(PROFILE_MODULES):
        shared._fail("invalid_module_profile_count", str(len(profile_paths)))
    wrappers: list[dict[str, Any]] = []
    for profile_module, value in zip(PROFILE_MODULES, profile_paths, strict=True):
        _, raw = shared._load_artifact(value, role=f"{profile_module} local profile")
        profile = shared._one_record(raw, role=f"{profile_module} local profile")
        _validate_profile_record(
            profile,
            case=case,
            profile_module=profile_module,
            location=f"profiles.{profile_module}",
        )
        wrappers.append(
            {
                "profile_module": profile_module,
                "profile_sha256": shared._stable_sha256(profile),
                "profile": profile,
            }
        )
    positives = _flatten_positive_errors(wrappers)
    bundle = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_prediction": anchor,
        "profile_count": len(wrappers),
        "profile_set_sha256": shared._stable_sha256(
            [wrapper["profile_sha256"] for wrapper in wrappers]
        ),
        "profiles": wrappers,
        "positive_error_count": len(positives),
        "positive_errors": positives,
    }
    _validate_profile_bundle_record(bundle, case=case, location="profile_bundle[0]")
    output = Path(bundle_path).expanduser().resolve()
    shared._assert_safe_path(output, role="profile bundle output", is_output=True)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps([bundle], ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return bundle


def _validate_profile_bundle_record(raw: Any, *, case: Any, location: str) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != PROFILE_BUNDLE_FIELDS:
        shared._fail("invalid_module_profile_bundle_schema", location)
    if raw["trajectory_id"] != case.trajectory_id or raw["trajectory_sha256"] != case.trajectory_sha256:
        shared._fail("module_profile_bundle_identity_mismatch", location)
    anchor = shared._validate_prediction_record(raw["anchor_prediction"], case=case, location=f"{location}.anchor")
    if raw["anchor_prediction_sha256"] != shared._stable_sha256(anchor):
        shared._fail("module_profile_bundle_anchor_hash_mismatch", location)
    wrappers = raw["profiles"]
    if raw["profile_count"] != len(PROFILE_MODULES) or not isinstance(wrappers, list) or len(wrappers) != len(PROFILE_MODULES):
        shared._fail("invalid_module_profile_bundle_count", location)
    hashes: list[str] = []
    for index, (profile_module, wrapper) in enumerate(zip(PROFILE_MODULES, wrappers, strict=True)):
        item_location = f"{location}.profiles[{index}]"
        if not isinstance(wrapper, dict) or tuple(wrapper) != PROFILE_WRAPPER_FIELDS:
            shared._fail("invalid_module_profile_wrapper_schema", item_location)
        if wrapper["profile_module"] != profile_module:
            shared._fail("module_profile_wrapper_order_mismatch", item_location)
        profile = _validate_profile_record(
            wrapper["profile"],
            case=case,
            profile_module=profile_module,
            location=f"{item_location}.profile",
        )
        if wrapper["profile_sha256"] != shared._stable_sha256(profile):
            shared._fail("module_profile_wrapper_hash_mismatch", item_location)
        hashes.append(wrapper["profile_sha256"])
    if raw["profile_set_sha256"] != shared._stable_sha256(hashes):
        shared._fail("module_profile_set_hash_mismatch", location)
    expected = _flatten_positive_errors(wrappers)
    if raw["positive_errors"] != expected or raw["positive_error_count"] != len(expected):
        shared._fail("module_profile_positive_inventory_mismatch", location)
    keys: list[str] = []
    for error in expected:
        if tuple(error) != POSITIVE_ERROR_FIELDS:
            shared._fail("invalid_positive_error_schema", location)
        keys.append(error["error_key"])
    if len(keys) != len(set(keys)):
        shared._fail("duplicate_positive_error_key", location)
    return raw


def build_promotion_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    bundle_path: str | Path,
    promotion_path: str | Path,
) -> str:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    bundle_file, raw = shared._load_artifact(bundle_path, role="module profile bundle")
    bundle = shared._one_record(raw, role="module profile bundle")
    _validate_profile_bundle_record(bundle, case=case, location="profile_bundle[0]")
    output = Path(promotion_path).expanduser().resolve()
    shared._assert_safe_path(output, role="causal promotion output", is_output=True)
    audit = output.parent / PROMOTION_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_46_clean_v3p20_module_complete_local_error_profile_causal_promotion",
            "--compact-validate",
            "promotion",
            manifest,
            cohort,
            bundle_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    prediction_schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        "predicted_step": "selected Step",
        "predicted_module": "selected module",
        "predicted_error_type": "valid taxonomy type",
        "evidence_quote": "literal owner quote; exact profile quote if promoted",
        "root_cause": "specific local root",
        "causal_summary": "counterfactual path effect",
        "rejected_adjacent_owner": "strongest adjacent alternative and why rejected",
    }
    keys = [item["error_key"] for item in bundle["positive_errors"]]
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "profile_bundle_sha256": shared._stable_sha256(bundle),
        "anchor_step": bundle["anchor_prediction"]["predicted_step"],
        "positive_error_count": len(keys),
        "compared_error_keys": keys,
        "decision": "keep_anchor or promote_profile_error",
        "anchor_classification": (
            "critical_root, uncertain, reasonable_probe, "
            "noncritical_predecessor, or recovered_defect"
        ),
        "promoted_error_key": "one exact compared key or null",
        "anchor_veto_evidence_step": "literal anchor-veto/recovery Step or null",
        "anchor_veto_evidence_quote": "literal quote or null",
        "selected_prediction_sha256": "stable hash of selected_prediction",
        "selected_prediction": prediction_schema,
        "anchor_only_repair_counterfactual": "required prefixed certificate",
        "candidate_only_repair_counterfactual": "required prefixed certificate",
        "veto_assessment": "required prefixed veto comparison",
        "timeline_comparison": "anchor, every profile row, and earliest mature boundary",
        "decision_basis": "default-keep threshold decision",
        "selection_falsifier": "strongest concrete argument against this decision",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_46_VERSION} causal promotion.

{_boundary(manifest=manifest, cohort=cohort, reads=(bundle_file,), output=output)}

{_PROMOTION_RULES}

The anchor Step is {bundle['anchor_prediction']['predicted_step']}. There are
{len(keys)} positive profile rows. `compared_error_keys` must exact-copy this
ordered list from the bundle, including when empty. For keep_anchor, set
promoted_error_key and both anchor_veto_evidence fields to null. For promotion,
the selected Step/module/type/evidence_quote must exactly match the promoted
profile row and the Step must differ from the anchor.

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

Compute selected_prediction_sha256 from sorted compact UTF-8 JSON. After
writing, run:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def normalize_inactive_promotion_fields(promotion_path: str | Path) -> bool:
    """Mechanically null conditionally inactive keep fields before freezing."""

    path = Path(promotion_path).expanduser().resolve()
    raw = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, list) or len(raw) != 1 or not isinstance(raw[0], dict):
        return False
    row = raw[0]
    if row.get("decision") != "keep_anchor":
        return False
    changed = False
    for field in (
        "promoted_error_key",
        "anchor_veto_evidence_step",
        "anchor_veto_evidence_quote",
    ):
        if row.get(field) is not None:
            row[field] = None
            changed = True
    if changed:
        path.write_text(json.dumps(raw, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return changed


def _validate_promotion_record(
    raw: Any, *, case: Any, bundle: dict[str, Any], location: str
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != PROMOTION_FIELDS:
        shared._fail("invalid_causal_promotion_schema", location)
    if raw["trajectory_id"] != case.trajectory_id or raw["trajectory_sha256"] != case.trajectory_sha256:
        shared._fail("causal_promotion_identity_mismatch", location)
    if raw["profile_bundle_sha256"] != shared._stable_sha256(bundle):
        shared._fail("causal_promotion_bundle_hash_mismatch", location)
    anchor = bundle["anchor_prediction"]
    positives = bundle["positive_errors"]
    keys = [item["error_key"] for item in positives]
    if (
        raw["anchor_step"] != anchor["predicted_step"]
        or raw["positive_error_count"] != len(keys)
        or raw["compared_error_keys"] != keys
    ):
        shared._fail("causal_promotion_coverage_mismatch", location)
    if raw["decision"] not in PROMOTION_DECISIONS:
        shared._fail("invalid_causal_promotion_decision", location)
    selected = shared._validate_prediction_record(
        raw["selected_prediction"], case=case, location=f"{location}.selected"
    )
    if raw["selected_prediction_sha256"] != shared._stable_sha256(selected):
        shared._fail("causal_promotion_selected_hash_mismatch", location)
    for field in (
        "anchor_only_repair_counterfactual",
        "candidate_only_repair_counterfactual",
        "veto_assessment",
        "timeline_comparison",
        "decision_basis",
        "selection_falsifier",
    ):
        shared._nonempty_text(raw[field], location=f"{location}.{field}", maximum=3500)
    if raw["decision"] == "keep_anchor":
        if raw["anchor_classification"] not in KEEP_CLASSIFICATIONS:
            shared._fail("invalid_keep_anchor_classification", location)
        if any(
            raw[field] is not None
            for field in (
                "promoted_error_key",
                "anchor_veto_evidence_step",
                "anchor_veto_evidence_quote",
            )
        ):
            shared._fail("inactive_keep_anchor_fields_not_null", location)
        if selected != anchor:
            shared._fail("causal_promotion_anchor_copy_mismatch", location)
        expected_prefixes = (
            ("anchor_only_repair_counterfactual", "anchor_only_repair=not_proven;"),
            ("candidate_only_repair_counterfactual", "candidate_only_repair=not_proven;"),
            ("veto_assessment", "veto=not_passed;"),
        )
    else:
        if raw["anchor_classification"] not in OVERRIDE_CLASSIFICATIONS:
            shared._fail("invalid_promotion_anchor_classification", location)
        key = raw["promoted_error_key"]
        if key not in keys:
            shared._fail("promoted_error_absent_from_profile", location)
        promoted = positives[keys.index(key)]["local_error"]
        if (
            selected["predicted_step"] != promoted["step"]
            or selected["predicted_module"] != promoted["module"]
            or selected["predicted_error_type"] != promoted["error_type"]
            or selected["evidence_quote"] != promoted["evidence_quote"]
            or selected["predicted_step"] == anchor["predicted_step"]
        ):
            shared._fail("promoted_prediction_profile_binding_mismatch", location)
        _validate_optional_quote_pair(
            case=case,
            step=raw["anchor_veto_evidence_step"],
            quote=raw["anchor_veto_evidence_quote"],
            location=f"{location}.anchor_veto",
        )
        expected_prefixes = (
            ("anchor_only_repair_counterfactual", "anchor_only_repair=does_not_avert;"),
            ("candidate_only_repair_counterfactual", "candidate_only_repair=changes_path;"),
            ("veto_assessment", "veto=passed;"),
        )
    for field, prefix in expected_prefixes:
        if not raw[field].startswith(prefix):
            shared._fail("missing_causal_promotion_certificate_prefix", f"{location}.{field}")
    return raw


def validate_promotion(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    bundle_path: str | Path,
    promotion_path: str | Path,
) -> dict[str, Any]:
    _, _, case = shared._single_case_paths(prediction_manifest_path, cohort_manifest_path)
    bundle_file, bundle_raw = shared._load_artifact(bundle_path, role="module profile bundle")
    promotion_file, promotion_raw = shared._load_artifact(promotion_path, role="causal promotion")
    bundle = shared._one_record(bundle_raw, role="module profile bundle")
    promotion = shared._one_record(promotion_raw, role="causal promotion")
    _validate_profile_bundle_record(bundle, case=case, location="profile_bundle[0]")
    _validate_promotion_record(promotion, case=case, bundle=bundle, location="promotion[0]")
    return _retag(
        {
            "schema_version": "agentdebug.anchor-preserving-causal-promotion-audit.v1",
            "stage": "causal_promotion",
            "gold_free_validation": True,
            "case_count": 1,
            "positive_error_count": bundle["positive_error_count"],
            "all_positive_errors_compared": True,
            "decision": promotion["decision"],
            "default_anchor_policy": True,
            "maximum_promotions": 1,
            "input_sha256": {PROFILE_BUNDLE_FILENAME: shared._file_sha256(bundle_file)},
            "output_sha256": {PROMOTION_FILENAME: shared._file_sha256(promotion_file)},
        },
        policy="module_profile_anchor_preserving_causal_promotion",
    )


def _validate_aggregate(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(prediction_manifest_path, cohort_manifest_path)
    root = Path(predictions_path).expanduser().resolve().parent
    names = (
        ANCHOR_PREDICTIONS_FILENAME,
        ANCHOR_LEDGER_AGGREGATE_FILENAME,
        ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        PROFILE_BUNDLES_FILENAME,
        PROMOTIONS_FILENAME,
    )
    loaded = {
        name: shared._load_artifact(root / name, role=f"merged {name}")[1]
        for name in names
    }
    if any(not isinstance(value, list) or len(value) != len(cases) for value in loaded.values()):
        shared._fail("invalid_local_profile_aggregate_count", "all artifacts need all cases")
    finals = shared._load_artifact(predictions_path, role="merged predictions")[1]
    if not isinstance(finals, list) or len(finals) != len(cases):
        shared._fail("invalid_local_profile_prediction_count", "predictions need all cases")
    decision_counts: Counter[str] = Counter()
    positive_counts: Counter[int] = Counter()
    exact_anchor_copy_count = 0
    for index, case in enumerate(cases):
        location = f"local_profile_merged[{index}]"
        anchor = loaded[ANCHOR_PREDICTIONS_FILENAME][index]
        ledger = loaded[ANCHOR_LEDGER_AGGREGATE_FILENAME][index]
        checkpoint = loaded[ANCHOR_CHECKPOINT_AGGREGATE_FILENAME][index]
        bundle = loaded[PROFILE_BUNDLES_FILENAME][index]
        promotion = loaded[PROMOTIONS_FILENAME][index]
        shared._validate_prediction_record(anchor, case=case, location=f"{location}.anchor")
        if (
            ledger.get("trajectory_id") != case.trajectory_id
            or ledger.get("selected_step") != anchor["predicted_step"]
            or checkpoint.get("trajectory_id") != case.trajectory_id
            or checkpoint.get("predicted_step") != anchor["predicted_step"]
        ):
            shared._fail("local_profile_anchor_sidecar_mismatch", location)
        _validate_profile_bundle_record(bundle, case=case, location=f"{location}.bundle")
        if bundle["anchor_prediction"] != anchor:
            shared._fail("local_profile_bundle_anchor_mismatch", location)
        _validate_promotion_record(promotion, case=case, bundle=bundle, location=f"{location}.promotion")
        final = shared._validate_prediction_record(finals[index], case=case, location=f"{location}.final")
        if final != promotion["selected_prediction"]:
            shared._fail("local_profile_final_prediction_mismatch", location)
        decision_counts[promotion["decision"]] += 1
        positive_counts[bundle["positive_error_count"]] += 1
        exact_anchor_copy_count += final == anchor
    return {
        "required": True,
        "valid": True,
        "anchor_blind_panel": True,
        "profile_modules": list(PROFILE_MODULES),
        "complete_module_and_step_coverage": True,
        "profiles_are_evidence_inventory_not_votes": True,
        "maximum_specialist_candidates": 1,
        "maximum_promotions": 1,
        "default_anchor_policy": True,
        "all_positive_errors_compared": True,
        "all_selected_predictions_exact_copies": exact_anchor_copy_count == len(cases),
        "all_selected_predictions_exact_anchor_or_profile_grounded": True,
        "exact_anchor_copy_count": exact_anchor_copy_count,
        "profile_positive_count_distribution": dict(sorted(positive_counts.items())),
        "promotion_decision_counts": dict(sorted(decision_counts.items())),
        "packet_state_closure": parent._validate_packet_state_ledgers(
            root / ANCHOR_LEDGER_AGGREGATE_FILENAME
        ),
    }


def validate_agent_judge_luna_gaia_v3_46_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    profiles = _validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_46_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_46_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_46_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_46_REASONING_EFFORT,
        "selection_policy": "clean_v3_20_module_complete_local_profile_causal_promotion",
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": "one module-complete local-error profile with causal promotion",
        "anchor_semantics_unchanged_from_v3_20": True,
        "factorized_specialist_panel": profiles,
    }


def build_agent_judge_luna_gaia_v3_46_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_promotion_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / PROFILE_BUNDLE_FILENAME,
        prediction.parent / PROMOTION_FILENAME,
    )


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_profile_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_profile(*paths[:-1]), paths[-1])


def validate_and_write_promotion_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_promotion(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_46_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_46_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


validate_and_write_selector_audit = validate_and_write_promotion_audit
validate_and_write_agent_judge_luna_gaia_v3_37_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_46_audit
)
build_agent_judge_luna_gaia_v3_37_task = build_agent_judge_luna_gaia_v3_46_task


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "profile" and len(paths) == 5:
            profile_module, manifest, cohort, profile, audit_path = paths
            audit = validate_and_write_profile_audit(
                manifest, cohort, profile_module, profile, audit_path
            )
        elif stage == "promotion" and len(paths) == 5:
            normalize_inactive_promotion_fields(paths[3])
            audit = validate_and_write_promotion_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_46_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except (shared.AgentJudgeValidationError, json.JSONDecodeError, OSError) as error:
        code = getattr(error, "code", type(error).__name__)
        print(json.dumps({"ok": False, "code": code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "profile", "promotion", "prediction"))
    parser.add_argument("paths", nargs="+")
    args = parser.parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

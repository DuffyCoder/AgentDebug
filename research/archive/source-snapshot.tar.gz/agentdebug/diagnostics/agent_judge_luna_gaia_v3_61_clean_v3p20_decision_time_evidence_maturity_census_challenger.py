"""Luna GAIA v3.61: decision-time evidence-maturity census challenger."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger as transport
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent


AGENT_JUDGE_LUNA_GAIA_V3_61_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.61-clean-v3.20-"
    "decision-time-evidence-maturity-census-challenger"
)
AGENT_JUDGE_LUNA_GAIA_V3_61_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_61_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_61_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility aliases used by the shared three-stage runner.
AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_61_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_61_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_61_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_13_AUDIT_SCHEMA_VERSION = (
    AGENT_JUDGE_LUNA_GAIA_V3_61_AUDIT_SCHEMA_VERSION
)

ANCHOR_PREDICTIONS_FILENAME = transport.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = transport.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = transport.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
CHALLENGER_FILENAME = transport.CHALLENGER_FILENAME
CHALLENGERS_FILENAME = transport.CHALLENGERS_FILENAME
ARBITER_FILENAME = transport.ARBITER_FILENAME
ARBITERS_FILENAME = transport.ARBITERS_FILENAME
CHALLENGER_AUDIT_FILENAME = transport.CHALLENGER_AUDIT_FILENAME
ARBITER_AUDIT_FILENAME = transport.ARBITER_AUDIT_FILENAME
PREDICTION_AUDIT_FILENAME = transport.PREDICTION_AUDIT_FILENAME


_CENSUS_PREFIX = re.compile(
    r"^maturity_census=([^;]+); "
    r"decision_boundary_step=(none|[1-9]\d*); "
    r"boundary_direction=(none|earlier|same|later); "
)
_CENSUS_ENTRY = re.compile(r"^([1-9]\d*):([a-z_]+)$")
_CENSUS_VERDICTS = frozenset(
    {
        "clear",
        "justified_probe",
        "ordinary_observation",
        "recovered_or_mechanical",
        "faithful_propagation",
        "locally_improvable",
        "decision_boundary",
    }
)


_COMPLETE_STEP_CENSUS_RULES = """\
DECISION-TIME EVIDENCE-MATURITY CENSUS — ONE BOUNDARY MAXIMUM

The frozen v3.20 packet-state prediction is the incumbent anchor. Do not edit
or re-run it. Before classifying that anchor, inspect every Canonical Step
exactly once in chronological order, including Steps before, at, and after the
anchor. Do not stop when the anchor first looks plausible.

PHASE 1 — EXACT COMPLETE TIMELINE CENSUS

Assign exactly one closed verdict to every Step:

- `clear`: no task-material defect is observable at this Step.
- `justified_probe`: an initial or materially different acquisition decision
  can expose any necessary intermediate, identifier, page, source, text, or
  lead. It need not prove the final answer predicate itself.
- `ordinary_observation`: the Agent decision was reasonable and only the
  tool/site outcome failed or supplied useful negative evidence. An external
  failure message alone is not an Agent boundary.
- `recovered_or_mechanical`: the defect is fully repaired or is only a narrow
  mechanical predecessor to a later state or strategy decision.
- `faithful_propagation`: the Step carries an unresolved earlier condition
  forward without making a new unjustified decision.
- `locally_improvable`: a real local weakness is not material enough to own the
  benchmark boundary.
- `decision_boundary`: this is the single chronologically earliest
  task-material Agent decision that was no longer justified by the information
  visible by this Step and whose local repair can change the failed path.

Freeze at most one `decision_boundary`. Test justification at the time of the
Step, not with hindsight that every unsuccessful probe was wrong. A boundary
requires literal same-Step owner evidence, a concrete decision or state claim,
an unresolved task condition affected by it, and a Step-only repair that can
change the subsequent failed path.

The following boundaries can be mature immediately without prior failure:

1. a literal task constraint is ignored;
2. the visible interface or Action contract already proves that the selected
   route cannot expose even a necessary intermediate for the immediate subgoal;
3. parameters are malformed, rejected, or observably misparsed;
4. Memory or Reflection loses a necessary fact, invents a retained fact, or
   makes an outcome/progress claim contradicted by visible feedback;
5. a terminal answer commits an unsupported result.

For acquisition and strategy choices, protect a first or materially different
probe when it can produce a useful intermediate. After literal prior feedback
shows zero contribution, an unavailable assumption, rejected parameters, a
violated constraint, or a false state/progress claim, a plan or Action that
recommits without a material target, corpus, interface, extraction, or evidence
dimension can be the first decision boundary.

Do not promote ordinary tool/site failure, useful negative evidence, a genuine
route change, full recovery, mechanical repair, faithful propagation, or a
later symptom. Successful execution vetoes a parameter-format error unless
literal feedback rejects or misparses the field. Do not choose a Step merely
because its wording is severe, it is late, or it is easiest to quote.

Candidate generation is chronological and time-local. A later boundary DOES
NOT need to remain independently failure-causing after hypothetical repair of
an earlier justified probe. That counterfactual is overstrong: the benchmark
boundary may be the first decision that becomes unjustified only after the
earlier probes supply their actual feedback.

Begin search_summary exactly with every Step/verdict pair in order:

`maturity_census=1:<verdict>,2:<verdict>,...; decision_boundary_step=<none|Step>; boundary_direction=<none|earlier|same|later>; `

The certificate must contain every observable Step exactly once. Exactly one
row must be `decision_boundary` when decision_boundary_step is a Step; zero
rows must use it when the boundary is none. Direction is relative to the frozen
anchor.

PHASE 2 — COMPARE THE DECISION BOUNDARY WITH THE ANCHOR

- If no boundary exists, emit no_challenge.
- If the boundary equals the anchor, emit no_challenge because the anchor
  already owns it.
- If the boundary differs, challenge only when the anchor's census verdict is
  `justified_probe`, `recovered_or_mechanical`, `faithful_propagation`, or
  `locally_improvable`, and the proposed Step is the first `decision_boundary`.
- Do not require a later boundary to survive fictional anchor-only repair. Use
  the real evidence sequence and ask when the Agent's decision first ceased to
  be justified.
- If uncertainty remains or the anchor is also a material decision boundary,
  preserve the anchor.

A challenge proposal must exactly use decision_boundary_step and literal
evidence owned by that Step. Emit at most one proposal. Use the existing repair
and timeline fields to explain the real chronological relation; do not invent a
candidate pool, case rule, third prediction, or score. When uncertain,
no_challenge.
"""


def _rewrite_identity(task: str) -> str:
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_61_VERSION,
        )
        .replace(
            transport.AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_61_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            "agent_judge_luna_gaia_v3_61_clean_v3p20_decision_time_evidence_maturity_census_challenger",
        )
        .replace(
            "agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger",
            "agent_judge_luna_gaia_v3_61_clean_v3p20_decision_time_evidence_maturity_census_challenger",
        )
    )


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_anchor_task(*paths))


def build_challenger_task(*paths: str | Path) -> str:
    task = transport.build_challenger_task(*paths)
    if task.count(transport._BOUNDED_BIDIRECTIONAL_RULES) != 1:
        raise RuntimeError("bounded challenger rule marker changed unexpectedly")
    task = task.replace(
        transport._BOUNDED_BIDIRECTIONAL_RULES,
        _COMPLETE_STEP_CENSUS_RULES,
        1,
    )
    task = task.replace(
        '"which direction was searched and why one proposal exists or none qualifies"',
        '"maturity_census=1:clear,...; decision_boundary_step=none; '
        'boundary_direction=none; literal decision-time comparison"',
    )
    return _rewrite_identity(task)


def _validate_census_records(path: str | Path, cases: Sequence[Any]) -> dict[str, Any]:
    challenger_path, raw = shared._load_artifact(
        path, role="decision-time evidence-maturity census"
    )
    records = raw if isinstance(raw, list) else [raw]
    if len(records) != len(cases) or any(not isinstance(item, dict) for item in records):
        shared._fail("invalid_maturity_census_record_count", "case/record count differs")

    verdict_counts: Counter[str] = Counter()
    direction_counts: Counter[str] = Counter()
    candidate_count = 0
    challenge_count = 0
    for index, (record, case) in enumerate(zip(records, cases, strict=True)):
        location = f"maturity_census[{index}]"
        match = _CENSUS_PREFIX.match(str(record.get("search_summary") or ""))
        if match is None:
            shared._fail("missing_evidence_maturity_census_prefix", location)
        census_text, candidate_text, direction = match.groups()
        entries: list[tuple[int, str]] = []
        for entry_text in census_text.split(","):
            entry_match = _CENSUS_ENTRY.match(entry_text)
            if entry_match is None:
                shared._fail("invalid_maturity_census_entry", f"{location}:{entry_text}")
            step_text, verdict = entry_match.groups()
            if verdict not in _CENSUS_VERDICTS:
                shared._fail("invalid_maturity_census_verdict", f"{location}:{verdict}")
            entries.append((int(step_text), verdict))
            verdict_counts[verdict] += 1
        expected_steps = [step.step for step in case.judge_view.steps]
        if [step for step, _ in entries] != expected_steps:
            shared._fail("maturity_census_step_list_mismatch", location)

        critical_steps = [step for step, verdict in entries if verdict == "decision_boundary"]
        candidate_step = None if candidate_text == "none" else int(candidate_text)
        if candidate_step is None:
            if critical_steps or direction != "none":
                shared._fail("invalid_empty_decision_boundary", location)
        else:
            if critical_steps != [candidate_step]:
                shared._fail("decision_boundary_binding_mismatch", location)
            anchor_step = record.get("anchor_step")
            expected_direction = (
                "earlier"
                if candidate_step < anchor_step
                else "later"
                if candidate_step > anchor_step
                else "same"
            )
            if direction != expected_direction:
                shared._fail("decision_boundary_direction_mismatch", location)
            candidate_count += 1

        if record.get("challenge_status") == "challenge":
            proposal = record.get("proposed_prediction")
            if (
                candidate_step is None
                or direction not in {"earlier", "later"}
                or not isinstance(proposal, dict)
                or proposal.get("predicted_step") != candidate_step
            ):
                shared._fail("proposal_differs_from_decision_boundary", location)
            challenge_count += 1
        direction_counts[direction] += 1
    return {
        "required": True,
        "valid": True,
        "path": str(challenger_path),
        "record_count": len(records),
        "exact_complete_step_enumeration": True,
        "time_local_justification_required": True,
        "anchor_repair_independence_required": False,
        "one_boundary_maximum": True,
        "boundary_count": candidate_count,
        "challenge_count": challenge_count,
        "verdict_counts": dict(sorted(verdict_counts.items())),
        "direction_counts": dict(sorted(direction_counts.items())),
    }


def _retag(audit: dict[str, Any]) -> dict[str, Any]:
    result = dict(audit)
    result["agent_judge_version"] = AGENT_JUDGE_LUNA_GAIA_V3_61_VERSION
    result["model"] = AGENT_JUDGE_LUNA_GAIA_V3_61_MODEL
    result["reasoning_effort"] = AGENT_JUDGE_LUNA_GAIA_V3_61_REASONING_EFFORT
    return result


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths))


def validate_challenger(*paths: str | Path) -> dict[str, Any]:
    audit = _retag(transport.validate_challenger(*paths))
    _, _, case = shared._single_case_paths(paths[0], paths[1])
    audit["schema_version"] = "agentdebug.decision-time-maturity-census-challenger-audit.v1"
    audit["decision_time_maturity_census"] = _validate_census_records(paths[5], [case])
    return audit


def validate_arbiter(*paths: str | Path) -> dict[str, Any]:
    audit = _retag(transport.validate_arbiter(*paths))
    _, _, case = shared._single_case_paths(paths[0], paths[1])
    audit["schema_version"] = "agentdebug.decision-time-maturity-census-arbiter-audit.v1"
    audit["decision_time_maturity_census"] = _validate_census_records(paths[5], [case])
    return audit


def build_arbiter_task(*paths: str | Path) -> str:
    validate_challenger(*paths[:6])
    task = transport.build_arbiter_task(*paths)
    if task.count(transport._BOUNDED_BIDIRECTIONAL_RULES) != 1:
        raise RuntimeError("bounded arbiter rule marker changed unexpectedly")
    task = task.replace(
        transport._BOUNDED_BIDIRECTIONAL_RULES,
        _COMPLETE_STEP_CENSUS_RULES,
        1,
    )
    return _rewrite_identity(task)


def build_agent_judge_luna_gaia_v3_61_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_arbiter_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / CHALLENGER_FILENAME,
        prediction.parent / ARBITER_FILENAME,
    )


def validate_agent_judge_luna_gaia_v3_61_predictions(
    *paths: str | Path,
) -> dict[str, Any]:
    audit = _retag(transport.validate_agent_judge_luna_gaia_v3_16_predictions(*paths))
    _, _, cases = shared._load_cases(paths[0], paths[1])
    predictions = Path(paths[2]).expanduser().resolve()
    audit["schema_version"] = AGENT_JUDGE_LUNA_GAIA_V3_61_AUDIT_SCHEMA_VERSION
    audit["selection_policy"] = (
        "clean_v3_20_packet_state_anchor_complete_decision_time_evidence_"
        "maturity_census_one_boundary_challenger_default_keep_exact_copy_arbiter"
    )
    audit["direct_semantic_parent"] = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION
    audit["rejected_lineage_inherited"] = False
    audit["anchor_semantics_unchanged_from_v3_20"] = True
    audit["packet_state_closure"] = parent._validate_packet_state_ledgers(
        predictions.parent / ANCHOR_LEDGER_AGGREGATE_FILENAME
    )
    audit["decision_time_maturity_census"] = _validate_census_records(
        predictions.parent / CHALLENGERS_FILENAME,
        cases,
    )
    return audit


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_challenger_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_challenger(*paths[:-1]), paths[-1])


def validate_and_write_arbiter_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_arbiter(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_61_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_61_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


build_agent_judge_luna_gaia_v3_13_task = build_agent_judge_luna_gaia_v3_61_task
validate_agent_judge_luna_gaia_v3_13_predictions = (
    validate_agent_judge_luna_gaia_v3_61_predictions
)
validate_and_write_agent_judge_luna_gaia_v3_13_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_61_audit
)


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "challenger" and len(paths) == 7:
            audit = validate_and_write_challenger_audit(*paths)
        elif stage == "arbiter" and len(paths) == 8:
            audit = validate_and_write_arbiter_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_61_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except shared.AgentJudgeValidationError as error:
        print(json.dumps({"ok": False, "code": error.code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument("stage", choices=("anchor", "challenger", "arbiter", "prediction"))
    parser.add_argument("paths", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

"""Luna GAIA v3.62: clean-v3.20 full-local Step pairwise reducer."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

from . import agent_judge_luna_gaia_v3_13_conservative_challenger as shared
from . import agent_judge_luna_gaia_v3_20_packet_state_closure as parent
from . import (
    agent_judge_luna_gaia_v3_56_clean_v3p20_step_isolated_class_stratified_anchor_selector_enumerated_contract
    as step_local_transport,
)
from .agent_judge_luna_gaia_v2_1 import validate_agent_judge_luna_gaia_v2_1_predictions
from .taxonomy import taxonomy_prompt


AGENT_JUDGE_LUNA_GAIA_V3_62_VERSION = (
    "agentdebug.codex-agent-judge.luna-gaia.v3.62-clean-v3.20-"
    "full-local-step-pairwise-reducer"
)
AGENT_JUDGE_LUNA_GAIA_V3_62_MODEL = parent.AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_62_REASONING_EFFORT = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT
)
AGENT_JUDGE_LUNA_GAIA_V3_62_AUDIT_SCHEMA_VERSION = (
    parent.AGENT_JUDGE_LUNA_GAIA_V3_20_AUDIT_SCHEMA_VERSION
)

# Compatibility names let the clean v3.62 runner reuse generic v3.56 execution
# transport without inheriting the rejected class selector semantics.
AGENT_JUDGE_LUNA_GAIA_V3_56_VERSION = AGENT_JUDGE_LUNA_GAIA_V3_62_VERSION
AGENT_JUDGE_LUNA_GAIA_V3_56_MODEL = AGENT_JUDGE_LUNA_GAIA_V3_62_MODEL
AGENT_JUDGE_LUNA_GAIA_V3_56_REASONING_EFFORT = (
    AGENT_JUDGE_LUNA_GAIA_V3_62_REASONING_EFFORT
)

ANCHOR_PREDICTIONS_FILENAME = parent.ANCHOR_PREDICTIONS_FILENAME
ANCHOR_LEDGER_AGGREGATE_FILENAME = parent.ANCHOR_LEDGER_AGGREGATE_FILENAME
ANCHOR_CHECKPOINT_AGGREGATE_FILENAME = parent.ANCHOR_CHECKPOINT_AGGREGATE_FILENAME
PREDICTION_AUDIT_FILENAME = parent.PREDICTION_AUDIT_FILENAME
STEP_PROJECTION_FILENAME = step_local_transport.STEP_PROJECTION_FILENAME
STEP_LOCAL_FILENAME = step_local_transport.STEP_LOCAL_FILENAME
STEP_LOCAL_AUDIT_FILENAME = step_local_transport.STEP_LOCAL_AUDIT_FILENAME
STEP_LOCAL_RECORDS_FILENAME = step_local_transport.STEP_LOCAL_RECORDS_FILENAME
LOCAL_MATRIX_FILENAME = step_local_transport.LOCAL_MATRIX_FILENAME
LOCAL_MATRICES_FILENAME = step_local_transport.LOCAL_MATRICES_FILENAME
MODULES = step_local_transport.MODULES
CLASS_SELECTOR_FILENAME = "full-local-step-pairwise-reducer.json"
CLASS_SELECTORS_FILENAME = "full-local-step-pairwise-reducers.json"
CLASS_SELECTOR_AUDIT_FILENAME = "full-local-step-pairwise-reducer-audit.json"

PAIR_RECORD_FIELDS = (
    "trajectory_id",
    "trajectory_sha256",
    "anchor_prediction_sha256",
    "anchor_ledger_sha256",
    "anchor_checkpoint_sha256",
    "local_matrix_sha256",
    "anchor_step",
    "reviewed_positive_steps",
    "positive_step_count",
    "pair_assessments",
    "decision",
    "selected_pair_index",
    "frozen_step",
    "selected_prediction_sha256",
    "selected_prediction",
    "deterministic_reducer_basis",
)
PAIR_ASSESSMENT_FIELDS = (
    "candidate_step",
    "candidate_row_ids",
    "winner",
    "candidate_witness_row_id",
    "selected_row_id",
    "anchor_role",
    "candidate_role",
    "anchor_evidence_quote",
    "anchor_veto_evidence_step",
    "anchor_veto_evidence_quote",
    "candidate_evidence_quote",
    "anchor_only_repair_effect",
    "candidate_only_repair_effect",
    "repair_relation",
    "pair_comparison",
    "pair_falsifier",
)
PAIR_WINNERS = frozenset({"anchor_wins", "candidate_wins"})
PAIR_DECISIONS = frozenset({"keep_anchor", "select_candidate"})
ANCHOR_ROLES = frozenset(
    {
        "critical_boundary",
        "reasonable_probe",
        "normal_tool_failure",
        "recovered_defect",
        "noncritical_predecessor",
        "faithful_propagation",
        "downstream_symptom",
        "uncertain",
    }
)
CANDIDATE_ROLES = frozenset(
    {
        "critical_boundary",
        "reasonable_probe",
        "normal_tool_failure",
        "recovered_defect",
        "faithful_propagation",
        "downstream_symptom",
        "local_only",
        "uncertain",
    }
)
OVERRIDABLE_ANCHOR_ROLES = ANCHOR_ROLES - {"critical_boundary", "uncertain"}
SELECT_RELATION_PREFIX = (
    "anchor_repair_leaves_candidate_failure=yes; "
    "candidate_repair_can_redirect=yes; "
)
KEEP_RELATION_PREFIX = (
    "anchor_repair_leaves_candidate_failure=not_proven; "
    "candidate_repair_can_redirect=not_proven; "
)


_PAIR_RULES = """\
FULL LOCAL-STEP PAIRWISE CRITICAL-BOUNDARY REDUCTION

The clean v3.20 anchor and complete frozen Step-local positive matrix are
immutable. Group positives only by exact Step. Produce one assessment for every
positive Step in chronological order. Each assessment is a separate
anchor-versus-one-Step comparison: do not use another candidate's status,
wording, Module, vote, or salience to decide the current pair.

Use exactly `anchor_wins` or `candidate_wins`. Local positives are evidence
inventory, not critical nominations. `candidate_wins` is legal only when:

1. one frozen row at the candidate Step owns a concrete task-material error;
2. the anchor is specifically a reasonable probe, normal tool failure,
   recovered defect, noncritical predecessor, faithful propagation, or
   downstream symptom in this pair;
3. candidate-only repair can materially redirect the recorded failed path;
4. anchor-only repair leaves the candidate's independent owner defect; and
5. literal anchor-veto and candidate-owner evidence are bound.

A probe is reasonable if it can expose any necessary intermediate fact, page,
identifier, text, source, or lead. A normal empty/negative result, a genuinely
different probe, mechanical repair, fully recovered defect, faithful
propagation, merely improvable behavior, and downstream symptom cannot win.
For a later recommitment, literal prior feedback must have rejected the same
normalized route, assumption, parameter, state, or evidence family. For an
earlier candidate, it must already own the local defect before the later
anchor. Keep the anchor whenever either repair relation or ownership is
uncertain.

There is no shared anchor class and no candidate ranking in model output. After
all pairs validate, a deterministic reducer selects the chronologically
earliest `candidate_wins`; if none wins it exact-copies the anchor. Never select
the first positive, last positive, majority Module, Planning by default,
strongest prose, or a third prediction.

For `candidate_wins`, use the required `yes` repair prefix, set
selected_row_id equal to the candidate witness row, classify the candidate
`critical_boundary`, and classify the anchor with an overrideable role. For
`anchor_wins`, selected_row_id and both veto fields are null and use the exact
`not_proven` repair prefix. Every candidate_evidence_quote must exact-copy the
witness row. Every anchor_evidence_quote must exact-copy the frozen anchor's
evidence quote.
"""


def _rewrite_identity(task: str) -> str:
    current_module = (
        "agent_judge_luna_gaia_v3_62_clean_v3p20_full_local_step_pairwise_reducer"
    )
    current_path = (
        "agentdebug/diagnostics/"
        "agent_judge_luna_gaia_v3_62_clean_v3p20_full_local_step_pairwise_reducer.py"
    )
    return (
        task.replace(
            parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_62_VERSION,
        )
        .replace(
            step_local_transport.AGENT_JUDGE_LUNA_GAIA_V3_56_VERSION,
            AGENT_JUDGE_LUNA_GAIA_V3_62_VERSION,
        )
        .replace(
            "agent_judge_luna_gaia_v3_20_packet_state_closure",
            current_module,
        )
        .replace(
            "agent_judge_luna_gaia_v3_56_clean_v3p20_step_isolated_class_stratified_anchor_selector_enumerated_contract",
            current_module,
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py",
            current_path,
        )
        .replace(
            "agentdebug/diagnostics/agent_judge_luna_gaia_v3_56_clean_v3p20_step_isolated_class_stratified_anchor_selector_enumerated_contract.py",
            current_path,
        )
        .replace(f"- {current_path}", "- agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py")
    )


def _retag(audit: dict[str, Any], *, policy: str) -> dict[str, Any]:
    return {
        **audit,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_62_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_62_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_62_REASONING_EFFORT,
        "selection_policy": policy,
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": (
            "one complete Step-isolated local matrix retained through a full "
            "anchor-versus-positive-Step pair table and deterministic earliest-winner reducer"
        ),
    }


def _boundary(
    *, manifest: Path, cohort: Path, reads: Sequence[Path], output: Path
) -> str:
    read_lines = "\n".join(f"- {path}" for path in reads)
    return f"""\
IMMUTABLE EXECUTION CONFIGURATION
- model: {AGENT_JUDGE_LUNA_GAIA_V3_62_MODEL}
- reasoning_effort: {AGENT_JUDGE_LUNA_GAIA_V3_62_REASONING_EFFORT}
- one isolated case; fresh session; no cross-case state or prior predictions
- external LLM/API/network calls: forbidden
- scoring or gold-label access: forbidden

INPUT/OUTPUT BOUNDARY
- prediction manifest: {manifest}
- prediction manifest file sha256: {shared._file_sha256(manifest)}
- cohort manifest: {cohort}
- cohort manifest file sha256: {shared._file_sha256(cohort)}
- permitted frozen stage inputs:
{read_lines}
- write the sole stage artifact only to: {output}

Read only those exact inputs plus this v3.62 protocol source and
`agentdebug/diagnostics/taxonomy.py`. Do not inspect directories or infer from
trajectory/source-model/environment names. Never read labels, metrics, scored
artifacts, experiment documents, prior outputs, error reports, case studies,
git history, raw trajectory files, or external resources.
"""


def build_anchor_task(*paths: str | Path) -> str:
    return _rewrite_identity(parent.build_anchor_task(*paths))


def validate_anchor_predictions(*paths: str | Path) -> dict[str, Any]:
    return _retag(parent.validate_anchor_predictions(*paths), policy="unchanged_v3_20_anchor")


def build_step_projection_document(case: Any, step_number: int) -> dict[str, Any]:
    return step_local_transport.build_step_projection_document(case, step_number)


def build_step_local_task(projection_path: str | Path, local_path: str | Path) -> str:
    return _rewrite_identity(
        step_local_transport.build_step_local_task(projection_path, local_path)
    ).replace("this v3.56 protocol source", "this v3.62 protocol source")


def validate_step_local(
    projection_path: str | Path, local_path: str | Path
) -> dict[str, Any]:
    return _retag(
        step_local_transport.validate_step_local(projection_path, local_path),
        policy="fresh_step_isolated_paper_local_evidence_only",
    )


def build_local_matrix_document(
    *, case: Any, local_records: Sequence[dict[str, Any]]
) -> dict[str, Any]:
    return step_local_transport.build_local_matrix_document(
        case=case, local_records=local_records
    )


def build_local_record_set_document(
    *, case: Any, local_records: Sequence[dict[str, Any]]
) -> dict[str, Any]:
    return step_local_transport.build_local_record_set_document(
        case=case, local_records=local_records
    )


def validate_local_matrix(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    matrix_path: str | Path,
) -> dict[str, Any]:
    return _retag(
        step_local_transport.validate_local_matrix(
            prediction_manifest_path, cohort_manifest_path, matrix_path
        ),
        policy="deterministic_complete_step_isolated_local_evidence_matrix",
    )


def _step_bundles(matrix: dict[str, Any]) -> list[tuple[int, list[dict[str, Any]]]]:
    grouped: dict[int, list[dict[str, Any]]] = {}
    for row in matrix["positive_rows"]:
        grouped.setdefault(int(row["step"]), []).append(row)
    return [(step, grouped[step]) for step in sorted(grouped)]


def _row_prediction(
    *, case: Any, row: dict[str, Any], assessment: dict[str, Any]
) -> dict[str, Any]:
    return {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "status": "success",
        "predicted_step": row["step"],
        "predicted_module": row["module"],
        "predicted_error_type": row["error_type"],
        "evidence_quote": row["evidence_quote"],
        "root_cause": row["local_reasoning"],
        "causal_summary": assessment["candidate_only_repair_effect"],
        "rejected_adjacent_owner": assessment["pair_comparison"],
    }


def _load_pair_inputs(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    matrix_path: str | Path,
) -> tuple[
    Path,
    Path,
    Any,
    Path,
    Path,
    Path,
    Path,
    dict[str, Any],
    dict[str, Any],
    dict[str, Any],
    dict[str, Any],
]:
    manifest, cohort, case = shared._single_case_paths(
        prediction_manifest_path, cohort_manifest_path
    )
    anchor_file, ledger_file, checkpoint_file, anchor, ledger, checkpoint = (
        step_local_transport._load_anchor_bundle(
            manifest, cohort, anchor_path, ledger_path, checkpoint_path
        )
    )
    matrix_file, matrix_raw = shared._load_artifact(
        matrix_path, role="complete Step-local evidence matrix"
    )
    matrix = step_local_transport._validate_local_matrix_record(
        matrix_raw, case=case, location="local_matrix"
    )
    return (
        manifest,
        cohort,
        case,
        anchor_file,
        ledger_file,
        checkpoint_file,
        matrix_file,
        anchor,
        ledger,
        checkpoint,
        matrix,
    )


def _validate_optional_literal(
    *, case: Any, step: Any, quote: Any, location: str
) -> None:
    step_local_transport._validate_optional_literal(
        case=case, step=step, quote=quote, location=location
    )


def _validate_pair_record(
    raw: Any,
    *,
    case: Any,
    anchor: dict[str, Any],
    ledger: dict[str, Any],
    checkpoint: dict[str, Any],
    matrix: dict[str, Any],
    location: str,
) -> dict[str, Any]:
    if not isinstance(raw, dict) or tuple(raw) != PAIR_RECORD_FIELDS:
        shared._fail("invalid_full_local_pair_record_schema", location)
    expected_identity = (
        raw["trajectory_id"] == case.trajectory_id
        and raw["trajectory_sha256"] == case.trajectory_sha256
        and raw["anchor_prediction_sha256"] == shared._stable_sha256(anchor)
        and raw["anchor_ledger_sha256"] == shared._stable_sha256(ledger)
        and raw["anchor_checkpoint_sha256"] == shared._stable_sha256(checkpoint)
        and raw["local_matrix_sha256"] == shared._stable_sha256(matrix)
        and raw["anchor_step"] == anchor["predicted_step"]
    )
    if not expected_identity:
        shared._fail("full_local_pair_identity_mismatch", location)
    bundles = _step_bundles(matrix)
    expected_steps = [step for step, _ in bundles]
    if (
        raw["reviewed_positive_steps"] != expected_steps
        or raw["positive_step_count"] != len(expected_steps)
        or not isinstance(raw["pair_assessments"], list)
        or len(raw["pair_assessments"]) != len(expected_steps)
    ):
        shared._fail("full_local_pair_coverage_mismatch", location)
    row_index = {row["row_id"]: row for row in matrix["positive_rows"]}
    winners: list[tuple[int, dict[str, Any], dict[str, Any]]] = []
    for index, ((step, rows), assessment) in enumerate(
        zip(bundles, raw["pair_assessments"], strict=True), start=1
    ):
        pair_location = f"{location}.pair_assessments[{index - 1}]"
        if not isinstance(assessment, dict) or tuple(assessment) != PAIR_ASSESSMENT_FIELDS:
            shared._fail("invalid_full_local_pair_assessment_schema", pair_location)
        row_ids = [row["row_id"] for row in rows]
        if assessment["candidate_step"] != step or assessment["candidate_row_ids"] != row_ids:
            shared._fail("full_local_pair_bundle_mismatch", pair_location)
        if assessment["winner"] not in PAIR_WINNERS:
            shared._fail("invalid_full_local_pair_winner", pair_location)
        witness_id = assessment["candidate_witness_row_id"]
        if witness_id not in row_ids:
            shared._fail("invalid_full_local_pair_witness", pair_location)
        witness = row_index[witness_id]
        if assessment["candidate_evidence_quote"] != witness["evidence_quote"]:
            shared._fail("full_local_pair_candidate_evidence_mismatch", pair_location)
        if assessment["anchor_evidence_quote"] != anchor["evidence_quote"]:
            shared._fail("full_local_pair_anchor_evidence_mismatch", pair_location)
        if assessment["anchor_role"] not in ANCHOR_ROLES:
            shared._fail("invalid_full_local_pair_anchor_role", pair_location)
        if assessment["candidate_role"] not in CANDIDATE_ROLES:
            shared._fail("invalid_full_local_pair_candidate_role", pair_location)
        for key in (
            "anchor_only_repair_effect",
            "candidate_only_repair_effect",
            "repair_relation",
            "pair_comparison",
            "pair_falsifier",
        ):
            shared._nonempty_text(
                assessment[key], location=f"{pair_location}.{key}", maximum=1800
            )
        if assessment["winner"] == "candidate_wins":
            if (
                assessment["selected_row_id"] != witness_id
                or assessment["anchor_role"] not in OVERRIDABLE_ANCHOR_ROLES
                or assessment["candidate_role"] != "critical_boundary"
                or not assessment["repair_relation"].startswith(SELECT_RELATION_PREFIX)
            ):
                shared._fail("ineligible_full_local_candidate_win", pair_location)
            _validate_optional_literal(
                case=case,
                step=assessment["anchor_veto_evidence_step"],
                quote=assessment["anchor_veto_evidence_quote"],
                location=f"{pair_location}.anchor_veto",
            )
            if assessment["anchor_veto_evidence_step"] is None:
                shared._fail("missing_full_local_anchor_veto", pair_location)
            winners.append((index, assessment, witness))
        else:
            if (
                assessment["selected_row_id"] is not None
                or assessment["anchor_veto_evidence_step"] is not None
                or assessment["anchor_veto_evidence_quote"] is not None
                or not assessment["repair_relation"].startswith(KEEP_RELATION_PREFIX)
            ):
                shared._fail("invalid_full_local_anchor_win", pair_location)

    expected_decision = "select_candidate" if winners else "keep_anchor"
    if raw["decision"] not in PAIR_DECISIONS or raw["decision"] != expected_decision:
        shared._fail("full_local_pair_reducer_decision_mismatch", location)
    if winners:
        selected_index, selected_assessment, selected_row = winners[0]
        expected_prediction = _row_prediction(
            case=case, row=selected_row, assessment=selected_assessment
        )
        expected_basis = (
            f"earliest_candidate_pair_wins=Step {selected_row['step']}; "
            f"exact_copy_row={selected_row['row_id']}"
        )
    else:
        selected_index = None
        expected_prediction = anchor
        expected_basis = "no_candidate_pair_wins; exact_copy_anchor"
    shared._validate_prediction_record(
        expected_prediction, case=case, location=f"{location}.expected_prediction"
    )
    if (
        raw["selected_pair_index"] != selected_index
        or raw["frozen_step"] != expected_prediction["predicted_step"]
        or raw["selected_prediction"] != expected_prediction
        or raw["selected_prediction_sha256"] != shared._stable_sha256(expected_prediction)
        or raw["deterministic_reducer_basis"] != expected_basis
    ):
        shared._fail("full_local_pair_deterministic_assembly_mismatch", location)
    return raw


def validate_class_selector(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    matrix_path: str | Path,
    pair_path: str | Path,
) -> dict[str, Any]:
    (
        _,
        _,
        case,
        anchor_file,
        ledger_file,
        checkpoint_file,
        matrix_file,
        anchor,
        ledger,
        checkpoint,
        matrix,
    ) = _load_pair_inputs(
        prediction_manifest_path,
        cohort_manifest_path,
        anchor_path,
        ledger_path,
        checkpoint_path,
        matrix_path,
    )
    pair_file, raw = shared._load_artifact(pair_path, role="full local Step pair reducer")
    if not isinstance(raw, list) or len(raw) != 1:
        shared._fail("invalid_full_local_pair_file_count", str(pair_file))
    record = _validate_pair_record(
        raw[0],
        case=case,
        anchor=anchor,
        ledger=ledger,
        checkpoint=checkpoint,
        matrix=matrix,
        location="full_local_pair_reducer[0]",
    )
    return _retag(
        {
            "schema_version": "agentdebug.full-local-step-pairwise-reducer-audit.v1",
            "stage": "full_local_step_pairwise_reducer",
            "gold_free_validation": True,
            "case_count": 1,
            "positive_step_count": record["positive_step_count"],
            "pair_count": len(record["pair_assessments"]),
            "candidate_win_count": sum(
                row["winner"] == "candidate_wins"
                for row in record["pair_assessments"]
            ),
            "decision": record["decision"],
            "deterministic_earliest_winner_reducer": True,
            "all_positive_steps_reviewed_exactly_once": True,
            "input_sha256": {
                "anchor": shared._file_sha256(anchor_file),
                "ledger": shared._file_sha256(ledger_file),
                "checkpoint": shared._file_sha256(checkpoint_file),
                "matrix": shared._file_sha256(matrix_file),
            },
            "output_sha256": {CLASS_SELECTOR_FILENAME: shared._file_sha256(pair_file)},
        },
        policy="full_local_positive_step_pairwise_semantics_then_deterministic_earliest_winner",
    )


def build_class_selector_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    anchor_path: str | Path,
    ledger_path: str | Path,
    checkpoint_path: str | Path,
    matrix_path: str | Path,
    pair_path: str | Path,
) -> str:
    (
        manifest,
        cohort,
        case,
        anchor_file,
        ledger_file,
        checkpoint_file,
        matrix_file,
        anchor,
        ledger,
        checkpoint,
        matrix,
    ) = _load_pair_inputs(
        prediction_manifest_path,
        cohort_manifest_path,
        anchor_path,
        ledger_path,
        checkpoint_path,
        matrix_path,
    )
    output = Path(pair_path).expanduser().resolve()
    shared._assert_safe_path(output, role="full local Step pair reducer output", is_output=True)
    audit = output.parent / CLASS_SELECTOR_AUDIT_FILENAME
    command = shared._command(
        (
            "PYTHONPATH=. python3 -m",
            "agentdebug.diagnostics.agent_judge_luna_gaia_v3_62_clean_v3p20_full_local_step_pairwise_reducer",
            "--compact-validate",
            "class-selector",
            manifest,
            cohort,
            anchor_file,
            ledger_file,
            checkpoint_file,
            matrix_file,
            output,
            audit,
        )
    ).replace("'PYTHONPATH=. python3 -m'", "PYTHONPATH=. python3 -m")
    templates = []
    for step, rows in _step_bundles(matrix):
        templates.append(
            {
                "candidate_step": step,
                "candidate_row_ids": [row["row_id"] for row in rows],
                "winner": "anchor_wins or candidate_wins",
                "candidate_witness_row_id": "exact row_id from this Step bundle",
                "selected_row_id": "same witness row for candidate_wins, else null",
                "anchor_role": "one exact anchor role",
                "candidate_role": "one exact candidate role",
                "anchor_evidence_quote": anchor["evidence_quote"],
                "anchor_veto_evidence_step": "literal veto Step or null",
                "anchor_veto_evidence_quote": "literal veto quote or null",
                "candidate_evidence_quote": "exact witness-row evidence_quote",
                "anchor_only_repair_effect": "pair-local anchor repair effect",
                "candidate_only_repair_effect": "pair-local candidate repair effect",
                "repair_relation": "required exact prefix then literal relation",
                "pair_comparison": "only anchor versus this Step bundle",
                "pair_falsifier": "strongest concrete argument reversing this pair",
            }
        )
    schema = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "anchor_prediction_sha256": shared._stable_sha256(anchor),
        "anchor_ledger_sha256": shared._stable_sha256(ledger),
        "anchor_checkpoint_sha256": shared._stable_sha256(checkpoint),
        "local_matrix_sha256": shared._stable_sha256(matrix),
        "anchor_step": anchor["predicted_step"],
        "reviewed_positive_steps": [step for step, _ in _step_bundles(matrix)],
        "positive_step_count": len(templates),
        "pair_assessments": templates,
        "decision": "keep_anchor or select_candidate, mechanically implied",
        "selected_pair_index": "earliest candidate_wins 1-based index or null",
        "frozen_step": "mechanically selected Step",
        "selected_prediction_sha256": "stable hash of exact deterministic prediction",
        "selected_prediction": "exact anchor or deterministic selected-row prediction",
        "deterministic_reducer_basis": "exact required reducer string",
    }
    return f"""\
Run {AGENT_JUDGE_LUNA_GAIA_V3_62_VERSION} full-local Step pairwise reducer.

{_boundary(manifest=manifest, cohort=cohort, reads=(anchor_file, ledger_file, checkpoint_file, matrix_file), output=output)}

{_PAIR_RULES}

The immutable anchor Step is {anchor['predicted_step']}. The complete local
matrix has {matrix['positive_row_count']} positive rows grouped into
{len(templates)} positive Steps. The output must include every listed Step and
row bundle exactly once and in the supplied order. An empty matrix requires an
empty pair table and keep_anchor.

Allowed anchor_role values:
{', '.join(sorted(ANCHOR_ROLES))}

Allowed candidate_role values:
{', '.join(sorted(CANDIDATE_ROLES))}

AGENT ERROR TAXONOMY
{taxonomy_prompt()}

Write one JSON array with one object and fields in exactly this order:
{json.dumps(schema, ensure_ascii=False, indent=2)}

After writing, run exactly:
cd {Path(__file__).resolve().parents[2]}
{command}
Complete only when it exits zero and creates {audit}.
"""


def _validate_aggregate(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    _, _, cases = shared._load_cases(
        prediction_manifest_path, cohort_manifest_path
    )
    root = Path(predictions_path).expanduser().resolve().parent
    names = (
        ANCHOR_PREDICTIONS_FILENAME,
        ANCHOR_LEDGER_AGGREGATE_FILENAME,
        ANCHOR_CHECKPOINT_AGGREGATE_FILENAME,
        STEP_LOCAL_RECORDS_FILENAME,
        LOCAL_MATRICES_FILENAME,
        CLASS_SELECTORS_FILENAME,
    )
    loaded = {
        name: shared._load_artifact(root / name, role=f"merged {name}")[1]
        for name in names
    }
    if any(
        not isinstance(value, list) or len(value) != len(cases)
        for value in loaded.values()
    ):
        shared._fail("invalid_full_local_pair_aggregate_count", "all artifacts need all cases")
    finals = shared._load_artifact(predictions_path, role="merged predictions")[1]
    if not isinstance(finals, list) or len(finals) != len(cases):
        shared._fail("invalid_full_local_pair_prediction_count", "predictions need all cases")
    decisions: Counter[str] = Counter()
    pair_winners: Counter[str] = Counter()
    positive_steps: Counter[int] = Counter()
    selected_directions: Counter[str] = Counter()
    for index, case in enumerate(cases):
        location = f"full_local_pair_merged[{index}]"
        anchor = loaded[ANCHOR_PREDICTIONS_FILENAME][index]
        ledger = loaded[ANCHOR_LEDGER_AGGREGATE_FILENAME][index]
        checkpoint = loaded[ANCHOR_CHECKPOINT_AGGREGATE_FILENAME][index]
        local_records = loaded[STEP_LOCAL_RECORDS_FILENAME][index]
        matrix = loaded[LOCAL_MATRICES_FILENAME][index]
        pair = loaded[CLASS_SELECTORS_FILENAME][index]
        shared._validate_prediction_record(anchor, case=case, location=f"{location}.anchor")
        if (
            ledger.get("trajectory_id") != case.trajectory_id
            or ledger.get("selected_step") != anchor["predicted_step"]
            or checkpoint.get("trajectory_id") != case.trajectory_id
            or checkpoint.get("predicted_step") != anchor["predicted_step"]
        ):
            shared._fail("full_local_pair_anchor_sidecar_mismatch", location)
        step_local_transport._validate_local_matrix_record(
            matrix, case=case, location=f"{location}.local_matrix"
        )
        step_local_transport._validate_local_record_set(
            local_records,
            case=case,
            matrix=matrix,
            location=f"{location}.local_records",
        )
        _validate_pair_record(
            pair,
            case=case,
            anchor=anchor,
            ledger=ledger,
            checkpoint=checkpoint,
            matrix=matrix,
            location=f"{location}.pair",
        )
        final = shared._validate_prediction_record(
            finals[index], case=case, location=f"{location}.final"
        )
        if final != pair["selected_prediction"]:
            shared._fail("full_local_pair_final_copy_mismatch", location)
        decisions[pair["decision"]] += 1
        positive_steps[pair["positive_step_count"]] += 1
        for assessment in pair["pair_assessments"]:
            pair_winners[assessment["winner"]] += 1
        if pair["decision"] == "select_candidate":
            selected_directions[
                "earlier"
                if pair["frozen_step"] < pair["anchor_step"]
                else "later"
                if pair["frozen_step"] > pair["anchor_step"]
                else "same"
            ] += 1
    return {
        "required": True,
        "valid": True,
        "step_isolated_local_evidence": True,
        "local_step_coverage_complete": True,
        "full_positive_step_pair_coverage": True,
        "shared_anchor_class_forbidden": True,
        "default_anchor_policy": True,
        "pair_local_literal_binding": True,
        "two_sided_repair_relation_binding": True,
        "deterministic_earliest_winner_reducer": True,
        "all_selected_predictions_exact_copies": True,
        "decision_counts": dict(sorted(decisions.items())),
        "pair_winner_counts": dict(sorted(pair_winners.items())),
        "selected_direction_counts": dict(sorted(selected_directions.items())),
        "positive_step_count_distribution": {
            str(key): value for key, value in sorted(positive_steps.items())
        },
        "packet_state_closure": parent._validate_packet_state_ledgers(
            root / ANCHOR_LEDGER_AGGREGATE_FILENAME
        ),
    }


def validate_agent_judge_luna_gaia_v3_62_predictions(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> dict[str, Any]:
    audit = validate_agent_judge_luna_gaia_v2_1_predictions(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    mechanism = _validate_aggregate(
        prediction_manifest_path, cohort_manifest_path, predictions_path
    )
    return {
        **audit,
        "schema_version": AGENT_JUDGE_LUNA_GAIA_V3_62_AUDIT_SCHEMA_VERSION,
        "agent_judge_version": AGENT_JUDGE_LUNA_GAIA_V3_62_VERSION,
        "model": AGENT_JUDGE_LUNA_GAIA_V3_62_MODEL,
        "reasoning_effort": AGENT_JUDGE_LUNA_GAIA_V3_62_REASONING_EFFORT,
        "selection_policy": (
            "clean_v3_20_complete_step_isolated_local_matrix_full_positive_step_"
            "pair_table_deterministic_earliest_winner_exact_copy_reducer"
        ),
        "direct_semantic_parent": parent.AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        "rejected_lineage_inherited": False,
        "single_major_change": (
            "one complete Step-isolated local matrix retained through a full "
            "anchor-versus-positive-Step pair table and deterministic earliest-winner reducer"
        ),
        "anchor_semantics_unchanged_from_v3_20": True,
        "all_selected_predictions_exact_copies": True,
        "full_local_step_pairwise_reducer": mechanism,
    }


def _write(audit: dict[str, Any], path: str | Path) -> dict[str, Any]:
    return shared._write_audit(audit, path)


def validate_and_write_anchor_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_anchor_predictions(*paths[:-1]), paths[-1])


def validate_and_write_step_local_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_step_local(*paths[:-1]), paths[-1])


def validate_and_write_local_matrix_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_local_matrix(*paths[:-1]), paths[-1])


def validate_and_write_class_selector_audit(*paths: str | Path) -> dict[str, Any]:
    return _write(validate_class_selector(*paths[:-1]), paths[-1])


def validate_and_write_agent_judge_luna_gaia_v3_62_audit(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path,
) -> dict[str, Any]:
    return _write(
        validate_agent_judge_luna_gaia_v3_62_predictions(
            prediction_manifest_path, cohort_manifest_path, predictions_path
        ),
        audit_path,
    )


# Compatibility callable used only by the generic clean Step-isolated runner.
validate_and_write_agent_judge_luna_gaia_v3_56_audit = (
    validate_and_write_agent_judge_luna_gaia_v3_62_audit
)


def build_agent_judge_luna_gaia_v3_62_task(
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
) -> str:
    prediction = Path(predictions_path).expanduser().resolve()
    return build_class_selector_task(
        prediction_manifest_path,
        cohort_manifest_path,
        prediction.parent / ANCHOR_PREDICTIONS_FILENAME,
        prediction.parent / "step-candidates.json",
        prediction.parent / "step-freeze.json",
        prediction.parent / LOCAL_MATRIX_FILENAME,
        prediction.parent / CLASS_SELECTOR_FILENAME,
    )


def run_compact_validation(stage: str, paths: Sequence[str]) -> int:
    try:
        if stage == "anchor" and len(paths) == 4:
            audit = validate_and_write_anchor_audit(*paths)
        elif stage == "local" and len(paths) == 3:
            audit = validate_and_write_step_local_audit(*paths)
        elif stage == "matrix" and len(paths) == 4:
            audit = validate_and_write_local_matrix_audit(*paths)
        elif stage == "class-selector" and len(paths) == 8:
            audit = validate_and_write_class_selector_audit(*paths)
        elif stage == "prediction" and len(paths) == 4:
            audit = validate_and_write_agent_judge_luna_gaia_v3_62_audit(*paths)
        else:
            shared._fail("invalid_compact_validation_arguments", "stage/path count differs")
    except (shared.AgentJudgeValidationError, json.JSONDecodeError, OSError) as error:
        code = getattr(error, "code", type(error).__name__)
        print(json.dumps({"ok": False, "code": code}, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True, "audit": audit}, ensure_ascii=False))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--compact-validate", action="store_true")
    parser.add_argument(
        "stage", choices=("anchor", "local", "matrix", "class-selector", "prediction")
    )
    parser.add_argument("paths", nargs="+")
    args = parser.parse_args(argv)
    if not args.compact_validate:
        raise SystemExit("only --compact-validate is supported")
    return run_compact_validation(args.stage, args.paths)


if __name__ == "__main__":
    raise SystemExit(main())

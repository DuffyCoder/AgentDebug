"""Archive-only trace helpers and the retired diagnostic CLI.

The CLI deliberately operates on source traces.  It never produces or consumes
the former XML-tagged AgentDebug message representation.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence


_SOURCE_ARGUMENTS: tuple[tuple[str, str], ...] = (
    ("session", "OpenClaw session v3 JSONL"),
    ("runtime_trace", "OpenClaw runtime trajectory JSONL"),
    ("eval_trace", "Claw-Eval trace JSONL"),
    ("manifest", "Evaluation manifest JSONL"),
    ("task", "Task definition YAML or JSON"),
)


def _json_value(value: Any) -> Any:
    if hasattr(value, "to_dict"):
        return value.to_dict()
    if hasattr(value, "to_json"):
        rendered = value.to_json()
        return json.loads(rendered) if isinstance(rendered, str) else rendered
    if isinstance(value, Mapping):
        return dict(value)
    raise TypeError(f"{type(value).__name__} cannot be serialized as a JSON document")


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(_json_value(value), ensure_ascii=False, indent=2) + "\n"
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(payload, encoding="utf-8")
    temporary.replace(path)


def _default_output(args: argparse.Namespace, kind: str) -> Path:
    source = next(
        (
            Path(getattr(args, name))
            for name, _ in _SOURCE_ARGUMENTS
            if getattr(args, name) is not None
        ),
        None,
    )
    if source is None:
        raise ValueError("at least one trajectory source path is required")
    return source.with_name(f"{source.stem}.{kind}.json")


def _load_trace(args: argparse.Namespace) -> Any:
    from agentdebug.trace import load_trace_bundle

    return load_trace_bundle(
        session_path=args.session,
        runtime_path=args.runtime_trace,
        eval_trace_path=args.eval_trace,
        manifest_path=args.manifest,
        task_path=args.task,
        strict=False,
    )


def _validate(trace: Any) -> Any:
    from agentdebug.trace import validate_trace

    # Strict-mode control belongs to the CLI so an integrity artifact can still
    # be written before returning a non-zero status.
    return validate_trace(trace, strict=False)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _input_sources(args: argparse.Namespace) -> list[dict[str, str]]:
    sources: list[dict[str, str]] = []
    for name, _ in _SOURCE_ARGUMENTS:
        value = getattr(args, name)
        if value is None:
            continue
        path = Path(value).resolve()
        sources.append(
            {
                "source": name,
                "path": str(path),
                "sha256": _sha256(path),
            }
        )
    return sources


def _normalise_severity(value: Any) -> str:
    if hasattr(value, "value"):
        value = value.value
    return str(value or "").strip().lower()


def _integrity_summary(report: Any) -> dict[str, Any]:
    payload = _json_value(report)
    issues = payload.get("issues", [])
    counts = {"error": 0, "critical": 0, "warning": 0, "info": 0}
    if isinstance(issues, list):
        for issue in issues:
            if not isinstance(issue, Mapping):
                continue
            severity = _normalise_severity(issue.get("severity"))
            if severity in counts:
                counts[severity] += 1

    supplied = payload.get("summary")
    if isinstance(supplied, Mapping):
        for key in counts:
            candidate = supplied.get(key, supplied.get(f"{key}s"))
            if isinstance(candidate, int):
                counts[key] = candidate

    valid = payload.get("valid")
    if not isinstance(valid, bool):
        valid = payload.get("ok")
    status = _normalise_severity(payload.get("status"))
    if status:
        valid = status not in {"fail", "failed", "error", "critical", "invalid"}
    if not isinstance(valid, bool):
        valid = counts["error"] == 0 and counts["critical"] == 0

    return {
        "valid": valid,
        "errors": counts["error"] + counts["critical"],
        "critical": counts["critical"],
        "warnings": counts["warning"],
        "info": counts["info"],
    }


def _integrity_has_errors(report: Any) -> bool:
    return not _integrity_summary(report)["valid"]


def _output_path(args: argparse.Namespace, kind: str) -> Path:
    return args.output or _default_output(args, kind)


def _command_ingest(args: argparse.Namespace) -> int:
    from agentdebug.trace import save_canonical_trace

    trace = _load_trace(args)
    output = _output_path(args, "canonical")
    save_canonical_trace(trace, output)

    integrity = _validate(trace)
    print(f"canonical: {output}")
    if args.strict and _integrity_has_errors(integrity):
        print("ingest: integrity errors found", file=sys.stderr)
        return 2
    return 0


def _command_validate(args: argparse.Namespace) -> int:
    trace = _load_trace(args)
    integrity = _validate(trace)
    output = _output_path(args, "integrity")
    _write_json(output, integrity)
    print(f"integrity: {output}")

    if args.strict and _integrity_has_errors(integrity):
        print("validate: integrity errors found", file=sys.stderr)
        return 2
    return 0


def _report_metadata(
    args: argparse.Namespace,
    integrity: Any,
) -> dict[str, Any]:
    return {
        "sources": _input_sources(args),
        "integrity": _integrity_summary(integrity),
    }


def _create_judge(args: argparse.Namespace) -> Any:
    from agentdebug.diagnostics import (
        GeminiGenerateContentJudge,
        OpenAICompatibleJudge,
    )

    judge_class = (
        GeminiGenerateContentJudge
        if args.judge_provider == "gemini-generate-content"
        else OpenAICompatibleJudge
    )
    return judge_class(
        base_url=args.judge_base_url,
        api_key_env=args.judge_api_key_env,
        model=args.judge_model,
        temperature=args.judge_temperature,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
    )


def _command_analyze(args: argparse.Namespace) -> int:
    trace = _load_trace(args)
    output = _output_path(args, "report")

    from agentdebug.diagnostics.analyzer import analyze

    integrity = _validate(trace)
    if _integrity_has_errors(integrity):
        class _NeverCalledJudge:
            def analyze_module(self, request: Any) -> Any:
                raise AssertionError("integrity gate must run before specialists")

            def arbitrate_root_cause(self, request: Any) -> Any:
                raise AssertionError("integrity gate must run before arbiter")

            def critique_root_cause(self, request: Any) -> Any:
                raise AssertionError("integrity gate must run before critic")

        judge: Any = _NeverCalledJudge()
    else:
        judge = _create_judge(args)
    report_object = analyze(trace, judge=judge)
    report = _json_value(report_object)
    report_metadata = report.get("metadata")
    if not isinstance(report_metadata, dict):
        report_metadata = {}
        report["metadata"] = report_metadata
    report_metadata.update(_report_metadata(args, report_object.integrity))
    report_metadata["judge"] = {
        "provider": args.judge_provider,
        "model": args.judge_model,
        "base_url": args.judge_base_url,
        "temperature": args.judge_temperature,
        "max_output_tokens": args.judge_max_output_tokens,
    }
    _write_json(output, report)
    print(f"report: {output}")
    if report["status"] in {"invalid", "blocked_by_integrity"}:
        print(f"analyze: diagnosis status is {report['status']}", file=sys.stderr)
        return 2
    return 0


def _add_source_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--session",
        type=Path,
        help=_SOURCE_ARGUMENTS[0][1],
    )
    parser.add_argument(
        "--runtime-trace",
        dest="runtime_trace",
        type=Path,
        help=_SOURCE_ARGUMENTS[1][1],
    )
    parser.add_argument(
        "--eval-trace",
        dest="eval_trace",
        type=Path,
        help=_SOURCE_ARGUMENTS[2][1],
    )
    parser.add_argument(
        "--manifest",
        type=Path,
        help=_SOURCE_ARGUMENTS[3][1],
    )
    parser.add_argument(
        "--task",
        type=Path,
        help=_SOURCE_ARGUMENTS[4][1],
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="Output path (defaults beside the first trajectory source)",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Return non-zero when integrity contains an error",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="agentdebug-trace",
        description="Ingest, validate, and diagnose real OpenClaw traces",
    )
    commands = parser.add_subparsers(dest="command", required=True)

    definitions: tuple[tuple[str, str, Callable[[argparse.Namespace], int]], ...] = (
        ("ingest", "Build a lossless Canonical Trace", _command_ingest),
        ("validate", "Write a source-integrity report", _command_validate),
        ("analyze", "Locate failures using canonical evidence", _command_analyze),
    )
    for name, help_text, handler in definitions:
        command = commands.add_parser(name, help=help_text, description=help_text)
        _add_source_arguments(command)
        if name == "analyze":
            command.add_argument(
                "--judge-provider",
                choices=("openai-compatible", "gemini-generate-content"),
                default="openai-compatible",
                help="LLM judge transport (default: openai-compatible)",
            )
            command.add_argument(
                "--judge-model",
                required=True,
                help="Model used for both judge phases",
            )
            command.add_argument(
                "--judge-base-url",
                default=os.environ.get(
                    "AGENTDEBUG_JUDGE_BASE_URL",
                    "https://api.openai.com/v1",
                ),
                help=(
                    "Provider base URL or full completion endpoint "
                    "(default: AGENTDEBUG_JUDGE_BASE_URL or OpenAI)"
                ),
            )
            command.add_argument(
                "--judge-api-key-env",
                default="OPENAI_API_KEY",
                help=(
                    "Name of the environment variable containing the API key "
                    "(default: OPENAI_API_KEY)"
                ),
            )
            command.add_argument(
                "--judge-temperature",
                type=float,
                default=0.0,
                help="Judge sampling temperature (default: 0)",
            )
            command.add_argument(
                "--judge-timeout",
                type=float,
                default=120.0,
                help="Timeout in seconds for each judge phase (default: 120)",
            )
            command.add_argument(
                "--judge-max-output-tokens",
                type=int,
                default=8192,
                help="Maximum tokens returned by each judge phase (default: 8192)",
            )
        command.set_defaults(handler=handler)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.handler(args)
    except (OSError, TypeError, ValueError) as error:
        print(f"agentdebug-trace: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())

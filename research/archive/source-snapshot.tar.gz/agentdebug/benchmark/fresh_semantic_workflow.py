"""Gold-isolated E8 fresh semantic prediction and raw-derived scoring.

The provider process consumes only a frozen :class:`PredictionManifest`.
Every final semantic field comes from one fresh LLM raw response.  Deterministic
code is limited to contracts, lineage, evidence validation, an optional
evidence-only repair, and benchmark scoring after prediction artifacts close.
"""

from __future__ import annotations

import fcntl
import hashlib
import json
import os
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from agentdebug.diagnostics.evidence_repair import (
    parse_evidence_repair,
)
from agentdebug.diagnostics.fresh_semantic_evidence import (
    FRESH_EVIDENCE_REPAIR_MAX_ATTEMPTS,
    FRESH_EVIDENCE_REPAIR_PIPELINE_VERSION,
    FRESH_EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION,
    FRESH_EVIDENCE_VALIDATION_VERSION,
    build_fresh_evidence_repair_request,
    fresh_evidence_repair_messages,
    validate_fresh_semantic_evidence,
)
from agentdebug.diagnostics.fresh_semantic_judge import (
    FRESH_SEMANTIC_PIPELINE_VERSION,
    FRESH_SEMANTIC_PROMPT_PROTOCOL_VERSION,
    fresh_semantic_judge_messages,
    parse_fresh_semantic_judge,
)
from agentdebug.diagnostics.judge_view import JUDGE_VIEW_VERSION
from agentdebug.diagnostics.models import RootCauseJudgment
from agentdebug.diagnostics.parsing import JudgeOutputError

from .cohort import CohortManifest
from .metrics import compute_metrics
from .models import BenchmarkDataset
from .prediction_manifest import (
    PredictionCase,
    load_prediction_manifest,
    stable_sha256,
)
from .runner import (
    TRANSPORT_POLICY_VERSION,
    BenchmarkRunConfig,
    _apply_root,
    _base_record,
)
from .stage_cache import (
    build_stage_request,
    run_cached_stage,
    stable_sha256 as stage_sha256,
    sum_stage_telemetry,
)


E8_EXPERIMENT = "e8_fresh_semantic_judge"
E8_METHOD = "two_stage"
E8_STAGE = "fresh_semantic_judge"
E8_REPAIR_STAGE = "fresh_semantic_evidence_repair"
E8_PREDICTION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e8-unscored-prediction.v1"
)
E8_PREDICT_RUN_SCHEMA_VERSION = "agentdebug.benchmark.e8-predict-run.v2"
E8_LOGICAL_COMPLETION_LEDGER_SCHEMA_VERSION = (
    "agentdebug.benchmark.e8-logical-completion-ledger.v1"
)
_STAGES = (E8_STAGE, E8_REPAIR_STAGE)
_OUTCOME_FIELDS = {
    "status",
    "failure_stage",
    "failure_code",
    "failure_message",
}
_SEMANTIC_FIELDS = {
    "status",
    "failure_stage",
    "failure_code",
    "failure_message",
    "root_cause_judgment",
    "judge_reported_step",
    "predicted_step",
    "predicted_event_id",
    "predicted_module",
    "predicted_error_type",
    "root_cause",
    "judge_step_matches_event_mapping",
    "evidence_validation_issues",
    "evidence_repair",
}
_ROW_FIELDS = {
    "schema_version",
    "method",
    "experiment",
    "pipeline_version",
    "prompt_protocol_version",
    "evidence_repair_pipeline_version",
    "evidence_repair_prompt_protocol_version",
    "evidence_repair_max_attempts",
    "evidence_validation_version",
    "transport_policy_version",
    "preregistration_sha256",
    "prediction_manifest_sha256",
    "trajectory_id",
    "trajectory_sha256",
    "case_input_sha256",
    "provider_config",
    "cache_dir",
    "stage_attempted",
    "stage_cache_hits",
    "stage_identities",
    "stage_outcomes",
    "stage_provider_telemetry",
    "raw_judge_outputs",
    "provider_telemetry",
    "latency_seconds",
    "cache_hit",
    *_SEMANTIC_FIELDS,
    "unscored_prediction_sha256",
}
_RUN_FIELDS = {
    "schema_version",
    "method",
    "experiment",
    "pipeline_version",
    "prompt_protocol_version",
    "evidence_repair_pipeline_version",
    "evidence_repair_prompt_protocol_version",
    "evidence_repair_max_attempts",
    "evidence_validation_version",
    "transport_policy_version",
    "preregistration_sha256",
    "prediction_manifest_path",
    "prediction_manifest_file_sha256",
    "prediction_manifest_sha256",
    "unscored_predictions_path",
    "unscored_predictions_sha256",
    "predict_run_metadata_path",
    "run_output_dir",
    "cache_dir",
    "selected_trajectory_ids",
    "prediction_count",
    "provider_config",
    "provider_telemetry",
    "provider_telemetry_coverage",
    "provider_capabilities",
    "repair_eligible_count",
    "repair_attempt_count",
    "repair_applied_count",
    "semantic_mutation_count",
    "max_logical_completions",
    "logical_completion_budget_used",
    "logical_completion_ledger_path",
    "logical_completion_ledger_file_sha256",
    "logical_completion_ledger_sha256",
    "retry_failures",
    "predict_run_sha256",
}
_FORBIDDEN_KEYS = {
    "all_correct",
    "confidence",
    "critical_failure_module",
    "critical_failure_step",
    "critical_failure_type",
    "deterministic_finding",
    "gold_error_type",
    "gold_event_id",
    "gold_module",
    "gold_normalization_notes",
    "gold_raw_error_type",
    "gold_raw_module",
    "gold_reasoning",
    "gold_step",
    "rank",
    "score",
    "scores",
    "severity",
    "step_annotations",
    "step_exact",
    "step_module_exact",
    "vote",
    "votes",
    "weight",
    "weights",
}


class FreshSemanticWorkflowError(ValueError):
    """An E8 prediction artifact is unsafe, inconsistent, or unreproducible."""


def _assert_gold_free(value: Any, *, location: str) -> None:
    if isinstance(value, Mapping):
        forbidden = sorted(
            str(key)
            for key in value
            if str(key).casefold() in _FORBIDDEN_KEYS
            or str(key).casefold().startswith("gold_")
        )
        if forbidden:
            raise FreshSemanticWorkflowError(
                f"{location} contains forbidden evaluator fields: "
                + ", ".join(forbidden)
            )
        for key, item in value.items():
            _assert_gold_free(item, location=f"{location}.{key}")
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _assert_gold_free(item, location=f"{location}[{index}]")


def _file_sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _assert_sha256(value: Any, *, field: str) -> str:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise FreshSemanticWorkflowError(
            f"E8 {field} must be one lowercase SHA-256 digest"
        )
    return value


def _atomic_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(value, encoding="utf-8")
    temporary.replace(path)


def _atomic_json(path: Path, value: Any) -> None:
    _atomic_text(
        path,
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
    )


def _durable_atomic_json(path: Path, value: Any) -> None:
    """Atomically persist an authorization record before a provider call."""

    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)
    directory_fd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def _ledger_lock_path(path: Path) -> Path:
    return path.with_suffix(f"{path.suffix}.lock")


@contextmanager
def _locked_ledger(path: Path):
    lock_path = _ledger_lock_path(path)
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a+", encoding="utf-8") as stream:
        fcntl.flock(stream.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def _completion_ledger_document(
    *,
    preregistration_sha256: str,
    cumulative_before: int,
    maximum_new: int,
    authorized_cumulative_ceiling: int,
    entries: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    body: dict[str, Any] = {
        "schema_version": E8_LOGICAL_COMPLETION_LEDGER_SCHEMA_VERSION,
        "preregistration_sha256": preregistration_sha256,
        "cumulative_logical_completions_before": cumulative_before,
        "maximum_new_logical_completions": maximum_new,
        "hard_cumulative_stop": cumulative_before + maximum_new,
        "authorized_cumulative_ceiling": authorized_cumulative_ceiling,
        "entries": [dict(entry) for entry in entries],
    }
    body["ledger_sha256"] = stable_sha256(body)
    return body


def _validate_completion_ledger(
    value: Mapping[str, Any],
    *,
    preregistration_sha256: str | None = None,
    cumulative_before: int | None = None,
    maximum_new: int | None = None,
    authorized_cumulative_ceiling: int | None = None,
    allowed_stages: Sequence[str] = _STAGES,
) -> dict[str, Any]:
    expected_fields = {
        "schema_version",
        "preregistration_sha256",
        "cumulative_logical_completions_before",
        "maximum_new_logical_completions",
        "hard_cumulative_stop",
        "authorized_cumulative_ceiling",
        "entries",
        "ledger_sha256",
    }
    document = dict(value)
    if set(document) != expected_fields:
        raise FreshSemanticWorkflowError(
            "E8 logical-completion ledger fields are invalid"
        )
    body = dict(document)
    claimed = body.pop("ledger_sha256", None)
    if (
        document.get("schema_version")
        != E8_LOGICAL_COMPLETION_LEDGER_SCHEMA_VERSION
        or claimed != stable_sha256(body)
    ):
        raise FreshSemanticWorkflowError(
            "E8 logical-completion ledger hash is invalid"
        )
    before = document.get("cumulative_logical_completions_before")
    maximum = document.get("maximum_new_logical_completions")
    hard_stop = document.get("hard_cumulative_stop")
    ceiling = document.get("authorized_cumulative_ceiling")
    entries = document.get("entries")
    if (
        isinstance(before, bool)
        or not isinstance(before, int)
        or before < 0
        or isinstance(maximum, bool)
        or not isinstance(maximum, int)
        or maximum < 1
        or isinstance(hard_stop, bool)
        or not isinstance(hard_stop, int)
        or hard_stop != before + maximum
        or isinstance(ceiling, bool)
        or not isinstance(ceiling, int)
        or hard_stop > ceiling
        or not isinstance(entries, list)
        or len(entries) > maximum
    ):
        raise FreshSemanticWorkflowError(
            "E8 logical-completion ledger budget is invalid"
        )
    for index, entry in enumerate(entries, start=1):
        if (
            not isinstance(entry, Mapping)
            or set(entry) != {"ordinal", "stage", "request_sha256"}
            or entry.get("ordinal") != index
            or entry.get("stage") not in set(allowed_stages)
        ):
            raise FreshSemanticWorkflowError(
                "E8 logical-completion ledger entry is invalid"
            )
        _assert_sha256(
            entry.get("request_sha256"),
            field="ledger request_sha256",
        )
    expected = {
        "preregistration_sha256": preregistration_sha256,
        "cumulative_logical_completions_before": cumulative_before,
        "maximum_new_logical_completions": maximum_new,
        "authorized_cumulative_ceiling": authorized_cumulative_ceiling,
    }
    if any(
        required is not None and document.get(field) != required
        for field, required in expected.items()
    ):
        raise FreshSemanticWorkflowError(
            "E8 logical-completion ledger identity is invalid"
        )
    return document


def load_fresh_semantic_completion_ledger(
    path: str | Path,
    *,
    preregistration_sha256: str | None = None,
    cumulative_before: int | None = None,
    maximum_new: int | None = None,
    authorized_cumulative_ceiling: int | None = None,
    allowed_stages: Sequence[str] = _STAGES,
) -> dict[str, Any]:
    ledger_path = Path(path).expanduser().resolve()
    value = _read_object(
        ledger_path,
        location="E8 logical-completion ledger",
    )
    return _validate_completion_ledger(
        value,
        preregistration_sha256=preregistration_sha256,
        cumulative_before=cumulative_before,
        maximum_new=maximum_new,
        authorized_cumulative_ceiling=authorized_cumulative_ceiling,
        allowed_stages=allowed_stages,
    )


def initialize_fresh_semantic_completion_ledger(
    path: str | Path,
    *,
    preregistration_sha256: str,
    cumulative_before: int,
    maximum_new: int,
    authorized_cumulative_ceiling: int,
    allowed_stages: Sequence[str] = _STAGES,
) -> dict[str, Any]:
    ledger_path = Path(path).expanduser().resolve()
    preregistration_digest = _assert_sha256(
        preregistration_sha256,
        field="preregistration_sha256",
    )
    expected = _completion_ledger_document(
        preregistration_sha256=preregistration_digest,
        cumulative_before=cumulative_before,
        maximum_new=maximum_new,
        authorized_cumulative_ceiling=authorized_cumulative_ceiling,
        entries=[],
    )
    with _locked_ledger(ledger_path):
        if ledger_path.is_file():
            return _validate_completion_ledger(
                _read_object(
                    ledger_path,
                    location="E8 logical-completion ledger",
                ),
                preregistration_sha256=preregistration_digest,
                cumulative_before=cumulative_before,
                maximum_new=maximum_new,
                authorized_cumulative_ceiling=(
                    authorized_cumulative_ceiling
                ),
                allowed_stages=allowed_stages,
            )
        _durable_atomic_json(ledger_path, expected)
    return expected


class _LogicalBudget:
    """A durable, conservative count of authorized provider attempts."""

    def __init__(
        self,
        maximum: int,
        *,
        ledger_path: str | Path,
        preregistration_sha256: str,
        cumulative_before: int,
        authorized_cumulative_ceiling: int,
        allowed_stages: Sequence[str] = _STAGES,
    ) -> None:
        self.maximum = maximum
        self.ledger_path = Path(ledger_path).expanduser().resolve()
        self.preregistration_sha256 = _assert_sha256(
            preregistration_sha256,
            field="preregistration_sha256",
        )
        self.cumulative_before = cumulative_before
        self.authorized_cumulative_ceiling = authorized_cumulative_ceiling
        self.allowed_stages = tuple(allowed_stages)
        if (
            not self.allowed_stages
            or any(
                not isinstance(stage, str) or not stage.strip()
                for stage in self.allowed_stages
            )
            or len(set(self.allowed_stages)) != len(self.allowed_stages)
        ):
            raise FreshSemanticWorkflowError(
                "logical-completion allowed stages are invalid"
            )
        initialize_fresh_semantic_completion_ledger(
            self.ledger_path,
            preregistration_sha256=self.preregistration_sha256,
            cumulative_before=cumulative_before,
            maximum_new=maximum,
            authorized_cumulative_ceiling=authorized_cumulative_ceiling,
            allowed_stages=self.allowed_stages,
        )

    @property
    def issued(self) -> int:
        return len(self.snapshot["entries"])

    @property
    def snapshot(self) -> dict[str, Any]:
        return load_fresh_semantic_completion_ledger(
            self.ledger_path,
            preregistration_sha256=self.preregistration_sha256,
            cumulative_before=self.cumulative_before,
            maximum_new=self.maximum,
            authorized_cumulative_ceiling=(
                self.authorized_cumulative_ceiling
            ),
            allowed_stages=self.allowed_stages,
        )

    def before_complete(self, *, stage: str, request_sha256: str) -> None:
        if stage not in self.allowed_stages:
            raise FreshSemanticWorkflowError(
                "E8 logical-completion stage is invalid"
            )
        request_digest = _assert_sha256(
            request_sha256,
            field="ledger request_sha256",
        )
        with _locked_ledger(self.ledger_path):
            document = _validate_completion_ledger(
                _read_object(
                    self.ledger_path,
                    location="E8 logical-completion ledger",
                ),
                preregistration_sha256=self.preregistration_sha256,
                cumulative_before=self.cumulative_before,
                maximum_new=self.maximum,
                authorized_cumulative_ceiling=(
                    self.authorized_cumulative_ceiling
                ),
                allowed_stages=self.allowed_stages,
            )
            entries = list(document["entries"])
            if len(entries) >= self.maximum:
                raise FreshSemanticWorkflowError(
                    "E8 logical-completion budget is exhausted"
                )
            entries.append(
                {
                    "ordinal": len(entries) + 1,
                    "stage": stage,
                    "request_sha256": request_digest,
                }
            )
            updated = _completion_ledger_document(
                preregistration_sha256=self.preregistration_sha256,
                cumulative_before=self.cumulative_before,
                maximum_new=self.maximum,
                authorized_cumulative_ceiling=(
                    self.authorized_cumulative_ceiling
                ),
                entries=entries,
            )
            _durable_atomic_json(self.ledger_path, updated)


DurableLogicalCompletionBudget = _LogicalBudget


def _atomic_jsonl(
    path: Path,
    values: Sequence[Mapping[str, Any]],
) -> None:
    _atomic_text(
        path,
        "".join(
            json.dumps(value, ensure_ascii=False, sort_keys=True) + "\n"
            for value in values
        ),
    )


def _read_object(path: str | Path, *, location: str) -> dict[str, Any]:
    try:
        value = json.loads(
            Path(path).expanduser().resolve().read_text(encoding="utf-8")
        )
    except (OSError, json.JSONDecodeError) as error:
        raise FreshSemanticWorkflowError(
            f"{location} is missing or corrupt"
        ) from error
    if not isinstance(value, dict):
        raise FreshSemanticWorkflowError(f"{location} must be an object")
    return value


def _read_jsonl(path: str | Path) -> list[dict[str, Any]]:
    try:
        lines = (
            Path(path)
            .expanduser()
            .resolve()
            .read_text(encoding="utf-8")
            .splitlines()
        )
        values = [json.loads(line) for line in lines if line.strip()]
    except (OSError, json.JSONDecodeError) as error:
        raise FreshSemanticWorkflowError(
            "E8 unscored predictions are missing or corrupt"
        ) from error
    if any(not isinstance(value, dict) for value in values):
        raise FreshSemanticWorkflowError(
            "E8 unscored prediction rows must be objects"
        )
    return values


def _document_with_hash(
    body: Mapping[str, Any],
    *,
    hash_field: str,
) -> dict[str, Any]:
    value = dict(body)
    value[hash_field] = stable_sha256(value)
    return value


def _public_root(root: RootCauseJudgment) -> dict[str, Any]:
    return {
        "critical_step": root.critical_step,
        "module": root.module.value,
        "error_type": root.error_type.value,
        "evidence": root.evidence_quote,
        "root_cause": root.root_cause,
    }


def _shared_identity(
    *,
    case: PredictionCase,
    prediction_manifest: Mapping[str, Any],
    config: BenchmarkRunConfig,
) -> dict[str, Any]:
    return {
        "method": E8_METHOD,
        "experiment": E8_EXPERIMENT,
        "prediction_schema_version": E8_PREDICTION_SCHEMA_VERSION,
        "pipeline_version": FRESH_SEMANTIC_PIPELINE_VERSION,
        "prompt_protocol_version": (
            FRESH_SEMANTIC_PROMPT_PROTOCOL_VERSION
        ),
        "judge_view_version": JUDGE_VIEW_VERSION,
        "evidence_validation_version": FRESH_EVIDENCE_VALIDATION_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "prediction_manifest_sha256": prediction_manifest[
            "prediction_manifest_sha256"
        ],
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "case_input_sha256": case.case_input_sha256,
        "judge_view_sha256": stable_sha256(case.judge_view.to_dict()),
        "provider_config": config.public_dict(),
    }


def _judge_stage_request(
    *,
    case: PredictionCase,
    prediction_manifest: Mapping[str, Any],
    config: BenchmarkRunConfig,
):
    messages = fresh_semantic_judge_messages(case.judge_view)
    request = build_stage_request(
        stage=E8_STAGE,
        messages=messages,
        identity=_shared_identity(
            case=case,
            prediction_manifest=prediction_manifest,
            config=config,
        ),
        dependency_sha256=stable_sha256(
            {
                "case_input_sha256": case.case_input_sha256,
                "no_prior_root": True,
            }
        ),
    )
    return request, messages


def _repair_eligible(root: RootCauseJudgment, case: PredictionCase) -> bool:
    validation = validate_fresh_semantic_evidence(
        case.judge_view,
        root,
        stage=E8_STAGE,
    )
    return (
        len(validation.issues) == 1
        and validation.issues[0].code
        == "owner_evidence_quote_not_found"
        and validation.issues[0].level.value == "error"
    )


def _repair_stage_request(
    *,
    case: PredictionCase,
    prediction_manifest: Mapping[str, Any],
    config: BenchmarkRunConfig,
    judge_root: RootCauseJudgment,
    judge_raw_sha256: str,
):
    repair = build_fresh_evidence_repair_request(
        case.judge_view,
        judge_root,
    )
    messages = fresh_evidence_repair_messages(repair)
    identity = {
        **_shared_identity(
            case=case,
            prediction_manifest=prediction_manifest,
            config=config,
        ),
        "evidence_repair_pipeline_version": (
            FRESH_EVIDENCE_REPAIR_PIPELINE_VERSION
        ),
        "evidence_repair_prompt_protocol_version": (
            FRESH_EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
        ),
        "evidence_repair_max_attempts": (
            FRESH_EVIDENCE_REPAIR_MAX_ATTEMPTS
        ),
        "judge_raw_sha256": judge_raw_sha256,
        "frozen_root_sha256": stable_sha256(judge_root.to_dict()),
    }
    request = build_stage_request(
        stage=E8_REPAIR_STAGE,
        messages=messages,
        identity=identity,
        dependency_sha256=stable_sha256(
            {
                "judge_raw_sha256": judge_raw_sha256,
                "frozen_root": judge_root.to_dict(),
            }
        ),
    )
    return request, messages, repair


def _outcome(stage: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "status": stage["status"],
        "failure_stage": stage["failure_stage"],
        "failure_code": stage["failure_code"],
        "failure_message": stage["failure_message"],
    }


def _stage_identity(stage: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "request_sha256": stage["request_sha256"],
        "prompt_sha256": stage["prompt_sha256"],
        "raw_response_sha256": stage["raw_response_sha256"],
        "dependency_sha256": stage["identity"]["dependency_sha256"],
    }


def _empty_repair_state() -> dict[str, Any]:
    return {
        "eligible": False,
        "attempted": False,
        "applied": False,
        "status": "not_applicable",
        "failure_stage": None,
        "failure_code": None,
        "failure_message": None,
    }


def _semantic_fields(
    *,
    case: PredictionCase,
    raw_outputs: Mapping[str, Any],
    outcomes: Mapping[str, Any],
    attempted: Mapping[str, bool],
) -> dict[str, Any]:
    """Reconstruct every final semantic field from immutable raw responses."""

    result: dict[str, Any] = {
        "status": None,
        "failure_stage": None,
        "failure_code": None,
        "failure_message": None,
        "root_cause_judgment": None,
        "judge_reported_step": None,
        "predicted_step": None,
        "predicted_event_id": None,
        "predicted_module": None,
        "predicted_error_type": None,
        "root_cause": None,
        "judge_step_matches_event_mapping": False,
        "evidence_validation_issues": [],
        "evidence_repair": _empty_repair_state(),
    }
    judge_outcome = outcomes.get(E8_STAGE)
    if not isinstance(judge_outcome, Mapping):
        raise FreshSemanticWorkflowError("E8 judge outcome is missing")
    if judge_outcome.get("status") != "success":
        if attempted.get(E8_REPAIR_STAGE):
            raise FreshSemanticWorkflowError(
                "E8 repair was attempted after judge failure"
            )
        result.update(dict(judge_outcome))
        return result

    try:
        judge_root = parse_fresh_semantic_judge(
            raw_outputs.get(E8_STAGE),
            view=case.judge_view,
        )
    except JudgeOutputError as error:
        raise FreshSemanticWorkflowError(
            "successful E8 judge raw response cannot be parsed"
        ) from error
    validation = validate_fresh_semantic_evidence(
        case.judge_view,
        judge_root,
        stage=E8_STAGE,
    )
    eligible = _repair_eligible(judge_root, case)
    if bool(attempted.get(E8_REPAIR_STAGE)) is not eligible:
        raise FreshSemanticWorkflowError(
            "E8 evidence-repair eligibility/attempt mismatch"
        )

    final_root = judge_root
    repair_state = _empty_repair_state()
    if eligible:
        repair_outcome = outcomes.get(E8_REPAIR_STAGE)
        if not isinstance(repair_outcome, Mapping):
            raise FreshSemanticWorkflowError(
                "E8 attempted repair outcome is missing"
            )
        applied = repair_outcome.get("status") == "success"
        repair_state = {
            "eligible": True,
            "attempted": True,
            "applied": applied,
            **dict(repair_outcome),
        }
        if applied:
            repair = build_fresh_evidence_repair_request(
                case.judge_view,
                judge_root,
            )
            try:
                repaired = parse_evidence_repair(
                    raw_outputs.get(E8_REPAIR_STAGE),
                    request=repair,
                )
            except JudgeOutputError as error:
                raise FreshSemanticWorkflowError(
                    "successful E8 repair raw response cannot be parsed"
                ) from error
            repaired_validation = validate_fresh_semantic_evidence(
                case.judge_view,
                repaired,
                stage=E8_REPAIR_STAGE,
            )
            if not repaired_validation.valid:
                raise FreshSemanticWorkflowError(
                    "successful E8 repair evidence is invalid"
                )
            final_root = repaired
            validation = repaired_validation
    else:
        repair_state["status"] = (
            "not_needed" if validation.valid else "not_eligible"
        )

    mapped_step = case.step_for_event(final_root.critical_event_id)
    if mapped_step != final_root.critical_step:
        raise FreshSemanticWorkflowError(
            "E8 parsed root does not map to its selected decision step"
        )
    result.update(
        {
            "root_cause_judgment": final_root.to_dict(),
            "judge_reported_step": final_root.critical_step,
            "predicted_step": mapped_step,
            "predicted_event_id": final_root.critical_event_id,
            "predicted_module": final_root.module.value,
            "predicted_error_type": final_root.error_type.value,
            "root_cause": final_root.root_cause,
            "judge_step_matches_event_mapping": True,
            "evidence_validation_issues": [
                issue.to_dict() for issue in validation.issues
            ],
            "evidence_repair": repair_state,
        }
    )
    if validation.valid:
        result["status"] = (
            "success_needs_review"
            if validation.needs_review
            else "success"
        )
    else:
        result.update(
            {
                "status": "evidence_invalid",
                "failure_stage": "evidence_validation",
                "failure_code": "invalid_evidence",
                "failure_message": (
                    "The E8 final evidence is not one strict observable "
                    "single-source substring at the selected step."
                ),
            }
        )
    return result


def _provider_capability_snapshot(judge: Any) -> dict[str, Any] | None:
    snapshotter = getattr(judge, "capability_snapshot", None)
    if not callable(snapshotter):
        return None
    value = snapshotter()
    if not isinstance(value, Mapping):
        raise FreshSemanticWorkflowError(
            "E8 provider capability snapshot must be an object"
        )
    result = dict(value)
    _assert_gold_free(result, location="E8 provider capabilities")
    return result


def _row_telemetry(
    attempted: Mapping[str, bool],
    values: Mapping[str, Any],
) -> dict[str, Any] | None:
    selected = [
        values.get(stage)
        for stage in _STAGES
        if attempted.get(stage)
    ]
    return sum_stage_telemetry(selected)


def _aggregate_telemetry(
    rows: Sequence[Mapping[str, Any]],
) -> tuple[dict[str, Any] | None, dict[str, Any]]:
    values = [
        row.get("provider_telemetry")
        for row in rows
        if row.get("provider_telemetry") is not None
    ]
    coverage = {
        "trajectory_count": len(rows),
        "covered_trajectory_count": len(values),
        "complete": len(values) == len(rows),
    }
    return (
        sum_stage_telemetry(values) if values else None,
        coverage,
    )


def _validate_provider_telemetry(
    value: Mapping[str, Any] | None,
    *,
    max_retries: int,
) -> None:
    if value is None:
        return
    for field in (
        "logical_completion_count",
        "http_attempt_count",
        "retry_count",
    ):
        counter = value.get(field)
        if (
            isinstance(counter, bool)
            or not isinstance(counter, int)
            or counter < 0
        ):
            raise FreshSemanticWorkflowError(
                f"E8 provider telemetry {field} is invalid"
            )
    logical = value["logical_completion_count"]
    http = value["http_attempt_count"]
    retries = value["retry_count"]
    if http != logical + retries or retries > logical * max_retries:
        raise FreshSemanticWorkflowError(
            "E8 telemetry violates HTTP = logical + retry or retry bound"
        )


def predict_fresh_semantic_cases(
    *,
    prediction_manifest_path: str | Path,
    preregistration_sha256: str,
    judge: Any,
    config: BenchmarkRunConfig,
    cache_dir: str | Path,
    unscored_output_path: str | Path,
    predict_run_metadata_path: str | Path,
    selected_trajectory_ids: Sequence[str] | None = None,
    max_logical_completions: int | None = None,
    logical_completion_ledger_path: str | Path | None = None,
    cumulative_logical_completions_before: int = 0,
    authorized_cumulative_ceiling: int | None = None,
    on_result: Callable[[Mapping[str, Any]], None] | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Run E8 from a gold-free manifest; this function cannot load labels."""

    preregistration_digest = _assert_sha256(
        preregistration_sha256,
        field="preregistration_sha256",
    )
    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    prediction_manifest, cases = load_prediction_manifest(manifest_path)
    if (
        config.cohort_sha256 != prediction_manifest["cohort_sha256"]
        or not config.api_key_env
    ):
        raise FreshSemanticWorkflowError(
            "E8 prediction/provider identities do not match"
        )
    selected: set[str] | None = None
    if selected_trajectory_ids is not None:
        values = [str(value) for value in selected_trajectory_ids]
        if not values or len(set(values)) != len(values):
            raise FreshSemanticWorkflowError(
                "E8 selected trajectory IDs must be unique and non-empty"
            )
        selected = set(values)
        known = {case.trajectory_id for case in cases}
        if not selected <= known:
            raise FreshSemanticWorkflowError(
                "E8 selected trajectory ID is outside the manifest"
            )
    chosen = [
        case
        for case in cases
        if selected is None or case.trajectory_id in selected
    ]
    if (
        isinstance(max_logical_completions, bool)
        or not isinstance(max_logical_completions, int)
        or max_logical_completions < 1
    ):
        raise FreshSemanticWorkflowError(
            "E8 max_logical_completions must be a positive integer"
        )
    complete = getattr(judge, "complete", None)
    if not callable(complete):
        raise TypeError("E8 prediction requires judge.complete(messages)")
    raw_snapshotter = getattr(judge, "telemetry_snapshot", None)
    telemetry_snapshotter = (
        raw_snapshotter if callable(raw_snapshotter) else None
    )
    cache_resolved = Path(cache_dir).expanduser().resolve()
    cache_root = cache_resolved / "semantic_stages"
    output_path = Path(unscored_output_path).expanduser().resolve()
    run_metadata_path = (
        Path(predict_run_metadata_path).expanduser().resolve()
    )
    if output_path.parent != run_metadata_path.parent:
        raise FreshSemanticWorkflowError(
            "E8 unscored and predict-run artifacts must share one directory"
        )
    ledger_path = (
        Path(logical_completion_ledger_path).expanduser().resolve()
        if logical_completion_ledger_path is not None
        else run_metadata_path.with_name("logical-completion-ledger.json")
    )
    if ledger_path.parent != output_path.parent:
        raise FreshSemanticWorkflowError(
            "E8 completion ledger must share the prediction output directory"
        )
    ceiling = (
        cumulative_logical_completions_before + max_logical_completions
        if authorized_cumulative_ceiling is None
        else authorized_cumulative_ceiling
    )
    budget = _LogicalBudget(
        max_logical_completions,
        ledger_path=ledger_path,
        preregistration_sha256=preregistration_digest,
        cumulative_before=cumulative_logical_completions_before,
        authorized_cumulative_ceiling=ceiling,
    )
    rows: list[dict[str, Any]] = []
    for case in chosen:
        judge_request, judge_messages = _judge_stage_request(
            case=case,
            prediction_manifest=prediction_manifest,
            config=config,
        )
        judge_stage, judge_cache_hit = run_cached_stage(
            request=judge_request,
            messages=judge_messages,
            complete=complete,
            parser=lambda raw, view=case.judge_view: (
                parse_fresh_semantic_judge(raw, view=view).to_dict()
            ),
            cache_root=cache_root,
            retry_failures=False,
            telemetry_snapshotter=telemetry_snapshotter,
            completion_guard=lambda request=judge_request: (
                budget.before_complete(
                    stage=E8_STAGE,
                    request_sha256=request.request_sha256,
                )
            ),
        )
        attempted = {E8_STAGE: True, E8_REPAIR_STAGE: False}
        cache_hits = {
            E8_STAGE: judge_cache_hit,
            E8_REPAIR_STAGE: False,
        }
        identities: dict[str, Any] = {
            E8_STAGE: _stage_identity(judge_stage),
            E8_REPAIR_STAGE: None,
        }
        outcomes: dict[str, Any] = {
            E8_STAGE: _outcome(judge_stage),
            E8_REPAIR_STAGE: None,
        }
        raw_outputs: dict[str, Any] = {
            E8_STAGE: judge_stage["raw_response"],
        }
        stage_telemetry: dict[str, Any] = {
            E8_STAGE: judge_stage["stage_telemetry"],
            E8_REPAIR_STAGE: None,
        }
        latency = float(judge_stage["latency_seconds"])

        if judge_stage["status"] == "success":
            judge_root = parse_fresh_semantic_judge(
                judge_stage["raw_response"],
                view=case.judge_view,
            )
            if _repair_eligible(judge_root, case):
                repair_request, repair_messages, repair = (
                    _repair_stage_request(
                        case=case,
                        prediction_manifest=prediction_manifest,
                        config=config,
                        judge_root=judge_root,
                        judge_raw_sha256=judge_stage[
                            "raw_response_sha256"
                        ],
                    )
                )

                def parse_repair(raw: Any) -> dict[str, Any]:
                    root = parse_evidence_repair(raw, request=repair)
                    validation = validate_fresh_semantic_evidence(
                        case.judge_view,
                        root,
                        stage=E8_REPAIR_STAGE,
                    )
                    if not validation.valid:
                        raise JudgeOutputError(
                            E8_REPAIR_STAGE,
                            "owner_evidence_quote_not_found",
                            "E8 repaired evidence failed strict validation.",
                            raw_output=raw,
                        )
                    return root.to_dict()

                repair_stage, repair_cache_hit = run_cached_stage(
                    request=repair_request,
                    messages=repair_messages,
                    complete=complete,
                    parser=parse_repair,
                    cache_root=cache_root,
                    retry_failures=False,
                    telemetry_snapshotter=telemetry_snapshotter,
                    completion_guard=lambda request=repair_request: (
                        budget.before_complete(
                            stage=E8_REPAIR_STAGE,
                            request_sha256=request.request_sha256,
                        )
                    ),
                )
                attempted[E8_REPAIR_STAGE] = True
                cache_hits[E8_REPAIR_STAGE] = repair_cache_hit
                identities[E8_REPAIR_STAGE] = _stage_identity(repair_stage)
                outcomes[E8_REPAIR_STAGE] = _outcome(repair_stage)
                raw_outputs[E8_REPAIR_STAGE] = repair_stage["raw_response"]
                stage_telemetry[E8_REPAIR_STAGE] = repair_stage[
                    "stage_telemetry"
                ]
                latency += float(repair_stage["latency_seconds"])

        semantics = _semantic_fields(
            case=case,
            raw_outputs=raw_outputs,
            outcomes=outcomes,
            attempted=attempted,
        )
        row: dict[str, Any] = {
            "schema_version": E8_PREDICTION_SCHEMA_VERSION,
            "method": E8_METHOD,
            "experiment": E8_EXPERIMENT,
            "pipeline_version": FRESH_SEMANTIC_PIPELINE_VERSION,
            "prompt_protocol_version": (
                FRESH_SEMANTIC_PROMPT_PROTOCOL_VERSION
            ),
            "evidence_repair_pipeline_version": (
                FRESH_EVIDENCE_REPAIR_PIPELINE_VERSION
            ),
            "evidence_repair_prompt_protocol_version": (
                FRESH_EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
            ),
            "evidence_repair_max_attempts": (
                FRESH_EVIDENCE_REPAIR_MAX_ATTEMPTS
            ),
            "evidence_validation_version": (
                FRESH_EVIDENCE_VALIDATION_VERSION
            ),
            "transport_policy_version": TRANSPORT_POLICY_VERSION,
            "preregistration_sha256": preregistration_digest,
            "prediction_manifest_sha256": prediction_manifest[
                "prediction_manifest_sha256"
            ],
            "trajectory_id": case.trajectory_id,
            "trajectory_sha256": case.trajectory_sha256,
            "case_input_sha256": case.case_input_sha256,
            "provider_config": config.public_dict(),
            "cache_dir": str(cache_resolved),
            "stage_attempted": attempted,
            "stage_cache_hits": cache_hits,
            "stage_identities": identities,
            "stage_outcomes": outcomes,
            "stage_provider_telemetry": stage_telemetry,
            "raw_judge_outputs": raw_outputs,
            "provider_telemetry": _row_telemetry(
                attempted,
                stage_telemetry,
            ),
            "latency_seconds": latency,
            "cache_hit": all(
                cache_hits[stage] for stage in _STAGES if attempted[stage]
            ),
            **semantics,
        }
        _assert_gold_free(row, location="E8 unscored prediction")
        row["unscored_prediction_sha256"] = stable_sha256(row)
        rows.append(row)
        _atomic_jsonl(output_path, rows)
        if on_result is not None:
            on_result(row)

    telemetry, coverage = _aggregate_telemetry(rows)
    if coverage["complete"]:
        _validate_provider_telemetry(
            telemetry,
            max_retries=config.max_retries,
        )
    ledger = budget.snapshot
    metadata = _document_with_hash(
        {
            "schema_version": E8_PREDICT_RUN_SCHEMA_VERSION,
            "method": E8_METHOD,
            "experiment": E8_EXPERIMENT,
            "pipeline_version": FRESH_SEMANTIC_PIPELINE_VERSION,
            "prompt_protocol_version": (
                FRESH_SEMANTIC_PROMPT_PROTOCOL_VERSION
            ),
            "evidence_repair_pipeline_version": (
                FRESH_EVIDENCE_REPAIR_PIPELINE_VERSION
            ),
            "evidence_repair_prompt_protocol_version": (
                FRESH_EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
            ),
            "evidence_repair_max_attempts": (
                FRESH_EVIDENCE_REPAIR_MAX_ATTEMPTS
            ),
            "evidence_validation_version": (
                FRESH_EVIDENCE_VALIDATION_VERSION
            ),
            "transport_policy_version": TRANSPORT_POLICY_VERSION,
            "preregistration_sha256": preregistration_digest,
            "prediction_manifest_path": str(manifest_path),
            "prediction_manifest_file_sha256": _file_sha256(manifest_path),
            "prediction_manifest_sha256": prediction_manifest[
                "prediction_manifest_sha256"
            ],
            "unscored_predictions_path": str(output_path),
            "unscored_predictions_sha256": _file_sha256(output_path),
            "predict_run_metadata_path": str(run_metadata_path),
            "run_output_dir": str(output_path.parent),
            "cache_dir": str(cache_resolved),
            "selected_trajectory_ids": [
                case.trajectory_id for case in chosen
            ],
            "prediction_count": len(rows),
            "provider_config": config.public_dict(),
            "provider_telemetry": telemetry,
            "provider_telemetry_coverage": coverage,
            "provider_capabilities": _provider_capability_snapshot(judge),
            "repair_eligible_count": sum(
                bool(row["evidence_repair"]["eligible"]) for row in rows
            ),
            "repair_attempt_count": sum(
                bool(row["evidence_repair"]["attempted"]) for row in rows
            ),
            "repair_applied_count": sum(
                bool(row["evidence_repair"]["applied"]) for row in rows
            ),
            "semantic_mutation_count": 0,
            "max_logical_completions": max_logical_completions,
            "logical_completion_budget_used": len(ledger["entries"]),
            "logical_completion_ledger_path": str(ledger_path),
            "logical_completion_ledger_file_sha256": _file_sha256(
                ledger_path
            ),
            "logical_completion_ledger_sha256": ledger["ledger_sha256"],
            "retry_failures": False,
        },
        hash_field="predict_run_sha256",
    )
    _assert_gold_free(metadata, location="E8 predict run")
    _atomic_json(
        run_metadata_path,
        metadata,
    )
    return rows, metadata


def _validate_stage_identity(
    *,
    persisted: Any,
    request: Any,
    raw: Any,
) -> None:
    expected = {
        "request_sha256": request.request_sha256,
        "prompt_sha256": request.prompt_sha256,
        "raw_response_sha256": stage_sha256(raw),
        "dependency_sha256": request.identity["dependency_sha256"],
    }
    if persisted != expected:
        raise FreshSemanticWorkflowError(
            "E8 persisted stage identity diverges from raw request"
        )


def _validate_unscored_row(
    row: Mapping[str, Any],
    *,
    case: PredictionCase,
    prediction_manifest: Mapping[str, Any],
    config: BenchmarkRunConfig,
    preregistration_sha256: str,
    cache_dir: Path,
) -> dict[str, Any]:
    value = dict(row)
    if set(value) != _ROW_FIELDS:
        raise FreshSemanticWorkflowError(
            "E8 unscored prediction fields are invalid"
        )
    claimed = value.pop("unscored_prediction_sha256", None)
    if claimed != stable_sha256(value):
        raise FreshSemanticWorkflowError(
            "E8 unscored prediction hash is invalid"
        )
    value["unscored_prediction_sha256"] = claimed
    identity_checks = {
        "schema_version": E8_PREDICTION_SCHEMA_VERSION,
        "method": E8_METHOD,
        "experiment": E8_EXPERIMENT,
        "pipeline_version": FRESH_SEMANTIC_PIPELINE_VERSION,
        "prompt_protocol_version": (
            FRESH_SEMANTIC_PROMPT_PROTOCOL_VERSION
        ),
        "evidence_repair_pipeline_version": (
            FRESH_EVIDENCE_REPAIR_PIPELINE_VERSION
        ),
        "evidence_repair_prompt_protocol_version": (
            FRESH_EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
        ),
        "evidence_repair_max_attempts": (
            FRESH_EVIDENCE_REPAIR_MAX_ATTEMPTS
        ),
        "evidence_validation_version": FRESH_EVIDENCE_VALIDATION_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "preregistration_sha256": preregistration_sha256,
        "prediction_manifest_sha256": prediction_manifest[
            "prediction_manifest_sha256"
        ],
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "case_input_sha256": case.case_input_sha256,
        "provider_config": config.public_dict(),
        "cache_dir": str(cache_dir),
    }
    if any(
        value.get(field) != expected
        for field, expected in identity_checks.items()
    ):
        raise FreshSemanticWorkflowError(
            "E8 unscored prediction identity is invalid"
        )
    attempted = value.get("stage_attempted")
    cache_hits = value.get("stage_cache_hits")
    identities = value.get("stage_identities")
    outcomes = value.get("stage_outcomes")
    telemetry = value.get("stage_provider_telemetry")
    raw_outputs = value.get("raw_judge_outputs")
    if any(
        not isinstance(item, Mapping) or set(item) != set(_STAGES)
        for item in (
            attempted,
            cache_hits,
            identities,
            outcomes,
            telemetry,
        )
    ) or not isinstance(raw_outputs, Mapping):
        raise FreshSemanticWorkflowError("E8 stage envelopes are invalid")
    if attempted[E8_STAGE] is not True or any(
        not isinstance(attempted[stage], bool)
        or not isinstance(cache_hits[stage], bool)
        for stage in _STAGES
    ):
        raise FreshSemanticWorkflowError("E8 stage flags are invalid")
    expected_raw = {stage for stage in _STAGES if attempted[stage]}
    if set(raw_outputs) != expected_raw:
        raise FreshSemanticWorkflowError(
            "E8 raw outputs do not match attempted stages"
        )

    judge_request, _ = _judge_stage_request(
        case=case,
        prediction_manifest=prediction_manifest,
        config=config,
    )
    _validate_stage_identity(
        persisted=identities[E8_STAGE],
        request=judge_request,
        raw=raw_outputs[E8_STAGE],
    )
    if attempted[E8_REPAIR_STAGE]:
        if outcomes[E8_STAGE].get("status") != "success":
            raise FreshSemanticWorkflowError(
                "E8 repair follows an unsuccessful semantic judgment"
            )
        judge_root = parse_fresh_semantic_judge(
            raw_outputs[E8_STAGE],
            view=case.judge_view,
        )
        repair_request, _, _ = _repair_stage_request(
            case=case,
            prediction_manifest=prediction_manifest,
            config=config,
            judge_root=judge_root,
            judge_raw_sha256=stage_sha256(raw_outputs[E8_STAGE]),
        )
        _validate_stage_identity(
            persisted=identities[E8_REPAIR_STAGE],
            request=repair_request,
            raw=raw_outputs[E8_REPAIR_STAGE],
        )
    elif any(
        item is not None
        for item in (
            identities[E8_REPAIR_STAGE],
            outcomes[E8_REPAIR_STAGE],
            telemetry[E8_REPAIR_STAGE],
        )
    ) or cache_hits[E8_REPAIR_STAGE]:
        raise FreshSemanticWorkflowError(
            "unattempted E8 repair contains persisted state"
        )

    semantics = _semantic_fields(
        case=case,
        raw_outputs=raw_outputs,
        outcomes=outcomes,
        attempted=attempted,
    )
    for field, expected in semantics.items():
        if value.get(field) != expected:
            raise FreshSemanticWorkflowError(
                f"E8 {field} diverges from raw semantic chain"
            )
    expected_telemetry = _row_telemetry(attempted, telemetry)
    if value.get("provider_telemetry") != expected_telemetry:
        raise FreshSemanticWorkflowError(
            "E8 row telemetry diverges from stage telemetry"
        )
    _validate_provider_telemetry(
        expected_telemetry,
        max_retries=config.max_retries,
    )
    expected_cache_hit = all(
        cache_hits[stage] for stage in _STAGES if attempted[stage]
    )
    if value.get("cache_hit") is not expected_cache_hit:
        raise FreshSemanticWorkflowError(
            "E8 cache-hit summary is invalid"
        )
    if (
        isinstance(value.get("latency_seconds"), bool)
        or not isinstance(value.get("latency_seconds"), (int, float))
        or value["latency_seconds"] < 0
    ):
        raise FreshSemanticWorkflowError("E8 latency is invalid")

    for stage in _STAGES:
        outcome = outcomes[stage]
        if attempted[stage]:
            if (
                not isinstance(outcome, Mapping)
                or set(outcome) != _OUTCOME_FIELDS
                or not isinstance(outcome.get("status"), str)
                or not outcome["status"]
            ):
                raise FreshSemanticWorkflowError(
                    f"E8 {stage} outcome is invalid"
                )
        elif outcome is not None:
            raise FreshSemanticWorkflowError(
                f"unattempted E8 {stage} has an outcome"
            )

    try:
        parsed_judge = parse_fresh_semantic_judge(
            raw_outputs[E8_STAGE],
            view=case.judge_view,
        )
    except JudgeOutputError:
        parsed_judge = None
    if (
        outcomes[E8_STAGE]["status"] == "success"
    ) is not (parsed_judge is not None):
        raise FreshSemanticWorkflowError(
            "E8 judge outcome does not match its raw response"
        )
    if attempted[E8_REPAIR_STAGE]:
        valid_repair = False
        if parsed_judge is not None:
            repair = build_fresh_evidence_repair_request(
                case.judge_view,
                parsed_judge,
            )
            try:
                repaired = parse_evidence_repair(
                    raw_outputs[E8_REPAIR_STAGE],
                    request=repair,
                )
            except JudgeOutputError:
                repaired = None
            if repaired is not None:
                valid_repair = validate_fresh_semantic_evidence(
                    case.judge_view,
                    repaired,
                    stage=E8_REPAIR_STAGE,
                ).valid
        if (
            outcomes[E8_REPAIR_STAGE]["status"] == "success"
        ) is not valid_repair:
            raise FreshSemanticWorkflowError(
                "E8 repair outcome does not match its raw response"
            )
    _assert_gold_free(value, location="E8 unscored prediction")
    return value


def validate_partial_fresh_semantic_predictions(
    *,
    prediction_manifest_path: str | Path,
    unscored_predictions_path: str | Path,
    preregistration_sha256: str,
    cache_dir: str | Path,
    config: BenchmarkRunConfig,
    selected_trajectory_ids: Sequence[str],
) -> list[dict[str, Any]]:
    """Validate a crash-recovery JSONL prefix without loading benchmark gold."""

    manifest, cases = load_prediction_manifest(prediction_manifest_path)
    requested = [str(value) for value in selected_trajectory_ids]
    selected = set(requested)
    chosen = [case for case in cases if case.trajectory_id in selected]
    if (
        not requested
        or len(selected) != len(requested)
        or [case.trajectory_id for case in chosen] != requested
    ):
        raise FreshSemanticWorkflowError(
            "E8 partial prediction selection is invalid"
        )
    path = Path(unscored_predictions_path).expanduser().resolve()
    if not path.is_file():
        return []
    rows = _read_jsonl(path)
    if (
        len(rows) > len(chosen)
        or [row.get("trajectory_id") for row in rows]
        != [case.trajectory_id for case in chosen[: len(rows)]]
    ):
        raise FreshSemanticWorkflowError(
            "E8 partial predictions are not a manifest-order prefix"
        )
    cache_resolved = Path(cache_dir).expanduser().resolve()
    return [
        _validate_unscored_row(
            row,
            case=case,
            prediction_manifest=manifest,
            config=config,
            preregistration_sha256=preregistration_sha256,
            cache_dir=cache_resolved,
        )
        for row, case in zip(rows, chosen, strict=False)
    ]


def validate_fresh_semantic_judge_cache(
    *,
    prediction_manifest_path: str | Path,
    unscored_predictions_path: str | Path,
    predict_run_metadata_path: str | Path,
    cache_dir: str | Path,
    selected_trajectory_ids: Sequence[str],
) -> tuple[str, ...]:
    """Prove that selected judge requests are recoverable without a call."""

    (
        manifest,
        cases,
        rows,
        _,
        config,
    ) = validate_fresh_semantic_artifacts(
        prediction_manifest_path=prediction_manifest_path,
        unscored_predictions_path=unscored_predictions_path,
        predict_run_metadata_path=predict_run_metadata_path,
    )
    cases_by_id = {case.trajectory_id: case for case in cases}
    rows_by_id = {row["trajectory_id"]: row for row in rows}
    selected = [str(value) for value in selected_trajectory_ids]
    if (
        not selected
        or len(set(selected)) != len(selected)
        or any(
            trajectory_id not in cases_by_id
            or trajectory_id not in rows_by_id
            for trajectory_id in selected
        )
    ):
        raise FreshSemanticWorkflowError(
            "E8 judge-cache validation selection is invalid"
        )
    cache_root = (
        Path(cache_dir).expanduser().resolve() / "semantic_stages"
    )
    request_digests: list[str] = []
    for trajectory_id in selected:
        case = cases_by_id[trajectory_id]
        row = rows_by_id[trajectory_id]
        request, messages = _judge_stage_request(
            case=case,
            prediction_manifest=manifest,
            config=config,
        )

        def reject_provider_call() -> None:
            raise FreshSemanticWorkflowError(
                "E8 required predecessor judge cache is unavailable"
            )

        def forbidden_complete(_: list[dict[str, str]]) -> Any:
            raise AssertionError(
                "provider call is forbidden during E8 cache proof"
            )

        stage, cache_hit = run_cached_stage(
            request=request,
            messages=messages,
            complete=forbidden_complete,
            parser=lambda raw, view=case.judge_view: (
                parse_fresh_semantic_judge(raw, view=view).to_dict()
            ),
            cache_root=cache_root,
            retry_failures=False,
            completion_guard=reject_provider_call,
        )
        if (
            not cache_hit
            or row["stage_attempted"].get(E8_STAGE) is not True
            or row["stage_identities"].get(E8_STAGE)
            != _stage_identity(stage)
            or row["stage_outcomes"].get(E8_STAGE) != _outcome(stage)
            or row["raw_judge_outputs"].get(E8_STAGE)
            != stage["raw_response"]
        ):
            raise FreshSemanticWorkflowError(
                "E8 predecessor judge cache diverges from its raw run"
            )
        request_digests.append(request.request_sha256)
    return tuple(request_digests)


def fresh_semantic_judge_request_sha256s(
    *,
    prediction_manifest_path: str | Path,
    config: BenchmarkRunConfig,
    selected_trajectory_ids: Sequence[str],
) -> tuple[str, ...]:
    """Rebuild selected E8 judge request identities without a provider."""

    manifest, cases = load_prediction_manifest(prediction_manifest_path)
    selected = [str(value) for value in selected_trajectory_ids]
    selected_set = set(selected)
    chosen = [
        case for case in cases if case.trajectory_id in selected_set
    ]
    if (
        not selected
        or len(selected_set) != len(selected)
        or [case.trajectory_id for case in chosen] != selected
        or config.cohort_sha256 != manifest["cohort_sha256"]
    ):
        raise FreshSemanticWorkflowError(
            "E8 judge-request identity selection is invalid"
        )
    return tuple(
        _judge_stage_request(
            case=case,
            prediction_manifest=manifest,
            config=config,
        )[0].request_sha256
        for case in chosen
    )


def _load_predict_run(
    *,
    path: str | Path,
    prediction_manifest_path: Path,
    unscored_path: Path,
    rows: Sequence[Mapping[str, Any]],
    prediction_manifest: Mapping[str, Any],
    config: BenchmarkRunConfig,
    preregistration_sha256: str,
    cache_dir: Path,
) -> dict[str, Any]:
    run_path = Path(path).expanduser().resolve()
    run = _read_object(run_path, location="E8 predict run")
    if set(run) != _RUN_FIELDS:
        raise FreshSemanticWorkflowError(
            "E8 predict-run fields are invalid"
        )
    body = dict(run)
    claimed = body.pop("predict_run_sha256", None)
    if claimed != stable_sha256(body):
        raise FreshSemanticWorkflowError(
            "E8 predict-run hash is invalid"
        )
    checks = {
        "schema_version": E8_PREDICT_RUN_SCHEMA_VERSION,
        "method": E8_METHOD,
        "experiment": E8_EXPERIMENT,
        "pipeline_version": FRESH_SEMANTIC_PIPELINE_VERSION,
        "prompt_protocol_version": (
            FRESH_SEMANTIC_PROMPT_PROTOCOL_VERSION
        ),
        "evidence_repair_pipeline_version": (
            FRESH_EVIDENCE_REPAIR_PIPELINE_VERSION
        ),
        "evidence_repair_prompt_protocol_version": (
            FRESH_EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
        ),
        "evidence_repair_max_attempts": (
            FRESH_EVIDENCE_REPAIR_MAX_ATTEMPTS
        ),
        "evidence_validation_version": FRESH_EVIDENCE_VALIDATION_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "preregistration_sha256": preregistration_sha256,
        "prediction_manifest_path": str(prediction_manifest_path),
        "prediction_manifest_file_sha256": _file_sha256(
            prediction_manifest_path
        ),
        "prediction_manifest_sha256": prediction_manifest[
            "prediction_manifest_sha256"
        ],
        "unscored_predictions_path": str(unscored_path),
        "unscored_predictions_sha256": _file_sha256(unscored_path),
        "predict_run_metadata_path": str(run_path),
        "run_output_dir": str(unscored_path.parent),
        "cache_dir": str(cache_dir),
        "prediction_count": len(rows),
        "provider_config": config.public_dict(),
        "retry_failures": False,
        "semantic_mutation_count": 0,
    }
    if any(run.get(field) != expected for field, expected in checks.items()):
        raise FreshSemanticWorkflowError(
            "E8 predict-run identity is invalid"
        )
    selected = run.get("selected_trajectory_ids")
    if (
        not isinstance(selected, list)
        or selected != [row.get("trajectory_id") for row in rows]
        or len(set(selected)) != len(selected)
    ):
        raise FreshSemanticWorkflowError(
            "E8 predict-run selection is invalid"
        )
    telemetry, coverage = _aggregate_telemetry(rows)
    if (
        run.get("provider_telemetry") != telemetry
        or run.get("provider_telemetry_coverage") != coverage
        or run.get("repair_eligible_count")
        != sum(bool(row["evidence_repair"]["eligible"]) for row in rows)
        or run.get("repair_attempt_count")
        != sum(bool(row["evidence_repair"]["attempted"]) for row in rows)
        or run.get("repair_applied_count")
        != sum(bool(row["evidence_repair"]["applied"]) for row in rows)
    ):
        raise FreshSemanticWorkflowError(
            "E8 predict-run aggregates are invalid"
        )
    if coverage["complete"]:
        _validate_provider_telemetry(
            telemetry,
            max_retries=config.max_retries,
        )
    maximum = run.get("max_logical_completions")
    used = run.get("logical_completion_budget_used")
    ledger_path_value = run.get("logical_completion_ledger_path")
    expected_ledger_path = (
        Path(ledger_path_value).expanduser().resolve()
        if isinstance(ledger_path_value, str)
        else run_path.parent / "<invalid-ledger-path>"
    )
    if (
        (
            maximum is not None
            and (
                isinstance(maximum, bool)
                or not isinstance(maximum, int)
                or maximum < 1
            )
        )
        or isinstance(used, bool)
        or not isinstance(used, int)
        or used < 0
        or (maximum is not None and used > maximum)
        or expected_ledger_path.parent != run_path.parent
        or ledger_path_value != str(expected_ledger_path)
    ):
        raise FreshSemanticWorkflowError(
            "E8 logical-completion budget metadata is invalid"
        )
    ledger = load_fresh_semantic_completion_ledger(
        expected_ledger_path,
        preregistration_sha256=preregistration_sha256,
        maximum_new=maximum,
    )
    if (
        run.get("logical_completion_ledger_file_sha256")
        != _file_sha256(expected_ledger_path)
        or run.get("logical_completion_ledger_sha256")
        != ledger["ledger_sha256"]
        or used != len(ledger["entries"])
    ):
        raise FreshSemanticWorkflowError(
            "E8 logical-completion ledger diverges from predict-run metadata"
        )
    attempted_requests = {
        (
            stage,
            row["stage_identities"][stage]["request_sha256"],
        )
        for row in rows
        for stage in _STAGES
        if row["stage_attempted"][stage]
    }
    ledger_requests = [
        (entry["stage"], entry["request_sha256"])
        for entry in ledger["entries"]
    ]
    cache_miss_requests = {
        (
            stage,
            row["stage_identities"][stage]["request_sha256"],
        )
        for row in rows
        for stage in _STAGES
        if row["stage_attempted"][stage]
        and not row["stage_cache_hits"][stage]
    }
    if (
        any(request not in attempted_requests for request in ledger_requests)
        or not cache_miss_requests <= set(ledger_requests)
    ):
        raise FreshSemanticWorkflowError(
            "E8 logical-completion ledger diverges from attempted stages"
        )
    _assert_gold_free(run, location="E8 predict run")
    return run


def validate_fresh_semantic_artifacts(
    *,
    prediction_manifest_path: str | Path,
    unscored_predictions_path: str | Path,
    predict_run_metadata_path: str | Path,
) -> tuple[
    dict[str, Any],
    list[PredictionCase],
    list[dict[str, Any]],
    dict[str, Any],
    BenchmarkRunConfig,
]:
    """Reconstruct one complete gold-free E8 prediction artifact chain."""

    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    prediction_manifest, cases = load_prediction_manifest(manifest_path)
    unscored_path = (
        Path(unscored_predictions_path).expanduser().resolve()
    )
    rows = _read_jsonl(unscored_path)
    if not rows:
        raise FreshSemanticWorkflowError(
            "E8 has no unscored predictions"
        )
    first_config = rows[0].get("provider_config")
    if not isinstance(first_config, Mapping):
        raise FreshSemanticWorkflowError(
            "E8 prediction provider config is missing"
        )
    try:
        config = BenchmarkRunConfig(**dict(first_config))
    except (TypeError, ValueError) as error:
        raise FreshSemanticWorkflowError(
            "E8 prediction provider config is invalid"
        ) from error
    preregistration_sha256 = _assert_sha256(
        rows[0].get("preregistration_sha256"),
        field="preregistration_sha256",
    )
    raw_cache_dir = rows[0].get("cache_dir")
    if not isinstance(raw_cache_dir, str) or not raw_cache_dir:
        raise FreshSemanticWorkflowError(
            "E8 prediction cache directory is missing"
        )
    cache_dir = Path(raw_cache_dir).expanduser().resolve()
    if str(cache_dir) != raw_cache_dir:
        raise FreshSemanticWorkflowError(
            "E8 prediction cache directory is not canonical"
        )
    if config.cohort_sha256 != prediction_manifest["cohort_sha256"]:
        raise FreshSemanticWorkflowError(
            "E8 prediction provider/cohort identity is invalid"
        )
    by_case = {case.trajectory_id: case for case in cases}
    row_ids = [str(row.get("trajectory_id")) for row in rows]
    expected_order = [
        case.trajectory_id
        for case in cases
        if case.trajectory_id in set(row_ids)
    ]
    if (
        len(set(row_ids)) != len(row_ids)
        or not set(row_ids) <= set(by_case)
        or row_ids != expected_order
    ):
        raise FreshSemanticWorkflowError(
            "E8 unscored identities are duplicated, unknown, or out of order"
        )
    validated = [
        _validate_unscored_row(
            row,
            case=by_case[str(row["trajectory_id"])],
            prediction_manifest=prediction_manifest,
            config=config,
            preregistration_sha256=preregistration_sha256,
            cache_dir=cache_dir,
        )
        for row in rows
    ]
    run = _load_predict_run(
        path=predict_run_metadata_path,
        prediction_manifest_path=manifest_path,
        unscored_path=unscored_path,
        rows=validated,
        prediction_manifest=prediction_manifest,
        config=config,
        preregistration_sha256=preregistration_sha256,
        cache_dir=cache_dir,
    )
    return prediction_manifest, cases, validated, run, config


def score_fresh_semantic_predictions(
    *,
    dataset: BenchmarkDataset,
    cohort: CohortManifest,
    prediction_manifest_path: str | Path,
    unscored_predictions_path: str | Path,
    predict_run_metadata_path: str | Path,
) -> tuple[list[dict[str, Any]], dict[str, Any], dict[str, Any]]:
    """Validate the complete raw chain before joining benchmark gold."""

    (
        prediction_manifest,
        cases,
        validated,
        run,
        config,
    ) = validate_fresh_semantic_artifacts(
        prediction_manifest_path=prediction_manifest_path,
        unscored_predictions_path=unscored_predictions_path,
        predict_run_metadata_path=predict_run_metadata_path,
    )
    if (
        dataset.dataset_sha256
        != prediction_manifest["dataset_manifest_sha256"]
        or cohort.dataset_manifest_sha256
        != prediction_manifest["dataset_manifest_sha256"]
        or cohort.cohort_name != prediction_manifest["cohort_name"]
        or cohort.cohort_sha256 != prediction_manifest["cohort_sha256"]
    ):
        raise FreshSemanticWorkflowError(
            "E8 scoring dataset/cohort lineage is invalid"
        )
    by_case = {case.trajectory_id: case for case in cases}
    if not {
        str(row["trajectory_id"]) for row in validated
    } <= set(cohort.trajectory_ids):
        raise FreshSemanticWorkflowError(
            "E8 unscored identities are outside the scoring cohort"
        )

    # Gold is first touched here, after every raw response, prompt identity,
    # repair, artifact hash, and run aggregate has been reconstructed.
    examples = {
        example.label.trajectory_id: example for example in dataset.examples
    }
    scored: list[dict[str, Any]] = []
    for row in validated:
        trajectory_id = str(row["trajectory_id"])
        example = examples.get(trajectory_id)
        if example is None:
            raise FreshSemanticWorkflowError(
                "E8 trajectory has no benchmark scoring example"
            )
        case = by_case[trajectory_id]
        if (
            example.mapping.trajectory_sha256 != case.trajectory_sha256
            or tuple(
                (item.original_step, item.critical_event_id)
                for item in example.mapping.steps
            )
            != case.step_event_mapping
        ):
            raise FreshSemanticWorkflowError(
                "E8 scoring adaptation diverges from prediction manifest"
            )
        record = _base_record(
            example,
            method=E8_METHOD,
            config=config,
        )
        record.update(
            {
                "status": row["status"],
                "failure_stage": row["failure_stage"],
                "failure_code": row["failure_code"],
                "failure_message": row["failure_message"],
                "root_cause_judgment": row["root_cause_judgment"],
                "evidence_validation_issues": row[
                    "evidence_validation_issues"
                ],
                "evidence_repair": row["evidence_repair"],
                "raw_judge_outputs": row["raw_judge_outputs"],
                "stage_attempted": row["stage_attempted"],
                "stage_cache_hits": row["stage_cache_hits"],
                "stage_identities": row["stage_identities"],
                "stage_outcomes": row["stage_outcomes"],
                "stage_provider_telemetry": row[
                    "stage_provider_telemetry"
                ],
                "provider_telemetry": row["provider_telemetry"],
                "latency_seconds": row["latency_seconds"],
                "cache_hit": row["cache_hit"],
                "prompt_version": (
                    FRESH_SEMANTIC_PROMPT_PROTOCOL_VERSION
                ),
                "pipeline_version": FRESH_SEMANTIC_PIPELINE_VERSION,
                "experiment": E8_EXPERIMENT,
                "semantic_classifier": "fresh_llm_raw_output",
                "prior_root": None,
                "preregistration_sha256": row[
                    "preregistration_sha256"
                ],
                "prediction_manifest_sha256": row[
                    "prediction_manifest_sha256"
                ],
                "cache_dir": row["cache_dir"],
                "unscored_prediction_sha256": row[
                    "unscored_prediction_sha256"
                ],
                "judge_step_matches_event_mapping": row[
                    "judge_step_matches_event_mapping"
                ],
            }
        )
        if row["root_cause_judgment"] is not None:
            root = parse_fresh_semantic_judge(
                json.dumps(
                    _public_root(
                        parse_fresh_semantic_judge(
                            row["raw_judge_outputs"][E8_STAGE],
                            view=case.judge_view,
                        )
                    ),
                    ensure_ascii=False,
                ),
                view=case.judge_view,
            )
            if row["evidence_repair"]["applied"]:
                request = build_fresh_evidence_repair_request(
                    case.judge_view,
                    root,
                )
                root = parse_evidence_repair(
                    row["raw_judge_outputs"][E8_REPAIR_STAGE],
                    request=request,
                )
            _apply_root(record, example=example, root=root)
        scored.append(record)
    metrics = compute_metrics(scored)
    return scored, metrics, run


__all__ = [
    "E8_EXPERIMENT",
    "E8_LOGICAL_COMPLETION_LEDGER_SCHEMA_VERSION",
    "E8_METHOD",
    "E8_PREDICTION_SCHEMA_VERSION",
    "E8_PREDICT_RUN_SCHEMA_VERSION",
    "E8_REPAIR_STAGE",
    "E8_STAGE",
    "DurableLogicalCompletionBudget",
    "FreshSemanticWorkflowError",
    "initialize_fresh_semantic_completion_ledger",
    "load_fresh_semantic_completion_ledger",
    "fresh_semantic_judge_request_sha256s",
    "predict_fresh_semantic_cases",
    "score_fresh_semantic_predictions",
    "validate_fresh_semantic_artifacts",
    "validate_fresh_semantic_judge_cache",
    "validate_partial_fresh_semantic_predictions",
]

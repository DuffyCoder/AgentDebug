"""Four-command CLI for the E9 v55 one-stage global judge.

``predict`` intentionally has no dataset, cohort, label, or scored-artifact
argument.  ``score`` validates the raw chain before loading benchmark gold.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from agentdebug.diagnostics.providers import OpenAICompatibleJudge

from .cohort import load_cohort_manifest
from .dataset import load_agent_error_bench
from .reporting import write_outputs
from .runner import BenchmarkRunConfig
from .simple_global_preregistration import (
    SimpleGlobalPreregistrationError,
    verify_simple_global_preregistration,
    verify_simple_global_promotion,
    write_simple_global_preregistration,
)
from .simple_global_workflow import (
    SIMPLE_GLOBAL_EXPERIMENT,
    SimpleGlobalWorkflowError,
    predict_simple_global_cases,
    score_simple_global_predictions,
    validate_simple_global_artifacts,
    write_simple_global_batch_plan,
)


FIXED_PROVIDER = "openai-compatible"
FIXED_BASE_URL = "https://api.deepseek.com/v1/chat/completions"
FIXED_API_KEY_ENV = "DEEPSEEK_API_KEY"
FIXED_MODEL = "deepseek-v4-flash"
FIXED_TEMPERATURE = 0.0
FIXED_TIMEOUT = 600.0
FIXED_MAX_OUTPUT_TOKENS = 8192
FIXED_MAX_RETRIES = 5
FIXED_RETRY_BACKOFF = 2.0
FIXED_REQUEST_BODY_MODE = "default"


class SimpleGlobalCLIError(ValueError):
    """One safe user-facing CLI failure."""


class _Parser(argparse.ArgumentParser):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        kwargs.setdefault("allow_abbrev", False)
        super().__init__(*args, **kwargs)

    def error(self, message: str) -> None:  # noqa: ARG002
        raise SimpleGlobalCLIError("invalid command arguments")


def _parser() -> argparse.ArgumentParser:
    parser = _Parser(
        prog="python -m agentdebug.benchmark.simple_global_cli",
        description="Plan, preregister, predict, score, and gate E9 v55.",
    )
    commands = parser.add_subparsers(dest="command", required=True)

    plan = commands.add_parser("plan", help="Freeze gold-free batches.")
    plan.add_argument("--prediction-manifest", required=True)
    plan.add_argument("--output", required=True)
    plan.add_argument("--trajectory-id", action="append", default=[])

    preregister = commands.add_parser(
        "preregister", help="Freeze inputs, code, provider, paths, budget, and gate."
    )
    preregister.add_argument("--prediction-manifest", required=True)
    preregister.add_argument("--batch-plan", required=True)
    preregister.add_argument("--run-output-dir", required=True)
    preregister.add_argument("--cache-dir", required=True)
    preregister.add_argument("--output", required=True)
    preregister.add_argument(
        "--gate-profile", choices=("dry3", "full30", "smoke30"), required=True
    )
    preregister.add_argument("--hypothesis", required=True)
    preregister.add_argument("--selection-rule", required=True)
    preregister.add_argument(
        "--cumulative-logical-completions-before", type=int, required=True
    )
    preregister.add_argument("--historical-rejection")

    predict = commands.add_parser(
        "predict",
        help="Run from gold-free manifest, plan, and preregistration only.",
    )
    predict.add_argument("--prediction-manifest", required=True)
    predict.add_argument("--batch-plan", required=True)
    predict.add_argument("--preregistration", required=True)
    predict.add_argument("--run-output-dir", required=True)
    predict.add_argument("--cache-dir", required=True)

    score = commands.add_parser(
        "score", help="Validate raw artifacts, then load gold and score."
    )
    score.add_argument("--dataset", required=True)
    score.add_argument("--cohort-manifest", required=True)
    score.add_argument("--prediction-manifest", required=True)
    score.add_argument("--batch-plan", required=True)
    score.add_argument("--unscored-predictions", required=True)
    score.add_argument("--predict-run", required=True)
    score.add_argument("--output-dir", required=True)

    gate = commands.add_parser("gate", help="Write the immutable promotion result.")
    gate.add_argument("--preregistration", required=True)
    gate.add_argument("--metrics", required=True)
    gate.add_argument("--predictions", required=True)
    gate.add_argument("--output", required=True)
    return parser


def _load_manifest(path: str | Path) -> dict[str, Any]:
    from .prediction_manifest import load_prediction_manifest

    manifest, _cases = load_prediction_manifest(path)
    return manifest


def _config(manifest: Mapping[str, Any]) -> BenchmarkRunConfig:
    return BenchmarkRunConfig(
        model=FIXED_MODEL,
        temperature=FIXED_TEMPERATURE,
        provider=FIXED_PROVIDER,
        endpoint=FIXED_BASE_URL,
        timeout=FIXED_TIMEOUT,
        max_output_tokens=FIXED_MAX_OUTPUT_TOKENS,
        max_retries=FIXED_MAX_RETRIES,
        retry_backoff=FIXED_RETRY_BACKOFF,
        cohort_sha256=str(manifest["cohort_sha256"]),
        api_key_env=FIXED_API_KEY_ENV,
        thinking_mode=None,
        request_body_mode=FIXED_REQUEST_BODY_MODE,
    )


def _judge() -> OpenAICompatibleJudge:
    return OpenAICompatibleJudge(
        base_url=FIXED_BASE_URL,
        api_key_env=FIXED_API_KEY_ENV,
        model=FIXED_MODEL,
        temperature=FIXED_TEMPERATURE,
        timeout=FIXED_TIMEOUT,
        max_output_tokens=FIXED_MAX_OUTPUT_TOKENS,
        max_retries=FIXED_MAX_RETRIES,
        retry_backoff=FIXED_RETRY_BACKOFF,
        thinking_mode=None,
        request_body_mode=FIXED_REQUEST_BODY_MODE,
    )


def _plan(args: argparse.Namespace) -> dict[str, Any]:
    plan = write_simple_global_batch_plan(
        prediction_manifest_path=args.prediction_manifest,
        output_path=args.output,
        selected_trajectory_ids=(args.trajectory_id or None),
    )
    return plan.to_dict()


def _preregister(args: argparse.Namespace) -> dict[str, Any]:
    manifest = _load_manifest(args.prediction_manifest)
    return write_simple_global_preregistration(
        prediction_manifest_path=args.prediction_manifest,
        batch_plan_path=args.batch_plan,
        run_output_dir=args.run_output_dir,
        cache_dir=args.cache_dir,
        output_path=args.output,
        config=_config(manifest),
        gate_profile=args.gate_profile,
        hypothesis=args.hypothesis,
        selection_rule=args.selection_rule,
        cumulative_logical_completions_before=(
            args.cumulative_logical_completions_before
        ),
        historical_rejection_path=args.historical_rejection,
    )


def _predict(args: argparse.Namespace) -> dict[str, Any]:
    manifest = _load_manifest(args.prediction_manifest)
    config = _config(manifest)
    preregistration = verify_simple_global_preregistration(
        preregistration_path=args.preregistration,
        config=config,
        prediction_manifest_path=args.prediction_manifest,
        batch_plan_path=args.batch_plan,
        run_output_dir=args.run_output_dir,
        cache_dir=args.cache_dir,
    )
    execution = preregistration["execution"]
    budget = preregistration["logical_completion_budget"]

    def progress(event: Mapping[str, Any]) -> None:
        print(
            f"[v55 batch {event['batch_index']}] "
            f"{event['batch_id']} {event['stage_outcome']['status']}",
            flush=True,
        )

    rows, run = predict_simple_global_cases(
        prediction_manifest_path=args.prediction_manifest,
        batch_plan_path=args.batch_plan,
        preregistration_sha256=preregistration["preregistration_sha256"],
        judge=_judge(),
        config=config,
        cache_dir=args.cache_dir,
        unscored_output_path=execution["unscored_output_path"],
        predict_run_metadata_path=execution["predict_run_metadata_path"],
        max_logical_completions=budget["maximum_new"],
        logical_completion_ledger_path=execution[
            "logical_completion_ledger_path"
        ],
        cumulative_logical_completions_before=budget["cumulative_before"],
        authorized_cumulative_ceiling=budget["phase_ceiling"],
        on_batch=progress,
    )
    return {
        "prediction_count": len(rows),
        "batch_count": run["batch_count"],
        "logical_completion_budget_used": run[
            "logical_completion_budget_used"
        ],
        "predict_run_sha256": run["predict_run_sha256"],
    }


def _score(args: argparse.Namespace) -> dict[str, Any]:
    # Complete raw-chain validation occurs before either gold-bearing loader.
    validate_simple_global_artifacts(
        prediction_manifest_path=args.prediction_manifest,
        batch_plan_path=args.batch_plan,
        unscored_predictions_path=args.unscored_predictions,
        predict_run_metadata_path=args.predict_run,
    )
    started = datetime.now(timezone.utc)
    dataset = load_agent_error_bench(args.dataset)
    cohort = load_cohort_manifest(args.cohort_manifest, dataset=dataset)
    predictions, metrics, predict_run = score_simple_global_predictions(
        dataset=dataset,
        cohort=cohort,
        prediction_manifest_path=args.prediction_manifest,
        batch_plan_path=args.batch_plan,
        unscored_predictions_path=args.unscored_predictions,
        predict_run_metadata_path=args.predict_run,
    )
    finished = datetime.now(timezone.utc)
    run_metadata = {
        "started_at": started.isoformat(),
        "finished_at": finished.isoformat(),
        "duration_seconds": (finished - started).total_seconds(),
        "experiment": SIMPLE_GLOBAL_EXPERIMENT,
        "semantic_topology": "one_stage_global",
        "provider_config": predict_run["provider_config"],
        "selected_trajectory_ids": predict_run["selected_trajectory_ids"],
        "batch_plan_sha256": predict_run["batch_plan_sha256"],
        "preregistration_sha256": predict_run["preregistration_sha256"],
        "gold_isolation": {
            "raw_artifacts_validated_before_dataset_load": True,
            "prediction_process_received_gold": False,
        },
    }
    return write_outputs(
        output_dir=args.output_dir,
        dataset=dataset,
        predictions=predictions,
        metrics=metrics,
        run_metadata=run_metadata,
    )


def _gate(args: argparse.Namespace) -> dict[str, Any]:
    return verify_simple_global_promotion(
        preregistration_path=args.preregistration,
        metrics_path=args.metrics,
        predictions_path=args.predictions,
        output_path=args.output,
    )


def main(argv: list[str] | None = None) -> int:
    command: str | None = None
    try:
        args = _parser().parse_args(argv)
        command = args.command
        result = {
            "plan": _plan,
            "preregister": _preregister,
            "predict": _predict,
            "score": _score,
            "gate": _gate,
        }[command](args)
        print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
        return 0
    except (
        SimpleGlobalCLIError,
        SimpleGlobalPreregistrationError,
        SimpleGlobalWorkflowError,
        KeyError,
        OSError,
        ValueError,
    ):
        print(
            json.dumps(
                {
                    "command": command,
                    "status": "failed",
                    "message": "v55 command failed closed; inspect local artifacts.",
                },
                ensure_ascii=False,
            ),
            file=sys.stderr,
        )
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

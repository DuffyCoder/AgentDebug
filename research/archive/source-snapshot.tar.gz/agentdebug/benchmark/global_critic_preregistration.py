"""Write-once preregistration for E7 global causal critic runs."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any, Mapping, Sequence

from agentdebug.diagnostics import (
    EVIDENCE_REPAIR_MAX_ATTEMPTS,
    EVIDENCE_REPAIR_PIPELINE_VERSION,
    EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION,
    EVIDENCE_VALIDATION_VERSION,
    GLOBAL_CRITIC_PIPELINE_VERSION,
    GLOBAL_CRITIC_PROMPT_PROTOCOL_VERSION,
    JUDGE_VIEW_VERSION,
)

from .global_critic_workflow import (
    E7_EXPERIMENT,
    E7_INPUT_SCHEMA_VERSION,
    E7_PREDICTION_SCHEMA_VERSION,
    E7_PREDICT_RUN_SCHEMA_VERSION,
    load_global_critic_inputs,
)
from .metrics import SUCCESS_STATUSES, compute_metrics
from .prediction_manifest import load_prediction_manifest, stable_sha256
from .runner import TRANSPORT_POLICY_VERSION, BenchmarkRunConfig
from .stage_cache import (
    RAW_RESPONSE_SIDECAR_SCHEMA_VERSION,
    RAW_STAGE_SCHEMA_VERSION,
    STAGE_CACHE_SCHEMA_VERSION,
)


E7_PREREGISTRATION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e7-preregistration.v1"
)
_CODE_PATHS = (
    "agentdebug/diagnostics/__init__.py",
    "agentdebug/diagnostics/evidence_repair.py",
    "agentdebug/diagnostics/global_critic.py",
    "agentdebug/diagnostics/judge_view.py",
    "agentdebug/diagnostics/parsing.py",
    "agentdebug/diagnostics/providers.py",
    "agentdebug/diagnostics/taxonomy.py",
    "agentdebug/diagnostics/validator.py",
    "agentdebug/benchmark/cohort.py",
    "agentdebug/benchmark/dataset.py",
    "agentdebug/benchmark/global_critic_cli.py",
    "agentdebug/benchmark/global_critic_preregistration.py",
    "agentdebug/benchmark/global_critic_workflow.py",
    "agentdebug/benchmark/metrics.py",
    "agentdebug/benchmark/prediction_manifest.py",
    "agentdebug/benchmark/production_workflow.py",
    "agentdebug/benchmark/reporting.py",
    "agentdebug/benchmark/runner.py",
    "agentdebug/benchmark/stage_cache.py",
    "docs/experiments/e7-global-causal-critic.md",
    "tests/test_global_critic_workflow.py",
)


class GlobalCriticPreregistrationError(ValueError):
    """An E7 run does not match its frozen experiment identity."""


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _atomic_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def _read(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise GlobalCriticPreregistrationError(
            "E7 preregistration is missing or corrupt"
        ) from error
    if not isinstance(value, dict):
        raise GlobalCriticPreregistrationError(
            "E7 preregistration must be an object"
        )
    return value


def write_global_critic_preregistration(
    *,
    experiment_name: str,
    prediction_manifest_path: str | Path,
    critic_input_manifest_path: str | Path,
    output_path: str | Path,
    run_output_dir: str | Path,
    cache_dir: str | Path,
    config: BenchmarkRunConfig,
    selected_trajectory_ids: Sequence[str],
    selection_rule: str,
    hypothesis: str,
    promotion_gate: Mapping[str, Any],
    cumulative_logical_completions_before: int,
    maximum_new_logical_completions: int,
) -> dict[str, Any]:
    """Freeze code, prompts, inputs, output paths, gate, and paid-call ceiling."""

    if not isinstance(experiment_name, str) or not experiment_name.strip():
        raise ValueError("experiment_name must be non-empty text")
    if not isinstance(selection_rule, str) or not selection_rule.strip():
        raise ValueError("selection_rule must be non-empty text")
    if not isinstance(hypothesis, str) or not hypothesis.strip():
        raise ValueError("hypothesis must be non-empty text")
    selected = [str(value) for value in selected_trajectory_ids]
    if not selected or len(set(selected)) != len(selected):
        raise ValueError("selected trajectory IDs must be unique and non-empty")
    if (
        isinstance(cumulative_logical_completions_before, bool)
        or not isinstance(cumulative_logical_completions_before, int)
        or cumulative_logical_completions_before < 0
        or isinstance(maximum_new_logical_completions, bool)
        or not isinstance(maximum_new_logical_completions, int)
        or maximum_new_logical_completions < 1
        or maximum_new_logical_completions > 2 * len(selected)
    ):
        raise ValueError("E7 logical-completion budget is invalid")
    if not config.api_key_env:
        raise ValueError(
            "E7 preregistration requires an API-key environment name"
        )

    prediction_path = Path(
        prediction_manifest_path
    ).expanduser().resolve()
    input_path = Path(critic_input_manifest_path).expanduser().resolve()
    prediction, cases = load_prediction_manifest(prediction_path)
    critic_inputs, entries = load_global_critic_inputs(input_path)
    known = [case.trajectory_id for case in cases]
    expected_selected = [value for value in known if value in set(selected)]
    if selected != expected_selected:
        raise GlobalCriticPreregistrationError(
            "selected IDs must follow prediction-manifest order"
        )
    if set(selected) - set(entries):
        raise GlobalCriticPreregistrationError(
            "selected ID is absent from E7 inputs"
        )
    if (
        critic_inputs["prediction_manifest_sha256"]
        != prediction["prediction_manifest_sha256"]
        or config.cohort_sha256 != prediction["cohort_sha256"]
    ):
        raise GlobalCriticPreregistrationError(
            "E7 preregistration input/provider lineage is invalid"
        )

    repository_root = Path(__file__).resolve().parents[2]
    code_bundle: dict[str, str] = {}
    for relative in _CODE_PATHS:
        path = repository_root / relative
        if not path.is_file():
            raise GlobalCriticPreregistrationError(
                f"E7 code bundle file is missing: {relative}"
            )
        code_bundle[relative] = _file_sha256(path)

    document: dict[str, Any] = {
        "schema_version": E7_PREREGISTRATION_SCHEMA_VERSION,
        "experiment_name": experiment_name.strip(),
        "hypothesis": hypothesis.strip(),
        "selection": {
            "rule": selection_rule.strip(),
            "trajectory_ids": selected,
            "count": len(selected),
        },
        "prediction_manifest": {
            "path": str(prediction_path),
            "file_sha256": _file_sha256(prediction_path),
            "content_sha256": prediction["prediction_manifest_sha256"],
            "dataset_manifest_sha256": prediction[
                "dataset_manifest_sha256"
            ],
            "cohort_name": prediction["cohort_name"],
            "cohort_sha256": prediction["cohort_sha256"],
            "entry_count": len(cases),
        },
        "critic_input_manifest": {
            "path": str(input_path),
            "file_sha256": _file_sha256(input_path),
            "content_sha256": critic_inputs[
                "critic_input_manifest_sha256"
            ],
            "schema_version": E7_INPUT_SCHEMA_VERSION,
            "source_kind": critic_inputs["source_kind"],
            "source_unscored_sha256": critic_inputs[
                "source_unscored_sha256"
            ],
            "source_predict_run_sha256": critic_inputs[
                "source_predict_run_sha256"
            ],
            "entry_count": critic_inputs["entry_count"],
        },
        "implementation": {
            "experiment": E7_EXPERIMENT,
            "pipeline_version": GLOBAL_CRITIC_PIPELINE_VERSION,
            "prompt_protocol_version": (
                GLOBAL_CRITIC_PROMPT_PROTOCOL_VERSION
            ),
            "judge_view_version": JUDGE_VIEW_VERSION,
            "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
            "evidence_repair_pipeline_version": (
                EVIDENCE_REPAIR_PIPELINE_VERSION
            ),
            "evidence_repair_prompt_protocol_version": (
                EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
            ),
            "evidence_repair_max_attempts": EVIDENCE_REPAIR_MAX_ATTEMPTS,
            "transport_policy_version": TRANSPORT_POLICY_VERSION,
            "prediction_schema_version": E7_PREDICTION_SCHEMA_VERSION,
            "predict_run_schema_version": E7_PREDICT_RUN_SCHEMA_VERSION,
            "stage_cache_schema_version": STAGE_CACHE_SCHEMA_VERSION,
            "raw_stage_schema_version": RAW_STAGE_SCHEMA_VERSION,
            "raw_response_sidecar_schema_version": (
                RAW_RESPONSE_SIDECAR_SCHEMA_VERSION
            ),
            "semantic_classifier": "single_global_llm_raw_output",
            "deterministic_root_fallback": False,
            "confidence_score_weight_vote": False,
        },
        "provider_config": config.public_dict(),
        "execution": {
            "run_output_dir": str(
                Path(run_output_dir).expanduser().resolve()
            ),
            "cache_dir": str(Path(cache_dir).expanduser().resolve()),
            "workers": 1,
            "retry_failures": False,
            "critic_max_per_case": 1,
            "repair_max_per_mechanically_eligible_critic": 1,
            "repair_eligibility": {
                "validation_issue_count": 1,
                "validation_issue_level": "error",
                "validation_issue_code": "evidence_quote_not_found",
            },
        },
        "logical_completion_budget": {
            "cumulative_before": cumulative_logical_completions_before,
            "maximum_new": maximum_new_logical_completions,
            "hard_cumulative_stop": (
                cumulative_logical_completions_before
                + maximum_new_logical_completions
            ),
            "authorized_cumulative_ceiling": 380,
            "http_transport_retries_are_not_logical_completions": True,
        },
        "promotion_gate": dict(promotion_gate),
        "code_bundle_sha256": stable_sha256(code_bundle),
        "code_bundle": code_bundle,
    }
    document["preregistration_sha256"] = stable_sha256(document)
    destination = Path(output_path).expanduser().resolve()
    if destination.is_file():
        existing = _read(destination)
        if existing != document:
            differing = sorted(
                key
                for key in set(existing) | set(document)
                if existing.get(key) != document.get(key)
            )
            raise GlobalCriticPreregistrationError(
                "existing E7 preregistration conflicts with current identity: "
                + ", ".join(differing)
            )
        return document
    _atomic_json(destination, document)
    return document


def verify_global_critic_preregistration(
    *,
    preregistration_path: str | Path,
    prediction_manifest_path: str | Path,
    critic_input_manifest_path: str | Path,
    run_output_dir: str | Path,
    cache_dir: str | Path,
    config: BenchmarkRunConfig,
    selected_trajectory_ids: Sequence[str],
    maximum_new_logical_completions: int,
) -> dict[str, Any]:
    """Recompute the complete write-once E7 identity immediately before calls."""

    path = Path(preregistration_path).expanduser().resolve()
    document = _read(path)
    body = dict(document)
    claimed = body.pop("preregistration_sha256", None)
    if (
        document.get("schema_version")
        != E7_PREREGISTRATION_SCHEMA_VERSION
        or claimed != stable_sha256(body)
    ):
        raise GlobalCriticPreregistrationError(
            "E7 preregistration schema or self-hash is invalid"
        )
    selection = document.get("selection")
    budget = document.get("logical_completion_budget")
    if (
        not isinstance(selection, Mapping)
        or not isinstance(budget, Mapping)
        or selection.get("trajectory_ids")
        != [str(value) for value in selected_trajectory_ids]
        or budget.get("maximum_new") != maximum_new_logical_completions
    ):
        raise GlobalCriticPreregistrationError(
            "runtime E7 selection or budget differs from preregistration"
        )
    return write_global_critic_preregistration(
        experiment_name=str(document.get("experiment_name", "")),
        prediction_manifest_path=prediction_manifest_path,
        critic_input_manifest_path=critic_input_manifest_path,
        output_path=path,
        run_output_dir=run_output_dir,
        cache_dir=cache_dir,
        config=config,
        selected_trajectory_ids=selected_trajectory_ids,
        selection_rule=str(selection.get("rule", "")),
        hypothesis=str(document.get("hypothesis", "")),
        promotion_gate=dict(document.get("promotion_gate") or {}),
        cumulative_logical_completions_before=int(
            budget.get("cumulative_before")
        ),
        maximum_new_logical_completions=(
            maximum_new_logical_completions
        ),
    )


def verify_global_critic_promotion(
    *,
    preregistration_path: str | Path,
    predictions_path: str | Path,
    metrics_path: str | Path,
    predict_run_path: str | Path,
    output_path: str | Path,
) -> dict[str, Any]:
    """Apply the frozen gate to independently scored E7 artifacts."""

    prereg_path = Path(preregistration_path).expanduser().resolve()
    predictions_resolved = Path(predictions_path).expanduser().resolve()
    metrics_resolved = Path(metrics_path).expanduser().resolve()
    run_resolved = Path(predict_run_path).expanduser().resolve()
    prereg = _read(prereg_path)
    prereg_body = dict(prereg)
    if prereg_body.pop("preregistration_sha256", None) != stable_sha256(
        prereg_body
    ):
        raise GlobalCriticPreregistrationError(
            "E7 preregistration self-hash is invalid"
        )
    try:
        prediction_rows = [
            json.loads(line)
            for line in predictions_resolved.read_text(
                encoding="utf-8"
            ).splitlines()
            if line.strip()
        ]
    except (OSError, json.JSONDecodeError) as error:
        raise GlobalCriticPreregistrationError(
            "E7 scored predictions are corrupt"
        ) from error
    if not prediction_rows or any(
        not isinstance(row, dict) for row in prediction_rows
    ):
        raise GlobalCriticPreregistrationError(
            "E7 scored predictions are invalid"
        )
    metrics_document = _read(metrics_resolved)
    predict_run = _read(run_resolved)
    run_body = dict(predict_run)
    if run_body.pop("predict_run_sha256", None) != stable_sha256(run_body):
        raise GlobalCriticPreregistrationError(
            "E7 predict-run self-hash is invalid"
        )
    recomputed_metrics = compute_metrics(prediction_rows)
    if metrics_document.get("metrics") != recomputed_metrics:
        raise GlobalCriticPreregistrationError(
            "E7 metrics do not match scored predictions"
        )
    selection = prereg.get("selection")
    gate = prereg.get("promotion_gate")
    budget = prereg.get("logical_completion_budget")
    if not all(
        isinstance(value, Mapping) for value in (selection, gate, budget)
    ):
        raise GlobalCriticPreregistrationError(
            "E7 preregistration gate envelope is invalid"
        )
    selected = selection["trajectory_ids"]
    if [row.get("trajectory_id") for row in prediction_rows] != selected:
        raise GlobalCriticPreregistrationError(
            "E7 scored prediction order differs from preregistration"
        )
    try:
        overall = recomputed_metrics["by_method"]["two_stage"]["overall"]
    except KeyError as error:
        raise GlobalCriticPreregistrationError(
            "E7 metrics lack the two_stage method"
        ) from error

    checks: dict[str, bool] = {}

    def check(name: str, passed: bool) -> None:
        checks[name] = bool(passed)

    if "trajectory_denominator" in gate:
        check(
            "trajectory_denominator",
            overall["trajectory_count"] == gate["trajectory_denominator"],
        )
    if "successful_prediction_minimum" in gate:
        check(
            "successful_prediction_minimum",
            overall["successful_prediction_count"]
            >= gate["successful_prediction_minimum"],
        )
    if "step_exact_minimum_correct" in gate:
        check(
            "step_exact_minimum_correct",
            overall["step_exact"]["correct"]
            >= gate["step_exact_minimum_correct"],
        )
    if "step_module_exact_minimum_correct" in gate:
        check(
            "step_module_exact_minimum_correct",
            overall["step_module_exact"]["correct"]
            >= gate["step_module_exact_minimum_correct"],
        )
    if "all_correct_minimum" in gate:
        check(
            "all_correct_minimum",
            overall["all_correct"]["correct"]
            >= gate["all_correct_minimum"],
        )
    failed = overall["failed_prediction_count"]
    if "hard_failure_maximum" in gate:
        check(
            "hard_failure_maximum",
            failed <= gate["hard_failure_maximum"],
        )
    if "failed_prediction_maximum" in gate:
        check(
            "failed_prediction_maximum",
            failed <= gate["failed_prediction_maximum"],
        )
    if "evidence_valid_minimum" in gate:
        check(
            "evidence_valid_minimum",
            sum(
                row.get("status") in SUCCESS_STATUSES
                for row in prediction_rows
            )
            >= gate["evidence_valid_minimum"],
        )
    if gate.get("semantic_mutation_maximum") is not None:
        check(
            "semantic_mutation_maximum",
            predict_run.get("semantic_mutation_count")
            <= gate["semantic_mutation_maximum"],
        )
    by_id = {
        str(row.get("trajectory_id")): row for row in prediction_rows
    }
    for trajectory_id in gate.get(
        "required_step_module_exact_trajectory_ids",
        [],
    ):
        check(
            f"required_step_module_exact:{trajectory_id}",
            by_id.get(str(trajectory_id), {}).get("step_module_exact")
            is True,
        )
    for index, group in enumerate(
        gate.get("minimum_step_exact_by_groups", [])
    ):
        group_ids = group.get("trajectory_ids", [])
        check(
            f"minimum_step_exact_group:{index}",
            sum(
                by_id.get(str(trajectory_id), {}).get("step_exact") is True
                for trajectory_id in group_ids
            )
            >= group.get("minimum", 0),
        )
    if gate.get("telemetry_logical_equals_critic_plus_repair"):
        telemetry = predict_run.get("provider_telemetry")
        logical = (
            telemetry.get("logical_completion_count")
            if isinstance(telemetry, Mapping)
            else None
        )
        check(
            "telemetry_logical_equals_critic_plus_repair",
            logical
            == predict_run.get("prediction_count")
            + predict_run.get("repair_attempt_count"),
        )
    used = predict_run.get("logical_completion_budget_used")
    check(
        "runtime_budget_within_preregistration",
        isinstance(used, int)
        and not isinstance(used, bool)
        and used <= budget["maximum_new"]
        and budget["cumulative_before"] + used
        <= budget["hard_cumulative_stop"]
        <= budget["authorized_cumulative_ceiling"],
    )
    accepted = bool(checks) and all(checks.values())
    document = {
        "schema_version": "agentdebug.benchmark.e7-promotion.v1",
        "accepted": accepted,
        "preregistration_path": str(prereg_path),
        "preregistration_sha256": prereg["preregistration_sha256"],
        "predictions_path": str(predictions_resolved),
        "predictions_file_sha256": _file_sha256(predictions_resolved),
        "metrics_path": str(metrics_resolved),
        "metrics_file_sha256": _file_sha256(metrics_resolved),
        "predict_run_path": str(run_resolved),
        "predict_run_file_sha256": _file_sha256(run_resolved),
        "checks": checks,
        "summary": {
            "trajectory_count": overall["trajectory_count"],
            "step_correct": overall["step_exact"]["correct"],
            "step_denominator": overall["step_exact"]["denominator"],
            "step_module_correct": overall["step_module_exact"]["correct"],
            "all_correct": overall["all_correct"]["correct"],
            "all_denominator": overall["all_correct"]["denominator"],
            "failed_prediction_count": failed,
            "logical_completion_budget_used": used,
        },
    }
    document["promotion_sha256"] = stable_sha256(document)
    _atomic_json(Path(output_path).expanduser().resolve(), document)
    if not accepted:
        failed_checks = sorted(
            name for name, passed in checks.items() if not passed
        )
        raise GlobalCriticPreregistrationError(
            "E7 promotion gate failed: " + ", ".join(failed_checks)
        )
    return document


__all__ = [
    "E7_PREREGISTRATION_SCHEMA_VERSION",
    "GlobalCriticPreregistrationError",
    "verify_global_critic_preregistration",
    "verify_global_critic_promotion",
    "write_global_critic_preregistration",
]

"""Gold-isolated persistence and scoring for the Codex Agent Judge.

``prepare_agent_judge_run`` crosses no gold-bearing boundary.  It freezes the
public prediction/cohort inputs and writes the complete task that an external
orchestrator gives to one fresh Codex subagent.  Scoring is deliberately a
separate, post-validation operation.
"""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from agentdebug.diagnostics.agent_judge import (
    AGENT_JUDGE_MODEL,
    AGENT_JUDGE_REASONING_EFFORT,
    AGENT_JUDGE_VERSION,
    build_agent_judge_task,
    validate_agent_judge_predictions,
)
from agentdebug.diagnostics.agent_judge_v2 import (
    AGENT_JUDGE_V2_MODEL,
    AGENT_JUDGE_V2_REASONING_EFFORT,
    AGENT_JUDGE_V2_VERSION,
    build_agent_judge_v2_task,
    validate_agent_judge_v2_predictions,
)
from agentdebug.diagnostics.agent_judge_v2_1 import (
    AGENT_JUDGE_V2_1_MODEL,
    AGENT_JUDGE_V2_1_REASONING_EFFORT,
    AGENT_JUDGE_V2_1_VERSION,
    build_agent_judge_v2_1_task,
    validate_agent_judge_v2_1_predictions,
)
from agentdebug.diagnostics.agent_judge_v2_2 import (
    AGENT_JUDGE_V2_2_MODEL,
    AGENT_JUDGE_V2_2_REASONING_EFFORT,
    AGENT_JUDGE_V2_2_VERSION,
    build_agent_judge_v2_2_task,
    validate_agent_judge_v2_2_predictions,
)
from agentdebug.diagnostics.agent_judge_v2_3 import (
    AGENT_JUDGE_V2_3_MODEL,
    AGENT_JUDGE_V2_3_REASONING_EFFORT,
    AGENT_JUDGE_V2_3_VERSION,
    build_agent_judge_v2_3_task,
    validate_agent_judge_v2_3_predictions,
)
from agentdebug.diagnostics.agent_judge_v2_4 import (
    AGENT_JUDGE_V2_4_MODEL,
    AGENT_JUDGE_V2_4_REASONING_EFFORT,
    AGENT_JUDGE_V2_4_VERSION,
    build_agent_judge_v2_4_task,
    validate_agent_judge_v2_4_predictions,
)
from agentdebug.diagnostics.agent_judge_sol_gaia_two_stage import (
    AGENT_JUDGE_SOL_GAIA_TWO_STAGE_MODEL,
    AGENT_JUDGE_SOL_GAIA_TWO_STAGE_REASONING_EFFORT,
    AGENT_JUDGE_SOL_GAIA_TWO_STAGE_VERSION,
    build_sol_gaia_two_stage_task,
    validate_sol_gaia_two_stage_predictions,
)
from agentdebug.diagnostics.agent_judge_sol_gaia_specialist_critic import (
    AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_MODEL,
    AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_REASONING_EFFORT,
    AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_VERSION,
    build_sol_gaia_specialist_critic_task,
    validate_sol_gaia_specialist_critic_predictions,
)
from agentdebug.diagnostics.agent_judge_sol_luna_gaia_serial import (
    AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_MODEL,
    AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_REASONING_EFFORT,
    AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_VERSION,
    build_sol_luna_serial_task,
    validate_sol_luna_serial_predictions,
)
from agentdebug.diagnostics.agent_judge_sol_luna_gaia_serial_v2 import (
    AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_V2_MODEL,
    AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_V2_REASONING_EFFORT,
    AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_V2_VERSION,
    build_sol_luna_v2_serial_task,
    validate_sol_luna_v2_serial_predictions,
)
from agentdebug.diagnostics.agent_judge_sol_gaia_forced_census import (
    MODEL as AGENT_JUDGE_SOL_GAIA_FORCED_CENSUS_MODEL,
    REASONING_EFFORT as AGENT_JUDGE_SOL_GAIA_FORCED_CENSUS_REASONING_EFFORT,
    VERSION as AGENT_JUDGE_SOL_GAIA_FORCED_CENSUS_VERSION,
    build_protocol_task as build_sol_gaia_forced_census_task,
    validate_forced_predictions as validate_sol_gaia_forced_census_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_causal_serial import (
    STEP_MODEL as AGENT_JUDGE_GAIA_CAUSAL_SERIAL_MODEL,
    STEP_REASONING_EFFORT as AGENT_JUDGE_GAIA_CAUSAL_SERIAL_REASONING_EFFORT,
    VERSION as AGENT_JUDGE_GAIA_CAUSAL_SERIAL_VERSION,
    build_protocol_task as build_gaia_causal_serial_task,
    validate_predictions as validate_gaia_causal_serial_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_official_phase2 import (
    MODEL as AGENT_JUDGE_GAIA_OFFICIAL_PHASE2_MODEL,
    REASONING_EFFORT as AGENT_JUDGE_GAIA_OFFICIAL_PHASE2_REASONING_EFFORT,
    VERSION as AGENT_JUDGE_GAIA_OFFICIAL_PHASE2_VERSION,
    build_protocol_task as build_gaia_official_phase2_task,
    validate_predictions as validate_gaia_official_phase2_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_raw_causal_serial import (
    MODEL as AGENT_JUDGE_GAIA_RAW_CAUSAL_SERIAL_MODEL,
    REASONING_EFFORT as AGENT_JUDGE_GAIA_RAW_CAUSAL_SERIAL_REASONING_EFFORT,
    VERSION as AGENT_JUDGE_GAIA_RAW_CAUSAL_SERIAL_VERSION,
    build_protocol_task as build_gaia_raw_causal_serial_task,
    validate_predictions as validate_gaia_raw_causal_serial_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_faithful_local import (
    PHASE2_MODEL as AGENT_JUDGE_GAIA_FAITHFUL_LOCAL_MODEL,
    PHASE2_REASONING_EFFORT as AGENT_JUDGE_GAIA_FAITHFUL_LOCAL_REASONING_EFFORT,
    VERSION as AGENT_JUDGE_GAIA_FAITHFUL_LOCAL_VERSION,
    build_protocol_task as build_gaia_faithful_local_task,
    validate_predictions as validate_gaia_faithful_local_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_official_repo_gpt41 import (
    MODEL as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_MODEL,
    REASONING_EFFORT as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_REASONING_EFFORT,
    VERSION as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_VERSION,
    build_protocol_task as build_gaia_official_repo_gpt41_task,
    validate_predictions as validate_gaia_official_repo_gpt41_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_official_repo_gpt55_codex_sdk import (
    MODEL as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT55_CODEX_SDK_MODEL,
    REASONING_EFFORT as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT55_CODEX_SDK_REASONING_EFFORT,
    VERSION as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT55_CODEX_SDK_VERSION,
    build_protocol_task as build_gaia_official_repo_gpt55_codex_sdk_task,
    validate_predictions as validate_gaia_official_repo_gpt55_codex_sdk_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_official_repo_gpt55_codex_sdk_v2 import (
    MODEL as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT55_CODEX_SDK_V2_MODEL,
    REASONING_EFFORT as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT55_CODEX_SDK_V2_REASONING_EFFORT,
    VERSION as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT55_CODEX_SDK_V2_VERSION,
    build_protocol_task as build_gaia_official_repo_gpt55_codex_sdk_v2_task,
    validate_predictions as validate_gaia_official_repo_gpt55_codex_sdk_v2_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_official_repo_gpt55_codex_sdk_v3 import (
    MODEL as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT55_CODEX_SDK_V3_MODEL,
    REASONING_EFFORT as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT55_CODEX_SDK_V3_REASONING_EFFORT,
    VERSION as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT55_CODEX_SDK_V3_VERSION,
    build_protocol_task as build_gaia_official_repo_gpt55_codex_sdk_v3_task,
    validate_predictions as validate_gaia_official_repo_gpt55_codex_sdk_v3_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_official_repo_gpt41_strict_v8 import (
    MODEL as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_STRICT_V8_MODEL,
    REASONING_EFFORT as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_STRICT_V8_REASONING_EFFORT,
    VERSION as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_STRICT_V8_VERSION,
    build_protocol_task as build_gaia_official_repo_gpt41_strict_v8_task,
    validate_predictions as validate_gaia_official_repo_gpt41_strict_v8_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_official_repo_gpt41_strict_v8_1 import (
    MODEL as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_STRICT_V8_1_MODEL,
    REASONING_EFFORT as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_STRICT_V8_1_REASONING_EFFORT,
    VERSION as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_STRICT_V8_1_VERSION,
    build_protocol_task as build_gaia_official_repo_gpt41_strict_v8_1_task,
    validate_predictions as validate_gaia_official_repo_gpt41_strict_v8_1_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_official_repo_gpt41_strict_v8_2 import (
    MODEL as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_STRICT_V8_2_MODEL,
    REASONING_EFFORT as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_STRICT_V8_2_REASONING_EFFORT,
    VERSION as AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_STRICT_V8_2_VERSION,
    build_protocol_task as build_gaia_official_repo_gpt41_strict_v8_2_task,
    validate_predictions as validate_gaia_official_repo_gpt41_strict_v8_2_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v1 import (
    AGENT_JUDGE_LUNA_V1_MODEL,
    AGENT_JUDGE_LUNA_V1_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V1_VERSION,
    build_agent_judge_luna_v1_task,
    validate_agent_judge_luna_v1_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v2 import (
    AGENT_JUDGE_LUNA_V2_MODEL,
    AGENT_JUDGE_LUNA_V2_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V2_VERSION,
    build_agent_judge_luna_v2_task,
    validate_agent_judge_luna_v2_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v3 import (
    AGENT_JUDGE_LUNA_V3_MODEL,
    AGENT_JUDGE_LUNA_V3_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V3_VERSION,
    build_agent_judge_luna_v3_task,
    validate_agent_judge_luna_v3_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v1 import (
    AGENT_JUDGE_LUNA_GAIA_V1_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V1_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V1_VERSION,
    build_agent_judge_luna_gaia_v1_task,
    validate_agent_judge_luna_gaia_v1_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v2 import (
    AGENT_JUDGE_LUNA_GAIA_V2_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V2_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V2_VERSION,
    build_agent_judge_luna_gaia_v2_task,
    validate_agent_judge_luna_gaia_v2_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v2_1 import (
    AGENT_JUDGE_LUNA_GAIA_V2_1_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V2_1_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V2_1_VERSION,
    build_agent_judge_luna_gaia_v2_1_task,
    validate_agent_judge_luna_gaia_v2_1_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3 import (
    AGENT_JUDGE_LUNA_GAIA_V3_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_VERSION,
    build_agent_judge_luna_gaia_v3_task,
    validate_agent_judge_luna_gaia_v3_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_1 import (
    AGENT_JUDGE_LUNA_GAIA_V3_1_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_1_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_1_VERSION,
    build_agent_judge_luna_gaia_v3_1_task,
    validate_agent_judge_luna_gaia_v3_1_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_2 import (
    AGENT_JUDGE_LUNA_GAIA_V3_2_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_2_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_2_VERSION,
    build_agent_judge_luna_gaia_v3_2_task,
    validate_agent_judge_luna_gaia_v3_2_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_3 import (
    AGENT_JUDGE_LUNA_GAIA_V3_3_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_3_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_3_VERSION,
    build_agent_judge_luna_gaia_v3_3_task,
    validate_agent_judge_luna_gaia_v3_3_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_4 import (
    AGENT_JUDGE_LUNA_GAIA_V3_4_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_4_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_4_VERSION,
    build_agent_judge_luna_gaia_v3_4_task,
    validate_agent_judge_luna_gaia_v3_4_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_5 import (
    AGENT_JUDGE_LUNA_GAIA_V3_5_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_5_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_5_VERSION,
    build_agent_judge_luna_gaia_v3_5_task,
    validate_agent_judge_luna_gaia_v3_5_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_5_1 import (
    AGENT_JUDGE_LUNA_GAIA_V3_5_1_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_5_1_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_5_1_VERSION,
    build_agent_judge_luna_gaia_v3_5_1_task,
    validate_agent_judge_luna_gaia_v3_5_1_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_6 import (
    AGENT_JUDGE_LUNA_GAIA_V3_6_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_6_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_6_VERSION,
    build_agent_judge_luna_gaia_v3_6_task,
    validate_agent_judge_luna_gaia_v3_6_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_7 import (
    AGENT_JUDGE_LUNA_GAIA_V3_7_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_7_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_7_VERSION,
    build_agent_judge_luna_gaia_v3_7_task,
    validate_agent_judge_luna_gaia_v3_7_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_7_1 import (
    AGENT_JUDGE_LUNA_GAIA_V3_7_1_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_7_1_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_7_1_VERSION,
    build_agent_judge_luna_gaia_v3_7_1_task,
    validate_agent_judge_luna_gaia_v3_7_1_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_8 import (
    AGENT_JUDGE_LUNA_GAIA_V3_8_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_8_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_8_VERSION,
    build_agent_judge_luna_gaia_v3_8_task,
    validate_agent_judge_luna_gaia_v3_8_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_9 import (
    AGENT_JUDGE_LUNA_GAIA_V3_9_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_9_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_9_VERSION,
    build_agent_judge_luna_gaia_v3_9_task,
    validate_agent_judge_luna_gaia_v3_9_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_10 import (
    AGENT_JUDGE_LUNA_GAIA_V3_10_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_10_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_10_VERSION,
    build_agent_judge_luna_gaia_v3_10_task,
    validate_agent_judge_luna_gaia_v3_10_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_11 import (
    AGENT_JUDGE_LUNA_GAIA_V3_11_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_11_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_11_VERSION,
    build_agent_judge_luna_gaia_v3_11_task,
    validate_agent_judge_luna_gaia_v3_11_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_12_global import (
    AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_VERSION,
    build_agent_judge_luna_gaia_v3_12_global_task,
    validate_agent_judge_luna_gaia_v3_12_global_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_13_conservative_challenger import (
    AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION,
    build_agent_judge_luna_gaia_v3_13_task,
    validate_agent_judge_luna_gaia_v3_13_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_14_earliest_causal_challenger import (
    AGENT_JUDGE_LUNA_GAIA_V3_14_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_14_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_14_VERSION,
    build_agent_judge_luna_gaia_v3_14_task,
    validate_agent_judge_luna_gaia_v3_14_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_15_packet_handoff_closure import (
    AGENT_JUDGE_LUNA_GAIA_V3_15_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_15_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_15_VERSION,
    build_agent_judge_luna_gaia_v3_15_task,
    validate_agent_judge_luna_gaia_v3_15_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_16_bounded_bidirectional_challenger import (
    AGENT_JUDGE_LUNA_GAIA_V3_16_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_16_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
    build_agent_judge_luna_gaia_v3_16_task,
    validate_agent_judge_luna_gaia_v3_16_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_17_mandatory_earlier_scan import (
    AGENT_JUDGE_LUNA_GAIA_V3_17_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_17_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_17_VERSION,
    build_agent_judge_luna_gaia_v3_17_task,
    validate_agent_judge_luna_gaia_v3_17_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_18_probe_contribution_veto import (
    AGENT_JUDGE_LUNA_GAIA_V3_18_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_18_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_18_VERSION,
    build_agent_judge_luna_gaia_v3_18_task,
    validate_agent_judge_luna_gaia_v3_18_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_19_hard_disqualifier_precedence import (
    AGENT_JUDGE_LUNA_GAIA_V3_19_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_19_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_19_VERSION,
    build_agent_judge_luna_gaia_v3_19_task,
    validate_agent_judge_luna_gaia_v3_19_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_20_packet_state_closure import (
    AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
    build_agent_judge_luna_gaia_v3_20_task,
    validate_agent_judge_luna_gaia_v3_20_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_21_typed_state_claim_entailment import (
    AGENT_JUDGE_LUNA_GAIA_V3_21_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_21_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_21_VERSION,
    build_agent_judge_luna_gaia_v3_21_task,
    validate_agent_judge_luna_gaia_v3_21_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_22_isolated_bidirectional_state_challenger import (
    AGENT_JUDGE_LUNA_GAIA_V3_22_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_22_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_22_VERSION,
    build_agent_judge_luna_gaia_v3_22_task,
    validate_agent_judge_luna_gaia_v3_22_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_23_mandatory_state_scan_before_veto import (
    AGENT_JUDGE_LUNA_GAIA_V3_23_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_23_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_23_VERSION,
    build_agent_judge_luna_gaia_v3_23_task,
    validate_agent_judge_luna_gaia_v3_23_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_24_isolated_state_evidence_ledger import (
    AGENT_JUDGE_LUNA_GAIA_V3_24_AUDIT_SCHEMA_VERSION,
    AGENT_JUDGE_LUNA_GAIA_V3_24_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_24_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_24_VERSION,
    build_agent_judge_luna_gaia_v3_24_task,
    validate_agent_judge_luna_gaia_v3_24_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_25_predecessor_feedback_aligned_state_ledger import (
    AGENT_JUDGE_LUNA_GAIA_V3_25_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_25_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_25_VERSION,
    build_agent_judge_luna_gaia_v3_25_task,
    validate_agent_judge_luna_gaia_v3_25_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_26_same_step_consumer_witnessed_state_ledger import (
    AGENT_JUDGE_LUNA_GAIA_V3_26_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_26_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_26_VERSION,
    build_agent_judge_luna_gaia_v3_26_task,
    validate_agent_judge_luna_gaia_v3_26_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_27_prior_feedback_matured_capability_admission import (
    AGENT_JUDGE_LUNA_GAIA_V3_27_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_27_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_27_VERSION,
    build_agent_judge_luna_gaia_v3_27_task,
    validate_agent_judge_luna_gaia_v3_27_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_28_clean_v3p20_prior_feedback_matured_capability_admission import (
    AGENT_JUDGE_LUNA_GAIA_V3_28_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_28_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_28_VERSION,
    build_agent_judge_luna_gaia_v3_28_task,
    validate_agent_judge_luna_gaia_v3_28_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_29_clean_v3p20_acquisition_anchor_zero_contribution_challenger import (
    AGENT_JUDGE_LUNA_GAIA_V3_29_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_29_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_29_VERSION,
    build_agent_judge_luna_gaia_v3_29_task,
    validate_agent_judge_luna_gaia_v3_29_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_30_clean_v3p20_bounded_bidirectional_challenger import (
    AGENT_JUDGE_LUNA_GAIA_V3_30_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_30_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_30_VERSION,
    build_agent_judge_luna_gaia_v3_30_task,
    validate_agent_judge_luna_gaia_v3_30_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_31_clean_v3p20_dual_anchor_disagreement_adjudication import (
    AGENT_JUDGE_LUNA_GAIA_V3_31_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_31_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_31_VERSION,
    build_agent_judge_luna_gaia_v3_31_task,
    validate_agent_judge_luna_gaia_v3_31_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_32_clean_v3p20_complete_step_census_challenger import (
    AGENT_JUDGE_LUNA_GAIA_V3_32_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_32_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_32_VERSION,
    build_agent_judge_luna_gaia_v3_32_task,
    validate_agent_judge_luna_gaia_v3_32_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_33_clean_v3p20_anchor_blind_complete_step_census_freeze import (
    AGENT_JUDGE_LUNA_GAIA_V3_33_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_33_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_33_VERSION,
    build_agent_judge_luna_gaia_v3_33_task,
    validate_agent_judge_luna_gaia_v3_33_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_34_clean_v3p20_observable_impact_bidirectional_challenger import (
    AGENT_JUDGE_LUNA_GAIA_V3_34_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_34_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_34_VERSION,
    build_agent_judge_luna_gaia_v3_34_task,
    validate_agent_judge_luna_gaia_v3_34_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_35_clean_v3p20_veto_closed_observable_impact_challenger import (
    AGENT_JUDGE_LUNA_GAIA_V3_35_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_35_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_35_VERSION,
    build_agent_judge_luna_gaia_v3_35_task,
    validate_agent_judge_luna_gaia_v3_35_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_36_clean_v3p20_task_predicate_maturity_closure import (
    AGENT_JUDGE_LUNA_GAIA_V3_36_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_36_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_36_VERSION,
    build_agent_judge_luna_gaia_v3_36_task,
    validate_agent_judge_luna_gaia_v3_36_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_37_clean_v3p20_factorized_anchor_blind_specialist_panel import (
    AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION,
    build_agent_judge_luna_gaia_v3_37_task,
    validate_agent_judge_luna_gaia_v3_37_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_38_clean_v3p20_typed_boundary_calibration import (
    AGENT_JUDGE_LUNA_GAIA_V3_38_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_38_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_38_VERSION,
    build_agent_judge_luna_gaia_v3_38_task,
    validate_agent_judge_luna_gaia_v3_38_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_39_clean_v3p20_bounded_typed_boundary_challenger import (
    AGENT_JUDGE_LUNA_GAIA_V3_39_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_39_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_39_VERSION,
    build_agent_judge_luna_gaia_v3_39_task,
    validate_agent_judge_luna_gaia_v3_39_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_40_clean_v3p20_complete_typed_boundary_census_challenger import (
    AGENT_JUDGE_LUNA_GAIA_V3_40_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_40_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_40_VERSION,
    build_agent_judge_luna_gaia_v3_40_task,
    validate_agent_judge_luna_gaia_v3_40_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_41_clean_v3p20_owner_factored_boundary_census_challenger import (
    AGENT_JUDGE_LUNA_GAIA_V3_41_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_41_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_41_VERSION,
    build_agent_judge_luna_gaia_v3_41_task,
    validate_agent_judge_luna_gaia_v3_41_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_42_clean_v3p20_anchor_blind_three_specialist_tournament import (
    AGENT_JUDGE_LUNA_GAIA_V3_42_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_42_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_42_VERSION,
    build_agent_judge_luna_gaia_v3_42_task,
    validate_agent_judge_luna_gaia_v3_42_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_43_clean_v3p20_direction_factorized_anchor_aware_challenger_tournament import (
    AGENT_JUDGE_LUNA_GAIA_V3_43_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_43_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_43_VERSION,
    build_agent_judge_luna_gaia_v3_43_task,
    validate_agent_judge_luna_gaia_v3_43_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_44_clean_v3p20_provenance_blind_independent_boundary_ballot_tournament import (
    AGENT_JUDGE_LUNA_GAIA_V3_44_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_44_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_44_VERSION,
    build_agent_judge_luna_gaia_v3_44_task,
    validate_agent_judge_luna_gaia_v3_44_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_45_clean_v3p20_anchor_preserving_independent_typed_challenger_panel import (
    AGENT_JUDGE_LUNA_GAIA_V3_45_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_45_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_45_VERSION,
    build_agent_judge_luna_gaia_v3_45_task,
    validate_agent_judge_luna_gaia_v3_45_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_46_clean_v3p20_module_complete_local_error_profile_causal_promotion import (
    AGENT_JUDGE_LUNA_GAIA_V3_46_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_46_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_46_VERSION,
    build_agent_judge_luna_gaia_v3_46_task,
    validate_agent_judge_luna_gaia_v3_46_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_47_clean_v3p20_relative_io_module_complete_local_error_profile_causal_promotion import (
    AGENT_JUDGE_LUNA_GAIA_V3_47_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_47_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_47_VERSION,
    build_agent_judge_luna_gaia_v3_47_task,
    validate_agent_judge_luna_gaia_v3_47_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_48_clean_v3p20_profile_critical_compression_anchor_duel import (
    AGENT_JUDGE_LUNA_GAIA_V3_48_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_48_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_48_VERSION,
    build_agent_judge_luna_gaia_v3_48_task,
    validate_agent_judge_luna_gaia_v3_48_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_49_clean_v3p20_anchor_blind_global_causal_proposal_duel import (
    AGENT_JUDGE_LUNA_GAIA_V3_49_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_49_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_49_VERSION,
    build_agent_judge_luna_gaia_v3_49_task,
    validate_agent_judge_luna_gaia_v3_49_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_50_clean_v3p20_factorized_local_inventory_global_proposal_duel import (
    AGENT_JUDGE_LUNA_GAIA_V3_50_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_50_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_50_VERSION,
    build_agent_judge_luna_gaia_v3_50_task,
    validate_agent_judge_luna_gaia_v3_50_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_51_clean_v3p20_replicated_global_causal_proposal_panel import (
    AGENT_JUDGE_LUNA_GAIA_V3_51_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_51_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_51_VERSION,
    build_agent_judge_luna_gaia_v3_51_task,
    validate_agent_judge_luna_gaia_v3_51_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_52_clean_v3p20_module_factorized_local_census_proposal_panel import (
    AGENT_JUDGE_LUNA_GAIA_V3_52_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_52_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_52_VERSION,
    build_agent_judge_luna_gaia_v3_52_task,
    validate_agent_judge_luna_gaia_v3_52_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_53_clean_v3p20_step_isolated_paper_local_global_challenger import (
    AGENT_JUDGE_LUNA_GAIA_V3_53_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_53_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_53_VERSION,
    build_agent_judge_luna_gaia_v3_53_task,
    validate_agent_judge_luna_gaia_v3_53_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_54_clean_v3p20_step_isolated_paper_local_promotion_safe_system_evidence import (
    AGENT_JUDGE_LUNA_GAIA_V3_54_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_54_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_54_VERSION,
    build_agent_judge_luna_gaia_v3_54_task,
    validate_agent_judge_luna_gaia_v3_54_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_55_clean_v3p20_step_isolated_class_stratified_anchor_selector import (
    AGENT_JUDGE_LUNA_GAIA_V3_55_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_55_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_55_VERSION,
    build_agent_judge_luna_gaia_v3_55_task,
    validate_agent_judge_luna_gaia_v3_55_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_56_clean_v3p20_step_isolated_class_stratified_anchor_selector_enumerated_contract import (
    AGENT_JUDGE_LUNA_GAIA_V3_56_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_56_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_56_VERSION,
    build_agent_judge_luna_gaia_v3_56_task,
    validate_agent_judge_luna_gaia_v3_56_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_57_clean_v3p20_step_isolated_earliest_module_reservoir_anchor_selector import (
    AGENT_JUDGE_LUNA_GAIA_V3_57_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_57_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_57_VERSION,
    build_agent_judge_luna_gaia_v3_57_task,
    validate_agent_judge_luna_gaia_v3_57_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_58_clean_v3p20_step_isolated_module_reservoir_pairwise_observed_continuation_reducer import (
    AGENT_JUDGE_LUNA_GAIA_V3_58_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_58_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_58_VERSION,
    build_agent_judge_luna_gaia_v3_58_task,
    validate_agent_judge_luna_gaia_v3_58_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_59_clean_v3p20_step_isolated_module_reservoir_pairwise_observed_continuation_deterministic_assembly import (
    AGENT_JUDGE_LUNA_GAIA_V3_59_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_59_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_59_VERSION,
    build_agent_judge_luna_gaia_v3_59_task,
    validate_agent_judge_luna_gaia_v3_59_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_60_clean_v3p20_retrospective_prefix_ledger_closure import (
    AGENT_JUDGE_LUNA_GAIA_V3_60_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_60_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_60_VERSION,
    build_agent_judge_luna_gaia_v3_60_task,
    validate_agent_judge_luna_gaia_v3_60_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_61_clean_v3p20_decision_time_evidence_maturity_census_challenger import (
    AGENT_JUDGE_LUNA_GAIA_V3_61_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_61_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_61_VERSION,
    build_agent_judge_luna_gaia_v3_61_task,
    validate_agent_judge_luna_gaia_v3_61_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_62_clean_v3p20_full_local_step_pairwise_reducer import (
    AGENT_JUDGE_LUNA_GAIA_V3_62_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_62_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_62_VERSION,
    build_agent_judge_luna_gaia_v3_62_task,
    validate_agent_judge_luna_gaia_v3_62_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_63_clean_v3p20_heterogeneous_critical_boundary_panel import (
    AGENT_JUDGE_LUNA_GAIA_V3_63_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_63_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_63_VERSION,
    build_agent_judge_luna_gaia_v3_63_task,
    validate_agent_judge_luna_gaia_v3_63_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_64_clean_v3p20_heterogeneous_critical_boundary_panel_runtime_compatible import (
    AGENT_JUDGE_LUNA_GAIA_V3_64_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_64_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_64_VERSION,
    build_agent_judge_luna_gaia_v3_64_task,
    validate_agent_judge_luna_gaia_v3_64_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_65_clean_v3p20_outcome_conditioned_global_boundary_proposal_duel import (
    AGENT_JUDGE_LUNA_GAIA_V3_65_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_65_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_65_VERSION,
    build_agent_judge_luna_gaia_v3_65_task,
    validate_agent_judge_luna_gaia_v3_65_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_66_clean_v3p20_exact_predicate_acquisition_boundary_reducer import (
    AGENT_JUDGE_LUNA_GAIA_V3_66_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_66_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_66_VERSION,
    build_agent_judge_luna_gaia_v3_66_task,
    validate_agent_judge_luna_gaia_v3_66_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_67_clean_v3p20_exact_predicate_acquisition_boundary_reducer_read_only_input import (
    AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION,
    build_agent_judge_luna_gaia_v3_67_task,
    validate_agent_judge_luna_gaia_v3_67_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_68_clean_v3p20_exact_predicate_acquisition_boundary_reducer_compact_embedded_input import (
    AGENT_JUDGE_LUNA_GAIA_V3_68_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_68_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_68_VERSION,
    build_agent_judge_luna_gaia_v3_68_task,
    validate_agent_judge_luna_gaia_v3_68_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_69_clean_v3p20_exact_predicate_acquisition_boundary_reducer_runtime_integrated import (
    AGENT_JUDGE_LUNA_GAIA_V3_69_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_69_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_69_VERSION,
    build_agent_judge_luna_gaia_v3_69_task,
    validate_agent_judge_luna_gaia_v3_69_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_70_clean_v3p20_exact_predicate_acquisition_boundary_reducer_owner_explicit import (
    AGENT_JUDGE_LUNA_GAIA_V3_70_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_70_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_70_VERSION,
    build_agent_judge_luna_gaia_v3_70_task,
    validate_agent_judge_luna_gaia_v3_70_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_71_clean_v3p20_exact_predicate_acquisition_boundary_reducer_evidence_materialized import (
    AGENT_JUDGE_LUNA_GAIA_V3_71_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_71_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_71_VERSION,
    build_agent_judge_luna_gaia_v3_71_task,
    validate_agent_judge_luna_gaia_v3_71_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_72_clean_v3p20_exact_predicate_acquisition_boundary_reducer_binding_materialized import (
    AGENT_JUDGE_LUNA_GAIA_V3_72_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_72_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_72_VERSION,
    build_agent_judge_luna_gaia_v3_72_task,
    validate_agent_judge_luna_gaia_v3_72_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_73_clean_v3p20_exact_predicate_acquisition_boundary_reducer_auditor_corrected import (
    AGENT_JUDGE_LUNA_GAIA_V3_73_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_73_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_73_VERSION,
    build_agent_judge_luna_gaia_v3_73_task,
    validate_agent_judge_luna_gaia_v3_73_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_74_clean_v3p20_exact_predicate_acquisition_boundary_reducer_owner_materialized import (
    AGENT_JUDGE_LUNA_GAIA_V3_74_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_74_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_74_VERSION,
    build_agent_judge_luna_gaia_v3_74_task,
    validate_agent_judge_luna_gaia_v3_74_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_75_clean_v3p20_sparse_ledger_global_boundary_selector import (
    AGENT_JUDGE_LUNA_GAIA_V3_75_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_75_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_75_VERSION,
    build_agent_judge_luna_gaia_v3_75_task,
    validate_agent_judge_luna_gaia_v3_75_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_76_clean_v3p20_sparse_ledger_global_boundary_selector_runtime_repair import (
    AGENT_JUDGE_LUNA_GAIA_V3_76_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_76_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_76_VERSION,
    build_agent_judge_luna_gaia_v3_76_task,
    validate_agent_judge_luna_gaia_v3_76_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_77_clean_v3p20_factorized_sparse_ledger_pairwise_selector import (
    AGENT_JUDGE_LUNA_GAIA_V3_77_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_77_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_77_VERSION,
    build_agent_judge_luna_gaia_v3_77_task,
    validate_agent_judge_luna_gaia_v3_77_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_78_clean_v3p20_factorized_sparse_ledger_pairwise_selector_contract_repair import (
    AGENT_JUDGE_LUNA_GAIA_V3_78_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_78_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_78_VERSION,
    build_agent_judge_luna_gaia_v3_78_task,
    validate_agent_judge_luna_gaia_v3_78_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_79_clean_v3p20_outcome_conditioned_predicate_handoff_tournament import (
    AGENT_JUDGE_LUNA_GAIA_V3_79_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_79_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_79_VERSION,
    build_agent_judge_luna_gaia_v3_79_task,
    validate_agent_judge_luna_gaia_v3_79_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_gaia_v3_80_clean_v3p20_outcome_conditioned_predicate_handoff_tournament_taxonomy_repair import (
    AGENT_JUDGE_LUNA_GAIA_V3_80_MODEL,
    AGENT_JUDGE_LUNA_GAIA_V3_80_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION,
    build_agent_judge_luna_gaia_v3_80_task,
    validate_agent_judge_luna_gaia_v3_80_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_81_clean_v3p20_model_only_sol_medium import (
    AGENT_JUDGE_GAIA_V3_81_MODEL,
    AGENT_JUDGE_GAIA_V3_81_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_81_VERSION,
    build_agent_judge_gaia_v3_81_task,
    validate_agent_judge_gaia_v3_81_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_82_clean_v3p20_model_only_terra_medium import (
    AGENT_JUDGE_GAIA_V3_82_MODEL,
    AGENT_JUDGE_GAIA_V3_82_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_82_VERSION,
    build_agent_judge_gaia_v3_82_task,
    validate_agent_judge_gaia_v3_82_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_83_clean_v3p20_model_only_gpt55_medium import (
    AGENT_JUDGE_GAIA_V3_83_MODEL,
    AGENT_JUDGE_GAIA_V3_83_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_83_VERSION,
    build_agent_judge_gaia_v3_83_task,
    validate_agent_judge_gaia_v3_83_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_84_model_only_gpt54_medium import (
    AGENT_JUDGE_GAIA_V3_84_MODEL,
    AGENT_JUDGE_GAIA_V3_84_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_84_VERSION,
    build_agent_judge_gaia_v3_84_task,
    validate_agent_judge_gaia_v3_84_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_85_gpt55_high_effort_only import (
    AGENT_JUDGE_GAIA_V3_85_MODEL,
    AGENT_JUDGE_GAIA_V3_85_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_85_VERSION,
    build_agent_judge_gaia_v3_85_task,
    validate_agent_judge_gaia_v3_85_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_86_gpt55_bounded_typed_boundary_challenger import (
    AGENT_JUDGE_GAIA_V3_86_MODEL,
    AGENT_JUDGE_GAIA_V3_86_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_86_VERSION,
    build_agent_judge_gaia_v3_86_task,
    validate_agent_judge_gaia_v3_86_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_87_gpt55_evidence_lifecycle_challenger import (
    AGENT_JUDGE_GAIA_V3_87_MODEL,
    AGENT_JUDGE_GAIA_V3_87_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_87_VERSION,
    build_agent_judge_gaia_v3_87_task,
    validate_agent_judge_gaia_v3_87_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_88_gpt55_sparse_influence_graph_challenger import (
    AGENT_JUDGE_GAIA_V3_88_MODEL,
    AGENT_JUDGE_GAIA_V3_88_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_88_VERSION,
    build_agent_judge_gaia_v3_88_task,
    validate_agent_judge_gaia_v3_88_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_89_gpt55_sol_heterogeneous_challenger import (
    AGENT_JUDGE_GAIA_V3_89_MODEL,
    AGENT_JUDGE_GAIA_V3_89_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_89_VERSION,
    build_agent_judge_gaia_v3_89_task,
    validate_agent_judge_gaia_v3_89_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_90_gpt55_outcome_conditioned_predicate_handoff_tournament import (
    AGENT_JUDGE_GAIA_V3_90_MODEL,
    AGENT_JUDGE_GAIA_V3_90_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_90_VERSION,
    build_agent_judge_gaia_v3_90_task,
    validate_agent_judge_gaia_v3_90_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_91_gpt55_file_inspected_predicate_handoff_tournament import (
    AGENT_JUDGE_GAIA_V3_91_MODEL,
    AGENT_JUDGE_GAIA_V3_91_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_91_VERSION,
    build_agent_judge_gaia_v3_91_task,
    validate_agent_judge_gaia_v3_91_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_92_gpt55_singleton_safe_file_inspected_predicate_handoff_tournament import (
    AGENT_JUDGE_GAIA_V3_92_MODEL,
    AGENT_JUDGE_GAIA_V3_92_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_92_VERSION,
    build_agent_judge_gaia_v3_92_task,
    validate_agent_judge_gaia_v3_92_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_93_gpt55_audited_no_bwrap_predicate_handoff_tournament import (
    AGENT_JUDGE_GAIA_V3_93_MODEL,
    AGENT_JUDGE_GAIA_V3_93_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_93_VERSION,
    build_agent_judge_gaia_v3_93_task,
    validate_agent_judge_gaia_v3_93_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_94_gpt55_response_only_audited_no_bwrap_predicate_handoff_tournament import (
    AGENT_JUDGE_GAIA_V3_94_MODEL,
    AGENT_JUDGE_GAIA_V3_94_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_94_VERSION,
    build_agent_judge_gaia_v3_94_task,
    validate_agent_judge_gaia_v3_94_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_95_gpt55_dual_stage_response_only_audited_tournament import (
    AGENT_JUDGE_GAIA_V3_95_MODEL,
    AGENT_JUDGE_GAIA_V3_95_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_95_VERSION,
    build_agent_judge_gaia_v3_95_task,
    validate_agent_judge_gaia_v3_95_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_96_gpt55_normalized_access_audited_tournament import (
    AGENT_JUDGE_GAIA_V3_96_MODEL,
    AGENT_JUDGE_GAIA_V3_96_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_96_VERSION,
    build_agent_judge_gaia_v3_96_task,
    validate_agent_judge_gaia_v3_96_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_97_gpt55_python3_bounded_access_audited_tournament import (
    AGENT_JUDGE_GAIA_V3_97_MODEL,
    AGENT_JUDGE_GAIA_V3_97_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_97_VERSION,
    build_agent_judge_gaia_v3_97_task,
    validate_agent_judge_gaia_v3_97_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_98_gpt55_stage_bounded_access_audited_tournament import (
    AGENT_JUDGE_GAIA_V3_98_MODEL,
    AGENT_JUDGE_GAIA_V3_98_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_98_VERSION,
    build_agent_judge_gaia_v3_98_task,
    validate_agent_judge_gaia_v3_98_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_99_gpt55_cwd_robust_access_audited_tournament import (
    AGENT_JUDGE_GAIA_V3_99_MODEL,
    AGENT_JUDGE_GAIA_V3_99_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_99_VERSION,
    build_agent_judge_gaia_v3_99_task,
    validate_agent_judge_gaia_v3_99_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_100_gpt55_short_bound_access_audited_tournament import (
    AGENT_JUDGE_GAIA_V3_100_MODEL,
    AGENT_JUDGE_GAIA_V3_100_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_100_VERSION,
    build_agent_judge_gaia_v3_100_task,
    validate_agent_judge_gaia_v3_100_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_101_gpt55_stage_local_access_validated_tournament import (
    AGENT_JUDGE_GAIA_V3_101_MODEL,
    AGENT_JUDGE_GAIA_V3_101_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_101_VERSION,
    build_agent_judge_gaia_v3_101_task,
    validate_agent_judge_gaia_v3_101_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_102_gpt55_three_attempt_access_validated_tournament import (
    AGENT_JUDGE_GAIA_V3_102_MODEL,
    AGENT_JUDGE_GAIA_V3_102_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_102_VERSION,
    build_agent_judge_gaia_v3_102_task,
    validate_agent_judge_gaia_v3_102_predictions,
)
from agentdebug.diagnostics.agent_judge_gaia_v3_103_gpt55_initial_probe_veto_tournament import (
    AGENT_JUDGE_GAIA_V3_103_MODEL,
    AGENT_JUDGE_GAIA_V3_103_REASONING_EFFORT,
    AGENT_JUDGE_GAIA_V3_103_VERSION,
    build_agent_judge_gaia_v3_103_task,
    validate_agent_judge_gaia_v3_103_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v3_serial import (
    AGENT_JUDGE_LUNA_V3_SERIAL_MODEL,
    AGENT_JUDGE_LUNA_V3_SERIAL_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V3_SERIAL_VERSION,
    build_agent_judge_luna_v3_serial_task,
    validate_agent_judge_luna_v3_serial_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v3_serial_v2 import (
    AGENT_JUDGE_LUNA_V3_SERIAL_V2_MODEL,
    AGENT_JUDGE_LUNA_V3_SERIAL_V2_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V3_SERIAL_V2_VERSION,
    build_agent_judge_luna_v3_serial_v2_task,
    validate_agent_judge_luna_v3_serial_v2_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v4 import (
    AGENT_JUDGE_LUNA_V4_MODEL,
    AGENT_JUDGE_LUNA_V4_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V4_VERSION,
    build_agent_judge_luna_v4_task,
    validate_agent_judge_luna_v4_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v5 import (
    AGENT_JUDGE_LUNA_V5_MODEL,
    AGENT_JUDGE_LUNA_V5_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V5_VERSION,
    build_agent_judge_luna_v5_task,
    validate_agent_judge_luna_v5_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v6 import (
    AGENT_JUDGE_LUNA_V6_MODEL,
    AGENT_JUDGE_LUNA_V6_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V6_VERSION,
    build_agent_judge_luna_v6_task,
    validate_agent_judge_luna_v6_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v7 import (
    AGENT_JUDGE_LUNA_V7_MODEL,
    AGENT_JUDGE_LUNA_V7_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V7_VERSION,
    build_agent_judge_luna_v7_task,
    validate_agent_judge_luna_v7_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v8 import (
    AGENT_JUDGE_LUNA_V8_MODEL,
    AGENT_JUDGE_LUNA_V8_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V8_VERSION,
    build_agent_judge_luna_v8_task,
    validate_agent_judge_luna_v8_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v9 import (
    AGENT_JUDGE_LUNA_V9_MODEL,
    AGENT_JUDGE_LUNA_V9_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V9_VERSION,
    build_agent_judge_luna_v9_task,
    validate_agent_judge_luna_v9_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v10 import (
    AGENT_JUDGE_LUNA_V10_MODEL,
    AGENT_JUDGE_LUNA_V10_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V10_VERSION,
    build_agent_judge_luna_v10_task,
    validate_agent_judge_luna_v10_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v11 import (
    AGENT_JUDGE_LUNA_V11_MODEL,
    AGENT_JUDGE_LUNA_V11_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V11_VERSION,
    build_agent_judge_luna_v11_task,
    validate_agent_judge_luna_v11_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v12 import (
    AGENT_JUDGE_LUNA_V12_MODEL,
    AGENT_JUDGE_LUNA_V12_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V12_VERSION,
    build_agent_judge_luna_v12_task,
    validate_agent_judge_luna_v12_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v12_standalone import (
    AGENT_JUDGE_LUNA_V12_STANDALONE_MODEL,
    AGENT_JUDGE_LUNA_V12_STANDALONE_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V12_STANDALONE_VERSION,
    build_agent_judge_luna_v12_standalone_task,
    validate_agent_judge_luna_v12_standalone_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v13_unified import (
    AGENT_JUDGE_LUNA_V13_UNIFIED_MODEL,
    AGENT_JUDGE_LUNA_V13_UNIFIED_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V13_UNIFIED_VERSION,
    build_agent_judge_luna_v13_unified_task,
    validate_agent_judge_luna_v13_unified_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v14_unified import (
    AGENT_JUDGE_LUNA_V14_UNIFIED_MODEL,
    AGENT_JUDGE_LUNA_V14_UNIFIED_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V14_UNIFIED_VERSION,
    build_agent_judge_luna_v14_unified_task,
    validate_agent_judge_luna_v14_unified_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v15_unified import (
    AGENT_JUDGE_LUNA_V15_UNIFIED_MODEL,
    AGENT_JUDGE_LUNA_V15_UNIFIED_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V15_UNIFIED_VERSION,
    build_agent_judge_luna_v15_unified_task,
    validate_agent_judge_luna_v15_unified_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v16_unified import (
    AGENT_JUDGE_LUNA_V16_UNIFIED_MODEL,
    AGENT_JUDGE_LUNA_V16_UNIFIED_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V16_UNIFIED_VERSION,
    build_agent_judge_luna_v16_unified_task,
    validate_agent_judge_luna_v16_unified_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_v17_unified import (
    AGENT_JUDGE_LUNA_V17_UNIFIED_MODEL,
    AGENT_JUDGE_LUNA_V17_UNIFIED_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_V17_UNIFIED_VERSION,
    build_agent_judge_luna_v17_unified_task,
    validate_agent_judge_luna_v17_unified_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_debate_v1 import (
    AGENT_JUDGE_LUNA_DEBATE_V1_MODEL,
    AGENT_JUDGE_LUNA_DEBATE_V1_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_DEBATE_V1_VERSION,
    build_luna_clean_debate_task,
    validate_luna_clean_debate_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_debate_v2 import (
    AGENT_JUDGE_LUNA_DEBATE_V2_MODEL,
    AGENT_JUDGE_LUNA_DEBATE_V2_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_DEBATE_V2_VERSION,
    build_luna_clean_debate_v2_task,
    validate_luna_clean_debate_v2_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_debate_v3 import (
    AGENT_JUDGE_LUNA_DEBATE_V3_MODEL,
    AGENT_JUDGE_LUNA_DEBATE_V3_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_DEBATE_V3_VERSION,
    build_luna_clean_debate_v3_task,
    validate_luna_clean_debate_v3_predictions,
)
from agentdebug.diagnostics.agent_judge_luna_debate_v4 import (
    AGENT_JUDGE_LUNA_DEBATE_V4_MODEL,
    AGENT_JUDGE_LUNA_DEBATE_V4_REASONING_EFFORT,
    AGENT_JUDGE_LUNA_DEBATE_V4_VERSION,
    build_luna_clean_debate_v4_task,
    validate_luna_clean_debate_v4_predictions,
)

from .cohort import CohortManifest
from .metrics import compute_metrics
from .models import BenchmarkDataset, BenchmarkExample
from .prediction_manifest import load_prediction_manifest, stable_sha256


AGENT_JUDGE_RUN_SCHEMA_VERSION = "agentdebug.benchmark.agent-judge-run.v1"
AGENT_JUDGE_METHOD = "agent_judge"
DEFAULT_AGENT_JUDGE_PROTOCOL = "luna-v1"
AGENT_JUDGE_PROMPT_VERSION = AGENT_JUDGE_LUNA_V1_VERSION
AGENT_JUDGE_PIPELINE_VERSION = AGENT_JUDGE_LUNA_V1_VERSION
PREREGISTRATION_FILENAME = "preregistration.json"
AGENT_TASK_FILENAME = "agent-task.md"
PREDICTIONS_FILENAME = "predictions.json"
PREDICTION_AUDIT_FILENAME = "prediction-audit.json"
AGENT_JUDGE_PROTOCOL_NAMES = (
    "v1",
    "v2",
    "v2.1",
    "v2.2",
    "v2.3",
    "v2.4",
    "sol-gaia-two-stage-v1",
    "sol-gaia-specialist-critic-v1",
    "sol-luna-gaia-serial-v1",
    "sol-luna-gaia-serial-v2",
    "sol-gaia-forced-census-v1",
    "gaia-causal-serial-v1",
    "gaia-official-repo-gpt4.1-v1",
    "gaia-official-repo-gpt55-codex-sdk-v1",
    "gaia-official-repo-gpt55-codex-sdk-v2",
    "gaia-official-repo-gpt55-codex-sdk-v3",
    "gaia-official-repo-gpt4.1-strict-v8-paper50-v1",
    "gaia-official-repo-gpt4.1-strict-v8.1-paper50-v1",
    "gaia-official-repo-gpt4.1-strict-v8.2-paper50-v1",
    "luna-v1",
    "luna-v2",
    "luna-v3",
    "luna-gaia-v1",
    "luna-gaia-v2",
    "luna-gaia-v2.1",
    "luna-gaia-v3",
    "luna-gaia-v3.1",
    "luna-gaia-v3.2",
    "luna-gaia-v3.3",
    "luna-gaia-v3.4",
    "luna-gaia-v3.5",
    "luna-gaia-v3.5.1",
    "luna-gaia-v3.6",
    "luna-gaia-v3.7",
    "luna-gaia-v3.7.1",
    "luna-gaia-v3.8",
    "luna-gaia-v3.9",
    "luna-gaia-v3.10",
    "luna-gaia-v3.11",
    "luna-gaia-v3.12-global",
    "luna-gaia-v3.13-conservative-challenger",
    "luna-gaia-v3.14-earliest-causal-challenger",
    "luna-gaia-v3.15-packet-handoff-closure",
    "luna-gaia-v3.16-bounded-bidirectional-challenger",
    "luna-gaia-v3.17-mandatory-earlier-scan",
    "luna-gaia-v3.18-probe-contribution-veto",
    "luna-gaia-v3.19-hard-disqualifier-precedence",
    "luna-gaia-v3.20-packet-state-closure",
    "luna-gaia-v3.21-typed-state-claim-entailment",
    "luna-gaia-v3.22-isolated-bidirectional-state-challenger",
    "luna-gaia-v3.23-mandatory-state-scan-before-veto",
    "luna-gaia-v3.24-isolated-state-evidence-ledger",
    "luna-gaia-v3.25-predecessor-feedback-aligned-state-ledger",
    "luna-gaia-v3.26-same-step-consumer-witnessed-state-ledger",
    "luna-gaia-v3.27-prior-feedback-matured-capability-admission",
    "luna-gaia-v3.28-clean-v3.20-prior-feedback-matured-capability-admission",
    "luna-gaia-v3.29-clean-v3.20-acquisition-anchor-zero-contribution-challenger",
    "luna-gaia-v3.30-clean-v3.20-bounded-bidirectional-challenger",
    "luna-gaia-v3.31-clean-v3.20-dual-anchor-disagreement-adjudication",
    "luna-gaia-v3.32-clean-v3.20-complete-step-census-challenger",
    "luna-gaia-v3.33-clean-v3.20-anchor-blind-complete-step-census-freeze",
    "luna-gaia-v3.34-clean-v3.20-observable-impact-bidirectional-challenger",
    "luna-gaia-v3.35-clean-v3.20-veto-closed-observable-impact-challenger",
    "luna-gaia-v3.36-clean-v3.20-task-predicate-maturity-closure",
    "luna-gaia-v3.37-clean-v3.20-factorized-anchor-blind-specialist-panel",
    "luna-gaia-v3.38-clean-v3.20-typed-boundary-calibration",
    "luna-gaia-v3.39-clean-v3.20-bounded-typed-boundary-challenger",
    "luna-gaia-v3.40-clean-v3.20-complete-typed-boundary-census-challenger",
    "luna-gaia-v3.41-clean-v3.20-owner-factored-boundary-census-challenger",
    "luna-gaia-v3.42-clean-v3.20-anchor-blind-three-specialist-tournament",
    "luna-gaia-v3.43-clean-v3.20-direction-factorized-anchor-aware-challenger-tournament",
    "luna-gaia-v3.44-clean-v3.20-provenance-blind-independent-boundary-ballot-tournament",
    "luna-gaia-v3.45-clean-v3.20-anchor-preserving-independent-typed-challenger-panel",
    "luna-gaia-v3.46-clean-v3.20-module-complete-local-error-profile-causal-promotion",
    "luna-gaia-v3.47-clean-v3.20-relative-io-module-complete-local-error-profile-causal-promotion",
    "luna-gaia-v3.48-clean-v3.20-profile-critical-compression-anchor-duel",
    "luna-gaia-v3.49-clean-v3.20-anchor-blind-global-causal-proposal-duel",
    "luna-gaia-v3.50-clean-v3.20-factorized-local-inventory-global-proposal-duel",
    "luna-gaia-v3.51-clean-v3.20-replicated-global-causal-proposal-panel",
    "luna-gaia-v3.52-clean-v3.20-module-factorized-local-census-proposal-panel",
    "luna-gaia-v3.53-clean-v3.20-step-isolated-paper-local-global-challenger",
    "luna-gaia-v3.54-clean-v3.20-step-isolated-paper-local-promotion-safe-system-evidence",
    "luna-gaia-v3.65-clean-v3.20-outcome-conditioned-global-boundary-proposal-duel",
    "luna-gaia-v3.66-clean-v3.20-exact-predicate-acquisition-boundary-reducer",
    "luna-gaia-v3.67-clean-v3.20-exact-predicate-acquisition-boundary-reducer-read-only-input",
    "luna-gaia-v3.68-clean-v3.20-exact-predicate-acquisition-boundary-reducer-compact-embedded-input",
    "luna-gaia-v3.69-clean-v3.20-exact-predicate-acquisition-boundary-reducer-runtime-integrated",
    "luna-gaia-v3.70-clean-v3.20-exact-predicate-acquisition-boundary-reducer-owner-explicit",
    "luna-gaia-v3.71-clean-v3.20-exact-predicate-acquisition-boundary-reducer-evidence-materialized",
    "luna-gaia-v3.72-clean-v3.20-exact-predicate-acquisition-boundary-reducer-binding-materialized",
    "luna-gaia-v3.73-clean-v3.20-exact-predicate-acquisition-boundary-reducer-auditor-corrected",
    "luna-gaia-v3.74-clean-v3.20-exact-predicate-acquisition-boundary-reducer-owner-materialized",
    "luna-gaia-v3.75-clean-v3.20-sparse-ledger-global-boundary-selector",
    "luna-v3-serial",
    "luna-v3-serial-v2",
    "luna-v4",
    "luna-v5",
    "luna-v6",
    "luna-v7",
    "luna-v8",
    "luna-v9",
    "luna-v10",
    "luna-v11",
    "luna-v12",
    "luna-v12-standalone",
    "luna-v13-unified",
    "luna-v14-unified",
    "luna-v15-unified",
    "luna-v16-unified",
    "luna-v17-unified",
    "luna-clean-debate-v1",
    "luna-clean-debate-v2",
    "luna-clean-debate-v3",
    "luna-clean-debate-v4",
)


class AgentJudgeWorkflowError(ValueError):
    """An Agent Judge run cannot be frozen or joined safely."""


@dataclass(frozen=True)
class AgentJudgeProtocol:
    """One immutable semantic protocol behind the shared workflow."""

    name: str
    version: str
    model: str
    reasoning_effort: str
    semantic_topology: str
    build_task: Callable[[str | Path, str | Path, str | Path], str]
    validate_predictions: Callable[
        [str | Path, str | Path, str | Path], dict[str, Any]
    ]


_AGENT_JUDGE_PROTOCOLS = {
    "v1": AgentJudgeProtocol(
        name="v1",
        version=AGENT_JUDGE_VERSION,
        model=AGENT_JUDGE_MODEL,
        reasoning_effort=AGENT_JUDGE_REASONING_EFFORT,
        semantic_topology="three_stage_five_step_agent_judge",
        build_task=build_agent_judge_task,
        validate_predictions=validate_agent_judge_predictions,
    ),
    "v2": AgentJudgeProtocol(
        name="v2",
        version=AGENT_JUDGE_V2_VERSION,
        model=AGENT_JUDGE_V2_MODEL,
        reasoning_effort=AGENT_JUDGE_V2_REASONING_EFFORT,
        semantic_topology="step_then_owner_then_type_agent_judge",
        build_task=build_agent_judge_v2_task,
        validate_predictions=validate_agent_judge_v2_predictions,
    ),
    "v2.1": AgentJudgeProtocol(
        name="v2.1",
        version=AGENT_JUDGE_V2_1_VERSION,
        model=AGENT_JUDGE_V2_1_MODEL,
        reasoning_effort=AGENT_JUDGE_V2_1_REASONING_EFFORT,
        semantic_topology=(
            "step_owner_type_with_admission_gates_and_evidence_copy_lock"
        ),
        build_task=build_agent_judge_v2_1_task,
        validate_predictions=validate_agent_judge_v2_1_predictions,
    ),
    "v2.2": AgentJudgeProtocol(
        name="v2.2",
        version=AGENT_JUDGE_V2_2_VERSION,
        model=AGENT_JUDGE_V2_2_MODEL,
        reasoning_effort=AGENT_JUDGE_V2_2_REASONING_EFFORT,
        semantic_topology=(
            "step_owner_type_with_first_false_proposition_and_validation_loop"
        ),
        build_task=build_agent_judge_v2_2_task,
        validate_predictions=validate_agent_judge_v2_2_predictions,
    ),
    "v2.3": AgentJudgeProtocol(
        name="v2.3",
        version=AGENT_JUDGE_V2_3_VERSION,
        model=AGENT_JUDGE_V2_3_MODEL,
        reasoning_effort=AGENT_JUDGE_V2_3_REASONING_EFFORT,
        semantic_topology=(
            "critical_commitment_step_owner_type_with_v2_2_evidence_and_validation_loop"
        ),
        build_task=build_agent_judge_v2_3_task,
        validate_predictions=validate_agent_judge_v2_3_predictions,
    ),
    "v2.4": AgentJudgeProtocol(
        name="v2.4",
        version=AGENT_JUDGE_V2_4_VERSION,
        model=AGENT_JUDGE_V2_4_MODEL,
        reasoning_effort=AGENT_JUDGE_V2_4_REASONING_EFFORT,
        semantic_topology=(
            "complete_local_pair_census_global_critical_root_new_defect_owner"
        ),
        build_task=build_agent_judge_v2_4_task,
        validate_predictions=validate_agent_judge_v2_4_predictions,
    ),
    "sol-gaia-two-stage-v1": AgentJudgeProtocol(
        name="sol-gaia-two-stage-v1",
        version=AGENT_JUDGE_SOL_GAIA_TWO_STAGE_VERSION,
        model=AGENT_JUDGE_SOL_GAIA_TWO_STAGE_MODEL,
        reasoning_effort=AGENT_JUDGE_SOL_GAIA_TWO_STAGE_REASONING_EFFORT,
        semantic_topology=(
            "fresh_unranked_candidate_proposer_then_fresh_closed_set_root_arbiter"
        ),
        build_task=build_sol_gaia_two_stage_task,
        validate_predictions=validate_sol_gaia_two_stage_predictions,
    ),
    "sol-gaia-specialist-critic-v1": AgentJudgeProtocol(
        name="sol-gaia-specialist-critic-v1",
        version=AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_VERSION,
        model=AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_MODEL,
        reasoning_effort=AGENT_JUDGE_SOL_GAIA_SPECIALIST_CRITIC_REASONING_EFFORT,
        semantic_topology=(
            "five_fresh_module_specialists_then_fresh_arbiter_then_fresh_critic"
        ),
        build_task=build_sol_gaia_specialist_critic_task,
        validate_predictions=validate_sol_gaia_specialist_critic_predictions,
    ),
    "sol-luna-gaia-serial-v1": AgentJudgeProtocol(
        name="sol-luna-gaia-serial-v1",
        version=AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_VERSION,
        model=AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_MODEL,
        reasoning_effort=AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_REASONING_EFFORT,
        semantic_topology=(
            "fresh_sol_candidate_proposer_then_label_hidden_luna_step_"
            "then_frozen_luna_module_then_late_bound_luna_type"
        ),
        build_task=build_sol_luna_serial_task,
        validate_predictions=validate_sol_luna_serial_predictions,
    ),
    "sol-luna-gaia-serial-v2": AgentJudgeProtocol(
        name="sol-luna-gaia-serial-v2",
        version=AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_V2_VERSION,
        model=AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_V2_MODEL,
        reasoning_effort=AGENT_JUDGE_SOL_LUNA_GAIA_SERIAL_V2_REASONING_EFFORT,
        semantic_topology=(
            "frozen_gold_free_v1_sol_step_module_lineage_then_fresh_luna_type_"
            "with_deterministic_validator_owner_sources"
        ),
        build_task=build_sol_luna_v2_serial_task,
        validate_predictions=validate_sol_luna_v2_serial_predictions,
    ),
    "sol-gaia-forced-census-v1": AgentJudgeProtocol(
        name="sol-gaia-forced-census-v1",
        version=AGENT_JUDGE_SOL_GAIA_FORCED_CENSUS_VERSION,
        model=AGENT_JUDGE_SOL_GAIA_FORCED_CENSUS_MODEL,
        reasoning_effort=AGENT_JUDGE_SOL_GAIA_FORCED_CENSUS_REASONING_EFFORT,
        semantic_topology=(
            "five_fresh_module_specialists_forced_to_review_every_step_then_"
            "deterministic_merge_then_fresh_global_root_arbiter"
        ),
        build_task=build_sol_gaia_forced_census_task,
        validate_predictions=validate_sol_gaia_forced_census_predictions,
    ),
    "gaia-causal-serial-v1": AgentJudgeProtocol(
        name="gaia-causal-serial-v1",
        version=AGENT_JUDGE_GAIA_CAUSAL_SERIAL_VERSION,
        model=AGENT_JUDGE_GAIA_CAUSAL_SERIAL_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_CAUSAL_SERIAL_REASONING_EFFORT,
        semantic_topology=(
            "frozen_label_hidden_forced_census_step_dossiers_then_fresh_"
            "luna_step_then_frozen_sol_module_then_frozen_sol_type"
        ),
        build_task=build_gaia_causal_serial_task,
        validate_predictions=validate_gaia_causal_serial_predictions,
    ),
    "gaia-official-phase2-v1": AgentJudgeProtocol(
        name="gaia-official-phase2-v1",
        version=AGENT_JUDGE_GAIA_OFFICIAL_PHASE2_VERSION,
        model=AGENT_JUDGE_GAIA_OFFICIAL_PHASE2_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_OFFICIAL_PHASE2_REASONING_EFFORT,
        semantic_topology=(
            "frozen_gold_free_five_module_phase1_census_projected_with_full_"
            "step_context_then_fresh_unrestricted_joint_phase2_decision"
        ),
        build_task=build_gaia_official_phase2_task,
        validate_predictions=validate_gaia_official_phase2_predictions,
    ),
    "gaia-raw-causal-serial-v1": AgentJudgeProtocol(
        name="gaia-raw-causal-serial-v1",
        version=AGENT_JUDGE_GAIA_RAW_CAUSAL_SERIAL_VERSION,
        model=AGENT_JUDGE_GAIA_RAW_CAUSAL_SERIAL_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_RAW_CAUSAL_SERIAL_REASONING_EFFORT,
        semantic_topology=(
            "label_free_complete_raw_trajectory_step_then_frozen_selected_"
            "step_owner_then_frozen_late_bound_type"
        ),
        build_task=build_gaia_raw_causal_serial_task,
        validate_predictions=validate_gaia_raw_causal_serial_predictions,
    ),
    "gaia-faithful-local-v1": AgentJudgeProtocol(
        name="gaia-faithful-local-v1",
        version=AGENT_JUDGE_GAIA_FAITHFUL_LOCAL_VERSION,
        model=AGENT_JUDGE_GAIA_FAITHFUL_LOCAL_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_FAITHFUL_LOCAL_REASONING_EFFORT,
        semantic_topology=(
            "four_fresh_official_local_phase1_module_reviewers_then_positive_"
            "only_merge_then_fresh_unrestricted_joint_phase2"
        ),
        build_task=build_gaia_faithful_local_task,
        validate_predictions=validate_gaia_faithful_local_predictions,
    ),
    "gaia-official-repo-gpt4.1-v1": AgentJudgeProtocol(
        name="gaia-official-repo-gpt4.1-v1",
        version=AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_VERSION,
        model=AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_REASONING_EFFORT,
        semantic_topology=(
            "official_repository_independent_step_module_phase1_calls_then_"
            "positive_only_full_trajectory_joint_phase2"
        ),
        build_task=build_gaia_official_repo_gpt41_task,
        validate_predictions=validate_gaia_official_repo_gpt41_predictions,
    ),
    "gaia-official-repo-gpt55-codex-sdk-v1": AgentJudgeProtocol(
        name="gaia-official-repo-gpt55-codex-sdk-v1",
        version=AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT55_CODEX_SDK_VERSION,
        model=AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT55_CODEX_SDK_MODEL,
        reasoning_effort=(
            AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT55_CODEX_SDK_REASONING_EFFORT
        ),
        semantic_topology=(
            "official_repository_independent_step_module_phase1_calls_then_"
            "positive_only_full_trajectory_joint_phase2_over_fresh_codex_sdk_threads"
        ),
        build_task=build_gaia_official_repo_gpt55_codex_sdk_task,
        validate_predictions=(
            validate_gaia_official_repo_gpt55_codex_sdk_predictions
        ),
    ),
    "gaia-official-repo-gpt55-codex-sdk-v2": AgentJudgeProtocol(
        name="gaia-official-repo-gpt55-codex-sdk-v2",
        version=AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT55_CODEX_SDK_V2_VERSION,
        model=AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT55_CODEX_SDK_V2_MODEL,
        reasoning_effort=(
            AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT55_CODEX_SDK_V2_REASONING_EFFORT
        ),
        semantic_topology=(
            "official_repository_phase1_then_bounded_fresh_phase2_"
            "normalization_resample_over_codex_sdk_threads"
        ),
        build_task=build_gaia_official_repo_gpt55_codex_sdk_v2_task,
        validate_predictions=(
            validate_gaia_official_repo_gpt55_codex_sdk_v2_predictions
        ),
    ),
    "gaia-official-repo-gpt55-codex-sdk-v3": AgentJudgeProtocol(
        name="gaia-official-repo-gpt55-codex-sdk-v3",
        version=AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT55_CODEX_SDK_V3_VERSION,
        model=AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT55_CODEX_SDK_V3_MODEL,
        reasoning_effort=(
            AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT55_CODEX_SDK_V3_REASONING_EFFORT
        ),
        semantic_topology=(
            "official_repository_parent_topology_with_public_native_taxonomy_"
            "and_selected_step_others_owner_bridge_over_codex_sdk_threads"
        ),
        build_task=build_gaia_official_repo_gpt55_codex_sdk_v3_task,
        validate_predictions=(
            validate_gaia_official_repo_gpt55_codex_sdk_v3_predictions
        ),
    ),
    "gaia-official-repo-gpt4.1-strict-v8-paper50-v1": AgentJudgeProtocol(
        name="gaia-official-repo-gpt4.1-strict-v8-paper50-v1",
        version=AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_STRICT_V8_VERSION,
        model=AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_STRICT_V8_MODEL,
        reasoning_effort=(
            AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_STRICT_V8_REASONING_EFFORT
        ),
        semantic_topology=(
            "three_top2_scouts_top3_coverage_exhaustive_assessor_"
            "fresh_root_error_selector_then_module_and_type"
        ),
        build_task=build_gaia_official_repo_gpt41_strict_v8_task,
        validate_predictions=(
            validate_gaia_official_repo_gpt41_strict_v8_predictions
        ),
    ),
    "gaia-official-repo-gpt4.1-strict-v8.1-paper50-v1": AgentJudgeProtocol(
        name="gaia-official-repo-gpt4.1-strict-v8.1-paper50-v1",
        version=AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_STRICT_V8_1_VERSION,
        model=AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_STRICT_V8_1_MODEL,
        reasoning_effort=(
            AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_STRICT_V8_1_REASONING_EFFORT
        ),
        semantic_topology=(
            "strict_v8_semantics_with_uniform_json_interface_normalization"
        ),
        build_task=build_gaia_official_repo_gpt41_strict_v8_1_task,
        validate_predictions=(
            validate_gaia_official_repo_gpt41_strict_v8_1_predictions
        ),
    ),
    "gaia-official-repo-gpt4.1-strict-v8.2-paper50-v1": AgentJudgeProtocol(
        name="gaia-official-repo-gpt4.1-strict-v8.2-paper50-v1",
        version=AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_STRICT_V8_2_VERSION,
        model=AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_STRICT_V8_2_MODEL,
        reasoning_effort=(
            AGENT_JUDGE_GAIA_OFFICIAL_REPO_GPT41_STRICT_V8_2_REASONING_EFFORT
        ),
        semantic_topology=(
            "strict_v8_semantics_with_structural_slot_and_quote_normalization"
        ),
        build_task=build_gaia_official_repo_gpt41_strict_v8_2_task,
        validate_predictions=(
            validate_gaia_official_repo_gpt41_strict_v8_2_predictions
        ),
    ),
    "luna-v1": AgentJudgeProtocol(
        name="luna-v1",
        version=AGENT_JUDGE_LUNA_V1_VERSION,
        model=AGENT_JUDGE_LUNA_V1_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V1_REASONING_EFFORT,
        semantic_topology=(
            "complete_local_pair_census_global_critical_root_"
            "definition_guarded_luna"
        ),
        build_task=build_agent_judge_luna_v1_task,
        validate_predictions=validate_agent_judge_luna_v1_predictions,
    ),
    "luna-v2": AgentJudgeProtocol(
        name="luna-v2",
        version=AGENT_JUDGE_LUNA_V2_VERSION,
        model=AGENT_JUDGE_LUNA_V2_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V2_REASONING_EFFORT,
        semantic_topology=(
            "upstream_introduction_ledger_same_step_handoff_luna"
        ),
        build_task=build_agent_judge_luna_v2_task,
        validate_predictions=validate_agent_judge_luna_v2_predictions,
    ),
    "luna-v3": AgentJudgeProtocol(
        name="luna-v3",
        version=AGENT_JUDGE_LUNA_V3_VERSION,
        model=AGENT_JUDGE_LUNA_V3_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V3_REASONING_EFFORT,
        semantic_topology=(
            "chronological_first_mature_breakpoint_then_owner_then_type_luna"
        ),
        build_task=build_agent_judge_luna_v3_task,
        validate_predictions=validate_agent_judge_luna_v3_predictions,
    ),
    "luna-gaia-v1": AgentJudgeProtocol(
        name="luna-gaia-v1",
        version=AGENT_JUDGE_LUNA_GAIA_V1_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V1_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V1_REASONING_EFFORT,
        semantic_topology=(
            "v3_chronological_breakpoint_with_nested_owner_evidence_fragments"
        ),
        build_task=build_agent_judge_luna_gaia_v1_task,
        validate_predictions=validate_agent_judge_luna_gaia_v1_predictions,
    ),
    "luna-gaia-v2": AgentJudgeProtocol(
        name="luna-gaia-v2",
        version=AGENT_JUDGE_LUNA_GAIA_V2_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V2_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V2_REASONING_EFFORT,
        semantic_topology=(
            "recovery_aware_causal_state_ledger_with_nonfinal_system_evidence"
        ),
        build_task=build_agent_judge_luna_gaia_v2_task,
        validate_predictions=validate_agent_judge_luna_gaia_v2_predictions,
    ),
    "luna-gaia-v2.1": AgentJudgeProtocol(
        name="luna-gaia-v2.1",
        version=AGENT_JUDGE_LUNA_GAIA_V2_1_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V2_1_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V2_1_REASONING_EFFORT,
        semantic_topology=(
            "recovery_aware_causal_state_ledger_with_short_execution_aliases"
        ),
        build_task=build_agent_judge_luna_gaia_v2_1_task,
        validate_predictions=validate_agent_judge_luna_gaia_v2_1_predictions,
    ),
    "luna-gaia-v3": AgentJudgeProtocol(
        name="luna-gaia-v3",
        version=AGENT_JUDGE_LUNA_GAIA_V3_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_REASONING_EFFORT,
        semantic_topology=(
            "lane_ordered_chronology_with_immutable_step_checkpoint"
        ),
        build_task=build_agent_judge_luna_gaia_v3_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_predictions,
    ),
    "luna-gaia-v3.1": AgentJudgeProtocol(
        name="luna-gaia-v3.1",
        version=AGENT_JUDGE_LUNA_GAIA_V3_1_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_1_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_1_REASONING_EFFORT,
        semantic_topology=(
            "lane_ordered_chronology_with_step_checkpoint_and_"
            "external_exception_packet_fence"
        ),
        build_task=build_agent_judge_luna_gaia_v3_1_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_1_predictions,
    ),
    "luna-gaia-v3.2": AgentJudgeProtocol(
        name="luna-gaia-v3.2",
        version=AGENT_JUDGE_LUNA_GAIA_V3_2_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_2_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_2_REASONING_EFFORT,
        semantic_topology=(
            "lane_ordered_chronology_with_step_checkpoint_packet_fence_"
            "and_capability_admission_gate"
        ),
        build_task=build_agent_judge_luna_gaia_v3_2_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_2_predictions,
    ),
    "luna-gaia-v3.3": AgentJudgeProtocol(
        name="luna-gaia-v3.3",
        version=AGENT_JUDGE_LUNA_GAIA_V3_3_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_3_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_3_REASONING_EFFORT,
        semantic_topology=(
            "lane_ordered_chronology_with_step_checkpoint_packet_fence_"
            "and_strategy_identity_gate"
        ),
        build_task=build_agent_judge_luna_gaia_v3_3_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_3_predictions,
    ),
    "luna-gaia-v3.4": AgentJudgeProtocol(
        name="luna-gaia-v3.4",
        version=AGENT_JUDGE_LUNA_GAIA_V3_4_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_4_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_4_REASONING_EFFORT,
        semantic_topology=(
            "lane_ordered_chronology_with_validated_step_candidate_ledger_"
            "step_checkpoint_and_external_exception_packet_fence"
        ),
        build_task=build_agent_judge_luna_gaia_v3_4_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_4_predictions,
    ),
    "luna-gaia-v3.5": AgentJudgeProtocol(
        name="luna-gaia-v3.5",
        version=AGENT_JUDGE_LUNA_GAIA_V3_5_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_5_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_5_REASONING_EFFORT,
        semantic_topology=(
            "lane_ordered_chronology_with_validated_step_candidate_ledger_"
            "checkpoint_packet_fence_and_positive_immediate_subgoal_capability"
        ),
        build_task=build_agent_judge_luna_gaia_v3_5_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_5_predictions,
    ),
    "luna-gaia-v3.5.1": AgentJudgeProtocol(
        name="luna-gaia-v3.5.1",
        version=AGENT_JUDGE_LUNA_GAIA_V3_5_1_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_5_1_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_5_1_REASONING_EFFORT,
        semantic_topology=(
            "lane_ordered_chronology_with_validated_step_only_candidate_ledger_"
            "checkpoint_packet_fence_and_positive_immediate_subgoal_capability"
        ),
        build_task=build_agent_judge_luna_gaia_v3_5_1_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_5_1_predictions,
    ),
    "luna-gaia-v3.6": AgentJudgeProtocol(
        name="luna-gaia-v3.6",
        version=AGENT_JUDGE_LUNA_GAIA_V3_6_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_6_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_6_REASONING_EFFORT,
        semantic_topology=(
            "lane_ordered_chronology_with_step_only_candidate_ledger_"
            "checkpoint_packet_fence_positive_capability_and_action_materiality"
        ),
        build_task=build_agent_judge_luna_gaia_v3_6_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_6_predictions,
    ),
    "luna-gaia-v3.7": AgentJudgeProtocol(
        name="luna-gaia-v3.7",
        version=AGENT_JUDGE_LUNA_GAIA_V3_7_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_7_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_7_REASONING_EFFORT,
        semantic_topology=(
            "lane_ordered_chronology_with_step_only_candidate_ledger_"
            "checkpoint_packet_fence_positive_capability_action_materiality_"
            "and_validated_strategy_state"
        ),
        build_task=build_agent_judge_luna_gaia_v3_7_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_7_predictions,
    ),
    "luna-gaia-v3.7.1": AgentJudgeProtocol(
        name="luna-gaia-v3.7.1",
        version=AGENT_JUDGE_LUNA_GAIA_V3_7_1_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_7_1_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_7_1_REASONING_EFFORT,
        semantic_topology=(
            "lane_ordered_chronology_with_precommit_step_ledger_checkpoint_"
            "packet_fence_positive_capability_action_materiality_and_"
            "orthogonal_same_route_strategy_state"
        ),
        build_task=build_agent_judge_luna_gaia_v3_7_1_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_7_1_predictions,
    ),
    "luna-gaia-v3.8": AgentJudgeProtocol(
        name="luna-gaia-v3.8",
        version=AGENT_JUDGE_LUNA_GAIA_V3_8_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_8_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_8_REASONING_EFFORT,
        semantic_topology=(
            "lane_ordered_chronology_with_precommit_step_ledger_checkpoint_"
            "packet_fence_positive_capability_action_materiality_and_"
            "structured_lane_a_claim_support"
        ),
        build_task=build_agent_judge_luna_gaia_v3_8_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_8_predictions,
    ),
    "luna-gaia-v3.9": AgentJudgeProtocol(
        name="luna-gaia-v3.9",
        version=AGENT_JUDGE_LUNA_GAIA_V3_9_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_9_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_9_REASONING_EFFORT,
        semantic_topology=(
            "lane_ordered_chronology_with_validated_step_candidate_ledger_"
            "checkpoint_packet_fence_and_static_document_capability_outcome_"
            "separation"
        ),
        build_task=build_agent_judge_luna_gaia_v3_9_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_9_predictions,
    ),
    "luna-gaia-v3.10": AgentJudgeProtocol(
        name="luna-gaia-v3.10",
        version=AGENT_JUDGE_LUNA_GAIA_V3_10_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_10_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_10_REASONING_EFFORT,
        semantic_topology=(
            "lane_ordered_chronology_with_validated_step_candidate_ledger_"
            "checkpoint_packet_fence_literal_pdf_capability_outcome_rule_and_"
            "shell_safe_compact_validation"
        ),
        build_task=build_agent_judge_luna_gaia_v3_10_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_10_predictions,
    ),
    "luna-gaia-v3.11": AgentJudgeProtocol(
        name="luna-gaia-v3.11",
        version=AGENT_JUDGE_LUNA_GAIA_V3_11_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_11_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_11_REASONING_EFFORT,
        semantic_topology=(
            "lane_ordered_chronology_with_validated_step_candidate_ledger_"
            "checkpoint_packet_fence_same_step_target_binding_and_shell_safe_"
            "compact_validation"
        ),
        build_task=build_agent_judge_luna_gaia_v3_11_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_11_predictions,
    ),
    "luna-gaia-v3.12-global": AgentJudgeProtocol(
        name="luna-gaia-v3.12-global",
        version=AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_12_GLOBAL_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_exhaustive_step_module_census_then_"
            "global_root_selection_then_same_step_owner_type_binding"
        ),
        build_task=build_agent_judge_luna_gaia_v3_12_global_task,
        validate_predictions=(
            validate_agent_judge_luna_gaia_v3_12_global_predictions
        ),
    ),
    "luna-gaia-v3.13-conservative-challenger": AgentJudgeProtocol(
        name="luna-gaia-v3.13-conservative-challenger",
        version=AGENT_JUDGE_LUNA_GAIA_V3_13_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_13_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_13_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_v3_4_anchor_then_one_later_"
            "challenger_then_default_keep_independent_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_13_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_13_predictions,
    ),
    "luna-gaia-v3.14-earliest-causal-challenger": AgentJudgeProtocol(
        name="luna-gaia-v3.14-earliest-causal-challenger",
        version=AGENT_JUDGE_LUNA_GAIA_V3_14_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_14_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_14_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_v3_4_anchor_then_one_earliest_"
            "path_intervention_causal_later_challenger_then_default_keep_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_14_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_14_predictions,
    ),
    "luna-gaia-v3.15-packet-handoff-closure": AgentJudgeProtocol(
        name="luna-gaia-v3.15-packet-handoff-closure",
        version=AGENT_JUDGE_LUNA_GAIA_V3_15_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_15_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_15_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_packet_handoff_closed_v3_4_anchor_"
            "then_one_earliest_path_intervention_causal_later_challenger_"
            "then_default_keep_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_15_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_15_predictions,
    ),
    "luna-gaia-v3.16-bounded-bidirectional-challenger": AgentJudgeProtocol(
        name="luna-gaia-v3.16-bounded-bidirectional-challenger",
        version=AGENT_JUDGE_LUNA_GAIA_V3_16_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_16_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_16_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_unchanged_v3_4_anchor_then_one_bounded_"
            "earlier_first_bidirectional_challenger_then_default_keep_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_16_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_16_predictions,
    ),
    "luna-gaia-v3.17-mandatory-earlier-scan": AgentJudgeProtocol(
        name="luna-gaia-v3.17-mandatory-earlier-scan",
        version=AGENT_JUDGE_LUNA_GAIA_V3_17_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_17_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_17_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_unchanged_v3_4_anchor_then_one_"
            "mandatory_ordered_earlier_scan_bidirectional_challenger_then_"
            "default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_17_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_17_predictions,
    ),
    "luna-gaia-v3.18-probe-contribution-veto": AgentJudgeProtocol(
        name="luna-gaia-v3.18-probe-contribution-veto",
        version=AGENT_JUDGE_LUNA_GAIA_V3_18_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_18_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_18_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_probe_contribution_veto_v3_4_anchor_"
            "then_one_earliest_path_intervention_causal_later_challenger_"
            "then_default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_18_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_18_predictions,
    ),
    "luna-gaia-v3.19-hard-disqualifier-precedence": AgentJudgeProtocol(
        name="luna-gaia-v3.19-hard-disqualifier-precedence",
        version=AGENT_JUDGE_LUNA_GAIA_V3_19_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_19_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_19_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_hard_disqualifier_precedence_probe_veto_"
            "v3_4_anchor_then_one_earliest_path_intervention_causal_later_"
            "challenger_then_default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_19_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_19_predictions,
    ),
    "luna-gaia-v3.20-packet-state-closure": AgentJudgeProtocol(
        name="luna-gaia-v3.20-packet-state-closure",
        version=AGENT_JUDGE_LUNA_GAIA_V3_20_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_20_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_20_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_packet_state_closure_v3_4_anchor_then_"
            "one_earliest_path_intervention_causal_later_challenger_then_"
            "default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_20_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_20_predictions,
    ),
    "luna-gaia-v3.21-typed-state-claim-entailment": AgentJudgeProtocol(
        name="luna-gaia-v3.21-typed-state-claim-entailment",
        version=AGENT_JUDGE_LUNA_GAIA_V3_21_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_21_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_21_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_typed_state_claim_entailment_v3_4_"
            "anchor_then_one_earliest_path_intervention_causal_later_"
            "challenger_then_default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_21_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_21_predictions,
    ),
    "luna-gaia-v3.22-isolated-bidirectional-state-challenger": AgentJudgeProtocol(
        name="luna-gaia-v3.22-isolated-bidirectional-state-challenger",
        version=AGENT_JUDGE_LUNA_GAIA_V3_22_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_22_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_22_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_v3_20_packet_state_anchor_then_one_"
            "isolated_bidirectional_state_challenger_then_default_keep_exact_"
            "copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_22_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_22_predictions,
    ),
    "luna-gaia-v3.23-mandatory-state-scan-before-veto": AgentJudgeProtocol(
        name="luna-gaia-v3.23-mandatory-state-scan-before-veto",
        version=AGENT_JUDGE_LUNA_GAIA_V3_23_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_23_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_23_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_v3_20_packet_state_anchor_then_"
            "mandatory_complete_state_scan_candidate_freeze_before_veto_then_"
            "default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_23_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_23_predictions,
    ),
    "luna-gaia-v3.24-isolated-state-evidence-ledger": AgentJudgeProtocol(
        name="luna-gaia-v3.24-isolated-state-evidence-ledger",
        version=AGENT_JUDGE_LUNA_GAIA_V3_24_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_24_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_24_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_v3_20_packet_state_anchor_then_"
            "isolated_complete_state_evidence_ledger_earliest_candidate_then_"
            "default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_24_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_24_predictions,
    ),
    "luna-gaia-v3.25-predecessor-feedback-aligned-state-ledger": AgentJudgeProtocol(
        name="luna-gaia-v3.25-predecessor-feedback-aligned-state-ledger",
        version=AGENT_JUDGE_LUNA_GAIA_V3_25_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_25_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_25_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_v3_20_packet_state_anchor_then_"
            "predecessor_feedback_aligned_state_ledger_earliest_candidate_then_"
            "default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_25_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_25_predictions,
    ),
    "luna-gaia-v3.26-same-step-consumer-witnessed-state-ledger": AgentJudgeProtocol(
        name="luna-gaia-v3.26-same-step-consumer-witnessed-state-ledger",
        version=AGENT_JUDGE_LUNA_GAIA_V3_26_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_26_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_26_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_v3_20_packet_state_anchor_then_"
            "predecessor_aligned_same_step_consumer_witnessed_state_ledger_"
            "earliest_candidate_then_default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_26_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_26_predictions,
    ),
    "luna-gaia-v3.27-prior-feedback-matured-capability-admission": AgentJudgeProtocol(
        name="luna-gaia-v3.27-prior-feedback-matured-capability-admission",
        version=AGENT_JUDGE_LUNA_GAIA_V3_27_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_27_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_27_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_v3_20_packet_state_anchor_with_"
            "prior_feedback_matured_capability_admission_then_predecessor_"
            "aligned_same_step_consumer_witnessed_state_ledger_then_"
            "default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_27_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_27_predictions,
    ),
    "luna-gaia-v3.28-clean-v3.20-prior-feedback-matured-capability-admission": AgentJudgeProtocol(
        name="luna-gaia-v3.28-clean-v3.20-prior-feedback-matured-capability-admission",
        version=AGENT_JUDGE_LUNA_GAIA_V3_28_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_28_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_28_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_clean_v3_20_packet_state_anchor_with_"
            "prior_feedback_matured_capability_admission_then_v3_20_earliest_"
            "causal_challenger_then_default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_28_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_28_predictions,
    ),
    "luna-gaia-v3.29-clean-v3.20-acquisition-anchor-zero-contribution-challenger": AgentJudgeProtocol(
        name="luna-gaia-v3.29-clean-v3.20-acquisition-anchor-zero-contribution-challenger",
        version=AGENT_JUDGE_LUNA_GAIA_V3_29_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_29_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_29_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_clean_v3_20_packet_state_anchor_then_"
            "acquisition_anchor_zero_contribution_later_challenger_then_"
            "default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_29_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_29_predictions,
    ),
    "luna-gaia-v3.30-clean-v3.20-bounded-bidirectional-challenger": AgentJudgeProtocol(
        name="luna-gaia-v3.30-clean-v3.20-bounded-bidirectional-challenger",
        version=AGENT_JUDGE_LUNA_GAIA_V3_30_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_30_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_30_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_clean_v3_20_packet_state_anchor_then_"
            "one_bounded_earlier_first_bidirectional_challenger_then_"
            "default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_30_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_30_predictions,
    ),
    "luna-gaia-v3.31-clean-v3.20-dual-anchor-disagreement-adjudication": AgentJudgeProtocol(
        name="luna-gaia-v3.31-clean-v3.20-dual-anchor-disagreement-adjudication",
        version=AGENT_JUDGE_LUNA_GAIA_V3_31_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_31_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_31_REASONING_EFFORT,
        semantic_topology=(
            "five_fresh_luna_sessions_two_independent_v3_20_packet_state_"
            "anchors_then_disagreement_only_exact_copy_adjudication_then_"
            "unchanged_v3_20_challenger_and_default_keep_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_31_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_31_predictions,
    ),
    "luna-gaia-v3.32-clean-v3.20-complete-step-census-challenger": AgentJudgeProtocol(
        name="luna-gaia-v3.32-clean-v3.20-complete-step-census-challenger",
        version=AGENT_JUDGE_LUNA_GAIA_V3_32_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_32_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_32_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_clean_v3_20_packet_state_anchor_then_"
            "validator_complete_step_census_before_anchor_classification_one_"
            "bidirectional_challenger_then_default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_32_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_32_predictions,
    ),
    "luna-gaia-v3.33-clean-v3.20-anchor-blind-complete-step-census-freeze": AgentJudgeProtocol(
        name="luna-gaia-v3.33-clean-v3.20-anchor-blind-complete-step-census-freeze",
        version=AGENT_JUDGE_LUNA_GAIA_V3_33_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_33_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_33_REASONING_EFFORT,
        semantic_topology=(
            "four_fresh_luna_sessions_clean_v3_20_packet_state_anchor_plus_"
            "anchor_blind_complete_step_single_candidate_freeze_then_frozen_"
            "candidate_comparator_then_default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_33_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_33_predictions,
    ),
    "luna-gaia-v3.34-clean-v3.20-observable-impact-bidirectional-challenger": AgentJudgeProtocol(
        name="luna-gaia-v3.34-clean-v3.20-observable-impact-bidirectional-challenger",
        version=AGENT_JUDGE_LUNA_GAIA_V3_34_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_34_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_34_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_clean_v3_20_packet_state_anchor_then_"
            "one_observable_impact_evidence_stratified_bidirectional_"
            "challenger_then_default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_34_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_34_predictions,
    ),
    "luna-gaia-v3.35-clean-v3.20-veto-closed-observable-impact-challenger": AgentJudgeProtocol(
        name="luna-gaia-v3.35-clean-v3.20-veto-closed-observable-impact-challenger",
        version=AGENT_JUDGE_LUNA_GAIA_V3_35_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_35_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_35_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_clean_v3_20_packet_state_anchor_then_"
            "one_veto_closed_observable_impact_challenger_then_default_keep_"
            "exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_35_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_35_predictions,
    ),
    "luna-gaia-v3.36-clean-v3.20-task-predicate-maturity-closure": AgentJudgeProtocol(
        name="luna-gaia-v3.36-clean-v3.20-task-predicate-maturity-closure",
        version=AGENT_JUDGE_LUNA_GAIA_V3_36_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_36_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_36_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_clean_v3_20_packet_state_anchor_then_"
            "one_task_predicate_maturity_closure_challenger_then_default_"
            "keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_36_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_36_predictions,
    ),
    "luna-gaia-v3.37-clean-v3.20-factorized-anchor-blind-specialist-panel": AgentJudgeProtocol(
        name="luna-gaia-v3.37-clean-v3.20-factorized-anchor-blind-specialist-panel",
        version=AGENT_JUDGE_LUNA_GAIA_V3_37_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_37_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_37_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_clean_v3_20_packet_state_anchor_then_"
            "anchor_blind_factorized_state_and_strategy_specialists_then_"
            "bounded_exact_copy_selector"
        ),
        build_task=build_agent_judge_luna_gaia_v3_37_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_37_predictions,
    ),
    "luna-gaia-v3.38-clean-v3.20-typed-boundary-calibration": AgentJudgeProtocol(
        name="luna-gaia-v3.38-clean-v3.20-typed-boundary-calibration",
        version=AGENT_JUDGE_LUNA_GAIA_V3_38_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_38_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_38_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_clean_v3_20_anchor_with_typed_boundary_"
            "calibration_then_unchanged_v3_20_challenger_and_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_38_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_38_predictions,
    ),
    "luna-gaia-v3.39-clean-v3.20-bounded-typed-boundary-challenger": AgentJudgeProtocol(
        name="luna-gaia-v3.39-clean-v3.20-bounded-typed-boundary-challenger",
        version=AGENT_JUDGE_LUNA_GAIA_V3_39_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_39_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_39_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_unchanged_clean_v3_20_anchor_then_one_"
            "bounded_typed_boundary_later_challenger_then_unchanged_v3_20_"
            "default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_39_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_39_predictions,
    ),
    "luna-gaia-v3.40-clean-v3.20-complete-typed-boundary-census-challenger": AgentJudgeProtocol(
        name="luna-gaia-v3.40-clean-v3.20-complete-typed-boundary-census-challenger",
        version=AGENT_JUDGE_LUNA_GAIA_V3_40_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_40_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_40_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_unchanged_clean_v3_20_anchor_then_"
            "complete_typed_boundary_step_census_one_bidirectional_proposal_"
            "then_default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_40_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_40_predictions,
    ),
    "luna-gaia-v3.41-clean-v3.20-owner-factored-boundary-census-challenger": AgentJudgeProtocol(
        name="luna-gaia-v3.41-clean-v3.20-owner-factored-boundary-census-challenger",
        version=AGENT_JUDGE_LUNA_GAIA_V3_41_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_41_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_41_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_unchanged_clean_v3_20_anchor_then_"
            "complete_owner_factored_boundary_census_one_bidirectional_"
            "proposal_then_default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_41_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_41_predictions,
    ),
    "luna-gaia-v3.42-clean-v3.20-anchor-blind-three-specialist-tournament": AgentJudgeProtocol(
        name="luna-gaia-v3.42-clean-v3.20-anchor-blind-three-specialist-tournament",
        version=AGENT_JUDGE_LUNA_GAIA_V3_42_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_42_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_42_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_unchanged_clean_v3_20_anchor_then_"
            "anchor_blind_three_specialist_panel_then_bounded_exact_copy_"
            "tournament"
        ),
        build_task=build_agent_judge_luna_gaia_v3_42_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_42_predictions,
    ),
    "luna-gaia-v3.43-clean-v3.20-direction-factorized-anchor-aware-challenger-tournament": AgentJudgeProtocol(
        name="luna-gaia-v3.43-clean-v3.20-direction-factorized-anchor-aware-challenger-tournament",
        version=AGENT_JUDGE_LUNA_GAIA_V3_43_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_43_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_43_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_unchanged_clean_v3_20_anchor_then_"
            "anchor_aware_strict_earlier_later_factorized_panel_then_bounded_"
            "exact_copy_tournament"
        ),
        build_task=build_agent_judge_luna_gaia_v3_43_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_43_predictions,
    ),
    "luna-gaia-v3.44-clean-v3.20-provenance-blind-independent-boundary-ballot-tournament": AgentJudgeProtocol(
        name="luna-gaia-v3.44-clean-v3.20-provenance-blind-independent-boundary-ballot-tournament",
        version=AGENT_JUDGE_LUNA_GAIA_V3_44_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_44_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_44_REASONING_EFFORT,
        semantic_topology=(
            "six_fresh_luna_sessions_unchanged_clean_v3_20_anchor_plus_four_"
            "anchor_blind_independent_boundary_ballots_then_provenance_blind_"
            "bounded_exact_copy_tournament"
        ),
        build_task=build_agent_judge_luna_gaia_v3_44_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_44_predictions,
    ),
    "luna-gaia-v3.45-clean-v3.20-anchor-preserving-independent-typed-challenger-panel": AgentJudgeProtocol(
        name="luna-gaia-v3.45-clean-v3.20-anchor-preserving-independent-typed-challenger-panel",
        version=AGENT_JUDGE_LUNA_GAIA_V3_45_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_45_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_45_REASONING_EFFORT,
        semantic_topology=(
            "six_fresh_luna_sessions_unchanged_clean_v3_20_anchor_plus_four_"
            "mutually_isolated_anchor_aware_typed_challengers_then_anchor_"
            "preserving_exact_copy_selector"
        ),
        build_task=build_agent_judge_luna_gaia_v3_45_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_45_predictions,
    ),
    "luna-gaia-v3.46-clean-v3.20-module-complete-local-error-profile-causal-promotion": AgentJudgeProtocol(
        name="luna-gaia-v3.46-clean-v3.20-module-complete-local-error-profile-causal-promotion",
        version=AGENT_JUDGE_LUNA_GAIA_V3_46_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_46_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_46_REASONING_EFFORT,
        semantic_topology=(
            "seven_fresh_luna_sessions_unchanged_clean_v3_20_anchor_plus_five_"
            "anchor_blind_module_complete_local_error_profiles_then_anchor_"
            "preserving_single_causal_promotion"
        ),
        build_task=build_agent_judge_luna_gaia_v3_46_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_46_predictions,
    ),
    "luna-gaia-v3.47-clean-v3.20-relative-io-module-complete-local-error-profile-causal-promotion": AgentJudgeProtocol(
        name="luna-gaia-v3.47-clean-v3.20-relative-io-module-complete-local-error-profile-causal-promotion",
        version=AGENT_JUDGE_LUNA_GAIA_V3_47_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_47_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_47_REASONING_EFFORT,
        semantic_topology=(
            "seven_fresh_luna_sessions_unchanged_clean_v3_20_anchor_plus_five_"
            "relative_io_anchor_blind_module_complete_local_error_profiles_"
            "then_anchor_preserving_single_causal_promotion"
        ),
        build_task=build_agent_judge_luna_gaia_v3_47_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_47_predictions,
    ),
    "luna-gaia-v3.48-clean-v3.20-profile-critical-compression-anchor-duel": AgentJudgeProtocol(
        name="luna-gaia-v3.48-clean-v3.20-profile-critical-compression-anchor-duel",
        version=AGENT_JUDGE_LUNA_GAIA_V3_48_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_48_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_48_REASONING_EFFORT,
        semantic_topology=(
            "seven_fresh_luna_sessions_unchanged_clean_v3_20_anchor_plus_five_"
            "anchor_blind_module_complete_owner_profiles_then_one_profile_"
            "critical_compression_anchor_duel"
        ),
        build_task=build_agent_judge_luna_gaia_v3_48_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_48_predictions,
    ),
    "luna-gaia-v3.49-clean-v3.20-anchor-blind-global-causal-proposal-duel": AgentJudgeProtocol(
        name="luna-gaia-v3.49-clean-v3.20-anchor-blind-global-causal-proposal-duel",
        version=AGENT_JUDGE_LUNA_GAIA_V3_49_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_49_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_49_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_luna_sessions_unchanged_clean_v3_20_anchor_plus_one_"
            "anchor_blind_module_first_global_causal_proposal_then_bounded_"
            "default_keep_exact_copy_duel"
        ),
        build_task=build_agent_judge_luna_gaia_v3_49_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_49_predictions,
    ),
    "luna-gaia-v3.50-clean-v3.20-factorized-local-inventory-global-proposal-duel": AgentJudgeProtocol(
        name="luna-gaia-v3.50-clean-v3.20-factorized-local-inventory-global-proposal-duel",
        version=AGENT_JUDGE_LUNA_GAIA_V3_50_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_50_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_50_REASONING_EFFORT,
        semantic_topology=(
            "eight_fresh_luna_sessions_unchanged_clean_v3_20_anchor_plus_five_"
            "anchor_blind_module_local_error_inventories_then_anchor_blind_max_one_"
            "global_proposal_then_bounded_default_keep_exact_copy_duel"
        ),
        build_task=build_agent_judge_luna_gaia_v3_50_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_50_predictions,
    ),
    "luna-gaia-v3.51-clean-v3.20-replicated-global-causal-proposal-panel": AgentJudgeProtocol(
        name="luna-gaia-v3.51-clean-v3.20-replicated-global-causal-proposal-panel",
        version=AGENT_JUDGE_LUNA_GAIA_V3_51_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_51_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_51_REASONING_EFFORT,
        semantic_topology=(
            "five_fresh_luna_sessions_unchanged_clean_v3_20_anchor_plus_three_"
            "mutually_isolated_anchor_blind_max_one_global_causal_proposals_"
            "then_anchor_preserving_exact_copy_selector"
        ),
        build_task=build_agent_judge_luna_gaia_v3_51_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_51_predictions,
    ),
    "luna-gaia-v3.52-clean-v3.20-module-factorized-local-census-proposal-panel": AgentJudgeProtocol(
        name="luna-gaia-v3.52-clean-v3.20-module-factorized-local-census-proposal-panel",
        version=AGENT_JUDGE_LUNA_GAIA_V3_52_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_52_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_52_REASONING_EFFORT,
        semantic_topology=(
            "six_fresh_luna_sessions_unchanged_clean_v3_20_anchor_plus_four_"
            "mutually_isolated_anchor_blind_module_complete_local_census_max_one_"
            "proposals_then_anchor_preserving_exact_copy_selector"
        ),
        build_task=build_agent_judge_luna_gaia_v3_52_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_52_predictions,
    ),
    "luna-gaia-v3.53-clean-v3.20-step-isolated-paper-local-global-challenger": AgentJudgeProtocol(
        name="luna-gaia-v3.53-clean-v3.20-step-isolated-paper-local-global-challenger",
        version=AGENT_JUDGE_LUNA_GAIA_V3_53_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_53_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_53_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_plus_one_fresh_prefix_bounded_local_"
            "taxonomy_session_per_step_then_anchor_blind_max_one_global_proposal_"
            "then_v3_20_default_keep_exact_copy_duel"
        ),
        build_task=build_agent_judge_luna_gaia_v3_53_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_53_predictions,
    ),
    "luna-gaia-v3.54-clean-v3.20-step-isolated-paper-local-promotion-safe-system-evidence": AgentJudgeProtocol(
        name="luna-gaia-v3.54-clean-v3.20-step-isolated-paper-local-promotion-safe-system-evidence",
        version=AGENT_JUDGE_LUNA_GAIA_V3_54_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_54_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_54_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_plus_one_fresh_prefix_bounded_local_"
            "taxonomy_session_per_step_with_promotion_safe_system_sources_then_"
            "anchor_blind_max_one_global_proposal_then_v3_20_default_keep_duel"
        ),
        build_task=build_agent_judge_luna_gaia_v3_54_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_54_predictions,
    ),
    "luna-gaia-v3.55-clean-v3.20-step-isolated-class-stratified-anchor-selector": AgentJudgeProtocol(
        name="luna-gaia-v3.55-clean-v3.20-step-isolated-class-stratified-anchor-selector",
        version=AGENT_JUDGE_LUNA_GAIA_V3_55_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_55_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_55_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_plus_one_fresh_prefix_bounded_local_"
            "taxonomy_session_per_step_with_promotion_safe_system_sources_then_"
            "one_anchor_aware_class_stratified_exact_copy_selector"
        ),
        build_task=build_agent_judge_luna_gaia_v3_55_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_55_predictions,
    ),
    "luna-gaia-v3.56-clean-v3.20-step-isolated-class-stratified-anchor-selector-enumerated-contract": AgentJudgeProtocol(
        name="luna-gaia-v3.56-clean-v3.20-step-isolated-class-stratified-anchor-selector-enumerated-contract",
        version=AGENT_JUDGE_LUNA_GAIA_V3_56_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_56_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_56_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_plus_one_fresh_prefix_bounded_local_"
            "taxonomy_session_per_step_with_promotion_safe_system_sources_then_"
            "one_anchor_aware_class_stratified_exact_copy_selector_with_fully_"
            "enumerated_frozen_contract"
        ),
        build_task=build_agent_judge_luna_gaia_v3_56_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_56_predictions,
    ),
    "luna-gaia-v3.57-clean-v3.20-step-isolated-earliest-module-reservoir-anchor-selector": AgentJudgeProtocol(
        name="luna-gaia-v3.57-clean-v3.20-step-isolated-earliest-module-reservoir-anchor-selector",
        version=AGENT_JUDGE_LUNA_GAIA_V3_57_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_57_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_57_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_plus_one_fresh_prefix_bounded_local_"
            "taxonomy_session_per_step_with_promotion_safe_system_sources_then_"
            "deterministic_earliest_positive_per_module_reservoir_then_one_"
            "anchor_aware_exact_copy_selector"
        ),
        build_task=build_agent_judge_luna_gaia_v3_57_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_57_predictions,
    ),
    "luna-gaia-v3.58-clean-v3.20-step-isolated-module-reservoir-pairwise-observed-continuation-reducer": AgentJudgeProtocol(
        name="luna-gaia-v3.58-clean-v3.20-step-isolated-module-reservoir-pairwise-observed-continuation-reducer",
        version=AGENT_JUDGE_LUNA_GAIA_V3_58_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_58_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_58_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_plus_one_fresh_prefix_bounded_local_"
            "taxonomy_session_per_step_with_promotion_safe_system_sources_then_"
            "deterministic_earliest_positive_per_module_reservoir_then_isolated_"
            "anchor_representative_observed_continuation_pairs_and_validator_"
            "enforced_earliest_eligible_exact_copy_reducer"
        ),
        build_task=build_agent_judge_luna_gaia_v3_58_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_58_predictions,
    ),
    "luna-gaia-v3.59-clean-v3.20-step-isolated-module-reservoir-pairwise-observed-continuation-deterministic-assembly": AgentJudgeProtocol(
        name="luna-gaia-v3.59-clean-v3.20-step-isolated-module-reservoir-pairwise-observed-continuation-deterministic-assembly",
        version=AGENT_JUDGE_LUNA_GAIA_V3_59_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_59_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_59_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_plus_one_fresh_prefix_bounded_local_"
            "taxonomy_session_per_step_then_bounded_module_representatives_then_"
            "semantic_only_observed_continuation_pair_assessments_with_all_"
            "identity_hash_prediction_and_reducer_fields_deterministically_assembled"
        ),
        build_task=build_agent_judge_luna_gaia_v3_59_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_59_predictions,
    ),
    "luna-gaia-v3.60-clean-v3.20-retrospective-prefix-ledger-closure": AgentJudgeProtocol(
        name="luna-gaia-v3.60-clean-v3.20-retrospective-prefix-ledger-closure",
        version=AGENT_JUDGE_LUNA_GAIA_V3_60_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_60_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_60_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_then_one_fresh_complete_"
            "retrospective_assessment_of_every_pre_anchor_sparse_ledger_row_"
            "then_deterministic_earliest_qualifying_exact_copy_reducer"
        ),
        build_task=build_agent_judge_luna_gaia_v3_60_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_60_predictions,
    ),
    "luna-gaia-v3.61-clean-v3.20-decision-time-evidence-maturity-census-challenger": AgentJudgeProtocol(
        name="luna-gaia-v3.61-clean-v3.20-decision-time-evidence-maturity-census-challenger",
        version=AGENT_JUDGE_LUNA_GAIA_V3_61_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_61_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_61_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_then_complete_chronological_"
            "decision_time_evidence_maturity_census_with_at_most_one_"
            "boundary_then_default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_luna_gaia_v3_61_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_61_predictions,
    ),
    "luna-gaia-v3.62-clean-v3.20-full-local-step-pairwise-reducer": AgentJudgeProtocol(
        name="luna-gaia-v3.62-clean-v3.20-full-local-step-pairwise-reducer",
        version=AGENT_JUDGE_LUNA_GAIA_V3_62_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_62_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_62_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_plus_one_fresh_prefix_bounded_local_"
            "taxonomy_session_per_step_then_every_positive_step_compared_"
            "pairwise_with_anchor_then_deterministic_earliest_winner_exact_copy"
        ),
        build_task=build_agent_judge_luna_gaia_v3_62_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_62_predictions,
    ),
    "luna-gaia-v3.63-clean-v3.20-heterogeneous-critical-boundary-panel": AgentJudgeProtocol(
        name="luna-gaia-v3.63-clean-v3.20-heterogeneous-critical-boundary-panel",
        version=AGENT_JUDGE_LUNA_GAIA_V3_63_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_63_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_63_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_plus_three_isolated_heterogeneous_"
            "complete_boundary_specialists_then_origin_blind_anchor_preserving_"
            "failure_owner_exact_copy_selector"
        ),
        build_task=build_agent_judge_luna_gaia_v3_63_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_63_predictions,
    ),
    "luna-gaia-v3.64-clean-v3.20-heterogeneous-critical-boundary-panel": AgentJudgeProtocol(
        name="luna-gaia-v3.64-clean-v3.20-heterogeneous-critical-boundary-panel",
        version=AGENT_JUDGE_LUNA_GAIA_V3_64_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_64_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_64_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_plus_three_isolated_heterogeneous_"
            "complete_boundary_specialists_then_anchor_preserving_failure_"
            "owner_exact_copy_selector_with_attempt_scoped_runtime"
        ),
        build_task=build_agent_judge_luna_gaia_v3_64_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_64_predictions,
    ),
    "luna-gaia-v3.65-clean-v3.20-outcome-conditioned-global-boundary-proposal-duel": AgentJudgeProtocol(
        name="luna-gaia-v3.65-clean-v3.20-outcome-conditioned-global-boundary-proposal-duel",
        version=AGENT_JUDGE_LUNA_GAIA_V3_65_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_65_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_65_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_plus_one_anchor_blind_outcome_"
            "conditioned_global_boundary_proposal_then_bounded_default_keep_"
            "exact_copy_duel_with_attempt_local_runtime"
        ),
        build_task=build_agent_judge_luna_gaia_v3_65_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_65_predictions,
    ),
    "luna-gaia-v3.66-clean-v3.20-exact-predicate-acquisition-boundary-reducer": AgentJudgeProtocol(
        name="luna-gaia-v3.66-clean-v3.20-exact-predicate-acquisition-boundary-reducer",
        version=AGENT_JUDGE_LUNA_GAIA_V3_66_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_66_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_66_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_then_one_exact_predicate_acquisition_"
            "boundary_reducer_with_deterministic_exact_copy_selection_and_"
            "response_only_read_only_runtime"
        ),
        build_task=build_agent_judge_luna_gaia_v3_66_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_66_predictions,
    ),
    "luna-gaia-v3.67-clean-v3.20-exact-predicate-acquisition-boundary-reducer-read-only-input": AgentJudgeProtocol(
        name="luna-gaia-v3.67-clean-v3.20-exact-predicate-acquisition-boundary-reducer-read-only-input",
        version=AGENT_JUDGE_LUNA_GAIA_V3_67_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_67_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_67_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_then_one_exact_predicate_acquisition_"
            "boundary_reducer_with_deterministic_exact_copy_selection_and_"
            "staged_exact_read_only_input"
        ),
        build_task=build_agent_judge_luna_gaia_v3_67_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_67_predictions,
    ),
    "luna-gaia-v3.68-clean-v3.20-exact-predicate-acquisition-boundary-reducer-compact-embedded-input": AgentJudgeProtocol(
        name="luna-gaia-v3.68-clean-v3.20-exact-predicate-acquisition-boundary-reducer-compact-embedded-input",
        version=AGENT_JUDGE_LUNA_GAIA_V3_68_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_68_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_68_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_then_one_exact_predicate_acquisition_"
            "boundary_reducer_with_deterministic_exact_copy_selection_and_"
            "single_copy_compact_embedded_judge_view"
        ),
        build_task=build_agent_judge_luna_gaia_v3_68_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_68_predictions,
    ),
    "luna-gaia-v3.69-clean-v3.20-exact-predicate-acquisition-boundary-reducer-runtime-integrated": AgentJudgeProtocol(
        name="luna-gaia-v3.69-clean-v3.20-exact-predicate-acquisition-boundary-reducer-runtime-integrated",
        version=AGENT_JUDGE_LUNA_GAIA_V3_69_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_69_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_69_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_then_one_exact_predicate_acquisition_"
            "boundary_reducer_with_deterministic_exact_copy_selection_and_"
            "runtime_integrated_single_copy_compact_embedded_judge_view"
        ),
        build_task=build_agent_judge_luna_gaia_v3_69_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_69_predictions,
    ),
    "luna-gaia-v3.70-clean-v3.20-exact-predicate-acquisition-boundary-reducer-owner-explicit": AgentJudgeProtocol(
        name="luna-gaia-v3.70-clean-v3.20-exact-predicate-acquisition-boundary-reducer-owner-explicit",
        version=AGENT_JUDGE_LUNA_GAIA_V3_70_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_70_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_70_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_then_one_exact_predicate_acquisition_"
            "boundary_reducer_with_deterministic_exact_copy_selection_and_"
            "owner_explicit_validator_aligned_embedded_judge_view"
        ),
        build_task=build_agent_judge_luna_gaia_v3_70_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_70_predictions,
    ),
    "luna-gaia-v3.71-clean-v3.20-exact-predicate-acquisition-boundary-reducer-evidence-materialized": AgentJudgeProtocol(
        name="luna-gaia-v3.71-clean-v3.20-exact-predicate-acquisition-boundary-reducer-evidence-materialized",
        version=AGENT_JUDGE_LUNA_GAIA_V3_71_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_71_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_71_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_then_one_exact_predicate_acquisition_"
            "boundary_reducer_with_deterministic_exact_copy_selection_owner_explicit_"
            "input_and_invalid_agent_evidence_exact_copy_materialization"
        ),
        build_task=build_agent_judge_luna_gaia_v3_71_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_71_predictions,
    ),
    "luna-gaia-v3.72-clean-v3.20-exact-predicate-acquisition-boundary-reducer-binding-materialized": AgentJudgeProtocol(
        name="luna-gaia-v3.72-clean-v3.20-exact-predicate-acquisition-boundary-reducer-binding-materialized",
        version=AGENT_JUDGE_LUNA_GAIA_V3_72_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_72_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_72_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_then_one_exact_predicate_acquisition_"
            "boundary_reducer_owner_evidence_materialized_and_unbound_candidate_"
            "deterministically_vetoed_to_anchor"
        ),
        build_task=build_agent_judge_luna_gaia_v3_72_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_72_predictions,
    ),
    "luna-gaia-v3.73-clean-v3.20-exact-predicate-acquisition-boundary-reducer-auditor-corrected": AgentJudgeProtocol(
        name="luna-gaia-v3.73-clean-v3.20-exact-predicate-acquisition-boundary-reducer-auditor-corrected",
        version=AGENT_JUDGE_LUNA_GAIA_V3_73_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_73_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_73_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_then_one_exact_predicate_acquisition_"
            "boundary_reducer_with_owner_evidence_and_binding_materialization_"
            "plus_correct_owner_document_access_audit"
        ),
        build_task=build_agent_judge_luna_gaia_v3_73_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_73_predictions,
    ),
    "luna-gaia-v3.74-clean-v3.20-exact-predicate-acquisition-boundary-reducer-owner-materialized": AgentJudgeProtocol(
        name="luna-gaia-v3.74-clean-v3.20-exact-predicate-acquisition-boundary-reducer-owner-materialized",
        version=AGENT_JUDGE_LUNA_GAIA_V3_74_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_74_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_74_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_then_one_exact_predicate_acquisition_"
            "boundary_reducer_with_same_step_owner_evidence_and_binding_"
            "materialization_plus_correct_owner_document_access_audit"
        ),
        build_task=build_agent_judge_luna_gaia_v3_74_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_74_predictions,
    ),
    "luna-gaia-v3.75-clean-v3.20-sparse-ledger-global-boundary-selector": AgentJudgeProtocol(
        name="luna-gaia-v3.75-clean-v3.20-sparse-ledger-global-boundary-selector",
        version=AGENT_JUDGE_LUNA_GAIA_V3_75_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_75_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_75_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_then_all_sparse_ledger_steps_plus_at_"
            "most_one_later_boundary_in_one_global_selector_with_model_frozen_step"
        ),
        build_task=build_agent_judge_luna_gaia_v3_75_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_75_predictions,
    ),
    "luna-gaia-v3.76-clean-v3.20-sparse-ledger-global-boundary-selector-runtime-repair": AgentJudgeProtocol(
        name=(
            "luna-gaia-v3.76-clean-v3.20-sparse-ledger-global-boundary-selector-"
            "runtime-repair"
        ),
        version=AGENT_JUDGE_LUNA_GAIA_V3_76_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_76_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_76_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_then_all_sparse_ledger_steps_plus_at_"
            "most_one_later_boundary_in_one_global_selector_with_model_frozen_step_"
            "and_correct_sparse_selector_freeze_contract"
        ),
        build_task=build_agent_judge_luna_gaia_v3_76_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_76_predictions,
    ),
    "luna-gaia-v3.77-clean-v3.20-factorized-sparse-ledger-pairwise-selector": AgentJudgeProtocol(
        name=(
            "luna-gaia-v3.77-clean-v3.20-factorized-sparse-ledger-"
            "pairwise-selector"
        ),
        version=AGENT_JUDGE_LUNA_GAIA_V3_77_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_77_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_77_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_then_anchor_blind_local_facts_for_"
            "each_native_sparse_ledger_step_then_independent_pairwise_global_"
            "selector_with_exact_copy_or_anchor_keep"
        ),
        build_task=build_agent_judge_luna_gaia_v3_77_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_77_predictions,
    ),
    "luna-gaia-v3.78-clean-v3.20-factorized-sparse-ledger-pairwise-selector-contract-repair": AgentJudgeProtocol(
        name=(
            "luna-gaia-v3.78-clean-v3.20-factorized-sparse-ledger-pairwise-"
            "selector-contract-repair"
        ),
        version=AGENT_JUDGE_LUNA_GAIA_V3_78_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_78_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_78_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_then_anchor_blind_local_facts_for_"
            "each_native_sparse_ledger_step_then_independent_pairwise_global_"
            "selector_with_step_invariant_redundant_contract_normalization"
        ),
        build_task=build_agent_judge_luna_gaia_v3_78_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_78_predictions,
    ),
    "luna-gaia-v3.79-clean-v3.20-outcome-conditioned-predicate-handoff-tournament": AgentJudgeProtocol(
        name=(
            "luna-gaia-v3.79-clean-v3.20-outcome-conditioned-predicate-handoff-"
            "tournament"
        ),
        version=AGENT_JUDGE_LUNA_GAIA_V3_79_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_79_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_79_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_then_one_outcome_conditioned_exact_"
            "predicate_handoff_tournament_over_every_native_sparse_ledger_step"
        ),
        build_task=build_agent_judge_luna_gaia_v3_79_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_79_predictions,
    ),
    "luna-gaia-v3.80-clean-v3.20-outcome-conditioned-predicate-handoff-tournament-taxonomy-repair": AgentJudgeProtocol(
        name=(
            "luna-gaia-v3.80-clean-v3.20-outcome-conditioned-predicate-handoff-"
            "tournament-taxonomy-repair"
        ),
        version=AGENT_JUDGE_LUNA_GAIA_V3_80_VERSION,
        model=AGENT_JUDGE_LUNA_GAIA_V3_80_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_GAIA_V3_80_REASONING_EFFORT,
        semantic_topology=(
            "unchanged_clean_v3_20_anchor_then_one_outcome_conditioned_exact_"
            "predicate_handoff_tournament_with_step_invariant_taxonomy_repair"
        ),
        build_task=build_agent_judge_luna_gaia_v3_80_task,
        validate_predictions=validate_agent_judge_luna_gaia_v3_80_predictions,
    ),
    "gaia-v3.81-clean-v3.20-model-only-sol-medium": AgentJudgeProtocol(
        name="gaia-v3.81-clean-v3.20-model-only-sol-medium",
        version=AGENT_JUDGE_GAIA_V3_81_VERSION,
        model=AGENT_JUDGE_GAIA_V3_81_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_81_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_sol_sessions_with_exact_v3_20_packet_state_anchor_"
            "earliest_causal_challenger_and_default_keep_arbiter"
        ),
        build_task=build_agent_judge_gaia_v3_81_task,
        validate_predictions=validate_agent_judge_gaia_v3_81_predictions,
    ),
    "gaia-v3.82-clean-v3.20-model-only-terra-medium": AgentJudgeProtocol(
        name="gaia-v3.82-clean-v3.20-model-only-terra-medium",
        version=AGENT_JUDGE_GAIA_V3_82_VERSION,
        model=AGENT_JUDGE_GAIA_V3_82_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_82_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_terra_sessions_with_exact_v3_20_packet_state_anchor_"
            "earliest_causal_challenger_and_default_keep_arbiter"
        ),
        build_task=build_agent_judge_gaia_v3_82_task,
        validate_predictions=validate_agent_judge_gaia_v3_82_predictions,
    ),
    "gaia-v3.83-clean-v3.20-model-only-gpt55-medium": AgentJudgeProtocol(
        name="gaia-v3.83-clean-v3.20-model-only-gpt55-medium",
        version=AGENT_JUDGE_GAIA_V3_83_VERSION,
        model=AGENT_JUDGE_GAIA_V3_83_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_83_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_gpt55_sessions_with_exact_v3_20_packet_state_anchor_"
            "earliest_causal_challenger_and_default_keep_arbiter"
        ),
        build_task=build_agent_judge_gaia_v3_83_task,
        validate_predictions=validate_agent_judge_gaia_v3_83_predictions,
    ),
    "gaia-v3.84-model-only-gpt54-medium": AgentJudgeProtocol(
        name="gaia-v3.84-model-only-gpt54-medium",
        version=AGENT_JUDGE_GAIA_V3_84_VERSION,
        model=AGENT_JUDGE_GAIA_V3_84_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_84_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_three_stage_semantics_with_gpt54_model_only_swap"
        ),
        build_task=build_agent_judge_gaia_v3_84_task,
        validate_predictions=validate_agent_judge_gaia_v3_84_predictions,
    ),
    "gaia-v3.85-gpt55-high-effort-only": AgentJudgeProtocol(
        name="gaia-v3.85-gpt55-high-effort-only",
        version=AGENT_JUDGE_GAIA_V3_85_VERSION,
        model=AGENT_JUDGE_GAIA_V3_85_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_85_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_three_stage_semantics_with_gpt55_high_effort_only"
        ),
        build_task=build_agent_judge_gaia_v3_85_task,
        validate_predictions=validate_agent_judge_gaia_v3_85_predictions,
    ),
    "gaia-v3.86-gpt55-bounded-typed-boundary-challenger": AgentJudgeProtocol(
        name="gaia-v3.86-gpt55-bounded-typed-boundary-challenger",
        version=AGENT_JUDGE_GAIA_V3_86_VERSION,
        model=AGENT_JUDGE_GAIA_V3_86_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_86_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_anchor_one_bounded_typed_boundary_later_challenger_"
            "unchanged_default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_gaia_v3_86_task,
        validate_predictions=validate_agent_judge_gaia_v3_86_predictions,
    ),
    "gaia-v3.87-gpt55-evidence-lifecycle-challenger": AgentJudgeProtocol(
        name="gaia-v3.87-gpt55-evidence-lifecycle-challenger",
        version=AGENT_JUDGE_GAIA_V3_87_VERSION,
        model=AGENT_JUDGE_GAIA_V3_87_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_87_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_anchor_one_evidence_grounded_bidirectional_"
            "error_lifecycle_challenger_default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_gaia_v3_87_task,
        validate_predictions=validate_agent_judge_gaia_v3_87_predictions,
    ),
    "gaia-v3.88-gpt55-sparse-influence-graph-challenger": AgentJudgeProtocol(
        name="gaia-v3.88-gpt55-sparse-influence-graph-challenger",
        version=AGENT_JUDGE_GAIA_V3_88_VERSION,
        model=AGENT_JUDGE_GAIA_V3_88_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_88_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_anchor_one_sparse_producer_consumer_influence_"
            "graph_challenger_default_keep_exact_copy_arbiter"
        ),
        build_task=build_agent_judge_gaia_v3_88_task,
        validate_predictions=validate_agent_judge_gaia_v3_88_predictions,
    ),
    "gaia-v3.89-gpt55-sol-heterogeneous-challenger": AgentJudgeProtocol(
        name="gaia-v3.89-gpt55-sol-heterogeneous-challenger",
        version=AGENT_JUDGE_GAIA_V3_89_VERSION,
        model=AGENT_JUDGE_GAIA_V3_89_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_89_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_gpt55_anchor_exact_v3_83_earliest_causal_"
            "challenger_executed_by_sol_unchanged_gpt55_default_keep_arbiter"
        ),
        build_task=build_agent_judge_gaia_v3_89_task,
        validate_predictions=validate_agent_judge_gaia_v3_89_predictions,
    ),
    "gaia-v3.90-gpt55-outcome-conditioned-predicate-handoff-tournament": AgentJudgeProtocol(
        name="gaia-v3.90-gpt55-outcome-conditioned-predicate-handoff-tournament",
        version=AGENT_JUDGE_GAIA_V3_90_VERSION,
        model=AGENT_JUDGE_GAIA_V3_90_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_90_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_gpt55_packet_state_anchor_and_native_ledger_then_"
            "one_outcome_conditioned_exact_predicate_handoff_tournament"
        ),
        build_task=build_agent_judge_gaia_v3_90_task,
        validate_predictions=validate_agent_judge_gaia_v3_90_predictions,
    ),
    "gaia-v3.91-gpt55-file-inspected-predicate-handoff-tournament": AgentJudgeProtocol(
        name="gaia-v3.91-gpt55-file-inspected-predicate-handoff-tournament",
        version=AGENT_JUDGE_GAIA_V3_91_VERSION,
        model=AGENT_JUDGE_GAIA_V3_91_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_91_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_gpt55_packet_state_anchor_then_one_file_inspected_"
            "outcome_conditioned_exact_predicate_handoff_tournament"
        ),
        build_task=build_agent_judge_gaia_v3_91_task,
        validate_predictions=validate_agent_judge_gaia_v3_91_predictions,
    ),
    "gaia-v3.92-gpt55-singleton-safe-file-inspected-predicate-handoff-tournament": AgentJudgeProtocol(
        name="gaia-v3.92-gpt55-singleton-safe-file-inspected-predicate-handoff-tournament",
        version=AGENT_JUDGE_GAIA_V3_92_VERSION,
        model=AGENT_JUDGE_GAIA_V3_92_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_92_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_gpt55_anchor_then_one_singleton_safe_file_inspected_"
            "outcome_conditioned_predicate_handoff_tournament"
        ),
        build_task=build_agent_judge_gaia_v3_92_task,
        validate_predictions=validate_agent_judge_gaia_v3_92_predictions,
    ),
    "gaia-v3.93-gpt55-audited-no-bwrap-predicate-handoff-tournament": AgentJudgeProtocol(
        name="gaia-v3.93-gpt55-audited-no-bwrap-predicate-handoff-tournament",
        version=AGENT_JUDGE_GAIA_V3_93_VERSION,
        model=AGENT_JUDGE_GAIA_V3_93_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_93_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_gpt55_anchor_then_one_audited_no_bwrap_"
            "outcome_conditioned_predicate_handoff_tournament"
        ),
        build_task=build_agent_judge_gaia_v3_93_task,
        validate_predictions=validate_agent_judge_gaia_v3_93_predictions,
    ),
    "gaia-v3.94-gpt55-response-only-audited-no-bwrap-predicate-handoff-tournament": AgentJudgeProtocol(
        name="gaia-v3.94-gpt55-response-only-audited-no-bwrap-predicate-handoff-tournament",
        version=AGENT_JUDGE_GAIA_V3_94_VERSION,
        model=AGENT_JUDGE_GAIA_V3_94_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_94_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_gpt55_anchor_then_one_literal_response_only_audited_"
            "no_bwrap_predicate_handoff_tournament"
        ),
        build_task=build_agent_judge_gaia_v3_94_task,
        validate_predictions=validate_agent_judge_gaia_v3_94_predictions,
    ),
    "gaia-v3.95-gpt55-dual-stage-response-only-audited-tournament": AgentJudgeProtocol(
        name="gaia-v3.95-gpt55-dual-stage-response-only-audited-tournament",
        version=AGENT_JUDGE_GAIA_V3_95_VERSION,
        model=AGENT_JUDGE_GAIA_V3_95_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_95_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_gpt55_anchor_then_one_dual_stage_response_only_"
            "audited_predicate_handoff_tournament"
        ),
        build_task=build_agent_judge_gaia_v3_95_task,
        validate_predictions=validate_agent_judge_gaia_v3_95_predictions,
    ),
    "gaia-v3.96-gpt55-normalized-access-audited-tournament": AgentJudgeProtocol(
        name="gaia-v3.96-gpt55-normalized-access-audited-tournament",
        version=AGENT_JUDGE_GAIA_V3_96_VERSION,
        model=AGENT_JUDGE_GAIA_V3_96_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_96_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_gpt55_anchor_then_one_normalized_access_audited_"
            "predicate_handoff_tournament"
        ),
        build_task=build_agent_judge_gaia_v3_96_task,
        validate_predictions=validate_agent_judge_gaia_v3_96_predictions,
    ),
    "gaia-v3.97-gpt55-python3-bounded-access-audited-tournament": AgentJudgeProtocol(
        name="gaia-v3.97-gpt55-python3-bounded-access-audited-tournament",
        version=AGENT_JUDGE_GAIA_V3_97_VERSION,
        model=AGENT_JUDGE_GAIA_V3_97_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_97_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_gpt55_anchor_then_one_python3_bounded_access_"
            "audited_predicate_handoff_tournament"
        ),
        build_task=build_agent_judge_gaia_v3_97_task,
        validate_predictions=validate_agent_judge_gaia_v3_97_predictions,
    ),
    "gaia-v3.98-gpt55-stage-bounded-access-audited-tournament": AgentJudgeProtocol(
        name="gaia-v3.98-gpt55-stage-bounded-access-audited-tournament",
        version=AGENT_JUDGE_GAIA_V3_98_VERSION,
        model=AGENT_JUDGE_GAIA_V3_98_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_98_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_gpt55_anchor_then_one_stage_bounded_access_"
            "audited_predicate_handoff_tournament"
        ),
        build_task=build_agent_judge_gaia_v3_98_task,
        validate_predictions=validate_agent_judge_gaia_v3_98_predictions,
    ),
    "gaia-v3.99-gpt55-cwd-robust-access-audited-tournament": AgentJudgeProtocol(
        name="gaia-v3.99-gpt55-cwd-robust-access-audited-tournament",
        version=AGENT_JUDGE_GAIA_V3_99_VERSION,
        model=AGENT_JUDGE_GAIA_V3_99_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_99_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_gpt55_anchor_then_one_cwd_robust_access_"
            "audited_predicate_handoff_tournament"
        ),
        build_task=build_agent_judge_gaia_v3_99_task,
        validate_predictions=validate_agent_judge_gaia_v3_99_predictions,
    ),
    "gaia-v3.100-gpt55-short-bound-access-audited-tournament": AgentJudgeProtocol(
        name="gaia-v3.100-gpt55-short-bound-access-audited-tournament",
        version=AGENT_JUDGE_GAIA_V3_100_VERSION,
        model=AGENT_JUDGE_GAIA_V3_100_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_100_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_gpt55_anchor_then_one_short_bound_access_"
            "audited_predicate_handoff_tournament"
        ),
        build_task=build_agent_judge_gaia_v3_100_task,
        validate_predictions=validate_agent_judge_gaia_v3_100_predictions,
    ),
    "gaia-v3.101-gpt55-stage-local-access-validated-tournament": AgentJudgeProtocol(
        name="gaia-v3.101-gpt55-stage-local-access-validated-tournament",
        version=AGENT_JUDGE_GAIA_V3_101_VERSION,
        model=AGENT_JUDGE_GAIA_V3_101_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_101_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_gpt55_anchor_then_one_stage_local_access_"
            "validated_predicate_handoff_tournament"
        ),
        build_task=build_agent_judge_gaia_v3_101_task,
        validate_predictions=validate_agent_judge_gaia_v3_101_predictions,
    ),
    "gaia-v3.102-gpt55-three-attempt-access-validated-tournament": AgentJudgeProtocol(
        name="gaia-v3.102-gpt55-three-attempt-access-validated-tournament",
        version=AGENT_JUDGE_GAIA_V3_102_VERSION,
        model=AGENT_JUDGE_GAIA_V3_102_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_102_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_gpt55_anchor_then_one_three_attempt_access_"
            "validated_predicate_handoff_tournament"
        ),
        build_task=build_agent_judge_gaia_v3_102_task,
        validate_predictions=validate_agent_judge_gaia_v3_102_predictions,
    ),
    "gaia-v3.103-gpt55-native-initial-probe-veto-tournament": AgentJudgeProtocol(
        name="gaia-v3.103-gpt55-native-initial-probe-veto-tournament",
        version=AGENT_JUDGE_GAIA_V3_103_VERSION,
        model=AGENT_JUDGE_GAIA_V3_103_MODEL,
        reasoning_effort=AGENT_JUDGE_GAIA_V3_103_REASONING_EFFORT,
        semantic_topology=(
            "accepted_v3_83_gpt55_anchor_then_one_native_initial_probe_veto_"
            "predicate_handoff_tournament"
        ),
        build_task=build_agent_judge_gaia_v3_103_task,
        validate_predictions=validate_agent_judge_gaia_v3_103_predictions,
    ),
    "luna-v3-serial": AgentJudgeProtocol(
        name="luna-v3-serial",
        version=AGENT_JUDGE_LUNA_V3_SERIAL_VERSION,
        model=AGENT_JUDGE_LUNA_V3_SERIAL_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V3_SERIAL_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_serial_agents_freeze_step_then_module_then_type_luna"
        ),
        build_task=build_agent_judge_luna_v3_serial_task,
        validate_predictions=validate_agent_judge_luna_v3_serial_predictions,
    ),
    "luna-v3-serial-v2": AgentJudgeProtocol(
        name="luna-v3-serial-v2",
        version=AGENT_JUDGE_LUNA_V3_SERIAL_V2_VERSION,
        model=AGENT_JUDGE_LUNA_V3_SERIAL_V2_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V3_SERIAL_V2_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_serial_agents_with_deterministic_type_evidence_sources"
        ),
        build_task=build_agent_judge_luna_v3_serial_v2_task,
        validate_predictions=validate_agent_judge_luna_v3_serial_v2_predictions,
    ),
    "luna-v4": AgentJudgeProtocol(
        name="luna-v4",
        version=AGENT_JUDGE_LUNA_V4_VERSION,
        model=AGENT_JUDGE_LUNA_V4_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V4_REASONING_EFFORT,
        semantic_topology=(
            "chronological_breakpoint_same_defect_backtrace_then_owner_luna"
        ),
        build_task=build_agent_judge_luna_v4_task,
        validate_predictions=validate_agent_judge_luna_v4_predictions,
    ),
    "luna-v5": AgentJudgeProtocol(
        name="luna-v5",
        version=AGENT_JUDGE_LUNA_V5_VERSION,
        model=AGENT_JUDGE_LUNA_V5_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V5_REASONING_EFFORT,
        semantic_topology=(
            "module_lane_recall_categorical_first_mature_arbitration_luna"
        ),
        build_task=build_agent_judge_luna_v5_task,
        validate_predictions=validate_agent_judge_luna_v5_predictions,
    ),
    "luna-v6": AgentJudgeProtocol(
        name="luna-v6",
        version=AGENT_JUDGE_LUNA_V6_VERSION,
        model=AGENT_JUDGE_LUNA_V6_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V6_REASONING_EFFORT,
        semantic_topology=(
            "v3_draft_conservative_execution_recovery_probe_handoff_correction_luna"
        ),
        build_task=build_agent_judge_luna_v6_task,
        validate_predictions=validate_agent_judge_luna_v6_predictions,
    ),
    "luna-v7": AgentJudgeProtocol(
        name="luna-v7",
        version=AGENT_JUDGE_LUNA_V7_VERSION,
        model=AGENT_JUDGE_LUNA_V7_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V7_REASONING_EFFORT,
        semantic_topology=(
            "same_case_luna_v3_incumbent_strictly_earlier_conservative_review"
        ),
        build_task=build_agent_judge_luna_v7_task,
        validate_predictions=validate_agent_judge_luna_v7_predictions,
    ),
    "luna-v8": AgentJudgeProtocol(
        name="luna-v8",
        version=AGENT_JUDGE_LUNA_V8_VERSION,
        model=AGENT_JUDGE_LUNA_V8_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V8_REASONING_EFFORT,
        semantic_topology=(
            "same_case_v3_incumbent_earliest_independent_challenger_review"
        ),
        build_task=build_agent_judge_luna_v8_task,
        validate_predictions=validate_agent_judge_luna_v8_predictions,
    ),
    "luna-v9": AgentJudgeProtocol(
        name="luna-v9",
        version=AGENT_JUDGE_LUNA_V9_VERSION,
        model=AGENT_JUDGE_LUNA_V9_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V9_REASONING_EFFORT,
        semantic_topology=(
            "blind_same_case_v3_v4_dual_proposal_boundary_arbitration"
        ),
        build_task=build_agent_judge_luna_v9_task,
        validate_predictions=validate_agent_judge_luna_v9_predictions,
    ),
    "luna-v10": AgentJudgeProtocol(
        name="luna-v10",
        version=AGENT_JUDGE_LUNA_V10_VERSION,
        model=AGENT_JUDGE_LUNA_V10_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V10_REASONING_EFFORT,
        semantic_topology=(
            "single_v3_incumbent_confirmation_wrapper_recovery_hard_veto_review"
        ),
        build_task=build_agent_judge_luna_v10_task,
        validate_predictions=validate_agent_judge_luna_v10_predictions,
    ),
    "luna-v11": AgentJudgeProtocol(
        name="luna-v11",
        version=AGENT_JUDGE_LUNA_V11_VERSION,
        model=AGENT_JUDGE_LUNA_V11_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V11_REASONING_EFFORT,
        semantic_topology=(
            "v3_incumbent_planning_inefficient_sink_isolated_relocation"
        ),
        build_task=build_agent_judge_luna_v11_task,
        validate_predictions=validate_agent_judge_luna_v11_predictions,
    ),
    "luna-v12": AgentJudgeProtocol(
        name="luna-v12",
        version=AGENT_JUDGE_LUNA_V12_VERSION,
        model=AGENT_JUDGE_LUNA_V12_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V12_REASONING_EFFORT,
        semantic_topology=(
            "v3_sink_forced_single_local_failure_boundary_replacement"
        ),
        build_task=build_agent_judge_luna_v12_task,
        validate_predictions=validate_agent_judge_luna_v12_predictions,
    ),
    "luna-v12-standalone": AgentJudgeProtocol(
        name="luna-v12-standalone",
        version=AGENT_JUDGE_LUNA_V12_STANDALONE_VERSION,
        model=AGENT_JUDGE_LUNA_V12_STANDALONE_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V12_STANDALONE_REASONING_EFFORT,
        semantic_topology=(
            "proposal_free_all_module_single_local_failure_competition_luna"
        ),
        build_task=build_agent_judge_luna_v12_standalone_task,
        validate_predictions=validate_agent_judge_luna_v12_standalone_predictions,
    ),
    "luna-v13-unified": AgentJudgeProtocol(
        name="luna-v13-unified",
        version=AGENT_JUDGE_LUNA_V13_UNIFIED_VERSION,
        model=AGENT_JUDGE_LUNA_V13_UNIFIED_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V13_UNIFIED_REASONING_EFFORT,
        semantic_topology=(
            "proposal_free_one_session_chronological_and_local_step_"
            "locators_then_uniform_arbitration_and_step_locked_taxonomy"
        ),
        build_task=build_agent_judge_luna_v13_unified_task,
        validate_predictions=validate_agent_judge_luna_v13_unified_predictions,
    ),
    "luna-v14-unified": AgentJudgeProtocol(
        name="luna-v14-unified",
        version=AGENT_JUDGE_LUNA_V14_UNIFIED_VERSION,
        model=AGENT_JUDGE_LUNA_V14_UNIFIED_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V14_UNIFIED_REASONING_EFFORT,
        semantic_topology=(
            "proposal_free_one_session_dual_owner_bound_evidence_atom_"
            "locators_then_uniform_arbitration_and_atom_locked_taxonomy"
        ),
        build_task=build_agent_judge_luna_v14_unified_task,
        validate_predictions=validate_agent_judge_luna_v14_unified_predictions,
    ),
    "luna-v15-unified": AgentJudgeProtocol(
        name="luna-v15-unified",
        version=AGENT_JUDGE_LUNA_V15_UNIFIED_VERSION,
        model=AGENT_JUDGE_LUNA_V15_UNIFIED_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V15_UNIFIED_REASONING_EFFORT,
        semantic_topology=(
            "proposal_free_one_session_three_step_only_locators_plus_"
            "derived_predecessor_neutral_arbitration_then_same_step_"
            "owner_atom_and_type"
        ),
        build_task=build_agent_judge_luna_v15_unified_task,
        validate_predictions=validate_agent_judge_luna_v15_unified_predictions,
    ),
    "luna-v16-unified": AgentJudgeProtocol(
        name="luna-v16-unified",
        version=AGENT_JUDGE_LUNA_V16_UNIFIED_VERSION,
        model=AGENT_JUDGE_LUNA_V16_UNIFIED_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V16_UNIFIED_REASONING_EFFORT,
        semantic_topology=(
            "proposal_free_one_session_three_owner_bound_evidence_witnesses_"
            "plus_parent_strategy_predecessor_lane_blind_uniform_arbitration_"
            "then_same_step_owner_atom_and_type"
        ),
        build_task=build_agent_judge_luna_v16_unified_task,
        validate_predictions=validate_agent_judge_luna_v16_unified_predictions,
    ),
    "luna-v17-unified": AgentJudgeProtocol(
        name="luna-v17-unified",
        version=AGENT_JUDGE_LUNA_V17_UNIFIED_VERSION,
        model=AGENT_JUDGE_LUNA_V17_UNIFIED_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_V17_UNIFIED_REASONING_EFFORT,
        semantic_topology=(
            "proposal_free_one_session_classification_precommitment_"
            "three_owner_neutral_anchors_bounded_pairwise_boundaries_"
            "global_arbitration_and_precommitted_owner_type"
        ),
        build_task=build_agent_judge_luna_v17_unified_task,
        validate_predictions=validate_agent_judge_luna_v17_unified_predictions,
    ),
    "luna-clean-debate-v1": AgentJudgeProtocol(
        name="luna-clean-debate-v1",
        version=AGENT_JUDGE_LUNA_DEBATE_V1_VERSION,
        model=AGENT_JUDGE_LUNA_DEBATE_V1_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_DEBATE_V1_REASONING_EFFORT,
        semantic_topology=(
            "fresh_chronological_draft_uniform_different_step_challenger_neutral_arbiter"
        ),
        build_task=build_luna_clean_debate_task,
        validate_predictions=validate_luna_clean_debate_predictions,
    ),
    "luna-clean-debate-v2": AgentJudgeProtocol(
        name="luna-clean-debate-v2",
        version=AGENT_JUDGE_LUNA_DEBATE_V2_VERSION,
        model=AGENT_JUDGE_LUNA_DEBATE_V2_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_DEBATE_V2_REASONING_EFFORT,
        semantic_topology=(
            "fresh_different_step_candidates_structured_causal_tournament"
        ),
        build_task=build_luna_clean_debate_v2_task,
        validate_predictions=validate_luna_clean_debate_v2_predictions,
    ),
    "luna-clean-debate-v3": AgentJudgeProtocol(
        name="luna-clean-debate-v3",
        version=AGENT_JUDGE_LUNA_DEBATE_V3_VERSION,
        model=AGENT_JUDGE_LUNA_DEBATE_V3_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_DEBATE_V3_REASONING_EFFORT,
        semantic_topology=(
            "three_fresh_distinct_candidates_structured_causal_panel"
        ),
        build_task=build_luna_clean_debate_v3_task,
        validate_predictions=validate_luna_clean_debate_v3_predictions,
    ),
    "luna-clean-debate-v4": AgentJudgeProtocol(
        name="luna-clean-debate-v4",
        version=AGENT_JUDGE_LUNA_DEBATE_V4_VERSION,
        model=AGENT_JUDGE_LUNA_DEBATE_V4_MODEL,
        reasoning_effort=AGENT_JUDGE_LUNA_DEBATE_V4_REASONING_EFFORT,
        semantic_topology=(
            "fresh_v1_candidates_root_precedence_exact_copy_tournament"
        ),
        build_task=build_luna_clean_debate_v4_task,
        validate_predictions=validate_luna_clean_debate_v4_predictions,
    ),
}


def resolve_agent_judge_protocol(
    protocol: str = DEFAULT_AGENT_JUDGE_PROTOCOL,
) -> AgentJudgeProtocol:
    """Resolve a frozen protocol name; Luna v12 is the active default."""

    try:
        return _AGENT_JUDGE_PROTOCOLS[protocol]
    except (KeyError, TypeError) as error:
        raise AgentJudgeWorkflowError(
            f"unsupported Agent Judge protocol: {protocol!r}"
        ) from error


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _read_json(path: Path, *, role: str) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise AgentJudgeWorkflowError(f"{role} is missing or invalid JSON") from error


def _atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(text, encoding="utf-8")
    temporary.replace(path)


def _write_once_text(path: Path, text: str, *, role: str) -> None:
    if path.exists():
        if not path.is_file():
            raise AgentJudgeWorkflowError(f"existing {role} is not a file")
        try:
            existing = path.read_text(encoding="utf-8")
        except (OSError, UnicodeError) as error:
            raise AgentJudgeWorkflowError(f"existing {role} is unreadable") from error
        if existing != text:
            raise AgentJudgeWorkflowError(
                f"existing {role} conflicts with the frozen Agent Judge run"
            )
        return
    _atomic_text(path, text)


def _atomic_json(path: Path, value: Any) -> None:
    _atomic_text(
        path,
        json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n",
    )


def _assert_gold_free(value: Any, *, location: str) -> None:
    forbidden = {
        "all_correct",
        "confidence",
        "critical_failure_module",
        "critical_failure_step",
        "critical_failure_type",
        "gold_error_type",
        "gold_event_id",
        "gold_module",
        "gold_reasoning",
        "gold_step",
        "score",
        "step_annotations",
        "step_exact",
        "step_module_exact",
    }
    if isinstance(value, Mapping):
        for key, item in value.items():
            normalized = str(key).casefold()
            if normalized in forbidden or normalized.startswith("gold_"):
                raise AgentJudgeWorkflowError(
                    f"{location} contains forbidden gold/scored field {key!r}"
                )
            _assert_gold_free(item, location=f"{location}.{key}")
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _assert_gold_free(item, location=f"{location}[{index}]")


def _load_public_cohort(path: Path) -> dict[str, Any]:
    value = _read_json(path, role="cohort manifest")
    if not isinstance(value, dict):
        raise AgentJudgeWorkflowError("cohort manifest must be an object")
    _assert_gold_free(value, location="cohort manifest")
    required = {
        "cohort_name",
        "cohort_sha256",
        "dataset_manifest_sha256",
        "trajectory_ids",
    }
    if not required.issubset(value):
        raise AgentJudgeWorkflowError(
            "cohort manifest is missing public identity fields"
        )
    trajectory_ids = value["trajectory_ids"]
    if (
        not isinstance(trajectory_ids, list)
        or not trajectory_ids
        or any(not isinstance(item, str) or not item for item in trajectory_ids)
        or len(set(trajectory_ids)) != len(trajectory_ids)
    ):
        raise AgentJudgeWorkflowError("cohort trajectory order is invalid")
    body = dict(value)
    claimed = body.pop("cohort_sha256")
    if claimed != stable_sha256(body):
        raise AgentJudgeWorkflowError("cohort manifest content hash is invalid")
    return value


def prepare_agent_judge_run(
    *,
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    run_dir: str | Path,
    protocol: str = DEFAULT_AGENT_JUDGE_PROTOCOL,
) -> dict[str, Any]:
    """Freeze one label-free Agent Judge run and its complete subagent task."""

    selected = resolve_agent_judge_protocol(protocol)
    prediction_path = Path(prediction_manifest_path).expanduser().resolve()
    cohort_path = Path(cohort_manifest_path).expanduser().resolve()
    root = Path(run_dir).expanduser().resolve()
    if root.exists() and not root.is_dir():
        raise AgentJudgeWorkflowError("Agent Judge run path is not a directory")

    manifest, cases = load_prediction_manifest(prediction_path)
    cohort = _load_public_cohort(cohort_path)
    case_order = [case.trajectory_id for case in cases]
    if case_order != cohort["trajectory_ids"]:
        raise AgentJudgeWorkflowError(
            "prediction manifest and cohort case order differ"
        )
    if (
        manifest["dataset_manifest_sha256"]
        != cohort["dataset_manifest_sha256"]
        or manifest["cohort_name"] != cohort["cohort_name"]
        or manifest["cohort_sha256"] != cohort["cohort_sha256"]
    ):
        raise AgentJudgeWorkflowError(
            "prediction manifest and cohort lineage differ"
        )

    predictions_path = root / PREDICTIONS_FILENAME
    task_path = root / AGENT_TASK_FILENAME
    preregistration_path = root / PREREGISTRATION_FILENAME
    task = selected.build_task(
        prediction_path,
        cohort_path,
        predictions_path,
    )
    task_text = task if task.endswith("\n") else task + "\n"
    task_sha256 = hashlib.sha256(task_text.encode("utf-8")).hexdigest()
    document: dict[str, Any] = {
        "schema_version": AGENT_JUDGE_RUN_SCHEMA_VERSION,
        "agent_judge_version": selected.version,
        "prompt_version": selected.version,
        "pipeline_version": selected.version,
        "execution": {
            "model": selected.model,
            "reasoning_effort": selected.reasoning_effort,
            "fresh_subagent_required": True,
            "orchestrator_managed": True,
            "external_llm_api_calls_forbidden": True,
        },
        "prediction_manifest": {
            "path": str(prediction_path),
            "file_sha256": _file_sha256(prediction_path),
            "content_sha256": manifest["prediction_manifest_sha256"],
            "dataset_manifest_sha256": manifest["dataset_manifest_sha256"],
            "cohort_name": manifest["cohort_name"],
            "cohort_sha256": manifest["cohort_sha256"],
            "entry_count": len(cases),
        },
        "cohort_manifest": {
            "path": str(cohort_path),
            "file_sha256": _file_sha256(cohort_path),
            "content_sha256": cohort["cohort_sha256"],
        },
        "case_order": case_order,
        "cases": [
            {
                "trajectory_id": case.trajectory_id,
                "trajectory_sha256": case.trajectory_sha256,
                "case_input_sha256": case.case_input_sha256,
                "step_event_mapping": [
                    {
                        "step": step,
                        "assistant_event_id": event_id,
                    }
                    for step, event_id in case.step_event_mapping
                ],
            }
            for case in cases
        ],
        "artifacts": {
            "run_dir": str(root),
            "preregistration_path": str(preregistration_path),
            "agent_task_path": str(task_path),
            "agent_task_sha256": task_sha256,
            "predictions_path": str(predictions_path),
            "prediction_audit_path": str(root / PREDICTION_AUDIT_FILENAME),
        },
    }
    document["preregistration_sha256"] = stable_sha256(document)

    # Write the task first.  A conflicting second preparation never mutates it;
    # the preregistration is written only after its exact task identity is fixed.
    _write_once_text(task_path, task_text, role="Agent Judge task")
    preregistration_text = (
        json.dumps(document, ensure_ascii=False, indent=2, default=str) + "\n"
    )
    _write_once_text(
        preregistration_path,
        preregistration_text,
        role="Agent Judge preregistration",
    )
    return document


def validate_agent_judge_run(
    *,
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    audit_path: str | Path | None = None,
    protocol: str = DEFAULT_AGENT_JUDGE_PROTOCOL,
) -> dict[str, Any]:
    """Run the diagnostics-layer strict validator and optionally persist it."""

    selected = resolve_agent_judge_protocol(protocol)
    audit = selected.validate_predictions(
        prediction_manifest_path,
        cohort_manifest_path,
        predictions_path,
    )
    if audit_path is not None:
        _atomic_json(Path(audit_path).expanduser().resolve(), audit)
    return audit


def _lineage_example(
    *,
    trajectory_id: str,
    examples: Mapping[str, BenchmarkExample],
    case: Any,
) -> BenchmarkExample:
    example = examples.get(trajectory_id)
    if example is None:
        raise AgentJudgeWorkflowError(
            f"cohort trajectory has no scoring example: {trajectory_id}"
        )
    expected_mapping = tuple(
        (item.original_step, item.critical_event_id)
        for item in example.mapping.steps
    )
    if (
        example.mapping.trajectory_sha256 != case.trajectory_sha256
        or expected_mapping != case.step_event_mapping
    ):
        raise AgentJudgeWorkflowError(
            f"scoring adaptation diverges for trajectory {trajectory_id}"
        )
    return example


def _scored_record(
    *,
    example: BenchmarkExample,
    case: Any,
    prediction: Mapping[str, Any],
    manifest_sha256: str,
    protocol: AgentJudgeProtocol,
) -> dict[str, Any]:
    label = example.label
    predicted_step = int(prediction["predicted_step"])
    predicted_module = str(prediction["predicted_module"])
    predicted_error_type = str(prediction["predicted_error_type"])
    predicted_event_id = case.event_for_step(predicted_step)
    if predicted_event_id is None:
        raise AgentJudgeWorkflowError("validated step has no public event mapping")
    step_exact = predicted_step == label.original_step
    step_module_exact = step_exact and predicted_module == label.module
    all_correct = (
        None
        if label.error_type is None
        else step_module_exact and predicted_error_type == label.error_type
    )
    return {
        "trajectory_id": label.trajectory_id,
        "environment": label.environment,
        "source_llm": label.source_llm,
        "method": AGENT_JUDGE_METHOD,
        "status": "success",
        "failure_stage": None,
        "failure_code": None,
        "failure_message": None,
        "gold_step": label.original_step,
        "gold_event_id": example.mapping.event_for_step(label.original_step),
        "gold_raw_module": label.raw_module,
        "gold_module": label.module,
        "gold_raw_error_type": label.raw_error_type,
        "gold_error_type": label.error_type,
        "gold_normalization_notes": list(label.normalization_notes),
        "predicted_step": predicted_step,
        "judge_reported_step": predicted_step,
        "predicted_event_id": predicted_event_id,
        "predicted_module": predicted_module,
        "predicted_error_type": predicted_error_type,
        "step_exact": step_exact,
        "step_module_exact": step_module_exact,
        "all_correct": all_correct,
        "evidence_quote": prediction["evidence_quote"],
        "root_cause": prediction["root_cause"],
        "causal_summary": prediction["causal_summary"],
        "rejected_adjacent_owner": prediction["rejected_adjacent_owner"],
        "specialist_finding_count": None,
        "specialist_counts_by_module": None,
        "evidence_validation_issues": [],
        "latency_seconds": None,
        "cache_hit": False,
        "trajectory_sha256": case.trajectory_sha256,
        "prediction_manifest_sha256": manifest_sha256,
        "agent_judge_version": protocol.version,
        "prompt_version": protocol.version,
        "pipeline_version": protocol.version,
        "model": protocol.model,
        "reasoning_effort": protocol.reasoning_effort,
        "temperature": None,
        "provider": "codex-subagent",
        "endpoint": "orchestrator",
    }


def score_agent_judge_predictions(
    *,
    dataset: BenchmarkDataset,
    cohort: CohortManifest,
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    protocol: str = DEFAULT_AGENT_JUDGE_PROTOCOL,
) -> tuple[list[dict[str, Any]], dict[str, Any], dict[str, Any]]:
    """Validate gold-free output first, then strictly join benchmark gold."""

    selected = resolve_agent_judge_protocol(protocol)
    audit = validate_agent_judge_run(
        prediction_manifest_path=prediction_manifest_path,
        cohort_manifest_path=cohort_manifest_path,
        predictions_path=predictions_path,
        protocol=selected.name,
    )
    manifest, cases = load_prediction_manifest(prediction_manifest_path)
    case_order = tuple(case.trajectory_id for case in cases)
    if (
        dataset.dataset_sha256 != manifest["dataset_manifest_sha256"]
        or cohort.dataset_manifest_sha256 != manifest["dataset_manifest_sha256"]
        or cohort.cohort_name != manifest["cohort_name"]
        or cohort.cohort_sha256 != manifest["cohort_sha256"]
        or cohort.trajectory_ids != case_order
    ):
        raise AgentJudgeWorkflowError(
            "scoring dataset/cohort lineage is invalid"
        )
    if cohort.path is not None and (
        cohort.path.expanduser().resolve()
        != Path(cohort_manifest_path).expanduser().resolve()
    ):
        raise AgentJudgeWorkflowError(
            "loaded cohort does not come from the validated cohort path"
        )

    prediction_path = Path(predictions_path).expanduser().resolve()
    if audit["output_sha256"]["predictions.json"] != _file_sha256(prediction_path):
        raise AgentJudgeWorkflowError("predictions changed after validation")
    raw_predictions = _read_json(prediction_path, role="Agent Judge predictions")
    if not isinstance(raw_predictions, list):
        raise AgentJudgeWorkflowError("Agent Judge predictions must be an array")

    examples = {
        example.label.trajectory_id: example for example in dataset.examples
    }
    scored: list[dict[str, Any]] = []
    for case, prediction in zip(cases, raw_predictions, strict=True):
        if not isinstance(prediction, Mapping):
            raise AgentJudgeWorkflowError("validated prediction is not an object")
        example = _lineage_example(
            trajectory_id=case.trajectory_id,
            examples=examples,
            case=case,
        )
        scored.append(
            _scored_record(
                example=example,
                case=case,
                prediction=prediction,
                manifest_sha256=manifest["prediction_manifest_sha256"],
                protocol=selected,
            )
        )
    metrics = compute_metrics(
        scored,
        phase1_gold_available=dataset.phase1_gold_available,
        phase1_gold_reason=dataset.phase1_gold_reason,
    )
    return scored, metrics, audit


__all__ = [
    "AGENT_JUDGE_METHOD",
    "AGENT_JUDGE_PIPELINE_VERSION",
    "AGENT_JUDGE_PROMPT_VERSION",
    "AGENT_JUDGE_RUN_SCHEMA_VERSION",
    "AGENT_JUDGE_PROTOCOL_NAMES",
    "DEFAULT_AGENT_JUDGE_PROTOCOL",
    "AGENT_TASK_FILENAME",
    "AgentJudgeWorkflowError",
    "AgentJudgeProtocol",
    "PREDICTIONS_FILENAME",
    "PREDICTION_AUDIT_FILENAME",
    "PREREGISTRATION_FILENAME",
    "prepare_agent_judge_run",
    "resolve_agent_judge_protocol",
    "score_agent_judge_predictions",
    "validate_agent_judge_run",
]

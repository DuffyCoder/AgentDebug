"""Write-once preregistration and promotion gates for E9-v14.

The v14 experiment has two deliberately different upstream topologies:

* tuning (``dry3`` and ``full30``) reads one immutable eleven-batch v13
  Scout/Arbiter predecessor and pays for candidate plus final Selector; and
* held-out ``smoke30`` starts with all caches empty and pays for Scout,
  Arbiter, candidate, and Selector.

This module freezes that distinction before a provider can be called.  It
never opens benchmark labels on the prediction path.  Labels are loaded only
by :func:`verify_batched_critic_promotion`, after the raw prediction chain has
already been persisted and independently validated.
"""

from __future__ import annotations

import ast
import gzip
import hashlib
import io
import inspect
import json
import os
import tarfile
from collections import Counter
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from agentdebug.diagnostics.batched_critic_judge import (
    BATCHED_CRITIC_PIPELINE_VERSION,
    BATCHED_CRITIC_PROMPT_PROTOCOL_VERSION,
    BATCHED_CRITIC_STAGE,
    BATCHED_SELECTOR_PROMPT_PROTOCOL_VERSION,
    BATCHED_SELECTOR_STAGE,
)
from agentdebug.diagnostics.judge_view import JUDGE_VIEW_VERSION

from .cohort import load_cohort_manifest
from .dataset import load_agent_error_bench
from .fresh_semantic_workflow import (
    E8_LOGICAL_COMPLETION_LEDGER_SCHEMA_VERSION,
    initialize_fresh_semantic_completion_ledger,
    load_fresh_semantic_completion_ledger,
)
from .metrics import SUCCESS_STATUSES, compute_metrics
from .prediction_manifest import load_prediction_manifest, stable_sha256
from .runner import TRANSPORT_POLICY_VERSION, BenchmarkRunConfig
from .stage_cache import (
    RAW_RESPONSE_SIDECAR_SCHEMA_VERSION,
    RAW_STAGE_SCHEMA_VERSION,
    STAGE_CACHE_SCHEMA_VERSION,
    StageCacheError,
    sum_stage_telemetry,
)


V14_PREREGISTRATION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-v54-contradiction-first-planning-preregistration.v1"
)
V14_PROMOTION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-v54-contradiction-first-planning-promotion.v1"
)
V14_AUTHORIZATION_CLAIM_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-v54-contradiction-first-planning-phase-claim.v1"
)
V14_CODE_BUNDLE_ARCHIVE_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-v54-contradiction-first-planning-code-bundle-archive.v1"
)
V14_IMPLEMENTATION_CUMULATIVE_CEILING: None = None
V14_CUMULATIVE_LOGICAL_COMPLETIONS_BEFORE = 642
V14_AUTHORIZATION_CHAIN_RELATIVE_PATH = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v54-contradiction-first-phase-chain"
)

V14_FROZEN_V13_TUNING = "frozen_v13_tuning"
V14_FRESH_FOUR_STAGE_SMOKE = "fresh_four_stage_smoke"
V14_UPSTREAM_MODES = frozenset(
    {V14_FROZEN_V13_TUNING, V14_FRESH_FOUR_STAGE_SMOKE}
)

V13_SCOUT_STAGE = "batched_causal_scout"
V13_ARBITER_STAGE = "batched_causal_arbiter"
V14_TUNING_STAGES = (BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE)
V14_SMOKE_STAGES = (
    V13_SCOUT_STAGE,
    V13_ARBITER_STAGE,
    BATCHED_CRITIC_STAGE,
    BATCHED_SELECTOR_STAGE,
)

V14_DRY3_IDS_MANIFEST_ORDER = (
    "Qwen3-8B_024_id_24___chat_b013_t00_e01-5b8f974f",
    "Llama3.3-70B-Turbo_015_memory_b001_t00_e06-71f77595",
    "GPT-4o_008_chat_b000_t00_e07-d50ae81f",
)
V14_EVALUATION_PROFILES: dict[str, dict[str, Any]] = {
    "dry3": {
        "cohort_name": "tuning-v1",
        "cohort_sha256": (
            "e21b1034470577688b68aad2a0e006facc658fed28bdb986f"
            "ed039bc0347bd6f"
        ),
        "cohort_count": 30,
        "selection_count": 3,
        "batch_count": 1,
        "heldout": False,
        "upstream_mode": V14_FROZEN_V13_TUNING,
        "selection_ids": V14_DRY3_IDS_MANIFEST_ORDER,
    },
    "full30": {
        "cohort_name": "tuning-v1",
        "cohort_sha256": (
            "e21b1034470577688b68aad2a0e006facc658fed28bdb986f"
            "ed039bc0347bd6f"
        ),
        "cohort_count": 30,
        "selection_count": 30,
        "batch_count": 11,
        "heldout": False,
        "upstream_mode": V14_FROZEN_V13_TUNING,
        "selection_ids": None,
    },
    "smoke30": {
        "cohort_name": "smoke-v1",
        "cohort_sha256": (
            "6dfbc06b27a64f80719787b0cd56736a26ae97a98ba7714d"
            "af6a571808d11fe0"
        ),
        "cohort_count": 30,
        "selection_count": 30,
        "batch_count": 11,
        "heldout": True,
        "upstream_mode": V14_FRESH_FOUR_STAGE_SMOKE,
        "selection_ids": None,
    },
}

_FORMAL_PROFILES = frozenset(V14_EVALUATION_PROFILES)
_V14_METHOD = "two_stage"
_V14_SEMANTIC_INPUT_IDENTITY = (
    "complete_anonymous_judge_views_plus_untrusted_frozen_v13_raw_"
    "arbiter_prior_and_scout_hypotheses_late_exposure"
)
_V14_SEMANTIC_CLASSIFIER = "raw_independent_batch_selector_output"

_SUPPORTED_GATE_FIELDS = {
    "all_correct_minimum",
    "all_correct_report_only",
    "failed_prediction_maximum",
    "gold_isolation_required",
    "heldout_one_shot_required",
    "llm_selector_raw_final_required",
    "raw_chain_reconstruction_required",
    "semantic_mutation_maximum",
    "step_exact_minimum_correct",
    "step_module_exact_minimum_correct",
    "successful_prediction_minimum",
    "trajectory_denominator",
}

_PROVIDER_TELEMETRY_COUNTER_FIELDS = (
    "logical_completion_count",
    "http_attempt_count",
    "retry_count",
    "request_input_chars",
    "provider_usage_response_count",
)
_PROVIDER_TOKEN_FIELDS = (
    "input_tokens",
    "output_tokens",
    "total_tokens",
)
_PROVIDER_TELEMETRY_FIELDS = frozenset(
    {
        *_PROVIDER_TELEMETRY_COUNTER_FIELDS,
        "provider_usage_token_totals",
        "finish_reason_counts",
    }
)

_FORBIDDEN_SEMANTIC_KEYS = {
    "all_correct",
    "confidence",
    "critical_failure_module",
    "critical_failure_step",
    "critical_failure_type",
    "deterministic_finding",
    "deterministic_findings",
    "gold_error_type",
    "gold_event_id",
    "gold_module",
    "gold_normalization_notes",
    "gold_raw_error_type",
    "gold_raw_module",
    "gold_reasoning",
    "gold_step",
    "likelihood",
    "likelihoods",
    "priority",
    "priorities",
    "probabilities",
    "probability",
    "rank",
    "rating",
    "ratings",
    "score",
    "scores",
    "severity",
    "step_annotations",
    "step_exact",
    "step_module_exact",
    "vote",
    "votes",
    "weight",
    "weights",
}

_CODE_PATHS = (
    "agentdebug/__init__.py",
    # Current-checkout import closure after public API consolidation. Previously
    # recorded bundles/hashes are not rewritten by extending this source list.
    "agentdebug/method.py",
    "agentdebug/benchmark/agent_judge_shards.py",
    "agentdebug/diagnostics/agent_judge_gaia_v3_83_clean_v3p20_model_only_gpt55_medium.py",
    "agentdebug/diagnostics/agent_judge_luna_gaia_v1.py",
    "agentdebug/diagnostics/agent_judge_luna_gaia_v2.py",
    "agentdebug/diagnostics/agent_judge_luna_gaia_v2_1.py",
    "agentdebug/diagnostics/agent_judge_luna_gaia_v3.py",
    "agentdebug/diagnostics/agent_judge_luna_gaia_v3_1.py",
    "agentdebug/diagnostics/agent_judge_luna_gaia_v3_13_conservative_challenger.py",
    "agentdebug/diagnostics/agent_judge_luna_gaia_v3_14_earliest_causal_challenger.py",
    "agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py",
    "agentdebug/diagnostics/agent_judge_luna_gaia_v3_4.py",
    "agentdebug/diagnostics/agent_judge_luna_v3.py",
    "agentdebug/diagnostics/agent_judge_v2_4.py",
    "agentdebug/diagnostics/agent_judge.py",
    "agentdebug/diagnostics/agent_judge_v2.py",
    "agentdebug/diagnostics/agent_judge_v2_1.py",
    "agentdebug/diagnostics/agent_judge_v2_2.py",
    "agentdebug/diagnostics/__init__.py",
    "agentdebug/diagnostics/analyzer.py",
    "agentdebug/diagnostics/batched_causal_judge.py",
    "agentdebug/diagnostics/batched_critic_judge.py",
    "agentdebug/diagnostics/evidence_repair.py",
    "agentdebug/diagnostics/fresh_semantic_evidence.py",
    "agentdebug/diagnostics/fresh_semantic_judge.py",
    "agentdebug/diagnostics/global_critic.py",
    "agentdebug/diagnostics/handoff.py",
    "agentdebug/diagnostics/judge_view.py",
    "agentdebug/diagnostics/models.py",
    "agentdebug/diagnostics/parsing.py",
    "agentdebug/diagnostics/prompts.py",
    "agentdebug/diagnostics/providers.py",
    "agentdebug/diagnostics/redaction.py",
    "agentdebug/diagnostics/taxonomy.py",
    "agentdebug/diagnostics/validator.py",
    "agentdebug/benchmark/__init__.py",
    "agentdebug/benchmark/adapter.py",
    "agentdebug/benchmark/batched_causal_workflow.py",
    "agentdebug/benchmark/batched_critic_cli.py",
    "agentdebug/benchmark/batched_critic_preregistration.py",
    "agentdebug/benchmark/batched_critic_workflow.py",
    "agentdebug/benchmark/cohort.py",
    "agentdebug/benchmark/dataset.py",
    "agentdebug/benchmark/fresh_semantic_workflow.py",
    "agentdebug/benchmark/metrics.py",
    "agentdebug/benchmark/models.py",
    "agentdebug/benchmark/prediction_manifest.py",
    "agentdebug/benchmark/prompts.py",
    "agentdebug/benchmark/reporting.py",
    "agentdebug/benchmark/runner.py",
    "agentdebug/benchmark/stage_cache.py",
    "agentdebug/trace/__init__.py",
    "agentdebug/trace/_common.py",
    "agentdebug/trace/artifacts.py",
    "agentdebug/trace/claw_eval.py",
    "agentdebug/trace/integrity.py",
    "agentdebug/trace/io.py",
    "agentdebug/trace/models.py",
    "agentdebug/trace/reconcile.py",
    "agentdebug/trace/runtime_v1.py",
    "agentdebug/trace/session_v3.py",
    "docs/experiments/e9-v18-conservative-prior.md",
    "docs/experiments/e9-v18-failure-case-study.md",
    "docs/experiments/e9-v19-task-closing-recovery.md",
    "docs/experiments/e9-v19-failure-case-study.md",
    "docs/experiments/e9-v20-minimal-final.md",
    "docs/experiments/e9-v20-failure-case-study.md",
    "docs/experiments/e9-v21-format-safe.md",
    "docs/experiments/e9-v21-failure-case-study.md",
    "docs/experiments/e9-v22-recovery-checkpoint.md",
    "docs/experiments/e9-v22-failure-case-study.md",
    "docs/experiments/e9-v23-novelty-calibrated-recovery.md",
    "docs/experiments/e9-v23-failure-case-study.md",
    "docs/experiments/e9-v24-final-content-contract.md",
    "docs/experiments/e9-v24-full30-failure-case-study.md",
    "docs/experiments/e9-v25-full30-failure-case-study.md",
    "docs/experiments/e9-v26-dry3-failure-case-study.md",
    "docs/experiments/e9-v27-full30-failure-case-study.md",
    "docs/experiments/e9-v28-dry3-failure-case-study.md",
    "docs/experiments/e9-v29-full30-failure-case-study.md",
    "docs/experiments/e9-v30-full30-failure-case-study.md",
    "docs/experiments/e9-v31-full30-failure-case-study.md",
    "docs/experiments/e9-v32-independent-selector.md",
    "docs/experiments/e9-v32-dry3-failure-case-study.md",
    "docs/experiments/e9-v33-boundary-maturity-calibration.md",
    "docs/experiments/e9-v33-dry3-failure-case-study.md",
    "docs/experiments/e9-v34-capability-query-epoch.md",
    "docs/experiments/e9-v34-full30-failure-case-study.md",
    "docs/experiments/e9-v35-symmetric-brace-repair.md",
    "docs/experiments/e9-v35-full30-failure-case-study.md",
    "docs/experiments/e9-v36-original-agentdebug-causal-contract.md",
    "docs/experiments/e9-v36-dry3-invocation-failure-case-study.md",
    "docs/experiments/e9-v36-dry3-failure-case-study.md",
    "docs/experiments/e9-v37-incumbent-preserving-causal-contract.md",
    "docs/experiments/e9-v37-dry3-failure-case-study.md",
    "docs/experiments/e9-v38-first-defect-terminal-guard-contract.md",
    "docs/experiments/e9-v38-full30-failure-case-study.md",
    "docs/experiments/e9-v39-multi-hypothesis-causal-ledger.md",
    "docs/experiments/e9-v39-dry3-failure-case-study.md",
    "docs/experiments/e9-v40-causal-ledger-length-contract.md",
    "docs/experiments/e9-v40-full30-failure-case-study.md",
    "docs/experiments/e9-v41-dry3-failure-case-study.md",
    "docs/experiments/e9-v42-dry3-failure-case-study.md",
    "docs/experiments/e9-v43-dry3-failure-case-study.md",
    "docs/experiments/e9-v44-dry3-failure-case-study.md",
    "docs/experiments/e9-v45-dry3-failure-case-study.md",
    "docs/experiments/e9-v45-selector-recovery-invocation-case-study.md",
    "docs/experiments/e9-v45-recovered-dry3-failure-case-study.md",
    "docs/experiments/e9-v46-full30-failure-case-study.md",
    "docs/experiments/e9-v47-dry3-invocation-failure-case-study.md",
    "docs/experiments/e9-v47-dry3-failure-case-study.md",
    "docs/experiments/e9-v48-dry3-failure-case-study.md",
    "scripts/recover_e9_v45_selector.py",
    "tests/test_batched_critic_cli.py",
    "tests/test_batched_critic_judge.py",
    "tests/test_batched_critic_preregistration.py",
    "tests/test_batched_critic_workflow.py",
    "tests/test_v45_selector_recovery.py",
)

_V13_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-gpt-4.1-tuning-v1-e9-v13-"
    "atomic-taxonomy-pair-full30"
)
_V13_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "5f02626517fc5809a6e4428396a7f367c7aca280db6a7919e90e2234730a2603"
    ),
    "predict-run.json": (
        "3460ecad5c0fa8221e0907539be13ac01cde04458b1cb74a01366c6a83c6449f"
    ),
    "promotion.json": (
        "3a8999cb0313a84f8c14cdbf1a346fd114fdc2d4a45cc16cb7c9346eb83705d3"
    ),
    "metrics.json": (
        "f67d58feedec7a7d5613c84ec295b604d1686ce913c77ea717125eaf8918089a"
    ),
    "predictions.jsonl": (
        "c4dc8998010bc56bfe6585f0f538016c5433fa297db7696cfcd3422d7c55d0e4"
    ),
    "unscored-predictions.jsonl": (
        "1400cb7b98c463a4b899a20079d8af48646a584caf0a3cf01ed0fa4ba447446a"
    ),
    "code-bundle-v13.tar.gz": (
        "cf98e175318c614b12079c5d9884286dae62a4beb300f2ced4b17f2132cdb318"
    ),
}
_V13_REJECTED_PREREGISTRATION_SHA256 = (
    "547647ecaf30b362d2f532d923028bf48d47be23ed1d6d6edb421ce4ad5f22da"
)
_V13_REJECTED_PROMOTION_SHA256 = (
    "b4c177944072c9d728234b2af3cf0914082408349006e7dadd10ef9958aafe02"
)
_V13_SOURCE_CACHE_FILE_COUNT = 66
_V13_SOURCE_CACHE_FILES_SHA256 = (
    "a918abc4ab2ec76e95289ff5fb3855be31956c8adec310117f661ef280a6b494"
)

_V14_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-gpt-4.1-tuning-v1-e9-v14-"
    "prior-late-balanced-critic-dry3"
)
_V14_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "78e42e673e89c0ced464cc93c7fdbdd37a3b874b86e0df6067c1cd3febd382fb"
    ),
    "predict-run.json": (
        "a06320260aba3475d131744fa7985117cfbf107a8c2f6793f6daead0a9c2c002"
    ),
    "promotion.json": (
        "f7f543995800b73fc13f9b6cc82214860537d136a70ae7d557475aef13a91cd2"
    ),
    "metrics.json": (
        "a0881ef4ad933df3530524d7905e019f32d38995ce6896c883bc89c31853107a"
    ),
    "predictions.jsonl": (
        "677726a82a6f76bb4543605b203b797a37222421e77e67bd3fc27bce088292d7"
    ),
    "unscored-predictions.jsonl": (
        "ea2220193028ae4fd13626d714e5d074be65f756a1ce46b04295dfe7aa443fac"
    ),
    "logical-completion-ledger.json": (
        "e9d6756f0af1e8380503c791930a063adba074664888a8fa8d8dd813598a42d7"
    ),
    "artifact-manifest.json": (
        "20e5bf359cb23b3e10ed297357c61e67ef84047d19dfc2f52cc429e49de17b95"
    ),
}
_V14_REJECTED_PREREGISTRATION_SHA256 = (
    "69c5f8fb80e0df261d056f35ee3f3fe46776934b97c87a0664fc1709a899caa6"
)
_V14_REJECTED_PREDICT_RUN_SHA256 = (
    "de41a73c83e02a40b7b7aaddc0a2fd1723c8ca3b4e5a4cfee23d755fa971e8ec"
)
_V14_REJECTED_PROMOTION_SHA256 = (
    "7f98de2493af9c2a0c569f7deb403fea078be281932c95f24d7a9290aa7c883f"
)

_V15_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v15-"
    "prior-late-balanced-critic-dry3"
)
_V15_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "26b94930bba328716fda913c70fed8463a186235bdd476d0f589c3da6b24d422"
    ),
    "predict-run.json": (
        "4cd95a371d1fa999b6f668cf23dd0eea97df2872391573fca2ca0fc4a2f789bc"
    ),
    "promotion.json": (
        "33b1df516c00121f591380ba21c1fc3ce98058f29448228702a38d2cd20c8ee5"
    ),
    "metrics.json": (
        "38adc46a79151c12778ab471d657453f77727610a81dab857987ea3496a508ba"
    ),
    "predictions.jsonl": (
        "0afef06d2a337c165519e5386bd0ec00ae231ba2d600cbf84e9074b072280ee5"
    ),
    "unscored-predictions.jsonl": (
        "20aabc3ef7daa43e784a77666a35332287592ca48382c585e15ce194eaec6652"
    ),
    "logical-completion-ledger.json": (
        "202a39dd3cf938aadb404d5f4b6a5583edcb9d17ff8e0e6d7e037c1e6291ff3c"
    ),
    "artifact-manifest.json": (
        "921d0e5fe1c701f75a10bf629e4f87113e2c0ed7b91f49c6ad944a0063db18e5"
    ),
}
_V15_REJECTED_PREREGISTRATION_SHA256 = (
    "03a320d0ec9908d1591548623b909a69297c6aac6092e3a7ac2babb760c967c3"
)
_V15_REJECTED_PREDICT_RUN_SHA256 = (
    "2cc1907c02da402c7809f9b6dab717d167824a6054de361ddf652ca4b897357a"
)
_V15_REJECTED_PROMOTION_SHA256 = (
    "2ac6505ecee05065e2ea28494ca52c9cbcb4120853e6a2f47ba1e87b05f03c9f"
)

_V16_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v16-retry1-"
    "prior-late-balanced-critic-dry3"
)
_V16_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "60cc8fda408dc017607da5f3700c50d9a4b6fdb99c23ff58f6e2fe3a7262a1b5"
    ),
    "predict-run.json": (
        "47ac234e316ebd89ec5ce6d39365737fa8f14e786b3683916099a2ccf6d51811"
    ),
    "promotion.json": (
        "0a459a83536620a61b8ddbc5169c5e77f7d8a31abf52c19fe34234524fcb2d7e"
    ),
    "metrics.json": (
        "dab13f9ec815658ae0720ef59d44eca862508e9c2951ca8c93bd477c0386fc9e"
    ),
    "predictions.jsonl": (
        "504732bd2c69b642adee47ffea667514b739822792326cb981c4e844fddb8f1a"
    ),
    "unscored-predictions.jsonl": (
        "a5882e889ec4884a276e36a16a1f6d81018861ebb1ecdbfbe349ff33a95e5d5a"
    ),
    "logical-completion-ledger.json": (
        "adcd1fb53ab964dd9e74cee9d9d7746fdb5f7614fd1def2bcdc14341dc48f035"
    ),
    "artifact-manifest.json": (
        "16ec8b638e95817bab993eb46158b8abf8be2b61db2bb667529a3e7a29154834"
    ),
}
_V16_REJECTED_PREREGISTRATION_SHA256 = (
    "40b604492e59809d647d180c2d92674da9b0163c02cbd46a9354eab452711c02"
)
_V16_REJECTED_PREDICT_RUN_SHA256 = (
    "e3d47053cbc05a69dd35171a335d156d778e16cd64923b1c7ec550fedaf47c77"
)
_V16_REJECTED_PROMOTION_SHA256 = (
    "b9005893182b6db433b5560e32d4ffab0cb33c5fe959530782c2fdc9ac6a0126"
)

_V17_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v17-default-"
    "prior-late-balanced-critic-dry3"
)
_V17_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "a70fa5e671c9dac518a6c859f320451d69817e798c3d4783e4c4441b06e420f8"
    ),
    "predict-run.json": (
        "80eb54439068b734130a02e0fa6ce4d4d00483f03d94cea9fe103eb04c8a4549"
    ),
    "promotion.json": (
        "36047ee6473afe61e78c6fa9d1105397b12355de129771fc9a5bbdece8181206"
    ),
    "metrics.json": (
        "0d83d4f4d3f029fdcfc2b7b7077e89f4bd928889e3804efd3de3862430338d1c"
    ),
    "predictions.jsonl": (
        "8ba759b32ccaa246c8f1058422b82eb6376d53e7f173eaba1a759f79fef556cc"
    ),
    "unscored-predictions.jsonl": (
        "1a0af37dd7eb244348c0efe7658379e34380e05c7824bf51e8c4c6fe4e292f3c"
    ),
    "logical-completion-ledger.json": (
        "b90bad350ea203c2bcfa8396eaecddd879b0dee5b6df0b21420c6d3d122cbd23"
    ),
    "artifact-manifest.json": (
        "6ab15cb15f8ac1b7061444bee2cd4f0783b3201b512d640ce11f24f0067118e9"
    ),
}
_V17_REJECTED_PREREGISTRATION_SHA256 = (
    "0e3b2c7ab7bf119cc72eaa680798364637e5e1b7d282eab526fecc74e0f5de4d"
)
_V17_REJECTED_PREDICT_RUN_SHA256 = (
    "1b8cff3d8c14de057da7e4d25355cb9fbbcb8e4bd089db3890a86e65830df3a6"
)
_V17_REJECTED_PROMOTION_SHA256 = (
    "93e0998bd4c8382b3d6aea018e556855370ab21d9d5a868e859587af04d25934"
)

_V18_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v18-"
    "conservative-prior-critic-dry3"
)
_V18_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "f322af98135fa200df4ece276d5ffdb86807f264af30db60ab88eea85ead831f"
    ),
    "predict-run.json": (
        "9081ac03857d1358135609fb82b4cbac8a7ef40be2894248712170a4ca3803eb"
    ),
    "promotion.json": (
        "44fe0a59c51d094f51c58c9c5ab652b5fcf1dded639d1f56591701b2505a5d70"
    ),
    "metrics.json": (
        "473dff460f81b62ed53824ed4f54e02a5af99e84b0307d99049cef0f7aa48d87"
    ),
    "predictions.jsonl": (
        "3bf50b26307d4b1bbfe0605e3091510e8182287a328405569936673b38a0d45d"
    ),
    "unscored-predictions.jsonl": (
        "c8154665489b14c39a14cbc073ee64c3b5d19b6494c427cd64a25850253c1892"
    ),
    "logical-completion-ledger.json": (
        "cc393d7040974279cc1f59369a217de589a8295840c79e712e351db9e560a0fa"
    ),
    "artifact-manifest.json": (
        "d1d24d95ebc9a5a20626622781ff8c177458fbb8e9b45e4b49b0e9ec7a1fc77d"
    ),
}
_V18_REJECTED_PREREGISTRATION_SHA256 = (
    "477a77119d8d514a48dda39a0f16f56dd44c2a8309bc68a1fa7af6441e169d49"
)
_V18_REJECTED_PREDICT_RUN_SHA256 = (
    "80efc1d950df0f426af6d1de4f7d25e09a292fdda1c76d268e11e6094923bdc2"
)
_V18_REJECTED_PROMOTION_SHA256 = (
    "5e70d6477d692f7d745f41a06e9067ac68250abb57c69f922add736991e5bf22"
)

_V19_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-pro-tuning-v1-e9-v19-"
    "task-closing-prior-critic-dry3"
)
_V19_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "dc340e6bd1b5a26b96f9ae7188f012e782098c09f58f4a6aaa4c73fcefd97e6e"
    ),
    "predict-run.json": (
        "df07537f0b9c3280de667c76a6371acc9405068707eefaaa54b28666304fdac5"
    ),
    "promotion.json": (
        "e7dfec688d8111731d96631c0dfd82044bfa85b5173c1f97c4a61c9ef5581f2f"
    ),
    "metrics.json": (
        "9fe139f37ab86380a1a948b9dec42c022defd2445549a7a39a28eb9cc7706040"
    ),
    "predictions.jsonl": (
        "4bf8173276da03e37d406be1df3afd9c7c31c4dfe7fa3bed6a4cef6ff7a3e25e"
    ),
    "unscored-predictions.jsonl": (
        "e8581feb7101540e72f4a0326cd4ace4adf4b83c5f3a904b40aa1c2e465e33cf"
    ),
    "logical-completion-ledger.json": (
        "7c1ac3dc8b92532c1ac7159db9dd0a36df2d8b489576bcfb1e454b126bf6fdc6"
    ),
    "artifact-manifest.json": (
        "3bab48797c8de86a679b398a50a66076c4a347d6e1e097451327b932774c3bb5"
    ),
}
_V19_REJECTED_PREREGISTRATION_SHA256 = (
    "ad637b567ab454625d51d1b02a6aa461a806c08864a2e0db864352406ed604c8"
)
_V19_REJECTED_PREDICT_RUN_SHA256 = (
    "c87972956d4e9127ebee759562ab544de3b2fcd6e4209fd5b0f0bec0b7f73d7c"
)
_V19_REJECTED_PROMOTION_SHA256 = (
    "d3af88ea79bb6ede039b3e91b05770d5e6f798ce07b1ca8ee78d8d4b4916ede2"
)

_V20_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-pro-tuning-v1-e9-v20-"
    "minimal-final-prior-critic-dry3"
)
_V20_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "6852f57ba34a05f7d7fb880c36df02f73ac2df8a878be6ecbef327900e2aeac1"
    ),
    "predict-run.json": (
        "3a12b6c0efaf014c36d4bfb9f2a2b7b4e84700839cb0872be5f9aef9fc33ea14"
    ),
    "promotion.json": (
        "7c1b7225163fc53e6b96c279379e3dade08c87cd5306a0d7eb064437e4a3f229"
    ),
    "metrics.json": (
        "70307e45bcafcb9ca4613843f1c399a19257e8ac0e45e4f5b7c48325ba5c4ac8"
    ),
    "predictions.jsonl": (
        "6d8763df91c3d25355ca6502378efaaaaca23800d529b22b6883a9517fbec776"
    ),
    "unscored-predictions.jsonl": (
        "753e837485b832668e82292775a2b78507aa85ac19ad1ae104e1a5f36e525138"
    ),
    "logical-completion-ledger.json": (
        "b22f9fd3e66de93850414a5e771161022e8c1736631340be1fadd4c9c5739f61"
    ),
    "artifact-manifest.json": (
        "a69a58b8231072f266ad55bc9216c9a8de15e62908432aa688577d899c51e3c5"
    ),
}
_V20_REJECTED_PREREGISTRATION_SHA256 = (
    "434f2fda25807541b086d8c883bfe5de63fdfe1f7a295821eb935f944794bdc1"
)
_V20_REJECTED_PREDICT_RUN_SHA256 = (
    "de8e73ddad7818b57bbb7dcb41bdf27e9c1b0ddf2d2c836c3249f106112d7e6f"
)
_V20_REJECTED_PROMOTION_SHA256 = (
    "cf511af5b61034944cc5ee3b850ad59514a47d32d73a81773dffa9dc7f38ec46"
)

_V21_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v21-"
    "format-safe-critic-dry3"
)
_V21_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "6ea44ec968e756731e828fe066d7b926942e7e4a40a97044e3d6f6d931ee1a32"
    ),
    "predict-run.json": (
        "87848f93fc2fe8c04d14fca0766e96b0feb32d0574439c3d4c97cbb329bc5ee6"
    ),
    "promotion.json": (
        "5d16a30d94deed958cbf9fd7a63a279065eee8d74f8bc1030def58bcd7a9c64e"
    ),
    "metrics.json": (
        "bd1d3888ffd4e4c8a187de9d597ad0614568cd5f1b17330e4f599caa63770e92"
    ),
    "predictions.jsonl": (
        "cd9e1caadfb135436517813a78f6fe45dffb56b1048e88a8bae97cde1f80c753"
    ),
    "unscored-predictions.jsonl": (
        "1b3be8cdaf8a23a93116e12e2ad152641a35dcaf2df9b441eb5598b7c9989fc9"
    ),
    "logical-completion-ledger.json": (
        "e3224f0206381c2ff070b342b44805699bf2db7a924f69f5de4d4cb21095a972"
    ),
    "artifact-manifest.json": (
        "24a6a1bbf27f74fc725d2bbbeb87098eb63bcb23814a775f676da595f3b31e9d"
    ),
}
_V21_REJECTED_PREREGISTRATION_SHA256 = (
    "81e29e61bd4efed2e3eefc09a6f201deca1fb516580e55f19d55ab5712cc5d75"
)
_V21_REJECTED_PREDICT_RUN_SHA256 = (
    "5a41b4c359f2c817f8cf0c32b3df0281175bae1434e5e440e0983ee90d583801"
)
_V21_REJECTED_PROMOTION_SHA256 = (
    "af10b091a5909f2ef07f2cb445140279b619a53d56da87df37f0bb1efb6f242c"
)

_V22_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v22-"
    "recovery-checkpoint-critic-dry3"
)
_V22_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "7d368d8afc8ee1908e171aacff3e6b3289a5296e585ef1d4300e8aa92aac4d06"
    ),
    "predict-run.json": (
        "f71583d0d79edd46252bc53999b272ae43601fd0714a5bcecb35b729ad96d4a6"
    ),
    "promotion.json": (
        "c3ebc2138866673cbc1a724fa20d5410337cc911eaccbee896777589db50d265"
    ),
    "metrics.json": (
        "7a39babec082a62a83607e06c4641d750d8055a9cb0967a04ad46c69d689e1ad"
    ),
    "predictions.jsonl": (
        "39a6c4fd007785da968451f657e538e9c34640e0a066f4dd698d4e4b46839155"
    ),
    "unscored-predictions.jsonl": (
        "bc4c33d44f961863d046949d005445c11d47f798faab12b3bf15b970431028a2"
    ),
    "logical-completion-ledger.json": (
        "e8b7ce9264ef572f33a9b76dd1d178b096a1beba9586b2ef53f5831678fbc4f4"
    ),
    "artifact-manifest.json": (
        "0767c867ed68321ef7ad10133087b2978272097cdd652c9e512b6662b92c2ab5"
    ),
}
_V22_REJECTED_PREREGISTRATION_SHA256 = (
    "53b78aa304570f4408d6a0200060b7c161fd239b90dbccd16c8030d67686d464"
)
_V22_REJECTED_PREDICT_RUN_SHA256 = (
    "48d40f77999b86ccffab1149f335d378aab3d9f4f1b7badef4d24f317cd1c84d"
)
_V22_REJECTED_PROMOTION_SHA256 = (
    "d87a955011f113eccc584ba537c6b09cde3d523dc0e790ab8808783918fd3452"
)

_V23_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v23-"
    "novelty-recovery-critic-dry3"
)
_V23_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "1c8a1b0b8659deff8ba0e0fc5bda23c5eaa1d0a395c31e7e35a8d21ff470205a"
    ),
    "predict-run.json": (
        "943f29c86e0c38398f3578588eab2a75e10f9b840d8a8460edb7207c32110243"
    ),
    "promotion.json": (
        "ab9e017f3def3a44d3704d21c07b07017a679365fe2d709efcf892b8e285df84"
    ),
    "metrics.json": (
        "f4e1a63a4c17427c3cd192ddf87a367b7925afd8188999665a72205add8405cb"
    ),
    "predictions.jsonl": (
        "ce6c399398222355a18e044e4da659e9115beb7b8b806a04863fe3f112cf0fdb"
    ),
    "unscored-predictions.jsonl": (
        "eb1bcb5040ad3e4d3e877e55b6bf60bb71bd59f74daa6ada00257f28f3d73faa"
    ),
    "logical-completion-ledger.json": (
        "a94cd2b3e967abb68b8dc324102f70e6f714d86379d7cf380f75d1a42250aff5"
    ),
    "artifact-manifest.json": (
        "e7fdaa3585248a0da156fd9fddf4d18185e173a6aadee23af30e96e724881ec1"
    ),
}
_V23_REJECTED_PREREGISTRATION_SHA256 = (
    "c5c9f78835c4bd3a62659a92c7deb1df42d1a98750cfeac8334c5aaa6ab6b286"
)
_V23_REJECTED_PREDICT_RUN_SHA256 = (
    "7ee33955752ee73d4352092440ce1cb02977177ff5f2da790ee3cb6be13ceb2f"
)
_V23_REJECTED_PROMOTION_SHA256 = (
    "94124c2ed271c38ab1ea5cc614bf0075bd30a9abfd5e14001810ae84c588061f"
)

_V24_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v24-"
    "final-content-critic-full30"
)
_V24_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "4b29e645ea1fd3a0e978caa6de162d28e8300282dc2809b273daaae3ebc8d165"
    ),
    "predict-run.json": (
        "ba9b79f204384a8bd5424483b68030876cb623bcec8f512ccd03a9dd87b9c8ca"
    ),
    "promotion.json": (
        "0f19ef6de4f564c763a4c4efb3a98de2aba7f14e9d90de25d0d109ce2e44181a"
    ),
    "metrics.json": (
        "947ccb938c0381de02bec833272c2a05d1786951b77244a343b15d5b5b1b5a70"
    ),
    "predictions.jsonl": (
        "30c26d86f83b5b1e84d1bb17763e8c979e3ed871e411b32e5d8d42e6cd1c5392"
    ),
    "unscored-predictions.jsonl": (
        "ea714cad318db9f6645e1e56e7c5f12db6417f3551d5901b310a252664df49b3"
    ),
    "logical-completion-ledger.json": (
        "ec57740802e21affadf7b99d2e12c56d36a63a295f1c6709b1133e403d8a19d5"
    ),
    "artifact-manifest.json": (
        "55448fd7bc594b61b73bc84f28ad9f3c4eb61ff778c267ce85373da878488559"
    ),
}
_V24_REJECTED_PREREGISTRATION_SHA256 = (
    "9f4eb292abcae627e8c847419836f58f21a52cea3ee1632317d20054d7f9e809"
)
_V24_REJECTED_PREDICT_RUN_SHA256 = (
    "5f7f52ad12f4c47ed6d24a5e0f250eb7d995df397d322dcdae07d651a6a4f627"
)
_V24_REJECTED_PROMOTION_SHA256 = (
    "9d9bbf102560d8b15e1e99097d6ec80c51df226c4b36da7f0d63d66ef0db7246"
)

_V25_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v25-"
    "local-error-critic-full30"
)
_V25_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "5d7dbf72e270fc4cec2cca2f919384459b0bde4197a0db15539d641f52baf925"
    ),
    "predict-run.json": (
        "ad78cb7a1c6ac3b072c86fe9af7acdcd4cf0f5b9ae5106972a524e6048ec1667"
    ),
    "promotion.json": (
        "d3b0d7722c0b0d832fecc1124ba9c5dd6a17cf39ee2f7e694d388ac258e6a072"
    ),
    "metrics.json": (
        "773eea2886d666414fa52276e44a46f2baf2d4cb6095fc7f50bcb9efeaa5d602"
    ),
    "predictions.jsonl": (
        "5a558d79947a9b0e524d3cde01fec66f9394bde6f0a17ff19b51d08e70758a73"
    ),
    "unscored-predictions.jsonl": (
        "f8f1ebb20c3e682b5d86e42c9d6c952cfb06d84c042b6fdea81694e067a0eb3a"
    ),
    "logical-completion-ledger.json": (
        "3a851ae763432f2699ec67a73ab9c9fc8e13bfa7585b4a2c44ebef2d82a0d2b3"
    ),
    "artifact-manifest.json": (
        "3ace9cb26c812896dc0d3ee184561e6f6697e97dee6708bfbbf040d9feeb5235"
    ),
}
_V25_REJECTED_PREREGISTRATION_SHA256 = (
    "e4d186b31e90ad055a39d7ae95964f55dd297a250eb430428a1f365ea869f833"
)
_V25_REJECTED_PREDICT_RUN_SHA256 = (
    "0af065dc57edf03efc9217126a7ddad22448be6164d3caa129fc52e24048f22c"
)
_V25_REJECTED_PROMOTION_SHA256 = (
    "36a7f9fd63835b016b411d5ce98553458fb8cebbb842a3cad5fa1980f31330f7"
)

_V26_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v26-"
    "upstream-owner-critic-dry3"
)
_V26_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "2e393cbd8c4587e48e2112e795ad39fbd4ec0b6be1f242798d123ef4448832ac"
    ),
    "predict-run.json": (
        "a1c526ab502c53307fd37cb3e63d2912e8e8941a9ac9497f5b57c410e391966c"
    ),
    "promotion.json": (
        "c2c98ad8e94620aea6fc431717caf80eff477e76d2b5b9df9cad822210bc1087"
    ),
    "metrics.json": (
        "3d95c058ff21b51f8a51029b80cf28f584038fd12571ec3ef17412414b1e8fb3"
    ),
    "predictions.jsonl": (
        "328f6afae39a59cec5ce3b1ac1bc9870b9cfd2428d7ea92eefe6a42f26f0f8aa"
    ),
    "unscored-predictions.jsonl": (
        "0f84ee780e70a3fcef792ff41b3fb5efc2132c5a0d1b65a88b56cd8735ee52a4"
    ),
    "logical-completion-ledger.json": (
        "1391d662e4e435740d2762b0f2d54df43edef2c567f6ca31c7b4723591a0c795"
    ),
    "artifact-manifest.json": (
        "f5dfca7f2aaf1eb255d828085a43cd602e57c1d0b934bac6c903d87e1c8a0608"
    ),
}
_V26_REJECTED_PREREGISTRATION_SHA256 = (
    "a171d71923c3546a4b08ed62bd2092b4c6f9a76bfaeb727242236ae2f6da74ed"
)
_V26_REJECTED_PREDICT_RUN_SHA256 = (
    "c71c1a7c939a20a3fa396d5a466f5257cf2407b7099ee029025a0ac636ee8ba4"
)
_V26_REJECTED_PROMOTION_SHA256 = (
    "2ca1fad1d46d12a37c70989c9c49e941cfa3b4668eb72974d7e86b43475494e0"
)

_V27_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v27-"
    "critical-event-critic-full30"
)
_V27_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "a17595ed56d7f15dbda742c7102c648bfe2b447459a78ff414a62c4f42d0cbf3"
    ),
    "predict-run.json": (
        "4cb9d0949f817ddee374fe725bb0c629520be919067e9049e0c1826c51f4dacb"
    ),
    "promotion.json": (
        "eadec1387c9436c2b8794ff485b40f03af0e68d786e77d59086475179a9d20d1"
    ),
    "metrics.json": (
        "0a29c903f3b7ed2b06965ff59b4b9ff756e860a652cb6874129c045bec436956"
    ),
    "predictions.jsonl": (
        "b6dcc9a92c9f9d401a660fe9320ba60750e1dfd1272553789480ef32753683c1"
    ),
    "unscored-predictions.jsonl": (
        "159706995814aa50b6378d0f702d6c5297977ee1494c170ea104333e1d4d7e69"
    ),
    "logical-completion-ledger.json": (
        "dae1df678d7b2458fddeb5b8aa015265588de1c0d881b8b6e599210c57c02683"
    ),
    "artifact-manifest.json": (
        "be306c7d4ffcf69324dd81b7ab8805ddfb6c8cce5ee624aea225d308d04f53b4"
    ),
}
_V27_REJECTED_PREREGISTRATION_SHA256 = (
    "650a3079f237b42fe11fae701f77c5b5213f2be19c24e154da987bd6eb1fe76e"
)
_V27_REJECTED_PREDICT_RUN_SHA256 = (
    "4a36b05b51d0b9e704106a3fe48527cc4f65c602bac608ee2d26bcbd9518d0f8"
)
_V27_REJECTED_PROMOTION_SHA256 = (
    "07492b9c297ae46dcb2e14f1f3871b6d5cef6f1e9cab94742cd6769e4373eb4a"
)

_V28_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v28-"
    "flat-review-critic-dry3"
)
_V28_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "37d066ac0998bd03165cb50ee0797aa179617298e750cfc1331b5ba365615f4a"
    ),
    "predict-run.json": (
        "dfcf99a4e1714529825550dc9c41f5103fdec43c1b52bee9cced88e758efcd8d"
    ),
    "promotion.json": (
        "7f03bb05c3969fd2623bd0d268c55f7b37e2ce4797331a2c00532f3e6845f1dd"
    ),
    "metrics.json": (
        "c397fbc6053e70c4f6092e72149d59c4105788f94a87e0fbcddcca88a869e921"
    ),
    "predictions.jsonl": (
        "a4ac30323c952d72551c436d86513655a2519f8ab74b79b8313efb314ba625a4"
    ),
    "unscored-predictions.jsonl": (
        "7efe144d0ef6e84d7107bf0eb7ea2179f693e04ea9e542d1d5df25998c0ad84b"
    ),
    "logical-completion-ledger.json": (
        "f74a17799a0192f31051ddec96bd4343ebcb59ae44f61ae5258741bd49378841"
    ),
    "artifact-manifest.json": (
        "f6aa3b392f1fe6356a913da653ae18d947b1ae3f152cc1ea3978499a77ced5c4"
    ),
}
_V28_REJECTED_PREREGISTRATION_SHA256 = (
    "2ddc7b14c3ee56615c46ca3e8becc1c5fd83552f7e97efeecf0a37d5c2409213"
)
_V28_REJECTED_PREDICT_RUN_SHA256 = (
    "0c083a54fb7e6195af0851d077aafb8778389207c7671f584421ea540e005439"
)
_V28_REJECTED_PROMOTION_SHA256 = (
    "5ddf5a33cdeccb6cf51050a05c8bba24eef16a65cab0fe109fd05ce312aaa473"
)

_V29_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v29-"
    "terminal-guard-critic-full30"
)
_V29_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "514854369700adb8a9d8dea1673d6fc1250967f9f562ed52770e738275d0c156"
    ),
    "predict-run.json": (
        "bab3b9f375999ba16561bcd9846fd9b4d3e253b431a255a5b7858a0e872ea420"
    ),
    "promotion.json": (
        "e5d5d1fb2e38ccb04b731110fcf96a70c74d7ce11a8b06a4e8fdea12a9d72f0e"
    ),
    "metrics.json": (
        "39d1e33e69507c26ef1e26a067828d497ff21819721504f2f001b046dce6a376"
    ),
    "predictions.jsonl": (
        "dd0f563f88ea6ddb3dbd3383c8272d6f6c1e9fe960aed37946223ee13750be24"
    ),
    "unscored-predictions.jsonl": (
        "687adc06d8d814a456674041e0b58e479c2e0fac28c5dcc2161753fd22a694aa"
    ),
    "logical-completion-ledger.json": (
        "338744f028275672762e34c1c2e5466d410ab533875c94e86e27f10865786d13"
    ),
    "artifact-manifest.json": (
        "4fe4b8d63acf18751d91b2138c0327b1a0e95536a075baa7539db3e416e25d96"
    ),
}
_V29_REJECTED_PREREGISTRATION_SHA256 = (
    "5a00be7d6f1ee1702bc5842a5c727431fa16a8a5a2c6329dc900265a5063a353"
)
_V29_REJECTED_PREDICT_RUN_SHA256 = (
    "81bd8f7a92f6cbce7a50c3a07a959060736110c47d4877ee5a6215096b8cc2a7"
)
_V29_REJECTED_PROMOTION_SHA256 = (
    "e1fa45e7d3c810b0ce7efe78abb58fb242c12f54cf8f00038f95db3a90722d2e"
)

_V30_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v30-"
    "first-defect-critic-full30"
)
_V30_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "5a079f97b140026faac5bde2c9dcd30636280552b0590b47832fca471dfab5af"
    ),
    "predict-run.json": (
        "770f6f5fdba7baa9cabd568690d944c1eba6097a293048f7648850306968ffa1"
    ),
    "promotion.json": (
        "1ea736c4507063a14a455235f6422f7a20f1cda44344a7dd6800f26c3e1d945c"
    ),
    "metrics.json": (
        "0c837a50d7165d765df8ad4d1811e6cb21f66d5523c391bddb91ed609f57fe1d"
    ),
    "predictions.jsonl": (
        "6d8c35a7cce716ba097f64948e2229d1321ee0e61aec5afcceb1b3e0850b7efe"
    ),
    "unscored-predictions.jsonl": (
        "5cb5e2a9f36bf957b1d9a66f13b09f0a7df7b87c3a3a18bae76065887fc09208"
    ),
    "logical-completion-ledger.json": (
        "aabd329b9f0166b348ae0a749efb5d55972003ae36cc16fbbc00d5094f3e2ecd"
    ),
    "artifact-manifest.json": (
        "ff560296989ed251fd5a15444a35750cdf4d3931a5978b41a0b5273024307669"
    ),
}
_V30_REJECTED_PREREGISTRATION_SHA256 = (
    "495ea85bf8cdced1f47864ed645dff9dbc61032a8c84c9364a89d8dccceb3469"
)
_V30_REJECTED_PREDICT_RUN_SHA256 = (
    "f59f926a32addae8c741eb595ec57034d9f24e4be02ae5314dbb2ed1a53b7a14"
)
_V30_REJECTED_PROMOTION_SHA256 = (
    "f3cc8f66789a78c6989226bd36a516fc9dd501871f0979cf9959895db5d98ec8"
)
_V31_INCOMPLETE_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v31-"
    "pairwise-candidate-critic-full30"
)
_V31_INCOMPLETE_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v31-pairwise-"
    "candidate-tuning-critic-cache"
)
_V31_INCOMPLETE_FILE_SHA256 = {
    "preregistration.json": (
        "e88c836f32d33c19105ff1d25634be3c3cc36d83ff84df321054ebb2747c0b2a"
    ),
    "unscored-predictions.jsonl": (
        "ee868f73ea99894c7b843ba3db6eb6ce866610ea6a7d1e1f3532732469022f14"
    ),
    "logical-completion-ledger.json": (
        "b0ca9fd03560f8e283542fcc34374d309a71db58e0375def74e097b3efbd85c6"
    ),
}
_V31_INCOMPLETE_PREREGISTRATION_SHA256 = (
    "f6a5f1cf11f52851e836709971362be4e16397f506bfdeb9242d97ee5225e21d"
)
_V31_INCOMPLETE_LEDGER_SHA256 = (
    "a0d3882fd915bd2a37fa1a7874d287cf2a917d36499668e49186aeea1fe4a60c"
)
_V31_INCOMPLETE_CACHE_STATE = {
    "file_count": 30,
    "files_sha256": (
        "59718a4cc4be0c628968d4ecfa5f0ca22f112fb2ed906d6e88118dd909e096f3"
    ),
}

_V32_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v32-"
    "candidate-selector-dry3"
)
_V32_REJECTED_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v32-candidate-"
    "selector-tuning-cache"
)
_V32_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "a484918e44015c06828895778f9a0de3388bad98cf5f16a8e0651f533fa05f92"
    ),
    "predict-run.json": (
        "1004f522c66d7ba75363d067139bf792e25ebf9023453d9a846c56a6e52e157e"
    ),
    "promotion.json": (
        "1c4bd162320604acacbaa3082286af4ba902204763fbe4c0f0bfa5dda7945816"
    ),
    "metrics.json": (
        "76063f121667620ff0de8227dfedc1f9e86e61a4e2c10935d7f59caa2270f024"
    ),
    "predictions.jsonl": (
        "e464d96e3cadd8931f0345b3b20b71c04eaf89170a21c84922d41948398d687c"
    ),
    "unscored-predictions.jsonl": (
        "50b80294052bca3e0baba3fc9d559afbdca39ab250cf654ed86d3a7c641708a2"
    ),
    "logical-completion-ledger.json": (
        "f73fb8322288a076b97cac6df7b7871f27b8ae0e2d832717e5baf4335ec8d6fd"
    ),
    "artifact-manifest.json": (
        "1595d73304211722fbf9bbee9516ef3e9cd80b14911df64d9da18f8d6ab5eda7"
    ),
}
_V32_REJECTED_PREREGISTRATION_SHA256 = (
    "585365a0c5000cad697a8244e7468121e098ef9999bf72a90f8f6ee5c39d08d1"
)
_V32_REJECTED_PREDICT_RUN_SHA256 = (
    "7f8bbe9b124a4707d0ed44f7ceac3ac8718f9c0c58ef603739bd09cc1822d747"
)
_V32_REJECTED_PROMOTION_SHA256 = (
    "e6e823261be996438be78f075fe4d3a46758de039b9c2a63dfee61639a02687c"
)
_V32_REJECTED_LEDGER_SHA256 = (
    "2b8dc29086145f724bdf1b0dd0592a6206171a5f5810f1b4b5cd76d5b6bde157"
)
_V32_REJECTED_CACHE_STATE = {
    "file_count": 6,
    "files_sha256": (
        "40fa0bfda774f119ed77b46b01452a1e425bd18d4d539a7f699004d72cbc1f3d"
    ),
}

_V33_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v33-"
    "maturity-calibrated-dry3"
)
_V33_REJECTED_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v33-maturity-"
    "calibrated-tuning-cache"
)
_V33_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "6a8a42ebecc2189982dfe87dc12e9f2def33472c6bb38825178a97e494ef20c4"
    ),
    "predict-run.json": (
        "6b861849ee8a34ee12da5338dc7045c5b4ffcf89bc6eb5d21060c1b3aebee4a1"
    ),
    "promotion.json": (
        "f4cdbfa87d6dcf7a65d3331abc95d0b665dd1335801ba72fed0c16683b1f1110"
    ),
    "metrics.json": (
        "95a67b2447fd1cdeb9b0be8a65aeefcd08285f3ce4e34ff8498e1b0180a2cf47"
    ),
    "predictions.jsonl": (
        "121ee8b0951eec3617af357b6e368375d8dcd72e84e42679f4abb1bc2c0ddfc7"
    ),
    "unscored-predictions.jsonl": (
        "fcf6931a522126e55c61d4fdfc6732417fc48c36ac222fd9eb0f64a8fd1ebde3"
    ),
    "logical-completion-ledger.json": (
        "7410fa83ce3501509b1c6defffa6d187f015b9a1642c09d219e2b0bd7f11c535"
    ),
    "artifact-manifest.json": (
        "67ddd8a66861a60ac54405b7cf25f5e66715d3db1d087004b030677bef37378c"
    ),
}
_V33_REJECTED_PREREGISTRATION_SHA256 = (
    "c55aeaba361010d47b0be494d6a8b3fe321c172e2e549a37124631e013a5b386"
)
_V33_REJECTED_PREDICT_RUN_SHA256 = (
    "38e0e61d04206fdab059612e785b51731936970a113228c0de37f4e90b496b16"
)
_V33_REJECTED_PROMOTION_SHA256 = (
    "d630393a375c16bbee6e53e8699286a2be6810f858b3b0e711232c85a2ba0de0"
)
_V33_REJECTED_LEDGER_SHA256 = (
    "04b68a496dbf90d6a5006e7e1bfb4ab97859826878400272c82464e875d24227"
)
_V33_REJECTED_CACHE_STATE = {
    "file_count": 6,
    "files_sha256": (
        "5c7534a2545b42d8d896fb2914c2778f4fc437ba818bc015f2ee6afadf346772"
    ),
}

_V34_INCOMPLETE_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v34-"
    "capability-query-epoch-full30"
)
_V34_INCOMPLETE_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v34-capability-"
    "query-epoch-tuning-cache"
)
_V34_INCOMPLETE_FILE_SHA256 = {
    "preregistration.json": (
        "01b863b7d7c1cb6244e6d97b063831ca0fc09c39f21da698d01feb5a39c06e1c"
    ),
    "unscored-predictions.jsonl": (
        "83649c9f2ab64cc1b9c236c79842be9ed207d498e87397a5720eb823257ea8a8"
    ),
    "logical-completion-ledger.json": (
        "905844f9cd1a7a3e7a5edba461d16718a70c79a29e9eb175e13e2bfda90d3dcc"
    ),
}
_V34_INCOMPLETE_PREREGISTRATION_SHA256 = (
    "02dae1fe149e996d0bc263483dc37ae068392679a7036ba69de5aa6c4c1fb926"
)
_V34_INCOMPLETE_LEDGER_SHA256 = (
    "159318aa6c5a0f08c80f98733ee938c55e7a27df314518c34c6c64dd8066f769"
)
_V34_INCOMPLETE_CACHE_STATE = {
    "file_count": 42,
    "files_sha256": (
        "f3162fec83833d022d2e1b3006d6af675339f6043db7b31f32389f3c8b53012f"
    ),
}
_V34_INCOMPLETE_MISSING_REQUEST_SHA256 = (
    "b9619f5ee52da7035a410e9b763d4695bd5555248a3c54683751502a473fa4cb"
)

_V35_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v35-"
    "symmetric-brace-full30"
)
_V35_REJECTED_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v35-symmetric-"
    "brace-tuning-cache"
)
_V35_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "7aba7bf2d614aa22069ef9d3c2712fab77e76cbd1f42f3e270017549228559df"
    ),
    "predict-run.json": (
        "d7a33654d5a85d62fff46a2da45c989cf0c81070ea975ae7e59f85115dc1e188"
    ),
    "promotion.json": (
        "72edbba6dfd3a7949703ba882db0c37da639b0a5c097b21feac3aadd7a252db6"
    ),
    "metrics.json": (
        "4c4592886fdbd52654871db63c1038cada6f73d3fce22eedd120657c93ba9f5c"
    ),
    "predictions.jsonl": (
        "02418dabda2aba3caeab6dd75ee591c36e435b1152ca429a591338bb2593ca31"
    ),
    "unscored-predictions.jsonl": (
        "4292e911fb0ce79e7f07b2bb15cc355882afe1565ce67e7fcb690805a03f43c1"
    ),
    "logical-completion-ledger.json": (
        "3c476d5c7580f86b7c641064d2f6193c35146cffe2fad54191b37ae853a4597d"
    ),
    "artifact-manifest.json": (
        "b662f72746e8c54e9eec52bba86694b36dcf752553bbda7a93401201f3c44e70"
    ),
}
_V35_REJECTED_PREREGISTRATION_SHA256 = (
    "2a8118f2527931b39b3825d27c9ebe8a8ebb2bfce34d9b7ad09eefed88f36eb4"
)
_V35_REJECTED_PREDICT_RUN_SHA256 = (
    "65a6ccddb710293fe94a0f106b28ceeadf69b94f8e2f44f23ed73006d0606d25"
)
_V35_REJECTED_PROMOTION_SHA256 = (
    "56929b4280ac5604907fc7bb160962687c9ec01046299e0a15b2ba11e3c0141c"
)
_V35_REJECTED_LEDGER_SHA256 = (
    "b9f9efdc5e346650a73ebd03cb89ff1ed9dd6864f60f154a61cdea4ef74bfab7"
)
_V35_REJECTED_CACHE_STATE = {
    "file_count": 66,
    "files_sha256": (
        "18ad5cb29bac5dad979cf238a100a22f8b24485add6d1a3e663e9aa11bc9dd89"
    ),
}

_V36_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v36-"
    "original-causal-dry3"
)
_V36_REJECTED_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v36-original-"
    "causal-tuning-cache"
)
_V36_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "4032165b6cd3fc46eccb6323010d3f553b010fecbd06ef0887f485b9cd4160fc"
    ),
    "predict-run.json": (
        "515ede15ec0f1d830585843c9ad315a8114409ac773f211813287387325dca0d"
    ),
    "promotion.json": (
        "dcc580e63e36c2a06d9d54cd8c9027b781e6e0a825b2ec90f8f6dde0d817b33f"
    ),
    "metrics.json": (
        "11a110fcede8e2d567415a0101b9d29b593ff09efa4e638c65293f44a1d43bab"
    ),
    "predictions.jsonl": (
        "a9c31b8fca345d09b7e64a8a248338ddcb447660ff9e7a2db416838e40b39c9f"
    ),
    "unscored-predictions.jsonl": (
        "ba993271afad95610b12e1676ab8561208d8ef451ab6c500713b224029a474c0"
    ),
    "logical-completion-ledger.json": (
        "09dd2e32207a02116725842e05eea80a1d788c5170a35ba9859ab5e831575bae"
    ),
    "artifact-manifest.json": (
        "540ae225992ea486053a8bae7b8bb40535381832bef39ceab5a7958dcd552626"
    ),
}
_V36_REJECTED_PREREGISTRATION_SHA256 = (
    "b42f9b57892b7e3503320c258df36a8765129541c0adfb7b8320d3abadc25e78"
)
_V36_REJECTED_PREDICT_RUN_SHA256 = (
    "ac3f2ca00f6c5812f985af1f75acad7270be60ea3bae98399939e82efdfc360a"
)
_V36_REJECTED_PROMOTION_SHA256 = (
    "99653f13646953d9b18f65b3f6b93f543d1ae07508a654d83c5697806010fc1a"
)
_V36_REJECTED_LEDGER_SHA256 = (
    "d5e5864fa47d2854cfd575ab2839ab23c2169cf72c1d015d5e8810c30b174a4b"
)
_V36_REJECTED_CACHE_STATE = {
    "file_count": 6,
    "files_sha256": (
        "b38153c838443f89893e078989c4163cb7a30f188cb537f2a371b5d60ed8fad9"
    ),
}

_V37_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v37-"
    "incumbent-preserving-dry3"
)
_V37_REJECTED_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v37-incumbent-"
    "preserving-tuning-cache"
)
_V37_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "e04d2d38153b0a1b2d0b4304a1f3c01ae8671dcf41cd05ba22dd7b2a9314ce8e"
    ),
    "predict-run.json": (
        "21cf794297ce87ed6c87a58fe4a344c2669aaf5f3c63db38d9dfcd65ecf95d54"
    ),
    "promotion.json": (
        "236863f6f0663ef1816eaba323ccc99a6b9bfe09ae963582e8817555ef25f19d"
    ),
    "metrics.json": (
        "3e9b9f17e87b2e1a6781766bb5068899575b3fd36ea709db2c99ba581f1c83f1"
    ),
    "predictions.jsonl": (
        "edffc62f6b0ba7054a85f28f62091f8e5995eeb478050e92aac7cc935f0d2d25"
    ),
    "unscored-predictions.jsonl": (
        "59c86c0e86596246942e2f5eef3195067837800c068333ae9e02e04c5ce3ae00"
    ),
    "logical-completion-ledger.json": (
        "040d838e8f08c73e74ae7a9a1e4ad76845e08976690d828ad81323a758555b51"
    ),
    "artifact-manifest.json": (
        "cfb4864002de1cfbc95b14680ceff74fd0d7570c221017cb0349148302f4d86f"
    ),
}
_V37_REJECTED_PREREGISTRATION_SHA256 = (
    "46d42db6fc61a9d91d1c70583f283fe4f4753f3e71558bc4d78a8ce8b141cea6"
)
_V37_REJECTED_PREDICT_RUN_SHA256 = (
    "b96cd0b7bcc4ecf4cbf21d17df5ae0fb8b433330614498941d95e3dcc147599e"
)
_V37_REJECTED_PROMOTION_SHA256 = (
    "fbaf51fbd21751f6d27ad5d0440f74b24355d75ed3d5cb2920918b3d28739098"
)
_V37_REJECTED_LEDGER_SHA256 = (
    "56f8f12bfe46e43ba44813c69bd4e7e9ac6296e8688da7da00350b247bdd5d95"
)
_V37_REJECTED_CACHE_STATE = {
    "file_count": 6,
    "files_sha256": (
        "7dc2dd8e983a64cceed9a405c040057ed8a4cd3fc4773bbd961b2fb1db167151"
    ),
}

_V38_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v38-"
    "first-defect-terminal-guard-full30"
)
_V38_REJECTED_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v38-first-defect-"
    "terminal-guard-tuning-cache"
)
_V38_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "5561c6c4b418d43d957c384b0307246d6fbdcfd538d73d821d94feb0da45d651"
    ),
    "predict-run.json": (
        "20fbfc773257dae4cffa940d37f4bd5b0be0bc6a6f1932014f6d300f5dbdf9e7"
    ),
    "promotion.json": (
        "582056ca29a725376fba93258ace69bc4db2aabfaa4f17feb5af56c863231e85"
    ),
    "metrics.json": (
        "ef8f312efb05309d8c1a3d24ee633cfabf37c892797cb1141af75be61035d42a"
    ),
    "predictions.jsonl": (
        "3a4200c1cacd64ebccb70a578770cb0acc55ce8df17a43c0087af7bfd2c39766"
    ),
    "unscored-predictions.jsonl": (
        "81da0d08ad6efb1c3af721143a8c635334356c897cc5d1d6204b30eecf2d1aee"
    ),
    "logical-completion-ledger.json": (
        "cacdb4b6ac9982206c8557d2f1f3c009e00958330e78de7289166f2f1689aceb"
    ),
    "artifact-manifest.json": (
        "9ebb627f5528bbcb2b21c4e54491cb2b457fa2cbc383e8c7ba19ef5464f06c81"
    ),
}
_V38_REJECTED_PREREGISTRATION_SHA256 = (
    "248d372d2bb682203320e4a404df27a5244377d54ff4d0dcdb198b32a9d613a7"
)
_V38_REJECTED_PREDICT_RUN_SHA256 = (
    "4ead0001cc84a8b560adafc25571b3e695ce3e05e2287a55ac53eb0cdb066996"
)
_V38_REJECTED_PROMOTION_SHA256 = (
    "e447689b3d362b3f7c4dac461456c6b3f9b02a8eb05ae29a209fbd501252f57c"
)
_V38_REJECTED_LEDGER_SHA256 = (
    "c61b19557f9eb756cbf9534cc9c2fdcec76c8945e6b750e603aeb19da3d17631"
)
_V38_REJECTED_CACHE_STATE = {
    "file_count": 66,
    "files_sha256": (
        "81ce5ef8180cbc04a24d4c749c5a465842ab94689a7e0b5d45b0db421bf710e4"
    ),
}

_V39_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v39-"
    "multi-hypothesis-causal-ledger-dry3"
)
_V39_REJECTED_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v39-multi-hypothesis-"
    "causal-ledger-tuning-cache"
)
_V39_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "4db4920381e5b1c704e48fc5039815a08458cb27007cd3af894040e5f5bd15f0"
    ),
    "predict-run.json": (
        "e358048427cd8f7ebace8f96910052ce73274af4de170e668ce94d5c99181874"
    ),
    "promotion.json": (
        "88d56a4b1c3a5c8b92c047f0404464401badef2dd787528c91c6aa577a39686c"
    ),
    "metrics.json": (
        "63aa53dcf49a08a16c30cf626595c22c2ec6d3e347670efc629ec86e81835f69"
    ),
    "predictions.jsonl": (
        "5864450e5619c672e140fe27745b599d10ee77269d9f29fa3310cb1cb457db99"
    ),
    "unscored-predictions.jsonl": (
        "096d152316980ba188eecc3b33443626c2e1eb08d6f3c3e5f5974a9d0bd04fe6"
    ),
    "logical-completion-ledger.json": (
        "ae7188621d4ca53d834dad8ff2c79f44a90290e69a3dac2f4f75fabc33aa1834"
    ),
    "artifact-manifest.json": (
        "b9fddf8f38bca66feb32d10a28134f705303f081a2bec21ffaa11f4f67c5587e"
    ),
}
_V39_REJECTED_PREREGISTRATION_SHA256 = (
    "8ac279af49eeb6a8b543e1efb01f7e6988e5aafbd5cd558b23e0c7d5975550f6"
)
_V39_REJECTED_PREDICT_RUN_SHA256 = (
    "0bec282c1c103b8711d0ed1637256a460efcfed987df472819efa9a11a730f5d"
)
_V39_REJECTED_PROMOTION_SHA256 = (
    "500ea179ca697c25b1a7946ce65f83e8336fd1a2c01c20691d9ca9ef4f532f87"
)
_V39_REJECTED_LEDGER_SHA256 = (
    "cb49b5c61a02cd32f52cebe7c044afd73315349dc7b0c0d87634061edab49447"
)
_V39_REJECTED_CACHE_STATE = {
    "file_count": 6,
    "files_sha256": (
        "d813f3fa6d53e51c33e5dbe6b603d491f2db660daaf47fae27815bd0018bd00a"
    ),
}

_V40_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v40-"
    "causal-ledger-length-full30"
)
_V40_REJECTED_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v40-causal-ledger-length-"
    "tuning-cache"
)
_V40_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "85c1bab8ee2803f492160e094097cc62ec21faf2ae4d4585d72a42e4fe76e709"
    ),
    "predict-run.json": (
        "e4bd4aae510fb632dc97f9d699f54f91261a36f3243440e9a301c0b8a3af1c9f"
    ),
    "promotion.json": (
        "606a16ff8b544725640bc1396d61837abb9e506a23261c4447270978578b3754"
    ),
    "metrics.json": (
        "7dbac9436aa2053c8d3c7428ee3a8ccac108996b70c33ffeb124a190a245d4b4"
    ),
    "predictions.jsonl": (
        "4c34b63e8279d64a171470ca0afa37e8f4c60c448fcbdb9dc65b3812c5fa6a44"
    ),
    "unscored-predictions.jsonl": (
        "adc27d45d53f4cff35ccf24eb2bcfad5e92f091633f4d4af4491962327bac759"
    ),
    "logical-completion-ledger.json": (
        "b32b8c7cfb2e6e419465761c3c790abca337bcd14d67f8a75d292c5873340fd0"
    ),
    "artifact-manifest.json": (
        "7b48817bf0974c6006f062e6c437dee784f54ee045f6b11c4867792c300a3662"
    ),
}
_V40_REJECTED_PREREGISTRATION_SHA256 = (
    "6aada33ee16b3246458e798513dd093ea159c521094a456cd4209e75cb809d94"
)
_V40_REJECTED_PREDICT_RUN_SHA256 = (
    "ceedaaadd788c80aba99428c3991fb09288a58326fcb48fee9ad722f3e0c43e0"
)
_V40_REJECTED_PROMOTION_SHA256 = (
    "8cd4a01f9560966dd8947220de0ba689ebca23f62fdfdb4ab1eadfe1cebf8223"
)
_V40_REJECTED_LEDGER_SHA256 = (
    "44c755b77fe94b32834630adec4812a6475b75c4f16a87c7dba21628b29a8e0f"
)
_V40_REJECTED_CACHE_STATE = {
    "file_count": 66,
    "files_sha256": (
        "c40982069f6f34f8f20fec003762ac55d1fc0ed89eb811f73006b7e25aaf2434"
    ),
}

_V41_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v41-"
    "symmetric-module-census-dry3"
)
_V41_REJECTED_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v41-symmetric-module-census-"
    "tuning-cache"
)
_V41_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "4eb8a9a34aeefd05c40a67b2f47dd310b73559d848c7e7e442243f2518afe6b7"
    ),
    "predict-run.json": (
        "190a6ab9879cf2ece44dd8021aa8e3d3a40566211ffa6767062bbf43bf9b21c0"
    ),
    "promotion.json": (
        "325610b02701d36ed4d560b63c09ebdaf704e337581eb785b06e5662a909a59b"
    ),
    "metrics.json": (
        "0a9cbb3c37aa28c6c8d9cd1b1aa32957c27ecda1f654027c1bd2884d139f7d30"
    ),
    "predictions.jsonl": (
        "b5c448435ba84c2cfdbb7b474acb1639c4ec320ce387629ebd96e8ca535b3001"
    ),
    "unscored-predictions.jsonl": (
        "28fcf0afe13e0187e84c014e0d7fa30581805704f91a94236ddf6f178aaf939b"
    ),
    "logical-completion-ledger.json": (
        "fdb68736ec7af2e8a9cf9b229015731d64b21ca541b3b8073693a54d65818be8"
    ),
    "artifact-manifest.json": (
        "3618f4e66b3f5fa20898f45241df615c67f9eb7cb00a7ad16b35307330a3e539"
    ),
}
_V41_REJECTED_PREREGISTRATION_SHA256 = (
    "d7c1087e4845bbd2f71089cb88ed9b4b49c52dece774243597a01102d9032cf1"
)
_V41_REJECTED_PREDICT_RUN_SHA256 = (
    "f9a0ba488e4099148853b357fe9ecc9227021168ae4e7c746f8fd3bfdced5a34"
)
_V41_REJECTED_PROMOTION_SHA256 = (
    "ac5b076812402d3a950aa09c58eb81658cdda401e71171887dffdf8661cba1f1"
)
_V41_REJECTED_LEDGER_SHA256 = (
    "b5e2d9ff830587a91726b4bcc9530ae7d50fa27a00834dd348ac52877b653a75"
)
_V41_REJECTED_CACHE_STATE = {
    "file_count": 6,
    "files_sha256": (
        "0f6f1f86153ab15584c54756976de542aad880738719f42f0bfe9ff34b213b59"
    ),
}

_V42_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v42-"
    "chronological-module-census-dry3"
)
_V42_REJECTED_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v42-chronological-module-"
    "census-tuning-cache"
)
_V42_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "ccbadfb22caf6050a49af04d2c846e6952eb1ca8c27abbec0605d3b5003e78de"
    ),
    "predict-run.json": (
        "d9a6b014b859eff442f6b97892895ff4095c1b662d1b3a965f8b4c51ebb8b39f"
    ),
    "promotion.json": (
        "31184287016cbd96c8646ee86c1a1e65a1f5eb03fa66714306915d939b6a85ad"
    ),
    "metrics.json": (
        "880483d3cc24d39ea497c0d782d1a474324353745340703ea26466ffa3ef993e"
    ),
    "predictions.jsonl": (
        "57f8f846a892ba649c6fa3721f9ac7868df8db04f12bb9a7db6a3a86b600379d"
    ),
    "unscored-predictions.jsonl": (
        "ddec56714f2693b4b8b8c71012be1ac5fb189b83a11ad7cd252fc9cc19b87051"
    ),
    "logical-completion-ledger.json": (
        "714922632e8afeba313075c1722c0035a2547c28f588ea2c871fdfa3688659b3"
    ),
    "artifact-manifest.json": (
        "a14b2c9d3480ccf3ef5882ff9b31f85ba2d9d666f5ba4ace79a4306ddad69017"
    ),
}
_V42_REJECTED_PREREGISTRATION_SHA256 = (
    "ce5e4aa9ea03ada9b7fad255f7fa7b9ed155bcaf7f2e5d3aa6aa539ebe9b462b"
)
_V42_REJECTED_PREDICT_RUN_SHA256 = (
    "eeab201186543397d154903c1d7149d7c505acc20ddcac34c515344458159d60"
)
_V42_REJECTED_PROMOTION_SHA256 = (
    "353bab3431cc4bd26b5977030f489a7c1bb32fbb970d8e8d2b6d80be7d27c3b7"
)
_V42_REJECTED_LEDGER_SHA256 = (
    "de76bc20034cb205cd87625dec6142487e729a76ddc9eab056c9e44d2828f29c"
)
_V42_REJECTED_CACHE_STATE = {
    "file_count": 6,
    "files_sha256": (
        "2aa200ae4cd97a66fd4f439f86658297af134e92ffdb143b98d1fdfe00496ea1"
    ),
}

_V43_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v43-"
    "symmetric-causal-lanes-dry3"
)
_V43_REJECTED_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v43-symmetric-causal-lanes-"
    "tuning-cache"
)
_V43_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "f11041725c806e2a44c46472a2a0dd08c192f2f54822fe405c55af9f458f446f"
    ),
    "predict-run.json": (
        "6c01a9154bfd8d81f6ebbbaff7ba388af41a9942c04562becea4af002f9ca9ea"
    ),
    "promotion.json": (
        "8addf77f50f5739077f1e098a76b2503d5a9b8c33799aa7b4afead90c5229379"
    ),
    "metrics.json": (
        "a5ddb3d8d02849a4964ac7c6a3fd822a1314aa205806afb24fb9100f5137f3e0"
    ),
    "predictions.jsonl": (
        "c149dfb48f41f2c80a9d6537a910a38b9525d745b1ffee712b7a92e61d9d947f"
    ),
    "unscored-predictions.jsonl": (
        "e162fa32f73996721f7749764c011fc01f5f192309b45bdceaba6fb1ccf6b3c4"
    ),
    "logical-completion-ledger.json": (
        "5f4f2b4e14c403567556d9c2a7407d1c02c618d4ed2305952e8b472cc37fc535"
    ),
    "artifact-manifest.json": (
        "247348281cc539f02d9c07883713c6f892b07114c8ae90329e86bf4a42bcedb1"
    ),
}
_V43_REJECTED_PREREGISTRATION_SHA256 = (
    "e883fed2024d919a4042ae4ac1a4cd12b97775500f216377bbcc088c27dc967d"
)
_V43_REJECTED_PREDICT_RUN_SHA256 = (
    "ae3cc0c88dc4437c19ce25e6fb847be4bbc34c4a68b7de3b58ca73d3265fa891"
)
_V43_REJECTED_PROMOTION_SHA256 = (
    "1d25d576d79f9181744fad46b3b8d1aa70f82b0ff0f81197acb5a9901896e256"
)
_V43_REJECTED_LEDGER_SHA256 = (
    "1f432d6f8271276e57304af81f195c8f69fb1f19d15381711ad1b4a4f2582be8"
)
_V43_REJECTED_CACHE_STATE = {
    "file_count": 6,
    "files_sha256": (
        "5b577d110eab2de235d57d659aacbcd9039a5e0e5a5f9f074e3749a646eb7a0d"
    ),
}

_V44_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v44-"
    "failure-preventing-causal-lanes-dry3"
)
_V44_REJECTED_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v44-failure-preventing-"
    "causal-lanes-tuning-cache"
)
_V44_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "76d3c3de98bdfd12c19fd9f69aa110e009a6e579c614f2f490f6d389f2f19fb3"
    ),
    "predict-run.json": (
        "b258322f6f7b2ae30ea9846c1e0cc4f623ae1a4935e6c9f78dc77e38a5000d30"
    ),
    "promotion.json": (
        "f48bb250f14aa708ac8bf1e7b088a25d8eaa52100cf59bb1afac539428e003cf"
    ),
    "metrics.json": (
        "02bda85cb5935060b2de72870b66b33daee9393eb41f5bd709eaf867f4f1ac4f"
    ),
    "predictions.jsonl": (
        "61da24996b9e548754ba0822a26282427d3856baec9c12d02a0ba2b9678f7c52"
    ),
    "unscored-predictions.jsonl": (
        "3bdbba43b732392627458f6561a24593cc3c450bf3a6c56bf4e5cea88ccef4f4"
    ),
    "logical-completion-ledger.json": (
        "b2ec2c396f936bda1bf5eb31929bc5e758d83c7f40a2f43f4342e0904c6dd49f"
    ),
    "artifact-manifest.json": (
        "d2a630b14f94eb35c7ac73b0192c655dc2fbeb89a61c833ec6cc3217d49231d8"
    ),
}
_V44_REJECTED_PREREGISTRATION_SHA256 = (
    "74093b1cabcb507096bbe1f97f3aaaec666c083866d485b99df4d42faab695e9"
)
_V44_REJECTED_PREDICT_RUN_SHA256 = (
    "5d14e66c1acd1a88fcda0ffc4d27e232c2efdd42112ba77fae0d65843d749cc1"
)
_V44_REJECTED_PROMOTION_SHA256 = (
    "c48af173d300642f3149f6ad3febafa5cc1f7367506d3eceab95b01b1747cd86"
)
_V44_REJECTED_LEDGER_SHA256 = (
    "963f31eeec624ef0c060eccdfcce43384e108db9dca0a0d5698ac3ecd5c01289"
)
_V44_REJECTED_CACHE_STATE = {
    "file_count": 6,
    "files_sha256": (
        "5c22ed40f9ea210b06587c123ad7adcf475ec1ea0d1c438c8b40859d1d4eaff7"
    ),
}

_V45_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v45-"
    "categorical-boundary-action-dry3"
)
_V45_REJECTED_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v45-"
    "categorical-boundary-action-tuning-cache"
)
_V45_RECOVERY_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v45-"
    "selector-recovery-dry3"
)
_V45_RECOVERY_ARCHIVE_RELATIVE_PATH = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v45-"
    "selector-recovery-input/code-bundle-recovery.tar.gz"
)
_V45_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "442e1c464232d91ebd7a246d7f55a77e6d4dfd33fc19254e97b40ce6db95b1db"
    ),
    "predict-run.json": (
        "e4ebe2a8e8e6964fcbf13d453cec448acd86fef7dfa09f752996ff648cbade0d"
    ),
    "promotion.json": (
        "4a77c920d62074daa92698860a17185e23469ea813d84e7a7fcd8dc547250200"
    ),
    "metrics.json": (
        "b8707225937e348268fedc023d01c8d13c021a5b19c699ab2b698943c8fc75ba"
    ),
    "predictions.jsonl": (
        "a8d1ffee3e3bd76dcb0194aa9caaeb43e73d0f64654232451078dcb7383b6e07"
    ),
    "unscored-predictions.jsonl": (
        "842c307cf1078707d9db49ac597548248471969ab6bb1e5d4a7893525fd670ad"
    ),
    "logical-completion-ledger.json": (
        "caefd523e4b7e4e2e67d2b5d81bb423d280a031cf9b55caa6be63d02d3f64b5c"
    ),
    "artifact-manifest.json": (
        "b2eb6d92628da2430a141745717aa32ecf56568682a06192b402c7b4fe3cb41e"
    ),
}
_V45_RECOVERY_FILE_SHA256 = {
    "preregistration.json": (
        "313eed2aff1eb2495fd06c3a3837b62c16711e492b2448c207941f827246545a"
    ),
    "logical-completion-ledger.json": (
        "77d6dca9a6dd6ce9eb802350c3a3ed67e4f05442db7749a81f5711204a9a6c0f"
    ),
    "recovery-run.json": (
        "a6eb41aa58ecfc2bb43586f3a0287ecfc0807411f5f51d4e25622dcf2665d782"
    ),
}
_V45_RECOVERY_ARCHIVE_FILE_SHA256 = (
    "ca8609af0fca24a3fd49400e8551daf0cc707ae623f65664383c4ebd00961988"
)
_V45_FAILURE_CASE_STUDY_SHA256 = (
    "c32470263f99534f154b143cc17cc04164e946e18a1252cfb288882e69dbf822"
)
_V45_RECOVERED_CASE_STUDY_SHA256 = (
    "a42b86e1fb3083d729ea643780bc327d0d427d155d182f6514816b36153cf525"
)
_V45_INVOCATION_CASE_STUDY_SHA256 = (
    "0babe8fbac68fb4dd09fdd1b0715aa73afbaf041c79abd66869e29e5dff464ec"
)
_V45_REJECTED_PREREGISTRATION_SHA256 = (
    "5627147d3901c1fa0a23d9ddc06cf2da668503dfbc89325e5cde08830582af83"
)
_V45_REJECTED_PREDICT_RUN_SHA256 = (
    "f0e19b19114e452fbfb42d09393d4ca6863f57e6900fb2d0d9cbe3efad048c20"
)
_V45_REJECTED_PROMOTION_SHA256 = (
    "cc8f9220071576ccd44fd3d5465fd9a5bf581fd891c9a5bd6be2631b676ececd"
)
_V45_REJECTED_LEDGER_SHA256 = (
    "e123e12fb7d5502cc80a1cb996eb8f7791e7161c8db8e5d1c0c0a66d569a78fa"
)
_V45_RECOVERY_PREREGISTRATION_SHA256 = (
    "f772c8f52f1bd1169b09f4c57d0473f05e927c08391180560bda9e616ec7ca80"
)
_V45_RECOVERY_RUN_SHA256 = (
    "8efd312a107bcc62cf7bc2f3679db7e72e39f909df032f9e7b29df78e6575cb1"
)
_V45_RECOVERY_LEDGER_SHA256 = (
    "7edb5cb94f40471861d91d0417d0e79759fed6af18fb18b1e30464125773efc6"
)
_V45_CRITIC_REQUEST_SHA256 = (
    "a6382dec3f94a9f5acc47e6625805887ccb634b29842098067857665e609c2c8"
)
_V45_SELECTOR_REQUEST_SHA256 = (
    "4fadfc5080530223bcc88f9077c64cd9ede5a353f3758f79c7b1a9c35b6ab989"
)
_V45_REJECTED_CACHE_STATE = {
    "file_count": 6,
    "files_sha256": (
        "d414f241e077bcc4b50515683e00326ac4b891607aff0e51c700d629ef705d05"
    ),
}

_V46_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v46-"
    "persistent-information-root-full30"
)
_V46_REJECTED_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v46-"
    "persistent-information-root-tuning-cache"
)
_V46_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "eb95f95f1fb8e7ef3d313403f709b967d1aa78745ed276c2add95879260bea94"
    ),
    "predict-run.json": (
        "248fc46183770da46cd714b92254042e881185d5d5a02a9e3321be5badeaef3b"
    ),
    "promotion.json": (
        "6830a79b56c37479af52e16326b2fc43435788b089d9754ff2ee7078355a68ec"
    ),
    "metrics.json": (
        "a886f67513aa0e417257e6d5cec32e12f05cce45d063226bd7266edbb24f94fa"
    ),
    "predictions.jsonl": (
        "3e1322bfdbec03e9811304aef0fad01c45ebad0471168f4f5ed05734da287f79"
    ),
    "unscored-predictions.jsonl": (
        "22f70432086e4300b627492ccf2deaa074746b4c57d3bfb572f7cf39cf06af7f"
    ),
    "logical-completion-ledger.json": (
        "a85cfcf5797ce91aa75f640789d230118aebbb8f09a4a81f66f2b033de662141"
    ),
    "artifact-manifest.json": (
        "a71046b22877028ba7044bc5dbb79279f184d1e9734e3b14edc8c92a6b31fe06"
    ),
}
_V46_REJECTED_PREREGISTRATION_SHA256 = (
    "8f4d9f8c2b1cd9a94fdcbb12a12f1dfd6e502264908db4118f3328a7c33d8fe1"
)
_V46_REJECTED_PREDICT_RUN_SHA256 = (
    "c5bf1b088b2647d7a395ebdad098e8132a1b976ccd6b7d720d817e177f255814"
)
_V46_REJECTED_PROMOTION_SHA256 = (
    "5d69876962d95958b1870f1f6c9d12aec0e186575dc39122771e255b83a33ce6"
)
_V46_REJECTED_LEDGER_SHA256 = (
    "8d5f90104560e3c8286cbf83a4c6ab2bd625a3aea75b1c3b1b5b5064906a408e"
)
_V46_FAILURE_CASE_STUDY_SHA256 = (
    "6cca2868c9fd31fa179027f22bd0cef15b173a859eec1d202032f350352f54be"
)
_V46_REJECTED_CACHE_STATE = {
    "file_count": 66,
    "files_sha256": (
        "024b7c9da8912d9888bbff6726bd670624f4b4816db1f63108155987bd8364c1"
    ),
}

_V47_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v47-"
    "five-lane-handoff-dry3"
)
_V47_REJECTED_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v47-"
    "five-lane-handoff-tuning-cache"
)
_V47_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "47721f576045e0e9e2bb1e98a4b46930a1fff7163eeed79f26ea08080dd325ce"
    ),
    "predict-run.json": (
        "c1367aae2a5501554fe9e2d30a497bd3659d591a24030deaf3bf3fb9eefd4068"
    ),
    "promotion.json": (
        "1aaf415b6fc8beab1d98f510e7cbd40fed39825c0012dec7052ca96412604955"
    ),
    "metrics.json": (
        "3678b583131cafd7b9ee135513dd78e650a06cd2ee976e8d5c75288e0d287df7"
    ),
    "predictions.jsonl": (
        "85c0b8d0cd5c09756e998a86f40a2ccaf32c151a3b619fe19dac421db65f51ff"
    ),
    "unscored-predictions.jsonl": (
        "c92b6c2bf930de8a611c2f0de0cc46a072647dac9e162b4e863b27131b01ac4b"
    ),
    "logical-completion-ledger.json": (
        "fd20be7250b379ca1b4aa69e1dcad45619a3ecf44eb9ddb6f4e08fcff1778ea1"
    ),
    "artifact-manifest.json": (
        "890edaec205c8f1551dbcff3d6eb4f9f1de4c0e423f84ddfdcd8d6cc1fffcdfa"
    ),
}
_V47_REJECTED_PREREGISTRATION_SHA256 = (
    "31c76ce9bd904638fa072b224539d7d789daac445ed9cbd1d4a55d7eb1f17ba6"
)
_V47_REJECTED_PREDICT_RUN_SHA256 = (
    "57719017a877b0ac4ee314c0bfd170d7d6840466d20e95490f82f3d8a7d56ca9"
)
_V47_REJECTED_PROMOTION_SHA256 = (
    "8b725013182f478d71178a8c6d6acc1da06d85666624ab026027434069bd3970"
)
_V47_REJECTED_LEDGER_SHA256 = (
    "411220b3eb7dcb7f104e9631a3fa7c4437d7783833e06c6e299341034f986040"
)
_V47_INVOCATION_CASE_STUDY_SHA256 = (
    "b4dc7b5b3b99d4e4c8bbfcea90acd962804450d7827e856708067b41df7e3976"
)
_V47_FAILURE_CASE_STUDY_SHA256 = (
    "412edacd1b0e832830b7eed0a7f8abd637d11dc13f095d688ac01f6c1ecb16e6"
)
_V47_REJECTED_CACHE_STATE = {
    "file_count": 6,
    "files_sha256": (
        "57e040dcdf1b685700d93a404245bf4c142017e375f4082440a2473148f11c26"
    ),
}

_V48_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v48-"
    "scout-broadened-handoff-dry3"
)
_V48_REJECTED_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v48-"
    "scout-broadened-handoff-tuning-cache"
)
_V48_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "6a92cf6924afdbb7f60fad344dd43341954718ea93ecb9bf5cf8abd99b608022"
    ),
    "predict-run.json": (
        "9cc780cb2324d664041233a6ae615a741f689000c61473972d76cf75b368a10d"
    ),
    "promotion.json": (
        "9dd689e1c7a48ec3f992f7f0c43770949593eeda68bb8f9f11e4b444aed0c17c"
    ),
    "metrics.json": (
        "781f5099ef2e9c08eea095588c1afe01cd50397114bf1e062389d593b1d9aa48"
    ),
    "predictions.jsonl": (
        "1d3dbb586974e554d8c8c4f5210287cca923e4990498f4b421e64c992dd1f135"
    ),
    "unscored-predictions.jsonl": (
        "ff1c6d65956a78f14b281aced9f01d3c534d5b140ef55c3d0d8ebb162f3f7344"
    ),
    "logical-completion-ledger.json": (
        "a9942d8ded873d4d9e9d633b20afc5a745b6309831d4c3f4fccf0dca8a1cb13f"
    ),
    "artifact-manifest.json": (
        "53f518685b7759dd7c6e16223d89dc0777240637e13a75830073dc29d2a0d49c"
    ),
}
_V48_REJECTED_PREREGISTRATION_SHA256 = (
    "c66b18cb82c7499b181673583c93769bf9a94d5653248e2c719da403a92d2b77"
)
_V48_REJECTED_PREDICT_RUN_SHA256 = (
    "8574b0ad019864e4c92653cfe0b87a7b7a916620cecf2cc962ed66467c49b7a2"
)
_V48_REJECTED_PROMOTION_SHA256 = (
    "5965fdc56d820a8f411d8084b56da70f34ce313ae0bf333154f23a92d27909f3"
)
_V48_REJECTED_LEDGER_SHA256 = (
    "ca123743724f981ca82df5493a3ac0377e8294d6489bb6630848408ef7916f46"
)
_V48_FAILURE_CASE_STUDY_SHA256 = (
    "79dbf6e305522257c8a0b533ea29bd60b49e4d82826a1054a13bc6bcc318674a"
)
_V48_REJECTED_CACHE_STATE = {
    "file_count": 6,
    "files_sha256": (
        "2f43424286adfb38318e7b20987cc756253d819f24a2ad154b7f0aee671c52e2"
    ),
}

_V49_INCOMPLETE_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v49-"
    "cross-module-consistency-full30"
)
_V49_INCOMPLETE_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v49-"
    "cross-module-consistency-tuning-cache"
)
_V49_INCOMPLETE_FILE_SHA256 = {
    "preregistration.json": (
        "6479867e60497da7783fd1128a906d4fdfd7c735e478f4ef8e98fc7d66302ada"
    ),
    "logical-completion-ledger.json": (
        "4601e06ab7d0919e03fc7127fa7cd88cf39602022fcfa6e63770e88a75f780c0"
    ),
    "unscored-predictions.jsonl": (
        "fef528e00c90fe0217387ef52fdad74efbd31c06453d221faea8631e70e48f93"
    ),
}
_V49_INCOMPLETE_PREREGISTRATION_SHA256 = (
    "dd4d1619838a7dc4ce49aa0d8d3b1a80b23498fb5c14965b2da54a9d0f8e031e"
)
_V49_INCOMPLETE_LEDGER_SHA256 = (
    "745eb533306e0e853c082c121e5c7b4d4efa61611b8da8855cdec5f844b8a9ef"
)
_V49_INCOMPLETE_FAILURE_CASE_STUDY_SHA256 = (
    "03b1c12f380e1fff36a851d51a484daaa5e96ae9781722fdb75ad55a63fb674d"
)
_V49_INCOMPLETE_CACHE_STATE = {
    "file_count": 51,
    "files_sha256": (
        "ce154edf46cf16904da73fe78f5c1d2c612cdcd23d7555a5c90c6a78f647d558"
    ),
}
_V49_INCOMPLETE_BATCH9_CRITIC_REQUEST_SHA256 = (
    "bc11e3d7f205027b6d4a64119aad3c2be776f49b883d0efb9fa07a8b751e1a7c"
)
_V49_INCOMPLETE_LEDGER_REQUEST_SHA256S = (
    "a4bf63742b7da245e30c6c97f5dd790e683a2207ac5d8678a1fdb7139cbc1eb8",
    "6548150fdb7b6b8b5e27b53b2ba5c7081e7f41c9c71375dfaa42e2cbfbfd581a",
    "2726156808e35a35cca6cdd81b4c9c305eda4d4293113ecab38a1161efee0b3c",
    "f1cc711feeab97ab668d0a252fdbdb163437ccb20ebfe8047807b34d43be931d",
    "c47111762a0f8a0109d51d267b0407b5a9716ef144c773ec615799ffb22300d1",
    "bc004626d6a5d3f11a7793af71864abc97418c6f1bea3b5d5755a172fd7f23ea",
    "8b7aca9ac6b36ae94094b1c72facc842122e112740f09836c7172a258fa552eb",
    "e1fec538c6c0aad7938dbb1966c9638dd854743732b29b779295aa1887c97a93",
    "601689150a3ad495d8e5cfe77e9fb8b72c1c06db9cac5c0f05a57bd50a71a9b7",
    "a99b8c932979c10d593b65b0db96b928f75d859361cb3fabca79482439f00147",
    "350df5206eafeff9e5d3dbcf9f3c6a73fc30efd5309642d36165f797a2174ee9",
    "f2c1446bd0d2f61ac39f4fd7fc539da5b0f66560c6cd90eda30ca5a1ac29b016",
    "a2f482c6d417e1eec2cbac54a86b28959d274ff403309406bfc3a70263c9a030",
    "360138c595775f1cfe8b63865354a2ea31bbd04609d8500e1156d4ae11fe3cad",
    _V49_INCOMPLETE_BATCH9_CRITIC_REQUEST_SHA256,
)

_V50_INCOMPLETE_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v50-"
    "selector-capacity-full30"
)
_V50_INCOMPLETE_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v50-"
    "selector-capacity-tuning-cache"
)
_V50_INCOMPLETE_FILE_SHA256 = {
    "preregistration.json": (
        "4d304be36d8220fe836d943fcb0b58e41c636058c117d6388ccab2ce7ab69925"
    ),
    "logical-completion-ledger.json": (
        "c3678a831f2a4c7b9a6d1447d86b24a027662a2aedf3ac2afc13dc27949a7451"
    ),
    "unscored-predictions.jsonl": (
        "210442d41f467cb0b0caf6724cc2f405524327810fa753a9f1578e9a55450241"
    ),
}
_V50_INCOMPLETE_PREREGISTRATION_SHA256 = (
    "672e5b36bd63743f4fd308318aca622c573cf978963251860463bb5485bcab22"
)
_V50_INCOMPLETE_LEDGER_SHA256 = (
    "ac8bde7ac3ae167fafbe64a3f7051123ca6d9e9b9fffbd2703da1cda6f097797"
)
_V50_INCOMPLETE_FAILURE_CASE_STUDY_SHA256 = (
    "d39fe0749815c2f2d66e9d940aaeb3cea7cc583228611d211f9c3fb3b1e3fd8c"
)
_V50_INCOMPLETE_CACHE_STATE = {
    "file_count": 24,
    "files_sha256": (
        "04e2762dafb832d3c5802905200f708cb474a6b7aaccc9cad9ca5335cf99851c"
    ),
}
_V50_INCOMPLETE_BATCH4_SELECTOR_REQUEST_SHA256 = (
    "7d5032477f023ef9ca204c5dfb31c0b9572e24654a86b94c13cf2fa16f94c886"
)
_V50_INCOMPLETE_INTERRUPTED_CRITIC_REQUEST_SHA256 = (
    "972141b7c631c58e4f683382b8647c9a1da72c284d34b42aefd15d20fe0aa418"
)
_V50_INCOMPLETE_LEDGER_REQUEST_SHA256S = (
    "460c597292c2f9b00aea5f8f1848bce59d141cef51245fa93949cdbe2b9fd203",
    "bc6059b01f2a426a9b0483c45572c04ea9ddeef684bb74f6eb970407b0b115cb",
    "6100661ecd07dacec80b9bc5be6b143a5e446ee9546cfec914508f3fc7a53f4a",
    "124978461b5523c429d702bc99b40dd9a2778db726d1455b58b6403707d69856",
    "8443a176a6556860303f25d85f63c5448f1b29724dde6754ec499179c982e13f",
    _V50_INCOMPLETE_BATCH4_SELECTOR_REQUEST_SHA256,
    _V50_INCOMPLETE_INTERRUPTED_CRITIC_REQUEST_SHA256,
)

_V51_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v51-"
    "whitespace-brace-full30"
)
_V51_REJECTED_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v51-"
    "whitespace-brace-tuning-cache"
)
_V51_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "81e1c34b9b89becd60cb7b9e7d66461f40c19669cfeb09fbe83d1cade2b5b01f"
    ),
    "predict-run.json": (
        "f201ad8694ffcad2e0cbc200877000baef830f1b0fcc26c9f828da670220b86b"
    ),
    "promotion.json": (
        "e7c76220182237295705611c8b2343ce165c88287f5d2b7974e69b31c972ac2f"
    ),
    "metrics.json": (
        "8d3e46f38534e26f93f52f3a98fe9d6a691257ad7f7615af744392cef5a2db8e"
    ),
    "predictions.jsonl": (
        "8c67421938c21ded8ecd7424e7daafcbf0ef2a3ccc1db673ff44c07f8ea1a9f8"
    ),
    "unscored-predictions.jsonl": (
        "8071517dfe7f4adca1a958e8241436953a7db0170634080d677a27d5d01e8d2a"
    ),
    "logical-completion-ledger.json": (
        "7d9f5f6ea82e49cec64f2d6721c2eeca868d1a838af5320700eb9eb6d13d4601"
    ),
    "artifact-manifest.json": (
        "ceae57c3955b5f12ca4823eddadfe5f918a9eb399e7430912183eebc657c8dda"
    ),
}
_V51_REJECTED_PREREGISTRATION_SHA256 = (
    "a362e2e51d5ce6dd4252880187dbe1a9f9bc50cd7cc7dfa477901da55977a433"
)
_V51_REJECTED_PREDICT_RUN_SHA256 = (
    "cdbc27b38e33153c1024bdd62cddcd88da50617c18f31853bbc389008edc96ed"
)
_V51_REJECTED_PROMOTION_SHA256 = (
    "ef85807f10eb7c0313e466a8117fd9559239ecb8d568b622f4ec5231299b93d5"
)
_V51_REJECTED_LEDGER_SHA256 = (
    "d701b7d81a4f048974fbad907ab943186e07e1bc0d331045baf12bea347c60d2"
)
_V51_FAILURE_CASE_STUDY_SHA256 = (
    "9c2456d278ad9347cbe251a95e3e949cf8f9da993a6e7063c2715232bb9f41dc"
)
_V51_REJECTED_CACHE_STATE = {
    "file_count": 66,
    "files_sha256": (
        "efd776605b67f9811e32d863aba34023058b7a7bde20763bb91fec55d991d4e4"
    ),
}

_V52_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v52-"
    "module-census-recovery-v2-full30"
)
_V52_REJECTED_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v52-"
    "module-census-recovery-v2-cache"
)
_V52_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "ac609da8dcdd6500c5acccc795e79b14883c18fb30b9b2e180bb12cbb5ab70c7"
    ),
    "predict-run.json": (
        "f79d8a1505e990eae48f6358a75d9ea07abf1e3a2e95e02a642c5a3d3b46ccf4"
    ),
    "promotion.json": (
        "0dfafc007d8498ab13a15edbf6ca18c5fc6ed8d97454d4c87df7265c89633d4b"
    ),
    "metrics.json": (
        "304655f90fa2937c1c5630b4760d651734f4d954aef1f836337355e537592428"
    ),
    "predictions.jsonl": (
        "ce213c2fff88c608c54490f61499675e20bfd478332c65a9a2389d0da2d27726"
    ),
    "unscored-predictions.jsonl": (
        "0f792e965f2157ed4334129eb823a989e626ca176c129ce1b3d57327823359ae"
    ),
    "logical-completion-ledger.json": (
        "f5d2b7a72f673919aa443d88fc0bae7985fb81c7eb97f2bfd515de11127880cc"
    ),
    "artifact-manifest.json": (
        "1f268c7b5e51ed7499e17ef22ebf3744d04ec783f1879e6c2dccd360bb5e68de"
    ),
}
_V52_REJECTED_PREREGISTRATION_SHA256 = (
    "071272b532efd6fe755f2133e47d0a52963b478123a9648722e58c79b8f74411"
)
_V52_REJECTED_PREDICT_RUN_SHA256 = (
    "802353ca5658c4e74f0350b9e23ee5d5a2ba5508a7b2d709b6226549aac63e6c"
)
_V52_REJECTED_PROMOTION_SHA256 = (
    "a0d2da928235ec3126c33d851f6b6bb013364aa0a68d0438d4d580cac2c43276"
)
_V52_REJECTED_LEDGER_SHA256 = (
    "68dbbd6624ca69e224cbba91299d6327004528ebfeb0467a6f86c3a53a1a7660"
)
_V52_FAILURE_CASE_STUDY_SHA256 = (
    "55948f7f1567713548f12ac9eb20df8c3b01c5cf10602b1643ccd507a156e607"
)
_V52_REJECTED_CACHE_STATE = {
    "file_count": 66,
    "files_sha256": (
        "952867063d9e3f8ffdc55399dbcab4e9b4bb48e53d452c5c127618cfe78848e4"
    ),
}

_V53_REJECTED_RUN_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-tuning-v1-e9-v53-"
    "dual-timescale-dry3"
)
_V53_REJECTED_CACHE_RELATIVE_ROOT = (
    "output/agenterrorbench-deepseek-v4-flash-e9-v53-"
    "dual-timescale-tuning-cache"
)
_V53_REJECTED_FILE_SHA256 = {
    "preregistration.json": (
        "4e762e32375c1d450807d3bc342517c36967e207c3ccd6e9e78c43d06611f73d"
    ),
    "predict-run.json": (
        "9b441508c102a3b42b3af9f70cb10572044507e3bc45886f509d1e64a4a470b8"
    ),
    "promotion.json": (
        "2486fac4910650c486f8e2527814473688ac8848e3832974c9adb1546867de23"
    ),
    "metrics.json": (
        "669189586f7b9594619a7a73b4d8c34296c14833e86f144ea80921fab5c49f37"
    ),
    "predictions.jsonl": (
        "ed6da5fba2381b5cf3818f513cedf7619a1accbcbe3441f298a9a9fa1891ccb3"
    ),
    "unscored-predictions.jsonl": (
        "3eb85d4196128fe20159e87aac027029718385d60e26662aeb523103f948373d"
    ),
    "logical-completion-ledger.json": (
        "d100476ce908b8f260d6201d193e997896600c486863b802bfc8d22d6813f970"
    ),
    "artifact-manifest.json": (
        "16aef70906e0e2d0cd4408b4c9944689d64ec9c5de2f50f6b8711aebcb194c75"
    ),
}
_V53_REJECTED_PREREGISTRATION_SHA256 = (
    "e54fd10cfa7d2cd45626a5e0fb07618968538652739ee3aad21315d099651c82"
)
_V53_REJECTED_PREDICT_RUN_SHA256 = (
    "48d0c11e5d235a577576464a1733efda674440a3c687e633c4997e9d2bbc22d5"
)
_V53_REJECTED_PROMOTION_SHA256 = (
    "e98c937194a85750cb59030b61a8fe817a607ec2bb5b985fc8f2a49a049e0f10"
)
_V53_REJECTED_LEDGER_SHA256 = (
    "4181578300849ccd6ff889681ce03435d91bde4aa42832404cfbe130b205c072"
)
_V53_REJECTED_CACHE_STATE = {
    "file_count": 6,
    "files_sha256": (
        "3731e6f9b19b8995f3da141fb81ce302faefcb5b3b95a09b7417ea09cebd1eec"
    ),
}


class BatchedCriticPreregistrationError(ValueError):
    """A v14 artifact differs from the frozen experiment identity."""


def _workflow() -> Any:
    # Lazy import keeps this module importable while workflow integration is
    # developed, without weakening any runtime validation.
    from . import batched_critic_workflow

    return batched_critic_workflow


def _repository_path(relative_path: str) -> Path:
    return (Path(__file__).resolve().parents[2] / relative_path).resolve()


def _file_sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).expanduser().resolve().open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _read(path: str | Path, *, location: str) -> dict[str, Any]:
    try:
        value = json.loads(
            Path(path).expanduser().resolve().read_text(encoding="utf-8")
        )
    except (OSError, json.JSONDecodeError) as error:
        raise BatchedCriticPreregistrationError(
            f"{location} is missing or corrupt"
        ) from error
    if not isinstance(value, dict):
        raise BatchedCriticPreregistrationError(
            f"{location} must be an object"
        )
    return value


def _read_jsonl(path: str | Path, *, location: str) -> list[dict[str, Any]]:
    resolved = Path(path).expanduser().resolve()
    try:
        lines = resolved.read_text(encoding="utf-8").splitlines()
    except OSError as error:
        raise BatchedCriticPreregistrationError(
            f"{location} is missing"
        ) from error
    if not lines or any(not line.strip() for line in lines):
        raise BatchedCriticPreregistrationError(
            f"{location} must be non-empty strict JSONL"
        )
    rows: list[dict[str, Any]] = []
    for line in lines:
        try:
            value = json.loads(line)
        except json.JSONDecodeError as error:
            raise BatchedCriticPreregistrationError(
                f"{location} contains invalid JSON"
            ) from error
        if not isinstance(value, dict):
            raise BatchedCriticPreregistrationError(
                f"{location} rows must be objects"
            )
        rows.append(value)
    return rows


def _validated_hashed_document(
    path: str | Path,
    *,
    location: str,
    hash_field: str,
) -> dict[str, Any]:
    document = _read(path, location=location)
    body = dict(document)
    claimed = body.pop(hash_field, None)
    if claimed != stable_sha256(body):
        raise BatchedCriticPreregistrationError(
            f"{location} self-hash is invalid"
        )
    return document


def _atomic_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def _exclusive_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError as error:
        raise BatchedCriticPreregistrationError(
            "v14 authorization phase was already claimed"
        ) from error
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def _directory_state(
    root: str | Path,
    *,
    excluded_paths: Sequence[str | Path] = (),
) -> dict[str, Any]:
    resolved_root = Path(root).expanduser().resolve()
    excluded = {
        Path(value).expanduser().resolve() for value in excluded_paths
    }
    files: dict[str, str] = {}
    if resolved_root.is_dir():
        for path in sorted(
            (item for item in resolved_root.rglob("*") if item.is_file()),
            key=lambda item: str(item),
        ):
            resolved = path.resolve()
            if resolved not in excluded:
                files[str(resolved.relative_to(resolved_root))] = (
                    _file_sha256(resolved)
                )
    return {
        "file_count": len(files),
        "files_sha256": stable_sha256(files),
    }


def _paths_are_disjoint(*paths: Path) -> bool:
    resolved = [path.resolve() for path in paths]
    return all(
        left != right
        and not left.is_relative_to(right)
        and not right.is_relative_to(left)
        for index, left in enumerate(resolved)
        for right in resolved[index + 1 :]
    )


def _profile_contract(profile: str) -> dict[str, Any]:
    value = V14_EVALUATION_PROFILES.get(profile)
    if not isinstance(value, Mapping):
        raise BatchedCriticPreregistrationError(
            "v14 evaluation profile is unsupported"
        )
    return dict(value)


def frozen_batched_critic_promotion_gate(
    profile: str,
    *,
    selected_trajectory_ids: Sequence[str],
) -> dict[str, Any]:
    """Return the sole metric and integrity gate for one v14 phase."""

    selected = [str(value) for value in selected_trajectory_ids]
    common = {
        "semantic_mutation_maximum": 0,
        "llm_selector_raw_final_required": True,
        "raw_chain_reconstruction_required": True,
        "gold_isolation_required": True,
    }
    if profile == "dry3":
        if tuple(selected) != V14_DRY3_IDS_MANIFEST_ORDER:
            raise BatchedCriticPreregistrationError(
                "v14 dry3 gate requires the frozen three tuning IDs"
            )
        return {
            "trajectory_denominator": 3,
            "successful_prediction_minimum": 3,
            "failed_prediction_maximum": 0,
            "step_exact_minimum_correct": 3,
            "step_module_exact_minimum_correct": 3,
            "all_correct_minimum": 3,
            "all_correct_report_only": False,
            "heldout_one_shot_required": False,
            **common,
        }
    if profile not in {"full30", "smoke30"} or len(selected) != 30:
        raise BatchedCriticPreregistrationError(
            "formal v14 full/smoke gate requires exactly 30 trajectories"
        )
    if len(set(selected)) != 30:
        raise BatchedCriticPreregistrationError(
            "formal v14 full/smoke gate requires unique trajectories"
        )
    if profile == "full30":
        return {
            "trajectory_denominator": 30,
            "successful_prediction_minimum": 29,
            "failed_prediction_maximum": 1,
            "step_exact_minimum_correct": 12,
            "step_module_exact_minimum_correct": 3,
            "all_correct_minimum": 3,
            "all_correct_report_only": False,
            "heldout_one_shot_required": False,
            **common,
        }
    return {
        "trajectory_denominator": 30,
        "successful_prediction_minimum": 29,
        "failed_prediction_maximum": 1,
        "step_exact_minimum_correct": 12,
        "step_module_exact_minimum_correct": 2,
        # Smoke All Correct is reported but is deliberately not a gate.
        "all_correct_minimum": None,
        "all_correct_report_only": True,
        "heldout_one_shot_required": True,
        **common,
    }


def _expected_budget(profile: str, *, batch_count: int) -> tuple[int, int]:
    expected = {
        "dry3": (1, 642, 2),
        "full30": (11, 644, 20),
        "smoke30": (11, 664, 44),
    }
    if profile not in expected:
        raise BatchedCriticPreregistrationError(
            "v14 formal budget profile is unsupported"
        )
    expected_batches, cumulative_before, maximum_new = expected[profile]
    if batch_count != expected_batches:
        raise BatchedCriticPreregistrationError(
            f"v14 {profile} requires exactly {expected_batches} batches"
        )
    return cumulative_before, maximum_new


def _validate_phase_budget(
    *,
    profile: str,
    batch_count: int,
    cumulative_before: Any,
    maximum_new: Any,
    hard_cumulative_stop: Any,
    authorized_cumulative_ceiling: Any,
    predecessor_cumulative_after: int | None,
) -> None:
    if (
        isinstance(cumulative_before, bool)
        or not isinstance(cumulative_before, int)
        or cumulative_before < 0
        or isinstance(maximum_new, bool)
        or not isinstance(maximum_new, int)
        or maximum_new < 1
        or hard_cumulative_stop != cumulative_before + maximum_new
        or isinstance(authorized_cumulative_ceiling, bool)
        or not isinstance(authorized_cumulative_ceiling, int)
        or authorized_cumulative_ceiling < 0
        or hard_cumulative_stop > authorized_cumulative_ceiling
    ):
        raise BatchedCriticPreregistrationError(
            "v14 logical-completion budget arithmetic is invalid"
        )
    expected_before, expected_maximum = _expected_budget(
        profile,
        batch_count=batch_count,
    )
    expected_predecessor = None if profile == "dry3" else expected_before
    if (
        cumulative_before != expected_before
        or maximum_new != expected_maximum
        or predecessor_cumulative_after != expected_predecessor
    ):
        raise BatchedCriticPreregistrationError(
            "v14 profile-specific exact call budget is invalid"
        )


def _validate_formal_provider_config(
    *,
    profile: str,
    config: BenchmarkRunConfig,
) -> None:
    if profile not in _FORMAL_PROFILES:
        return
    expected = {
        "model": "deepseek-v4-flash",
        "temperature": 0,
        "provider": "openai-compatible",
        "endpoint": "https://api.deepseek.com/v1/chat/completions",
        "timeout": 600,
        "max_output_tokens": 8192,
        "max_retries": 5,
        "retry_backoff": 2,
        "cohort_sha256": _profile_contract(profile)["cohort_sha256"],
        "api_key_env": "DEEPSEEK_API_KEY",
        "request_body_mode": "default",
    }
    if config.public_dict() != expected:
        raise BatchedCriticPreregistrationError(
            "formal v25 provider configuration is not the frozen DeepSeek "
            "V4 Flash default-body identity"
        )


def _load_gold_free_cohort_header(path: Path) -> dict[str, Any]:
    document = _read(path, location="v14 cohort manifest")
    body = dict(document)
    claimed = body.pop("cohort_sha256", None)
    trajectory_ids = document.get("trajectory_ids")
    if (
        claimed != stable_sha256(body)
        or not isinstance(trajectory_ids, list)
        or not trajectory_ids
        or any(not isinstance(value, str) or not value for value in trajectory_ids)
        or len(set(trajectory_ids)) != len(trajectory_ids)
        or not isinstance(document.get("cohort_name"), str)
        or not isinstance(document.get("dataset_manifest_sha256"), str)
    ):
        raise BatchedCriticPreregistrationError(
            "v14 cohort manifest public identity is invalid"
        )
    return document


def _load_batch_plan(path: Path) -> tuple[dict[str, Any], Sequence[Any]]:
    loader = getattr(
        __import__(
            "agentdebug.benchmark.batched_causal_workflow",
            fromlist=["load_batched_causal_batch_plan"],
        ),
        "load_batched_causal_batch_plan",
        None,
    )
    if not callable(loader):
        raise BatchedCriticPreregistrationError(
            "v14 lacks the frozen batch-plan loader"
        )
    try:
        value = loader(path)
    except (OSError, TypeError, ValueError) as error:
        raise BatchedCriticPreregistrationError(
            "v14 batch plan is invalid"
        ) from error
    if isinstance(value, tuple) and len(value) == 2:
        document, batches = value
    else:
        serializer = getattr(value, "to_dict", None)
        document = serializer() if callable(serializer) else None
        batches = getattr(value, "batches", None)
    if not isinstance(document, dict) or not isinstance(batches, Sequence):
        raise BatchedCriticPreregistrationError(
            "v14 batch-plan loader returned an invalid result"
        )
    return document, batches


def _batch_value(batch: Any, *names: str) -> Any:
    for name in names:
        value = getattr(batch, name, None)
        if value is not None:
            return value
        if isinstance(batch, Mapping) and name in batch:
            return batch[name]
    return None


def _batch_trajectory_ids(batch: Any) -> tuple[str, ...]:
    values = _batch_value(batch, "trajectory_ids", "case_trajectory_ids")
    if isinstance(values, (list, tuple)) and values and all(
        isinstance(value, str) and value for value in values
    ):
        return tuple(values)
    raise BatchedCriticPreregistrationError(
        "v14 batch plan lacks trajectory membership"
    )


def _batch_identity(batch: Any) -> str:
    value = _batch_value(batch, "batch_id", "batch_sha256", "batch_input_sha256")
    if not isinstance(value, str) or not value:
        raise BatchedCriticPreregistrationError(
            "v14 batch plan lacks a stable batch identity"
        )
    return value


def _batch_case_keys(batch: Any) -> tuple[str, ...]:
    values = _batch_value(batch, "case_keys")
    if isinstance(values, (list, tuple)) and values and all(
        isinstance(value, str) and value for value in values
    ):
        return tuple(values)
    raise BatchedCriticPreregistrationError(
        "v14 batch plan lacks anonymous case keys"
    )


def _batch_input_sha256s(batch: Any) -> tuple[str, ...]:
    values = _batch_value(batch, "ordered_case_input_sha256s")
    if isinstance(values, (list, tuple)) and values and all(
        isinstance(value, str) and len(value) == 64 for value in values
    ):
        return tuple(values)
    raise BatchedCriticPreregistrationError(
        "v14 batch plan lacks ordered case-input identities"
    )


def _validate_batch_plan_binding(
    *,
    plan: Mapping[str, Any],
    batches: Sequence[Any],
    selected_ids: Sequence[str],
) -> dict[str, Any]:
    if not batches:
        raise BatchedCriticPreregistrationError("v14 batch plan is empty")
    memberships = [_batch_trajectory_ids(batch) for batch in batches]
    flattened = [value for batch in memberships for value in batch]
    selected = [str(value) for value in selected_ids]
    content_hash = plan.get("batch_plan_sha256")
    body = dict(plan)
    body.pop("batch_plan_sha256", None)
    if (
        plan.get("selected_trajectory_ids") != selected
        or len(flattened) != len(selected)
        or len(set(flattened)) != len(flattened)
        or set(flattened) != set(selected)
        or content_hash != stable_sha256(body)
        or len({_batch_identity(batch) for batch in batches}) != len(batches)
        or any(not 1 <= len(batch) <= 3 for batch in memberships)
    ):
        raise BatchedCriticPreregistrationError(
            "v14 batch plan does not partition the selected cases exactly"
        )
    return {
        "batch_count": len(batches),
        "batch_identities": [_batch_identity(batch) for batch in batches],
        "batch_memberships": [list(batch) for batch in memberships],
        "batch_case_keys": [list(_batch_case_keys(batch)) for batch in batches],
        "ordered_case_input_sha256s": [
            list(_batch_input_sha256s(batch)) for batch in batches
        ],
        "execution_trajectory_ids": flattened,
        "required_prefix_batch_plan_sha256": plan.get(
            "required_prefix_batch_plan_sha256"
        ),
        "content_sha256": content_hash,
    }


def _validate_profile_binding(
    *,
    profile: str,
    upstream_mode: str,
    cohort: Mapping[str, Any],
    manifest: Mapping[str, Any],
    manifest_ids: Sequence[str],
    selected_ids: Sequence[str],
    gate: Mapping[str, Any],
    plan_binding: Mapping[str, Any],
) -> dict[str, Any]:
    contract = _profile_contract(profile)
    selected = [str(value) for value in selected_ids]
    ids = [str(value) for value in manifest_ids]
    frozen_gate = frozen_batched_critic_promotion_gate(
        profile,
        selected_trajectory_ids=selected,
    )
    if (
        upstream_mode not in V14_UPSTREAM_MODES
        or upstream_mode != contract["upstream_mode"]
        or cohort.get("cohort_name") != contract["cohort_name"]
        or cohort.get("cohort_sha256") != contract["cohort_sha256"]
        or len(cohort.get("trajectory_ids", [])) != contract["cohort_count"]
        or list(cohort.get("trajectory_ids", [])) != ids
        or manifest.get("cohort_name") != contract["cohort_name"]
        or manifest.get("cohort_sha256") != contract["cohort_sha256"]
        or manifest.get("dataset_manifest_sha256")
        != cohort.get("dataset_manifest_sha256")
        or len(selected) != contract["selection_count"]
        or plan_binding.get("batch_count") != contract["batch_count"]
        or dict(gate) != frozen_gate
    ):
        raise BatchedCriticPreregistrationError(
            "v14 profile/cohort/manifest/mode/plan/gate binding is invalid"
        )
    if profile == "dry3":
        if selected != list(V14_DRY3_IDS_MANIFEST_ORDER):
            raise BatchedCriticPreregistrationError(
                "v14 dry3 requires the frozen three cases"
            )
    elif selected != ids:
        raise BatchedCriticPreregistrationError(
            "v14 full profile requires the complete cohort in manifest order"
        )
    return contract


def _module_source_path(root: Path, module: str) -> str | None:
    if not module.startswith("agentdebug"):
        return None
    relative = Path(*module.split("."))
    module_path = root / relative.with_suffix(".py")
    if module_path.is_file():
        return str(module_path.relative_to(root))
    package_path = root / relative / "__init__.py"
    if package_path.is_file():
        return str(package_path.relative_to(root))
    return None


def _source_module_and_package(relative_path: str) -> tuple[str, str]:
    path = Path(relative_path)
    parts = list(path.with_suffix("").parts)
    if parts[-1] == "__init__":
        parts.pop()
        module = ".".join(parts)
        return module, module
    module = ".".join(parts)
    return module, ".".join(parts[:-1])


def _local_import_paths(root: Path, relative_path: str) -> set[str]:
    path = root / relative_path
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    except (OSError, SyntaxError) as error:
        raise BatchedCriticPreregistrationError(
            f"v14 code bundle source cannot be parsed: {relative_path}"
        ) from error
    _module, package = _source_module_and_package(relative_path)
    dependencies: set[str] = set()

    def add(module_name: str) -> None:
        resolved = _module_source_path(root, module_name)
        if resolved is not None:
            dependencies.add(resolved)

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                add(alias.name)
            continue
        if not isinstance(node, ast.ImportFrom):
            continue
        if node.level:
            base_parts = package.split(".") if package else []
            ascent = node.level - 1
            if ascent > len(base_parts):
                raise BatchedCriticPreregistrationError(
                    f"v14 code bundle has an invalid relative import: {relative_path}"
                )
            if ascent:
                base_parts = base_parts[:-ascent]
            if node.module:
                base_parts.extend(node.module.split("."))
            imported_module = ".".join(base_parts)
        else:
            imported_module = node.module or ""
        if imported_module:
            add(imported_module)
        # ``from . import child`` and package re-exports may load a local
        # submodule rather than an attribute.  Include it whenever it exists.
        for alias in node.names:
            candidate = ".".join(
                value for value in (imported_module, alias.name) if value
            )
            if candidate:
                add(candidate)
    return dependencies


def _validate_code_bundle_import_closure(
    relative_paths: Sequence[str],
) -> tuple[str, ...]:
    root = Path(__file__).resolve().parents[2]
    normalized = tuple(str(value) for value in relative_paths)
    if len(normalized) != len(set(normalized)):
        raise BatchedCriticPreregistrationError(
            "v14 code bundle contains duplicate paths"
        )
    available = set(normalized)
    missing_files = sorted(
        relative for relative in normalized if not (root / relative).is_file()
    )
    if missing_files:
        raise BatchedCriticPreregistrationError(
            "v14 code bundle files are missing: " + ", ".join(missing_files)
        )
    required: set[str] = set()
    for relative in normalized:
        if relative.endswith(".py"):
            required.update(_local_import_paths(root, relative))
    missing_imports = sorted(required - available)
    if missing_imports:
        raise BatchedCriticPreregistrationError(
            "v14 code bundle omits local import closure: "
            + ", ".join(missing_imports)
        )
    return tuple(sorted(required))


def _current_code_bundle() -> dict[str, str]:
    root = Path(__file__).resolve().parents[2]
    _validate_code_bundle_import_closure(_CODE_PATHS)
    bundle: dict[str, str] = {}
    for relative in _CODE_PATHS:
        path = root / relative
        if not path.is_file():
            raise BatchedCriticPreregistrationError(
                f"v14 code bundle file is missing: {relative}"
            )
        bundle[relative] = _file_sha256(path)
    return bundle


def verify_batched_critic_code_bundle_archive(
    archive_path: str | Path,
) -> dict[str, Any]:
    """Verify one exact archive against every currently frozen source byte."""

    path = Path(archive_path).expanduser().resolve()
    expected = _current_code_bundle()
    try:
        with tarfile.open(path, mode="r:gz") as archive:
            members = archive.getmembers()
            names = [member.name for member in members]
            if (
                len(names) != len(set(names))
                or set(names) != set(expected)
                or any(not member.isfile() for member in members)
            ):
                raise BatchedCriticPreregistrationError(
                    "v14 code bundle archive members are invalid"
                )
            actual: dict[str, str] = {}
            for member in members:
                stream = archive.extractfile(member)
                if stream is None:
                    raise BatchedCriticPreregistrationError(
                        "v14 code bundle archive member is unreadable"
                    )
                actual[member.name] = hashlib.sha256(stream.read()).hexdigest()
    except BatchedCriticPreregistrationError:
        raise
    except (OSError, tarfile.TarError) as error:
        raise BatchedCriticPreregistrationError(
            "v14 code bundle archive is missing or corrupt"
        ) from error
    if actual != expected:
        raise BatchedCriticPreregistrationError(
            "v14 code bundle archive bytes differ from frozen sources"
        )
    names = sorted(actual)
    return {
        "schema_version": V14_CODE_BUNDLE_ARCHIVE_SCHEMA_VERSION,
        "path": str(path),
        "file_sha256": _file_sha256(path),
        "member_count": len(actual),
        "member_names_sha256": stable_sha256(names),
        "code_bundle_sha256": stable_sha256(actual),
    }


def write_batched_critic_code_bundle_archive(
    output_path: str | Path,
) -> dict[str, Any]:
    """Write a deterministic, write-once archive before preregistration."""

    destination = Path(output_path).expanduser().resolve()
    if destination.exists():
        raise BatchedCriticPreregistrationError(
            "v14 code bundle archive is write-once"
        )
    root = Path(__file__).resolve().parents[2]
    bundle = _current_code_bundle()
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(
        f"{destination.suffix}.{os.getpid()}.tmp"
    )
    try:
        with temporary.open("xb") as raw_stream:
            with gzip.GzipFile(
                filename="",
                mode="wb",
                fileobj=raw_stream,
                mtime=0,
            ) as compressed:
                with tarfile.open(
                    fileobj=compressed,
                    mode="w",
                    format=tarfile.PAX_FORMAT,
                ) as archive:
                    for relative in _CODE_PATHS:
                        data = (root / relative).read_bytes()
                        if hashlib.sha256(data).hexdigest() != bundle[relative]:
                            raise BatchedCriticPreregistrationError(
                                "v14 source changed while creating code archive"
                            )
                        member = tarfile.TarInfo(name=relative)
                        member.size = len(data)
                        member.mode = 0o644
                        member.mtime = 0
                        member.uid = 0
                        member.gid = 0
                        member.uname = ""
                        member.gname = ""
                        archive.addfile(member, io.BytesIO(data))
        temporary.replace(destination)
    except Exception:
        if temporary.exists():
            temporary.unlink()
        raise
    return verify_batched_critic_code_bundle_archive(destination)


def _workflow_contract() -> dict[str, Any]:
    workflow = _workflow()
    values = {
        "experiment": getattr(workflow, "V14_EXPERIMENT", None),
        "pipeline_version": getattr(workflow, "V14_PIPELINE_VERSION", None),
        "prompt_protocol_version": getattr(
            workflow, "V14_CRITIC_PROMPT_PROTOCOL_VERSION", None
        ),
        "selector_prompt_protocol_version": getattr(
            workflow, "V14_SELECTOR_PROMPT_PROTOCOL_VERSION", None
        ),
        "critic_stage": getattr(workflow, "V14_CRITIC_STAGE", None),
        "selector_stage": getattr(workflow, "V14_SELECTOR_STAGE", None),
        "prediction_schema_version": getattr(
            workflow, "V14_PREDICTION_SCHEMA_VERSION", None
        ),
        "semantic_classifier": getattr(
            workflow, "V14_SEMANTIC_CLASSIFIER", None
        ),
        "implementation_cumulative_ceiling": getattr(
            workflow, "V14_IMPLEMENTATION_CUMULATIVE_CEILING", None
        ),
        "maximum_critic_request_chars": getattr(
            workflow, "V14_MAXIMUM_CRITIC_REQUEST_CHARS", None
        ),
        "maximum_selector_request_chars": getattr(
            workflow, "V14_MAXIMUM_SELECTOR_REQUEST_CHARS", None
        ),
    }
    if (
        not all(
            isinstance(value, str) and value
            for key, value in values.items()
            if key
            not in {
                "implementation_cumulative_ceiling",
                "maximum_critic_request_chars",
                "maximum_selector_request_chars",
            }
        )
        or values["pipeline_version"] != BATCHED_CRITIC_PIPELINE_VERSION
        or values["prompt_protocol_version"]
        != BATCHED_CRITIC_PROMPT_PROTOCOL_VERSION
        or values["critic_stage"] != BATCHED_CRITIC_STAGE
        or values["selector_prompt_protocol_version"]
        != BATCHED_SELECTOR_PROMPT_PROTOCOL_VERSION
        or values["selector_stage"] != BATCHED_SELECTOR_STAGE
        or values["semantic_classifier"] != _V14_SEMANTIC_CLASSIFIER
        or values["implementation_cumulative_ceiling"]
        != V14_IMPLEMENTATION_CUMULATIVE_CEILING
        or values["maximum_critic_request_chars"] != 800_000
        or values["maximum_selector_request_chars"] != 900_000
    ):
        raise BatchedCriticPreregistrationError(
            "v14 workflow implementation contract is incomplete"
        )
    return values


def _resolve_v13_rejected_run_binding() -> dict[str, Any]:
    """Bind the authoritative rejected v13 full30 run and usage at 362."""

    root = _repository_path(_V13_REJECTED_RUN_RELATIVE_ROOT)
    paths = {name: root / name for name in _V13_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V13_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v13 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v13 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v13 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v13 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(paths["metrics.json"], location="rejected v13 metrics")
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v13 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    checks = promotion.get("checks")
    if (
        prereg.get("preregistration_sha256")
        != _V13_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 342
        or budget.get("maximum_new") != 20
        or budget.get("hard_cumulative_stop") != 362
        or run.get("preregistration_sha256")
        != _V13_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 20
        or promotion.get("promotion_sha256")
        != _V13_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or not isinstance(checks, Mapping)
        or checks.get("step_exact_minimum_correct") is not False
        or overall.get("trajectory_count") != 30
        or overall.get("failed_prediction_count") != 1
        or overall.get("step_exact", {}).get("correct") != 6
        or overall.get("step_module_exact", {}).get("correct") != 3
        or overall.get("all_correct", {}).get("correct") != 3
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v13 run is not the authoritative usage/source anchor"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v13_usage_and_semantic_source_anchor",
        "cumulative_before": 342,
        "logical_completions_used": 20,
        "cumulative_after": 362,
        "accepted": False,
        "summary": {
            "trajectory_count": 30,
            "step_correct": 6,
            "step_module_correct": 3,
            "all_correct": 3,
            "failed_prediction_count": 1,
        },
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V13_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V13_REJECTED_PREREGISTRATION_SHA256,
        "promotion_sha256": _V13_REJECTED_PROMOTION_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v13_rejected_run_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v13_rejected_run_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v14 rejected-v13 anchor changed after preregistration"
        )
    return expected


def _resolve_v14_rejected_transport_binding() -> dict[str, Any]:
    """Bind the paid v14 HTTP-402 call that advanced usage to 363."""

    root = _repository_path(_V14_REJECTED_RUN_RELATIVE_ROOT)
    paths = {name: root / name for name in _V14_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V14_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v14 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v14 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v14 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v14 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(paths["metrics.json"], location="rejected v14 metrics")
    ledger = _read(
        paths["logical-completion-ledger.json"],
        location="rejected v14 logical-completion ledger",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v14 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    summary = promotion.get("summary")
    entries = ledger.get("entries")
    if (
        prereg.get("preregistration_sha256")
        != _V14_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 362
        or budget.get("maximum_new") != 1
        or budget.get("hard_cumulative_stop") != 363
        or run.get("predict_run_sha256")
        != _V14_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V14_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 1
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 1
        or telemetry.get("http_attempt_count") != 1
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 0
        or promotion.get("promotion_sha256")
        != _V14_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or not isinstance(summary, Mapping)
        or summary.get("trajectory_count") != 3
        or summary.get("failed_prediction_count") != 3
        or summary.get("logical_completion_budget_used") != 1
        or overall.get("trajectory_count") != 3
        or overall.get("failed_prediction_count") != 3
        or overall.get("step_exact", {}).get("correct") != 0
        or not isinstance(entries, list)
        or len(entries) != 1
        or entries[0].get("ordinal") != 1
        or entries[0].get("stage") != BATCHED_CRITIC_STAGE
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v14 run is not the authoritative transport usage anchor"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v14_transport_usage_anchor",
        "cumulative_before": 362,
        "logical_completions_used": 1,
        "http_attempt_count": 1,
        "provider_usage_response_count": 0,
        "cumulative_after": 363,
        "accepted": False,
        "failure_class": "http_402_transport_failure",
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V14_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V14_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V14_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V14_REJECTED_PROMOTION_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v14_rejected_transport_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v14_rejected_transport_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v15 rejected-v14 transport anchor changed after preregistration"
        )
    return expected


def _resolve_v15_rejected_json_binding() -> dict[str, Any]:
    """Bind the first DeepSeek response and cumulative usage at 364."""

    root = _repository_path(_V15_REJECTED_RUN_RELATIVE_ROOT)
    paths = {name: root / name for name in _V15_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V15_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v15 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v15 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v15 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v15 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(paths["metrics.json"], location="rejected v15 metrics")
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v15 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    summary = promotion.get("summary")
    if (
        prereg.get("preregistration_sha256")
        != _V15_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 363
        or budget.get("maximum_new") != 1
        or budget.get("hard_cumulative_stop") != 364
        or run.get("predict_run_sha256")
        != _V15_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V15_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 1
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 1
        or telemetry.get("http_attempt_count") != 1
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 1
        or promotion.get("promotion_sha256")
        != _V15_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or not isinstance(summary, Mapping)
        or summary.get("trajectory_count") != 3
        or summary.get("failed_prediction_count") != 3
        or summary.get("logical_completion_budget_used") != 1
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 0
        or overall.get("failed_prediction_count") != 3
        or overall.get("failure_code_counts") != {"malformed_json": 3}
        or overall.get("status_counts") != {"invalid_json": 3}
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v15 run is not the authoritative JSON usage anchor"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v15_deepseek_json_usage_anchor",
        "cumulative_before": 363,
        "logical_completions_used": 1,
        "http_attempt_count": 1,
        "provider_usage_response_count": 1,
        "cumulative_after": 364,
        "accepted": False,
        "failure_class": "deepseek_malformed_json",
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V15_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V15_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V15_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V15_REJECTED_PROMOTION_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v15_rejected_json_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v15_rejected_json_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v16 rejected-v15 JSON anchor changed after preregistration"
        )
    return expected


def _resolve_v16_rejected_json_binding() -> dict[str, Any]:
    """Bind the exact DeepSeek retry and cumulative usage at 365."""

    root = _repository_path(_V16_REJECTED_RUN_RELATIVE_ROOT)
    paths = {name: root / name for name in _V16_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V16_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v16 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v16 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v16 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v16 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(paths["metrics.json"], location="rejected v16 metrics")
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v16 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    if (
        prereg.get("preregistration_sha256")
        != _V16_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 364
        or budget.get("maximum_new") != 1
        or budget.get("hard_cumulative_stop") != 365
        or run.get("predict_run_sha256")
        != _V16_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V16_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 1
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 1
        or telemetry.get("http_attempt_count") != 1
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 1
        or promotion.get("promotion_sha256")
        != _V16_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 0
        or overall.get("failure_code_counts") != {"malformed_json": 3}
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v16 run is not the authoritative retry usage anchor"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v16_deepseek_retry_json_usage_anchor",
        "cumulative_before": 364,
        "logical_completions_used": 1,
        "cumulative_after": 365,
        "accepted": False,
        "failure_class": "deepseek_malformed_json_reproduced",
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V16_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V16_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V16_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V16_REJECTED_PROMOTION_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v16_rejected_json_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v16_rejected_json_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v17 rejected-v16 JSON anchor changed after preregistration"
        )
    return expected


def _resolve_v17_rejected_semantic_binding() -> dict[str, Any]:
    """Bind the valid-JSON default-body run and usage at 366."""

    root = _repository_path(_V17_REJECTED_RUN_RELATIVE_ROOT)
    paths = {name: root / name for name in _V17_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V17_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v17 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v17 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v17 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v17 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(paths["metrics.json"], location="rejected v17 metrics")
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v17 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    if (
        prereg.get("preregistration_sha256")
        != _V17_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 365
        or budget.get("maximum_new") != 1
        or budget.get("hard_cumulative_stop") != 366
        or run.get("predict_run_sha256")
        != _V17_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V17_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 1
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 1
        or telemetry.get("http_attempt_count") != 1
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 1
        or promotion.get("promotion_sha256")
        != _V17_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 2
        or overall.get("failed_prediction_count") != 1
        or overall.get("failure_code_counts")
        != {"invalid_evidence_quote": 1}
        or overall.get("step_exact", {}).get("correct") != 0
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v17 run is not the authoritative semantic usage anchor"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v17_default_body_semantic_usage_anchor",
        "cumulative_before": 365,
        "logical_completions_used": 1,
        "cumulative_after": 366,
        "accepted": False,
        "summary": {
            "valid_json": True,
            "successful_prediction_count": 2,
            "failed_prediction_count": 1,
            "step_correct": 0,
        },
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V17_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V17_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V17_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V17_REJECTED_PROMOTION_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v17_rejected_semantic_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v17_rejected_semantic_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v18 rejected-v17 semantic anchor changed after preregistration"
        )
    return expected


def _resolve_v18_rejected_malformed_binding() -> dict[str, Any]:
    """Bind the malformed Flash response and cumulative usage at 367."""

    root = _repository_path(_V18_REJECTED_RUN_RELATIVE_ROOT)
    paths = {name: root / name for name in _V18_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V18_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v18 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v18 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v18 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v18 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(paths["metrics.json"], location="rejected v18 metrics")
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v18 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v18 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    raw_values = {
        row.get("raw_judge_outputs", {}).get(BATCHED_CRITIC_STAGE)
        for row in rows
        if isinstance(row.get("raw_judge_outputs"), Mapping)
    }
    raw = next(iter(raw_values)) if len(raw_values) == 1 else None
    malformed_extra_close = False
    if isinstance(raw, str) and raw.endswith("}}]}"):
        try:
            json.loads(raw)
        except json.JSONDecodeError:
            try:
                repaired = json.loads(raw[:-3] + raw[-2:])
            except json.JSONDecodeError:
                repaired = None
            malformed_extra_close = (
                isinstance(repaired, Mapping)
                and isinstance(repaired.get("cases"), list)
                and len(repaired["cases"]) == 3
            )
    if (
        prereg.get("preregistration_sha256")
        != _V18_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 366
        or budget.get("maximum_new") != 1
        or budget.get("hard_cumulative_stop") != 367
        or run.get("predict_run_sha256")
        != _V18_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V18_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 1
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 1
        or telemetry.get("http_attempt_count") != 1
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 1
        or telemetry.get("finish_reason_counts") != {"stop": 1}
        or promotion.get("promotion_sha256")
        != _V18_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 0
        or overall.get("failed_prediction_count") != 3
        or overall.get("failure_code_counts") != {"malformed_json": 3}
        or overall.get("step_exact", {}).get("correct") != 0
        or len(rows) != 3
        or any(
            row.get("status") != "invalid_json"
            or row.get("failure_code") != "malformed_json"
            for row in rows
        )
        or not malformed_extra_close
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v18 run is not the authoritative malformed usage anchor"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v18_flash_malformed_usage_anchor",
        "cumulative_before": 366,
        "logical_completions_used": 1,
        "cumulative_after": 367,
        "accepted": False,
        "failure_class": "deepseek_flash_extra_closing_brace",
        "summary": {
            "trajectory_count": 3,
            "successful_prediction_count": 0,
            "failed_prediction_count": 3,
            "strict_json": False,
            "single_unmatched_closing_brace": True,
        },
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V18_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V18_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V18_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V18_REJECTED_PROMOTION_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v18_rejected_malformed_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v18_rejected_malformed_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v19 rejected-v18 malformed anchor changed after preregistration"
        )
    return expected


def _resolve_v19_rejected_semantic_binding() -> dict[str, Any]:
    """Bind the valid-JSON but rejected Pro run and usage at 368."""

    root = _repository_path(_V19_REJECTED_RUN_RELATIVE_ROOT)
    paths = {name: root / name for name in _V19_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V19_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v19 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v19 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v19 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v19 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(paths["metrics.json"], location="rejected v19 metrics")
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v19 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v19 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    raw_values = {
        row.get("raw_judge_outputs", {}).get(BATCHED_CRITIC_STAGE)
        for row in rows
        if isinstance(row.get("raw_judge_outputs"), Mapping)
    }
    strict_json = False
    if len(raw_values) == 1:
        raw = next(iter(raw_values))
        if isinstance(raw, str):
            try:
                strict_json = isinstance(json.loads(raw), Mapping)
            except json.JSONDecodeError:
                strict_json = False
    if (
        prereg.get("preregistration_sha256")
        != _V19_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 367
        or budget.get("maximum_new") != 1
        or budget.get("hard_cumulative_stop") != 368
        or run.get("predict_run_sha256")
        != _V19_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V19_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 1
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 1
        or telemetry.get("http_attempt_count") != 1
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 1
        or telemetry.get("finish_reason_counts") != {"stop": 1}
        or promotion.get("promotion_sha256")
        != _V19_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 2
        or overall.get("failed_prediction_count") != 1
        or overall.get("failure_code_counts")
        != {"invalid_evidence_quote": 1}
        or overall.get("step_exact", {}).get("correct") != 1
        or len(rows) != 3
        or not strict_json
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v19 run is not the authoritative semantic usage anchor"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v19_pro_semantic_usage_anchor",
        "cumulative_before": 367,
        "logical_completions_used": 1,
        "cumulative_after": 368,
        "accepted": False,
        "summary": {
            "trajectory_count": 3,
            "successful_prediction_count": 2,
            "failed_prediction_count": 1,
            "strict_json": True,
            "failure_code_counts": {"invalid_evidence_quote": 1},
            "step_correct": 1,
        },
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V19_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V19_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V19_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V19_REJECTED_PROMOTION_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v19_rejected_semantic_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v19_rejected_semantic_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v20 rejected-v19 semantic anchor changed after preregistration"
        )
    return expected


def _resolve_v20_rejected_semantic_binding() -> dict[str, Any]:
    """Bind the rejected minimal-final Pro run and usage at 369."""

    root = _repository_path(_V20_REJECTED_RUN_RELATIVE_ROOT)
    paths = {name: root / name for name in _V20_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V20_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v20 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v20 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v20 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v20 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(paths["metrics.json"], location="rejected v20 metrics")
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v20 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v20 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    if (
        prereg.get("preregistration_sha256")
        != _V20_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 368
        or budget.get("maximum_new") != 1
        or budget.get("hard_cumulative_stop") != 369
        or run.get("predict_run_sha256")
        != _V20_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V20_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 1
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 1
        or telemetry.get("http_attempt_count") != 1
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 1
        or telemetry.get("finish_reason_counts") != {"stop": 1}
        or promotion.get("promotion_sha256")
        != _V20_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 2
        or overall.get("failed_prediction_count") != 1
        or overall.get("failure_code_counts")
        != {"invalid_evidence_quote": 1}
        or overall.get("step_exact", {}).get("correct") != 1
        or len(rows) != 3
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v20 run is not the authoritative semantic usage anchor"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v20_pro_quote_format_usage_anchor",
        "cumulative_before": 368,
        "logical_completions_used": 1,
        "cumulative_after": 369,
        "accepted": False,
        "summary": {
            "trajectory_count": 3,
            "successful_prediction_count": 2,
            "failed_prediction_count": 1,
            "failure_code_counts": {"invalid_evidence_quote": 1},
            "step_correct": 1,
        },
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V20_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V20_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V20_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V20_REJECTED_PROMOTION_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v20_rejected_semantic_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v20_rejected_semantic_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v21 rejected-v20 semantic anchor changed after preregistration"
        )
    return expected


def _resolve_v21_rejected_semantic_binding() -> dict[str, Any]:
    """Bind the format-valid but semantically rejected Flash run at 370."""

    root = _repository_path(_V21_REJECTED_RUN_RELATIVE_ROOT)
    paths = {name: root / name for name in _V21_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V21_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v21 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v21 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v21 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v21 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(paths["metrics.json"], location="rejected v21 metrics")
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v21 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v21 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    audits = [row.get("critic_audit") for row in rows]
    if (
        prereg.get("preregistration_sha256")
        != _V21_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 369
        or budget.get("maximum_new") != 1
        or budget.get("hard_cumulative_stop") != 370
        or run.get("predict_run_sha256")
        != _V21_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V21_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 1
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 1
        or telemetry.get("http_attempt_count") != 1
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 1
        or telemetry.get("finish_reason_counts") != {"stop": 1}
        or promotion.get("promotion_sha256")
        != _V21_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 3
        or overall.get("failed_prediction_count") != 0
        or overall.get("failure_code_counts") != {}
        or overall.get("step_exact", {}).get("correct") != 1
        or len(rows) != 3
        or any(
            not isinstance(audit, Mapping)
            or audit.get("format_repairs") != []
            for audit in audits
        )
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v21 run is not the authoritative semantic usage anchor"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v21_flash_format_valid_semantic_usage_anchor",
        "cumulative_before": 369,
        "logical_completions_used": 1,
        "cumulative_after": 370,
        "accepted": False,
        "summary": {
            "trajectory_count": 3,
            "successful_prediction_count": 3,
            "failed_prediction_count": 0,
            "failure_code_counts": {},
            "format_repair_count": 0,
            "step_correct": 1,
        },
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V21_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V21_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V21_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V21_REJECTED_PROMOTION_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v21_rejected_semantic_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v21_rejected_semantic_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v22 rejected-v21 semantic anchor changed after preregistration"
        )
    return expected


def _resolve_v22_rejected_semantic_binding() -> dict[str, Any]:
    """Bind the over-corrected recovery run and usage at cumulative 371."""

    root = _repository_path(_V22_REJECTED_RUN_RELATIVE_ROOT)
    paths = {name: root / name for name in _V22_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V22_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v22 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v22 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v22 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v22 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(paths["metrics.json"], location="rejected v22 metrics")
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v22 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v22 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    audits = [row.get("critic_audit") for row in rows]
    if (
        prereg.get("preregistration_sha256")
        != _V22_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 370
        or budget.get("maximum_new") != 1
        or budget.get("hard_cumulative_stop") != 371
        or run.get("predict_run_sha256")
        != _V22_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V22_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 1
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 1
        or telemetry.get("http_attempt_count") != 1
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 1
        or telemetry.get("finish_reason_counts") != {"stop": 1}
        or promotion.get("promotion_sha256")
        != _V22_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 3
        or overall.get("failed_prediction_count") != 0
        or overall.get("failure_code_counts") != {}
        or overall.get("step_exact", {}).get("correct") != 1
        or len(rows) != 3
        or any(
            not isinstance(audit, Mapping)
            or audit.get("format_repairs") != []
            for audit in audits
        )
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v22 run is not the authoritative semantic usage anchor"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v22_flash_overcorrected_recovery_usage_anchor",
        "cumulative_before": 370,
        "logical_completions_used": 1,
        "cumulative_after": 371,
        "accepted": False,
        "summary": {
            "trajectory_count": 3,
            "successful_prediction_count": 3,
            "failed_prediction_count": 0,
            "failure_code_counts": {},
            "format_repair_count": 0,
            "step_correct": 1,
        },
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V22_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V22_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V22_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V22_REJECTED_PROMOTION_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v22_rejected_semantic_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v22_rejected_semantic_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v23 rejected-v22 semantic anchor changed after preregistration"
        )
    return expected


def _resolve_v23_rejected_empty_content_binding() -> dict[str, Any]:
    """Bind the default-thinking empty-final-content run at cumulative 372."""

    root = _repository_path(_V23_REJECTED_RUN_RELATIVE_ROOT)
    paths = {name: root / name for name in _V23_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V23_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v23 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v23 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v23 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v23 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(paths["metrics.json"], location="rejected v23 metrics")
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v23 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v23 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    if (
        prereg.get("preregistration_sha256")
        != _V23_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 371
        or budget.get("maximum_new") != 1
        or budget.get("hard_cumulative_stop") != 372
        or run.get("predict_run_sha256")
        != _V23_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V23_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 1
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 1
        or telemetry.get("http_attempt_count") != 1
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 1
        or telemetry.get("provider_usage_token_totals", {}).get(
            "output_tokens"
        ) != 647
        or telemetry.get("finish_reason_counts") != {"stop": 1}
        or promotion.get("promotion_sha256")
        != _V23_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 0
        or overall.get("failed_prediction_count") != 3
        or overall.get("failure_code_counts") != {"empty_response": 3}
        or len(rows) != 3
        or any(
            row.get("status") != "invalid_json"
            or row.get("failure_code") != "empty_response"
            or row.get("raw_judge_outputs", {}).get(BATCHED_CRITIC_STAGE)
            != ""
            for row in rows
        )
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v23 run is not the authoritative empty-content anchor"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v23_flash_empty_final_content_usage_anchor",
        "cumulative_before": 371,
        "logical_completions_used": 1,
        "cumulative_after": 372,
        "accepted": False,
        "summary": {
            "trajectory_count": 3,
            "successful_prediction_count": 0,
            "failed_prediction_count": 3,
            "failure_code_counts": {"empty_response": 3},
            "provider_output_tokens": 647,
            "final_content_empty": True,
        },
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V23_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V23_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V23_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V23_REJECTED_PROMOTION_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v23_rejected_empty_content_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v23_rejected_empty_content_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v24 rejected-v23 empty-content anchor changed after preregistration"
        )
    return expected


def _resolve_v24_rejected_full30_binding() -> dict[str, Any]:
    """Bind the rejected v24 full30 run and its ten paid calls at 383."""

    root = _repository_path(_V24_REJECTED_RUN_RELATIVE_ROOT)
    paths = {name: root / name for name in _V24_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V24_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v24 full30 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v24 full30 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v24 full30 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v24 full30 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(
        paths["metrics.json"], location="rejected v24 full30 metrics"
    )
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v24 full30 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v24 full30 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    status_counts = Counter(row.get("status") for row in rows)
    if (
        prereg.get("preregistration_sha256")
        != _V24_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 373
        or budget.get("maximum_new") != 10
        or budget.get("hard_cumulative_stop") != 383
        or run.get("predict_run_sha256")
        != _V24_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V24_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 10
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 10
        or telemetry.get("http_attempt_count") != 10
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 10
        or promotion.get("promotion_sha256")
        != _V24_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or overall.get("trajectory_count") != 30
        or overall.get("successful_prediction_count") != 20
        or overall.get("failed_prediction_count") != 10
        or overall.get("step_exact", {}).get("correct") != 6
        or status_counts
        != Counter({"success": 20, "invalid_output": 7, "invalid_json": 3})
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v24 full30 run is not the authoritative failure anchor"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v24_flash_full30_usage_and_semantic_anchor",
        "cumulative_before": 373,
        "logical_completions_used": 10,
        "cumulative_after": 383,
        "accepted": False,
        "summary": {
            "trajectory_count": 30,
            "successful_prediction_count": 20,
            "failed_prediction_count": 10,
            "step_correct": 6,
            "status_counts": dict(status_counts),
        },
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V24_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V24_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V24_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V24_REJECTED_PROMOTION_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v24_rejected_full30_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v24_rejected_full30_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v25 rejected-v24 full30 anchor changed after preregistration"
        )
    return expected


def _resolve_v25_rejected_full30_binding() -> dict[str, Any]:
    """Bind the rejected v25 full30 run and its ten paid calls at 394."""

    root = _repository_path(_V25_REJECTED_RUN_RELATIVE_ROOT)
    paths = {name: root / name for name in _V25_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V25_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v25 full30 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v25 full30 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v25 full30 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v25 full30 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(
        paths["metrics.json"], location="rejected v25 full30 metrics"
    )
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v25 full30 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v25 full30 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    status_counts = Counter(row.get("status") for row in rows)
    if (
        prereg.get("preregistration_sha256")
        != _V25_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 384
        or budget.get("maximum_new") != 10
        or budget.get("hard_cumulative_stop") != 394
        or run.get("predict_run_sha256")
        != _V25_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V25_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 10
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 10
        or telemetry.get("http_attempt_count") != 10
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 10
        or promotion.get("promotion_sha256")
        != _V25_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or overall.get("trajectory_count") != 30
        or overall.get("successful_prediction_count") != 28
        or overall.get("failed_prediction_count") != 2
        or overall.get("step_exact", {}).get("correct") != 10
        or status_counts != Counter({"success": 28, "invalid_json": 2})
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v25 full30 run is not the authoritative failure anchor"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v25_flash_full30_usage_and_semantic_anchor",
        "cumulative_before": 384,
        "logical_completions_used": 10,
        "cumulative_after": 394,
        "accepted": False,
        "summary": {
            "trajectory_count": 30,
            "successful_prediction_count": 28,
            "failed_prediction_count": 2,
            "step_correct": 10,
            "status_counts": dict(status_counts),
        },
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V25_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V25_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V25_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V25_REJECTED_PROMOTION_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v25_rejected_full30_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v25_rejected_full30_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v29 rejected-v25 full30 anchor changed after preregistration"
        )
    return expected


def _resolve_v26_rejected_dry3_binding() -> dict[str, Any]:
    """Bind the rejected v26 dry3 run and its one paid call at 395."""

    root = _repository_path(_V26_REJECTED_RUN_RELATIVE_ROOT)
    paths = {name: root / name for name in _V26_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V26_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v26 dry3 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v26 dry3 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v26 dry3 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v26 dry3 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(
        paths["metrics.json"], location="rejected v26 dry3 metrics"
    )
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v26 dry3 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v26 dry3 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    status_counts = Counter(row.get("status") for row in rows)
    if (
        prereg.get("preregistration_sha256")
        != _V26_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 394
        or budget.get("maximum_new") != 1
        or budget.get("hard_cumulative_stop") != 395
        or run.get("predict_run_sha256") != _V26_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V26_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 1
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 1
        or telemetry.get("http_attempt_count") != 1
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 1
        or promotion.get("promotion_sha256")
        != _V26_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 3
        or overall.get("failed_prediction_count") != 0
        or overall.get("step_exact", {}).get("correct") != 1
        or overall.get("step_module_exact", {}).get("correct") != 1
        or overall.get("all_correct", {}).get("correct") != 1
        or status_counts != Counter({"success": 3})
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v26 dry3 run is not the authoritative failure anchor"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v26_flash_dry3_usage_and_semantic_anchor",
        "cumulative_before": 394,
        "logical_completions_used": 1,
        "cumulative_after": 395,
        "accepted": False,
        "summary": {
            "trajectory_count": 3,
            "successful_prediction_count": 3,
            "failed_prediction_count": 0,
            "step_correct": 1,
            "step_module_correct": 1,
            "all_correct": 1,
            "status_counts": dict(status_counts),
        },
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V26_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V26_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V26_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V26_REJECTED_PROMOTION_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v26_rejected_dry3_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v26_rejected_dry3_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v29 rejected-v26 dry3 anchor changed after preregistration"
        )
    return expected


def _resolve_v27_rejected_full30_binding() -> dict[str, Any]:
    """Bind the rejected v27 full30 run and its ten paid calls at 406."""

    root = _repository_path(_V27_REJECTED_RUN_RELATIVE_ROOT)
    paths = {name: root / name for name in _V27_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V27_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v27 full30 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v27 full30 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v27 full30 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v27 full30 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(
        paths["metrics.json"], location="rejected v27 full30 metrics"
    )
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v27 full30 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v27 full30 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    status_counts = Counter(row.get("status") for row in rows)
    if (
        prereg.get("preregistration_sha256")
        != _V27_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 396
        or budget.get("maximum_new") != 10
        or budget.get("hard_cumulative_stop") != 406
        or run.get("predict_run_sha256") != _V27_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V27_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 10
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 10
        or telemetry.get("http_attempt_count") != 10
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 10
        or promotion.get("promotion_sha256")
        != _V27_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or overall.get("trajectory_count") != 30
        or overall.get("successful_prediction_count") != 27
        or overall.get("failed_prediction_count") != 3
        or overall.get("step_exact", {}).get("correct") != 9
        or overall.get("step_module_exact", {}).get("correct") != 3
        or overall.get("all_correct", {}).get("correct") != 3
        or status_counts != Counter({"success": 27, "invalid_json": 3})
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v27 full30 run is not the authoritative failure anchor"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v27_flash_full30_usage_and_semantic_anchor",
        "cumulative_before": 396,
        "logical_completions_used": 10,
        "cumulative_after": 406,
        "accepted": False,
        "summary": {
            "trajectory_count": 30,
            "successful_prediction_count": 27,
            "failed_prediction_count": 3,
            "step_correct": 9,
            "step_module_correct": 3,
            "all_correct": 3,
            "status_counts": dict(status_counts),
        },
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V27_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V27_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V27_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V27_REJECTED_PROMOTION_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v27_rejected_full30_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v27_rejected_full30_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v29 rejected-v27 full30 anchor changed after preregistration"
        )
    return expected


def _resolve_v28_rejected_dry3_binding() -> dict[str, Any]:
    """Bind the rejected v28 dry3 run and its one paid call at 407."""

    root = _repository_path(_V28_REJECTED_RUN_RELATIVE_ROOT)
    paths = {name: root / name for name in _V28_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V28_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v28 dry3 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v28 dry3 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v28 dry3 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v28 dry3 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(
        paths["metrics.json"], location="rejected v28 dry3 metrics"
    )
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v28 dry3 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v28 dry3 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    status_counts = Counter(row.get("status") for row in rows)
    if (
        prereg.get("preregistration_sha256")
        != _V28_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 406
        or budget.get("maximum_new") != 1
        or budget.get("hard_cumulative_stop") != 407
        or run.get("predict_run_sha256") != _V28_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V28_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 1
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 1
        or telemetry.get("http_attempt_count") != 1
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 1
        or promotion.get("promotion_sha256")
        != _V28_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 3
        or overall.get("failed_prediction_count") != 0
        or overall.get("step_exact", {}).get("correct") != 1
        or overall.get("step_module_exact", {}).get("correct") != 1
        or overall.get("all_correct", {}).get("correct") != 1
        or status_counts != Counter({"success": 3})
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v28 dry3 run is not the authoritative failure anchor"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v28_flash_dry3_usage_and_semantic_anchor",
        "cumulative_before": 406,
        "logical_completions_used": 1,
        "cumulative_after": 407,
        "accepted": False,
        "summary": {
            "trajectory_count": 3,
            "successful_prediction_count": 3,
            "failed_prediction_count": 0,
            "step_correct": 1,
            "step_module_correct": 1,
            "all_correct": 1,
            "status_counts": dict(status_counts),
        },
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V28_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V28_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V28_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V28_REJECTED_PROMOTION_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v28_rejected_dry3_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v28_rejected_dry3_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v29 rejected-v28 dry3 anchor changed after preregistration"
        )
    return expected


def _resolve_v29_rejected_full30_binding() -> dict[str, Any]:
    """Bind the rejected v29 full30 run and its ten paid calls at 418."""

    root = _repository_path(_V29_REJECTED_RUN_RELATIVE_ROOT)
    paths = {name: root / name for name in _V29_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V29_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v29 full30 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v29 full30 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v29 full30 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v29 full30 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(
        paths["metrics.json"], location="rejected v29 full30 metrics"
    )
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v29 full30 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v29 full30 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    status_counts = Counter(row.get("status") for row in rows)
    if (
        prereg.get("preregistration_sha256")
        != _V29_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 408
        or budget.get("maximum_new") != 10
        or budget.get("hard_cumulative_stop") != 418
        or run.get("predict_run_sha256") != _V29_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V29_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 10
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 10
        or telemetry.get("http_attempt_count") != 10
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 10
        or promotion.get("promotion_sha256")
        != _V29_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or overall.get("trajectory_count") != 30
        or overall.get("successful_prediction_count") != 29
        or overall.get("failed_prediction_count") != 1
        or overall.get("step_exact", {}).get("correct") != 9
        or overall.get("step_module_exact", {}).get("correct") != 3
        or overall.get("all_correct", {}).get("correct") != 3
        or status_counts != Counter({"success": 29, "invalid_output": 1})
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v29 full30 run is not the authoritative failure anchor"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v29_flash_full30_usage_and_semantic_anchor",
        "cumulative_before": 408,
        "logical_completions_used": 10,
        "cumulative_after": 418,
        "accepted": False,
        "summary": {
            "trajectory_count": 30,
            "successful_prediction_count": 29,
            "failed_prediction_count": 1,
            "step_correct": 9,
            "step_module_correct": 3,
            "all_correct": 3,
            "status_counts": dict(status_counts),
        },
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V29_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V29_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V29_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V29_REJECTED_PROMOTION_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v29_rejected_full30_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v29_rejected_full30_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v30 rejected-v29 full30 anchor changed after preregistration"
        )
    return expected


def _resolve_v30_rejected_full30_binding() -> dict[str, Any]:
    """Bind the rejected v30 full30 run and its ten paid calls at 429."""

    root = _repository_path(_V30_REJECTED_RUN_RELATIVE_ROOT)
    paths = {name: root / name for name in _V30_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V30_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v30 full30 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v30 full30 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v30 full30 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v30 full30 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(
        paths["metrics.json"], location="rejected v30 full30 metrics"
    )
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v30 full30 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v30 full30 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    status_counts = Counter(row.get("status") for row in rows)
    if (
        prereg.get("preregistration_sha256")
        != _V30_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 419
        or budget.get("maximum_new") != 10
        or budget.get("hard_cumulative_stop") != 429
        or run.get("predict_run_sha256") != _V30_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V30_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 10
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 10
        or telemetry.get("http_attempt_count") != 10
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 10
        or promotion.get("promotion_sha256")
        != _V30_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or overall.get("trajectory_count") != 30
        or overall.get("successful_prediction_count") != 29
        or overall.get("failed_prediction_count") != 1
        or overall.get("step_exact", {}).get("correct") != 10
        or overall.get("step_module_exact", {}).get("correct") != 5
        or overall.get("all_correct", {}).get("correct") != 4
        or status_counts != Counter({"success": 29, "invalid_output": 1})
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v30 full30 run is not the authoritative failure anchor"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v30_flash_full30_usage_and_semantic_anchor",
        "cumulative_before": 419,
        "logical_completions_used": 10,
        "cumulative_after": 429,
        "accepted": False,
        "summary": {
            "trajectory_count": 30,
            "successful_prediction_count": 29,
            "failed_prediction_count": 1,
            "step_correct": 10,
            "step_module_correct": 5,
            "all_correct": 4,
            "status_counts": dict(status_counts),
        },
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V30_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V30_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V30_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V30_REJECTED_PROMOTION_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v30_rejected_full30_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v30_rejected_full30_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v31 rejected-v30 full30 anchor changed after preregistration"
        )
    return expected


def _resolve_v31_incomplete_full30_binding() -> dict[str, Any]:
    """Bind v31's paid-but-interrupted full30 attempt at cumulative 440."""

    root = _repository_path(_V31_INCOMPLETE_RUN_RELATIVE_ROOT)
    cache = _repository_path(_V31_INCOMPLETE_CACHE_RELATIVE_ROOT)
    paths = {name: root / name for name in _V31_INCOMPLETE_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V31_INCOMPLETE_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative incomplete v31 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="incomplete v31 full30 preregistration",
        hash_field="preregistration_sha256",
    )
    if prereg.get("preregistration_sha256") != (
        _V31_INCOMPLETE_PREREGISTRATION_SHA256
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v31 preregistration identity changed"
        )
    budget = prereg.get("logical_completion_budget")
    execution = prereg.get("execution")
    batch_plan = prereg.get("batch_plan")
    if (
        not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 430
        or budget.get("maximum_new") != 10
        or budget.get("hard_cumulative_stop") != 440
        or not isinstance(execution, Mapping)
        or execution.get("run_output_dir") != str(root)
        or execution.get("critic_cache_dir") != str(cache)
        or not isinstance(batch_plan, Mapping)
        or batch_plan.get("batch_count") != 11
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v31 preregistration topology is invalid"
        )
    ledger = load_fresh_semantic_completion_ledger(
        paths["logical-completion-ledger.json"],
        preregistration_sha256=_V31_INCOMPLETE_PREREGISTRATION_SHA256,
        cumulative_before=430,
        maximum_new=10,
        authorized_cumulative_ceiling=440,
        allowed_stages=[BATCHED_CRITIC_STAGE],
    )
    if (
        ledger.get("ledger_sha256") != _V31_INCOMPLETE_LEDGER_SHA256
        or len(ledger["entries"]) != 10
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v31 ledger is not the ten-call authority record"
        )
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="incomplete v31 partial predictions",
    )
    memberships = batch_plan.get("batch_memberships")
    identities = batch_plan.get("batch_identities")
    expected_trajectory_ids = (
        [value for batch in memberships[:10] for value in batch]
        if isinstance(memberships, list)
        and len(memberships) == 11
        and all(isinstance(batch, list) for batch in memberships)
        else []
    )
    expected_batch_ids = identities[:10] if isinstance(identities, list) else []
    if (
        len(rows) != 27
        or [row.get("trajectory_id") for row in rows]
        != expected_trajectory_ids
        or sorted({row.get("batch_index") for row in rows})
        != list(range(1, 11))
        or [
            next(
                row.get("batch_id")
                for row in rows
                if row.get("batch_index") == index
            )
            for index in range(1, 11)
        ]
        != expected_batch_ids
        or any(
            row.get("status") != "success"
            or row.get("pipeline_version")
            != (
                "e9-frozen-v13-prior-pairwise-candidate-critic-v31-"
                "deepseek-v4-flash-default"
            )
            or row.get("preregistration_sha256")
            != _V31_INCOMPLETE_PREREGISTRATION_SHA256
            or row.get("unscored_prediction_sha256")
            != stable_sha256(
                {
                    key: value
                    for key, value in row.items()
                    if key != "unscored_prediction_sha256"
                }
            )
            for row in rows
        )
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v31 partial prediction prefix is invalid"
        )
    if _directory_state(cache) != _V31_INCOMPLETE_CACHE_STATE:
        raise BatchedCriticPreregistrationError(
            "incomplete v31 cache bytes changed"
        )
    cache_stage_root = cache / "semantic_stages"
    request_sets = [
        {
            path.stem
            for path in (
                cache_stage_root / kind / BATCHED_CRITIC_STAGE
            ).glob("*.json")
        }
        for kind in ("raw", "response_sidecar", "parsed")
    ]
    row_requests = {
        str(row["stage_identities"][BATCHED_CRITIC_STAGE]["request_sha256"])
        for row in rows
    }
    ledger_requests = [
        str(entry["request_sha256"]) for entry in ledger["entries"]
    ]
    if (
        len(request_sets[0]) != 10
        or not all(values == request_sets[0] for values in request_sets[1:])
        or request_sets[0] != row_requests
        or set(ledger_requests[:9]) != row_requests.intersection(
            ledger_requests
        )
        or ledger_requests[-1] in request_sets[0]
        or len(row_requests - set(ledger_requests)) != 1
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v31 ledger/cache crash-window proof is invalid"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v31_interrupted_full30_usage_anchor",
        "cumulative_before": 430,
        "logical_completions_reserved": 10,
        "persisted_new_responses": 9,
        "cumulative_after": 440,
        "accepted": False,
        "termination": "request_reserved_response_not_persisted",
        "partial_prediction_count": 27,
        "completed_batch_count": 10,
        "missing_request_sha256": ledger_requests[-1],
        "cache_state": dict(_V31_INCOMPLETE_CACHE_STATE),
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V31_INCOMPLETE_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V31_INCOMPLETE_PREREGISTRATION_SHA256,
        "logical_completion_ledger_sha256": _V31_INCOMPLETE_LEDGER_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v31_incomplete_full30_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v31_incomplete_full30_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v32 incomplete-v31 full30 anchor changed after preregistration"
        )
    return expected


def _resolve_v32_rejected_dry3_binding() -> dict[str, Any]:
    """Bind v32's rejected 1/3 dry run and its two paid stage calls."""

    root = _repository_path(_V32_REJECTED_RUN_RELATIVE_ROOT)
    cache = _repository_path(_V32_REJECTED_CACHE_RELATIVE_ROOT)
    paths = {name: root / name for name in _V32_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V32_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v32 dry3 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v32 dry3 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v32 dry3 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v32 dry3 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(
        paths["metrics.json"], location="rejected v32 dry3 metrics"
    )
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v32 dry3 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v32 dry3 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    status_counts = Counter(row.get("status") for row in rows)
    if (
        prereg.get("preregistration_sha256")
        != _V32_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 440
        or budget.get("maximum_new") != 2
        or budget.get("hard_cumulative_stop") != 442
        or run.get("predict_run_sha256") != _V32_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V32_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 2
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 2
        or telemetry.get("http_attempt_count") != 2
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 2
        or promotion.get("promotion_sha256")
        != _V32_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 3
        or overall.get("failed_prediction_count") != 0
        or overall.get("step_exact", {}).get("correct") != 1
        or overall.get("step_module_exact", {}).get("correct") != 1
        or overall.get("all_correct", {}).get("correct") != 1
        or status_counts != Counter({"success": 3})
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v32 dry3 run is not the authoritative failure anchor"
        )
    ledger = load_fresh_semantic_completion_ledger(
        paths["logical-completion-ledger.json"],
        preregistration_sha256=_V32_REJECTED_PREREGISTRATION_SHA256,
        cumulative_before=440,
        maximum_new=2,
        authorized_cumulative_ceiling=442,
        allowed_stages=[BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE],
    )
    if (
        ledger.get("ledger_sha256") != _V32_REJECTED_LEDGER_SHA256
        or [entry.get("stage") for entry in ledger["entries"]]
        != [BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE]
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v32 dry3 ledger is not the two-stage authority record"
        )
    if _directory_state(cache) != _V32_REJECTED_CACHE_STATE:
        raise BatchedCriticPreregistrationError(
            "rejected v32 dry3 cache bytes changed"
        )
    request_by_stage = {
        str(entry["stage"]): str(entry["request_sha256"])
        for entry in ledger["entries"]
    }
    if any(
        row.get("pipeline_version")
        != "e9-independent-candidate-selector-v32-deepseek-v4-flash-default"
        or row.get("unscored_prediction_sha256")
        != stable_sha256(
            {
                key: value
                for key, value in row.items()
                if key != "unscored_prediction_sha256"
            }
        )
        or any(
            row.get("stage_identities", {})
            .get(stage, {})
            .get("request_sha256")
            != request_sha256
            for stage, request_sha256 in request_by_stage.items()
        )
        for row in rows
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v32 dry3 raw-stage lineage is invalid"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v32_flash_dry3_usage_and_semantic_anchor",
        "cumulative_before": 440,
        "logical_completions_used": 2,
        "cumulative_after": 442,
        "accepted": False,
        "summary": {
            "trajectory_count": 3,
            "successful_prediction_count": 3,
            "failed_prediction_count": 0,
            "step_correct": 1,
            "step_module_correct": 1,
            "all_correct": 1,
            "status_counts": dict(status_counts),
        },
        "cache_state": dict(_V32_REJECTED_CACHE_STATE),
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V32_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V32_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V32_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V32_REJECTED_PROMOTION_SHA256,
        "logical_completion_ledger_sha256": _V32_REJECTED_LEDGER_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v32_rejected_dry3_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v32_rejected_dry3_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v33 rejected-v32 dry3 anchor changed after preregistration"
        )
    return expected


def _resolve_v33_rejected_dry3_binding() -> dict[str, Any]:
    """Bind v33's rejected 1/3 dry run and its two paid stage calls."""

    root = _repository_path(_V33_REJECTED_RUN_RELATIVE_ROOT)
    cache = _repository_path(_V33_REJECTED_CACHE_RELATIVE_ROOT)
    paths = {name: root / name for name in _V33_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V33_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v33 dry3 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v33 dry3 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v33 dry3 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v33 dry3 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(
        paths["metrics.json"], location="rejected v33 dry3 metrics"
    )
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v33 dry3 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v33 dry3 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    status_counts = Counter(row.get("status") for row in rows)
    if (
        prereg.get("preregistration_sha256")
        != _V33_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 442
        or budget.get("maximum_new") != 2
        or budget.get("hard_cumulative_stop") != 444
        or run.get("predict_run_sha256") != _V33_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V33_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 2
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 2
        or telemetry.get("http_attempt_count") != 2
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 2
        or promotion.get("promotion_sha256")
        != _V33_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 3
        or overall.get("failed_prediction_count") != 0
        or overall.get("step_exact", {}).get("correct") != 1
        or overall.get("step_module_exact", {}).get("correct") != 1
        or overall.get("all_correct", {}).get("correct") != 1
        or status_counts != Counter({"success": 3})
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v33 dry3 run is not the authoritative failure anchor"
        )
    ledger = load_fresh_semantic_completion_ledger(
        paths["logical-completion-ledger.json"],
        preregistration_sha256=_V33_REJECTED_PREREGISTRATION_SHA256,
        cumulative_before=442,
        maximum_new=2,
        authorized_cumulative_ceiling=444,
        allowed_stages=[BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE],
    )
    if (
        ledger.get("ledger_sha256") != _V33_REJECTED_LEDGER_SHA256
        or [entry.get("stage") for entry in ledger["entries"]]
        != [BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE]
        or _directory_state(cache) != _V33_REJECTED_CACHE_STATE
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v33 dry3 ledger/cache authority record changed"
        )
    request_by_stage = {
        str(entry["stage"]): str(entry["request_sha256"])
        for entry in ledger["entries"]
    }
    if any(
        row.get("pipeline_version")
        != "e9-independent-selector-maturity-calibrated-v33-deepseek-v4-flash-default"
        or row.get("unscored_prediction_sha256")
        != stable_sha256(
            {
                key: value
                for key, value in row.items()
                if key != "unscored_prediction_sha256"
            }
        )
        or any(
            row.get("stage_identities", {})
            .get(stage, {})
            .get("request_sha256")
            != request_sha256
            for stage, request_sha256 in request_by_stage.items()
        )
        for row in rows
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v33 dry3 raw-stage lineage is invalid"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v33_flash_dry3_usage_and_semantic_anchor",
        "cumulative_before": 442,
        "logical_completions_used": 2,
        "cumulative_after": 444,
        "accepted": False,
        "summary": {
            "trajectory_count": 3,
            "successful_prediction_count": 3,
            "failed_prediction_count": 0,
            "step_correct": 1,
            "step_module_correct": 1,
            "all_correct": 1,
            "status_counts": dict(status_counts),
        },
        "cache_state": dict(_V33_REJECTED_CACHE_STATE),
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V33_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V33_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V33_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V33_REJECTED_PROMOTION_SHA256,
        "logical_completion_ledger_sha256": _V33_REJECTED_LEDGER_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v33_rejected_dry3_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v33_rejected_dry3_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v34 rejected-v33 dry3 anchor changed after preregistration"
        )
    return expected


def _resolve_v34_incomplete_full30_binding() -> dict[str, Any]:
    """Bind v34's 18-row failure and interrupted thirteenth reservation."""

    root = _repository_path(_V34_INCOMPLETE_RUN_RELATIVE_ROOT)
    cache = _repository_path(_V34_INCOMPLETE_CACHE_RELATIVE_ROOT)
    paths = {name: root / name for name in _V34_INCOMPLETE_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V34_INCOMPLETE_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative incomplete v34 full30 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="incomplete v34 full30 preregistration",
        hash_field="preregistration_sha256",
    )
    if prereg.get("preregistration_sha256") != (
        _V34_INCOMPLETE_PREREGISTRATION_SHA256
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v34 preregistration identity changed"
        )
    budget = prereg.get("logical_completion_budget")
    execution = prereg.get("execution")
    batch_plan = prereg.get("batch_plan")
    if (
        not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 446
        or budget.get("maximum_new") != 20
        or budget.get("hard_cumulative_stop") != 466
        or not isinstance(execution, Mapping)
        or execution.get("run_output_dir") != str(root)
        or execution.get("critic_cache_dir") != str(cache)
        or not isinstance(batch_plan, Mapping)
        or batch_plan.get("batch_count") != 11
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v34 preregistration topology is invalid"
        )
    ledger = load_fresh_semantic_completion_ledger(
        paths["logical-completion-ledger.json"],
        preregistration_sha256=_V34_INCOMPLETE_PREREGISTRATION_SHA256,
        cumulative_before=446,
        maximum_new=20,
        authorized_cumulative_ceiling=466,
        allowed_stages=[BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE],
    )
    if (
        ledger.get("ledger_sha256") != _V34_INCOMPLETE_LEDGER_SHA256
        or len(ledger["entries"]) != 13
        or ledger["entries"][-1].get("request_sha256")
        != _V34_INCOMPLETE_MISSING_REQUEST_SHA256
        or ledger["entries"][-1].get("stage") != BATCHED_CRITIC_STAGE
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v34 ledger is not the thirteen-reservation record"
        )
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="incomplete v34 partial predictions",
    )
    memberships = batch_plan.get("batch_memberships")
    identities = batch_plan.get("batch_identities")
    expected_trajectory_ids = (
        [value for batch in memberships[:7] for value in batch]
        if isinstance(memberships, list)
        and len(memberships) == 11
        and all(isinstance(batch, list) for batch in memberships)
        else []
    )
    expected_batch_ids = identities[:7] if isinstance(identities, list) else []
    status_counts = Counter(row.get("status") for row in rows)
    invalid_rows = [row for row in rows if row.get("status") != "success"]
    if (
        len(rows) != 18
        or [row.get("trajectory_id") for row in rows]
        != expected_trajectory_ids
        or sorted({row.get("batch_index") for row in rows})
        != list(range(1, 8))
        or [
            next(
                row.get("batch_id")
                for row in rows
                if row.get("batch_index") == index
            )
            for index in range(1, 8)
        ]
        != expected_batch_ids
        or status_counts != Counter({"success": 16, "invalid_json": 2})
        or any(
            row.get("pipeline_version")
            != (
                "e9-independent-selector-capability-epoch-v34-"
                "deepseek-v4-flash-default"
            )
            or row.get("preregistration_sha256")
            != _V34_INCOMPLETE_PREREGISTRATION_SHA256
            or row.get("unscored_prediction_sha256")
            != stable_sha256(
                {
                    key: value
                    for key, value in row.items()
                    if key != "unscored_prediction_sha256"
                }
            )
            for row in rows
        )
        or len(invalid_rows) != 2
        or any(
            row.get("batch_index") != 7
            or row.get("failure_stage") != BATCHED_SELECTOR_STAGE
            or row.get("failure_code") != "malformed_json"
            for row in invalid_rows
        )
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v34 partial prediction prefix is invalid"
        )
    if _directory_state(cache) != _V34_INCOMPLETE_CACHE_STATE:
        raise BatchedCriticPreregistrationError(
            "incomplete v34 cache bytes changed"
        )
    cache_stage_root = cache / "semantic_stages"
    cache_requests: dict[str, set[str]] = {}
    row_requests: dict[str, set[str]] = {}
    ledger_requests: dict[str, set[str]] = {}
    for stage in (BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE):
        request_sets = [
            {
                path.stem
                for path in (cache_stage_root / kind / stage).glob("*.json")
            }
            for kind in ("raw", "response_sidecar", "parsed")
        ]
        if len(request_sets[0]) != 7 or not all(
            values == request_sets[0] for values in request_sets[1:]
        ):
            raise BatchedCriticPreregistrationError(
                "incomplete v34 cache stage triples are invalid"
            )
        cache_requests[stage] = request_sets[0]
        row_requests[stage] = {
            str(row["stage_identities"][stage]["request_sha256"])
            for row in rows
        }
        ledger_requests[stage] = {
            str(entry["request_sha256"])
            for entry in ledger["entries"]
            if entry["stage"] == stage
        }
    missing_request = _V34_INCOMPLETE_MISSING_REQUEST_SHA256
    if (
        any(cache_requests[stage] != row_requests[stage] for stage in cache_requests)
        or len(ledger_requests[BATCHED_CRITIC_STAGE]) != 7
        or len(ledger_requests[BATCHED_SELECTOR_STAGE]) != 6
        or ledger_requests[BATCHED_CRITIC_STAGE] - row_requests[BATCHED_CRITIC_STAGE]
        != {missing_request}
        or len(row_requests[BATCHED_CRITIC_STAGE] - ledger_requests[BATCHED_CRITIC_STAGE])
        != 1
        or len(row_requests[BATCHED_SELECTOR_STAGE] - ledger_requests[BATCHED_SELECTOR_STAGE])
        != 1
        or ledger_requests[BATCHED_SELECTOR_STAGE]
        - row_requests[BATCHED_SELECTOR_STAGE]
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v34 ledger/cache crash-window proof is invalid"
        )
    selector_request = str(
        invalid_rows[0]["stage_identities"][BATCHED_SELECTOR_STAGE][
            "request_sha256"
        ]
    )
    if any(
        row["stage_identities"][BATCHED_SELECTOR_STAGE]["request_sha256"]
        != selector_request
        for row in invalid_rows
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v34 invalid rows do not share one Selector response"
        )
    raw_record = _read(
        cache_stage_root
        / "raw"
        / BATCHED_SELECTOR_STAGE
        / f"{selector_request}.json",
        location="incomplete v34 malformed Selector raw record",
    )
    parsed_record = _read(
        cache_stage_root
        / "parsed"
        / BATCHED_SELECTOR_STAGE
        / f"{selector_request}.json",
        location="incomplete v34 malformed Selector parsed record",
    )
    raw_response = raw_record.get("raw_response")
    try:
        repaired_envelope = (
            json.loads(raw_response + "}")
            if isinstance(raw_response, str) and raw_response.endswith("}]")
            else None
        )
    except json.JSONDecodeError:
        repaired_envelope = None
    if (
        not isinstance(repaired_envelope, dict)
        or set(repaired_envelope) != {"cases"}
        or not isinstance(repaired_envelope["cases"], list)
        or len(repaired_envelope["cases"]) != 2
        or parsed_record.get("status") != "invalid_json"
        or parsed_record.get("failure_stage") != BATCHED_SELECTOR_STAGE
        or parsed_record.get("failure_code") != "malformed_json"
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v34 missing-final-brace proof is invalid"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v34_interrupted_full30_format_and_usage_anchor",
        "cumulative_before": 446,
        "logical_completions_reserved": 13,
        "persisted_new_responses": 12,
        "cumulative_after": 459,
        "accepted": False,
        "termination": "next_request_reserved_then_user_rule_interrupt",
        "partial_prediction_count": 18,
        "completed_batch_count": 7,
        "status_counts": dict(status_counts),
        "format_failure": {
            "stage": BATCHED_SELECTOR_STAGE,
            "request_sha256": selector_request,
            "shape": "single_missing_final_top_level_object_close",
            "affected_prediction_count": 2,
        },
        "missing_request_sha256": missing_request,
        "cache_state": dict(_V34_INCOMPLETE_CACHE_STATE),
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V34_INCOMPLETE_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V34_INCOMPLETE_PREREGISTRATION_SHA256,
        "logical_completion_ledger_sha256": _V34_INCOMPLETE_LEDGER_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v34_incomplete_full30_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v34_incomplete_full30_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v35 incomplete-v34 full30 anchor changed after preregistration"
        )
    return expected


def _resolve_v35_rejected_full30_binding() -> dict[str, Any]:
    """Bind v35's complete 7/30 rejection and twenty paid calls at 481."""

    root = _repository_path(_V35_REJECTED_RUN_RELATIVE_ROOT)
    cache = _repository_path(_V35_REJECTED_CACHE_RELATIVE_ROOT)
    paths = {name: root / name for name in _V35_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V35_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v35 full30 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v35 full30 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v35 full30 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v35 full30 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(
        paths["metrics.json"], location="rejected v35 full30 metrics"
    )
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v35 full30 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v35 full30 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    status_counts = Counter(row.get("status") for row in rows)
    checks = promotion.get("checks")
    if (
        prereg.get("preregistration_sha256")
        != _V35_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 461
        or budget.get("maximum_new") != 20
        or budget.get("hard_cumulative_stop") != 481
        or run.get("predict_run_sha256") != _V35_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V35_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 20
        or run.get("semantic_mutation_count") != 0
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 20
        or telemetry.get("http_attempt_count") != 20
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 20
        or promotion.get("promotion_sha256")
        != _V35_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or not isinstance(checks, Mapping)
        or checks.get("step_exact_minimum_correct") is not False
        or any(
            value is not True
            for key, value in checks.items()
            if key != "step_exact_minimum_correct"
        )
        or overall.get("trajectory_count") != 30
        or overall.get("successful_prediction_count") != 30
        or overall.get("failed_prediction_count") != 0
        or overall.get("step_exact", {}).get("correct") != 7
        or overall.get("step_module_exact", {}).get("correct") != 4
        or overall.get("all_correct", {}).get("correct") != 4
        or status_counts != Counter({"success": 30})
        or any(
            row.get("pipeline_version")
            != (
                "e9-independent-selector-symmetric-brace-v35-"
                "deepseek-v4-flash-default"
            )
            or row.get("preregistration_sha256")
            != _V35_REJECTED_PREREGISTRATION_SHA256
            or row.get("unscored_prediction_sha256")
            != stable_sha256(
                {
                    key: value
                    for key, value in row.items()
                    if key != "unscored_prediction_sha256"
                }
            )
            for row in rows
        )
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v35 full30 run is not the authoritative failure anchor"
        )
    ledger = load_fresh_semantic_completion_ledger(
        paths["logical-completion-ledger.json"],
        preregistration_sha256=_V35_REJECTED_PREREGISTRATION_SHA256,
        cumulative_before=461,
        maximum_new=20,
        authorized_cumulative_ceiling=481,
        allowed_stages=[BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE],
    )
    if (
        ledger.get("ledger_sha256") != _V35_REJECTED_LEDGER_SHA256
        or len(ledger["entries"]) != 20
        or Counter(entry.get("stage") for entry in ledger["entries"])
        != Counter({BATCHED_CRITIC_STAGE: 10, BATCHED_SELECTOR_STAGE: 10})
        or _directory_state(cache) != _V35_REJECTED_CACHE_STATE
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v35 full30 ledger/cache authority record changed"
        )

    repaired_records: list[tuple[str, Mapping[str, Any]]] = []
    parsed_root = cache / "semantic_stages" / "parsed" / BATCHED_SELECTOR_STAGE
    for path in sorted(parsed_root.glob("*.json")):
        record = _read(path, location="rejected v35 parsed Selector record")
        raw_response = record.get("raw_response")
        parsed_output = record.get("parsed_output")
        cases = (
            parsed_output.get("cases")
            if isinstance(parsed_output, Mapping)
            else None
        )
        repairs = (
            [
                item.get("adjudication", {})
                .get("audit", {})
                .get("format_repairs")
                for item in cases
            ]
            if isinstance(cases, list)
            else []
        )
        if any(repairs):
            repaired_records.append((path.stem, record))
    if len(repaired_records) != 1:
        raise BatchedCriticPreregistrationError(
            "rejected v35 symmetric repair audit is not unique"
        )
    repaired_request, repaired_record = repaired_records[0]
    repaired_raw = repaired_record.get("raw_response")
    repaired_cases = repaired_record["parsed_output"]["cases"]
    try:
        json.loads(repaired_raw)
        original_is_strict = True
    except (TypeError, json.JSONDecodeError):
        original_is_strict = False
    try:
        repaired_envelope = (
            json.loads(repaired_raw + "}")
            if isinstance(repaired_raw, str) and repaired_raw.endswith("}]")
            else None
        )
    except json.JSONDecodeError:
        repaired_envelope = None
    expected_repair = ["added_single_missing_final_object_close"]
    if (
        original_is_strict
        or not isinstance(repaired_envelope, dict)
        or set(repaired_envelope) != {"cases"}
        or len(repaired_envelope["cases"]) != 3
        or len(repaired_cases) != 3
        or any(
            item.get("adjudication", {})
            .get("audit", {})
            .get("format_repairs")
            != expected_repair
            for item in repaired_cases
        )
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v35 single-missing-brace proof is invalid"
        )

    binding: dict[str, Any] = {
        "role": "rejected_v35_flash_full30_usage_semantic_and_format_anchor",
        "cumulative_before": 461,
        "logical_completions_used": 20,
        "cumulative_after": 481,
        "accepted": False,
        "summary": {
            "trajectory_count": 30,
            "successful_prediction_count": 30,
            "failed_prediction_count": 0,
            "step_correct": 7,
            "step_module_correct": 4,
            "all_correct": 4,
            "status_counts": dict(status_counts),
        },
        "format_repair": {
            "stage": BATCHED_SELECTOR_STAGE,
            "request_sha256": repaired_request,
            "shape": "single_missing_final_top_level_object_close",
            "affected_prediction_count": 3,
        },
        "cache_state": dict(_V35_REJECTED_CACHE_STATE),
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V35_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V35_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V35_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V35_REJECTED_PROMOTION_SHA256,
        "logical_completion_ledger_sha256": _V35_REJECTED_LEDGER_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v35_rejected_full30_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v35_rejected_full30_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v39 rejected-v35 full30 anchor changed after preregistration"
        )
    return expected


def _resolve_v36_rejected_dry3_binding() -> dict[str, Any]:
    """Bind v36's rejected 1/3 dry run and its two paid stage calls."""

    root = _repository_path(_V36_REJECTED_RUN_RELATIVE_ROOT)
    cache = _repository_path(_V36_REJECTED_CACHE_RELATIVE_ROOT)
    paths = {name: root / name for name in _V36_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V36_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v36 dry3 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v36 dry3 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v36 dry3 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v36 dry3 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(
        paths["metrics.json"], location="rejected v36 dry3 metrics"
    )
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v36 dry3 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v36 dry3 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    checks = promotion.get("checks")
    status_counts = Counter(row.get("status") for row in rows)
    if (
        prereg.get("preregistration_sha256")
        != _V36_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 481
        or budget.get("maximum_new") != 2
        or budget.get("hard_cumulative_stop") != 483
        or run.get("predict_run_sha256") != _V36_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V36_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 2
        or run.get("semantic_mutation_count") != 0
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 2
        or telemetry.get("http_attempt_count") != 2
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 2
        or promotion.get("promotion_sha256")
        != _V36_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or not isinstance(checks, Mapping)
        or checks.get("step_exact_minimum_correct") is not False
        or checks.get("step_module_exact_minimum_correct") is not False
        or checks.get("all_correct_minimum") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 3
        or overall.get("failed_prediction_count") != 0
        or overall.get("step_exact", {}).get("correct") != 1
        or overall.get("step_module_exact", {}).get("correct") != 1
        or overall.get("all_correct", {}).get("correct") != 1
        or status_counts != Counter({"success": 3})
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v36 dry3 run is not the authoritative failure anchor"
        )
    ledger = load_fresh_semantic_completion_ledger(
        paths["logical-completion-ledger.json"],
        preregistration_sha256=_V36_REJECTED_PREREGISTRATION_SHA256,
        cumulative_before=481,
        maximum_new=2,
        authorized_cumulative_ceiling=483,
        allowed_stages=[BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE],
    )
    if (
        ledger.get("ledger_sha256") != _V36_REJECTED_LEDGER_SHA256
        or [entry.get("stage") for entry in ledger["entries"]]
        != [BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE]
        or _directory_state(cache) != _V36_REJECTED_CACHE_STATE
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v36 dry3 ledger/cache authority record changed"
        )
    request_by_stage = {
        str(entry["stage"]): str(entry["request_sha256"])
        for entry in ledger["entries"]
    }
    if any(
        row.get("pipeline_version")
        != (
            "e9-independent-selector-original-causal-contract-v36-"
            "deepseek-v4-flash-default"
        )
        or row.get("preregistration_sha256")
        != _V36_REJECTED_PREREGISTRATION_SHA256
        or row.get("unscored_prediction_sha256")
        != stable_sha256(
            {
                key: value
                for key, value in row.items()
                if key != "unscored_prediction_sha256"
            }
        )
        or any(
            row.get("stage_identities", {})
            .get(stage, {})
            .get("request_sha256")
            != request_sha256
            for stage, request_sha256 in request_by_stage.items()
        )
        for row in rows
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v36 dry3 raw-stage lineage is invalid"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v36_flash_dry3_usage_and_semantic_anchor",
        "cumulative_before": 481,
        "logical_completions_used": 2,
        "cumulative_after": 483,
        "accepted": False,
        "summary": {
            "trajectory_count": 3,
            "successful_prediction_count": 3,
            "failed_prediction_count": 0,
            "step_correct": 1,
            "step_module_correct": 1,
            "all_correct": 1,
            "status_counts": dict(status_counts),
        },
        "cache_state": dict(_V36_REJECTED_CACHE_STATE),
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V36_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V36_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V36_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V36_REJECTED_PROMOTION_SHA256,
        "logical_completion_ledger_sha256": _V36_REJECTED_LEDGER_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v36_rejected_dry3_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v36_rejected_dry3_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v39 rejected-v36 dry3 anchor changed after preregistration"
        )
    return expected


def _resolve_v37_rejected_dry3_binding() -> dict[str, Any]:
    """Bind v37's rejected 0/3 dry run and its two paid stage calls."""

    root = _repository_path(_V37_REJECTED_RUN_RELATIVE_ROOT)
    cache = _repository_path(_V37_REJECTED_CACHE_RELATIVE_ROOT)
    paths = {name: root / name for name in _V37_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V37_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v37 dry3 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v37 dry3 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v37 dry3 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v37 dry3 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(
        paths["metrics.json"], location="rejected v37 dry3 metrics"
    )
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v37 dry3 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v37 dry3 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    checks = promotion.get("checks")
    status_counts = Counter(row.get("status") for row in rows)
    if (
        prereg.get("preregistration_sha256")
        != _V37_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 483
        or budget.get("maximum_new") != 2
        or budget.get("hard_cumulative_stop") != 485
        or run.get("predict_run_sha256") != _V37_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V37_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 2
        or run.get("semantic_mutation_count") != 0
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 2
        or telemetry.get("http_attempt_count") != 2
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 2
        or promotion.get("promotion_sha256")
        != _V37_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or not isinstance(checks, Mapping)
        or checks.get("step_exact_minimum_correct") is not False
        or checks.get("step_module_exact_minimum_correct") is not False
        or checks.get("all_correct_minimum") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 3
        or overall.get("failed_prediction_count") != 0
        or overall.get("step_exact", {}).get("correct") != 0
        or overall.get("step_module_exact", {}).get("correct") != 0
        or overall.get("all_correct", {}).get("correct") != 0
        or status_counts != Counter({"success": 3})
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v37 dry3 run is not the authoritative failure anchor"
        )
    ledger = load_fresh_semantic_completion_ledger(
        paths["logical-completion-ledger.json"],
        preregistration_sha256=_V37_REJECTED_PREREGISTRATION_SHA256,
        cumulative_before=483,
        maximum_new=2,
        authorized_cumulative_ceiling=485,
        allowed_stages=[BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE],
    )
    if (
        ledger.get("ledger_sha256") != _V37_REJECTED_LEDGER_SHA256
        or [entry.get("stage") for entry in ledger["entries"]]
        != [BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE]
        or _directory_state(cache) != _V37_REJECTED_CACHE_STATE
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v37 dry3 ledger/cache authority record changed"
        )
    request_by_stage = {
        str(entry["stage"]): str(entry["request_sha256"])
        for entry in ledger["entries"]
    }
    if any(
        row.get("pipeline_version")
        != (
            "e9-incumbent-preserving-original-causal-contract-v37-"
            "deepseek-v4-flash-default"
        )
        or row.get("preregistration_sha256")
        != _V37_REJECTED_PREREGISTRATION_SHA256
        or row.get("unscored_prediction_sha256")
        != stable_sha256(
            {
                key: value
                for key, value in row.items()
                if key != "unscored_prediction_sha256"
            }
        )
        or any(
            row.get("stage_identities", {})
            .get(stage, {})
            .get("request_sha256")
            != request_sha256
            for stage, request_sha256 in request_by_stage.items()
        )
        for row in rows
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v37 dry3 raw-stage lineage is invalid"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v37_flash_dry3_usage_and_semantic_anchor",
        "cumulative_before": 483,
        "logical_completions_used": 2,
        "cumulative_after": 485,
        "accepted": False,
        "summary": {
            "trajectory_count": 3,
            "successful_prediction_count": 3,
            "failed_prediction_count": 0,
            "step_correct": 0,
            "step_module_correct": 0,
            "all_correct": 0,
            "status_counts": dict(status_counts),
        },
        "cache_state": dict(_V37_REJECTED_CACHE_STATE),
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V37_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V37_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V37_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V37_REJECTED_PROMOTION_SHA256,
        "logical_completion_ledger_sha256": _V37_REJECTED_LEDGER_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v37_rejected_dry3_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v37_rejected_dry3_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v39 rejected-v37 dry3 anchor changed after preregistration"
        )
    return expected


def _resolve_v38_rejected_full30_binding() -> dict[str, Any]:
    """Bind v38's accepted dry plus rejected full run through cumulative 507."""

    root = _repository_path(_V38_REJECTED_RUN_RELATIVE_ROOT)
    cache = _repository_path(_V38_REJECTED_CACHE_RELATIVE_ROOT)
    paths = {name: root / name for name in _V38_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V38_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v38 full30 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v38 full30 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v38 full30 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v38 full30 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(
        paths["metrics.json"], location="rejected v38 full30 metrics"
    )
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v38 full30 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v38 full30 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    phase_predecessor = prereg.get("phase_predecessor")
    telemetry = run.get("provider_telemetry_current_run")
    checks = promotion.get("checks")
    status_counts = Counter(row.get("status") for row in rows)
    if (
        prereg.get("preregistration_sha256")
        != _V38_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 487
        or budget.get("maximum_new") != 20
        or budget.get("hard_cumulative_stop") != 507
        or not isinstance(phase_predecessor, Mapping)
        or phase_predecessor.get("profile") != "dry3"
        or phase_predecessor.get("cumulative_after") != 487
        or run.get("predict_run_sha256") != _V38_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V38_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 20
        or run.get("semantic_mutation_count") != 0
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 20
        or telemetry.get("http_attempt_count") != 20
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 20
        or promotion.get("promotion_sha256")
        != _V38_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or not isinstance(checks, Mapping)
        or checks.get("step_exact_minimum_correct") is not False
        or checks.get("step_module_exact_minimum_correct") is not True
        or checks.get("all_correct_minimum") is not True
        or overall.get("trajectory_count") != 30
        or overall.get("successful_prediction_count") != 30
        or overall.get("failed_prediction_count") != 0
        or overall.get("step_exact", {}).get("correct") != 9
        or overall.get("step_module_exact", {}).get("correct") != 4
        or overall.get("all_correct", {}).get("correct") != 3
        or status_counts != Counter({"success": 30})
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v38 full30 run is not the authoritative failure anchor"
        )
    ledger = load_fresh_semantic_completion_ledger(
        paths["logical-completion-ledger.json"],
        preregistration_sha256=_V38_REJECTED_PREREGISTRATION_SHA256,
        cumulative_before=487,
        maximum_new=20,
        authorized_cumulative_ceiling=507,
        allowed_stages=[BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE],
    )
    expected_stage_order = [
        stage
        for _batch in range(10)
        for stage in (BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE)
    ]
    if (
        ledger.get("ledger_sha256") != _V38_REJECTED_LEDGER_SHA256
        or [entry.get("stage") for entry in ledger["entries"]]
        != expected_stage_order
        or _directory_state(cache) != _V38_REJECTED_CACHE_STATE
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v38 full30 ledger/cache authority record changed"
        )
    if any(
        row.get("pipeline_version")
        != (
            "e9-first-defect-terminal-guard-contract-v38-"
            "deepseek-v4-flash-default"
        )
        or row.get("preregistration_sha256")
        != _V38_REJECTED_PREREGISTRATION_SHA256
        or row.get("unscored_prediction_sha256")
        != stable_sha256(
            {
                key: value
                for key, value in row.items()
                if key != "unscored_prediction_sha256"
            }
        )
        for row in rows
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v38 full30 raw-stage lineage is invalid"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v38_flash_full30_usage_and_semantic_anchor",
        "cumulative_before": 485,
        "dry3_logical_completions_used": 2,
        "full30_logical_completions_used": 20,
        "cumulative_after": 507,
        "accepted": False,
        "summary": {
            "trajectory_count": 30,
            "successful_prediction_count": 30,
            "failed_prediction_count": 0,
            "step_correct": 9,
            "step_module_correct": 4,
            "all_correct": 3,
            "status_counts": dict(status_counts),
        },
        "cache_state": dict(_V38_REJECTED_CACHE_STATE),
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V38_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V38_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V38_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V38_REJECTED_PROMOTION_SHA256,
        "logical_completion_ledger_sha256": _V38_REJECTED_LEDGER_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v38_rejected_full30_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v38_rejected_full30_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v39 rejected-v38 full30 anchor changed after preregistration"
        )
    return expected


def _resolve_v39_rejected_dry3_binding() -> dict[str, Any]:
    """Bind v39's rejected 1/3 dry run and its proven length-boundary loss."""

    root = _repository_path(_V39_REJECTED_RUN_RELATIVE_ROOT)
    cache = _repository_path(_V39_REJECTED_CACHE_RELATIVE_ROOT)
    paths = {name: root / name for name in _V39_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V39_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v39 dry3 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v39 dry3 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v39 dry3 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v39 dry3 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(paths["metrics.json"], location="rejected v39 dry3 metrics")
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v39 dry3 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v39 dry3 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    checks = promotion.get("checks")
    status_counts = Counter(row.get("status") for row in rows)
    if (
        prereg.get("preregistration_sha256")
        != _V39_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 507
        or budget.get("maximum_new") != 2
        or budget.get("hard_cumulative_stop") != 509
        or run.get("predict_run_sha256") != _V39_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V39_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 2
        or run.get("semantic_mutation_count") != 0
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 2
        or telemetry.get("http_attempt_count") != 2
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 2
        or promotion.get("promotion_sha256")
        != _V39_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or not isinstance(checks, Mapping)
        or checks.get("successful_prediction_minimum") is not False
        or checks.get("failed_prediction_maximum") is not False
        or checks.get("step_exact_minimum_correct") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 2
        or overall.get("failed_prediction_count") != 1
        or overall.get("step_exact", {}).get("correct") != 1
        or overall.get("step_module_exact", {}).get("correct") != 1
        or overall.get("all_correct", {}).get("correct") != 1
        or status_counts != Counter({"success": 2, "invalid_output": 1})
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v39 dry3 run is not the authoritative failure anchor"
        )
    failed = [row for row in rows if row.get("status") != "success"]
    if (
        len(failed) != 1
        or failed[0].get("failure_stage") != BATCHED_SELECTOR_STAGE
        or failed[0].get("failure_code") != "invalid_text"
        or "causal_basis must be non-empty text" not in str(
            failed[0].get("failure_message")
        )
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v39 dry3 length-boundary failure changed"
        )
    raw_selector = rows[0].get("raw_judge_outputs", {}).get(
        BATCHED_SELECTOR_STAGE
    )
    try:
        selector_cases = json.loads(raw_selector)["cases"]
        failed_raw = selector_cases[1]
    except (KeyError, TypeError, ValueError, IndexError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v39 dry3 raw Selector response is invalid"
        ) from error
    if (
        failed_raw.get("case_key") != "C02"
        or len(failed_raw.get("causal_basis", "")) != 1027
        or failed_raw.get("critical_step") != 1
        or failed_raw.get("taxonomy_pair") != "action/misalignment"
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v39 dry3 counterfactual exact tuple changed"
        )
    ledger = load_fresh_semantic_completion_ledger(
        paths["logical-completion-ledger.json"],
        preregistration_sha256=_V39_REJECTED_PREREGISTRATION_SHA256,
        cumulative_before=507,
        maximum_new=2,
        authorized_cumulative_ceiling=509,
        allowed_stages=[BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE],
    )
    if (
        ledger.get("ledger_sha256") != _V39_REJECTED_LEDGER_SHA256
        or [entry.get("stage") for entry in ledger["entries"]]
        != [BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE]
        or _directory_state(cache) != _V39_REJECTED_CACHE_STATE
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v39 dry3 ledger/cache authority record changed"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v39_flash_dry3_length_and_semantic_anchor",
        "cumulative_before": 507,
        "logical_completions_used": 2,
        "cumulative_after": 509,
        "accepted": False,
        "summary": {
            "trajectory_count": 3,
            "successful_prediction_count": 2,
            "failed_prediction_count": 1,
            "step_correct": 1,
            "step_module_correct": 1,
            "all_correct": 1,
            "status_counts": dict(status_counts),
        },
        "format_failure": {
            "stage": BATCHED_SELECTOR_STAGE,
            "case_key": "C02",
            "field": "causal_basis",
            "observed_chars": 1027,
            "frozen_maximum_chars": 1024,
            "raw_counterfactual_tuple": "1/action/misalignment",
        },
        "cache_state": dict(_V39_REJECTED_CACHE_STATE),
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V39_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V39_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V39_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V39_REJECTED_PROMOTION_SHA256,
        "logical_completion_ledger_sha256": _V39_REJECTED_LEDGER_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v39_rejected_dry3_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v39_rejected_dry3_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v40 rejected-v39 dry3 anchor changed after preregistration"
        )
    return expected


def _resolve_v40_rejected_full30_binding() -> dict[str, Any]:
    """Bind v40's accepted dry plus rejected full run through cumulative 531."""

    root = _repository_path(_V40_REJECTED_RUN_RELATIVE_ROOT)
    cache = _repository_path(_V40_REJECTED_CACHE_RELATIVE_ROOT)
    paths = {name: root / name for name in _V40_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V40_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v40 full30 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v40 full30 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v40 full30 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v40 full30 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(paths["metrics.json"], location="rejected v40 metrics")
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"], location="rejected v40 predictions"
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v40 full30 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    predecessor = prereg.get("phase_predecessor")
    telemetry = run.get("provider_telemetry_current_run")
    checks = promotion.get("checks")
    status_counts = Counter(row.get("status") for row in rows)
    if (
        prereg.get("preregistration_sha256")
        != _V40_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 511
        or budget.get("maximum_new") != 20
        or budget.get("hard_cumulative_stop") != 531
        or not isinstance(predecessor, Mapping)
        or predecessor.get("profile") != "dry3"
        or predecessor.get("cumulative_after") != 511
        or run.get("predict_run_sha256") != _V40_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V40_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 20
        or run.get("semantic_mutation_count") != 0
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 20
        or telemetry.get("http_attempt_count") != 20
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 20
        or promotion.get("promotion_sha256") != _V40_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or not isinstance(checks, Mapping)
        or checks.get("step_exact_minimum_correct") is not False
        or checks.get("step_module_exact_minimum_correct") is not True
        or checks.get("all_correct_minimum") is not True
        or checks.get("failed_prediction_maximum") is not True
        or overall.get("trajectory_count") != 30
        or overall.get("successful_prediction_count") != 29
        or overall.get("failed_prediction_count") != 1
        or overall.get("step_exact", {}).get("correct") != 9
        or overall.get("step_module_exact", {}).get("correct") != 4
        or overall.get("all_correct", {}).get("correct") != 4
        or status_counts != Counter({"success": 29, "invalid_output": 1})
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v40 full30 run is not the authoritative failure anchor"
        )
    invalid = [row for row in rows if row.get("status") != "success"]
    raw_selector = invalid[0].get("raw_judge_outputs", {}).get(
        BATCHED_SELECTOR_STAGE
    ) if len(invalid) == 1 else None
    try:
        raw_case = json.loads(raw_selector)["cases"][2]
    except (KeyError, TypeError, ValueError, IndexError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v40 length-boundary response is invalid"
        ) from error
    if (
        invalid[0].get("failure_code") != "invalid_text"
        or len(raw_case.get("causal_basis", "")) != 1307
        or raw_case.get("critical_step") != 4
        or raw_case.get("taxonomy_pair") != "action/format_error"
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v40 length-boundary failure changed"
        )
    ledger = load_fresh_semantic_completion_ledger(
        paths["logical-completion-ledger.json"],
        preregistration_sha256=_V40_REJECTED_PREREGISTRATION_SHA256,
        cumulative_before=511,
        maximum_new=20,
        authorized_cumulative_ceiling=531,
        allowed_stages=[BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE],
    )
    expected_order = [
        stage for _batch in range(10)
        for stage in (BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE)
    ]
    if (
        ledger.get("ledger_sha256") != _V40_REJECTED_LEDGER_SHA256
        or [entry.get("stage") for entry in ledger["entries"]] != expected_order
        or _directory_state(cache) != _V40_REJECTED_CACHE_STATE
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v40 ledger/cache authority record changed"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v40_flash_full30_usage_semantic_and_length_anchor",
        "cumulative_before": 509,
        "dry3_logical_completions_used": 2,
        "full30_logical_completions_used": 20,
        "cumulative_after": 531,
        "accepted": False,
        "summary": {
            "trajectory_count": 30,
            "successful_prediction_count": 29,
            "failed_prediction_count": 1,
            "step_correct": 9,
            "step_module_correct": 4,
            "all_correct": 4,
            "status_counts": dict(status_counts),
        },
        "format_failure": {
            "stage": BATCHED_SELECTOR_STAGE,
            "field": "causal_basis",
            "observed_chars": 1307,
            "frozen_maximum_chars": 1280,
            "raw_counterfactual_tuple": "4/action/format_error",
        },
        "cache_state": dict(_V40_REJECTED_CACHE_STATE),
        "artifacts": {
            name: {"path": str(path), "file_sha256": _V40_REJECTED_FILE_SHA256[name]}
            for name, path in paths.items()
        },
        "preregistration_sha256": _V40_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V40_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V40_REJECTED_PROMOTION_SHA256,
        "logical_completion_ledger_sha256": _V40_REJECTED_LEDGER_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v40_rejected_full30_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v40_rejected_full30_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v41 rejected-v40 full30 anchor changed after preregistration"
        )
    return expected


def _resolve_v41_rejected_dry3_binding() -> dict[str, Any]:
    """Bind v41's rejected chronological/selection dry run through 533."""

    root = _repository_path(_V41_REJECTED_RUN_RELATIVE_ROOT)
    cache = _repository_path(_V41_REJECTED_CACHE_RELATIVE_ROOT)
    paths = {name: root / name for name in _V41_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V41_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v41 dry3 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v41 dry3 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v41 dry3 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v41 dry3 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(paths["metrics.json"], location="rejected v41 metrics")
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"], location="rejected v41 predictions"
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v41 dry3 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    checks = promotion.get("checks")
    status_counts = Counter(row.get("status") for row in rows)
    predicted = [
        (
            row.get("predicted_step"),
            row.get("predicted_module"),
            row.get("predicted_error_type"),
        )
        for row in rows
    ]
    prior_steps = [
        row.get("predecessor_bundle", {})
        .get("prior_root", {})
        .get("critical_step")
        for row in rows
    ]
    if (
        prereg.get("preregistration_sha256")
        != _V41_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 531
        or budget.get("maximum_new") != 2
        or budget.get("hard_cumulative_stop") != 533
        or run.get("predict_run_sha256") != _V41_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V41_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 2
        or run.get("semantic_mutation_count") != 0
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 2
        or telemetry.get("http_attempt_count") != 2
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 2
        or promotion.get("promotion_sha256") != _V41_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or not isinstance(checks, Mapping)
        or checks.get("step_exact_minimum_correct") is not False
        or checks.get("step_module_exact_minimum_correct") is not False
        or checks.get("all_correct_minimum") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 3
        or overall.get("failed_prediction_count") != 0
        or overall.get("step_exact", {}).get("correct") != 1
        or overall.get("step_module_exact", {}).get("correct") != 1
        or overall.get("all_correct", {}).get("correct") != 1
        or status_counts != Counter({"success": 3})
        or predicted
        != [
            (30, "system", "step_limit"),
            (4, "planning", "constraint_ignorance"),
            (8, "planning", "inefficient_plan"),
        ]
        or prior_steps != [30, 1, 1]
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v41 dry3 run is not the authoritative failure anchor"
        )
    try:
        raw_census = json.loads(
            rows[0]["raw_judge_outputs"][BATCHED_CRITIC_STAGE]
        )["cases"]
        raw_selector = json.loads(
            rows[0]["raw_judge_outputs"][BATCHED_SELECTOR_STAGE]
        )["cases"]
    except (KeyError, TypeError, ValueError, IndexError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v41 dry3 raw semantic chain is invalid"
        ) from error
    c03_planning = raw_census[2]["module_reviews"][2]["hypothesis"]
    if (
        c03_planning.get("critical_step") != 22
        or c03_planning.get("taxonomy_pair") != "planning/inefficient_plan"
        or raw_selector[1].get("critical_step") != 4
        or raw_selector[1].get("taxonomy_pair")
        != "planning/constraint_ignorance"
        or raw_selector[2].get("critical_step") != 8
        or raw_selector[2].get("taxonomy_pair")
        != "planning/inefficient_plan"
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v41 semantic failure details changed"
        )
    ledger = load_fresh_semantic_completion_ledger(
        paths["logical-completion-ledger.json"],
        preregistration_sha256=_V41_REJECTED_PREREGISTRATION_SHA256,
        cumulative_before=531,
        maximum_new=2,
        authorized_cumulative_ceiling=533,
        allowed_stages=[BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE],
    )
    if (
        ledger.get("ledger_sha256") != _V41_REJECTED_LEDGER_SHA256
        or [entry.get("stage") for entry in ledger["entries"]]
        != [BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE]
        or _directory_state(cache) != _V41_REJECTED_CACHE_STATE
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v41 ledger/cache authority record changed"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v41_flash_dry3_chronology_and_selection_anchor",
        "cumulative_before": 531,
        "logical_completions_used": 2,
        "cumulative_after": 533,
        "accepted": False,
        "summary": {
            "trajectory_count": 3,
            "successful_prediction_count": 3,
            "failed_prediction_count": 0,
            "step_correct": 1,
            "step_module_correct": 1,
            "all_correct": 1,
            "status_counts": dict(status_counts),
        },
        "semantic_failure": {
            "correct_hypothesis_available_cases": 2,
            "correct_final_cases": 1,
            "c02_recalled_then_rejected": "1/action/misalignment",
            "c03_census_hypothesis": "22/planning/inefficient_plan",
            "c03_raw_final": "8/planning/inefficient_plan",
        },
        "cache_state": dict(_V41_REJECTED_CACHE_STATE),
        "artifacts": {
            name: {"path": str(path), "file_sha256": _V41_REJECTED_FILE_SHA256[name]}
            for name, path in paths.items()
        },
        "preregistration_sha256": _V41_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V41_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V41_REJECTED_PROMOTION_SHA256,
        "logical_completion_ledger_sha256": _V41_REJECTED_LEDGER_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v41_rejected_dry3_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v41_rejected_dry3_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v42 rejected-v41 dry3 anchor changed after preregistration"
        )
    return expected


def _resolve_v42_rejected_dry3_binding() -> dict[str, Any]:
    """Bind v42's rejected chronological module-census dry run through 535."""

    root = _repository_path(_V42_REJECTED_RUN_RELATIVE_ROOT)
    cache = _repository_path(_V42_REJECTED_CACHE_RELATIVE_ROOT)
    paths = {name: root / name for name in _V42_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V42_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v42 dry3 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v42 dry3 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v42 dry3 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v42 dry3 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(paths["metrics.json"], location="rejected v42 metrics")
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"], location="rejected v42 predictions"
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v42 dry3 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    checks = promotion.get("checks")
    status_counts = Counter(row.get("status") for row in rows)
    predicted = [
        (
            row.get("predicted_step"),
            row.get("predicted_module"),
            row.get("predicted_error_type"),
        )
        for row in rows
    ]
    prior_steps = [
        row.get("predecessor_bundle", {})
        .get("prior_root", {})
        .get("critical_step")
        for row in rows
    ]
    if (
        prereg.get("preregistration_sha256")
        != _V42_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 533
        or budget.get("maximum_new") != 2
        or budget.get("hard_cumulative_stop") != 535
        or run.get("predict_run_sha256") != _V42_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V42_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 2
        or run.get("semantic_mutation_count") != 0
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 2
        or telemetry.get("http_attempt_count") != 2
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 2
        or telemetry.get("provider_usage_token_totals")
        != {"input_tokens": 380915, "output_tokens": 23264, "total_tokens": 404179}
        or promotion.get("promotion_sha256") != _V42_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or not isinstance(checks, Mapping)
        or checks.get("step_exact_minimum_correct") is not False
        or checks.get("step_module_exact_minimum_correct") is not False
        or checks.get("all_correct_minimum") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 3
        or overall.get("failed_prediction_count") != 0
        or overall.get("step_exact", {}).get("correct") != 0
        or overall.get("step_module_exact", {}).get("correct") != 0
        or overall.get("all_correct", {}).get("correct") != 0
        or status_counts != Counter({"success": 3})
        or predicted
        != [
            (16, "planning", "inefficient_plan"),
            (3, "planning", "constraint_ignorance"),
            (6, "planning", "inefficient_plan"),
        ]
        or prior_steps != [30, 1, 1]
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v42 dry3 run is not the authoritative failure anchor"
        )
    try:
        raw_census = json.loads(
            rows[0]["raw_judge_outputs"][BATCHED_CRITIC_STAGE]
        )["cases"]
        raw_selector = json.loads(
            rows[0]["raw_judge_outputs"][BATCHED_SELECTOR_STAGE]
        )["cases"]
        candidate_tuples = [
            [
                None
                if review["hypothesis"] is None
                else (
                    review["hypothesis"]["critical_step"],
                    review["hypothesis"]["taxonomy_pair"],
                )
                for review in case["module_reviews"]
                if review["hypothesis"] is not None
            ]
            for case in raw_census
        ]
        selector_tuples = [
            (case["critical_step"], case["taxonomy_pair"])
            for case in raw_selector
        ]
    except (KeyError, TypeError, ValueError, IndexError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v42 dry3 raw semantic chain is invalid"
        ) from error
    if (
        candidate_tuples
        != [
            [(9, "memory/hallucination"), (16, "planning/inefficient_plan")],
            [(4, "memory/over_simplification"), (3, "planning/constraint_ignorance")],
            [(6, "planning/inefficient_plan")],
        ]
        or selector_tuples
        != [
            (16, "planning/inefficient_plan"),
            (3, "planning/constraint_ignorance"),
            (6, "planning/inefficient_plan"),
        ]
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v42 semantic failure details changed"
        )
    ledger = load_fresh_semantic_completion_ledger(
        paths["logical-completion-ledger.json"],
        preregistration_sha256=_V42_REJECTED_PREREGISTRATION_SHA256,
        cumulative_before=533,
        maximum_new=2,
        authorized_cumulative_ceiling=535,
        allowed_stages=[BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE],
    )
    if (
        ledger.get("ledger_sha256") != _V42_REJECTED_LEDGER_SHA256
        or [entry.get("stage") for entry in ledger["entries"]]
        != [BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE]
        or _directory_state(cache) != _V42_REJECTED_CACHE_STATE
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v42 ledger/cache authority record changed"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v42_flash_dry3_chronological_compression_anchor",
        "cumulative_before": 533,
        "logical_completions_used": 2,
        "cumulative_after": 535,
        "accepted": False,
        "summary": {
            "trajectory_count": 3,
            "successful_prediction_count": 3,
            "failed_prediction_count": 0,
            "step_correct": 0,
            "step_module_correct": 0,
            "all_correct": 0,
            "status_counts": dict(status_counts),
        },
        "semantic_failure": {
            "correct_final_cases": 0,
            "c01_incumbent_then_rejected": "30/system/step_limit",
            "c02_incumbent_then_rejected": "1/action/misalignment",
            "c03_incumbent_then_rejected": "1/action/misalignment",
            "selected_tuples": [
                "16/planning/inefficient_plan",
                "3/planning/constraint_ignorance",
                "6/planning/inefficient_plan",
            ],
        },
        "provider_usage_token_totals": dict(
            telemetry["provider_usage_token_totals"]
        ),
        "cache_state": dict(_V42_REJECTED_CACHE_STATE),
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V42_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V42_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V42_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V42_REJECTED_PROMOTION_SHA256,
        "logical_completion_ledger_sha256": _V42_REJECTED_LEDGER_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v42_rejected_dry3_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v42_rejected_dry3_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v43 rejected-v42 dry3 anchor changed after preregistration"
        )
    return expected


def _resolve_v43_rejected_dry3_binding() -> dict[str, Any]:
    """Bind v43's rejected symmetric causal-lanes dry run through 537."""

    root = _repository_path(_V43_REJECTED_RUN_RELATIVE_ROOT)
    cache = _repository_path(_V43_REJECTED_CACHE_RELATIVE_ROOT)
    paths = {name: root / name for name in _V43_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V43_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v43 dry3 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v43 dry3 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v43 dry3 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v43 dry3 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(paths["metrics.json"], location="rejected v43 metrics")
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"], location="rejected v43 predictions"
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v43 dry3 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    checks = promotion.get("checks")
    status_counts = Counter(row.get("status") for row in rows)
    predicted = [
        (
            row.get("predicted_step"),
            row.get("predicted_module"),
            row.get("predicted_error_type"),
        )
        for row in rows
    ]
    prior_steps = [
        row.get("predecessor_bundle", {})
        .get("prior_root", {})
        .get("critical_step")
        for row in rows
    ]
    if (
        prereg.get("preregistration_sha256")
        != _V43_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 535
        or budget.get("maximum_new") != 2
        or budget.get("hard_cumulative_stop") != 537
        or run.get("predict_run_sha256") != _V43_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V43_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 2
        or run.get("semantic_mutation_count") != 0
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 2
        or telemetry.get("http_attempt_count") != 2
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 2
        or telemetry.get("provider_usage_token_totals")
        != {"input_tokens": 381043, "output_tokens": 30328, "total_tokens": 411371}
        or promotion.get("promotion_sha256") != _V43_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or not isinstance(checks, Mapping)
        or checks.get("step_exact_minimum_correct") is not False
        or checks.get("step_module_exact_minimum_correct") is not False
        or checks.get("all_correct_minimum") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 3
        or overall.get("failed_prediction_count") != 0
        or overall.get("step_exact", {}).get("correct") != 1
        or overall.get("step_module_exact", {}).get("correct") != 1
        or overall.get("all_correct", {}).get("correct") != 1
        or status_counts != Counter({"success": 3})
        or predicted
        != [
            (16, "memory", "memory_retrieval_failure"),
            (1, "action", "misalignment"),
            (8, "action", "parameter_error"),
        ]
        or prior_steps != [30, 1, 1]
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v43 dry3 run is not the authoritative failure anchor"
        )
    try:
        raw_lanes = json.loads(
            rows[0]["raw_judge_outputs"][BATCHED_CRITIC_STAGE]
        )["cases"]
        raw_selector = json.loads(
            rows[0]["raw_judge_outputs"][BATCHED_SELECTOR_STAGE]
        )["cases"]
        candidate_tuples = [
            [
                None
                if lane["hypothesis"] is None
                else (
                    lane["hypothesis"]["critical_step"],
                    lane["hypothesis"]["taxonomy_pair"],
                )
                for lane in case["causal_lanes"]
            ]
            for case in raw_lanes
        ]
        selector_tuples = [
            (case["critical_step"], case["taxonomy_pair"])
            for case in raw_selector
        ]
    except (KeyError, TypeError, ValueError, IndexError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v43 dry3 raw semantic chain is invalid"
        ) from error
    if (
        candidate_tuples
        != [
            [
                (16, "memory/memory_retrieval_failure"),
                (8, "planning/inefficient_plan"),
                (16, "memory/memory_retrieval_failure"),
            ],
            [
                None,
                (1, "action/misalignment"),
                (4, "planning/constraint_ignorance"),
            ],
            [
                None,
                (6, "planning/inefficient_plan"),
                (8, "action/parameter_error"),
            ],
        ]
        or selector_tuples
        != [
            (16, "memory/memory_retrieval_failure"),
            (1, "action/misalignment"),
            (8, "action/parameter_error"),
        ]
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v43 semantic failure details changed"
        )
    ledger = load_fresh_semantic_completion_ledger(
        paths["logical-completion-ledger.json"],
        preregistration_sha256=_V43_REJECTED_PREREGISTRATION_SHA256,
        cumulative_before=535,
        maximum_new=2,
        authorized_cumulative_ceiling=537,
        allowed_stages=[BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE],
    )
    if (
        ledger.get("ledger_sha256") != _V43_REJECTED_LEDGER_SHA256
        or [entry.get("stage") for entry in ledger["entries"]]
        != [BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE]
        or _directory_state(cache) != _V43_REJECTED_CACHE_STATE
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v43 ledger/cache authority record changed"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v43_flash_dry3_branch_cutting_sufficiency_anchor",
        "cumulative_before": 535,
        "logical_completions_used": 2,
        "cumulative_after": 537,
        "accepted": False,
        "summary": {
            "trajectory_count": 3,
            "successful_prediction_count": 3,
            "failed_prediction_count": 0,
            "step_correct": 1,
            "step_module_correct": 1,
            "all_correct": 1,
            "status_counts": dict(status_counts),
        },
        "semantic_failure": {
            "correct_candidate_available_cases": 2,
            "correct_final_cases": 1,
            "c01_boundary_rejected_for_unknown_alternative": (
                "30/system/step_limit->16/memory/memory_retrieval_failure"
            ),
            "c02_capability_root_retained": "1/action/misalignment",
            "c03_epoch_started_not_later_committed": (
                "13/planning/inefficient_plan->8/action/parameter_error"
            ),
        },
        "provider_usage_token_totals": dict(
            telemetry["provider_usage_token_totals"]
        ),
        "cache_state": dict(_V43_REJECTED_CACHE_STATE),
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V43_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V43_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V43_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V43_REJECTED_PROMOTION_SHA256,
        "logical_completion_ledger_sha256": _V43_REJECTED_LEDGER_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v43_rejected_dry3_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v43_rejected_dry3_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v44 rejected-v43 dry3 anchor changed after preregistration"
        )
    return expected


def _resolve_v44_rejected_dry3_binding() -> dict[str, Any]:
    """Bind v44's rejected failure-preventing dry run through 539."""

    root = _repository_path(_V44_REJECTED_RUN_RELATIVE_ROOT)
    cache = _repository_path(_V44_REJECTED_CACHE_RELATIVE_ROOT)
    paths = {name: root / name for name in _V44_REJECTED_FILE_SHA256}
    if any(
        not path.is_file()
        or _file_sha256(path) != _V44_REJECTED_FILE_SHA256[name]
        for name, path in paths.items()
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v44 dry3 artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v44 dry3 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v44 dry3 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v44 dry3 promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(paths["metrics.json"], location="rejected v44 metrics")
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"], location="rejected v44 predictions"
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v44 dry3 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    checks = promotion.get("checks")
    status_counts = Counter(row.get("status") for row in rows)
    predicted = [
        (
            row.get("predicted_step"),
            row.get("predicted_module"),
            row.get("predicted_error_type"),
        )
        for row in rows
    ]
    prior_steps = [
        row.get("predecessor_bundle", {})
        .get("prior_root", {})
        .get("critical_step")
        for row in rows
    ]
    if (
        prereg.get("preregistration_sha256")
        != _V44_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 537
        or budget.get("maximum_new") != 2
        or budget.get("hard_cumulative_stop") != 539
        or run.get("predict_run_sha256") != _V44_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V44_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 2
        or run.get("semantic_mutation_count") != 0
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 2
        or telemetry.get("http_attempt_count") != 2
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_response_count") != 2
        or telemetry.get("provider_usage_token_totals")
        != {"input_tokens": 381296, "output_tokens": 24692, "total_tokens": 405988}
        or promotion.get("promotion_sha256") != _V44_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or not isinstance(checks, Mapping)
        or checks.get("step_exact_minimum_correct") is not False
        or checks.get("step_module_exact_minimum_correct") is not False
        or checks.get("all_correct_minimum") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 3
        or overall.get("failed_prediction_count") != 0
        or overall.get("step_exact", {}).get("correct") != 1
        or overall.get("step_module_exact", {}).get("correct") != 1
        or overall.get("all_correct", {}).get("correct") != 0
        or status_counts != Counter({"success": 3})
        or predicted
        != [
            (4, "planning", "inefficient_plan"),
            (1, "action", "parameter_error"),
            (8, "planning", "inefficient_plan"),
        ]
        or prior_steps != [30, 1, 1]
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v44 dry3 run is not the authoritative failure anchor"
        )
    try:
        raw_lanes = json.loads(
            rows[0]["raw_judge_outputs"][BATCHED_CRITIC_STAGE]
        )["cases"]
        raw_selector = json.loads(
            rows[0]["raw_judge_outputs"][BATCHED_SELECTOR_STAGE]
        )["cases"]
        candidate_tuples = [
            [
                None
                if lane["hypothesis"] is None
                else (
                    lane["hypothesis"]["critical_step"],
                    lane["hypothesis"]["taxonomy_pair"],
                )
                for lane in case["causal_lanes"]
            ]
            for case in raw_lanes
        ]
        selector_tuples = [
            (case["critical_step"], case["taxonomy_pair"])
            for case in raw_selector
        ]
    except (KeyError, TypeError, ValueError, IndexError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v44 dry3 raw semantic chain is invalid"
        ) from error
    if (
        candidate_tuples
        != [
            [
                (30, "system/step_limit"),
                (12, "planning/inefficient_plan"),
                (16, "memory/memory_retrieval_failure"),
            ],
            [
                None,
                (1, "action/parameter_error"),
                (4, "planning/constraint_ignorance"),
            ],
            [
                (30, "system/step_limit"),
                (6, "planning/inefficient_plan"),
                (8, "planning/inefficient_plan"),
            ],
        ]
        or selector_tuples
        != [
            (4, "planning/inefficient_plan"),
            (1, "action/parameter_error"),
            (8, "planning/inefficient_plan"),
        ]
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v44 semantic failure details changed"
        )
    ledger = load_fresh_semantic_completion_ledger(
        paths["logical-completion-ledger.json"],
        preregistration_sha256=_V44_REJECTED_PREREGISTRATION_SHA256,
        cumulative_before=537,
        maximum_new=2,
        authorized_cumulative_ceiling=539,
        allowed_stages=[BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE],
    )
    if (
        ledger.get("ledger_sha256") != _V44_REJECTED_LEDGER_SHA256
        or [entry.get("stage") for entry in ledger["entries"]]
        != [BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE]
        or _directory_state(cache) != _V44_REJECTED_CACHE_STATE
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v44 ledger/cache authority record changed"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v44_flash_dry3_selector_category_anchor",
        "cumulative_before": 537,
        "logical_completions_used": 2,
        "cumulative_after": 539,
        "accepted": False,
        "summary": {
            "trajectory_count": 3,
            "successful_prediction_count": 3,
            "failed_prediction_count": 0,
            "step_correct": 1,
            "step_module_correct": 1,
            "all_correct": 0,
            "status_counts": dict(status_counts),
        },
        "semantic_failure": {
            "correct_candidate_available_cases": 2,
            "correct_final_cases": 0,
            "c01_fresh_unknown_search_displaced_boundary": (
                "30/system/step_limit->4/planning/inefficient_plan"
            ),
            "c02_action_subtype_confusion": (
                "1/action/misalignment->1/action/parameter_error"
            ),
            "c03_module_fixed_step_still_early": (
                "13/planning/inefficient_plan->8/planning/inefficient_plan"
            ),
        },
        "provider_usage_token_totals": dict(
            telemetry["provider_usage_token_totals"]
        ),
        "cache_state": dict(_V44_REJECTED_CACHE_STATE),
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V44_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "preregistration_sha256": _V44_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V44_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V44_REJECTED_PROMOTION_SHA256,
        "logical_completion_ledger_sha256": _V44_REJECTED_LEDGER_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v44_rejected_dry3_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v44_rejected_dry3_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v45 rejected-v44 dry3 anchor changed after preregistration"
        )
    return expected


def _resolve_v45_rejected_dry3_binding() -> dict[str, Any]:
    """Bind v45's interrupted, exactly recovered, rejected dry run."""

    root = _repository_path(_V45_REJECTED_RUN_RELATIVE_ROOT)
    cache = _repository_path(_V45_REJECTED_CACHE_RELATIVE_ROOT)
    recovery_root = _repository_path(_V45_RECOVERY_RUN_RELATIVE_ROOT)
    archive = _repository_path(_V45_RECOVERY_ARCHIVE_RELATIVE_PATH)
    paths = {name: root / name for name in _V45_REJECTED_FILE_SHA256}
    recovery_paths = {
        name: recovery_root / name for name in _V45_RECOVERY_FILE_SHA256
    }
    case_studies = {
        "interruption": _repository_path(
            "docs/experiments/e9-v45-dry3-failure-case-study.md"
        ),
        "invocation": _repository_path(
            "docs/experiments/e9-v45-selector-recovery-invocation-case-study.md"
        ),
        "semantic": _repository_path(
            "docs/experiments/e9-v45-recovered-dry3-failure-case-study.md"
        ),
    }
    expected_case_hashes = {
        "interruption": _V45_FAILURE_CASE_STUDY_SHA256,
        "invocation": _V45_INVOCATION_CASE_STUDY_SHA256,
        "semantic": _V45_RECOVERED_CASE_STUDY_SHA256,
    }
    if (
        any(
            not path.is_file()
            or _file_sha256(path) != _V45_REJECTED_FILE_SHA256[name]
            for name, path in paths.items()
        )
        or any(
            not path.is_file()
            or _file_sha256(path) != _V45_RECOVERY_FILE_SHA256[name]
            for name, path in recovery_paths.items()
        )
        or not archive.is_file()
        or _file_sha256(archive) != _V45_RECOVERY_ARCHIVE_FILE_SHA256
        or any(
            not path.is_file()
            or _file_sha256(path) != expected_case_hashes[name]
            for name, path in case_studies.items()
        )
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v45 recovery artifact bytes changed"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v45 preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v45 predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v45 promotion",
        hash_field="promotion_sha256",
    )
    recovery_prereg = _validated_hashed_document(
        recovery_paths["preregistration.json"],
        location="v45 Selector recovery preregistration",
        hash_field="preregistration_sha256",
    )
    recovery_run = _validated_hashed_document(
        recovery_paths["recovery-run.json"],
        location="v45 Selector recovery run",
        hash_field="recovery_run_sha256",
    )
    metrics = _read(paths["metrics.json"], location="rejected v45 metrics")
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"], location="rejected v45 predictions"
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v45 metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    telemetry = run.get("provider_telemetry_current_run")
    recovery_telemetry = recovery_run.get("stage_telemetry")
    checks = promotion.get("checks")
    status_counts = Counter(row.get("status") for row in rows)
    predicted = [
        (
            row.get("predicted_step"),
            row.get("predicted_module"),
            row.get("predicted_error_type"),
        )
        for row in rows
    ]
    if (
        prereg.get("preregistration_sha256")
        != _V45_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 539
        or budget.get("maximum_new") != 2
        or budget.get("hard_cumulative_stop") != 541
        or run.get("predict_run_sha256") != _V45_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V45_REJECTED_PREREGISTRATION_SHA256
        or run.get("logical_completion_budget_used") != 2
        or run.get("semantic_mutation_count") != 0
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 2
        or telemetry.get("http_attempt_count") != 2
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_token_totals")
        != {"input_tokens": 381615, "output_tokens": 30885, "total_tokens": 412500}
        or promotion.get("promotion_sha256") != _V45_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or not isinstance(checks, Mapping)
        or checks.get("step_exact_minimum_correct") is not False
        or checks.get("step_module_exact_minimum_correct") is not False
        or checks.get("all_correct_minimum") is not False
        or overall.get("trajectory_count") != 3
        or overall.get("successful_prediction_count") != 3
        or overall.get("failed_prediction_count") != 0
        or overall.get("step_exact", {}).get("correct") != 1
        or overall.get("step_module_exact", {}).get("correct") != 1
        or overall.get("all_correct", {}).get("correct") != 1
        or status_counts != Counter({"success": 3})
        or predicted
        != [
            (30, "system", "step_limit"),
            (4, "planning", "constraint_ignorance"),
            (15, "planning", "inefficient_plan"),
        ]
        or recovery_prereg.get("preregistration_sha256")
        != _V45_RECOVERY_PREREGISTRATION_SHA256
        or recovery_prereg.get("selector_request_sha256")
        != _V45_SELECTOR_REQUEST_SHA256
        or recovery_prereg.get("critic_request_sha256")
        != _V45_CRITIC_REQUEST_SHA256
        or recovery_prereg.get("semantic_change") is not False
        or recovery_prereg.get("gold_access") is not False
        or recovery_run.get("recovery_run_sha256") != _V45_RECOVERY_RUN_SHA256
        or recovery_run.get("selector_request_sha256")
        != _V45_SELECTOR_REQUEST_SHA256
        or recovery_run.get("status") != "success"
        or recovery_run.get("logical_completions") != 1
        or recovery_run.get("semantic_change") is not False
        or recovery_run.get("gold_access") is not False
        or not isinstance(recovery_telemetry, Mapping)
        or recovery_telemetry.get("logical_completion_count") != 1
        or recovery_telemetry.get("http_attempt_count") != 1
        or recovery_telemetry.get("retry_count") != 0
        or recovery_telemetry.get("provider_usage_token_totals")
        != {"input_tokens": 191436, "output_tokens": 9508, "total_tokens": 200944}
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v45 run/recovery is not the authoritative failure anchor"
        )
    try:
        raw_lanes = json.loads(
            rows[0]["raw_judge_outputs"][BATCHED_CRITIC_STAGE]
        )["cases"]
        raw_selector = json.loads(
            rows[0]["raw_judge_outputs"][BATCHED_SELECTOR_STAGE]
        )["cases"]
        candidate_tuples = [
            [
                None
                if lane["hypothesis"] is None
                else (
                    lane["hypothesis"]["critical_step"],
                    lane["hypothesis"]["taxonomy_pair"],
                )
                for lane in case["causal_lanes"]
            ]
            for case in raw_lanes
        ]
        selector_tuples = [
            (case["critical_step"], case["taxonomy_pair"])
            for case in raw_selector
        ]
    except (KeyError, TypeError, ValueError, IndexError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v45 raw semantic chain is invalid"
        ) from error
    if candidate_tuples != [
        [
            (30, "system/step_limit"),
            (8, "planning/inefficient_plan"),
            None,
        ],
        [
            None,
            (4, "planning/constraint_ignorance"),
            (4, "planning/constraint_ignorance"),
        ],
        [
            (30, "system/step_limit"),
            (5, "planning/inefficient_plan"),
            (15, "planning/inefficient_plan"),
        ],
    ] or selector_tuples != [
        (30, "system/step_limit"),
        (4, "planning/constraint_ignorance"),
        (15, "planning/inefficient_plan"),
    ]:
        raise BatchedCriticPreregistrationError(
            "rejected v45 semantic failure details changed"
        )
    ledger = load_fresh_semantic_completion_ledger(
        paths["logical-completion-ledger.json"],
        preregistration_sha256=_V45_REJECTED_PREREGISTRATION_SHA256,
        cumulative_before=539,
        maximum_new=2,
        authorized_cumulative_ceiling=541,
        allowed_stages=[BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE],
    )
    recovery_ledger = load_fresh_semantic_completion_ledger(
        recovery_paths["logical-completion-ledger.json"],
        preregistration_sha256=_V45_RECOVERY_PREREGISTRATION_SHA256,
        cumulative_before=541,
        maximum_new=1,
        authorized_cumulative_ceiling=542,
        allowed_stages=[BATCHED_SELECTOR_STAGE],
    )
    if (
        ledger.get("ledger_sha256") != _V45_REJECTED_LEDGER_SHA256
        or [
            (entry.get("stage"), entry.get("request_sha256"))
            for entry in ledger["entries"]
        ]
        != [
            (BATCHED_CRITIC_STAGE, _V45_CRITIC_REQUEST_SHA256),
            (BATCHED_SELECTOR_STAGE, _V45_SELECTOR_REQUEST_SHA256),
        ]
        or recovery_ledger.get("ledger_sha256")
        != _V45_RECOVERY_LEDGER_SHA256
        or [
            (entry.get("stage"), entry.get("request_sha256"))
            for entry in recovery_ledger["entries"]
        ]
        != [(BATCHED_SELECTOR_STAGE, _V45_SELECTOR_REQUEST_SHA256)]
        or _directory_state(cache) != _V45_REJECTED_CACHE_STATE
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v45 ledger/cache recovery authority changed"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v45_flash_recovered_selector_semantic_anchor",
        "cumulative_before": 539,
        "original_reservations": 2,
        "recovery_logical_completions": 1,
        "cumulative_after": 542,
        "accepted": False,
        "summary": {
            "trajectory_count": 3,
            "successful_prediction_count": 3,
            "failed_prediction_count": 0,
            "step_correct": 1,
            "step_module_correct": 1,
            "all_correct": 1,
            "status_counts": dict(status_counts),
        },
        "semantic_failure": {
            "c01_boundary_fixed": "30/system/step_limit",
            "c02_persistent_capability_root_bypassed": (
                "1/action/misalignment->4/planning/constraint_ignorance"
            ),
            "c03_candidate_recall_two_steps_late": (
                "13/planning/inefficient_plan->15/planning/inefficient_plan"
            ),
        },
        "completed_provider_usage_token_totals": dict(
            telemetry["provider_usage_token_totals"]
        ),
        "recovery_provider_usage_token_totals": dict(
            recovery_telemetry["provider_usage_token_totals"]
        ),
        "cache_state": dict(_V45_REJECTED_CACHE_STATE),
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V45_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "recovery_artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V45_RECOVERY_FILE_SHA256[name],
            }
            for name, path in recovery_paths.items()
        },
        "recovery_code_archive": {
            "path": str(archive),
            "file_sha256": _V45_RECOVERY_ARCHIVE_FILE_SHA256,
        },
        "case_studies": {
            name: {
                "path": str(path),
                "file_sha256": expected_case_hashes[name],
            }
            for name, path in case_studies.items()
        },
        "preregistration_sha256": _V45_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V45_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V45_REJECTED_PROMOTION_SHA256,
        "logical_completion_ledger_sha256": _V45_REJECTED_LEDGER_SHA256,
        "recovery_preregistration_sha256": (
            _V45_RECOVERY_PREREGISTRATION_SHA256
        ),
        "recovery_run_sha256": _V45_RECOVERY_RUN_SHA256,
        "recovery_ledger_sha256": _V45_RECOVERY_LEDGER_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v45_rejected_dry3_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v45_rejected_dry3_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v46 rejected-v45 dry3 anchor changed after preregistration"
        )
    return expected


def _resolve_recent_rejected_binding(
    *,
    label: str,
    role: str,
    run_relative_root: str,
    cache_relative_root: str,
    file_hashes: Mapping[str, str],
    case_study_hashes: Mapping[str, tuple[str, str]],
    preregistration_sha256: str,
    predict_run_sha256: str,
    promotion_sha256: str,
    ledger_sha256: str,
    cache_state: Mapping[str, Any],
    profile: str,
    cumulative_before: int,
    maximum_new: int,
    expected_summary: Mapping[str, int],
    expected_pipeline_version: str,
    expected_critic_protocol: str,
    expected_selector_protocol: str,
    expected_token_totals: Mapping[str, int],
    expected_predictions: Sequence[tuple[int, str, str]] | None = None,
) -> dict[str, Any]:
    """Hash-bind a completed rejected run and its mandatory case studies."""

    root = _repository_path(run_relative_root)
    cache = _repository_path(cache_relative_root)
    paths = {name: root / name for name in file_hashes}
    case_studies = {
        name: _repository_path(relative_path)
        for name, (relative_path, _digest) in case_study_hashes.items()
    }
    if any(
        not path.is_file() or _file_sha256(path) != file_hashes[name]
        for name, path in paths.items()
    ) or any(
        not case_studies[name].is_file()
        or _file_sha256(case_studies[name]) != digest
        for name, (_relative_path, digest) in case_study_hashes.items()
    ):
        raise BatchedCriticPreregistrationError(
            f"authoritative rejected {label} artifact bytes changed"
        )

    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location=f"rejected {label} preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location=f"rejected {label} predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location=f"rejected {label} promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(paths["metrics.json"], location=f"rejected {label} metrics")
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location=f"rejected {label} unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            f"rejected {label} metrics envelope is invalid"
        ) from error
    budget = prereg.get("logical_completion_budget")
    implementation = prereg.get("implementation")
    telemetry = run.get("provider_telemetry_current_run")
    checks = promotion.get("checks")
    predicted = [
        (
            row.get("predicted_step"),
            row.get("predicted_module"),
            row.get("predicted_error_type"),
        )
        for row in rows
    ]
    expected_count = expected_summary["trajectory_count"]
    if (
        prereg.get("preregistration_sha256") != preregistration_sha256
        or prereg.get("evaluation", {}).get("profile") != profile
        or not isinstance(implementation, Mapping)
        or implementation.get("pipeline_version") != expected_pipeline_version
        or implementation.get("prompt_protocol_version")
        != expected_critic_protocol
        or implementation.get("selector_prompt_protocol_version")
        != expected_selector_protocol
        or implementation.get("sole_final_semantics")
        != "raw_selector_final_fields"
        or implementation.get("deterministic_root_fallback") is not False
        or implementation.get("deterministic_semantic_mutation") is not False
        or implementation.get("confidence_score_weight_vote") is not False
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != cumulative_before
        or budget.get("maximum_new") != maximum_new
        or budget.get("hard_cumulative_stop")
        != cumulative_before + maximum_new
        or run.get("predict_run_sha256") != predict_run_sha256
        or run.get("preregistration_sha256") != preregistration_sha256
        or run.get("pipeline_version") != expected_pipeline_version
        or run.get("critic_prompt_protocol_version")
        != expected_critic_protocol
        or run.get("selector_prompt_protocol_version")
        != expected_selector_protocol
        or run.get("prediction_count") != expected_count
        or run.get("logical_completion_budget_used") != maximum_new
        or run.get("semantic_mutation_count") != 0
        or run.get("unscored_predictions_sha256")
        != file_hashes["unscored-predictions.jsonl"]
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != maximum_new
        or telemetry.get("http_attempt_count") != maximum_new
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_token_totals")
        != dict(expected_token_totals)
        or promotion.get("promotion_sha256") != promotion_sha256
        or promotion.get("accepted") is not False
        or not isinstance(checks, Mapping)
        or checks.get("step_exact_minimum_correct") is not False
        or overall.get("trajectory_count") != expected_count
        or overall.get("successful_prediction_count")
        != expected_summary["successful_prediction_count"]
        or overall.get("failed_prediction_count")
        != expected_summary["failed_prediction_count"]
        or overall.get("step_exact", {}).get("correct")
        != expected_summary["step_correct"]
        or overall.get("step_module_exact", {}).get("correct")
        != expected_summary["step_module_correct"]
        or overall.get("all_correct", {}).get("correct")
        != expected_summary["all_correct"]
        or Counter(row.get("status") for row in rows)
        != Counter({"success": expected_count})
        or (expected_predictions is not None and predicted != list(expected_predictions))
    ):
        raise BatchedCriticPreregistrationError(
            f"rejected {label} run is not the authoritative failure anchor"
        )
    ledger = load_fresh_semantic_completion_ledger(
        paths["logical-completion-ledger.json"],
        preregistration_sha256=preregistration_sha256,
        cumulative_before=cumulative_before,
        maximum_new=maximum_new,
        authorized_cumulative_ceiling=cumulative_before + maximum_new,
        allowed_stages=[BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE],
    )
    if (
        ledger.get("ledger_sha256") != ledger_sha256
        or len(ledger.get("entries", ())) != maximum_new
        or _directory_state(cache) != dict(cache_state)
    ):
        raise BatchedCriticPreregistrationError(
            f"rejected {label} ledger/cache authority changed"
        )
    binding: dict[str, Any] = {
        "role": role,
        "profile": profile,
        "cumulative_before": cumulative_before,
        "logical_completions": maximum_new,
        "cumulative_after": cumulative_before + maximum_new,
        "accepted": False,
        "summary": dict(expected_summary),
        "pipeline_version": expected_pipeline_version,
        "critic_prompt_protocol_version": expected_critic_protocol,
        "selector_prompt_protocol_version": expected_selector_protocol,
        "provider_usage_token_totals": dict(expected_token_totals),
        "cache_state": dict(cache_state),
        "artifacts": {
            name: {"path": str(path), "file_sha256": file_hashes[name]}
            for name, path in paths.items()
        },
        "case_studies": {
            name: {
                "path": str(case_studies[name]),
                "file_sha256": digest,
            }
            for name, (_relative_path, digest) in case_study_hashes.items()
        },
        "preregistration_sha256": preregistration_sha256,
        "predict_run_sha256": predict_run_sha256,
        "promotion_sha256": promotion_sha256,
        "logical_completion_ledger_sha256": ledger_sha256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _resolve_v46_rejected_full30_binding() -> dict[str, Any]:
    return _resolve_recent_rejected_binding(
        label="v46 full30",
        role="rejected_v46_flash_persistent_information_root_full30_anchor",
        run_relative_root=_V46_REJECTED_RUN_RELATIVE_ROOT,
        cache_relative_root=_V46_REJECTED_CACHE_RELATIVE_ROOT,
        file_hashes=_V46_REJECTED_FILE_SHA256,
        case_study_hashes={
            "semantic": (
                "docs/experiments/e9-v46-full30-failure-case-study.md",
                _V46_FAILURE_CASE_STUDY_SHA256,
            )
        },
        preregistration_sha256=_V46_REJECTED_PREREGISTRATION_SHA256,
        predict_run_sha256=_V46_REJECTED_PREDICT_RUN_SHA256,
        promotion_sha256=_V46_REJECTED_PROMOTION_SHA256,
        ledger_sha256=_V46_REJECTED_LEDGER_SHA256,
        cache_state=_V46_REJECTED_CACHE_STATE,
        profile="full30",
        cumulative_before=544,
        maximum_new=20,
        expected_summary={
            "trajectory_count": 30,
            "successful_prediction_count": 30,
            "failed_prediction_count": 0,
            "step_correct": 9,
            "step_module_correct": 3,
            "all_correct": 3,
        },
        expected_pipeline_version=(
            "e9-persistent-information-root-v46-deepseek-v4-flash-default"
        ),
        expected_critic_protocol=(
            "agentdebug-e9-candidate-v44-failure-preventing-causal-lanes-source-id"
        ),
        expected_selector_protocol=(
            "agentdebug-e9-selector-v46-persistent-information-root-source-id"
        ),
        expected_token_totals={
            "input_tokens": 3_654_148,
            "output_tokens": 397_937,
            "total_tokens": 4_052_085,
        },
    )


def _validate_v46_rejected_full30_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v46_rejected_full30_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v48 rejected-v46 full30 anchor changed after preregistration"
        )
    return expected


def _resolve_v47_rejected_dry3_binding() -> dict[str, Any]:
    return _resolve_recent_rejected_binding(
        label="v47 dry3",
        role="rejected_v47_flash_five_lane_handoff_dry3_anchor",
        run_relative_root=_V47_REJECTED_RUN_RELATIVE_ROOT,
        cache_relative_root=_V47_REJECTED_CACHE_RELATIVE_ROOT,
        file_hashes=_V47_REJECTED_FILE_SHA256,
        case_study_hashes={
            "invocation": (
                "docs/experiments/e9-v47-dry3-invocation-failure-case-study.md",
                _V47_INVOCATION_CASE_STUDY_SHA256,
            ),
            "semantic": (
                "docs/experiments/e9-v47-dry3-failure-case-study.md",
                _V47_FAILURE_CASE_STUDY_SHA256,
            ),
        },
        preregistration_sha256=_V47_REJECTED_PREREGISTRATION_SHA256,
        predict_run_sha256=_V47_REJECTED_PREDICT_RUN_SHA256,
        promotion_sha256=_V47_REJECTED_PROMOTION_SHA256,
        ledger_sha256=_V47_REJECTED_LEDGER_SHA256,
        cache_state=_V47_REJECTED_CACHE_STATE,
        profile="dry3",
        cumulative_before=564,
        maximum_new=2,
        expected_summary={
            "trajectory_count": 3,
            "successful_prediction_count": 3,
            "failed_prediction_count": 0,
            "step_correct": 1,
            "step_module_correct": 1,
            "all_correct": 1,
        },
        expected_pipeline_version=(
            "e9-five-lane-handoff-v47-deepseek-v4-flash-default"
        ),
        expected_critic_protocol=(
            "agentdebug-e9-candidate-v47-five-causal-lanes-source-id"
        ),
        expected_selector_protocol=(
            "agentdebug-e9-selector-v47-five-lane-handoff-source-id"
        ),
        expected_token_totals={
            "input_tokens": 383_220,
            "output_tokens": 32_131,
            "total_tokens": 415_351,
        },
        expected_predictions=(
            (30, "system", "step_limit"),
            (4, "planning", "constraint_ignorance"),
            (30, "system", "step_limit"),
        ),
    )


def _validate_v47_rejected_dry3_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v47_rejected_dry3_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v48 rejected-v47 dry3 anchor changed after preregistration"
        )
    return expected


def _resolve_v48_rejected_dry3_binding() -> dict[str, Any]:
    return _resolve_recent_rejected_binding(
        label="v48 dry3",
        role="rejected_v48_flash_scout_broadened_handoff_dry3_anchor",
        run_relative_root=_V48_REJECTED_RUN_RELATIVE_ROOT,
        cache_relative_root=_V48_REJECTED_CACHE_RELATIVE_ROOT,
        file_hashes=_V48_REJECTED_FILE_SHA256,
        case_study_hashes={
            "semantic": (
                "docs/experiments/e9-v48-dry3-failure-case-study.md",
                _V48_FAILURE_CASE_STUDY_SHA256,
            )
        },
        preregistration_sha256=_V48_REJECTED_PREREGISTRATION_SHA256,
        predict_run_sha256=_V48_REJECTED_PREDICT_RUN_SHA256,
        promotion_sha256=_V48_REJECTED_PROMOTION_SHA256,
        ledger_sha256=_V48_REJECTED_LEDGER_SHA256,
        cache_state=_V48_REJECTED_CACHE_STATE,
        profile="dry3",
        cumulative_before=566,
        maximum_new=2,
        expected_summary={
            "trajectory_count": 3,
            "successful_prediction_count": 3,
            "failed_prediction_count": 0,
            "step_correct": 1,
            "step_module_correct": 1,
            "all_correct": 1,
        },
        expected_pipeline_version=(
            "e9-scout-broadened-handoff-v48-deepseek-v4-flash-default"
        ),
        expected_critic_protocol=(
            "agentdebug-e9-candidate-v48-five-causal-lanes-source-id"
        ),
        expected_selector_protocol=(
            "agentdebug-e9-selector-v48-scout-broadened-handoff-source-id"
        ),
        expected_token_totals={
            "input_tokens": 383_052,
            "output_tokens": 30_478,
            "total_tokens": 413_530,
        },
        expected_predictions=(
            (30, "system", "step_limit"),
            (3, "planning", "constraint_ignorance"),
            (15, "planning", "inefficient_plan"),
        ),
    )


def _validate_v48_rejected_dry3_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v48_rejected_dry3_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v49 rejected-v48 dry3 anchor changed after preregistration"
        )
    return expected


def _resolve_v49_incomplete_full30_binding() -> dict[str, Any]:
    """Bind v49's locally rejected 21-row prefix and all 15 paid calls."""

    root = _repository_path(_V49_INCOMPLETE_RUN_RELATIVE_ROOT)
    cache = _repository_path(_V49_INCOMPLETE_CACHE_RELATIVE_ROOT)
    paths = {name: root / name for name in _V49_INCOMPLETE_FILE_SHA256}
    case_study = _repository_path(
        "docs/experiments/"
        "e9-v49-full30-selector-cap-preflight-failure-case-study.md"
    )
    if (
        any(
            not path.is_file()
            or _file_sha256(path) != _V49_INCOMPLETE_FILE_SHA256[name]
            for name, path in paths.items()
        )
        or not case_study.is_file()
        or _file_sha256(case_study)
        != _V49_INCOMPLETE_FAILURE_CASE_STUDY_SHA256
        or _directory_state(cache) != _V49_INCOMPLETE_CACHE_STATE
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative incomplete v49 artifact bytes changed"
        )
    if any(
        (root / name).exists()
        for name in (
            "predict-run.json",
            "predictions.jsonl",
            "metrics.json",
            "promotion.json",
            "artifact-manifest.json",
        )
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v49 run unexpectedly contains completion artifacts"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="incomplete v49 full30 preregistration",
        hash_field="preregistration_sha256",
    )
    implementation = prereg.get("implementation")
    budget = prereg.get("logical_completion_budget")
    if (
        prereg.get("preregistration_sha256")
        != _V49_INCOMPLETE_PREREGISTRATION_SHA256
        or prereg.get("evaluation", {}).get("profile") != "full30"
        or not isinstance(implementation, Mapping)
        or implementation.get("pipeline_version")
        != "e9-cross-module-consistency-v49-deepseek-v4-flash-default"
        or implementation.get("prompt_protocol_version")
        != "agentdebug-e9-candidate-v49-six-causal-lanes-source-id"
        or implementation.get("selector_prompt_protocol_version")
        != (
            "agentdebug-e9-selector-v49-required-field-state-consistency-"
            "source-id"
        )
        or implementation.get("sole_final_semantics")
        != "raw_selector_final_fields"
        or implementation.get("deterministic_root_fallback") is not False
        or implementation.get("deterministic_semantic_mutation") is not False
        or implementation.get("confidence_score_weight_vote") is not False
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 570
        or budget.get("maximum_new") != 20
        or budget.get("hard_cumulative_stop") != 590
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v49 preregistration identity changed"
        )
    ledger = load_fresh_semantic_completion_ledger(
        paths["logical-completion-ledger.json"],
        preregistration_sha256=_V49_INCOMPLETE_PREREGISTRATION_SHA256,
        cumulative_before=570,
        maximum_new=20,
        authorized_cumulative_ceiling=590,
        allowed_stages=[BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE],
    )
    entries = ledger.get("entries", ())
    expected_stages = tuple(
        stage
        for _index in range(7)
        for stage in (BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE)
    ) + (BATCHED_CRITIC_STAGE,)
    if (
        ledger.get("ledger_sha256") != _V49_INCOMPLETE_LEDGER_SHA256
        or tuple(entry.get("stage") for entry in entries) != expected_stages
        or tuple(entry.get("request_sha256") for entry in entries)
        != _V49_INCOMPLETE_LEDGER_REQUEST_SHA256S
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v49 ledger is not the fifteen-call authority record"
        )
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="incomplete v49 partial predictions",
    )
    plan_path = Path(str(prereg.get("batch_plan", {}).get("path")))
    plan_document = _read(
        plan_path,
        location="incomplete v49 frozen batch plan",
    )
    batches = plan_document.get("batches")
    if (
        not isinstance(batches, list)
        or len(batches) != 11
        or _file_sha256(plan_path)
        != prereg.get("batch_plan", {}).get("file_sha256")
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v49 frozen batch plan changed"
        )
    expected_ids = tuple(
        trajectory_id
        for batch in batches[:8]
        for trajectory_id in _batch_trajectory_ids(batch)
    )
    if (
        len(rows) != 21
        or Counter(row.get("status") for row in rows)
        != Counter({"success": 21})
        or tuple(row.get("trajectory_id") for row in rows) != expected_ids
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v49 partial prediction prefix is invalid"
        )
    telemetry_values: list[Mapping[str, Any] | None] = []
    for entry in entries:
        raw_path = (
            cache
            / "semantic_stages"
            / "raw"
            / str(entry["stage"])
            / f"{entry['request_sha256']}.json"
        )
        raw = _read(raw_path, location="incomplete v49 raw stage record")
        telemetry_values.append(raw.get("telemetry_delta"))
    try:
        telemetry = sum_stage_telemetry(telemetry_values)
    except StageCacheError as error:
        raise BatchedCriticPreregistrationError(
            "incomplete v49 telemetry is invalid"
        ) from error
    expected_telemetry = {
        "logical_completion_count": 15,
        "http_attempt_count": 15,
        "retry_count": 0,
        "request_input_chars": 9_291_858,
        "provider_usage_response_count": 15,
        "provider_usage_token_totals": {
            "input_tokens": 2_635_854,
            "output_tokens": 309_470,
            "total_tokens": 2_945_324,
        },
        "finish_reason_counts": {"stop": 15},
    }
    if telemetry != expected_telemetry:
        raise BatchedCriticPreregistrationError(
            "incomplete v49 provider usage changed"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v49_selector_cap_preflight_full30_anchor",
        "profile": "full30",
        "cumulative_before": 570,
        "logical_completions_used": 15,
        "cumulative_after": 585,
        "accepted": False,
        "failure_class": "local_selector_character_cap_preflight",
        "partial_prediction_count": 21,
        "partial_status_counts": {"success": 21},
        "failed_batch_id": "B2d2ea021a2bf6ad7d0a3",
        "selector_request_chars": 802_251,
        "historical_selector_cap": 800_000,
        "overage_chars": 2_251,
        "selector_ledger_reservation_created": False,
        "selector_http_attempted": False,
        "batch9_critic_request_sha256": (
            _V49_INCOMPLETE_BATCH9_CRITIC_REQUEST_SHA256
        ),
        "provider_telemetry": expected_telemetry,
        "cache_state": dict(_V49_INCOMPLETE_CACHE_STATE),
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V49_INCOMPLETE_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "case_study": {
            "path": str(case_study),
            "file_sha256": _V49_INCOMPLETE_FAILURE_CASE_STUDY_SHA256,
        },
        "preregistration_sha256": _V49_INCOMPLETE_PREREGISTRATION_SHA256,
        "logical_completion_ledger_sha256": _V49_INCOMPLETE_LEDGER_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v49_incomplete_full30_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v49_incomplete_full30_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v50 incomplete-v49 full30 anchor changed after preregistration"
        )
    return expected


def _resolve_v50_incomplete_full30_binding() -> dict[str, Any]:
    """Bind v50's whitespace-brace failure and interrupted next call."""

    root = _repository_path(_V50_INCOMPLETE_RUN_RELATIVE_ROOT)
    cache = _repository_path(_V50_INCOMPLETE_CACHE_RELATIVE_ROOT)
    paths = {name: root / name for name in _V50_INCOMPLETE_FILE_SHA256}
    case_study = _repository_path(
        "docs/experiments/e9-v50-full30-whitespace-brace-failure-case-study.md"
    )
    if (
        any(
            not path.is_file()
            or _file_sha256(path) != _V50_INCOMPLETE_FILE_SHA256[name]
            for name, path in paths.items()
        )
        or not case_study.is_file()
        or _file_sha256(case_study)
        != _V50_INCOMPLETE_FAILURE_CASE_STUDY_SHA256
        or _directory_state(cache) != _V50_INCOMPLETE_CACHE_STATE
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative incomplete v50 artifact bytes changed"
        )
    if any(
        (root / name).exists()
        for name in (
            "predict-run.json",
            "predictions.jsonl",
            "metrics.json",
            "promotion.json",
            "artifact-manifest.json",
        )
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v50 run unexpectedly contains completion artifacts"
        )
    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="incomplete v50 full30 preregistration",
        hash_field="preregistration_sha256",
    )
    implementation = prereg.get("implementation")
    budget = prereg.get("logical_completion_budget")
    if (
        prereg.get("preregistration_sha256")
        != _V50_INCOMPLETE_PREREGISTRATION_SHA256
        or prereg.get("evaluation", {}).get("profile") != "full30"
        or not isinstance(implementation, Mapping)
        or implementation.get("pipeline_version")
        != "e9-selector-capacity-v50-deepseek-v4-flash-default"
        or implementation.get("prompt_protocol_version")
        != "agentdebug-e9-candidate-v49-six-causal-lanes-source-id"
        or implementation.get("selector_prompt_protocol_version")
        != (
            "agentdebug-e9-selector-v49-required-field-state-consistency-"
            "source-id"
        )
        or implementation.get("maximum_critic_request_chars") != 800_000
        or implementation.get("maximum_selector_request_chars") != 900_000
        or implementation.get("sole_final_semantics")
        != "raw_selector_final_fields"
        or implementation.get("deterministic_root_fallback") is not False
        or implementation.get("deterministic_semantic_mutation") is not False
        or implementation.get("confidence_score_weight_vote") is not False
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 587
        or budget.get("maximum_new") != 20
        or budget.get("hard_cumulative_stop") != 607
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v50 preregistration identity changed"
        )
    ledger = load_fresh_semantic_completion_ledger(
        paths["logical-completion-ledger.json"],
        preregistration_sha256=_V50_INCOMPLETE_PREREGISTRATION_SHA256,
        cumulative_before=587,
        maximum_new=20,
        authorized_cumulative_ceiling=607,
        allowed_stages=[BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE],
    )
    entries = ledger.get("entries", ())
    expected_stages = (
        BATCHED_CRITIC_STAGE,
        BATCHED_SELECTOR_STAGE,
        BATCHED_CRITIC_STAGE,
        BATCHED_SELECTOR_STAGE,
        BATCHED_CRITIC_STAGE,
        BATCHED_SELECTOR_STAGE,
        BATCHED_CRITIC_STAGE,
    )
    if (
        ledger.get("ledger_sha256") != _V50_INCOMPLETE_LEDGER_SHA256
        or tuple(entry.get("stage") for entry in entries) != expected_stages
        or tuple(entry.get("request_sha256") for entry in entries)
        != _V50_INCOMPLETE_LEDGER_REQUEST_SHA256S
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v50 ledger is not the seven-reservation authority record"
        )
    plan_path = Path(str(prereg.get("batch_plan", {}).get("path")))
    plan_document = _read(
        plan_path,
        location="incomplete v50 frozen batch plan",
    )
    batches = plan_document.get("batches")
    if (
        not isinstance(batches, list)
        or len(batches) != 11
        or _file_sha256(plan_path)
        != prereg.get("batch_plan", {}).get("file_sha256")
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v50 frozen batch plan changed"
        )
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="incomplete v50 partial predictions",
    )
    expected_ids = tuple(
        trajectory_id
        for batch in batches[:4]
        for trajectory_id in _batch_trajectory_ids(batch)
    )
    if (
        len(rows) != 11
        or Counter(row.get("status") for row in rows)
        != Counter({"success": 8, "invalid_json": 3})
        or tuple(row.get("trajectory_id") for row in rows) != expected_ids
        or any(
            row.get("failure_code") != "malformed_json"
            for row in rows[-3:]
        )
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v50 partial prediction prefix is invalid"
        )
    telemetry_values: list[Mapping[str, Any] | None] = []
    for entry in entries[:6]:
        raw_path = (
            cache
            / "semantic_stages"
            / "raw"
            / str(entry["stage"])
            / f"{entry['request_sha256']}.json"
        )
        raw = _read(raw_path, location="incomplete v50 raw stage record")
        telemetry_values.append(raw.get("telemetry_delta"))
    interrupted_paths = [
        cache
        / "semantic_stages"
        / kind
        / BATCHED_CRITIC_STAGE
        / f"{_V50_INCOMPLETE_INTERRUPTED_CRITIC_REQUEST_SHA256}.json"
        for kind in ("raw", "parsed", "response_sidecar")
    ]
    if any(path.exists() for path in interrupted_paths):
        raise BatchedCriticPreregistrationError(
            "interrupted v50 Critic unexpectedly has a cache artifact"
        )
    try:
        telemetry = sum_stage_telemetry(telemetry_values)
    except StageCacheError as error:
        raise BatchedCriticPreregistrationError(
            "incomplete v50 telemetry is invalid"
        ) from error
    expected_telemetry = {
        "logical_completion_count": 6,
        "http_attempt_count": 6,
        "retry_count": 0,
        "request_input_chars": 4_346_946,
        "provider_usage_response_count": 6,
        "provider_usage_token_totals": {
            "input_tokens": 1_199_178,
            "output_tokens": 111_816,
            "total_tokens": 1_310_994,
        },
        "finish_reason_counts": {"stop": 6},
    }
    if telemetry != expected_telemetry:
        raise BatchedCriticPreregistrationError(
            "incomplete v50 completed provider usage changed"
        )
    selector_raw_path = (
        cache
        / "semantic_stages"
        / "raw"
        / BATCHED_SELECTOR_STAGE
        / f"{_V50_INCOMPLETE_BATCH4_SELECTOR_REQUEST_SHA256}.json"
    )
    selector_raw = _read(
        selector_raw_path,
        location="incomplete v50 malformed Selector raw record",
    ).get("raw_response")
    if not isinstance(selector_raw, str):
        raise BatchedCriticPreregistrationError(
            "incomplete v50 malformed Selector response is absent"
        )
    try:
        json.loads(selector_raw)
    except json.JSONDecodeError:
        pass
    else:
        raise BatchedCriticPreregistrationError(
            "incomplete v50 Selector response is unexpectedly strict JSON"
        )
    try:
        repaired = json.loads(selector_raw.strip() + "}")
    except json.JSONDecodeError as error:
        raise BatchedCriticPreregistrationError(
            "incomplete v50 one-byte repair proof is invalid"
        ) from error
    semantic_tuples = tuple(
        (
            value.get("critical_step"),
            value.get("taxonomy_pair"),
            value.get("selected_hypothesis_id"),
        )
        for value in repaired.get("cases", ())
        if isinstance(value, Mapping)
    )
    if (
        not selector_raw.rstrip().endswith("}\n]")
        or semantic_tuples
        != (
            (6, "planning/constraint_ignorance", "H06"),
            (3, "action/format_error", "H03"),
            (27, "planning/inefficient_plan", "fresh"),
        )
    ):
        raise BatchedCriticPreregistrationError(
            "incomplete v50 whitespace-brace proof changed"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v50_whitespace_brace_full30_anchor",
        "profile": "full30",
        "cumulative_before": 587,
        "logical_completions_reserved": 7,
        "completed_provider_responses": 6,
        "cumulative_after": 594,
        "accepted": False,
        "failure_class": "whitespace_sensitive_missing_final_brace_repair",
        "partial_prediction_count": 11,
        "partial_status_counts": {"success": 8, "invalid_json": 3},
        "failed_batch_id": "Ba71d8dd9700fd30c5352",
        "selector_request_chars": 742_928,
        "selector_response_chars": 3_391,
        "syntax_only_repair": "append_one_final_object_close",
        "next_critic_http_started_then_interrupted": True,
        "next_critic_response_persisted": False,
        "batch4_selector_request_sha256": (
            _V50_INCOMPLETE_BATCH4_SELECTOR_REQUEST_SHA256
        ),
        "interrupted_critic_request_sha256": (
            _V50_INCOMPLETE_INTERRUPTED_CRITIC_REQUEST_SHA256
        ),
        "completed_provider_telemetry": expected_telemetry,
        "cache_state": dict(_V50_INCOMPLETE_CACHE_STATE),
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V50_INCOMPLETE_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "case_study": {
            "path": str(case_study),
            "file_sha256": _V50_INCOMPLETE_FAILURE_CASE_STUDY_SHA256,
        },
        "preregistration_sha256": _V50_INCOMPLETE_PREREGISTRATION_SHA256,
        "logical_completion_ledger_sha256": _V50_INCOMPLETE_LEDGER_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v50_incomplete_full30_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v50_incomplete_full30_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v51 incomplete-v50 full30 anchor changed after preregistration"
        )
    return expected


def _resolve_v51_rejected_full30_binding() -> dict[str, Any]:
    """Bind the completed v51 semantic failure before v52 is frozen."""

    return _resolve_recent_rejected_binding(
        label="v51 full30",
        role="rejected_v51_whitespace_brace_full30_anchor",
        run_relative_root=_V51_REJECTED_RUN_RELATIVE_ROOT,
        cache_relative_root=_V51_REJECTED_CACHE_RELATIVE_ROOT,
        file_hashes=_V51_REJECTED_FILE_SHA256,
        case_study_hashes={
            "semantic": (
                "docs/experiments/e9-v51-full30-failure-case-study.md",
                _V51_FAILURE_CASE_STUDY_SHA256,
            )
        },
        preregistration_sha256=_V51_REJECTED_PREREGISTRATION_SHA256,
        predict_run_sha256=_V51_REJECTED_PREDICT_RUN_SHA256,
        promotion_sha256=_V51_REJECTED_PROMOTION_SHA256,
        ledger_sha256=_V51_REJECTED_LEDGER_SHA256,
        cache_state=_V51_REJECTED_CACHE_STATE,
        profile="full30",
        cumulative_before=596,
        maximum_new=20,
        expected_summary={
            "trajectory_count": 30,
            "successful_prediction_count": 30,
            "failed_prediction_count": 0,
            "step_correct": 7,
            "step_module_correct": 3,
            "all_correct": 3,
        },
        expected_pipeline_version=(
            "e9-whitespace-brace-v51-deepseek-v4-flash-default"
        ),
        expected_critic_protocol=(
            "agentdebug-e9-candidate-v49-six-causal-lanes-source-id"
        ),
        expected_selector_protocol=(
            "agentdebug-e9-selector-v49-required-field-state-consistency-source-id"
        ),
        expected_token_totals={
            "input_tokens": 3_675_402,
            "output_tokens": 504_571,
            "total_tokens": 4_179_973,
        },
    )


def _validate_v51_rejected_full30_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v51_rejected_full30_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v52 rejected-v51 full30 anchor changed after preregistration"
        )
    return expected


def _resolve_v52_rejected_full30_binding() -> dict[str, Any]:
    """Bind the denominator-complete v52 recovery before v53 is frozen."""

    root = _repository_path(_V52_REJECTED_RUN_RELATIVE_ROOT)
    cache = _repository_path(_V52_REJECTED_CACHE_RELATIVE_ROOT)
    paths = {name: root / name for name in _V52_REJECTED_FILE_SHA256}
    case_study = _repository_path(
        "docs/experiments/e9-v52-recovered-full30-failure-case-study.md"
    )
    if (
        any(
            not path.is_file()
            or _file_sha256(path) != _V52_REJECTED_FILE_SHA256[name]
            for name, path in paths.items()
        )
        or not case_study.is_file()
        or _file_sha256(case_study) != _V52_FAILURE_CASE_STUDY_SHA256
        or _directory_state(cache) != _V52_REJECTED_CACHE_STATE
    ):
        raise BatchedCriticPreregistrationError(
            "authoritative rejected v52 recovery artifact bytes changed"
        )

    prereg = _validated_hashed_document(
        paths["preregistration.json"],
        location="rejected v52 recovery preregistration",
        hash_field="preregistration_sha256",
    )
    run = _validated_hashed_document(
        paths["predict-run.json"],
        location="rejected v52 recovery predict run",
        hash_field="predict_run_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion.json"],
        location="rejected v52 recovery promotion",
        hash_field="promotion_sha256",
    )
    metrics = _read(paths["metrics.json"], location="rejected v52 metrics")
    rows = _read_jsonl(
        paths["unscored-predictions.jsonl"],
        location="rejected v52 unscored predictions",
    )
    try:
        overall = metrics["metrics"]["by_method"][_V14_METHOD]["overall"]
    except (KeyError, TypeError) as error:
        raise BatchedCriticPreregistrationError(
            "rejected v52 metrics envelope is invalid"
        ) from error
    contract = prereg.get("recovery_contract")
    telemetry = run.get("provider_telemetry_current_run")
    checks = promotion.get("checks")
    expected_tokens = {
        "input_tokens": 1_602_677,
        "output_tokens": 146_048,
        "total_tokens": 1_748_725,
    }
    if (
        prereg.get("preregistration_sha256")
        != _V52_REJECTED_PREREGISTRATION_SHA256
        or prereg.get("semantic_change") is not False
        or prereg.get("gold_access_before_raw_validation") is not False
        or prereg.get("sole_final_semantics") != "raw_selector_final_fields"
        or prereg.get("deterministic_root_fallback") is not False
        or prereg.get("confidence_score_weight_vote") is not False
        or not isinstance(contract, Mapping)
        or contract.get("cumulative_before") != 632
        or contract.get("maximum_new") != 8
        or contract.get("first_batch_index") != 8
        or run.get("predict_run_sha256") != _V52_REJECTED_PREDICT_RUN_SHA256
        or run.get("preregistration_sha256")
        != _V52_REJECTED_PREREGISTRATION_SHA256
        or run.get("pipeline_version")
        != "e9-module-census-v52-deepseek-v4-flash-default"
        or run.get("critic_prompt_protocol_version")
        != "agentdebug-e9-candidate-v52-module-local-census-source-id"
        or run.get("selector_prompt_protocol_version")
        != "agentdebug-e9-selector-v52-likely-cascade-first-error-source-id"
        or run.get("prediction_count") != 30
        or run.get("logical_completion_budget_used") != 8
        or run.get("semantic_mutation_count") != 0
        or run.get("unscored_predictions_sha256")
        != _V52_REJECTED_FILE_SHA256["unscored-predictions.jsonl"]
        or not isinstance(telemetry, Mapping)
        or telemetry.get("logical_completion_count") != 8
        or telemetry.get("http_attempt_count") != 8
        or telemetry.get("retry_count") != 0
        or telemetry.get("provider_usage_token_totals") != expected_tokens
        or promotion.get("promotion_sha256") != _V52_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or not isinstance(checks, Mapping)
        or checks.get("step_exact_minimum_correct") is not False
        or checks.get("step_module_exact_minimum_correct") is not True
        or checks.get("all_correct_minimum") is not True
        or checks.get("raw_selector_final") is not True
        or overall.get("trajectory_count") != 30
        or overall.get("successful_prediction_count") != 30
        or overall.get("failed_prediction_count") != 0
        or overall.get("step_exact", {}).get("correct") != 9
        or overall.get("step_module_exact", {}).get("correct") != 5
        or overall.get("all_correct", {}).get("correct") != 4
        or Counter(row.get("status") for row in rows) != Counter({"success": 30})
        or any(
            row.get("semantic_classifier")
            != "raw_independent_batch_selector_output"
            or row.get("pipeline_version")
            != "e9-module-census-v52-deepseek-v4-flash-default"
            for row in rows
        )
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v52 recovery is not the authoritative semantic anchor"
        )
    ledger = load_fresh_semantic_completion_ledger(
        paths["logical-completion-ledger.json"],
        preregistration_sha256=_V52_REJECTED_PREREGISTRATION_SHA256,
        cumulative_before=632,
        maximum_new=8,
        authorized_cumulative_ceiling=640,
        allowed_stages=[BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE],
    )
    expected_stage_order = [
        stage
        for _batch in range(4)
        for stage in (BATCHED_CRITIC_STAGE, BATCHED_SELECTOR_STAGE)
    ]
    if (
        ledger.get("ledger_sha256") != _V52_REJECTED_LEDGER_SHA256
        or [entry.get("stage") for entry in ledger.get("entries", ())]
        != expected_stage_order
    ):
        raise BatchedCriticPreregistrationError(
            "rejected v52 recovery ledger authority changed"
        )
    binding: dict[str, Any] = {
        "role": "rejected_v52_recovered_module_census_full30_anchor",
        "profile": "full30",
        "cumulative_before": 616,
        "dry3_reservations": 2,
        "interrupted_full30_reservations": 14,
        "recovery_logical_completions": 8,
        "cumulative_after": 640,
        "accepted": False,
        "summary": {
            "trajectory_count": 30,
            "successful_prediction_count": 30,
            "failed_prediction_count": 0,
            "step_correct": 9,
            "step_module_correct": 5,
            "all_correct": 4,
        },
        "pipeline_version": run["pipeline_version"],
        "critic_prompt_protocol_version": run[
            "critic_prompt_protocol_version"
        ],
        "selector_prompt_protocol_version": run[
            "selector_prompt_protocol_version"
        ],
        "recovery_provider_usage_token_totals": expected_tokens,
        "cache_state": dict(_V52_REJECTED_CACHE_STATE),
        "artifacts": {
            name: {
                "path": str(path),
                "file_sha256": _V52_REJECTED_FILE_SHA256[name],
            }
            for name, path in paths.items()
        },
        "case_study": {
            "path": str(case_study),
            "file_sha256": _V52_FAILURE_CASE_STUDY_SHA256,
        },
        "preregistration_sha256": _V52_REJECTED_PREREGISTRATION_SHA256,
        "predict_run_sha256": _V52_REJECTED_PREDICT_RUN_SHA256,
        "promotion_sha256": _V52_REJECTED_PROMOTION_SHA256,
        "logical_completion_ledger_sha256": _V52_REJECTED_LEDGER_SHA256,
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding


def _validate_v52_rejected_full30_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v52_rejected_full30_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v53 rejected-v52 full30 anchor changed after preregistration"
        )
    return expected


def _resolve_v53_rejected_dry3_binding() -> dict[str, Any]:
    """Bind the completed v53 dual-timescale semantic rejection through 642."""

    return _resolve_recent_rejected_binding(
        label="v53 dry3",
        role="rejected_v53_flash_dual_timescale_planning_dry3_anchor",
        run_relative_root=_V53_REJECTED_RUN_RELATIVE_ROOT,
        cache_relative_root=_V53_REJECTED_CACHE_RELATIVE_ROOT,
        file_hashes=_V53_REJECTED_FILE_SHA256,
        case_study_hashes={
            "freeze_invocation": (
                "docs/experiments/e9-v53-freeze-python-command-failure-case-study.md",
                "8c7e3cd6cf0269e67d54102803b9a6f2b796984e1380bcb4907b5fd8eacccce8",
            ),
            "runtime_path": (
                "docs/experiments/e9-v53-dry3-runtime-path-failure-case-study.md",
                "4eba02c7ac59e0bdcca2b59a4664e5aa9cb1eb442286da4ba2b4c64772d83465",
            ),
            "semantic": (
                "docs/experiments/e9-v53-dry3-semantic-failure-case-study.md",
                "49435e8bdb570c578f78208d38319a2a17f100e774d336eb606b380e1ee1efb0",
            ),
        },
        preregistration_sha256=_V53_REJECTED_PREREGISTRATION_SHA256,
        predict_run_sha256=_V53_REJECTED_PREDICT_RUN_SHA256,
        promotion_sha256=_V53_REJECTED_PROMOTION_SHA256,
        ledger_sha256=_V53_REJECTED_LEDGER_SHA256,
        cache_state=_V53_REJECTED_CACHE_STATE,
        profile="dry3",
        cumulative_before=640,
        maximum_new=2,
        expected_summary={
            "trajectory_count": 3,
            "successful_prediction_count": 3,
            "failed_prediction_count": 0,
            "step_correct": 2,
            "step_module_correct": 2,
            "all_correct": 2,
        },
        expected_pipeline_version=(
            "e9-dual-timescale-planning-v53-deepseek-v4-flash-default"
        ),
        expected_critic_protocol=(
            "agentdebug-e9-candidate-v53-dual-timescale-planning-source-id"
        ),
        expected_selector_protocol=(
            "agentdebug-e9-selector-v52-likely-cascade-first-error-source-id"
        ),
        expected_token_totals={
            "input_tokens": 383_972,
            "output_tokens": 33_857,
            "total_tokens": 417_829,
        },
        expected_predictions=(
            (30, "system", "step_limit"),
            (1, "action", "misalignment"),
            (2, "planning", "inefficient_plan"),
        ),
    )


def _validate_v53_rejected_dry3_binding(value: Any) -> dict[str, Any]:
    expected = _resolve_v53_rejected_dry3_binding()
    if value != expected:
        raise BatchedCriticPreregistrationError(
            "v54 rejected-v53 dry3 anchor changed after preregistration"
        )
    return expected


def _bind_file(path: Path, *, content_sha256: str | None = None) -> dict[str, Any]:
    value = {
        "path": str(path),
        "file_sha256": _file_sha256(path),
    }
    if content_sha256 is not None:
        value["content_sha256"] = content_sha256
    return value


def _validate_frozen_upstream(
    *,
    profile: str,
    prediction_manifest: Mapping[str, Any],
    manifest_ids: Sequence[str],
    current_plan: Mapping[str, Any],
    current_batches: Sequence[Any],
    current_plan_binding: Mapping[str, Any],
    source_batch_plan_path: str | Path | None,
    v13_predecessor_manifest_path: str | Path | None,
    source_cache_dir: str | Path | None,
    fresh_upstream_cache_dir: str | Path | None,
    critic_cache_dir: Path,
) -> dict[str, Any]:
    if (
        source_batch_plan_path is None
        or v13_predecessor_manifest_path is None
        or source_cache_dir is None
        or fresh_upstream_cache_dir is not None
    ):
        raise BatchedCriticPreregistrationError(
            "frozen v14 tuning requires only source plan, predecessor, and "
            "read-only source cache"
        )
    source_plan_path = Path(source_batch_plan_path).expanduser().resolve()
    predecessor_path = Path(
        v13_predecessor_manifest_path
    ).expanduser().resolve()
    source_cache = Path(source_cache_dir).expanduser().resolve()
    if not _paths_are_disjoint(source_cache, critic_cache_dir):
        raise BatchedCriticPreregistrationError(
            "v13 source and v14 Critic caches must be disjoint"
        )
    source_plan, source_batches = _load_batch_plan(source_plan_path)
    source_binding = _validate_batch_plan_binding(
        plan=source_plan,
        batches=source_batches,
        selected_ids=manifest_ids,
    )
    if (
        source_binding["batch_count"] != 11
        or source_plan.get("prediction_manifest_sha256")
        != prediction_manifest.get("prediction_manifest_sha256")
        or source_binding["execution_trajectory_ids"][:3]
        != list(V14_DRY3_IDS_MANIFEST_ORDER)
    ):
        raise BatchedCriticPreregistrationError(
            "frozen v13 source must be the unique full eleven-batch tuning plan"
        )
    if profile == "dry3":
        if (
            current_plan_binding["batch_count"] != 1
            or current_plan_binding["batch_identities"]
            != source_binding["batch_identities"][:1]
            or current_plan_binding["batch_memberships"]
            != source_binding["batch_memberships"][:1]
            or current_plan_binding["ordered_case_input_sha256s"]
            != source_binding["ordered_case_input_sha256s"][:1]
            or source_binding["required_prefix_batch_plan_sha256"]
            != current_plan_binding["content_sha256"]
        ):
            raise BatchedCriticPreregistrationError(
                "v14 dry plan is not the exact first batch of the full source"
            )
    elif profile == "full30":
        if current_plan_binding != source_binding or current_plan != source_plan:
            raise BatchedCriticPreregistrationError(
                "v14 full plan is not byte-semantically identical to source"
            )
    else:
        raise BatchedCriticPreregistrationError(
            "frozen v13 upstream is permitted only for tuning"
        )
    loader = getattr(_workflow(), "load_frozen_v13_predecessor", None)
    if not callable(loader):
        raise BatchedCriticPreregistrationError(
            "v14 workflow cannot verify the frozen v13 predecessor"
        )
    try:
        predecessor = loader(
            predecessor_path,
            source_cache_dir=source_cache,
            prediction_manifest_sha256=prediction_manifest[
                "prediction_manifest_sha256"
            ],
            batch_plan_sha256=source_binding["content_sha256"],
        )
    except (OSError, TypeError, ValueError) as error:
        raise BatchedCriticPreregistrationError(
            "frozen v13 predecessor validation failed"
        ) from error
    document = getattr(predecessor, "document", None)
    if not isinstance(document, Mapping):
        raise BatchedCriticPreregistrationError(
            "frozen v13 predecessor loader returned an invalid object"
        )
    source_state = _directory_state(source_cache)
    if (
        document.get("batch_count") != 11
        or document.get("batch_plan_sha256")
        != source_binding["content_sha256"]
        or document.get("prediction_manifest_sha256")
        != prediction_manifest["prediction_manifest_sha256"]
        or document.get("source_cache_state") != source_state
        or source_state.get("file_count") != _V13_SOURCE_CACHE_FILE_COUNT
        or source_state.get("files_sha256")
        != _V13_SOURCE_CACHE_FILES_SHA256
    ):
        raise BatchedCriticPreregistrationError(
            "frozen v13 predecessor/source cache is not authoritative full30"
        )
    return {
        "mode": V14_FROZEN_V13_TUNING,
        "source_batch_plan": {
            **_bind_file(
                source_plan_path,
                content_sha256=source_binding["content_sha256"],
            ),
            "batch_count": source_binding["batch_count"],
            "batch_identities": source_binding["batch_identities"],
            "batch_memberships": source_binding["batch_memberships"],
        },
        "predecessor_manifest": _bind_file(
            predecessor_path,
            content_sha256=document["predecessor_manifest_sha256"],
        ),
        "source_cache": {
            "path": str(source_cache),
            "state": source_state,
            "read_only": True,
        },
        "fresh_upstream_cache": None,
    }


def _validate_fresh_upstream(
    *,
    profile: str,
    source_batch_plan_path: str | Path | None,
    v13_predecessor_manifest_path: str | Path | None,
    source_cache_dir: str | Path | None,
    fresh_upstream_cache_dir: str | Path | None,
    critic_cache_dir: Path,
) -> dict[str, Any]:
    if (
        profile != "smoke30"
        or source_batch_plan_path is not None
        or v13_predecessor_manifest_path is not None
        or source_cache_dir is not None
        or fresh_upstream_cache_dir is None
    ):
        raise BatchedCriticPreregistrationError(
            "fresh smoke forbids every frozen-v13 predecessor input"
        )
    fresh_cache = Path(fresh_upstream_cache_dir).expanduser().resolve()
    if not _paths_are_disjoint(fresh_cache, critic_cache_dir):
        raise BatchedCriticPreregistrationError(
            "fresh upstream and Critic caches must be disjoint"
        )
    fresh_state = _directory_state(fresh_cache)
    critic_state = _directory_state(critic_cache_dir)
    if fresh_state["file_count"] != 0 or critic_state["file_count"] != 0:
        raise BatchedCriticPreregistrationError(
            "held-out smoke requires empty fresh upstream and Critic caches"
        )
    return {
        "mode": V14_FRESH_FOUR_STAGE_SMOKE,
        "source_batch_plan": None,
        "predecessor_manifest": None,
        "source_cache": None,
        "fresh_upstream_cache": {
            "path": str(fresh_cache),
            "state": fresh_state,
            "read_only": False,
        },
    }


def _resolve_upstream_binding(
    *,
    profile: str,
    upstream_mode: str,
    prediction_manifest: Mapping[str, Any],
    manifest_ids: Sequence[str],
    current_plan: Mapping[str, Any],
    current_batches: Sequence[Any],
    current_plan_binding: Mapping[str, Any],
    source_batch_plan_path: str | Path | None,
    v13_predecessor_manifest_path: str | Path | None,
    source_cache_dir: str | Path | None,
    fresh_upstream_cache_dir: str | Path | None,
    critic_cache_dir: Path,
) -> dict[str, Any]:
    if upstream_mode == V14_FROZEN_V13_TUNING:
        return _validate_frozen_upstream(
            profile=profile,
            prediction_manifest=prediction_manifest,
            manifest_ids=manifest_ids,
            current_plan=current_plan,
            current_batches=current_batches,
            current_plan_binding=current_plan_binding,
            source_batch_plan_path=source_batch_plan_path,
            v13_predecessor_manifest_path=v13_predecessor_manifest_path,
            source_cache_dir=source_cache_dir,
            fresh_upstream_cache_dir=fresh_upstream_cache_dir,
            critic_cache_dir=critic_cache_dir,
        )
    if upstream_mode == V14_FRESH_FOUR_STAGE_SMOKE:
        return _validate_fresh_upstream(
            profile=profile,
            source_batch_plan_path=source_batch_plan_path,
            v13_predecessor_manifest_path=v13_predecessor_manifest_path,
            source_cache_dir=source_cache_dir,
            fresh_upstream_cache_dir=fresh_upstream_cache_dir,
            critic_cache_dir=critic_cache_dir,
        )
    raise BatchedCriticPreregistrationError(
        "v14 upstream mode is unsupported"
    )


def _phase_identity(profile: str) -> tuple[int, str | None]:
    values = {
        "dry3": (1, None),
        "full30": (2, "dry3"),
        "smoke30": (3, "full30"),
    }
    if profile not in values:
        raise BatchedCriticPreregistrationError(
            "v14 authorization profile is unsupported"
        )
    return values[profile]


def _authorization_directory(
    *,
    profile: str,
    requested: str | Path | None,
    run_output_dir: Path,
) -> Path:
    formal = _repository_path(V14_AUTHORIZATION_CHAIN_RELATIVE_PATH)
    if profile in _FORMAL_PROFILES:
        resolved = formal if requested is None else Path(requested).resolve()
        if resolved != formal:
            raise BatchedCriticPreregistrationError(
                "formal v14 runs require the fixed authorization chain"
            )
        return resolved
    return (
        run_output_dir.parent / ".e9-v14-test-authorization-chain"
        if requested is None
        else Path(requested).expanduser().resolve()
    )


def _claim_path(directory: Path, *, profile: str) -> Path:
    return directory / f"{_phase_identity(profile)[0]:02d}-{profile}.json"


def _claim_for_preregistration(
    document: Mapping[str, Any],
) -> dict[str, Any]:
    evaluation = document["evaluation"]
    budget = document["logical_completion_budget"]
    authorization = document["authorization_chain"]
    claim: dict[str, Any] = {
        "schema_version": V14_AUTHORIZATION_CLAIM_SCHEMA_VERSION,
        "ordinal": authorization["ordinal"],
        "profile": evaluation["profile"],
        "upstream_mode": evaluation["upstream_mode"],
        "preregistration_path": document["preregistration_path"],
        "preregistration_sha256": document["preregistration_sha256"],
        "cumulative_before": budget["cumulative_before"],
        "maximum_new": budget["maximum_new"],
        "hard_cumulative_stop": budget["hard_cumulative_stop"],
        "authorized_cumulative_ceiling": budget[
            "authorized_cumulative_ceiling"
        ],
        "predecessor_claim_sha256": authorization[
            "predecessor_claim_sha256"
        ],
    }
    claim["claim_sha256"] = stable_sha256(claim)
    return claim


def _read_claim(path: Path, *, expected_profile: str) -> dict[str, Any]:
    claim = _validated_hashed_document(
        path,
        location="v14 authorization claim",
        hash_field="claim_sha256",
    )
    if (
        claim.get("schema_version") != V14_AUTHORIZATION_CLAIM_SCHEMA_VERSION
        or claim.get("profile") != expected_profile
        or claim.get("ordinal") != _phase_identity(expected_profile)[0]
    ):
        raise BatchedCriticPreregistrationError(
            "v14 authorization claim identity is invalid"
        )
    return claim


def _provider_identity_without_cohort(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, Mapping):
        return None
    result = dict(value)
    result.pop("cohort_sha256", None)
    return result


def _resolve_phase_predecessor(
    *,
    profile: str,
    authorization_dir: Path,
    current_code_bundle: Mapping[str, str],
    current_code_bundle_archive: Mapping[str, Any],
    config: BenchmarkRunConfig,
    upstream_binding: Mapping[str, Any],
    critic_cache_initial_state: Mapping[str, Any],
) -> tuple[dict[str, Any] | None, str | None]:
    _, predecessor_profile = _phase_identity(profile)
    if predecessor_profile is None:
        return None, None
    claim_path = _claim_path(authorization_dir, profile=predecessor_profile)
    claim = _read_claim(claim_path, expected_profile=predecessor_profile)
    prereg_path = Path(str(claim["preregistration_path"])).resolve()
    prereg = _validated_hashed_document(
        prereg_path,
        location="v14 predecessor preregistration",
        hash_field="preregistration_sha256",
    )
    if _claim_for_preregistration(prereg) != claim:
        raise BatchedCriticPreregistrationError(
            "v14 predecessor claim does not bind its preregistration"
        )
    execution = prereg.get("execution")
    budget = prereg.get("logical_completion_budget")
    if not isinstance(execution, Mapping) or not isinstance(budget, Mapping):
        raise BatchedCriticPreregistrationError(
            "v14 predecessor preregistration envelope is invalid"
        )
    promotion_path = Path(str(execution["run_output_dir"])) / "promotion.json"
    promotion = _validated_hashed_document(
        promotion_path,
        location="v14 predecessor promotion",
        hash_field="promotion_sha256",
    )
    checks = promotion.get("checks")
    if (
        prereg.get("schema_version") != V14_PREREGISTRATION_SCHEMA_VERSION
        or prereg.get("code_bundle") != dict(current_code_bundle)
        or prereg.get("code_bundle_sha256")
        != stable_sha256(dict(current_code_bundle))
        or prereg.get("code_bundle_archive")
        != dict(current_code_bundle_archive)
        or _provider_identity_without_cohort(prereg.get("provider_config"))
        != _provider_identity_without_cohort(config.public_dict())
        or promotion.get("schema_version") != V14_PROMOTION_SCHEMA_VERSION
        or promotion.get("accepted") is not True
        or not isinstance(checks, Mapping)
        or not checks
        or not all(value is True for value in checks.values())
        or promotion.get("preregistration_sha256")
        != prereg.get("preregistration_sha256")
        or budget.get("hard_cumulative_stop")
        != _expected_budget(profile, batch_count=_profile_contract(profile)["batch_count"])[0]
    ):
        raise BatchedCriticPreregistrationError(
            "v14 predecessor phase was not accepted under the same candidate"
        )
    if profile == "full30":
        if (
            prereg.get("upstream") != dict(upstream_binding)
            or promotion.get("critic_cache_final_state")
            != dict(critic_cache_initial_state)
        ):
            raise BatchedCriticPreregistrationError(
                "v14 full must reuse only dry's identical predecessor and "
                "first Critic batch"
            )
    elif profile == "smoke30":
        if (
            prereg.get("evaluation", {}).get("profile") != "full30"
            or prereg.get("evaluation", {}).get("upstream_mode")
            != V14_FROZEN_V13_TUNING
        ):
            raise BatchedCriticPreregistrationError(
                "v14 smoke requires the accepted full tuning candidate"
            )
    binding: dict[str, Any] = {
        "profile": predecessor_profile,
        "claim_path": str(claim_path),
        "claim_file_sha256": _file_sha256(claim_path),
        "claim_sha256": claim["claim_sha256"],
        "preregistration_path": str(prereg_path),
        "preregistration_file_sha256": _file_sha256(prereg_path),
        "preregistration_sha256": prereg["preregistration_sha256"],
        "promotion_path": str(promotion_path),
        "promotion_file_sha256": _file_sha256(promotion_path),
        "promotion_sha256": promotion["promotion_sha256"],
        "cumulative_after": budget["hard_cumulative_stop"],
    }
    binding["binding_sha256"] = stable_sha256(binding)
    return binding, claim["claim_sha256"]


def _ledger_lock_path(path: Path) -> Path:
    return path.with_suffix(f"{path.suffix}.lock")


def _load_ledger(
    *,
    execution: Mapping[str, Any],
    budget: Mapping[str, Any],
    preregistration_sha256: str,
) -> dict[str, Any]:
    allowed = execution.get("live_stages")
    if not isinstance(allowed, list) or not allowed:
        raise BatchedCriticPreregistrationError(
            "v14 live-stage ledger policy is invalid"
        )
    try:
        return load_fresh_semantic_completion_ledger(
            execution["logical_completion_ledger_path"],
            preregistration_sha256=preregistration_sha256,
            cumulative_before=budget["cumulative_before"],
            maximum_new=budget["maximum_new"],
            authorized_cumulative_ceiling=budget[
                "authorized_cumulative_ceiling"
            ],
            allowed_stages=allowed,
        )
    except (OSError, TypeError, ValueError) as error:
        raise BatchedCriticPreregistrationError(
            "v14 logical-completion ledger is invalid"
        ) from error


def write_batched_critic_preregistration(
    *,
    experiment_name: str,
    evaluation_profile: str,
    upstream_mode: str,
    dataset_path: str | Path,
    cohort_manifest_path: str | Path,
    prediction_manifest_path: str | Path,
    batch_plan_path: str | Path,
    source_batch_plan_path: str | Path | None = None,
    v13_predecessor_manifest_path: str | Path | None = None,
    source_cache_dir: str | Path | None = None,
    fresh_upstream_cache_dir: str | Path | None = None,
    code_bundle_archive_path: str | Path,
    output_path: str | Path,
    run_output_dir: str | Path,
    critic_cache_dir: str | Path,
    config: BenchmarkRunConfig,
    selected_trajectory_ids: Sequence[str],
    selection_rule: str,
    hypothesis: str,
    promotion_gate: Mapping[str, Any],
    cumulative_logical_completions_before: int,
    maximum_new_logical_completions: int,
    authorized_cumulative_ceiling: int | None = None,
    authorization_chain_dir: str | Path | None = None,
) -> dict[str, Any]:
    """Freeze v14 identity and initialize its durable budget ledger."""

    for name, value in (
        ("experiment_name", experiment_name),
        ("selection_rule", selection_rule),
        ("hypothesis", hypothesis),
    ):
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"{name} must be non-empty text")
    selected = [str(value) for value in selected_trajectory_ids]
    if (
        not selected
        or any(not value for value in selected)
        or len(set(selected)) != len(selected)
    ):
        raise ValueError("selected trajectory IDs must be unique and non-empty")
    if not isinstance(promotion_gate, Mapping) or not promotion_gate:
        raise ValueError("v14 promotion gate must be a non-empty object")
    gate = dict(promotion_gate)
    if set(gate) - _SUPPORTED_GATE_FIELDS:
        raise ValueError("v14 promotion gate contains unsupported fields")
    if not isinstance(config, BenchmarkRunConfig) or not config.api_key_env:
        raise ValueError(
            "v14 preregistration requires a public BenchmarkRunConfig"
        )
    _validate_formal_provider_config(
        profile=evaluation_profile,
        config=config,
    )

    prediction_path = Path(prediction_manifest_path).expanduser().resolve()
    plan_path = Path(batch_plan_path).expanduser().resolve()
    cohort_path = Path(cohort_manifest_path).expanduser().resolve()
    dataset_resolved = Path(dataset_path).expanduser().resolve()
    destination = Path(output_path).expanduser().resolve()
    run_output = Path(run_output_dir).expanduser().resolve()
    critic_cache = Path(critic_cache_dir).expanduser().resolve()
    prediction, cases = load_prediction_manifest(prediction_path)
    cohort = _load_gold_free_cohort_header(cohort_path)
    plan, batches = _load_batch_plan(plan_path)
    manifest_ids = [case.trajectory_id for case in cases]
    selected_set = set(selected)
    if selected != [value for value in manifest_ids if value in selected_set]:
        # Dry execution order is a frozen exception: its IDs are deliberately
        # the first source batch rather than contiguous manifest order.
        if evaluation_profile != "dry3" or tuple(selected) != V14_DRY3_IDS_MANIFEST_ORDER:
            raise BatchedCriticPreregistrationError(
                "selected IDs must follow the frozen profile order"
            )
    plan_binding = _validate_batch_plan_binding(
        plan=plan,
        batches=batches,
        selected_ids=selected,
    )
    contract = _validate_profile_binding(
        profile=evaluation_profile,
        upstream_mode=upstream_mode,
        cohort=cohort,
        manifest=prediction,
        manifest_ids=manifest_ids,
        selected_ids=selected,
        gate=gate,
        plan_binding=plan_binding,
    )
    if (
        config.cohort_sha256 != prediction["cohort_sha256"]
        or prediction["dataset_manifest_sha256"]
        != cohort["dataset_manifest_sha256"]
        or plan.get("prediction_manifest_sha256")
        != prediction["prediction_manifest_sha256"]
    ):
        raise BatchedCriticPreregistrationError(
            "v14 input/provider/cohort lineage is invalid"
        )
    expected_before, expected_maximum = _expected_budget(
        evaluation_profile,
        batch_count=plan_binding["batch_count"],
    )
    if (
        cumulative_logical_completions_before != expected_before
        or maximum_new_logical_completions != expected_maximum
    ):
        raise BatchedCriticPreregistrationError(
            "v14 requested budget differs from the exact frozen topology"
        )
    hard_stop = expected_before + expected_maximum
    # Cumulative user authorization is unbounded from v25 onward.  A legacy
    # caller may still supply a value, but it can only confirm that this
    # phase's topology-derived hard stop fits; it never creates a global cap.
    if authorized_cumulative_ceiling is not None and (
        isinstance(authorized_cumulative_ceiling, bool)
        or not isinstance(authorized_cumulative_ceiling, int)
        or authorized_cumulative_ceiling < hard_stop
    ):
        raise BatchedCriticPreregistrationError(
            "v14 logical-completion budget arithmetic is invalid"
        )
    authorized_cumulative_ceiling = hard_stop

    code_bundle = _current_code_bundle()
    code_bundle_archive = verify_batched_critic_code_bundle_archive(
        code_bundle_archive_path
    )
    workflow_contract = _workflow_contract()
    upstream = _resolve_upstream_binding(
        profile=evaluation_profile,
        upstream_mode=upstream_mode,
        prediction_manifest=prediction,
        manifest_ids=manifest_ids,
        current_plan=plan,
        current_batches=batches,
        current_plan_binding=plan_binding,
        source_batch_plan_path=source_batch_plan_path,
        v13_predecessor_manifest_path=v13_predecessor_manifest_path,
        source_cache_dir=source_cache_dir,
        fresh_upstream_cache_dir=fresh_upstream_cache_dir,
        critic_cache_dir=critic_cache,
    )
    critic_initial = _directory_state(critic_cache)
    if evaluation_profile in {"dry3", "smoke30"} and critic_initial[
        "file_count"
    ] != 0:
        raise BatchedCriticPreregistrationError(
            "v14 dry and smoke require a fresh Critic cache"
        )
    rejected_v13 = _resolve_v13_rejected_run_binding()
    rejected_v14_transport = _resolve_v14_rejected_transport_binding()
    rejected_v15_json = _resolve_v15_rejected_json_binding()
    rejected_v16_json = _resolve_v16_rejected_json_binding()
    rejected_v17_semantic = _resolve_v17_rejected_semantic_binding()
    rejected_v18_malformed = _resolve_v18_rejected_malformed_binding()
    rejected_v19_semantic = _resolve_v19_rejected_semantic_binding()
    rejected_v20_semantic = _resolve_v20_rejected_semantic_binding()
    rejected_v21_semantic = _resolve_v21_rejected_semantic_binding()
    rejected_v22_semantic = _resolve_v22_rejected_semantic_binding()
    rejected_v23_empty = _resolve_v23_rejected_empty_content_binding()
    rejected_v24_full = _resolve_v24_rejected_full30_binding()
    rejected_v25_full = _resolve_v25_rejected_full30_binding()
    rejected_v26_dry = _resolve_v26_rejected_dry3_binding()
    rejected_v27_full = _resolve_v27_rejected_full30_binding()
    rejected_v28_dry = _resolve_v28_rejected_dry3_binding()
    rejected_v29_full = _resolve_v29_rejected_full30_binding()
    rejected_v30_full = _resolve_v30_rejected_full30_binding()
    rejected_v31_incomplete = _resolve_v31_incomplete_full30_binding()
    rejected_v32_dry = _resolve_v32_rejected_dry3_binding()
    rejected_v33_dry = _resolve_v33_rejected_dry3_binding()
    rejected_v34_incomplete = _resolve_v34_incomplete_full30_binding()
    rejected_v35_full = _resolve_v35_rejected_full30_binding()
    rejected_v36_dry = _resolve_v36_rejected_dry3_binding()
    rejected_v37_dry = _resolve_v37_rejected_dry3_binding()
    rejected_v38_full = _resolve_v38_rejected_full30_binding()
    rejected_v39_dry = _resolve_v39_rejected_dry3_binding()
    rejected_v40_full = _resolve_v40_rejected_full30_binding()
    rejected_v41_dry = _resolve_v41_rejected_dry3_binding()
    rejected_v42_dry = _resolve_v42_rejected_dry3_binding()
    rejected_v43_dry = _resolve_v43_rejected_dry3_binding()
    rejected_v44_dry = _resolve_v44_rejected_dry3_binding()
    rejected_v45_dry = _resolve_v45_rejected_dry3_binding()
    rejected_v46_full = _resolve_v46_rejected_full30_binding()
    rejected_v47_dry = _resolve_v47_rejected_dry3_binding()
    rejected_v48_dry = _resolve_v48_rejected_dry3_binding()
    rejected_v49_incomplete = _resolve_v49_incomplete_full30_binding()
    rejected_v50_incomplete = _resolve_v50_incomplete_full30_binding()
    rejected_v51_full = _resolve_v51_rejected_full30_binding()
    rejected_v52_full = _resolve_v52_rejected_full30_binding()
    rejected_v53_dry = _resolve_v53_rejected_dry3_binding()
    authorization_dir = _authorization_directory(
        profile=evaluation_profile,
        requested=authorization_chain_dir,
        run_output_dir=run_output,
    )
    phase_predecessor, predecessor_claim_sha256 = (
        _resolve_phase_predecessor(
            profile=evaluation_profile,
            authorization_dir=authorization_dir,
            current_code_bundle=code_bundle,
            current_code_bundle_archive=code_bundle_archive,
            config=config,
            upstream_binding=upstream,
            critic_cache_initial_state=critic_initial,
        )
    )
    _validate_phase_budget(
        profile=evaluation_profile,
        batch_count=plan_binding["batch_count"],
        cumulative_before=expected_before,
        maximum_new=expected_maximum,
        hard_cumulative_stop=hard_stop,
        authorized_cumulative_ceiling=authorized_cumulative_ceiling,
        predecessor_cumulative_after=(
            None
            if phase_predecessor is None
            else phase_predecessor["cumulative_after"]
        ),
    )

    claim_path = _claim_path(authorization_dir, profile=evaluation_profile)
    ledger_path = run_output / "logical-completion-ledger.json"
    ledger_lock_path = _ledger_lock_path(ledger_path)
    run_initial = _directory_state(
        run_output,
        excluded_paths=(
            destination,
            ledger_path,
            ledger_lock_path,
            code_bundle_archive["path"],
        ),
    )
    if run_initial["file_count"] != 0:
        raise BatchedCriticPreregistrationError(
            "v14 formal run output directory must start empty"
        )
    if (
        (ledger_path.is_file() or ledger_lock_path.is_file())
        and not destination.is_file()
    ):
        raise BatchedCriticPreregistrationError(
            "v14 logical-completion ledger path is not fresh"
        )
    live_stages = (
        list(V14_TUNING_STAGES)
        if upstream_mode == V14_FROZEN_V13_TUNING
        else list(V14_SMOKE_STAGES)
    )
    document: dict[str, Any] = {
        "schema_version": V14_PREREGISTRATION_SCHEMA_VERSION,
        "preregistration_path": str(destination),
        "authorization_chain": {
            "directory": str(authorization_dir),
            "claim_path": str(claim_path),
            "ordinal": _phase_identity(evaluation_profile)[0],
            "predecessor_claim_sha256": predecessor_claim_sha256,
        },
        "phase_predecessor": phase_predecessor,
        "rejected_v13_anchor": rejected_v13,
        "rejected_v14_transport_anchor": rejected_v14_transport,
        "rejected_v15_json_anchor": rejected_v15_json,
        "rejected_v16_json_anchor": rejected_v16_json,
        "rejected_v17_semantic_anchor": rejected_v17_semantic,
        "rejected_v18_malformed_anchor": rejected_v18_malformed,
        "rejected_v19_semantic_anchor": rejected_v19_semantic,
        "rejected_v20_semantic_anchor": rejected_v20_semantic,
        "rejected_v21_semantic_anchor": rejected_v21_semantic,
        "rejected_v22_semantic_anchor": rejected_v22_semantic,
        "rejected_v23_empty_content_anchor": rejected_v23_empty,
        "rejected_v24_full30_anchor": rejected_v24_full,
        "rejected_v25_full30_anchor": rejected_v25_full,
        "rejected_v26_dry3_anchor": rejected_v26_dry,
        "rejected_v27_full30_anchor": rejected_v27_full,
        "rejected_v28_dry3_anchor": rejected_v28_dry,
        "rejected_v29_full30_anchor": rejected_v29_full,
        "rejected_v30_full30_anchor": rejected_v30_full,
        "rejected_v31_incomplete_full30_anchor": rejected_v31_incomplete,
        "rejected_v32_dry3_anchor": rejected_v32_dry,
        "rejected_v33_dry3_anchor": rejected_v33_dry,
        "rejected_v34_incomplete_full30_anchor": rejected_v34_incomplete,
        "rejected_v35_full30_anchor": rejected_v35_full,
        "rejected_v36_dry3_anchor": rejected_v36_dry,
        "rejected_v37_dry3_anchor": rejected_v37_dry,
        "rejected_v38_full30_anchor": rejected_v38_full,
        "rejected_v39_dry3_anchor": rejected_v39_dry,
        "rejected_v40_full30_anchor": rejected_v40_full,
        "rejected_v41_dry3_anchor": rejected_v41_dry,
        "rejected_v42_dry3_anchor": rejected_v42_dry,
        "rejected_v43_dry3_anchor": rejected_v43_dry,
        "rejected_v44_dry3_anchor": rejected_v44_dry,
        "rejected_v45_dry3_anchor": rejected_v45_dry,
        "rejected_v46_full30_anchor": rejected_v46_full,
        "rejected_v47_dry3_anchor": rejected_v47_dry,
        "rejected_v48_dry3_anchor": rejected_v48_dry,
        "rejected_v49_incomplete_full30_anchor": rejected_v49_incomplete,
        "rejected_v50_incomplete_full30_anchor": rejected_v50_incomplete,
        "rejected_v51_full30_anchor": rejected_v51_full,
        "rejected_v52_full30_anchor": rejected_v52_full,
        "rejected_v53_dry3_anchor": rejected_v53_dry,
        "experiment_name": experiment_name.strip(),
        "hypothesis": hypothesis.strip(),
        "selection": {
            "rule": selection_rule.strip(),
            "trajectory_ids": selected,
            "count": len(selected),
        },
        "prediction_manifest": {
            **_bind_file(
                prediction_path,
                content_sha256=prediction["prediction_manifest_sha256"],
            ),
            "dataset_manifest_sha256": prediction[
                "dataset_manifest_sha256"
            ],
            "cohort_name": prediction["cohort_name"],
            "cohort_sha256": prediction["cohort_sha256"],
            "entry_count": len(cases),
        },
        "batch_plan": {
            **_bind_file(
                plan_path,
                content_sha256=plan_binding["content_sha256"],
            ),
            **plan_binding,
        },
        "upstream": upstream,
        "evaluation": {
            "profile": evaluation_profile,
            "upstream_mode": upstream_mode,
            "heldout": bool(contract["heldout"]),
            "dataset_path": str(dataset_resolved),
            "dataset_manifest_sha256": prediction[
                "dataset_manifest_sha256"
            ],
            "cohort_manifest_path": str(cohort_path),
            "cohort_manifest_file_sha256": _file_sha256(cohort_path),
            "cohort_name": cohort["cohort_name"],
            "cohort_sha256": cohort["cohort_sha256"],
            "trajectory_count": len(manifest_ids),
        },
        "implementation": {
            **workflow_contract,
            "method": _V14_METHOD,
            "judge_view_version": JUDGE_VIEW_VERSION,
            "transport_policy_version": TRANSPORT_POLICY_VERSION,
            "stage_cache_schema_version": STAGE_CACHE_SCHEMA_VERSION,
            "raw_stage_schema_version": RAW_STAGE_SCHEMA_VERSION,
            "raw_response_sidecar_schema_version": (
                RAW_RESPONSE_SIDECAR_SCHEMA_VERSION
            ),
            "logical_completion_ledger_schema_version": (
                E8_LOGICAL_COMPLETION_LEDGER_SCHEMA_VERSION
            ),
            "semantic_input": _V14_SEMANTIC_INPUT_IDENTITY,
            "sole_final_semantics": "raw_selector_final_fields",
            "deterministic_root_fallback": False,
            "deterministic_semantic_mutation": False,
            "confidence_score_weight_vote": False,
            "smoke_fresh_four_stage_capability": True,
        },
        "provider_config": config.public_dict(),
        "execution": {
            "run_output_dir": str(run_output),
            "unscored_predictions_path": str(
                run_output / "unscored-predictions.jsonl"
            ),
            "predict_run_metadata_path": str(run_output / "predict-run.json"),
            "scored_output_dir": str(run_output),
            "run_output_initial_state": run_initial,
            "critic_cache_dir": str(critic_cache),
            "critic_cache_initial_state": critic_initial,
            "fresh_upstream_cache_dir": (
                upstream["fresh_upstream_cache"]["path"]
                if upstream["fresh_upstream_cache"] is not None
                else None
            ),
            "fresh_upstream_cache_initial_state": (
                upstream["fresh_upstream_cache"]["state"]
                if upstream["fresh_upstream_cache"] is not None
                else None
            ),
            "logical_completion_ledger_path": str(ledger_path),
            "logical_completion_ledger_lock_path": str(ledger_lock_path),
            "workers": 1,
            "retry_failures": False,
            "live_stages": live_stages,
            "logical_completions_per_uncached_batch": len(live_stages),
            "evidence_repair_enabled": False,
        },
        "logical_completion_budget": {
            "authorization_mode": "unbounded_phase_hard_stop_only",
            "cumulative_before": expected_before,
            "maximum_new": expected_maximum,
            "hard_cumulative_stop": hard_stop,
            "authorized_cumulative_ceiling": authorized_cumulative_ceiling,
            "implementation_cumulative_ceiling": (
                V14_IMPLEMENTATION_CUMULATIVE_CEILING
            ),
            "http_transport_retries_are_not_logical_completions": True,
            "derived_from_frozen_topology": True,
        },
        "promotion_gate": gate,
        "code_bundle_sha256": stable_sha256(code_bundle),
        "code_bundle": code_bundle,
        "code_bundle_archive": code_bundle_archive,
    }
    document["preregistration_sha256"] = stable_sha256(document)
    if destination.is_file():
        if _read(destination, location="v14 preregistration") != document:
            raise BatchedCriticPreregistrationError(
                "existing v14 preregistration conflicts with current identity"
            )
    elif claim_path.is_file():
        raise BatchedCriticPreregistrationError(
            "v14 authorization phase was already claimed"
        )
    else:
        _atomic_json(destination, document)
    claim = _claim_for_preregistration(document)
    if claim_path.is_file():
        if _read_claim(
            claim_path,
            expected_profile=evaluation_profile,
        ) != claim:
            raise BatchedCriticPreregistrationError(
                "existing v14 claim conflicts with preregistration"
            )
    else:
        _exclusive_json(claim_path, claim)
    initialize_fresh_semantic_completion_ledger(
        ledger_path,
        preregistration_sha256=document["preregistration_sha256"],
        cumulative_before=expected_before,
        maximum_new=expected_maximum,
        authorized_cumulative_ceiling=authorized_cumulative_ceiling,
        allowed_stages=live_stages,
    )
    return document


def _runtime_paths_match(
    *,
    document: Mapping[str, Any],
    preregistration_path: Path,
    prediction_manifest_path: Path,
    batch_plan_path: Path,
    source_batch_plan_path: str | Path | None,
    v13_predecessor_manifest_path: str | Path | None,
    source_cache_dir: str | Path | None,
    fresh_upstream_cache_dir: str | Path | None,
    run_output_dir: Path,
    critic_cache_dir: Path,
    unscored_output_path: Path,
    predict_run_metadata_path: Path,
) -> bool:
    execution = document["execution"]
    upstream = document["upstream"]
    source_plan = upstream.get("source_batch_plan")
    predecessor = upstream.get("predecessor_manifest")
    source_cache = upstream.get("source_cache")
    fresh = upstream.get("fresh_upstream_cache")
    return bool(
        document.get("preregistration_path") == str(preregistration_path)
        and document.get("prediction_manifest", {}).get("path")
        == str(prediction_manifest_path)
        and document.get("batch_plan", {}).get("path") == str(batch_plan_path)
        and execution.get("run_output_dir") == str(run_output_dir)
        and execution.get("critic_cache_dir") == str(critic_cache_dir)
        and execution.get("unscored_predictions_path")
        == str(unscored_output_path)
        and execution.get("predict_run_metadata_path")
        == str(predict_run_metadata_path)
        and (
            None
            if source_batch_plan_path is None
            else str(Path(source_batch_plan_path).expanduser().resolve())
        )
        == (source_plan.get("path") if isinstance(source_plan, Mapping) else None)
        and (
            None
            if v13_predecessor_manifest_path is None
            else str(Path(v13_predecessor_manifest_path).expanduser().resolve())
        )
        == (predecessor.get("path") if isinstance(predecessor, Mapping) else None)
        and (
            None
            if source_cache_dir is None
            else str(Path(source_cache_dir).expanduser().resolve())
        )
        == (source_cache.get("path") if isinstance(source_cache, Mapping) else None)
        and (
            None
            if fresh_upstream_cache_dir is None
            else str(Path(fresh_upstream_cache_dir).expanduser().resolve())
        )
        == (fresh.get("path") if isinstance(fresh, Mapping) else None)
    )


def verify_batched_critic_preregistration(
    *,
    preregistration_path: str | Path,
    upstream_mode: str,
    prediction_manifest_path: str | Path,
    batch_plan_path: str | Path,
    source_batch_plan_path: str | Path | None = None,
    v13_predecessor_manifest_path: str | Path | None = None,
    source_cache_dir: str | Path | None = None,
    fresh_upstream_cache_dir: str | Path | None = None,
    run_output_dir: str | Path,
    critic_cache_dir: str | Path,
    unscored_output_path: str | Path,
    predict_run_metadata_path: str | Path,
    config: BenchmarkRunConfig,
    selected_trajectory_ids: Sequence[str],
    maximum_new_logical_completions: int,
) -> dict[str, Any]:
    """Recompute the complete gold-free identity immediately before calls."""

    path = Path(preregistration_path).expanduser().resolve()
    document = _validated_hashed_document(
        path,
        location="v14 preregistration",
        hash_field="preregistration_sha256",
    )
    if document.get("schema_version") != V14_PREREGISTRATION_SCHEMA_VERSION:
        raise BatchedCriticPreregistrationError(
            "v14 preregistration schema is invalid"
        )
    selection = document.get("selection")
    budget = document.get("logical_completion_budget")
    execution = document.get("execution")
    evaluation = document.get("evaluation")
    if not all(
        isinstance(value, Mapping)
        for value in (selection, budget, execution, evaluation)
    ):
        raise BatchedCriticPreregistrationError(
            "v14 preregistration envelope is invalid"
        )
    selected = [str(value) for value in selected_trajectory_ids]
    profile = str(evaluation["profile"])
    prediction_path = Path(prediction_manifest_path).expanduser().resolve()
    plan_path = Path(batch_plan_path).expanduser().resolve()
    run_output = Path(run_output_dir).expanduser().resolve()
    critic_cache = Path(critic_cache_dir).expanduser().resolve()
    unscored = Path(unscored_output_path).expanduser().resolve()
    predict_run = Path(predict_run_metadata_path).expanduser().resolve()
    if (
        upstream_mode != evaluation.get("upstream_mode")
        or selection.get("trajectory_ids") != selected
        or selection.get("count") != len(selected)
        or budget.get("maximum_new") != maximum_new_logical_completions
        or not _runtime_paths_match(
            document=document,
            preregistration_path=path,
            prediction_manifest_path=prediction_path,
            batch_plan_path=plan_path,
            source_batch_plan_path=source_batch_plan_path,
            v13_predecessor_manifest_path=v13_predecessor_manifest_path,
            source_cache_dir=source_cache_dir,
            fresh_upstream_cache_dir=fresh_upstream_cache_dir,
            run_output_dir=run_output,
            critic_cache_dir=critic_cache,
            unscored_output_path=unscored,
            predict_run_metadata_path=predict_run,
        )
    ):
        raise BatchedCriticPreregistrationError(
            "runtime v14 mode/selection/path/budget differs from preregistration"
        )
    _validate_formal_provider_config(profile=profile, config=config)
    if config.public_dict() != document.get("provider_config"):
        raise BatchedCriticPreregistrationError(
            "runtime v14 provider differs from preregistration"
        )
    prediction, cases = load_prediction_manifest(prediction_path)
    plan, batches = _load_batch_plan(plan_path)
    plan_binding = _validate_batch_plan_binding(
        plan=plan,
        batches=batches,
        selected_ids=selected,
    )
    cohort_path = Path(str(evaluation["cohort_manifest_path"])).resolve()
    cohort = _load_gold_free_cohort_header(cohort_path)
    _validate_profile_binding(
        profile=profile,
        upstream_mode=upstream_mode,
        cohort=cohort,
        manifest=prediction,
        manifest_ids=[case.trajectory_id for case in cases],
        selected_ids=selected,
        gate=document.get("promotion_gate", {}),
        plan_binding=plan_binding,
    )
    expected_before, expected_maximum = _expected_budget(
        profile,
        batch_count=plan_binding["batch_count"],
    )
    authorization = document.get("authorization_chain")
    if not isinstance(authorization, Mapping):
        raise BatchedCriticPreregistrationError(
            "v14 authorization envelope is invalid"
        )
    authorization_dir = _authorization_directory(
        profile=profile,
        requested=authorization.get("directory"),
        run_output_dir=run_output,
    )
    current_bundle = _current_code_bundle()
    frozen_archive = document.get("code_bundle_archive")
    if not isinstance(frozen_archive, Mapping) or not isinstance(
        frozen_archive.get("path"), str
    ):
        raise BatchedCriticPreregistrationError(
            "v14 preregistration lacks its frozen code archive"
        )
    current_archive = verify_batched_critic_code_bundle_archive(
        frozen_archive["path"]
    )
    upstream = _resolve_upstream_binding(
        profile=profile,
        upstream_mode=upstream_mode,
        prediction_manifest=prediction,
        manifest_ids=[case.trajectory_id for case in cases],
        current_plan=plan,
        current_batches=batches,
        current_plan_binding=plan_binding,
        source_batch_plan_path=source_batch_plan_path,
        v13_predecessor_manifest_path=v13_predecessor_manifest_path,
        source_cache_dir=source_cache_dir,
        fresh_upstream_cache_dir=fresh_upstream_cache_dir,
        critic_cache_dir=critic_cache,
    )
    phase_predecessor, predecessor_claim_sha256 = _resolve_phase_predecessor(
        profile=profile,
        authorization_dir=authorization_dir,
        current_code_bundle=current_bundle,
        current_code_bundle_archive=current_archive,
        config=config,
        upstream_binding=upstream,
        critic_cache_initial_state=execution["critic_cache_initial_state"],
    )
    _validate_phase_budget(
        profile=profile,
        batch_count=plan_binding["batch_count"],
        cumulative_before=budget.get("cumulative_before"),
        maximum_new=budget.get("maximum_new"),
        hard_cumulative_stop=budget.get("hard_cumulative_stop"),
        authorized_cumulative_ceiling=budget.get(
            "authorized_cumulative_ceiling"
        ),
        predecessor_cumulative_after=(
            None
            if phase_predecessor is None
            else phase_predecessor["cumulative_after"]
        ),
    )
    ledger_path = Path(str(execution["logical_completion_ledger_path"])).resolve()
    ledger = _load_ledger(
        execution=execution,
        budget=budget,
        preregistration_sha256=document["preregistration_sha256"],
    )
    static_checks = (
        expected_before == budget.get("cumulative_before"),
        expected_maximum == budget.get("maximum_new"),
        document.get("code_bundle") == current_bundle,
        document.get("code_bundle_sha256") == stable_sha256(current_bundle),
        dict(frozen_archive) == current_archive,
        document.get("implementation")
        == {
            **document["implementation"],
            **_workflow_contract(),
        },
        document.get("upstream") == upstream,
        document.get("phase_predecessor") == phase_predecessor,
        document.get("rejected_v13_anchor")
        == _validate_v13_rejected_run_binding(
            document.get("rejected_v13_anchor")
        ),
        document.get("rejected_v14_transport_anchor")
        == _validate_v14_rejected_transport_binding(
            document.get("rejected_v14_transport_anchor")
        ),
        document.get("rejected_v15_json_anchor")
        == _validate_v15_rejected_json_binding(
            document.get("rejected_v15_json_anchor")
        ),
        document.get("rejected_v16_json_anchor")
        == _validate_v16_rejected_json_binding(
            document.get("rejected_v16_json_anchor")
        ),
        document.get("rejected_v17_semantic_anchor")
        == _validate_v17_rejected_semantic_binding(
            document.get("rejected_v17_semantic_anchor")
        ),
        document.get("rejected_v18_malformed_anchor")
        == _validate_v18_rejected_malformed_binding(
            document.get("rejected_v18_malformed_anchor")
        ),
        document.get("rejected_v19_semantic_anchor")
        == _validate_v19_rejected_semantic_binding(
            document.get("rejected_v19_semantic_anchor")
        ),
        document.get("rejected_v20_semantic_anchor")
        == _validate_v20_rejected_semantic_binding(
            document.get("rejected_v20_semantic_anchor")
        ),
        document.get("rejected_v21_semantic_anchor")
        == _validate_v21_rejected_semantic_binding(
            document.get("rejected_v21_semantic_anchor")
        ),
        document.get("rejected_v22_semantic_anchor")
        == _validate_v22_rejected_semantic_binding(
            document.get("rejected_v22_semantic_anchor")
        ),
        document.get("rejected_v23_empty_content_anchor")
        == _validate_v23_rejected_empty_content_binding(
            document.get("rejected_v23_empty_content_anchor")
        ),
        document.get("rejected_v24_full30_anchor")
        == _validate_v24_rejected_full30_binding(
            document.get("rejected_v24_full30_anchor")
        ),
        document.get("rejected_v25_full30_anchor")
        == _validate_v25_rejected_full30_binding(
            document.get("rejected_v25_full30_anchor")
        ),
        document.get("rejected_v26_dry3_anchor")
        == _validate_v26_rejected_dry3_binding(
            document.get("rejected_v26_dry3_anchor")
        ),
        document.get("rejected_v27_full30_anchor")
        == _validate_v27_rejected_full30_binding(
            document.get("rejected_v27_full30_anchor")
        ),
        document.get("rejected_v28_dry3_anchor")
        == _validate_v28_rejected_dry3_binding(
            document.get("rejected_v28_dry3_anchor")
        ),
        document.get("rejected_v29_full30_anchor")
        == _validate_v29_rejected_full30_binding(
            document.get("rejected_v29_full30_anchor")
        ),
        document.get("rejected_v30_full30_anchor")
        == _validate_v30_rejected_full30_binding(
            document.get("rejected_v30_full30_anchor")
        ),
        document.get("rejected_v31_incomplete_full30_anchor")
        == _validate_v31_incomplete_full30_binding(
            document.get("rejected_v31_incomplete_full30_anchor")
        ),
        document.get("rejected_v32_dry3_anchor")
        == _validate_v32_rejected_dry3_binding(
            document.get("rejected_v32_dry3_anchor")
        ),
        document.get("rejected_v33_dry3_anchor")
        == _validate_v33_rejected_dry3_binding(
            document.get("rejected_v33_dry3_anchor")
        ),
        document.get("rejected_v34_incomplete_full30_anchor")
        == _validate_v34_incomplete_full30_binding(
            document.get("rejected_v34_incomplete_full30_anchor")
        ),
        document.get("rejected_v35_full30_anchor")
        == _validate_v35_rejected_full30_binding(
            document.get("rejected_v35_full30_anchor")
        ),
        document.get("rejected_v36_dry3_anchor")
        == _validate_v36_rejected_dry3_binding(
            document.get("rejected_v36_dry3_anchor")
        ),
        document.get("rejected_v37_dry3_anchor")
        == _validate_v37_rejected_dry3_binding(
            document.get("rejected_v37_dry3_anchor")
        ),
        document.get("rejected_v38_full30_anchor")
        == _validate_v38_rejected_full30_binding(
            document.get("rejected_v38_full30_anchor")
        ),
        document.get("rejected_v39_dry3_anchor")
        == _validate_v39_rejected_dry3_binding(
            document.get("rejected_v39_dry3_anchor")
        ),
        document.get("rejected_v40_full30_anchor")
        == _validate_v40_rejected_full30_binding(
            document.get("rejected_v40_full30_anchor")
        ),
        document.get("rejected_v41_dry3_anchor")
        == _validate_v41_rejected_dry3_binding(
            document.get("rejected_v41_dry3_anchor")
        ),
        document.get("rejected_v42_dry3_anchor")
        == _validate_v42_rejected_dry3_binding(
            document.get("rejected_v42_dry3_anchor")
        ),
        document.get("rejected_v43_dry3_anchor")
        == _validate_v43_rejected_dry3_binding(
            document.get("rejected_v43_dry3_anchor")
        ),
        document.get("rejected_v44_dry3_anchor")
        == _validate_v44_rejected_dry3_binding(
            document.get("rejected_v44_dry3_anchor")
        ),
        document.get("rejected_v45_dry3_anchor")
        == _validate_v45_rejected_dry3_binding(
            document.get("rejected_v45_dry3_anchor")
        ),
        document.get("rejected_v46_full30_anchor")
        == _validate_v46_rejected_full30_binding(
            document.get("rejected_v46_full30_anchor")
        ),
        document.get("rejected_v47_dry3_anchor")
        == _validate_v47_rejected_dry3_binding(
            document.get("rejected_v47_dry3_anchor")
        ),
        document.get("rejected_v48_dry3_anchor")
        == _validate_v48_rejected_dry3_binding(
            document.get("rejected_v48_dry3_anchor")
        ),
        document.get("rejected_v49_incomplete_full30_anchor")
        == _validate_v49_incomplete_full30_binding(
            document.get("rejected_v49_incomplete_full30_anchor")
        ),
        document.get("rejected_v50_incomplete_full30_anchor")
        == _validate_v50_incomplete_full30_binding(
            document.get("rejected_v50_incomplete_full30_anchor")
        ),
        document.get("rejected_v51_full30_anchor")
        == _validate_v51_rejected_full30_binding(
            document.get("rejected_v51_full30_anchor")
        ),
        document.get("rejected_v52_full30_anchor")
        == _validate_v52_rejected_full30_binding(
            document.get("rejected_v52_full30_anchor")
        ),
        document.get("rejected_v53_dry3_anchor")
        == _validate_v53_rejected_dry3_binding(
            document.get("rejected_v53_dry3_anchor")
        ),
        authorization.get("claim_path")
        == str(_claim_path(authorization_dir, profile=profile)),
        authorization.get("predecessor_claim_sha256")
        == predecessor_claim_sha256,
        _claim_for_preregistration(document)
        == _read_claim(
            Path(str(authorization["claim_path"])),
            expected_profile=profile,
        ),
        document.get("prediction_manifest", {}).get("file_sha256")
        == _file_sha256(prediction_path),
        document.get("prediction_manifest", {}).get("content_sha256")
        == prediction["prediction_manifest_sha256"],
        document.get("batch_plan", {}).get("file_sha256")
        == _file_sha256(plan_path),
        document.get("batch_plan", {}).get("content_sha256")
        == plan_binding["content_sha256"],
        evaluation.get("cohort_manifest_file_sha256")
        == _file_sha256(cohort_path),
        execution.get("workers") == 1,
        execution.get("retry_failures") is False,
    )
    if not all(static_checks):
        raise BatchedCriticPreregistrationError(
            "runtime v14 code/input/upstream/authorization identity changed"
        )
    if predict_run.is_file():
        raise BatchedCriticPreregistrationError(
            "v14 prediction run is already complete"
        )
    current_output = _directory_state(
        run_output,
        excluded_paths=(
            path,
            ledger_path,
            _ledger_lock_path(ledger_path),
            unscored,
            current_archive["path"],
        ),
    )
    if current_output != execution.get("run_output_initial_state"):
        raise BatchedCriticPreregistrationError(
            "v14 output directory contains unregistered artifacts"
        )
    if not ledger["entries"]:
        clean_unscored = not unscored.exists() or (
            unscored.is_file() and unscored.stat().st_size == 0
        )
        if (
            not clean_unscored
            or _directory_state(critic_cache)
            != execution.get("critic_cache_initial_state")
            or (
                upstream_mode == V14_FRESH_FOUR_STAGE_SMOKE
                and _directory_state(fresh_upstream_cache_dir)
                != execution.get("fresh_upstream_cache_initial_state")
            )
        ):
            raise BatchedCriticPreregistrationError(
                "v14 clean-start cache/output state differs from preregistration"
            )
    else:
        validator = getattr(
            _workflow(), "validate_partial_batched_critic_predictions", None
        )
        if not callable(validator):
            raise BatchedCriticPreregistrationError(
                "v14 workflow cannot validate a partially completed run"
            )
        _invoke_checked(
            validator,
            {
                "upstream_mode": upstream_mode,
                "prediction_manifest_path": prediction_path,
                "batch_plan_path": plan_path,
                "source_batch_plan_path": source_batch_plan_path,
                "v13_predecessor_manifest_path": (
                    v13_predecessor_manifest_path
                ),
                "source_cache_dir": source_cache_dir,
                "fresh_upstream_cache_dir": fresh_upstream_cache_dir,
                "critic_cache_dir": critic_cache,
                "unscored_predictions_path": unscored,
                "preregistration_sha256": document[
                    "preregistration_sha256"
                ],
                "config": config,
            },
            location="partial v14 raw chain",
        )
    return document


def _invoke_checked(
    function: Callable[..., Any],
    arguments: Mapping[str, Any],
    *,
    location: str,
) -> Any:
    """Call a lazy workflow API while rejecting missing required semantics."""

    try:
        signature = inspect.signature(function)
    except (TypeError, ValueError) as error:
        raise BatchedCriticPreregistrationError(
            f"{location} API signature is unavailable"
        ) from error
    has_var_kwargs = any(
        parameter.kind is inspect.Parameter.VAR_KEYWORD
        for parameter in signature.parameters.values()
    )
    accepted = (
        dict(arguments)
        if has_var_kwargs
        else {
            name: value
            for name, value in arguments.items()
            if name in signature.parameters
        }
    )
    required = {
        name
        for name, parameter in signature.parameters.items()
        if parameter.kind
        in {inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY}
        and parameter.default is inspect.Parameter.empty
    }
    if not required <= set(accepted):
        raise BatchedCriticPreregistrationError(
            f"{location} API contract is incomplete"
        )
    try:
        return function(**accepted)
    except (OSError, TypeError, ValueError) as error:
        raise BatchedCriticPreregistrationError(
            f"{location} validation failed"
        ) from error


def _contains_forbidden_semantic_input(value: Any) -> bool:
    if isinstance(value, Mapping):
        return any(
            str(key).casefold() in _FORBIDDEN_SEMANTIC_KEYS
            or str(key).casefold().startswith("gold_")
            or _contains_forbidden_semantic_input(item)
            for key, item in value.items()
        )
    if isinstance(value, (list, tuple)):
        return any(_contains_forbidden_semantic_input(item) for item in value)
    return False


def _unique_live_stage_records(
    rows: Sequence[Mapping[str, Any]],
    *,
    expected_stages: Sequence[str],
    batch_count: int,
) -> list[dict[str, Any]]:
    per_key: dict[tuple[int, str], dict[str, Any]] = {}
    for row in rows:
        batch_index = row.get("batch_index")
        identities = row.get("stage_identities")
        hits = row.get("stage_cache_hits")
        stage_telemetry = row.get("stage_provider_telemetry")
        if (
            not isinstance(batch_index, int)
            or isinstance(batch_index, bool)
            or not isinstance(identities, Mapping)
            or not isinstance(hits, Mapping)
            or not isinstance(stage_telemetry, Mapping)
        ):
            raise BatchedCriticPreregistrationError(
                "v14 raw rows lack live stage provenance"
            )
        # Existing E9 rows use one-based indices; tolerate zero-based only if
        # the complete set later proves a contiguous exact topology.
        for stage in expected_stages:
            identity = identities.get(stage)
            cache_hit = hits.get(stage)
            if (
                not isinstance(identity, Mapping)
                or not isinstance(identity.get("request_sha256"), str)
                or not isinstance(cache_hit, bool)
            ):
                raise BatchedCriticPreregistrationError(
                    "v14 live stage identity/cache provenance is invalid"
                )
            record = {
                "batch_index": batch_index,
                "stage": stage,
                "request_sha256": identity["request_sha256"],
                "cache_hit": cache_hit,
                "stage_provider_telemetry": stage_telemetry.get(stage),
            }
            key = (batch_index, stage)
            if key in per_key and per_key[key] != record:
                raise BatchedCriticPreregistrationError(
                    "v14 cases disagree about their shared batch stage"
                )
            per_key[key] = record
    indices = sorted({key[0] for key in per_key})
    if indices not in [list(range(batch_count)), list(range(1, batch_count + 1))]:
        raise BatchedCriticPreregistrationError(
            "v14 raw rows do not cover every batch"
        )
    expected = {(index, stage) for index in indices for stage in expected_stages}
    if set(per_key) != expected:
        raise BatchedCriticPreregistrationError(
            "v14 raw rows do not cover every live stage"
        )
    return [per_key[key] for key in sorted(per_key)]


def _nonnegative_telemetry_counter(value: Any, *, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise BatchedCriticPreregistrationError(
            f"v14 live-miss telemetry field {field} is invalid"
        )
    return value


def _validated_live_miss_stage_telemetry(
    value: Any,
    *,
    stage: str,
) -> dict[str, Any]:
    """Validate one paid stage's complete, aggregate-only telemetry delta."""

    if not isinstance(value, Mapping) or set(value) != _PROVIDER_TELEMETRY_FIELDS:
        raise BatchedCriticPreregistrationError(
            f"v14 cache miss for {stage} lacks complete provider telemetry"
        )
    normalized = dict(value)
    counters = {
        field: _nonnegative_telemetry_counter(
            normalized.get(field),
            field=field,
        )
        for field in _PROVIDER_TELEMETRY_COUNTER_FIELDS
    }
    if (
        counters["logical_completion_count"] != 1
        or counters["http_attempt_count"] < 1
        or counters["retry_count"]
        != counters["http_attempt_count"] - 1
        or counters["request_input_chars"] < 1
        or counters["provider_usage_response_count"]
        > 1
        or counters["request_input_chars"]
        % counters["http_attempt_count"]
        != 0
    ):
        raise BatchedCriticPreregistrationError(
            f"v14 cache miss for {stage} has impossible provider telemetry"
        )
    tokens = normalized.get("provider_usage_token_totals")
    if not isinstance(tokens, Mapping) or set(tokens) != set(
        _PROVIDER_TOKEN_FIELDS
    ):
        raise BatchedCriticPreregistrationError(
            f"v14 cache miss for {stage} has invalid token telemetry"
        )
    normalized_tokens = {
        field: _nonnegative_telemetry_counter(tokens.get(field), field=field)
        for field in _PROVIDER_TOKEN_FIELDS
    }
    if (
        counters["provider_usage_response_count"] == 0
        and any(normalized_tokens.values())
    ):
        raise BatchedCriticPreregistrationError(
            f"v14 cache miss for {stage} has token counts without usage"
        )
    reasons = normalized.get("finish_reason_counts")
    if not isinstance(reasons, Mapping):
        raise BatchedCriticPreregistrationError(
            f"v14 cache miss for {stage} has invalid finish telemetry"
        )
    normalized_reasons: dict[str, int] = {}
    for reason, count in reasons.items():
        if (
            not isinstance(reason, str)
            or not reason.strip()
            or reason != reason.strip()
        ):
            raise BatchedCriticPreregistrationError(
                f"v14 cache miss for {stage} has invalid finish telemetry"
            )
        normalized_count = _nonnegative_telemetry_counter(
            count,
            field=f"finish_reason.{reason}",
        )
        if normalized_count == 0:
            raise BatchedCriticPreregistrationError(
                f"v14 cache miss for {stage} has invalid finish telemetry"
            )
        normalized_reasons[reason] = normalized_count
    if sum(normalized_reasons.values()) > 1:
        raise BatchedCriticPreregistrationError(
            f"v14 cache miss for {stage} has impossible finish telemetry"
        )
    return {
        **counters,
        "provider_usage_token_totals": normalized_tokens,
        "finish_reason_counts": normalized_reasons,
    }


def _aggregate_live_miss_telemetry(
    *,
    records: Sequence[Mapping[str, Any]],
    expected_logical_completions: int,
) -> dict[str, Any]:
    """Require one complete telemetry delta for every current-phase miss."""

    misses = [record for record in records if record.get("cache_hit") is False]
    if len(misses) != expected_logical_completions:
        raise BatchedCriticPreregistrationError(
            "v14 live cache-miss count differs from the frozen call budget"
        )
    values = [
        _validated_live_miss_stage_telemetry(
            record.get("stage_provider_telemetry"),
            stage=str(record.get("stage")),
        )
        for record in misses
    ]
    try:
        aggregate = sum_stage_telemetry(values)
    except StageCacheError as error:
        raise BatchedCriticPreregistrationError(
            "v14 live-miss telemetry cannot be aggregated"
        ) from error
    if (
        aggregate is None
        or aggregate.get("logical_completion_count")
        != expected_logical_completions
    ):
        raise BatchedCriticPreregistrationError(
            "v14 live-miss telemetry does not cover the frozen call budget"
        )
    return aggregate


def _ledger_matches_cache_misses(
    *,
    records: Sequence[Mapping[str, Any]],
    ledger_entries: Sequence[Mapping[str, Any]],
) -> bool:
    misses = Counter(
        (record.get("stage"), record.get("request_sha256"))
        for record in records
        if record.get("cache_hit") is False
    )
    reservations = Counter(
        (entry.get("stage"), entry.get("request_sha256"))
        for entry in ledger_entries
    )
    return misses == reservations


def _topology_cache_check(
    *,
    profile: str,
    records: Sequence[Mapping[str, Any]],
) -> bool:
    if profile == "dry3":
        return (
            len(records) == 2
            and {record["stage"] for record in records}
            == set(V14_TUNING_STAGES)
            and all(record["cache_hit"] is False for record in records)
        )
    if profile == "full30":
        if len(records) != 22:
            return False
        for stage in V14_TUNING_STAGES:
            ordered = sorted(
                (record for record in records if record["stage"] == stage),
                key=lambda item: item["batch_index"],
            )
            if len(ordered) != 11 or [
                item["cache_hit"] for item in ordered
            ] != [True, *([False] * 10)]:
                return False
        return True
    if profile == "smoke30":
        return len(records) == 44 and all(
            record["cache_hit"] is False for record in records
        )
    return False


def verify_batched_critic_promotion(
    *,
    preregistration_path: str | Path,
    predictions_path: str | Path,
    metrics_path: str | Path,
    predict_run_path: str | Path,
    output_path: str | Path,
    persist: bool = True,
    validate_cache_state: bool = True,
) -> dict[str, Any]:
    """Rebuild scores from the raw Critic chain and apply the frozen gate."""

    prereg_path = Path(preregistration_path).expanduser().resolve()
    predictions_resolved = Path(predictions_path).expanduser().resolve()
    metrics_resolved = Path(metrics_path).expanduser().resolve()
    run_resolved = Path(predict_run_path).expanduser().resolve()
    output_resolved = Path(output_path).expanduser().resolve()
    prereg = _validated_hashed_document(
        prereg_path,
        location="v14 preregistration",
        hash_field="preregistration_sha256",
    )
    if prereg.get("schema_version") != V14_PREREGISTRATION_SCHEMA_VERSION:
        raise BatchedCriticPreregistrationError(
            "v14 preregistration schema is invalid"
        )
    current_bundle = _current_code_bundle()
    frozen_archive = prereg.get("code_bundle_archive")
    if not isinstance(frozen_archive, Mapping) or not isinstance(
        frozen_archive.get("path"), str
    ):
        raise BatchedCriticPreregistrationError(
            "v14 preregistration lacks its frozen code archive"
        )
    current_archive = verify_batched_critic_code_bundle_archive(
        frozen_archive["path"]
    )
    if (
        prereg.get("code_bundle") != current_bundle
        or prereg.get("code_bundle_sha256") != stable_sha256(current_bundle)
        or dict(frozen_archive) != current_archive
    ):
        raise BatchedCriticPreregistrationError(
            "v14 code bundle changed after preregistration"
        )
    selection = prereg.get("selection")
    gate = prereg.get("promotion_gate")
    budget = prereg.get("logical_completion_budget")
    execution = prereg.get("execution")
    evaluation = prereg.get("evaluation")
    implementation = prereg.get("implementation")
    upstream = prereg.get("upstream")
    if not all(
        isinstance(value, Mapping)
        for value in (
            selection,
            gate,
            budget,
            execution,
            evaluation,
            implementation,
            upstream,
        )
    ):
        raise BatchedCriticPreregistrationError(
            "v14 promotion preregistration envelope is invalid"
        )
    if set(gate) - _SUPPORTED_GATE_FIELDS:
        raise BatchedCriticPreregistrationError(
            "v14 promotion gate contains unsupported fields"
        )
    profile = str(evaluation["profile"])
    try:
        config = BenchmarkRunConfig(**dict(prereg["provider_config"]))
    except (TypeError, ValueError) as error:
        raise BatchedCriticPreregistrationError(
            "v14 preregistered provider configuration is invalid"
        ) from error
    _validate_formal_provider_config(profile=profile, config=config)
    prediction_path = Path(
        str(prereg["prediction_manifest"]["path"])
    ).resolve()
    plan_path = Path(str(prereg["batch_plan"]["path"])).resolve()
    cohort_path = Path(str(evaluation["cohort_manifest_path"])).resolve()
    prediction, cases = load_prediction_manifest(prediction_path)
    plan, batches = _load_batch_plan(plan_path)
    selected = list(selection.get("trajectory_ids", ()))
    plan_binding = _validate_batch_plan_binding(
        plan=plan,
        batches=batches,
        selected_ids=selected,
    )
    cohort_header = _load_gold_free_cohort_header(cohort_path)
    _validate_profile_binding(
        profile=profile,
        upstream_mode=str(evaluation["upstream_mode"]),
        cohort=cohort_header,
        manifest=prediction,
        manifest_ids=[case.trajectory_id for case in cases],
        selected_ids=selected,
        gate=gate,
        plan_binding=plan_binding,
    )
    source_plan = upstream.get("source_batch_plan")
    predecessor = upstream.get("predecessor_manifest")
    source_cache = upstream.get("source_cache")
    fresh_cache = upstream.get("fresh_upstream_cache")
    if evaluation["upstream_mode"] == V14_FROZEN_V13_TUNING:
        reconstructed_upstream = _resolve_upstream_binding(
            profile=profile,
            upstream_mode=V14_FROZEN_V13_TUNING,
            prediction_manifest=prediction,
            manifest_ids=[case.trajectory_id for case in cases],
            current_plan=plan,
            current_batches=batches,
            current_plan_binding=plan_binding,
            source_batch_plan_path=(
                source_plan.get("path")
                if isinstance(source_plan, Mapping)
                else None
            ),
            v13_predecessor_manifest_path=(
                predecessor.get("path")
                if isinstance(predecessor, Mapping)
                else None
            ),
            source_cache_dir=(
                source_cache.get("path")
                if isinstance(source_cache, Mapping)
                else None
            ),
            fresh_upstream_cache_dir=None,
            critic_cache_dir=Path(str(execution["critic_cache_dir"])),
        )
        if reconstructed_upstream != upstream:
            raise BatchedCriticPreregistrationError(
                "v14 frozen upstream changed after preregistration"
            )
    elif evaluation["upstream_mode"] == V14_FRESH_FOUR_STAGE_SMOKE:
        fresh_path = (
            Path(str(fresh_cache.get("path"))).resolve()
            if isinstance(fresh_cache, Mapping)
            else None
        )
        critic_path = Path(str(execution["critic_cache_dir"])).resolve()
        if (
            source_plan is not None
            or predecessor is not None
            or source_cache is not None
            or fresh_path is None
            or not _paths_are_disjoint(fresh_path, critic_path)
            or fresh_cache.get("state")
            != execution.get("fresh_upstream_cache_initial_state")
            or fresh_cache.get("state", {}).get("file_count") != 0
            or execution.get("critic_cache_initial_state", {}).get(
                "file_count"
            )
            != 0
        ):
            raise BatchedCriticPreregistrationError(
                "v14 fresh smoke upstream preregistration is invalid"
            )
    else:
        raise BatchedCriticPreregistrationError(
            "v14 preregistered upstream mode is invalid"
        )
    authorization = prereg.get("authorization_chain")
    if not isinstance(authorization, Mapping):
        raise BatchedCriticPreregistrationError(
            "v14 authorization envelope is invalid"
        )
    authorization_dir = _authorization_directory(
        profile=profile,
        requested=authorization.get("directory"),
        run_output_dir=Path(str(execution["run_output_dir"])),
    )
    phase_predecessor, predecessor_claim_sha256 = _resolve_phase_predecessor(
        profile=profile,
        authorization_dir=authorization_dir,
        current_code_bundle=current_bundle,
        current_code_bundle_archive=current_archive,
        config=config,
        upstream_binding=upstream,
        critic_cache_initial_state=execution["critic_cache_initial_state"],
    )
    _validate_phase_budget(
        profile=profile,
        batch_count=plan_binding["batch_count"],
        cumulative_before=budget.get("cumulative_before"),
        maximum_new=budget.get("maximum_new"),
        hard_cumulative_stop=budget.get("hard_cumulative_stop"),
        authorized_cumulative_ceiling=budget.get(
            "authorized_cumulative_ceiling"
        ),
        predecessor_cumulative_after=(
            None
            if phase_predecessor is None
            else phase_predecessor["cumulative_after"]
        ),
    )
    static_checks = (
        prereg.get("prediction_manifest", {}).get("file_sha256")
        == _file_sha256(prediction_path),
        prereg.get("prediction_manifest", {}).get("content_sha256")
        == prediction["prediction_manifest_sha256"],
        prereg.get("batch_plan", {}).get("file_sha256")
        == _file_sha256(plan_path),
        prereg.get("batch_plan", {}).get("content_sha256")
        == plan_binding["content_sha256"],
        evaluation.get("cohort_manifest_file_sha256")
        == _file_sha256(cohort_path),
        prereg.get("implementation")
        == {
            **prereg["implementation"],
            **_workflow_contract(),
        },
        prereg.get("rejected_v13_anchor")
        == _validate_v13_rejected_run_binding(
            prereg.get("rejected_v13_anchor")
        ),
        prereg.get("rejected_v14_transport_anchor")
        == _validate_v14_rejected_transport_binding(
            prereg.get("rejected_v14_transport_anchor")
        ),
        prereg.get("rejected_v15_json_anchor")
        == _validate_v15_rejected_json_binding(
            prereg.get("rejected_v15_json_anchor")
        ),
        prereg.get("rejected_v16_json_anchor")
        == _validate_v16_rejected_json_binding(
            prereg.get("rejected_v16_json_anchor")
        ),
        prereg.get("rejected_v17_semantic_anchor")
        == _validate_v17_rejected_semantic_binding(
            prereg.get("rejected_v17_semantic_anchor")
        ),
        prereg.get("rejected_v18_malformed_anchor")
        == _validate_v18_rejected_malformed_binding(
            prereg.get("rejected_v18_malformed_anchor")
        ),
        prereg.get("rejected_v19_semantic_anchor")
        == _validate_v19_rejected_semantic_binding(
            prereg.get("rejected_v19_semantic_anchor")
        ),
        prereg.get("rejected_v20_semantic_anchor")
        == _validate_v20_rejected_semantic_binding(
            prereg.get("rejected_v20_semantic_anchor")
        ),
        prereg.get("rejected_v21_semantic_anchor")
        == _validate_v21_rejected_semantic_binding(
            prereg.get("rejected_v21_semantic_anchor")
        ),
        prereg.get("rejected_v22_semantic_anchor")
        == _validate_v22_rejected_semantic_binding(
            prereg.get("rejected_v22_semantic_anchor")
        ),
        prereg.get("rejected_v23_empty_content_anchor")
        == _validate_v23_rejected_empty_content_binding(
            prereg.get("rejected_v23_empty_content_anchor")
        ),
        prereg.get("rejected_v24_full30_anchor")
        == _validate_v24_rejected_full30_binding(
            prereg.get("rejected_v24_full30_anchor")
        ),
        prereg.get("rejected_v25_full30_anchor")
        == _validate_v25_rejected_full30_binding(
            prereg.get("rejected_v25_full30_anchor")
        ),
        prereg.get("rejected_v26_dry3_anchor")
        == _validate_v26_rejected_dry3_binding(
            prereg.get("rejected_v26_dry3_anchor")
        ),
        prereg.get("rejected_v27_full30_anchor")
        == _validate_v27_rejected_full30_binding(
            prereg.get("rejected_v27_full30_anchor")
        ),
        prereg.get("rejected_v28_dry3_anchor")
        == _validate_v28_rejected_dry3_binding(
            prereg.get("rejected_v28_dry3_anchor")
        ),
        prereg.get("rejected_v29_full30_anchor")
        == _validate_v29_rejected_full30_binding(
            prereg.get("rejected_v29_full30_anchor")
        ),
        prereg.get("rejected_v30_full30_anchor")
        == _validate_v30_rejected_full30_binding(
            prereg.get("rejected_v30_full30_anchor")
        ),
        prereg.get("rejected_v31_incomplete_full30_anchor")
        == _validate_v31_incomplete_full30_binding(
            prereg.get("rejected_v31_incomplete_full30_anchor")
        ),
        prereg.get("rejected_v32_dry3_anchor")
        == _validate_v32_rejected_dry3_binding(
            prereg.get("rejected_v32_dry3_anchor")
        ),
        prereg.get("rejected_v33_dry3_anchor")
        == _validate_v33_rejected_dry3_binding(
            prereg.get("rejected_v33_dry3_anchor")
        ),
        prereg.get("rejected_v34_incomplete_full30_anchor")
        == _validate_v34_incomplete_full30_binding(
            prereg.get("rejected_v34_incomplete_full30_anchor")
        ),
        prereg.get("rejected_v35_full30_anchor")
        == _validate_v35_rejected_full30_binding(
            prereg.get("rejected_v35_full30_anchor")
        ),
        prereg.get("rejected_v36_dry3_anchor")
        == _validate_v36_rejected_dry3_binding(
            prereg.get("rejected_v36_dry3_anchor")
        ),
        prereg.get("rejected_v37_dry3_anchor")
        == _validate_v37_rejected_dry3_binding(
            prereg.get("rejected_v37_dry3_anchor")
        ),
        prereg.get("rejected_v38_full30_anchor")
        == _validate_v38_rejected_full30_binding(
            prereg.get("rejected_v38_full30_anchor")
        ),
        prereg.get("rejected_v39_dry3_anchor")
        == _validate_v39_rejected_dry3_binding(
            prereg.get("rejected_v39_dry3_anchor")
        ),
        prereg.get("rejected_v40_full30_anchor")
        == _validate_v40_rejected_full30_binding(
            prereg.get("rejected_v40_full30_anchor")
        ),
        prereg.get("rejected_v41_dry3_anchor")
        == _validate_v41_rejected_dry3_binding(
            prereg.get("rejected_v41_dry3_anchor")
        ),
        prereg.get("rejected_v42_dry3_anchor")
        == _validate_v42_rejected_dry3_binding(
            prereg.get("rejected_v42_dry3_anchor")
        ),
        prereg.get("rejected_v43_dry3_anchor")
        == _validate_v43_rejected_dry3_binding(
            prereg.get("rejected_v43_dry3_anchor")
        ),
        prereg.get("rejected_v44_dry3_anchor")
        == _validate_v44_rejected_dry3_binding(
            prereg.get("rejected_v44_dry3_anchor")
        ),
        prereg.get("rejected_v45_dry3_anchor")
        == _validate_v45_rejected_dry3_binding(
            prereg.get("rejected_v45_dry3_anchor")
        ),
        prereg.get("rejected_v46_full30_anchor")
        == _validate_v46_rejected_full30_binding(
            prereg.get("rejected_v46_full30_anchor")
        ),
        prereg.get("rejected_v47_dry3_anchor")
        == _validate_v47_rejected_dry3_binding(
            prereg.get("rejected_v47_dry3_anchor")
        ),
        prereg.get("rejected_v48_dry3_anchor")
        == _validate_v48_rejected_dry3_binding(
            prereg.get("rejected_v48_dry3_anchor")
        ),
        prereg.get("rejected_v49_incomplete_full30_anchor")
        == _validate_v49_incomplete_full30_binding(
            prereg.get("rejected_v49_incomplete_full30_anchor")
        ),
        prereg.get("rejected_v50_incomplete_full30_anchor")
        == _validate_v50_incomplete_full30_binding(
            prereg.get("rejected_v50_incomplete_full30_anchor")
        ),
        prereg.get("rejected_v51_full30_anchor")
        == _validate_v51_rejected_full30_binding(
            prereg.get("rejected_v51_full30_anchor")
        ),
        prereg.get("rejected_v52_full30_anchor")
        == _validate_v52_rejected_full30_binding(
            prereg.get("rejected_v52_full30_anchor")
        ),
        prereg.get("rejected_v53_dry3_anchor")
        == _validate_v53_rejected_dry3_binding(
            prereg.get("rejected_v53_dry3_anchor")
        ),
        prereg.get("phase_predecessor") == phase_predecessor,
        authorization.get("predecessor_claim_sha256")
        == predecessor_claim_sha256,
        authorization.get("claim_path")
        == str(_claim_path(authorization_dir, profile=profile)),
        _claim_for_preregistration(prereg)
        == _read_claim(
            Path(str(authorization["claim_path"])),
            expected_profile=profile,
        ),
    )
    if not all(static_checks):
        raise BatchedCriticPreregistrationError(
            "v14 static promotion identity changed after preregistration"
        )
    expected_paths = {
        "predictions": Path(str(execution["run_output_dir"])) / "predictions.jsonl",
        "metrics": Path(str(execution["run_output_dir"])) / "metrics.json",
        "predict_run": Path(str(execution["predict_run_metadata_path"])),
        "promotion": Path(str(execution["run_output_dir"])) / "promotion.json",
    }
    if {
        "predictions": predictions_resolved,
        "metrics": metrics_resolved,
        "predict_run": run_resolved,
        "promotion": output_resolved,
    } != {key: value.resolve() for key, value in expected_paths.items()}:
        raise BatchedCriticPreregistrationError(
            "v14 promotion artifact paths differ from preregistration"
        )
    predict_run = _validated_hashed_document(
        run_resolved,
        location="v14 predict run",
        hash_field="predict_run_sha256",
    )
    unscored_path = Path(str(execution["unscored_predictions_path"])).resolve()
    workflow = _workflow()
    validator = getattr(workflow, "validate_batched_critic_artifacts", None)
    scorer = getattr(workflow, "score_batched_critic_predictions", None)
    if not callable(validator) or not callable(scorer):
        raise BatchedCriticPreregistrationError(
            "v14 workflow lacks raw validation/scoring entry points"
        )
    raw_arguments = {
        "upstream_mode": evaluation["upstream_mode"],
        "prediction_manifest_path": prediction_path,
        "batch_plan_path": plan_path,
        "source_batch_plan_path": (
            source_plan.get("path") if isinstance(source_plan, Mapping) else None
        ),
        "v13_predecessor_manifest_path": (
            predecessor.get("path") if isinstance(predecessor, Mapping) else None
        ),
        "source_cache_dir": (
            source_cache.get("path") if isinstance(source_cache, Mapping) else None
        ),
        "fresh_upstream_cache_dir": (
            fresh_cache.get("path") if isinstance(fresh_cache, Mapping) else None
        ),
        "critic_cache_dir": execution["critic_cache_dir"],
        "unscored_predictions_path": unscored_path,
        "predict_run_metadata_path": run_resolved,
    }
    # This is intentionally complete before either dataset or cohort loader.
    validated = _invoke_checked(
        validator,
        raw_arguments,
        location="complete v14 raw chain",
    )
    unscored_rows = _read_jsonl(
        unscored_path,
        location="v14 unscored predictions",
    )
    dataset_path = Path(str(evaluation["dataset_path"])).resolve()
    dataset = load_agent_error_bench(dataset_path)
    cohort = load_cohort_manifest(cohort_path, dataset=dataset)
    score_arguments = {
        "dataset": dataset,
        "cohort": cohort,
        **raw_arguments,
        "validated_artifacts": validated,
    }
    score_arguments.pop("critic_cache_dir", None)
    score_arguments.pop("fresh_upstream_cache_dir", None)
    rescored, raw_metrics, raw_run = _invoke_checked(
        scorer,
        score_arguments,
        location="v14 raw-derived scoring",
    )
    prediction_rows = _read_jsonl(
        predictions_resolved,
        location="v14 scored predictions",
    )
    metrics_document = _read(metrics_resolved, location="v14 metrics")
    recomputed_metrics = compute_metrics(prediction_rows)
    if (
        rescored != prediction_rows
        or raw_metrics != recomputed_metrics
        or raw_run != predict_run
        or metrics_document.get("metrics") != recomputed_metrics
        or [row.get("trajectory_id") for row in prediction_rows]
        != selection["trajectory_ids"]
        or len(unscored_rows) != len(prediction_rows)
    ):
        raise BatchedCriticPreregistrationError(
            "v14 scored artifacts are not an exact raw-derived evaluation"
        )
    try:
        overall = recomputed_metrics["by_method"][_V14_METHOD]["overall"]
    except KeyError as error:
        raise BatchedCriticPreregistrationError(
            "v14 metrics lack the frozen two_stage method"
        ) from error
    ledger = _load_ledger(
        execution=execution,
        budget=budget,
        preregistration_sha256=prereg["preregistration_sha256"],
    )
    records = _unique_live_stage_records(
        unscored_rows,
        expected_stages=execution["live_stages"],
        batch_count=prereg["batch_plan"]["batch_count"],
    )
    live_miss_telemetry = _aggregate_live_miss_telemetry(
        records=records,
        expected_logical_completions=budget["maximum_new"],
    )
    if (
        predict_run.get("provider_telemetry") != live_miss_telemetry
        or predict_run.get("provider_telemetry_current_run")
        != live_miss_telemetry
    ):
        raise BatchedCriticPreregistrationError(
            "v14 predict-run telemetry differs from its live cache misses"
        )

    checks: dict[str, bool] = {}

    def check(name: str, passed: bool) -> None:
        checks[name] = bool(passed)

    check(
        "trajectory_denominator",
        overall["trajectory_count"] == gate["trajectory_denominator"]
        and overall["step_exact"]["denominator"]
        == gate["trajectory_denominator"]
        and overall["step_module_exact"]["denominator"]
        == gate["trajectory_denominator"],
    )
    check(
        "successful_prediction_minimum",
        overall["successful_prediction_count"]
        >= gate["successful_prediction_minimum"],
    )
    check(
        "failed_prediction_maximum",
        overall["failed_prediction_count"]
        <= gate["failed_prediction_maximum"],
    )
    check(
        "step_exact_minimum_correct",
        overall["step_exact"]["correct"]
        >= gate["step_exact_minimum_correct"],
    )
    check(
        "step_module_exact_minimum_correct",
        overall["step_module_exact"]["correct"]
        >= gate["step_module_exact_minimum_correct"],
    )
    if gate["all_correct_report_only"]:
        check(
            "all_correct_report_only",
            gate["all_correct_minimum"] is None,
        )
    else:
        check(
            "all_correct_minimum",
            isinstance(gate["all_correct_minimum"], int)
            and overall["all_correct"]["correct"]
            >= gate["all_correct_minimum"],
        )
    check(
        "semantic_mutation_maximum",
        predict_run.get("semantic_mutation_count", 0)
        <= gate["semantic_mutation_maximum"],
    )
    check(
        "raw_chain_reconstruction_required",
        gate["raw_chain_reconstruction_required"] is True
        and len(rescored) == len(unscored_rows)
        and raw_run == predict_run,
    )
    check(
        "gold_isolation_required",
        gate["gold_isolation_required"] is True
        and implementation.get("semantic_input")
        == _V14_SEMANTIC_INPUT_IDENTITY
        and implementation.get("sole_final_semantics")
        == "raw_selector_final_fields"
        and implementation.get("deterministic_root_fallback") is False
        and implementation.get("deterministic_semantic_mutation") is False
        and implementation.get("confidence_score_weight_vote") is False
        and not _contains_forbidden_semantic_input(unscored_rows),
    )
    check(
        "llm_selector_raw_final_required",
        gate["llm_selector_raw_final_required"] is True
        and all(
            row.get("semantic_classifier") == _V14_SEMANTIC_CLASSIFIER
            and isinstance(
                row.get("raw_judge_outputs", {}).get(BATCHED_SELECTOR_STAGE),
                str,
            )
            for row in unscored_rows
            if row.get("status") in SUCCESS_STATUSES
        ),
    )
    used = predict_run.get("logical_completion_budget_used")
    check(
        "runtime_budget_exactly_preregistered",
        isinstance(used, int)
        and not isinstance(used, bool)
        and used == budget["maximum_new"]
        and len(ledger["entries"]) == budget["maximum_new"]
        and budget["cumulative_before"] + used
        == budget["hard_cumulative_stop"]
        == budget["authorized_cumulative_ceiling"]
        and V14_IMPLEMENTATION_CUMULATIVE_CEILING is None
        and _ledger_matches_cache_misses(
            records=records,
            ledger_entries=ledger["entries"],
        ),
    )
    check(
        "live_miss_provider_telemetry_complete",
        live_miss_telemetry["logical_completion_count"]
        == budget["maximum_new"]
        == len(ledger["entries"]),
    )
    check(
        {
            "dry3": "dry_candidate_and_selector_cache_miss",
            "full30": "full_reuses_only_dry_first_active_pair",
            "smoke30": "smoke_all_four_stages_cache_miss",
        }[profile],
        _topology_cache_check(profile=profile, records=records),
    )
    if gate["heldout_one_shot_required"]:
        check(
            "heldout_one_shot_required",
            profile == "smoke30"
            and evaluation.get("heldout") is True
            and evaluation.get("upstream_mode")
            == V14_FRESH_FOUR_STAGE_SMOKE
            and execution.get("run_output_initial_state", {}).get("file_count")
            == 0
            and execution.get("critic_cache_initial_state", {}).get("file_count")
            == 0
            and execution.get("fresh_upstream_cache_initial_state", {}).get(
                "file_count"
            )
            == 0
            and selection.get("count") == 30
            and predict_run.get("prediction_count") == 30
            and _topology_cache_check(profile=profile, records=records),
        )
    accepted = bool(checks) and all(checks.values())
    critic_final_state = _directory_state(execution["critic_cache_dir"])
    fresh_final_state = (
        _directory_state(execution["fresh_upstream_cache_dir"])
        if execution.get("fresh_upstream_cache_dir") is not None
        else None
    )
    if not validate_cache_state:
        existing = _read(output_resolved, location="existing v14 promotion")
        critic_final_state = existing.get("critic_cache_final_state")
        fresh_final_state = existing.get("fresh_upstream_cache_final_state")
    document = {
        "schema_version": V14_PROMOTION_SCHEMA_VERSION,
        "accepted": accepted,
        "preregistration_path": str(prereg_path),
        "preregistration_sha256": prereg["preregistration_sha256"],
        "predictions_path": str(predictions_resolved),
        "predictions_file_sha256": _file_sha256(predictions_resolved),
        "metrics_path": str(metrics_resolved),
        "metrics_file_sha256": _file_sha256(metrics_resolved),
        "predict_run_path": str(run_resolved),
        "predict_run_file_sha256": _file_sha256(run_resolved),
        "critic_cache_final_state": critic_final_state,
        "fresh_upstream_cache_final_state": fresh_final_state,
        "checks": checks,
        "summary": {
            "trajectory_count": overall["trajectory_count"],
            "step_correct": overall["step_exact"]["correct"],
            "step_denominator": overall["step_exact"]["denominator"],
            "step_module_correct": overall["step_module_exact"]["correct"],
            "step_module_denominator": overall["step_module_exact"][
                "denominator"
            ],
            "all_correct": overall["all_correct"]["correct"],
            "all_denominator": overall["all_correct"]["denominator"],
            "all_correct_gate_applied": not gate["all_correct_report_only"],
            "failed_prediction_count": overall["failed_prediction_count"],
            "logical_completion_budget_used": used,
            "provider_telemetry_current_run": live_miss_telemetry,
        },
    }
    document["promotion_sha256"] = stable_sha256(document)
    if persist:
        _atomic_json(output_resolved, document)
    elif _read(output_resolved, location="existing v14 promotion") != document:
        raise BatchedCriticPreregistrationError(
            "existing v14 promotion does not reproduce exactly"
        )
    if not accepted:
        failed = sorted(name for name, passed in checks.items() if not passed)
        raise BatchedCriticPreregistrationError(
            "v14 promotion gate failed: " + ", ".join(failed)
        )
    return document


__all__ = [
    "BatchedCriticPreregistrationError",
    "V14_AUTHORIZATION_CHAIN_RELATIVE_PATH",
    "V14_AUTHORIZATION_CLAIM_SCHEMA_VERSION",
    "V14_CUMULATIVE_LOGICAL_COMPLETIONS_BEFORE",
    "V14_CODE_BUNDLE_ARCHIVE_SCHEMA_VERSION",
    "V14_DRY3_IDS_MANIFEST_ORDER",
    "V14_EVALUATION_PROFILES",
    "V14_FRESH_FOUR_STAGE_SMOKE",
    "V14_FROZEN_V13_TUNING",
    "V14_IMPLEMENTATION_CUMULATIVE_CEILING",
    "V14_PREREGISTRATION_SCHEMA_VERSION",
    "V14_PROMOTION_SCHEMA_VERSION",
    "frozen_batched_critic_promotion_gate",
    "verify_batched_critic_code_bundle_archive",
    "verify_batched_critic_preregistration",
    "verify_batched_critic_promotion",
    "write_batched_critic_preregistration",
    "write_batched_critic_code_bundle_archive",
]

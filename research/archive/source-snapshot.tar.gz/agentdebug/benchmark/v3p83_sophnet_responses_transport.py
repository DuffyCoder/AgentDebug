"""Frozen direct Sophnet Responses transport primitives for GAIA v3.83.

This module implements only one stateless ``POST /v1/responses`` call.  It
does not orchestrate cases or stages and it does not provide the model with a
filesystem, tools, prior response IDs, conversations, labels, or scored data.

JudgeView projection, strict JSON parsing, and exact stage-artifact
materialization are intentionally shared with the frozen v3.83 direct-API
adapter.  The wire payload and typed Responses output parser remain separate
from Chat Completions so that the two transports cannot be silently mixed.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import re
import socket
import time
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass
from typing import Any, Callable, Mapping, Sequence

from agentdebug.benchmark.v3p83_sophnet_transport import (
    DuplicateJsonKeyError,
    HttpAttemptAudit,
    V3P83_REASONING_EFFORT,
    V3P83_REQUESTED_MODEL,
    build_deduplicated_judge_view,
    materialize_stage_envelope,
    parse_strict_json_object,
    projection_audit,
    redact_secret,
)


SOPHNET_RESPONSES_ENDPOINT = "https://api.sophnet.com/v1/responses"
V3P83_RESPONSES_TRANSPORT_CONTRACT_VERSION = (
    "agentdebug.v3p83-sophnet-direct-responses.v2"
)
SOPHNET_PROVIDER_ENVELOPE_NORMALIZATION_VERSION = (
    "agentdebug.sophnet-responses-identical-output-type-pair.v1"
)

_SECRET_ENVIRONMENT_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_RETRYABLE_HTTP_STATUSES = frozenset({408, 429, *range(500, 600)})


class SophnetResponsesTransportError(RuntimeError):
    """A direct Responses request failed closed."""

    def __init__(
        self,
        code: str,
        message: str,
        *,
        status_code: int | None = None,
        attempts: Sequence[HttpAttemptAudit] = (),
    ) -> None:
        self.code = code
        self.status_code = status_code
        self.attempts = tuple(attempts)
        super().__init__(f"{code}: {message}")


@dataclass(frozen=True)
class ProviderEnvelopeParseResult:
    """One parsed provider envelope and its narrowly scoped quirk count."""

    document: dict[str, Any]
    identical_duplicate_type_pair_count: int


@dataclass(frozen=True)
class _JsonObjectPairs:
    pairs: tuple[tuple[str, Any], ...]


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _capture_object_pairs(pairs: list[tuple[str, Any]]) -> _JsonObjectPairs:
    return _JsonObjectPairs(tuple(pairs))


def _reject_nonstandard_constant(value: str) -> None:
    raise ValueError(f"non-standard JSON constant: {value}")


def _is_allowed_duplicate_type_pair(
    path: tuple[str | int, ...],
    key: str,
    values: Sequence[Any],
) -> bool:
    return (
        len(path) == 2
        and path[0] == "output"
        and isinstance(path[1], int)
        and key == "type"
        and len(values) == 2
        and isinstance(values[0], str)
        and values[0] == values[1]
        and values[0] in {"reasoning", "message"}
    )


def _materialize_provider_json(
    value: Any,
    *,
    path: tuple[str | int, ...],
    normalization_count: list[int],
) -> Any:
    if isinstance(value, _JsonObjectPairs):
        grouped: dict[str, list[Any]] = {}
        for key, item in value.pairs:
            grouped.setdefault(key, []).append(item)
        for key, values in grouped.items():
            if len(values) == 1:
                continue
            if not _is_allowed_duplicate_type_pair(path, key, values):
                raise DuplicateJsonKeyError(f"duplicate JSON key: {key}")
            normalization_count[0] += 1

        result: dict[str, Any] = {}
        for key, item in value.pairs:
            if key in result:
                continue
            result[key] = _materialize_provider_json(
                item,
                path=(*path, key),
                normalization_count=normalization_count,
            )
        return result
    if isinstance(value, list):
        return [
            _materialize_provider_json(
                item,
                path=(*path, index),
                normalization_count=normalization_count,
            )
            for index, item in enumerate(value)
        ]
    return value


def parse_sophnet_provider_envelope(text: str) -> ProviderEnvelopeParseResult:
    """Parse one Responses envelope with one frozen Sophnet-only exception.

    The provider is known to emit two identical ``type`` fields in direct
    members of ``response.output``.  Only an identical pair whose value is
    ``reasoning`` or ``message`` is collapsed.  Every other duplicate remains
    illegal.  JSON stored inside an ``output_text.text`` string is not parsed
    here and remains subject to the fully strict stage-output parser.
    """

    if not isinstance(text, str) or not text.strip():
        raise ValueError("provider response must be non-empty JSON text")
    try:
        captured = json.loads(
            text,
            object_pairs_hook=_capture_object_pairs,
            parse_constant=_reject_nonstandard_constant,
        )
    except json.JSONDecodeError as error:
        raise ValueError("provider response is not strict JSON") from error
    if not isinstance(captured, _JsonObjectPairs):
        raise ValueError("provider response must contain exactly one JSON object")
    count = [0]
    document = _materialize_provider_json(
        captured,
        path=(),
        normalization_count=count,
    )
    if not isinstance(document, dict):
        raise AssertionError("provider object-pair materialization changed type")
    return ProviderEnvelopeParseResult(
        document=document,
        identical_duplicate_type_pair_count=count[0],
    )


def _usage_integer(value: Any) -> int | None:
    if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
        return value
    return None


def normalize_responses_usage(value: Any) -> dict[str, Any]:
    """Normalize the documented Responses usage fields without repairing them."""

    usage = dict(value) if isinstance(value, Mapping) else {}
    input_details = usage.get("input_tokens_details")
    output_details = usage.get("output_tokens_details")
    input_details = dict(input_details) if isinstance(input_details, Mapping) else {}
    output_details = (
        dict(output_details) if isinstance(output_details, Mapping) else {}
    )
    return {
        "input_tokens": _usage_integer(usage.get("input_tokens")),
        "output_tokens": _usage_integer(usage.get("output_tokens")),
        "total_tokens": _usage_integer(usage.get("total_tokens")),
        "cached_tokens": _usage_integer(input_details.get("cached_tokens")),
        "reasoning_tokens": _usage_integer(
            output_details.get("reasoning_tokens")
        ),
    }


def _contains_exact_secret(value: Any, secret: str) -> bool:
    """Find a credential after JSON decoding, including escaped strings."""

    if isinstance(value, str):
        return secret in value
    if isinstance(value, Mapping):
        return any(
            _contains_exact_secret(key, secret)
            or _contains_exact_secret(item, secret)
            for key, item in value.items()
        )
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return any(_contains_exact_secret(item, secret) for item in value)
    return False


@dataclass(frozen=True)
class AuditedResponse:
    endpoint: str
    wire_api: str
    requested_model: str
    resolved_model: str
    reasoning_effort: str
    response_id: str
    response_status: str
    request_sha256: str
    request_bytes: int
    response_sha256: str
    response_content_sha256: str
    elapsed_seconds: float
    usage: dict[str, Any]
    reasoning_item_count: int
    provider_identical_duplicate_type_pair_count: int
    content: str
    parsed_content: dict[str, Any]
    attempts: tuple[HttpAttemptAudit, ...]

    def audit_document(self) -> dict[str, Any]:
        """Return transport provenance without content or authorization data."""

        return {
            "schema_version": "agentdebug.v3p83-sophnet-responses-call-audit.v2",
            "transport_contract": V3P83_RESPONSES_TRANSPORT_CONTRACT_VERSION,
            "endpoint": self.endpoint,
            "wire_api": self.wire_api,
            "requested_model": self.requested_model,
            "resolved_model": self.resolved_model,
            "reasoning_effort": self.reasoning_effort,
            "response_id": self.response_id,
            "response_status": self.response_status,
            "request_sha256": self.request_sha256,
            "request_bytes": self.request_bytes,
            "response_sha256": self.response_sha256,
            "response_content_sha256": self.response_content_sha256,
            "elapsed_seconds": self.elapsed_seconds,
            "usage": self.usage,
            "reasoning_item_count": self.reasoning_item_count,
            "provider_envelope_normalization": {
                "schema_version": (
                    SOPHNET_PROVIDER_ENVELOPE_NORMALIZATION_VERSION
                ),
                "applied": (
                    self.provider_identical_duplicate_type_pair_count > 0
                ),
                "identical_duplicate_type_pair_count": (
                    self.provider_identical_duplicate_type_pair_count
                ),
                "allowed_location": "$.output[*]",
                "allowed_key": "type",
                "allowed_occurrence_count": 2,
                "values_must_be_identical": True,
                "allowed_values": ["reasoning", "message"],
                "all_other_duplicates_rejected": True,
                "inner_model_output_json_fully_strict": True,
            },
            "http_attempts": [asdict(item) for item in self.attempts],
            "authorization_persisted": False,
            "redirects_enabled": False,
            "redirects_followed": False,
            "fresh_stateless_request": True,
            "store": False,
            "stream": False,
            "previous_response_id_used": False,
            "conversation_used": False,
            "tools_enabled": False,
        }


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(  # type: ignore[override]
        self,
        req: urllib.request.Request,
        fp: Any,
        code: int,
        msg: str,
        headers: Any,
        newurl: str,
    ) -> None:
        del req, fp, code, msg, headers, newurl
        return None


def _default_open(request: urllib.request.Request, *, timeout: float) -> Any:
    opener = urllib.request.build_opener(_NoRedirectHandler())
    return opener.open(request, timeout=timeout)


def _retry_after_seconds(headers: Any) -> float | None:
    if headers is None:
        return None
    try:
        value = headers.get("Retry-After")
    except AttributeError:
        return None
    try:
        seconds = float(value)
    except (TypeError, ValueError):
        return None
    return seconds if seconds >= 0 else None


def _extract_typed_output(
    provider: Mapping[str, Any],
    *,
    expected_model: str,
) -> tuple[str, str, str, int, dict[str, Any]]:
    """Extract exactly one completed assistant ``output_text`` item."""

    if provider.get("object") != "response":
        raise ValueError("provider object must be 'response'")
    response_id = provider.get("id")
    if not isinstance(response_id, str) or not response_id:
        raise ValueError("provider response omitted a non-empty response id")
    status = provider.get("status")
    if status != "completed":
        raise ValueError(f"provider response status is not completed: {status!r}")
    if provider.get("error") is not None:
        raise ValueError("completed provider response contains an error")
    if provider.get("incomplete_details") is not None:
        raise ValueError("completed provider response contains incomplete details")
    resolved_model = provider.get("model")
    if resolved_model != expected_model:
        raise ValueError(
            "resolved model mismatch: "
            f"expected {expected_model}, got {resolved_model!r}"
        )

    output = provider.get("output")
    if not isinstance(output, list) or not output:
        raise ValueError("provider response omitted typed output items")
    messages: list[Mapping[str, Any]] = []
    reasoning_item_count = 0
    for item in output:
        if not isinstance(item, Mapping):
            raise ValueError("provider output item must be a JSON object")
        item_type = item.get("type")
        if item_type == "reasoning":
            reasoning_item_count += 1
            continue
        if item_type == "message":
            messages.append(item)
            continue
        raise ValueError(f"unexpected provider output item type: {item_type!r}")
    if len(messages) != 1:
        raise ValueError("provider response must contain exactly one message item")

    message = messages[0]
    if message.get("role") != "assistant":
        raise ValueError("provider message item role must be assistant")
    if message.get("status") != "completed":
        raise ValueError("provider message item status must be completed")
    content_items = message.get("content")
    if not isinstance(content_items, list) or len(content_items) != 1:
        raise ValueError(
            "provider message must contain exactly one output_text item"
        )
    content_item = content_items[0]
    if not isinstance(content_item, Mapping):
        raise ValueError("provider message content item must be a JSON object")
    if content_item.get("type") != "output_text":
        raise ValueError("provider message content is not output_text")
    content = content_item.get("text")
    if not isinstance(content, str) or not content.strip():
        raise ValueError("provider output_text is empty or non-text")
    return (
        response_id,
        status,
        content,
        reasoning_item_count,
        normalize_responses_usage(provider.get("usage")),
    )


class SophnetResponsesClient:
    """Audited direct HTTP client for one frozen, stateless Responses call."""

    def __init__(
        self,
        *,
        api_key_env: str = "SOPHNET_API_KEY",
        endpoint: str = SOPHNET_RESPONSES_ENDPOINT,
        model: str = V3P83_REQUESTED_MODEL,
        reasoning_effort: str = V3P83_REASONING_EFFORT,
        timeout_seconds: float = 600.0,
        max_http_attempts: int = 3,
        retry_backoff_seconds: float = 2.0,
        max_retry_delay_seconds: float = 65.0,
        open_request: Callable[..., Any] | None = None,
        sleep: Callable[[float], None] = time.sleep,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        if not _SECRET_ENVIRONMENT_NAME.fullmatch(api_key_env) or "=" in api_key_env:
            raise ValueError("API key environment-variable name is invalid")
        api_key = os.environ.get(api_key_env)
        if not api_key:
            raise ValueError(f"API key environment variable {api_key_env!r} is not set")
        if endpoint != SOPHNET_RESPONSES_ENDPOINT:
            raise ValueError("v3.83 Sophnet Responses endpoint must remain frozen")
        if model != V3P83_REQUESTED_MODEL:
            raise ValueError("v3.83 Sophnet Responses model must remain gpt-5.5")
        if reasoning_effort != V3P83_REASONING_EFFORT:
            raise ValueError(
                "v3.83 Sophnet Responses reasoning effort must remain medium"
            )
        if timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be positive")
        if max_http_attempts < 1 or max_http_attempts > 5:
            raise ValueError("max_http_attempts must be between 1 and 5")
        if retry_backoff_seconds < 0 or max_retry_delay_seconds < 0:
            raise ValueError("retry delays must not be negative")
        self.endpoint = endpoint
        self.model = model
        self.reasoning_effort = reasoning_effort
        self.timeout_seconds = float(timeout_seconds)
        self.max_http_attempts = int(max_http_attempts)
        self.retry_backoff_seconds = float(retry_backoff_seconds)
        self.max_retry_delay_seconds = float(max_retry_delay_seconds)
        self._api_key = api_key
        self._open_request = open_request or _default_open
        self._sleep = sleep
        self._monotonic = monotonic

    def request_payload(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
    ) -> dict[str, Any]:
        if not isinstance(system_prompt, str) or not system_prompt.strip():
            raise ValueError("system_prompt must be non-empty text")
        if not isinstance(user_prompt, str) or not user_prompt.strip():
            raise ValueError("user_prompt must be non-empty text")
        payload = {
            "model": self.model,
            "instructions": system_prompt,
            "input": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "input_text",
                            "text": user_prompt,
                        }
                    ],
                }
            ],
            "reasoning": {"effort": self.reasoning_effort},
            "store": False,
            "stream": False,
            "text": {"format": {"type": "json_object"}},
            "tools": [],
        }
        if self._api_key.encode("utf-8") in _canonical_json_bytes(payload):
            raise SophnetResponsesTransportError(
                "secret_in_request_body",
                "the model request unexpectedly contains the API credential",
            )
        return payload

    def _delay(self, attempt: int, retry_after: float | None) -> None:
        exponential = self.retry_backoff_seconds * (2 ** max(0, attempt - 1))
        requested = retry_after if retry_after is not None else exponential
        delay = min(requested, self.max_retry_delay_seconds)
        if delay > 0:
            self._sleep(delay)

    def complete(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
    ) -> AuditedResponse:
        """Perform one logical stateless Response with transport-only retries."""

        payload = self.request_payload(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
        )
        request_body = _canonical_json_bytes(payload)
        request_sha256 = _sha256_bytes(request_body)
        attempts: list[HttpAttemptAudit] = []
        logical_started = self._monotonic()

        for attempt in range(1, self.max_http_attempts + 1):
            started = self._monotonic()
            request = urllib.request.Request(
                self.endpoint,
                data=request_body,
                method="POST",
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                },
            )
            try:
                with self._open_request(
                    request,
                    timeout=self.timeout_seconds,
                ) as response:
                    status_value = getattr(response, "status", None)
                    status_code = int(
                        status_value
                        if status_value is not None
                        else response.getcode()
                    )
                    raw_response = response.read()
                elapsed = self._monotonic() - started
            except urllib.error.HTTPError as error:
                elapsed = self._monotonic() - started
                status_code = int(error.code)
                retryable = status_code in _RETRYABLE_HTTP_STATUSES
                # Do not persist provider error bodies. Arbitrary JSON escapes
                # can otherwise bypass a raw credential substring scan.
                message = f"Sophnet returned HTTP {status_code}"
                attempts.append(
                    HttpAttemptAudit(
                        attempt=attempt,
                        request_sha256=request_sha256,
                        elapsed_seconds=elapsed,
                        status_code=status_code,
                        outcome="http_error",
                        retryable=retryable,
                        error_code="http_error",
                        error_message=message,
                    )
                )
                if retryable and attempt < self.max_http_attempts:
                    self._delay(attempt, _retry_after_seconds(error.headers))
                    continue
                raise SophnetResponsesTransportError(
                    "http_error",
                    f"Sophnet returned HTTP {status_code}: {message}",
                    status_code=status_code,
                    attempts=attempts,
                ) from None
            except (urllib.error.URLError, TimeoutError, socket.timeout) as error:
                elapsed = self._monotonic() - started
                message = redact_secret(str(error), self._api_key)
                attempts.append(
                    HttpAttemptAudit(
                        attempt=attempt,
                        request_sha256=request_sha256,
                        elapsed_seconds=elapsed,
                        status_code=None,
                        outcome="transport_error",
                        retryable=True,
                        error_code="transport_error",
                        error_message=message,
                    )
                )
                if attempt < self.max_http_attempts:
                    self._delay(attempt, None)
                    continue
                raise SophnetResponsesTransportError(
                    "transport_error",
                    f"Sophnet request failed: {message}",
                    attempts=attempts,
                ) from None

            if status_code != 200:
                message = f"unexpected HTTP status {status_code}"
                retryable = status_code in _RETRYABLE_HTTP_STATUSES
                attempts.append(
                    HttpAttemptAudit(
                        attempt=attempt,
                        request_sha256=request_sha256,
                        elapsed_seconds=elapsed,
                        status_code=status_code,
                        outcome="http_error",
                        retryable=retryable,
                        error_code="http_error",
                        error_message=message,
                    )
                )
                if retryable and attempt < self.max_http_attempts:
                    self._delay(attempt, None)
                    continue
                raise SophnetResponsesTransportError(
                    "http_error",
                    message,
                    status_code=status_code,
                    attempts=attempts,
                )

            if self._api_key.encode("utf-8") in raw_response:
                attempts.append(
                    HttpAttemptAudit(
                        attempt=attempt,
                        request_sha256=request_sha256,
                        elapsed_seconds=elapsed,
                        status_code=status_code,
                        outcome="secret_in_provider_response",
                        retryable=False,
                        error_code="secret_in_provider_response",
                        error_message=(
                            "provider response contained the request credential"
                        ),
                    )
                )
                raise SophnetResponsesTransportError(
                    "secret_in_provider_response",
                    "the provider response unexpectedly contained the API credential",
                    status_code=status_code,
                    attempts=attempts,
                )

            try:
                response_text = raw_response.decode("utf-8")
                parsed_provider = parse_sophnet_provider_envelope(response_text)
                provider = parsed_provider.document
                if _contains_exact_secret(provider, self._api_key):
                    raise SophnetResponsesTransportError(
                        "secret_in_provider_response",
                        (
                            "the decoded provider response unexpectedly "
                            "contained the API credential"
                        ),
                        status_code=status_code,
                        attempts=attempts,
                    )
                (
                    response_id,
                    response_status,
                    content,
                    reasoning_item_count,
                    usage,
                ) = _extract_typed_output(provider, expected_model=self.model)
                required_usage = tuple(usage.values())
                if any(value is None for value in required_usage):
                    raise ValueError(
                        "completed provider response omitted complete integer "
                        "token usage"
                    )
                input_tokens = usage["input_tokens"]
                output_tokens = usage["output_tokens"]
                total_tokens = usage["total_tokens"]
                cached_tokens = usage["cached_tokens"]
                reasoning_tokens = usage["reasoning_tokens"]
                if input_tokens + output_tokens != total_tokens:
                    raise ValueError("provider total token usage is inconsistent")
                if cached_tokens > input_tokens:
                    raise ValueError("provider cached token usage exceeds input usage")
                if reasoning_tokens > output_tokens:
                    raise ValueError(
                        "provider reasoning token usage exceeds output usage"
                    )
                parsed_content = parse_strict_json_object(content)
            except SophnetResponsesTransportError:
                attempts.append(
                    HttpAttemptAudit(
                        attempt=attempt,
                        request_sha256=request_sha256,
                        elapsed_seconds=elapsed,
                        status_code=status_code,
                        outcome="secret_in_provider_response",
                        retryable=False,
                        error_code="secret_in_provider_response",
                        error_message=(
                            "decoded provider response contained the request credential"
                        ),
                    )
                )
                raise SophnetResponsesTransportError(
                    "secret_in_provider_response",
                    "the provider response unexpectedly contained the API credential",
                    status_code=status_code,
                    attempts=attempts,
                ) from None
            except (KeyError, TypeError, UnicodeDecodeError, ValueError) as error:
                message = redact_secret(str(error), self._api_key)
                attempts.append(
                    HttpAttemptAudit(
                        attempt=attempt,
                        request_sha256=request_sha256,
                        elapsed_seconds=elapsed,
                        status_code=status_code,
                        outcome="invalid_provider_response",
                        retryable=False,
                        error_code="invalid_provider_response",
                        error_message=message,
                    )
                )
                raise SophnetResponsesTransportError(
                    "invalid_provider_response",
                    message,
                    status_code=status_code,
                    attempts=attempts,
                ) from None

            attempts.append(
                HttpAttemptAudit(
                    attempt=attempt,
                    request_sha256=request_sha256,
                    elapsed_seconds=elapsed,
                    status_code=status_code,
                    outcome="success",
                    retryable=False,
                )
            )
            return AuditedResponse(
                endpoint=self.endpoint,
                wire_api="responses",
                requested_model=self.model,
                resolved_model=self.model,
                reasoning_effort=self.reasoning_effort,
                response_id=response_id,
                response_status=response_status,
                request_sha256=request_sha256,
                request_bytes=len(request_body),
                response_sha256=_sha256_bytes(raw_response),
                response_content_sha256=_sha256_bytes(content.encode("utf-8")),
                elapsed_seconds=self._monotonic() - logical_started,
                usage=usage,
                reasoning_item_count=reasoning_item_count,
                provider_identical_duplicate_type_pair_count=(
                    parsed_provider.identical_duplicate_type_pair_count
                ),
                content=content,
                parsed_content=parsed_content,
                attempts=tuple(attempts),
            )

        raise AssertionError("unreachable Sophnet Responses HTTP retry state")

    async def acomplete(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
    ) -> AuditedResponse:
        """Async facade with identical request bytes and validation semantics."""

        return await asyncio.to_thread(
            self.complete,
            system_prompt=system_prompt,
            user_prompt=user_prompt,
        )


__all__ = [
    "AuditedResponse",
    "ProviderEnvelopeParseResult",
    "SOPHNET_RESPONSES_ENDPOINT",
    "SOPHNET_PROVIDER_ENVELOPE_NORMALIZATION_VERSION",
    "SophnetResponsesClient",
    "SophnetResponsesTransportError",
    "V3P83_RESPONSES_TRANSPORT_CONTRACT_VERSION",
    "build_deduplicated_judge_view",
    "materialize_stage_envelope",
    "normalize_responses_usage",
    "parse_strict_json_object",
    "parse_sophnet_provider_envelope",
    "projection_audit",
    "redact_secret",
]

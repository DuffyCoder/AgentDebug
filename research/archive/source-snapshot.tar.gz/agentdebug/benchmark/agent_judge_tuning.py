"""Full-cohort, tuning-v1-only workflow for active Agent Judge optimization.

This module replaces the former 3x3 semantic gate in the active workflow.
Engineering checks stay synthetic and deterministic; every semantic candidate
is run on the same frozen 30-trajectory tuning-v1 cohort, strictly validated,
then scored.  Prediction distributions are diagnostics, never promotion gates.
"""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any, Mapping

from agentdebug.diagnostics.agent_judge_luna_v9 import (
    CHALLENGER_PROPOSAL_FILENAME,
    INCUMBENT_PROPOSAL_FILENAME,
)

from .agent_judge_workflow import (
    AgentJudgeWorkflowError,
    prepare_agent_judge_run,
    validate_agent_judge_run,
)
from .prediction_manifest import load_prediction_manifest, stable_sha256


ACTIVE_TUNING_PROTOCOL = "luna-v16-unified"
DEFAULT_MONOLITHIC_TUNING_PROTOCOL = "luna-v12-standalone"
LUNA_V3_INCUMBENT_PREDICTIONS = (
    Path(__file__).resolve().parents[2]
    / "output/agenterrorbench-codex-gpt-5.6-luna-tuning-v1-agent-judge-luna-v3-case30"
    / "predictions.json"
)
LUNA_V4_CHALLENGER_PREDICTIONS = (
    Path(__file__).resolve().parents[2]
    / "output/agenterrorbench-codex-gpt-5.6-luna-tuning-v1-agent-judge-luna-v4-case30"
    / "predictions.json"
)
TUNING_V1_COHORT_NAME = "tuning-v1"
TUNING_V1_EXPECTED_COUNT = 30
TUNING_V1_ENVIRONMENTS = ("alfworld", "gaia", "webshop")
TUNING_V1_PER_ENVIRONMENT = 10
TUNING_V1_DATASET_SHA256 = (
    "fa78de42eb1de06e3566555bd8c68f09deaa6930f2b07ac8937ded858cc6ac11"
)
TUNING_V1_COHORT_SHA256 = (
    "e21b1034470577688b68aad2a0e006facc658fed28bdb986fed039bc0347bd6f"
)
TUNING_V1_PREDICTION_MANIFEST_SHA256 = (
    "651acd1fa0dff6eae945406ad9cbe9f6c527cdff67b45874e0fac23576f785ad"
)

LIGHTWEIGHT_ENGINEERING_TESTS = (
    "tests/test_agent_judge_luna_v1.py",
    "tests/test_agent_judge_tuning.py",
    "tests/test_agent_judge_shards.py",
)
PROMOTION_METRIC_ORDER = (
    "step_exact",
    "step_module_exact",
    "all_correct",
    "failed_prediction_count",
)


def _load_json(path: Path, *, role: str) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise AgentJudgeWorkflowError(
            f"{role} is missing or invalid JSON"
        ) from error


def _atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def validate_tuning_v1_inputs(
    *,
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
) -> dict[str, Any]:
    """Fail closed unless inputs are the exact frozen full tuning-v1 cohort."""

    prediction_path = Path(prediction_manifest_path).expanduser().resolve()
    cohort_path = Path(cohort_manifest_path).expanduser().resolve()
    manifest, cases = load_prediction_manifest(prediction_path)
    cohort = _load_json(cohort_path, role="tuning-v1 cohort manifest")
    if not isinstance(cohort, dict):
        raise AgentJudgeWorkflowError("tuning-v1 cohort manifest must be an object")
    body = dict(cohort)
    claimed_cohort_sha256 = body.pop("cohort_sha256", None)
    if claimed_cohort_sha256 != stable_sha256(body):
        raise AgentJudgeWorkflowError("tuning-v1 cohort content hash is invalid")

    trajectory_ids = cohort.get("trajectory_ids")
    entries = cohort.get("entries")
    if (
        not isinstance(trajectory_ids, list)
        or not isinstance(entries, list)
        or len(trajectory_ids) != TUNING_V1_EXPECTED_COUNT
        or len(entries) != TUNING_V1_EXPECTED_COUNT
    ):
        raise AgentJudgeWorkflowError(
            "active tuning requires the complete 30-trajectory tuning-v1 cohort"
        )
    case_ids = [case.trajectory_id for case in cases]
    if case_ids != trajectory_ids:
        raise AgentJudgeWorkflowError(
            "tuning prediction manifest and cohort order differ"
        )
    if any(
        not isinstance(entry, Mapping)
        or entry.get("trajectory_id") != trajectory_id
        for entry, trajectory_id in zip(entries, trajectory_ids, strict=True)
    ):
        raise AgentJudgeWorkflowError("tuning-v1 entries do not match cohort order")

    environments = Counter(
        str(entry.get("environment"))
        for entry in entries
        if isinstance(entry, Mapping)
    )
    expected_environments = {
        environment: TUNING_V1_PER_ENVIRONMENT
        for environment in TUNING_V1_ENVIRONMENTS
    }
    if dict(environments) != expected_environments:
        raise AgentJudgeWorkflowError(
            "tuning-v1 must contain exactly ten trajectories per environment"
        )

    expected_identity = {
        "cohort_name": TUNING_V1_COHORT_NAME,
        "dataset_manifest_sha256": TUNING_V1_DATASET_SHA256,
        "cohort_sha256": TUNING_V1_COHORT_SHA256,
        "prediction_manifest_sha256": TUNING_V1_PREDICTION_MANIFEST_SHA256,
    }
    observed_identity = {
        "cohort_name": manifest.get("cohort_name"),
        "dataset_manifest_sha256": manifest.get("dataset_manifest_sha256"),
        "cohort_sha256": manifest.get("cohort_sha256"),
        "prediction_manifest_sha256": manifest.get(
            "prediction_manifest_sha256"
        ),
    }
    if observed_identity != expected_identity:
        raise AgentJudgeWorkflowError(
            "active tuning inputs are not the frozen tuning-v1 identity"
        )
    if (
        cohort.get("cohort_name") != TUNING_V1_COHORT_NAME
        or cohort.get("dataset_manifest_sha256") != TUNING_V1_DATASET_SHA256
        or claimed_cohort_sha256 != TUNING_V1_COHORT_SHA256
    ):
        raise AgentJudgeWorkflowError(
            "active tuning cohort is not the frozen tuning-v1 identity"
        )
    return {
        **expected_identity,
        "trajectory_count": len(case_ids),
        "environment_counts": expected_environments,
        "prediction_manifest_path": str(prediction_path),
        "cohort_manifest_path": str(cohort_path),
    }


def prepare_tuning_v1_run(
    *,
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    run_dir: str | Path,
    protocol: str = DEFAULT_MONOLITHIC_TUNING_PROTOCOL,
) -> dict[str, Any]:
    """Prepare one legacy monolithic tuning-v1 task.

    The active v16 protocol deliberately accepts only one-case manifests and
    must be launched through its isolated-session runner.  Keeping that
    topology out of this legacy one-task helper prevents an accidental
    30-trajectories-in-one-session run.
    """

    identity = validate_tuning_v1_inputs(
        prediction_manifest_path=prediction_manifest_path,
        cohort_manifest_path=cohort_manifest_path,
    )
    if protocol == ACTIVE_TUNING_PROTOCOL:
        raise AgentJudgeWorkflowError(
            "luna-v16-unified requires the dedicated 30-session tuning runner"
        )
    if protocol in {
        "luna-v7",
        "luna-v8",
        "luna-v9",
        "luna-v10",
        "luna-v11",
        "luna-v12",
    }:
        validate_agent_judge_run(
            prediction_manifest_path=prediction_manifest_path,
            cohort_manifest_path=cohort_manifest_path,
            predictions_path=LUNA_V3_INCUMBENT_PREDICTIONS,
            protocol="luna-v3",
        )
        incumbent = _load_json(
            LUNA_V3_INCUMBENT_PREDICTIONS,
            role="Luna v3 incumbent predictions",
        )
        _atomic_json(
            Path(run_dir).expanduser().resolve() / INCUMBENT_PROPOSAL_FILENAME,
            incumbent,
        )
    if protocol == "luna-v9":
        validate_agent_judge_run(
            prediction_manifest_path=prediction_manifest_path,
            cohort_manifest_path=cohort_manifest_path,
            predictions_path=LUNA_V4_CHALLENGER_PREDICTIONS,
            protocol="luna-v4",
        )
        challenger = _load_json(
            LUNA_V4_CHALLENGER_PREDICTIONS,
            role="Luna v4 challenger predictions",
        )
        _atomic_json(
            Path(run_dir).expanduser().resolve() / CHALLENGER_PROPOSAL_FILENAME,
            challenger,
        )
    document = prepare_agent_judge_run(
        prediction_manifest_path=prediction_manifest_path,
        cohort_manifest_path=cohort_manifest_path,
        run_dir=run_dir,
        protocol=protocol,
    )
    if (
        document["prediction_manifest"]["entry_count"]
        != TUNING_V1_EXPECTED_COUNT
    ):
        raise AgentJudgeWorkflowError("prepared tuning run is not full tuning-v1")
    return {**document, "optimization_scope": identity}


def tuning_v1_prediction_diagnostics(
    *,
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    protocol: str = ACTIVE_TUNING_PROTOCOL,
) -> dict[str, Any]:
    """Strictly validate full tuning output and report non-gating diagnostics."""

    validate_tuning_v1_inputs(
        prediction_manifest_path=prediction_manifest_path,
        cohort_manifest_path=cohort_manifest_path,
    )
    audit = validate_agent_judge_run(
        prediction_manifest_path=prediction_manifest_path,
        cohort_manifest_path=cohort_manifest_path,
        predictions_path=predictions_path,
        protocol=protocol,
    )
    predictions = _load_json(
        Path(predictions_path).expanduser().resolve(),
        role="tuning-v1 predictions",
    )
    if not isinstance(predictions, list):
        raise AgentJudgeWorkflowError("tuning-v1 predictions must be an array")
    module_counts = Counter(
        str(record.get("predicted_module"))
        for record in predictions
        if isinstance(record, Mapping)
    )
    type_counts = Counter(
        str(record.get("predicted_error_type"))
        for record in predictions
        if isinstance(record, Mapping)
    )
    return {
        "scope": TUNING_V1_COHORT_NAME,
        "trajectory_count": len(predictions),
        "strict_validation_passed": True,
        "distribution_is_promotion_gate": False,
        "module_counts": dict(sorted(module_counts.items())),
        "error_type_counts": dict(sorted(type_counts.items())),
        "validation_audit": audit,
    }


def _overall(metrics: Mapping[str, Any]) -> Mapping[str, Any]:
    try:
        value = metrics["by_method"]["agent_judge"]["overall"]
    except (KeyError, TypeError) as error:
        raise AgentJudgeWorkflowError(
            "tuning metrics do not contain agent_judge overall results"
        ) from error
    if not isinstance(value, Mapping):
        raise AgentJudgeWorkflowError("tuning overall metrics are invalid")
    return value


def tuning_v1_metric_key(metrics: Mapping[str, Any]) -> tuple[int, int, int, int]:
    """Return the frozen lexicographic tuning promotion key."""

    overall = _overall(metrics)
    if overall.get("trajectory_count") != TUNING_V1_EXPECTED_COUNT:
        raise AgentJudgeWorkflowError("promotion metrics must cover full tuning-v1")
    try:
        step = int(overall["step_exact"]["correct"])
        step_module = int(overall["step_module_exact"]["correct"])
        all_correct = int(overall["all_correct"]["correct"])
        failures = int(overall["failed_prediction_count"])
    except (KeyError, TypeError, ValueError) as error:
        raise AgentJudgeWorkflowError("promotion metrics are incomplete") from error
    return (step, step_module, all_correct, -failures)


def compare_tuning_v1_metrics(
    *,
    candidate: Mapping[str, Any],
    incumbent: Mapping[str, Any],
) -> dict[str, Any]:
    """Compare against the best full tuning incumbent, never the last run."""

    candidate_key = tuning_v1_metric_key(candidate)
    incumbent_key = tuning_v1_metric_key(incumbent)
    return {
        "metric_order": list(PROMOTION_METRIC_ORDER),
        "candidate_key": list(candidate_key),
        "incumbent_key": list(incumbent_key),
        "promote": candidate_key > incumbent_key,
        "tie": candidate_key == incumbent_key,
    }


__all__ = [
    "ACTIVE_TUNING_PROTOCOL",
    "DEFAULT_MONOLITHIC_TUNING_PROTOCOL",
    "LIGHTWEIGHT_ENGINEERING_TESTS",
    "PROMOTION_METRIC_ORDER",
    "TUNING_V1_COHORT_NAME",
    "TUNING_V1_COHORT_SHA256",
    "TUNING_V1_DATASET_SHA256",
    "TUNING_V1_ENVIRONMENTS",
    "TUNING_V1_EXPECTED_COUNT",
    "TUNING_V1_PER_ENVIRONMENT",
    "TUNING_V1_PREDICTION_MANIFEST_SHA256",
    "compare_tuning_v1_metrics",
    "prepare_tuning_v1_run",
    "tuning_v1_metric_key",
    "tuning_v1_prediction_diagnostics",
    "validate_tuning_v1_inputs",
]

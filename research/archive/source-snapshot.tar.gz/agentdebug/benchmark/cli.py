"""Command-line interface for AgentErrorBench inspection and evaluation."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from agentdebug.diagnostics import (
    DIAGNOSTIC_PIPELINE_VERSION,
    EVIDENCE_VALIDATION_VERSION,
    JUDGE_VIEW_VERSION,
    GeminiGenerateContentJudge,
    OpenAICompatibleJudge,
    resolve_judge_endpoint,
)

from .acceptance import (
    FINAL_ACCEPTANCE_SCHEMA_VERSION,
    AcceptanceError,
    verify_final_smoke_artifacts,
)
from .batched_causal_preregistration import (
    E9_IMPLEMENTATION_CUMULATIVE_CEILING,
    E9_PREREGISTRATION_SCHEMA_VERSION,
    verify_batched_causal_preregistration,
)
from .cohort import (
    CohortManifest,
    CohortManifestError,
    load_cohort_manifest,
    write_default_cohort_manifests,
)
from .dataset import DatasetSchemaError, load_agent_error_bench
from .metrics import compute_metrics
from .prompts import (
    DIRECT_PROMPT_VERSION,
    TWO_STAGE_PIPELINE_VERSION,
    TWO_STAGE_PROMPT_VERSION,
)
from .prompts import direct_messages
from .prediction_manifest import (
    build_prediction_case,
    load_prediction_manifest,
    stable_sha256,
    write_prediction_manifest,
)
from .production_workflow import (
    PRODUCTION_TWO_STAGE_PIPELINE_VERSION,
    score_persisted_predictions,
)
from .preregistration import (
    PreregistrationError,
    verify_production_preregistration,
    write_production_preregistration,
)
from .reporting import write_outputs
from .runner import (
    BenchmarkRunConfig,
    TRANSPORT_POLICY_VERSION,
    conversion_failure_records,
    evaluate_examples,
    provider_telemetry_snapshot,
)


_E9_BRIDGE_PREREGISTRATION_FILENAME = "preregistration.json"
_E9_BRIDGE_PROFILE = "smoke30"
_E9_BRIDGE_LOGICAL_COMPLETIONS = 22
_E9_BRIDGE_CUMULATIVE_BEFORE = 362
_E9_BRIDGE_HARD_STOP = 384


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="agentdebug-benchmark",
        description="Audit and evaluate the AgentErrorBench release.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    inspect_parser = subparsers.add_parser(
        "inspect",
        help="Validate release schema and convert every available trajectory.",
    )
    inspect_parser.add_argument("--dataset", required=True)
    inspect_parser.add_argument("--output")

    cohorts = subparsers.add_parser(
        "create-cohorts",
        help=(
            "Freeze deterministic, disjoint tuning-v1 and smoke-v1 manifests."
        ),
    )
    cohorts.add_argument("--dataset", required=True)
    cohorts.add_argument("--output-dir", required=True)
    cohorts.add_argument("--per-environment", type=int, default=10)

    prepare = subparsers.add_parser(
        "prepare-prediction",
        help=(
            "Freeze a gold-free production JudgeView manifest without "
            "constructing a provider client."
        ),
    )
    prepare.add_argument("--dataset", required=True)
    prepare.add_argument("--cohort-manifest", required=True)
    prepare.add_argument("--output", required=True)
    prepare.add_argument("--expected-count", type=int, required=True)

    preregister = subparsers.add_parser(
        "preregister-prediction",
        help="Freeze production code, provider, artifact, gate, and call budget.",
    )
    preregister.add_argument("--experiment-name", required=True)
    preregister.add_argument("--prediction-manifest", required=True)
    preregister.add_argument("--output", required=True)
    preregister.add_argument("--run-output-dir", required=True)
    preregister.add_argument("--cache-dir", required=True)
    preregister.add_argument("--expected-count", type=int, required=True)
    preregister.add_argument(
        "--cumulative-logical-completions-before",
        type=int,
        required=True,
    )
    preregister.add_argument(
        "--maximum-new-logical-completions",
        type=int,
        required=True,
    )
    preregister.add_argument(
        "--judge-provider",
        choices=("openai-compatible", "gemini-generate-content"),
        required=True,
    )
    preregister.add_argument("--judge-base-url", required=True)
    preregister.add_argument("--judge-api-key-env", required=True)
    preregister.add_argument("--judge-model", required=True)
    preregister.add_argument("--judge-temperature", type=float, required=True)
    preregister.add_argument("--judge-timeout", type=float, required=True)
    preregister.add_argument(
        "--judge-max-output-tokens",
        type=int,
        required=True,
    )
    preregister.add_argument(
        "--judge-max-retries",
        type=int,
        required=True,
    )
    preregister.add_argument(
        "--judge-retry-backoff",
        type=float,
        required=True,
    )

    verify_final = subparsers.add_parser(
        "verify-final-smoke",
        help=(
            "Rebuild the fixed smoke result from persisted raw stages and "
            "write a fail-closed acceptance artifact."
        ),
    )
    verify_final.add_argument("--dataset", required=True)
    verify_final.add_argument("--cohort-manifest", required=True)
    verify_final.add_argument("--output-dir", required=True)
    verify_final.add_argument(
        "--output",
        help=(
            "Acceptance JSON path; defaults to "
            "<output-dir>/acceptance.json."
        ),
    )

    run = subparsers.add_parser(
        "run",
        help="Run Direct Prompting and/or the production two-stage judge.",
    )
    run.add_argument("--dataset", required=True)
    run.add_argument("--output-dir", required=True)
    run.add_argument("--cache-dir")
    run.add_argument(
        "--prepared-prediction-manifest",
        help=(
            "Use this already frozen gold-free manifest without rewriting it."
        ),
    )
    run.add_argument(
        "--preregistration",
        help=(
            "Verify this write-once production preregistration before any "
            "uncached judge completion."
        ),
    )
    run.add_argument(
        "--cohort-manifest",
        help=(
            "Strict frozen cohort manifest. It cannot be combined with --limit "
            "or --trajectory-id."
        ),
    )
    run.add_argument(
        "--methods",
        default="direct,two_stage",
        help="Comma-separated subset of direct,two_stage.",
    )
    run.add_argument(
        "--judge-provider",
        choices=("openai-compatible", "gemini-generate-content"),
        default="openai-compatible",
    )
    run.add_argument("--judge-base-url", required=True)
    run.add_argument("--judge-api-key-env", required=True)
    run.add_argument("--judge-model", required=True)
    run.add_argument("--judge-temperature", type=float, default=0.0)
    run.add_argument("--judge-timeout", type=float, default=120.0)
    run.add_argument("--judge-max-output-tokens", type=int, default=8192)
    run.add_argument("--judge-max-retries", type=int, default=5)
    run.add_argument("--judge-retry-backoff", type=float, default=2.0)
    run.add_argument("--workers", type=int, default=1)
    run.add_argument(
        "--max-logical-completions",
        type=int,
        help=(
            "Fail before an uncached semantic stage would exceed this "
            "per-run logical-completion budget."
        ),
    )
    run.add_argument(
        "--order",
        choices=("dataset", "prompt-size"),
        default="dataset",
        help="Execution order only; never changes the metric cohort.",
    )
    run.add_argument("--limit", type=int)
    run.add_argument(
        "--trajectory-id",
        action="append",
        default=[],
        help="Evaluate only this trajectory ID; repeat for multiple IDs.",
    )
    run.add_argument(
        "--retry-failures",
        action="store_true",
        help="Reuse successful cache entries but rerun cached failures.",
    )
    run.add_argument(
        "--resume",
        action="store_true",
        help=(
            "Resume a previously interrupted hash-locked production run. "
            "Without this flag, pre-existing run artifacts are rejected."
        ),
    )
    return parser


def _inspect(args: argparse.Namespace) -> int:
    dataset = load_agent_error_bench(args.dataset)
    audit = dataset.audit_dict()
    text = json.dumps(audit, ensure_ascii=False, indent=2)
    if args.output:
        path = Path(args.output).expanduser().resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0 if not dataset.conversion_failures else 2


def _create_cohorts(args: argparse.Namespace) -> int:
    dataset = load_agent_error_bench(args.dataset)
    result = write_default_cohort_manifests(
        dataset,
        output_dir=args.output_dir,
        per_environment=args.per_environment,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def _prepare_prediction(args: argparse.Namespace) -> int:
    if args.expected_count < 1:
        raise ValueError("--expected-count must be positive")
    dataset = load_agent_error_bench(args.dataset)
    cohort = load_cohort_manifest(
        args.cohort_manifest,
        dataset=dataset,
    )
    selected = cohort.examples_from(dataset)
    if len(selected) != args.expected_count:
        raise ValueError(
            "prepared prediction count does not match --expected-count"
        )
    document = write_prediction_manifest(
        traces_and_mappings=[
            (example.trace, example.mapping) for example in selected
        ],
        dataset_manifest_sha256=dataset.dataset_sha256,
        cohort_name=cohort.cohort_name,
        cohort_sha256=cohort.cohort_sha256,
        selection_identity={
            "selection_name": cohort.cohort_name,
            "cohort_sha256": cohort.cohort_sha256,
            "trajectory_ids": list(cohort.trajectory_ids),
            "execution_order": "cohort-manifest",
            "expected_count": args.expected_count,
        },
        output_path=args.output,
    )
    print(
        json.dumps(
            {
                "output": str(Path(args.output).expanduser().resolve()),
                "entry_count": document["entry_count"],
                "prediction_manifest_sha256": document[
                    "prediction_manifest_sha256"
                ],
                "external_calls": 0,
                "gold_free": True,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _preregister_prediction(args: argparse.Namespace) -> int:
    manifest, _ = load_prediction_manifest(args.prediction_manifest)
    endpoint = resolve_judge_endpoint(
        provider=args.judge_provider,
        base_url=args.judge_base_url,
        model=args.judge_model,
    )
    config = BenchmarkRunConfig(
        model=args.judge_model,
        temperature=args.judge_temperature,
        provider=args.judge_provider,
        endpoint=endpoint,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
        cohort_sha256=manifest["cohort_sha256"],
        api_key_env=args.judge_api_key_env,
    )
    document = write_production_preregistration(
        experiment_name=args.experiment_name,
        prediction_manifest_path=args.prediction_manifest,
        output_path=args.output,
        run_output_dir=args.run_output_dir,
        cache_dir=args.cache_dir,
        config=config,
        expected_count=args.expected_count,
        cumulative_logical_completions_before=(
            args.cumulative_logical_completions_before
        ),
        maximum_new_logical_completions=(
            args.maximum_new_logical_completions
        ),
    )
    print(
        json.dumps(
            {
                "output": str(Path(args.output).expanduser().resolve()),
                "preregistration_sha256": document[
                    "preregistration_sha256"
                ],
                "code_bundle_sha256": document["code_bundle_sha256"],
                "maximum_new_logical_completions": document[
                    "logical_completion_budget"
                ]["maximum_new"],
                "hard_cumulative_stop": document[
                    "logical_completion_budget"
                ]["hard_cumulative_stop"],
                "external_calls": 0,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _verify_final_smoke(args: argparse.Namespace) -> int:
    dataset = load_agent_error_bench(args.dataset)
    cohort = load_cohort_manifest(
        args.cohort_manifest,
        dataset=dataset,
    )
    result = verify_final_smoke_artifacts(
        dataset=dataset,
        cohort=cohort,
        output_dir=args.output_dir,
    )
    output_path = (
        Path(args.output).expanduser().resolve()
        if args.output
        else Path(args.output_dir).expanduser().resolve()
        / "acceptance.json"
    )
    document = {
        "schema_version": FINAL_ACCEPTANCE_SCHEMA_VERSION,
        "output_dir": str(
            Path(args.output_dir).expanduser().resolve()
        ),
        **result.to_dict(),
    }
    document["acceptance_sha256"] = stable_sha256(document)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = output_path.with_suffix(
        f"{output_path.suffix}.{os.getpid()}.tmp"
    )
    temporary.write_text(
        json.dumps(document, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(output_path)
    print(
        json.dumps(
            {
                "accepted": True,
                "output": str(output_path),
                "acceptance_sha256": document["acceptance_sha256"],
                "step_correct": result.summary["step_correct"],
                "step_denominator": result.summary[
                    "step_denominator"
                ],
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _run_prediction_subprocess(
    *,
    args: argparse.Namespace,
    manifest_path: Path,
    cache_dir: Path,
    unscored_output_path: Path,
    predict_run_metadata_path: Path,
    cohort_sha256: str,
) -> None:
    """Run the credential-bearing judge in a process with no dataset path."""

    command = [
        sys.executable,
        "-m",
        "agentdebug.benchmark.prediction_worker",
        "--manifest",
        str(manifest_path),
        "--cache-dir",
        str(cache_dir),
        "--output",
        str(unscored_output_path),
        "--run-metadata",
        str(predict_run_metadata_path),
        "--judge-provider",
        args.judge_provider,
        "--judge-base-url",
        args.judge_base_url,
        "--judge-api-key-env",
        args.judge_api_key_env,
        "--judge-model",
        args.judge_model,
        "--judge-temperature",
        str(args.judge_temperature),
        "--judge-timeout",
        str(args.judge_timeout),
        "--judge-max-output-tokens",
        str(args.judge_max_output_tokens),
        "--judge-max-retries",
        str(args.judge_max_retries),
        "--judge-retry-backoff",
        str(args.judge_retry_backoff),
        "--cohort-sha256",
        cohort_sha256,
    ]
    if args.retry_failures:
        command.append("--retry-failures")
    preregistration_path = getattr(args, "preregistration", None)
    if preregistration_path:
        command.extend(
            [
                "--preregistration",
                str(
                    Path(preregistration_path).expanduser().resolve()
                ),
            ]
        )
    max_logical_completions = getattr(
        args,
        "max_logical_completions",
        None,
    )
    if max_logical_completions is not None:
        command.extend(
            [
                "--max-logical-completions",
                str(max_logical_completions),
            ]
        )
    subprocess.run(command, check=True)


def _reject_duplicate_bridge_keys(
    pairs: list[tuple[str, Any]],
) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, item in pairs:
        if key in value:
            raise ValueError(
                f"E9 bridge preregistration contains duplicate key: {key}"
            )
        value[key] = item
    return value


def _load_e9_bridge_preregistration(path: Path) -> dict[str, Any]:
    try:
        document = json.loads(
            path.read_text(encoding="utf-8"),
            object_pairs_hook=_reject_duplicate_bridge_keys,
        )
    except (OSError, json.JSONDecodeError) as error:
        raise ValueError(
            "E9 bridge preregistration is missing or invalid JSON"
        ) from error
    if not isinstance(document, dict):
        raise ValueError("E9 bridge preregistration must be an object")
    body = dict(document)
    claimed = body.pop("preregistration_sha256", None)
    if (
        document.get("schema_version")
        != E9_PREREGISTRATION_SCHEMA_VERSION
        or not isinstance(claimed, str)
        or claimed != stable_sha256(body)
    ):
        raise ValueError(
            "E9 bridge preregistration schema or self-hash is invalid"
        )
    return document


def _bridge_mapping(
    value: Mapping[str, Any],
    key: str,
) -> Mapping[str, Any]:
    item = value.get(key)
    if not isinstance(item, Mapping):
        raise ValueError(
            f"E9 bridge preregistration field {key!r} must be an object"
        )
    return item


def _bridge_path(value: Any, *, label: str) -> Path:
    if not isinstance(value, str) or not value:
        raise ValueError(f"E9 bridge {label} path is invalid")
    return Path(value).expanduser().resolve()


def _validate_e9_bridge_identity(
    *,
    args: argparse.Namespace,
    document: Mapping[str, Any],
    dataset: Any,
    cohort: CohortManifest,
    selected: list[Any],
    config: BenchmarkRunConfig,
    preregistration_path: Path,
    output_root: Path,
    cache_dir: Path,
) -> dict[str, Any]:
    evaluation = _bridge_mapping(document, "evaluation")
    selection = _bridge_mapping(document, "selection")
    prediction = _bridge_mapping(document, "prediction_manifest")
    plan = _bridge_mapping(document, "batch_plan")
    execution = _bridge_mapping(document, "execution")
    budget = _bridge_mapping(document, "logical_completion_budget")

    prediction_path = _bridge_path(
        prediction.get("path"),
        label="prediction manifest",
    )
    plan_path = _bridge_path(plan.get("path"), label="batch plan")
    run_output_path = _bridge_path(
        execution.get("run_output_dir"),
        label="run output",
    )
    registered_cache_path = _bridge_path(
        execution.get("cache_dir"),
        label="cache",
    )
    unscored_path = _bridge_path(
        execution.get("unscored_predictions_path"),
        label="unscored predictions",
    )
    predict_run_path = _bridge_path(
        execution.get("predict_run_metadata_path"),
        label="predict run",
    )
    scored_output_path = _bridge_path(
        execution.get("scored_output_dir"),
        label="scored output",
    )
    ledger_path = _bridge_path(
        execution.get("logical_completion_ledger_path"),
        label="logical-completion ledger",
    )
    selected_ids = [
        example.mapping.trajectory_id for example in selected
    ]
    cohort_path = (
        cohort.path.expanduser().resolve()
        if isinstance(cohort.path, Path)
        else None
    )
    expected_provider = config.public_dict()
    expected_budget = {
        "cumulative_before": _E9_BRIDGE_CUMULATIVE_BEFORE,
        "maximum_new": _E9_BRIDGE_LOGICAL_COMPLETIONS,
        "hard_cumulative_stop": _E9_BRIDGE_HARD_STOP,
    }
    authorized_ceiling = budget.get("authorized_cumulative_ceiling")
    if (
        isinstance(authorized_ceiling, bool)
        or not isinstance(authorized_ceiling, int)
        or authorized_ceiling < _E9_BRIDGE_HARD_STOP
    ):
        raise ValueError(
            "E9 v13 smoke requires an explicit cumulative authorization "
            f"of at least {_E9_BRIDGE_HARD_STOP}; the preregistration "
            f"authorizes {authorized_ceiling!r}"
        )
    if authorized_ceiling > E9_IMPLEMENTATION_CUMULATIVE_CEILING:
        raise ValueError(
            "E9 v13 smoke authorization exceeds the implementation ceiling"
        )

    checks = {
        "preregistration_path": document.get("preregistration_path")
        == str(preregistration_path),
        "profile": evaluation.get("profile") == _E9_BRIDGE_PROFILE,
        "heldout": evaluation.get("heldout") is True,
        "dataset_path": evaluation.get("dataset_path")
        == str(Path(args.dataset).expanduser().resolve()),
        "dataset_hash": evaluation.get("dataset_manifest_sha256")
        == dataset.dataset_sha256,
        "cohort_manifest_path": (
            cohort_path is not None
            and evaluation.get("cohort_manifest_path")
            == str(cohort_path)
        ),
        "cohort_name": (
            cohort.cohort_name == "smoke-v1"
            and evaluation.get("cohort_name") == cohort.cohort_name
            and prediction.get("cohort_name") == cohort.cohort_name
        ),
        "cohort_hash": (
            evaluation.get("cohort_sha256") == cohort.cohort_sha256
            and prediction.get("cohort_sha256") == cohort.cohort_sha256
        ),
        "dataset_lineage": prediction.get("dataset_manifest_sha256")
        == dataset.dataset_sha256,
        "selection": (
            len(selected_ids) == 30
            and selection.get("count") == 30
            and selection.get("trajectory_ids") == selected_ids
        ),
        "manifest_count": prediction.get("entry_count") == 30,
        "batch_count": plan.get("batch_count") == 11,
        "provider_config": document.get("provider_config")
        == expected_provider,
        "run_output": run_output_path == output_root,
        "cache": registered_cache_path == cache_dir,
        "unscored_output": unscored_path
        == output_root / "unscored-predictions.jsonl",
        "predict_run": predict_run_path == output_root / "predict-run.json",
        "scored_output": scored_output_path == output_root,
        "ledger": ledger_path
        == output_root / "logical-completion-ledger.json",
        "workers": execution.get("workers") == 1,
        "retry_failures": execution.get("retry_failures") is False,
        "budget": all(
            budget.get(key) == expected
            for key, expected in expected_budget.items()
        ),
        "standard_run_shape": (
            args.methods.strip() == "two_stage"
            and args.workers == 1
            and args.order == "dataset"
            and args.prepared_prediction_manifest is None
            and args.preregistration is None
            and args.resume is False
            and args.retry_failures is False
            and args.trajectory_id == []
            and args.limit is None
            and (
                args.max_logical_completions is None
                or args.max_logical_completions
                == _E9_BRIDGE_LOGICAL_COMPLETIONS
            )
        ),
        "gold_free_inputs_outside_run_output": (
            not prediction_path.is_relative_to(output_root)
            and not plan_path.is_relative_to(output_root)
        ),
    }
    failed = sorted(name for name, passed in checks.items() if not passed)
    if failed:
        raise ValueError(
            "E9 bridge identity differs from the fixed smoke run: "
            + ", ".join(failed)
        )
    return {
        "prediction_manifest": prediction_path,
        "batch_plan": plan_path,
        "unscored_predictions": unscored_path,
        "predict_run": predict_run_path,
        "selected_trajectory_ids": selected_ids,
    }


def _run_e9_bridge(
    *,
    args: argparse.Namespace,
    dataset: Any,
    cohort: CohortManifest,
    selected: list[Any],
    config: BenchmarkRunConfig,
    preregistration_path: Path,
    output_root: Path,
    cache_dir: Path,
) -> int:
    document = _load_e9_bridge_preregistration(preregistration_path)
    paths = _validate_e9_bridge_identity(
        args=args,
        document=document,
        dataset=dataset,
        cohort=cohort,
        selected=selected,
        config=config,
        preregistration_path=preregistration_path,
        output_root=output_root,
        cache_dir=cache_dir,
    )
    verified = verify_batched_causal_preregistration(
        preregistration_path=preregistration_path,
        prediction_manifest_path=paths["prediction_manifest"],
        batch_plan_path=paths["batch_plan"],
        run_output_dir=output_root,
        cache_dir=cache_dir,
        unscored_output_path=paths["unscored_predictions"],
        predict_run_metadata_path=paths["predict_run"],
        config=config,
        selected_trajectory_ids=paths["selected_trajectory_ids"],
        maximum_new_logical_completions=(
            _E9_BRIDGE_LOGICAL_COMPLETIONS
        ),
    )
    if (
        verified.get("preregistration_sha256")
        != document["preregistration_sha256"]
    ):
        raise ValueError(
            "E9 bridge verification returned a different preregistration"
        )

    provider_arguments = [
        "--judge-provider",
        args.judge_provider,
        "--judge-base-url",
        args.judge_base_url,
        "--judge-api-key-env",
        args.judge_api_key_env,
        "--judge-model",
        args.judge_model,
        "--judge-temperature",
        str(args.judge_temperature),
        "--judge-timeout",
        str(args.judge_timeout),
        "--judge-max-output-tokens",
        str(args.judge_max_output_tokens),
        "--judge-max-retries",
        str(args.judge_max_retries),
        "--judge-retry-backoff",
        str(args.judge_retry_backoff),
    ]
    module = "agentdebug.benchmark.batched_causal_cli"
    subprocess.run(
        [
            sys.executable,
            "-m",
            module,
            "predict",
            "--prediction-manifest",
            str(paths["prediction_manifest"]),
            "--batch-plan",
            str(paths["batch_plan"]),
            "--cache-dir",
            str(cache_dir),
            "--output",
            str(paths["unscored_predictions"]),
            "--run-metadata",
            str(paths["predict_run"]),
            "--preregistration",
            str(preregistration_path),
            "--max-logical-completions",
            str(_E9_BRIDGE_LOGICAL_COMPLETIONS),
            *provider_arguments,
        ],
        check=True,
    )
    subprocess.run(
        [
            sys.executable,
            "-m",
            module,
            "score",
            "--dataset",
            str(Path(args.dataset).expanduser().resolve()),
            "--cohort-manifest",
            str(cohort.path),
            "--prediction-manifest",
            str(paths["prediction_manifest"]),
            "--batch-plan",
            str(paths["batch_plan"]),
            "--unscored-predictions",
            str(paths["unscored_predictions"]),
            "--predict-run",
            str(paths["predict_run"]),
            "--output-dir",
            str(output_root),
        ],
        check=True,
    )
    subprocess.run(
        [
            sys.executable,
            "-m",
            module,
            "verify-gate",
            "--preregistration",
            str(preregistration_path),
            "--predictions",
            str(output_root / "predictions.jsonl"),
            "--metrics",
            str(output_root / "metrics.json"),
            "--predict-run",
            str(paths["predict_run"]),
            "--output",
            str(output_root / "promotion.json"),
        ],
        check=True,
    )
    return 0


def _run(args: argparse.Namespace) -> int:
    started = datetime.now(timezone.utc)
    dataset = load_agent_error_bench(args.dataset)
    methods = [item.strip() for item in args.methods.split(",") if item.strip()]
    selected = list(dataset.examples)
    cohort = None
    if args.cohort_manifest:
        if args.trajectory_id or args.limit is not None:
            raise ValueError(
                "--cohort-manifest cannot be combined with --trajectory-id "
                "or --limit"
            )
        cohort = load_cohort_manifest(
            args.cohort_manifest,
            dataset=dataset,
        )
        selected = cohort.examples_from(dataset)
    if args.trajectory_id:
        wanted = set(args.trajectory_id)
        known = {example.label.trajectory_id for example in selected}
        unknown = sorted(wanted - known)
        if unknown:
            raise ValueError(
                "trajectory IDs are unavailable or unknown: " + ", ".join(unknown)
            )
        selected = [
            example
            for example in selected
            if example.label.trajectory_id in wanted
        ]
    if args.limit is not None:
        if args.limit < 1:
            raise ValueError("--limit must be positive")
        selected = selected[: args.limit]
    if args.order == "prompt-size":
        selected.sort(
            key=lambda example: len(
                direct_messages(example.trace)[1]["content"]
            )
        )

    formal_two_stage = methods == ["two_stage"]
    if args.prepared_prediction_manifest and not formal_two_stage:
        raise ValueError(
            "--prepared-prediction-manifest requires --methods two_stage"
        )
    if args.preregistration and not formal_two_stage:
        raise ValueError(
            "--preregistration requires --methods two_stage"
        )
    if args.resume and not formal_two_stage:
        raise ValueError("--resume requires --methods two_stage")
    if formal_two_stage and args.workers != 1:
        raise ValueError(
            "gold-isolated production two_stage requires --workers 1"
        )
    endpoint = resolve_judge_endpoint(
        provider=args.judge_provider,
        base_url=args.judge_base_url,
        model=args.judge_model,
    )
    judge = None
    if not formal_two_stage:
        judge_class = (
            GeminiGenerateContentJudge
            if args.judge_provider == "gemini-generate-content"
            else OpenAICompatibleJudge
        )
        judge = judge_class(
            base_url=args.judge_base_url,
            api_key_env=args.judge_api_key_env,
            model=args.judge_model,
            temperature=args.judge_temperature,
            timeout=args.judge_timeout,
            max_output_tokens=args.judge_max_output_tokens,
            max_retries=args.judge_max_retries,
            retry_backoff=args.judge_retry_backoff,
        )
        if judge.endpoint != endpoint:
            raise ValueError(
                "judge endpoint resolution differs across run phases"
            )
    if cohort is not None:
        scoring_cohort = cohort
    else:
        selection_name = (
            "complete_available_release"
            if not args.trajectory_id
            and args.limit is None
            and len(selected) == len(dataset.examples)
            else "explicit_subset"
        )
        selection_document = {
            "selection_name": selection_name,
            "dataset_manifest_sha256": dataset.dataset_sha256,
            "trajectory_ids": [
                example.mapping.trajectory_id for example in selected
            ],
        }
        selection_sha256 = stable_sha256(selection_document)
        scoring_cohort = CohortManifest(
            path=None,
            cohort_name=selection_name,
            cohort_sha256=selection_sha256,
            dataset_manifest_sha256=dataset.dataset_sha256,
            trajectory_ids=tuple(
                example.mapping.trajectory_id for example in selected
            ),
            entries=tuple(
                {
                    "trajectory_id": example.mapping.trajectory_id,
                }
                for example in selected
            ),
            document=selection_document,
        )
    config = BenchmarkRunConfig(
        model=args.judge_model,
        temperature=args.judge_temperature,
        provider=args.judge_provider,
        endpoint=endpoint,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
        cohort_sha256=scoring_cohort.cohort_sha256,
        api_key_env=args.judge_api_key_env,
    )
    output_root = Path(args.output_dir).expanduser().resolve()
    cache_dir = (
        Path(args.cache_dir).expanduser().resolve()
        if args.cache_dir
        else output_root / "cache"
    )
    e9_preregistration_path = (
        output_root / _E9_BRIDGE_PREREGISTRATION_FILENAME
    )
    if formal_two_stage and e9_preregistration_path.is_file():
        if cohort is None:
            raise ValueError(
                "E9 bridge requires a persisted cohort manifest"
            )
        return _run_e9_bridge(
            args=args,
            dataset=dataset,
            cohort=cohort,
            selected=selected,
            config=config,
            preregistration_path=e9_preregistration_path,
            output_root=output_root,
            cache_dir=cache_dir,
        )
    if formal_two_stage and args.max_logical_completions is None:
        args.max_logical_completions = 3 * len(selected)
    total = len(selected) * len(methods)
    state = {"completed": 0}
    lock = threading.Lock()

    def progress(row: dict) -> None:
        with lock:
            state["completed"] += 1
            print(
                f"[{state['completed']}/{total}] {row['trajectory_id']} "
                f"{row['method']} {row['status']}",
                flush=True,
            )

    predict_metadata = None
    preregistration = None
    prepared_manifest_path = None
    unscored_predictions_path = None
    predict_run_metadata_path = None
    if formal_two_stage:
        prepared_manifest_path = (
            Path(args.prepared_prediction_manifest).expanduser().resolve()
            if args.prepared_prediction_manifest
            else output_root / "prediction-manifest.json"
        )
        unscored_predictions_path = (
            output_root / "unscored-predictions.jsonl"
        )
        predict_run_metadata_path = output_root / "predict-run.json"
        if not args.resume:
            allowed_preexisting = {prepared_manifest_path}
            if args.preregistration:
                allowed_preexisting.add(
                    Path(args.preregistration).expanduser().resolve()
                )
            preexisting = {
                path.resolve()
                for path in output_root.rglob("*")
                if path.is_file()
            }
            unexpected = sorted(
                str(path)
                for path in preexisting - allowed_preexisting
            )
            if unexpected:
                raise ValueError(
                    "production output directory is not fresh; use "
                    "--resume only for the same interrupted run: "
                    + ", ".join(unexpected[:5])
                )
            if (
                not cache_dir.is_relative_to(output_root)
                and cache_dir.exists()
                and any(path.is_file() for path in cache_dir.rglob("*"))
            ):
                raise ValueError(
                    "production cache directory is not fresh; use "
                    "--resume only for the same interrupted run"
                )
        if args.prepared_prediction_manifest:
            prepared_document, prepared_cases = load_prediction_manifest(
                prepared_manifest_path
            )
            expected_cases = [
                build_prediction_case(example.trace, example.mapping)
                for example in selected
            ]
            if (
                prepared_document.get("dataset_manifest_sha256")
                != dataset.dataset_sha256
                or prepared_document.get("cohort_name")
                != scoring_cohort.cohort_name
                or prepared_document.get("cohort_sha256")
                != scoring_cohort.cohort_sha256
                or len(prepared_cases) != len(expected_cases)
                or [
                    case.case_input_sha256 for case in prepared_cases
                ]
                != [
                    value["case_input_sha256"]
                    for value in expected_cases
                ]
            ):
                raise ValueError(
                    "prepared prediction manifest does not match the "
                    "selected frozen cohort"
                )
        else:
            write_prediction_manifest(
                traces_and_mappings=[
                    (example.trace, example.mapping) for example in selected
                ],
                dataset_manifest_sha256=dataset.dataset_sha256,
                cohort_name=scoring_cohort.cohort_name,
                cohort_sha256=scoring_cohort.cohort_sha256,
                selection_identity={
                    "selection_name": scoring_cohort.cohort_name,
                    "cohort_sha256": scoring_cohort.cohort_sha256,
                    "trajectory_ids": list(scoring_cohort.trajectory_ids),
                    "execution_order": args.order,
                },
                output_path=prepared_manifest_path,
            )
        if args.preregistration:
            preregistration = verify_production_preregistration(
                preregistration_path=args.preregistration,
                prediction_manifest_path=prepared_manifest_path,
                run_output_dir=output_root,
                cache_dir=cache_dir,
                config=config,
                maximum_new_logical_completions=(
                    args.max_logical_completions
                ),
            )
        _run_prediction_subprocess(
            args=args,
            manifest_path=prepared_manifest_path,
            cache_dir=cache_dir,
            unscored_output_path=unscored_predictions_path,
            predict_run_metadata_path=predict_run_metadata_path,
            cohort_sha256=scoring_cohort.cohort_sha256,
        )
        predictions, predict_metadata = score_persisted_predictions(
            dataset=dataset,
            cohort=scoring_cohort,
            manifest_path=prepared_manifest_path,
            unscored_predictions_path=unscored_predictions_path,
            predict_run_metadata_path=predict_run_metadata_path,
        )
    else:
        predictions = evaluate_examples(
            selected,
            methods=methods,
            judge=judge,
            config=config,
            cache_dir=cache_dir,
            retry_failures=args.retry_failures,
            workers=args.workers,
            on_result=progress,
        )
    full_cohort = (
        cohort is None
        and not args.trajectory_id
        and args.limit is None
        and len(selected) == len(dataset.examples)
    )
    if full_cohort:
        predictions.extend(
            conversion_failure_records(
                dataset,
                methods=methods,
                config=config,
            )
        )
        predictions.sort(key=lambda row: (row["trajectory_id"], row["method"]))
    metrics = compute_metrics(
        predictions,
        phase1_gold_available=dataset.phase1_gold_available,
        phase1_gold_reason=dataset.phase1_gold_reason,
    )
    provider_telemetry = (
        predict_metadata["provider_telemetry"]
        if predict_metadata is not None
        else provider_telemetry_snapshot(judge)
    )
    if predict_metadata is not None:
        provider_capabilities = predict_metadata.get(
            "provider_capabilities"
        )
    else:
        capability_snapshotter = getattr(
            judge,
            "capability_snapshot",
            None,
        )
        provider_capabilities = (
            capability_snapshotter()
            if callable(capability_snapshotter)
            else None
        )
    finished = datetime.now(timezone.utc)
    run_metadata = {
        "started_at": started.isoformat(),
        "finished_at": finished.isoformat(),
        "duration_seconds": (finished - started).total_seconds(),
        "model": args.judge_model,
        "temperature": args.judge_temperature,
        "provider": args.judge_provider,
        "endpoint": endpoint,
        "timeout": args.judge_timeout,
        "max_output_tokens": args.judge_max_output_tokens,
        "max_retries": args.judge_max_retries,
        "retry_backoff": args.judge_retry_backoff,
        "workers": args.workers,
        "execution_order": args.order,
        "methods": methods,
        "prompt_versions": {
            "direct": DIRECT_PROMPT_VERSION,
            "two_stage": TWO_STAGE_PROMPT_VERSION,
        },
        "judge_view_version": JUDGE_VIEW_VERSION,
        "diagnostic_pipeline_version": (
            TWO_STAGE_PIPELINE_VERSION
            if methods == ["two_stage"]
            else DIAGNOSTIC_PIPELINE_VERSION
            if methods == ["direct"]
            else "mixed"
        ),
        "pipeline_versions": {
            "direct": DIAGNOSTIC_PIPELINE_VERSION,
            "two_stage": TWO_STAGE_PIPELINE_VERSION,
        },
        "production_two_stage_pipeline_version": (
            PRODUCTION_TWO_STAGE_PIPELINE_VERSION
            if formal_two_stage
            else None
        ),
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
        "provider_telemetry": provider_telemetry,
        "provider_telemetry_known_subtotal": (
            predict_metadata.get("provider_telemetry_known_subtotal")
            if predict_metadata is not None
            else provider_telemetry
        ),
        "provider_telemetry_coverage": (
            predict_metadata.get("provider_telemetry_coverage")
            if predict_metadata is not None
            else None
        ),
        "provider_capabilities": provider_capabilities,
        "repair_eligible_count": (
            predict_metadata.get("repair_eligible_count")
            if predict_metadata is not None
            else None
        ),
        "repair_attempt_count": (
            predict_metadata.get("repair_attempt_count")
            if predict_metadata is not None
            else None
        ),
        "repair_applied_count": (
            predict_metadata.get("repair_applied_count")
            if predict_metadata is not None
            else None
        ),
        "released_label_count": len(dataset.labels),
        "available_trajectory_count": len(dataset.examples),
        "judge_input_count": len(selected),
        "metric_cohort_count": (
            len(selected) + len(dataset.conversion_failures)
            if full_cohort
            else len(selected)
        ),
        "prediction_count": len(predictions),
        "selection": {
            "trajectory_ids": list(args.trajectory_id),
            "limit": args.limit,
            "cohort_manifest_path": (
                str(cohort.path) if cohort is not None else None
            ),
            "cohort_name": (
                cohort.cohort_name if cohort is not None else None
            ),
            "cohort_sha256": (
                cohort.cohort_sha256 if cohort is not None else None
            ),
            "dataset_manifest_sha256": dataset.dataset_sha256,
            "cohort": (
                cohort.cohort_name
                if cohort is not None
                else "complete_available_release"
                if full_cohort
                else "explicit_subset"
            ),
        },
        "cache_dir": str(cache_dir),
        "retry_failures": args.retry_failures,
        "resume": args.resume,
        "max_logical_completions": args.max_logical_completions,
        "logical_completion_budget_used": (
            predict_metadata.get("logical_completion_budget_used")
            if predict_metadata is not None
            else None
        ),
        "preregistration": (
            {
                "path": str(
                    Path(args.preregistration).expanduser().resolve()
                ),
                "preregistration_sha256": preregistration[
                    "preregistration_sha256"
                ],
                "code_bundle_sha256": preregistration[
                    "code_bundle_sha256"
                ],
                "hard_cumulative_stop": preregistration[
                    "logical_completion_budget"
                ]["hard_cumulative_stop"],
            }
            if preregistration is not None
            else None
        ),
        "gold_isolation": {
            "enabled": formal_two_stage,
            "prediction_input_type": (
                "hash_locked_gold_free_judge_view_manifest"
                if formal_two_stage
                else "legacy_in_process"
            ),
            "raw_first_stage_cache": formal_two_stage,
            "provider_process_isolated_from_dataset": formal_two_stage,
            "unscored_persisted_before_gold_scoring": formal_two_stage,
            "prediction_manifest_path": (
                str(prepared_manifest_path)
                if prepared_manifest_path is not None
                else None
            ),
            "prediction_manifest_sha256": (
                predict_metadata["prediction_manifest_sha256"]
                if predict_metadata is not None
                else None
            ),
            "unscored_predictions_path": (
                str(unscored_predictions_path)
                if unscored_predictions_path is not None
                else None
            ),
            "unscored_predictions_sha256": (
                predict_metadata["unscored_predictions_sha256"]
                if predict_metadata is not None
                else None
            ),
            "predict_run_metadata_path": (
                str(predict_run_metadata_path)
                if predict_run_metadata_path is not None
                else None
            ),
            "predict_run_sha256": (
                predict_metadata["predict_run_sha256"]
                if predict_metadata is not None
                else None
            ),
        },
    }
    paths = write_outputs(
        output_dir=output_root,
        dataset=dataset,
        predictions=predictions,
        metrics=metrics,
        run_metadata=run_metadata,
    )
    print(json.dumps(paths, ensure_ascii=False, indent=2))
    return 0


def archive_main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.command == "inspect":
            return _inspect(args)
        if args.command == "create-cohorts":
            return _create_cohorts(args)
        if args.command == "prepare-prediction":
            return _prepare_prediction(args)
        if args.command == "preregister-prediction":
            return _preregister_prediction(args)
        if args.command == "verify-final-smoke":
            return _verify_final_smoke(args)
        return _run(args)
    except (
        CohortManifestError,
        DatasetSchemaError,
        AcceptanceError,
        PreregistrationError,
        OSError,
        ValueError,
        TypeError,
        subprocess.CalledProcessError,
    ) as error:
        print(f"agentdebug-benchmark: {error}", file=sys.stderr)
        return 2


def main(argv: list[str] | None = None) -> int:
    """Compatibility executable: the same single method as agentdebug."""
    from agentdebug.cli import main as public_main

    return public_main(argv)


if __name__ == "__main__":
    raise SystemExit(main())

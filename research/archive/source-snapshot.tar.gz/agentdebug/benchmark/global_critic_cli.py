"""CLI for the gold-isolated E7 global causal critic experiment."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

from agentdebug.diagnostics import (
    EVIDENCE_VALIDATION_VERSION,
    GLOBAL_CRITIC_PIPELINE_VERSION,
    GLOBAL_CRITIC_PROMPT_PROTOCOL_VERSION,
    GeminiGenerateContentJudge,
    JUDGE_VIEW_VERSION,
    OpenAICompatibleJudge,
    resolve_judge_endpoint,
)

from .cohort import load_cohort_manifest
from .dataset import load_agent_error_bench
from .global_critic_workflow import (
    E7_EXPERIMENT,
    GlobalCriticWorkflowError,
    predict_global_critic_cases,
    prepare_global_critic_inputs,
    score_global_critic_predictions,
)
from .global_critic_preregistration import (
    GlobalCriticPreregistrationError,
    verify_global_critic_preregistration,
    verify_global_critic_promotion,
    write_global_critic_preregistration,
)
from .prediction_manifest import load_prediction_manifest
from .production_workflow import ProductionWorkflowError
from .reporting import write_outputs
from .runner import TRANSPORT_POLICY_VERSION, BenchmarkRunConfig
from .stage_cache import StageCacheError


E7_DRY5_IDS_MANIFEST_ORDER = (
    "Qwen3-8B_024_id_24___chat_b013_t00_e01-5b8f974f",
    "Llama3.3-70B-Turbo_015_memory_b001_t00_e06-71f77595",
    "GPT-4o_011_memory_b001_t00_e03-21a3a421",
    "GPT-4o_008_chat_b000_t00_e07-d50ae81f",
    "GPT-4o_004_chat_b000_t00_e03-21a3a421",
)


def _provider_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--judge-provider",
        choices=("openai-compatible", "gemini-generate-content"),
        required=True,
    )
    parser.add_argument("--judge-base-url", required=True)
    parser.add_argument("--judge-api-key-env", required=True)
    parser.add_argument("--judge-model", required=True)
    parser.add_argument("--judge-temperature", type=float, required=True)
    parser.add_argument("--judge-timeout", type=float, required=True)
    parser.add_argument("--judge-max-output-tokens", type=int, required=True)
    parser.add_argument("--judge-max-retries", type=int, required=True)
    parser.add_argument("--judge-retry-backoff", type=float, required=True)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m agentdebug.benchmark.global_critic_cli",
        description="Prepare, predict, and independently score E7.",
    )
    commands = parser.add_subparsers(dest="command", required=True)

    prepare = commands.add_parser(
        "prepare",
        help="Sanitize a frozen production selector into gold-free E7 inputs.",
    )
    prepare.add_argument("--prediction-manifest", required=True)
    prepare.add_argument("--source-unscored", required=True)
    prepare.add_argument("--source-predict-run", required=True)
    prepare.add_argument(
        "--expected-prediction-manifest-file-sha256",
        required=True,
    )
    prepare.add_argument(
        "--expected-source-unscored-sha256",
        required=True,
    )
    prepare.add_argument(
        "--expected-source-predict-run-sha256",
        required=True,
    )
    prepare.add_argument("--output", required=True)

    preregister = commands.add_parser(
        "preregister",
        help="Freeze E7 code, prompts, inputs, gate, paths, and call budget.",
    )
    preregister.add_argument("--experiment-name", required=True)
    preregister.add_argument("--prediction-manifest", required=True)
    preregister.add_argument("--critic-input-manifest", required=True)
    preregister.add_argument("--run-output-dir", required=True)
    preregister.add_argument("--cache-dir", required=True)
    preregister.add_argument("--output", required=True)
    preregister.add_argument(
        "--trajectory-id",
        action="append",
        required=True,
    )
    preregister.add_argument("--selection-rule", required=True)
    preregister.add_argument("--hypothesis", required=True)
    preregister.add_argument(
        "--gate-profile",
        choices=("dry5", "full30"),
        required=True,
    )
    preregister.add_argument(
        "--cumulative-logical-completions-before",
        type=int,
        required=True,
    )
    preregister.add_argument(
        "--maximum-new-logical-completions",
        type=int,
        required=True,
    )
    _provider_arguments(preregister)

    predict = commands.add_parser(
        "predict",
        help=(
            "Call E7 using only gold-free manifests; this command accepts no "
            "dataset or label path."
        ),
    )
    predict.add_argument("--prediction-manifest", required=True)
    predict.add_argument("--critic-input-manifest", required=True)
    predict.add_argument("--cache-dir", required=True)
    predict.add_argument("--output", required=True)
    predict.add_argument("--run-metadata", required=True)
    predict.add_argument("--preregistration", required=True)
    predict.add_argument(
        "--trajectory-id",
        action="append",
        default=[],
    )
    predict.add_argument("--max-logical-completions", type=int, required=True)
    _provider_arguments(predict)

    score = commands.add_parser(
        "score",
        help="Validate all raw E7 artifacts, then load gold and score.",
    )
    score.add_argument("--dataset", required=True)
    score.add_argument("--cohort-manifest", required=True)
    score.add_argument("--prediction-manifest", required=True)
    score.add_argument("--critic-input-manifest", required=True)
    score.add_argument("--unscored-predictions", required=True)
    score.add_argument("--predict-run", required=True)
    score.add_argument("--output-dir", required=True)

    gate = commands.add_parser(
        "verify-gate",
        help="Apply the write-once E7 promotion gate to scored artifacts.",
    )
    gate.add_argument("--preregistration", required=True)
    gate.add_argument("--predictions", required=True)
    gate.add_argument("--metrics", required=True)
    gate.add_argument("--predict-run", required=True)
    gate.add_argument("--output", required=True)
    return parser


def _prepare(args: argparse.Namespace) -> int:
    document = prepare_global_critic_inputs(
        prediction_manifest_path=args.prediction_manifest,
        source_unscored_path=args.source_unscored,
        source_predict_run_path=args.source_predict_run,
        output_path=args.output,
        expected_prediction_manifest_file_sha256=(
            args.expected_prediction_manifest_file_sha256
        ),
        expected_source_unscored_sha256=(
            args.expected_source_unscored_sha256
        ),
        expected_source_predict_run_sha256=(
            args.expected_source_predict_run_sha256
        ),
    )
    print(
        json.dumps(
            {
                "output": str(Path(args.output).expanduser().resolve()),
                "entry_count": document["entry_count"],
                "critic_input_manifest_sha256": document[
                    "critic_input_manifest_sha256"
                ],
                "prior_root_count": sum(
                    entry["initial_root"] is not None
                    for entry in document["entries"]
                ),
                "external_calls": 0,
                "gold_free": True,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _predict(args: argparse.Namespace) -> int:
    manifest, _ = load_prediction_manifest(args.prediction_manifest)
    judge_class = (
        GeminiGenerateContentJudge
        if args.judge_provider == "gemini-generate-content"
        else OpenAICompatibleJudge
    )
    judge = judge_class(
        base_url=args.judge_base_url,
        api_key_env=args.judge_api_key_env,
        model=args.judge_model,
        temperature=args.judge_temperature,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
    )
    config = BenchmarkRunConfig(
        model=args.judge_model,
        temperature=args.judge_temperature,
        provider=args.judge_provider,
        endpoint=judge.endpoint,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
        cohort_sha256=manifest["cohort_sha256"],
        api_key_env=args.judge_api_key_env,
    )
    selected = (
        args.trajectory_id
        if args.trajectory_id
        else [
            case.trajectory_id
            for case in load_prediction_manifest(
                args.prediction_manifest
            )[1]
        ]
    )
    preregistration = verify_global_critic_preregistration(
        preregistration_path=args.preregistration,
        prediction_manifest_path=args.prediction_manifest,
        critic_input_manifest_path=args.critic_input_manifest,
        run_output_dir=Path(args.output).expanduser().resolve().parent,
        cache_dir=args.cache_dir,
        config=config,
        selected_trajectory_ids=selected,
        maximum_new_logical_completions=args.max_logical_completions,
    )
    state = {"completed": 0}

    def progress(row):
        state["completed"] += 1
        print(
            f"[E7 {state['completed']}] {row['trajectory_id']} "
            f"{row['status']}",
            flush=True,
        )

    rows, metadata = predict_global_critic_cases(
        prediction_manifest_path=args.prediction_manifest,
        critic_input_manifest_path=args.critic_input_manifest,
        judge=judge,
        config=config,
        cache_dir=args.cache_dir,
        unscored_output_path=args.output,
        predict_run_metadata_path=args.run_metadata,
        selected_trajectory_ids=(
            selected
        ),
        max_logical_completions=args.max_logical_completions,
        on_result=progress,
    )
    print(
        json.dumps(
            {
                "prediction_count": len(rows),
                "unscored_predictions_sha256": metadata[
                    "unscored_predictions_sha256"
                ],
                "predict_run_sha256": metadata["predict_run_sha256"],
                "logical_completion_budget_used": metadata[
                    "logical_completion_budget_used"
                ],
                "provider_telemetry": metadata["provider_telemetry"],
                "preregistration_sha256": preregistration[
                    "preregistration_sha256"
                ],
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _preregister(args: argparse.Namespace) -> int:
    manifest, cases = load_prediction_manifest(args.prediction_manifest)
    endpoint = resolve_judge_endpoint(
        provider=args.judge_provider,
        base_url=args.judge_base_url,
        model=args.judge_model,
    )
    config = BenchmarkRunConfig(
        model=args.judge_model,
        temperature=args.judge_temperature,
        provider=args.judge_provider,
        endpoint=endpoint,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
        cohort_sha256=manifest["cohort_sha256"],
        api_key_env=args.judge_api_key_env,
    )
    selected_set = set(args.trajectory_id)
    selected = [
        case.trajectory_id
        for case in cases
        if case.trajectory_id in selected_set
    ]
    if len(selected) != len(args.trajectory_id):
        raise ValueError(
            "preregistered trajectory IDs are duplicated or unknown"
        )
    if args.gate_profile == "dry5":
        if tuple(selected) != E7_DRY5_IDS_MANIFEST_ORDER:
            raise ValueError(
                "dry5 gate requires the frozen five trajectory IDs in "
                "prediction-manifest order"
            )
        promotion_gate = {
            "trajectory_denominator": 5,
            "successful_prediction_minimum": 5,
            "step_exact_minimum_correct": 3,
            "step_module_exact_minimum_correct": 3,
            "all_correct_minimum": 2,
            "hard_failure_maximum": 0,
            "evidence_valid_minimum": 5,
            "semantic_mutation_maximum": 0,
            "raw_chain_reconstruction_required": True,
            "gold_isolation_required": True,
            "telemetry_logical_equals_critic_plus_repair": True,
            "required_step_module_exact_trajectory_ids": [
                "Llama3.3-70B-Turbo_015_memory_b001_t00_e06-71f77595"
            ],
            "minimum_step_exact_by_groups": [
                {
                    "minimum": 1,
                    "trajectory_ids": [
                        "GPT-4o_004_chat_b000_t00_e03-21a3a421",
                        (
                            "Qwen3-8B_024_id_24___chat_b013_t00_e01-"
                            "5b8f974f"
                        ),
                    ],
                },
                {
                    "minimum": 1,
                    "trajectory_ids": [
                        "GPT-4o_008_chat_b000_t00_e07-d50ae81f",
                        "GPT-4o_011_memory_b001_t00_e03-21a3a421",
                    ],
                },
            ],
        }
    else:
        if len(selected) != 30:
            raise ValueError("full30 gate requires all 30 manifest cases")
        promotion_gate = {
            "trajectory_denominator": 30,
            "step_exact_minimum_correct": 12,
            "step_module_exact_minimum_correct": 2,
            "failed_prediction_maximum": 1,
            "semantic_mutation_maximum": 0,
            "raw_chain_reconstruction_required": True,
            "gold_isolation_required": True,
            "telemetry_logical_equals_critic_plus_repair": True,
        }
    document = write_global_critic_preregistration(
        experiment_name=args.experiment_name,
        prediction_manifest_path=args.prediction_manifest,
        critic_input_manifest_path=args.critic_input_manifest,
        output_path=args.output,
        run_output_dir=args.run_output_dir,
        cache_dir=args.cache_dir,
        config=config,
        selected_trajectory_ids=selected,
        selection_rule=args.selection_rule,
        hypothesis=args.hypothesis,
        promotion_gate=promotion_gate,
        cumulative_logical_completions_before=(
            args.cumulative_logical_completions_before
        ),
        maximum_new_logical_completions=(
            args.maximum_new_logical_completions
        ),
    )
    print(
        json.dumps(
            {
                "output": str(Path(args.output).expanduser().resolve()),
                "preregistration_sha256": document[
                    "preregistration_sha256"
                ],
                "code_bundle_sha256": document["code_bundle_sha256"],
                "selected_count": document["selection"]["count"],
                "hard_cumulative_stop": document[
                    "logical_completion_budget"
                ]["hard_cumulative_stop"],
                "external_calls": 0,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _score(args: argparse.Namespace) -> int:
    started = datetime.now(timezone.utc)
    dataset = load_agent_error_bench(args.dataset)
    cohort = load_cohort_manifest(
        args.cohort_manifest,
        dataset=dataset,
    )
    predictions, metrics, predict_run = score_global_critic_predictions(
        dataset=dataset,
        cohort=cohort,
        prediction_manifest_path=args.prediction_manifest,
        critic_input_manifest_path=args.critic_input_manifest,
        unscored_predictions_path=args.unscored_predictions,
        predict_run_metadata_path=args.predict_run,
    )
    finished = datetime.now(timezone.utc)
    config = predict_run["provider_config"]
    run_metadata = {
        "started_at": started.isoformat(),
        "finished_at": finished.isoformat(),
        "duration_seconds": (finished - started).total_seconds(),
        "experiment": E7_EXPERIMENT,
        "model": config["model"],
        "temperature": config["temperature"],
        "provider": config["provider"],
        "endpoint": config["endpoint"],
        "timeout": config["timeout"],
        "max_output_tokens": config["max_output_tokens"],
        "max_retries": config["max_retries"],
        "retry_backoff": config["retry_backoff"],
        "workers": 1,
        "execution_order": "prediction-manifest",
        "methods": ["two_stage"],
        "prompt_versions": {
            "two_stage": GLOBAL_CRITIC_PROMPT_PROTOCOL_VERSION,
        },
        "judge_view_version": JUDGE_VIEW_VERSION,
        "diagnostic_pipeline_version": GLOBAL_CRITIC_PIPELINE_VERSION,
        "pipeline_versions": {
            "two_stage": GLOBAL_CRITIC_PIPELINE_VERSION,
        },
        "production_two_stage_pipeline_version": (
            GLOBAL_CRITIC_PIPELINE_VERSION
        ),
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
        "provider_telemetry": predict_run["provider_telemetry"],
        "provider_telemetry_coverage": predict_run[
            "provider_telemetry_coverage"
        ],
        "provider_capabilities": predict_run["provider_capabilities"],
        "repair_eligible_count": predict_run["repair_eligible_count"],
        "repair_attempt_count": predict_run["repair_attempt_count"],
        "repair_applied_count": predict_run["repair_applied_count"],
        "semantic_mutation_count": predict_run[
            "semantic_mutation_count"
        ],
        "released_label_count": len(dataset.labels),
        "available_trajectory_count": len(dataset.examples),
        "judge_input_count": len(predictions),
        "metric_cohort_count": len(predictions),
        "prediction_count": len(predictions),
        "selection": {
            "trajectory_ids": predict_run["selected_trajectory_ids"],
            "cohort_manifest_path": str(cohort.path),
            "cohort_name": cohort.cohort_name,
            "cohort_sha256": cohort.cohort_sha256,
            "dataset_manifest_sha256": dataset.dataset_sha256,
            "cohort": cohort.cohort_name,
        },
        "cache_dir": None,
        "retry_failures": False,
        "resume": False,
        "max_logical_completions": predict_run[
            "max_logical_completions"
        ],
        "logical_completion_budget_used": predict_run[
            "logical_completion_budget_used"
        ],
        "gold_isolation": {
            "enabled": True,
            "prediction_input_type": (
                "hash_locked_gold_free_judge_view_plus_fallible_prior"
            ),
            "raw_first_stage_cache": True,
            "provider_process_isolated_from_dataset": True,
            "unscored_persisted_before_gold_scoring": True,
            "prediction_manifest_path": str(
                Path(args.prediction_manifest).expanduser().resolve()
            ),
            "prediction_manifest_sha256": predict_run[
                "prediction_manifest_sha256"
            ],
            "critic_input_manifest_path": str(
                Path(args.critic_input_manifest).expanduser().resolve()
            ),
            "critic_input_manifest_sha256": predict_run[
                "critic_input_manifest_sha256"
            ],
            "unscored_predictions_path": str(
                Path(args.unscored_predictions).expanduser().resolve()
            ),
            "unscored_predictions_sha256": predict_run[
                "unscored_predictions_sha256"
            ],
            "predict_run_metadata_path": str(
                Path(args.predict_run).expanduser().resolve()
            ),
            "predict_run_sha256": predict_run["predict_run_sha256"],
        },
    }
    paths = write_outputs(
        output_dir=args.output_dir,
        dataset=dataset,
        predictions=predictions,
        metrics=metrics,
        run_metadata=run_metadata,
    )
    print(json.dumps(paths, ensure_ascii=False, indent=2))
    return 0


def _verify_gate(args: argparse.Namespace) -> int:
    document = verify_global_critic_promotion(
        preregistration_path=args.preregistration,
        predictions_path=args.predictions,
        metrics_path=args.metrics,
        predict_run_path=args.predict_run,
        output_path=args.output,
    )
    print(
        json.dumps(
            {
                "accepted": document["accepted"],
                "output": str(Path(args.output).expanduser().resolve()),
                "promotion_sha256": document["promotion_sha256"],
                "summary": document["summary"],
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.command == "prepare":
            return _prepare(args)
        if args.command == "preregister":
            return _preregister(args)
        if args.command == "predict":
            return _predict(args)
        if args.command == "score":
            return _score(args)
        return _verify_gate(args)
    except (
        GlobalCriticWorkflowError,
        GlobalCriticPreregistrationError,
        ProductionWorkflowError,
        StageCacheError,
        OSError,
        TypeError,
        ValueError,
    ) as error:
        print(f"agentdebug-e7: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

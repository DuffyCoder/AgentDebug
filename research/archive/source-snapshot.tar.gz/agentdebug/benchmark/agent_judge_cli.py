"""CLI for preparing, validating, and scoring persisted Agent Judge runs.

The CLI never spawns Codex itself.  ``prepare`` writes ``agent-task.md``;
an orchestrator must give that task to one fresh subagent using the frozen
model and reasoning effort before ``validate`` or ``score`` is run.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from agentdebug.diagnostics.agent_judge import AgentJudgeValidationError

from .agent_judge_workflow import (
    AGENT_JUDGE_METHOD,
    AGENT_JUDGE_PROTOCOL_NAMES,
    DEFAULT_AGENT_JUDGE_PROTOCOL,
    AgentJudgeWorkflowError,
    prepare_agent_judge_run,
    resolve_agent_judge_protocol,
    score_agent_judge_predictions,
    validate_agent_judge_run,
)
from .cohort import CohortManifestError, load_cohort_manifest
from .dataset import DatasetSchemaError, load_agent_error_bench
from .reporting import write_outputs


class AgentJudgeCLIError(ValueError):
    """One safe command-line failure."""


class _Parser(argparse.ArgumentParser):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        kwargs.setdefault("allow_abbrev", False)
        super().__init__(*args, **kwargs)

    def error(self, message: str) -> None:  # noqa: ARG002
        raise AgentJudgeCLIError("invalid command arguments")


def _parser() -> argparse.ArgumentParser:
    active = resolve_agent_judge_protocol(DEFAULT_AGENT_JUDGE_PROTOCOL)
    parser = _Parser(
        prog="python -m agentdebug.benchmark.agent_judge_cli",
        description=(
            "Persist the Codex Agent Judge workflow. This CLI does not spawn "
            "Codex: an orchestrator must create one fresh subagent with "
            f"model={active.model} and "
            f"reasoning_effort={active.reasoning_effort}, then give it "
            "the generated agent-task.md."
        ),
    )
    commands = parser.add_subparsers(dest="command", required=True)

    prepare = commands.add_parser(
        "prepare",
        help=(
            "Freeze preregistration.json and agent-task.md for a fresh "
            "orchestrator-created subagent."
        ),
    )
    prepare.add_argument("--prediction-manifest", required=True)
    prepare.add_argument("--cohort-manifest", required=True)
    prepare.add_argument("--run-dir", required=True)
    prepare.add_argument(
        "--protocol",
        choices=AGENT_JUDGE_PROTOCOL_NAMES,
        default=DEFAULT_AGENT_JUDGE_PROTOCOL,
    )

    validate = commands.add_parser(
        "validate",
        help="Gold-free validation of the subagent's predictions.json.",
    )
    validate.add_argument("--prediction-manifest", required=True)
    validate.add_argument("--cohort-manifest", required=True)
    validate.add_argument("--predictions", required=True)
    validate.add_argument("--audit-output")
    validate.add_argument(
        "--protocol",
        choices=AGENT_JUDGE_PROTOCOL_NAMES,
        default=DEFAULT_AGENT_JUDGE_PROTOCOL,
    )

    score = commands.add_parser(
        "score",
        help="Gold-free validate first, then load AgentErrorBench gold and score.",
    )
    score.add_argument("--dataset", required=True)
    score.add_argument("--cohort-manifest", required=True)
    score.add_argument("--prediction-manifest", required=True)
    score.add_argument("--predictions", required=True)
    score.add_argument("--output-dir", required=True)
    score.add_argument("--audit-output")
    score.add_argument(
        "--protocol",
        choices=AGENT_JUDGE_PROTOCOL_NAMES,
        default=DEFAULT_AGENT_JUDGE_PROTOCOL,
    )
    return parser


def _protocol_name(args: argparse.Namespace) -> str:
    # Namespace construction in API callers predates the CLI protocol option.
    return str(getattr(args, "protocol", DEFAULT_AGENT_JUDGE_PROTOCOL))


def _prepare(args: argparse.Namespace) -> dict[str, Any]:
    return prepare_agent_judge_run(
        prediction_manifest_path=args.prediction_manifest,
        cohort_manifest_path=args.cohort_manifest,
        run_dir=args.run_dir,
        protocol=_protocol_name(args),
    )


def _validate(args: argparse.Namespace) -> dict[str, Any]:
    return validate_agent_judge_run(
        prediction_manifest_path=args.prediction_manifest,
        cohort_manifest_path=args.cohort_manifest,
        predictions_path=args.predictions,
        audit_path=args.audit_output,
        protocol=_protocol_name(args),
    )


def _score(args: argparse.Namespace) -> dict[str, Any]:
    selected = resolve_agent_judge_protocol(_protocol_name(args))
    # This explicit call is intentionally before either gold-bearing loader.
    # score_agent_judge_predictions validates again at its own public boundary.
    pre_gold_audit = validate_agent_judge_run(
        prediction_manifest_path=args.prediction_manifest,
        cohort_manifest_path=args.cohort_manifest,
        predictions_path=args.predictions,
        audit_path=args.audit_output,
        protocol=selected.name,
    )
    started = datetime.now(timezone.utc)
    dataset = load_agent_error_bench(args.dataset)
    cohort = load_cohort_manifest(args.cohort_manifest, dataset=dataset)
    predictions, metrics, scoring_audit = score_agent_judge_predictions(
        dataset=dataset,
        cohort=cohort,
        prediction_manifest_path=args.prediction_manifest,
        cohort_manifest_path=args.cohort_manifest,
        predictions_path=args.predictions,
        protocol=selected.name,
    )
    if pre_gold_audit != scoring_audit:
        raise AgentJudgeWorkflowError(
            "Agent Judge validation identity changed during scoring"
        )
    finished = datetime.now(timezone.utc)
    prediction_path = Path(args.predictions).expanduser().resolve()
    manifest_path = Path(args.prediction_manifest).expanduser().resolve()
    run_metadata = {
        "started_at": started.isoformat(),
        "finished_at": finished.isoformat(),
        "duration_seconds": (finished - started).total_seconds(),
        "experiment": selected.version,
        "method": AGENT_JUDGE_METHOD,
        "semantic_topology": selected.semantic_topology,
        "provider": "codex-subagent",
        "endpoint": "orchestrator",
        "model": selected.model,
        "reasoning_effort": selected.reasoning_effort,
        "temperature": None,
        "max_output_tokens": None,
        "timeout": None,
        "max_retries": None,
        "workers": 1,
        "execution_order": "cohort",
        "prompt_versions": {"agent_judge": selected.version},
        "production_two_stage_pipeline_version": selected.version,
        "evidence_validation_version": selected.version,
        "transport_policy_version": "codex-orchestrator-subagent",
        "judge_input_count": len(predictions),
        "metric_cohort_count": len(cohort.trajectory_ids),
        "selected_trajectory_ids": list(cohort.trajectory_ids),
        "selection": {
            "cohort": cohort.cohort_name,
            "cohort_manifest_path": str(
                Path(args.cohort_manifest).expanduser().resolve()
            ),
            "cohort_sha256": cohort.cohort_sha256,
        },
        "gold_isolation": {
            "raw_artifacts_validated_before_dataset_load": True,
            "prediction_process_received_gold": False,
            "prediction_manifest_path": str(manifest_path),
            "unscored_predictions_path": str(prediction_path),
            "prediction_audit": pre_gold_audit,
        },
    }
    return write_outputs(
        output_dir=args.output_dir,
        dataset=dataset,
        predictions=predictions,
        metrics=metrics,
        run_metadata=run_metadata,
    )


def archive_main(argv: list[str] | None = None) -> int:
    command: str | None = None
    try:
        args = _parser().parse_args(argv)
        command = args.command
        result = {
            "prepare": _prepare,
            "validate": _validate,
            "score": _score,
        }[command](args)
        print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
        return 0
    except (
        AgentJudgeCLIError,
        AgentJudgeValidationError,
        AgentJudgeWorkflowError,
        CohortManifestError,
        DatasetSchemaError,
        KeyError,
        OSError,
        TypeError,
        ValueError,
    ):
        print(
            json.dumps(
                {
                    "command": command,
                    "status": "failed",
                    "message": (
                        "Agent Judge command failed closed; inspect local "
                        "gold-free artifacts."
                    ),
                },
                ensure_ascii=False,
            ),
            file=sys.stderr,
        )
        return 2


def main(argv: list[str] | None = None) -> int:
    """Compatibility executable: no historical default protocol selection."""
    from agentdebug.cli import main as public_main

    return public_main(argv)


if __name__ == "__main__":
    raise SystemExit(main())

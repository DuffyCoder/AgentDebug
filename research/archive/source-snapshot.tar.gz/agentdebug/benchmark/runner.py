"""Fair Direct-vs-two-stage AgentErrorBench execution with caching."""

from __future__ import annotations

import hashlib
import json
import os
import re
import time
from collections.abc import Mapping
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Iterable

from agentdebug.diagnostics import (
    DIAGNOSTIC_PIPELINE_VERSION,
    EVIDENCE_VALIDATION_VERSION,
    JUDGE_VIEW_VERSION,
    JudgeView,
    JudgeOutputError,
    JudgeTransportError,
    handoff_ledger_messages,
    handoff_selector_messages,
    parse_handoff_ledger,
    parse_handoff_selector,
)
from agentdebug.diagnostics.parsing import parse_root
from agentdebug.diagnostics.validator import validate_evidence
from agentdebug.trace import IntegrityStatus, validate_trace

from .adapter import ADAPTER_VERSION
from .models import BenchmarkDataset, BenchmarkExample
from .prompts import (
    DIRECT_PROMPT_VERSION,
    TWO_STAGE_PIPELINE_VERSION,
    TWO_STAGE_PROMPT_VERSION,
    direct_messages,
)
from .prediction_manifest import (
    PredictionCase,
    build_prediction_case,
)
from .stage_cache import (
    build_stage_request,
    run_cached_stage,
    stable_sha256,
    sum_stage_telemetry,
)

TRANSPORT_POLICY_VERSION = (
    "judge-http-json-object-v5-nonjson-probe-fallback-telemetry"
)


def provider_telemetry_snapshot(judge: Any) -> dict[str, Any] | None:
    """Return a reporting-safe copy of optional provider telemetry.

    Only documented aggregate counters are admitted. This prevents a custom
    judge from accidentally placing credentials or request/response bodies in
    benchmark artifacts.
    """

    snapshotter = getattr(judge, "telemetry_snapshot", None)
    if not callable(snapshotter):
        return None
    raw = snapshotter()
    if not isinstance(raw, Mapping):
        return None

    def counter(name: str) -> int:
        value = raw.get(name)
        return (
            value
            if isinstance(value, int)
            and not isinstance(value, bool)
            and value >= 0
            else 0
        )

    def mapping_counter(values: Mapping[Any, Any], name: str) -> int:
        value = values.get(name)
        return (
            value
            if isinstance(value, int)
            and not isinstance(value, bool)
            and value >= 0
            else 0
        )

    raw_tokens = raw.get("provider_usage_token_totals")
    tokens = raw_tokens if isinstance(raw_tokens, Mapping) else {}
    raw_finish_reasons = raw.get("finish_reason_counts")
    finish_reasons = (
        raw_finish_reasons
        if isinstance(raw_finish_reasons, Mapping)
        else {}
    )
    return {
        "logical_completion_count": counter("logical_completion_count"),
        "http_attempt_count": counter("http_attempt_count"),
        "retry_count": counter("retry_count"),
        "request_input_chars": counter("request_input_chars"),
        "provider_usage_response_count": counter(
            "provider_usage_response_count"
        ),
        "provider_usage_token_totals": {
            name: mapping_counter(tokens, name)
            for name in ("input_tokens", "output_tokens", "total_tokens")
        },
        "finish_reason_counts": {
            str(reason): count
            for reason, count in sorted(
                finish_reasons.items(),
                key=lambda item: str(item[0]),
            )
            if isinstance(count, int)
            and not isinstance(count, bool)
            and count >= 0
        },
    }


@dataclass(frozen=True)
class BenchmarkRunConfig:
    model: str
    temperature: float
    provider: str
    endpoint: str
    timeout: float
    max_output_tokens: int = 8192
    max_retries: int = 0
    retry_backoff: float = 2.0
    cohort_sha256: str | None = None
    api_key_env: str | None = None
    thinking_mode: str | None = None
    request_body_mode: str | None = None

    def __post_init__(self) -> None:
        if self.api_key_env is not None and re.fullmatch(
            r"[A-Za-z_][A-Za-z0-9_]*",
            self.api_key_env,
        ) is None:
            raise ValueError(
                "api_key_env must be an environment-variable name, never a "
                "credential value"
            )
        if self.thinking_mode not in {None, "enabled", "disabled"}:
            raise ValueError(
                "thinking_mode must be 'enabled', 'disabled', or None"
            )
        if self.request_body_mode not in {None, "default"}:
            raise ValueError(
                "request_body_mode must be 'default' or None"
            )

    def public_dict(self) -> dict[str, Any]:
        value = asdict(self)
        if self.api_key_env is None:
            value.pop("api_key_env")
        if self.thinking_mode is None:
            value.pop("thinking_mode")
        if self.request_body_mode is None:
            value.pop("request_body_mode")
        return value


def _cache_key(
    example: BenchmarkExample,
    *,
    method: str,
    config: BenchmarkRunConfig,
) -> str:
    value = {
        "trajectory_id": example.label.trajectory_id,
        "trajectory_sha256": example.mapping.trajectory_sha256,
        "adapter_version": ADAPTER_VERSION,
        "judge_view_version": JUDGE_VIEW_VERSION,
        "diagnostic_pipeline_version": (
            DIAGNOSTIC_PIPELINE_VERSION
            if method == "direct"
            else TWO_STAGE_PIPELINE_VERSION
        ),
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
        "method": method,
        "prompt_version": (
            DIRECT_PROMPT_VERSION
            if method == "direct"
            else TWO_STAGE_PROMPT_VERSION
        ),
        "config": config.public_dict(),
    }
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _two_stage_identity(
    case: PredictionCase,
    *,
    config: BenchmarkRunConfig,
) -> dict[str, Any]:
    """Return the complete gold-free identity shared by semantic stages."""

    return {
        "method": "two_stage",
        "trace_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "judge_view_sha256": stable_sha256(case.judge_view.to_dict()),
        "case_input_sha256": case.case_input_sha256,
        "cohort_sha256": config.cohort_sha256,
        "adapter_version": ADAPTER_VERSION,
        "judge_view_version": JUDGE_VIEW_VERSION,
        "prompt_protocol_version": TWO_STAGE_PROMPT_VERSION,
        "pipeline_version": TWO_STAGE_PIPELINE_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
        "model": config.model,
        "temperature": config.temperature,
        "provider_config": config.public_dict(),
    }


def _prediction_case(example: BenchmarkExample) -> PredictionCase:
    """Cross the label-free prediction boundary before provider execution."""

    value = build_prediction_case(example.trace, example.mapping)
    return PredictionCase(
        trajectory_id=str(value["trajectory_id"]),
        trajectory_sha256=str(value["trajectory_sha256"]),
        judge_view=JudgeView.from_dict(value["judge_view"]),
        step_event_mapping=tuple(
            (int(item["step"]), str(item["assistant_event_id"]))
            for item in value["step_event_mapping"]
        ),
        case_input_sha256=str(value["case_input_sha256"]),
    )


def _validate_prediction_case(case: PredictionCase) -> None:
    expected_mapping = tuple(
        (step.step, step.assistant_event_id)
        for step in case.judge_view.steps
    )
    if (
        case.trajectory_id != case.judge_view.trace_id
        or case.step_event_mapping != expected_mapping
    ):
        raise ValueError(
            "PredictionCase identity or public step mapping is invalid"
        )
    case_body = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "adapter_version": ADAPTER_VERSION,
        "judge_view_version": JUDGE_VIEW_VERSION,
        "judge_view": case.judge_view.to_dict(),
        "step_event_mapping": [
            {
                "step": step,
                "assistant_event_id": event_id,
            }
            for step, event_id in case.step_event_mapping
        ],
    }
    if case.case_input_sha256 != stable_sha256(case_body):
        raise ValueError("PredictionCase content hash is invalid")


def _base_record(
    example: BenchmarkExample,
    *,
    method: str,
    config: BenchmarkRunConfig,
) -> dict[str, Any]:
    label = example.label
    return {
        "trajectory_id": label.trajectory_id,
        "environment": label.environment,
        "source_llm": label.source_llm,
        "method": method,
        "status": None,
        "failure_stage": None,
        "failure_code": None,
        "failure_message": None,
        "gold_step": label.original_step,
        "gold_event_id": example.mapping.event_for_step(label.original_step),
        "gold_raw_module": label.raw_module,
        "gold_module": label.module,
        "gold_raw_error_type": label.raw_error_type,
        "gold_error_type": label.error_type,
        "gold_normalization_notes": list(label.normalization_notes),
        "predicted_step": None,
        "judge_reported_step": None,
        "predicted_event_id": None,
        "predicted_module": None,
        "predicted_error_type": None,
        "root_cause": None,
        "step_exact": False,
        "step_module_exact": False,
        "all_correct": None if label.error_type is None else False,
        "specialist_finding_count": None,
        "specialist_counts_by_module": None,
        "evidence_validation_issues": [],
        "raw_judge_outputs": {},
        "latency_seconds": None,
        "cache_hit": False,
        "trajectory_sha256": example.mapping.trajectory_sha256,
        "prompt_version": (
            DIRECT_PROMPT_VERSION
            if method == "direct"
            else TWO_STAGE_PROMPT_VERSION
        ),
        "adapter_version": ADAPTER_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "model": config.model,
        "temperature": config.temperature,
        "provider": config.provider,
        "endpoint": config.endpoint,
    }


def _apply_root(
    record: dict[str, Any],
    *,
    example: BenchmarkExample,
    root: Any,
) -> None:
    mapped_step = example.mapping.step_for_event(root.critical_event_id)
    record.update(
        {
            "judge_reported_step": root.critical_step,
            "predicted_step": mapped_step,
            "predicted_event_id": root.critical_event_id,
            "predicted_module": root.module.value,
            "predicted_error_type": root.error_type.value,
            "root_cause": root.root_cause,
            "judge_step_matches_event_mapping": (
                mapped_step is not None and root.critical_step == mapped_step
            ),
        }
    )
    if mapped_step is None:
        record.update(
            {
                "status": "evidence_invalid",
                "failure_stage": "mapping",
                "failure_code": "critical_event_not_a_decision_step",
                "failure_message": (
                    "critical_event_id exists but is not the assistant event for "
                    "one uniquely mapped benchmark decision step."
                ),
            }
        )
        return
    if record.get("status") not in {"success", "success_needs_review"}:
        # Preserve the parsed prediction for audit, but an invalid evidence
        # package is never credited as a correct benchmark answer.
        return
    record["step_exact"] = mapped_step == record["gold_step"]
    record["step_module_exact"] = (
        record["step_exact"]
        and record["predicted_module"] == record["gold_module"]
    )
    if record["gold_error_type"] is not None:
        record["all_correct"] = (
            record["step_module_exact"]
            and record["predicted_error_type"] == record["gold_error_type"]
        )


def _direct(
    example: BenchmarkExample,
    *,
    complete: Callable[[list[dict[str, str]]], Any],
    config: BenchmarkRunConfig,
) -> dict[str, Any]:
    record = _base_record(example, method="direct", config=config)
    integrity = validate_trace(example.trace, strict=False)
    if integrity.status == IntegrityStatus.FAIL:
        record.update(
            {
                "status": "blocked_by_integrity",
                "failure_stage": "integrity",
                "failure_code": "canonical_integrity_failure",
            }
        )
        return record
    raw: Any = None
    try:
        raw = complete(direct_messages(example.trace))
        record["raw_judge_outputs"] = {"direct": raw}
        root = parse_root(raw, trace=example.trace, stage="direct")
    except JudgeOutputError as error:
        record.update(
            {
                "status": (
                    "invalid_taxonomy"
                    if error.code
                    in {"invalid_taxonomy", "invalid_taxonomy_pair"}
                    else "invalid_json"
                    if error.code
                    in {
                        "malformed_json",
                        "empty_response",
                        "invalid_top_level",
                    }
                    else "invalid_output"
                ),
                "failure_stage": "direct",
                "failure_code": error.code,
                "failure_message": error.safe_message,
                "raw_judge_outputs": {"direct": error.raw_output},
            }
        )
        return record
    except JudgeTransportError as error:
        record.update(
            {
                "status": error.code,
                "failure_stage": "direct",
                "failure_code": error.code,
                "failure_message": error.safe_message,
            }
        )
        return record
    except Exception:
        record.update(
            {
                "status": "judge_exception",
                "failure_stage": "direct",
                "failure_code": "judge_exception",
                "failure_message": (
                    "Direct judge raised an unexpected exception; its message "
                    "was omitted because it may contain sensitive data."
                ),
            }
        )
        return record

    validation = validate_evidence(example.trace, root, stage="direct")
    record["evidence_validation_issues"] = [
        issue.to_dict() for issue in validation.issues
    ]
    if not validation.valid:
        record.update(
            {
                "status": "evidence_invalid",
                "failure_stage": "evidence_validation",
                "failure_code": "invalid_evidence",
            }
        )
    else:
        record["status"] = (
            "success_needs_review" if validation.needs_review else "success"
        )
    _apply_root(record, example=example, root=root)
    return record


def predict_two_stage_case(
    case: PredictionCase,
    *,
    judge: Any,
    config: BenchmarkRunConfig,
    cache_root: str | Path,
    retry_failures: bool,
    completion_guard: Callable[[], None] | None = None,
) -> dict[str, Any]:
    """Run both provider stages from one hash-locked, gold-free case."""

    if not isinstance(case, PredictionCase):
        raise TypeError("two-stage prediction requires a PredictionCase")
    _validate_prediction_case(case)
    record: dict[str, Any] = {
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "case_input_sha256": case.case_input_sha256,
        "method": "two_stage",
        "status": None,
        "failure_stage": None,
        "failure_code": None,
        "failure_message": None,
        "handoff_ledger": None,
        "handoff_candidate_count": 0,
        "handoff_candidate_tuples": [],
        "specialist_finding_count": None,
        "specialist_counts_by_module": None,
        "root_cause_judgment": None,
        "judge_reported_step": None,
        "predicted_step": None,
        "predicted_event_id": None,
        "predicted_module": None,
        "predicted_error_type": None,
        "root_cause": None,
        "judge_step_matches_event_mapping": False,
        "raw_judge_outputs": {},
        "stage_attempted": {
            "handoff_ledger": False,
            "handoff_selector": False,
        },
        "stage_cache_hits": {
            "handoff_ledger": False,
            "handoff_selector": False,
        },
        "stage_identities": {
            "handoff_ledger": None,
            "handoff_selector": None,
        },
        "stage_provider_telemetry": {
            "handoff_ledger": None,
            "handoff_selector": None,
        },
        "provider_telemetry": None,
        "prompt_version": TWO_STAGE_PROMPT_VERSION,
        "adapter_version": ADAPTER_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "model": config.model,
        "temperature": config.temperature,
        "provider": config.provider,
        "endpoint": config.endpoint,
    }

    complete = getattr(judge, "complete", None)
    if not callable(complete):
        raise TypeError(
            "production two_stage requires judge.complete(messages)"
        )

    raw_snapshotter = getattr(judge, "telemetry_snapshot", None)
    telemetry_snapshotter = (
        raw_snapshotter if callable(raw_snapshotter) else None
    )
    semantic_cache_root = Path(cache_root) / "semantic_stages"
    shared_identity = _two_stage_identity(case, config=config)

    def apply_stage(
        stage: str,
        stage_record: Mapping[str, Any],
        *,
        cache_hit: bool,
    ) -> bool:
        record["stage_cache_hits"][stage] = cache_hit
        record["stage_identities"][stage] = {
            "request_sha256": stage_record["request_sha256"],
            "prompt_sha256": stage_record["prompt_sha256"],
            "raw_response_sha256": stage_record[
                "raw_response_sha256"
            ],
            "dependency_sha256": stage_record["identity"][
                "dependency_sha256"
            ],
        }
        record["raw_judge_outputs"][stage] = stage_record["raw_response"]
        record["stage_provider_telemetry"][stage] = stage_record[
            "stage_telemetry"
        ]
        attempted_telemetry = [
            record["stage_provider_telemetry"][name]
            for name in ("handoff_ledger", "handoff_selector")
            if record["stage_attempted"][name]
        ]
        record["provider_telemetry"] = sum_stage_telemetry(
            attempted_telemetry
        )
        if stage_record["status"] == "success":
            return True
        record.update(
            {
                "status": stage_record["status"],
                "failure_stage": stage_record["failure_stage"],
                "failure_code": stage_record["failure_code"],
                "failure_message": stage_record["failure_message"],
            }
        )
        return False

    ledger_messages = handoff_ledger_messages(case.judge_view)
    ledger_request = build_stage_request(
        stage="handoff_ledger",
        messages=ledger_messages,
        identity=shared_identity,
    )
    record["stage_attempted"]["handoff_ledger"] = True
    ledger_stage, ledger_cache_hit = run_cached_stage(
        request=ledger_request,
        messages=ledger_messages,
        complete=complete,
        parser=lambda raw: parse_handoff_ledger(
            raw,
            trace=case.judge_view,
        ).to_dict(),
        cache_root=semantic_cache_root,
        retry_failures=retry_failures,
        telemetry_snapshotter=telemetry_snapshotter,
        completion_guard=completion_guard,
    )
    if not apply_stage(
        "handoff_ledger",
        ledger_stage,
        cache_hit=ledger_cache_hit,
    ):
        return record
    ledger = parse_handoff_ledger(
        ledger_stage["raw_response"],
        trace=case.judge_view,
    )

    ledger_data = ledger.to_dict()
    record["handoff_ledger"] = ledger_data
    record["handoff_candidate_count"] = len(ledger.candidates)
    record["handoff_candidate_tuples"] = [
        {
            "step": candidate.critical_step,
            "module": candidate.module.value,
            "error_type": candidate.error_type.value,
        }
        for candidate in ledger.candidates
    ]
    record["specialist_finding_count"] = len(ledger.candidates)
    counts_by_module = {
        module: sum(
            candidate.module.value == module
            for candidate in ledger.candidates
        )
        for module in ("memory", "reflection", "planning", "action", "system")
    }
    record["specialist_counts_by_module"] = counts_by_module
    selector_messages = handoff_selector_messages(case.judge_view, ledger)
    selector_request = build_stage_request(
        stage="handoff_selector",
        messages=selector_messages,
        identity=shared_identity,
        dependency_sha256=stable_sha256(
            {
                "raw_response_sha256": ledger_stage[
                    "raw_response_sha256"
                ],
                "normalized_ledger": ledger_data,
            }
        ),
    )
    record["stage_attempted"]["handoff_selector"] = True
    selector_stage, selector_cache_hit = run_cached_stage(
        request=selector_request,
        messages=selector_messages,
        complete=complete,
        parser=lambda raw: parse_handoff_selector(
            raw,
            trace=case.judge_view,
        ).to_dict(),
        cache_root=semantic_cache_root,
        retry_failures=retry_failures,
        telemetry_snapshotter=telemetry_snapshotter,
        completion_guard=completion_guard,
    )
    if not apply_stage(
        "handoff_selector",
        selector_stage,
        cache_hit=selector_cache_hit,
    ):
        return record
    root = parse_handoff_selector(
        selector_stage["raw_response"],
        trace=case.judge_view,
    )
    mapped_step = case.step_for_event(root.critical_event_id)
    record.update(
        {
            "root_cause_judgment": root.to_dict(),
            "judge_reported_step": root.critical_step,
            "predicted_step": mapped_step,
            "predicted_event_id": root.critical_event_id,
            "predicted_module": root.module.value,
            "predicted_error_type": root.error_type.value,
            "root_cause": root.root_cause,
            "judge_step_matches_event_mapping": (
                mapped_step is not None and root.critical_step == mapped_step
            ),
        }
    )
    if mapped_step is None:
        record.update(
            {
                "status": "invalid_output",
                "failure_stage": "mapping",
                "failure_code": "critical_event_not_a_decision_step",
                "failure_message": (
                    "The selected event is not one uniquely mapped public "
                    "benchmark decision step."
                ),
            }
        )
        return record
    record["status"] = "success"
    return record


def _two_stage(
    example: BenchmarkExample,
    *,
    judge: Any,
    config: BenchmarkRunConfig,
    cache_root: str | Path,
    retry_failures: bool,
) -> dict[str, Any]:
    """Bridge a benchmark example to gold-free prediction, then score it."""

    record = _base_record(example, method="two_stage", config=config)
    record.update(
        {
            "handoff_ledger": None,
            "handoff_candidate_count": 0,
            "handoff_candidate_tuples": [],
            "candidate_evidence_validation_issues": [],
            "stage_attempted": {
                "handoff_ledger": False,
                "handoff_selector": False,
            },
            "stage_cache_hits": {
                "handoff_ledger": False,
                "handoff_selector": False,
            },
            "stage_identities": {
                "handoff_ledger": None,
                "handoff_selector": None,
            },
            "stage_provider_telemetry": {
                "handoff_ledger": None,
                "handoff_selector": None,
            },
            "provider_telemetry": None,
        }
    )
    integrity = validate_trace(example.trace, strict=False)
    if integrity.status == IntegrityStatus.FAIL:
        record.update(
            {
                "status": "blocked_by_integrity",
                "failure_stage": "integrity",
                "failure_code": "canonical_integrity_failure",
            }
        )
        return record

    prediction = predict_two_stage_case(
        _prediction_case(example),
        judge=judge,
        config=config,
        cache_root=cache_root,
        retry_failures=retry_failures,
    )
    record.update(
        {
            key: value
            for key, value in prediction.items()
            if key
            not in {
                "trajectory_id",
                "trajectory_sha256",
                "method",
            }
        }
    )
    if prediction["status"] != "success":
        return record

    ledger = parse_handoff_ledger(
        prediction["raw_judge_outputs"]["handoff_ledger"],
        trace=example.trace,
    )
    candidate_issues: list[dict[str, Any]] = []
    for index, candidate in enumerate(ledger.candidates):
        validation = validate_evidence(
            example.trace,
            candidate,
            stage=f"handoff_ledger.candidates[{index}]",
        )
        candidate_issues.extend(
            issue.to_dict() for issue in validation.issues
        )
    record["candidate_evidence_validation_issues"] = candidate_issues
    root = parse_handoff_selector(
        prediction["raw_judge_outputs"]["handoff_selector"],
        trace=example.trace,
    )

    validation = validate_evidence(
        example.trace,
        root,
        stage="handoff_selector",
    )
    record["evidence_validation_issues"] = [
        issue.to_dict() for issue in validation.issues
    ]
    if not validation.valid:
        record.update(
            {
                "status": "evidence_invalid",
                "failure_stage": "evidence_validation",
                "failure_code": "invalid_evidence",
            }
        )
    else:
        record["status"] = (
            "success_needs_review" if validation.needs_review else "success"
        )
    _apply_root(record, example=example, root=root)
    return record


def evaluate_examples(
    examples: Iterable[BenchmarkExample],
    *,
    methods: Iterable[str],
    judge: Any,
    config: BenchmarkRunConfig,
    cache_dir: str | Path,
    retry_failures: bool = False,
    workers: int = 1,
    on_result: Callable[[dict[str, Any]], None] | None = None,
) -> list[dict[str, Any]]:
    """Evaluate examples with atomic per-method result caching and resume."""

    method_list = list(methods)
    unknown = sorted(set(method_list) - {"direct", "two_stage"})
    if unknown:
        raise ValueError(f"unknown benchmark methods: {', '.join(unknown)}")
    complete = getattr(judge, "complete", None)
    if "direct" in method_list and not callable(complete):
        raise TypeError("Direct Prompting requires judge.complete(messages)")
    if "two_stage" in method_list and not callable(complete):
        raise TypeError(
            "production two_stage requires judge.complete(messages)"
        )
    if workers < 1:
        raise ValueError("workers must be at least 1")
    cache_root = Path(cache_dir).expanduser().resolve()
    cache_root.mkdir(parents=True, exist_ok=True)
    tasks = [
        (example, method)
        for example in examples
        for method in method_list
    ]

    def evaluate_one(
        example: BenchmarkExample,
        method: str,
    ) -> dict[str, Any]:
        key = _cache_key(example, method=method, config=config)
        cache_path = cache_root / f"{key}.json"
        if method == "direct" and cache_path.is_file():
            cached = json.loads(cache_path.read_text(encoding="utf-8"))
            if not retry_failures or str(cached.get("status", "")).startswith(
                "success"
            ):
                cached["cache_hit"] = True
                return cached
        started = time.monotonic()
        result = (
            _direct(
                example,
                complete=complete,
                config=config,
            )
            if method == "direct"
            else _two_stage(
                example,
                judge=judge,
                config=config,
                cache_root=cache_root,
                retry_failures=retry_failures,
            )
        )
        result["latency_seconds"] = time.monotonic() - started
        if method == "two_stage":
            attempted = [
                stage
                for stage, was_attempted in result["stage_attempted"].items()
                if was_attempted
            ]
            result["cache_hit"] = (
                all(result["stage_cache_hits"][stage] for stage in attempted)
                if attempted
                else cache_path.is_file()
            )
        else:
            result["cache_hit"] = False
        temporary = cache_path.with_suffix(f".{os.getpid()}.tmp")
        temporary.write_text(
            json.dumps(result, ensure_ascii=False, indent=2, default=str),
            encoding="utf-8",
        )
        temporary.replace(cache_path)
        return result

    results: list[dict[str, Any]] = []
    if workers == 1:
        for example, method in tasks:
            result = evaluate_one(example, method)
            results.append(result)
            if on_result:
                on_result(result)
    else:
        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {
                executor.submit(evaluate_one, example, method): (
                    example.label.trajectory_id,
                    method,
                )
                for example, method in tasks
            }
            for future in as_completed(futures):
                result = future.result()
                results.append(result)
                if on_result:
                    on_result(result)
        results.sort(key=lambda row: (row["trajectory_id"], row["method"]))
    return results


def conversion_failure_records(
    dataset: BenchmarkDataset,
    *,
    methods: Iterable[str],
    config: BenchmarkRunConfig,
) -> list[dict[str, Any]]:
    """Materialize accessible-but-unmappable samples as incorrect predictions."""

    label_by_id = {label.trajectory_id: label for label in dataset.labels}
    records: list[dict[str, Any]] = []
    for failure in dataset.conversion_failures:
        label = label_by_id.get(str(failure.get("trajectory_id")))
        if label is None:
            continue
        for method in methods:
            records.append(
                {
                    "trajectory_id": label.trajectory_id,
                    "environment": label.environment,
                    "source_llm": label.source_llm,
                    "method": method,
                    "status": "conversion_failure",
                    "failure_stage": "benchmark_adapter",
                    "failure_code": str(failure.get("reason")),
                    "failure_message": (
                        "The accessible source trajectory could not be paired "
                        "with its released gold step without inventing an event."
                    ),
                    "gold_step": label.original_step,
                    "gold_event_id": None,
                    "gold_raw_module": label.raw_module,
                    "gold_module": label.module,
                    "gold_raw_error_type": label.raw_error_type,
                    "gold_error_type": label.error_type,
                    "gold_normalization_notes": list(label.normalization_notes),
                    "predicted_step": None,
                    "judge_reported_step": None,
                    "predicted_event_id": None,
                    "predicted_module": None,
                    "predicted_error_type": None,
                    "root_cause": None,
                    "step_exact": False,
                    "step_module_exact": False,
                    "all_correct": None if label.error_type is None else False,
                    "specialist_finding_count": None,
                    "specialist_counts_by_module": None,
                    "evidence_validation_issues": [],
                    "raw_judge_outputs": {},
                    "latency_seconds": None,
                    "cache_hit": False,
                    "trajectory_sha256": None,
                    "prompt_version": (
                        DIRECT_PROMPT_VERSION
                        if method == "direct"
                        else TWO_STAGE_PROMPT_VERSION
                    ),
                    "adapter_version": ADAPTER_VERSION,
                    "transport_policy_version": TRANSPORT_POLICY_VERSION,
                    "model": config.model,
                    "temperature": config.temperature,
                    "provider": config.provider,
                    "endpoint": config.endpoint,
                    "conversion_failure": failure,
                }
            )
    return records

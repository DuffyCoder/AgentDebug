"""Write-once preregistration and promotion gates for E9.

The prediction side of this module is deliberately gold-free.  It freezes a
validated PredictionManifest, a deterministic batch plan, provider identity,
code bundle, paths, cache state, and a durable logical-completion budget before
the first provider call.  Benchmark labels are opened only by the promotion
function, after the raw prediction chain has closed.
"""

from __future__ import annotations

import hashlib
import json
import os
from collections import Counter
from pathlib import Path
from typing import Any, Mapping, Sequence

from agentdebug.diagnostics.batched_causal_judge import (
    BATCHED_ARBITER_PROMPT_PROTOCOL_VERSION,
    BATCHED_ARBITER_STAGE,
    BATCHED_CAUSAL_PIPELINE_VERSION,
    BATCHED_SCOUT_PROMPT_PROTOCOL_VERSION,
    BATCHED_SCOUT_STAGE,
)
from agentdebug.diagnostics.judge_view import JUDGE_VIEW_VERSION

from .cohort import load_cohort_manifest
from .dataset import load_agent_error_bench
from .fresh_semantic_workflow import (
    E8_LOGICAL_COMPLETION_LEDGER_SCHEMA_VERSION,
    FreshSemanticWorkflowError,
    initialize_fresh_semantic_completion_ledger,
    load_fresh_semantic_completion_ledger,
)
from .metrics import SUCCESS_STATUSES, compute_metrics
from .prediction_manifest import (
    build_prediction_case,
    load_prediction_manifest,
    stable_sha256,
)
from .runner import TRANSPORT_POLICY_VERSION, BenchmarkRunConfig
from .stage_cache import (
    RAW_RESPONSE_SIDECAR_SCHEMA_VERSION,
    RAW_STAGE_SCHEMA_VERSION,
    STAGE_CACHE_SCHEMA_VERSION,
)


E9_PREREGISTRATION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-preregistration.v8"
)
E9_PROMOTION_SCHEMA_VERSION = "agentdebug.benchmark.e9-promotion.v8"
E9_AUTHORIZATION_CLAIM_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-authorization-claim.v2"
)
E9_IMPLEMENTATION_CUMULATIVE_CEILING = 384
E9_CUMULATIVE_LOGICAL_COMPLETIONS_BEFORE = 340
E9_AUTHORIZATION_CHAIN_RELATIVE_PATH = (
    "output/agenterrorbench-gpt-4.1-e9-v13-authorization-chain"
)
_V8_TO_V11_AUTHORIZED_CUMULATIVE_CEILING = 380
_V12_AUTHORIZED_CUMULATIVE_CEILING = 380
_V12_PREREGISTRATION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-preregistration.v7"
)
_V12_PROMOTION_SCHEMA_VERSION = "agentdebug.benchmark.e9-promotion.v7"
_V11_PREREGISTRATION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-preregistration.v6"
)
_V11_PROMOTION_SCHEMA_VERSION = "agentdebug.benchmark.e9-promotion.v6"
_V10_PREREGISTRATION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-preregistration.v5"
)
_V10_PROMOTION_SCHEMA_VERSION = "agentdebug.benchmark.e9-promotion.v5"
_V9_PREREGISTRATION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-preregistration.v4"
)
_V9_PROMOTION_SCHEMA_VERSION = "agentdebug.benchmark.e9-promotion.v4"
_V7_REJECTED_DRY_RELATIVE_ROOT = (
    "output/agenterrorbench-gpt-4.1-tuning-v1-e9-v7-flat-arbiter-dry3"
)
_V7_REJECTED_CLAIM_RELATIVE_PATH = (
    "output/agenterrorbench-gpt-4.1-e9-v7-authorization-chain/01-dry3.json"
)
_V7_REJECTED_CLAIM_FILE_SHA256 = (
    "c0015d6366e6d7600d9ede4a6497b6a278dcfa8ba66fcfc3e6aef8a944cfbe9b"
)
_V7_REJECTED_CLAIM_SHA256 = (
    "9cc3b1f8c716a77dfe16f82f53eff70ebb71ed004402507f8b77e4cc388c296d"
)
_V7_REJECTED_PREREGISTRATION_FILE_SHA256 = (
    "65ec234ec1c77aa9b05a09cab9c088050486dcb96032b127a2332736e1fe73be"
)
_V7_REJECTED_PREREGISTRATION_SHA256 = (
    "24315f3a931ff9278e15dd49d862317b11673e819a8a8240c9a8e4c9d9142349"
)
_V7_REJECTED_PREDICT_RUN_FILE_SHA256 = (
    "a4da72bf686a35eadaaf40b717d984a6e90a410ee4fd7e9e97335030225ea6aa"
)
_V7_REJECTED_PREDICT_RUN_SHA256 = (
    "f3dcc135f9f0eab88555de45072ce245a9b207653871a39351925da6c8f13ba8"
)
_V7_REJECTED_LEDGER_FILE_SHA256 = (
    "6d97d5914d7510708a24242e7ccdc23de9fbbfbc0f42762c30189376f04c424b"
)
_V7_REJECTED_LEDGER_SHA256 = (
    "1cf6888131966072609d0ba78ae7b6266ab3b765a145dbe58ce853a9bc5343d1"
)
_V7_REJECTED_PROMOTION_FILE_SHA256 = (
    "0fa6a30e7f296b0e4f18d112a4683b2a1fc3a4b0a7b5d058902e235431f30784"
)
_V7_REJECTED_PROMOTION_SHA256 = (
    "082e0979cf17144fcee2c205915d131b3eb2fbfd4b3decddec41aa8ec44faf45"
)
_V7_REJECTED_ARBITER_REQUEST_SHA256 = (
    "a6f1691a8c98606feab17cc8394cae7890670b70ae10474b747545668a5a6f08"
)
_V8_REJECTED_DRY_RELATIVE_ROOT = (
    "output/agenterrorbench-gpt-4.1-tuning-v1-e9-v8-tail-recency-dry3"
)
_V8_REJECTED_CLAIM_RELATIVE_PATH = (
    "output/agenterrorbench-gpt-4.1-e9-v8-authorization-chain/01-dry3.json"
)
_V8_REJECTED_CLAIM_FILE_SHA256 = (
    "3ffe9c7d320007872b1bee79bb3d9465bc52dc217007334e8ee914619ce0fcd3"
)
_V8_REJECTED_CLAIM_SHA256 = (
    "caba7f9312d7ea99154ea7d71a0dcdf008244e2e991d92a2084627f79a552a6c"
)
_V8_REJECTED_PREREGISTRATION_FILE_SHA256 = (
    "2a3b9071c54e94ab3ba4973bf8780be9cee087f3b202cb53bd9d01ec7cc0c4b7"
)
_V8_REJECTED_PREREGISTRATION_SHA256 = (
    "cbf968f68f29f3950969c5d0d4d509536247fe88575077fdbaa08f41e4ac6a81"
)
_V8_REJECTED_PREDICT_RUN_FILE_SHA256 = (
    "93484337c0f48e6d01e698aa3d5c1f4be6667161feaa04826cd2fce3f92cc785"
)
_V8_REJECTED_PREDICT_RUN_SHA256 = (
    "86ce750882d288bd9fa945daa334043af7c2ab4835b786da5b98ea79f14a3993"
)
_V8_REJECTED_LEDGER_FILE_SHA256 = (
    "f00a5732a094bfc058bd4d6b60de9679b58d5318bb0da410cf61199dc8866995"
)
_V8_REJECTED_LEDGER_SHA256 = (
    "330aa8c9c3d10503d5ed6dbc380ec4b57099d383f49ed67f566841a0d48066a1"
)
_V8_REJECTED_PROMOTION_FILE_SHA256 = (
    "b6291345e3bb7d81c47b240639865331f354cc295b97f09cd73c0a547b0aaf2c"
)
_V8_REJECTED_PROMOTION_SHA256 = (
    "861a9b9b34ffc5248119b04023b3028bd2e8e8ab14d65364274d68cb9aaade33"
)
_V8_REJECTED_ARBITER_REQUEST_SHA256 = (
    "64c0080143a4552de3561505a3496031a9391d9e5d0b98ed2b548f09bb92bd14"
)
_V9_REJECTED_DRY_RELATIVE_ROOT = (
    "output/agenterrorbench-gpt-4.1-tuning-v1-e9-v9-"
    "literal-constraint-dry3"
)
_V9_REJECTED_CLAIM_RELATIVE_PATH = (
    "output/agenterrorbench-gpt-4.1-e9-v9-authorization-chain/01-dry3.json"
)
_V9_REJECTED_CLAIM_FILE_SHA256 = (
    "2b3ce1cf4164303519d3f10de18b67c271e0de462746140dcc0dc7400f33a997"
)
_V9_REJECTED_CLAIM_SHA256 = (
    "1d0fc1bff1b40ace74e2a6cee521dea2985227936fe56ad4d169434d99123ad8"
)
_V9_REJECTED_PREREGISTRATION_FILE_SHA256 = (
    "ccc488553693a7affc73a3bc15b5dffd010b2c1a3a74ecfa843d3fe2de2f68d7"
)
_V9_REJECTED_PREREGISTRATION_SHA256 = (
    "130b1c7bf549517139ed20efbf8c72eafcf9b1b0344030bc92966da95420bde0"
)
_V9_REJECTED_PREDICT_RUN_FILE_SHA256 = (
    "bee0f07915412d8ab0f8f124315a7ea881c36863ef017779d73ffac29c4503c4"
)
_V9_REJECTED_PREDICT_RUN_SHA256 = (
    "d7722a2bd2d47153f886820e55b55c845b37f56e91268605a2279c32f1622f8f"
)
_V9_REJECTED_LEDGER_FILE_SHA256 = (
    "83dbf94fa00425b683a2ef2e2f75558c9aa4571f47e0524ade419b676696e247"
)
_V9_REJECTED_LEDGER_SHA256 = (
    "14b953afab823d4dbafe22d674fb49f810278693b9f5f33f724067bfc5ad1d12"
)
_V9_REJECTED_PROMOTION_FILE_SHA256 = (
    "178b75fac2991a018a268dda1eb71fa9ac644bc3cf99eefa775c9fae31aa7a60"
)
_V9_REJECTED_PROMOTION_SHA256 = (
    "05d13f796ce2e4b90ba01fa1d903b4464456af1a38922c897d0e417a99359cf1"
)
_V9_REJECTED_ARBITER_REQUEST_SHA256 = (
    "ff70c011c85170651bbb44def82052fd20770d9d8e5e60a571c9d567e92cac64"
)
_V10_REJECTED_DRY_RELATIVE_ROOT = (
    "output/agenterrorbench-gpt-4.1-tuning-v1-e9-v10-ordered-root-dry3"
)
_V10_REJECTED_CLAIM_RELATIVE_PATH = (
    "output/agenterrorbench-gpt-4.1-e9-v10-authorization-chain/01-dry3.json"
)
_V10_REJECTED_CLAIM_FILE_SHA256 = (
    "7782b270e77ccafc98b8da81260745b6f542b98006b84bcedfc4b975b455bff4"
)
_V10_REJECTED_CLAIM_SHA256 = (
    "a521b1706a8dcb9d5a1c8b070704b60b556c85e7b7c1850cb99f920cebe3bc06"
)
_V10_REJECTED_PREREGISTRATION_FILE_SHA256 = (
    "d8c904a9d0339af12f778c95c91101e7a9d864c82fae89182e5b3fc53bb9d8bd"
)
_V10_REJECTED_PREREGISTRATION_SHA256 = (
    "4ef3ef550d7026a4535afaa30aa86a1f528071e22617d7e6455a25cdb4e0dc77"
)
_V10_REJECTED_PREDICT_RUN_FILE_SHA256 = (
    "f0a52b03953815ba716b46c0dd8353602b13cd8990d0424145feaefe6b64e855"
)
_V10_REJECTED_PREDICT_RUN_SHA256 = (
    "c27eb6465ada023a820cada7a3f44f715d4ea9c5d4c9703ee3ffc6e203597822"
)
_V10_REJECTED_LEDGER_FILE_SHA256 = (
    "66c03f05b153d726e1ffb2c98e9ff0efdf3399426600984ddecb66f02cd77c45"
)
_V10_REJECTED_LEDGER_SHA256 = (
    "a818079a94c7523f4d5038fdff638584012a9e27c8510d5d3b1916127d395c6d"
)
_V10_REJECTED_PROMOTION_FILE_SHA256 = (
    "e588e79924108f7a56933c9245d8b35df943906f4a1a3005b6f4941462280c43"
)
_V10_REJECTED_PROMOTION_SHA256 = (
    "2b0433f6b0c2369c50009a1fa9cea205ef92f3e50218bc16613eeb5ae6a62b02"
)
_V10_REJECTED_ARBITER_REQUEST_SHA256 = (
    "18cae0ddb6e70ac37efb47784869ab2e8f8b73afc291015f91f181c4b6327dbd"
)
_V11_REJECTED_DRY_RELATIVE_ROOT = (
    "output/agenterrorbench-gpt-4.1-tuning-v1-e9-v11-"
    "visible-audit-dry3"
)
_V11_REJECTED_CLAIM_RELATIVE_PATH = (
    "output/agenterrorbench-gpt-4.1-e9-v11-authorization-chain/01-dry3.json"
)
_V11_REJECTED_CLAIM_FILE_SHA256 = (
    "ff6988510e33ae3d087af596af3fc6117c2370b7f31a0dfb35061fb553048249"
)
_V11_REJECTED_CLAIM_SHA256 = (
    "84c752f6ab34e7c8092c34b81bf2741db4782f446d9dc6f25ce0c8dc6df214c8"
)
_V11_REJECTED_PREREGISTRATION_FILE_SHA256 = (
    "992b415b3f7a7029400020aaf035b085680ed60c1c3c6e8e671c31a5e1f01662"
)
_V11_REJECTED_PREREGISTRATION_SHA256 = (
    "0e436d1fa540e3269c05210c161d64bf6a93c8022116b448b921475df368b40a"
)
_V11_REJECTED_PREDICT_RUN_FILE_SHA256 = (
    "6e175ad6497c2f79bcd3cec456ccda1750d1b47aed1554acd1f61a86cb627493"
)
_V11_REJECTED_PREDICT_RUN_SHA256 = (
    "29ddf3adaf918611ab6c9aca9336620914cc701c404d411243bae5b7c5b8b402"
)
_V11_REJECTED_LEDGER_FILE_SHA256 = (
    "6df1fca3abc07c991f6e919872360a5d2116882f96a39ec00b7d3c6b2d9624d9"
)
_V11_REJECTED_LEDGER_SHA256 = (
    "a3ad70ac743660a76d405359270f26c93894147d04fccca65af0ce4031e69e4a"
)
_V11_REJECTED_PROMOTION_FILE_SHA256 = (
    "19aa161514897447b9c6f4eae4400a229690f0d9bda866390e503ef26d5d48e3"
)
_V11_REJECTED_PROMOTION_SHA256 = (
    "b49fc616de14fde7fc57bd956100af4c0e9e74a39841dc8d1ad1102127f2afcb"
)
_V11_REJECTED_ARBITER_REQUEST_SHA256 = (
    "721a6faea4b634bb10306fc42c13e39fd19540f63b35d2a64e3e214b71b6252a"
)
_V11_REJECTED_SCOUT_REQUEST_SHA256 = (
    "a20c9e4555667cc26b57508e96a48bd8758b92020777755fec5f2f532800905e"
)
_V12_REJECTED_DRY_RELATIVE_ROOT = (
    "output/agenterrorbench-gpt-4.1-tuning-v1-e9-v12-"
    "semantic-candidates-dry3"
)
_V12_REJECTED_CLAIM_RELATIVE_PATH = (
    "output/agenterrorbench-gpt-4.1-e9-v12-authorization-chain/01-dry3.json"
)
_V12_REJECTED_CLAIM_FILE_SHA256 = (
    "b3136d432149c2df3b22bfd8f6df624d825325e6f2d58c838dd49ca491c72b30"
)
_V12_REJECTED_CLAIM_SHA256 = (
    "62edd45fcda639d8d47cb8fd104fd653ffb906ca67bd2a7266446388d3d28482"
)
_V12_REJECTED_PREREGISTRATION_FILE_SHA256 = (
    "29cf9c2ef9ed93e42d43a31017a61b484d49e654c564fd7bd8302209a8299d5b"
)
_V12_REJECTED_PREREGISTRATION_SHA256 = (
    "faecbf4029fa5379212f72e84b3002a54539820a195c6d01a5c97fa1020eb5b1"
)
_V12_REJECTED_PREDICT_RUN_FILE_SHA256 = (
    "f3c7c554f1e4344bb7c4a7655c15b550def9050c88a2939ba8abdb5d7fd6d1e9"
)
_V12_REJECTED_PREDICT_RUN_SHA256 = (
    "0b69e31fb92f2e63399cea847c14e5d15ce096574b27875ed7a7b63fcb287604"
)
_V12_REJECTED_LEDGER_FILE_SHA256 = (
    "6d17052ebdcbce7d37b5447ab24df3171720d47abbc5a7c6bab0133e7a5b42ec"
)
_V12_REJECTED_LEDGER_SHA256 = (
    "27ba469b9023b38c78f2a0747ca33b049a9d6a81c71954ccea67d0f374aec348"
)
_V12_REJECTED_PROMOTION_FILE_SHA256 = (
    "13032284a32e13c0986522f72c81898420d6f960cccbd2a6a4d78c6843b4c69f"
)
_V12_REJECTED_PROMOTION_SHA256 = (
    "7a4a937af95388070239c5b93facac0aa676bb63e6a3cf3b0e8629e29381e2a3"
)
_V12_REJECTED_SCOUT_REQUEST_SHA256 = (
    "402666f2e16aa4e974af7f466473b9cfb38b9491c42e9b391123650d2392f736"
)
_V12_REJECTED_ARBITER_REQUEST_SHA256 = (
    "8f55d4af5f75f534a9a28ff8672554e9a5c84e1b4e57a59bd2019a606561ebda"
)
E9_DRY3_IDS_MANIFEST_ORDER = (
    "Qwen3-8B_024_id_24___chat_b013_t00_e01-5b8f974f",
    "Llama3.3-70B-Turbo_015_memory_b001_t00_e06-71f77595",
    "GPT-4o_008_chat_b000_t00_e07-d50ae81f",
)
E9_EVALUATION_PROFILES: dict[str, dict[str, Any]] = {
    "dry3": {
        "cohort_name": "tuning-v1",
        "cohort_sha256": (
            "e21b1034470577688b68aad2a0e006facc658fed28bdb986f"
            "ed039bc0347bd6f"
        ),
        "cohort_count": 30,
        "selection_count": 3,
        "full_cohort": False,
        "heldout": False,
        "selection_ids": E9_DRY3_IDS_MANIFEST_ORDER,
    },
    "full30": {
        "cohort_name": "tuning-v1",
        "cohort_sha256": (
            "e21b1034470577688b68aad2a0e006facc658fed28bdb986f"
            "ed039bc0347bd6f"
        ),
        "cohort_count": 30,
        "selection_count": 30,
        "full_cohort": True,
        "heldout": False,
        "selection_ids": None,
    },
    "smoke30": {
        "cohort_name": "smoke-v1",
        "cohort_sha256": (
            "6dfbc06b27a64f80719787b0cd56736a26ae97a98ba7714d"
            "af6a571808d11fe0"
        ),
        "cohort_count": 30,
        "selection_count": 30,
        "full_cohort": True,
        "heldout": True,
        "selection_ids": None,
    },
}

_FORMAL_PROFILES = frozenset(E9_EVALUATION_PROFILES)
_STAGES = (BATCHED_SCOUT_STAGE, BATCHED_ARBITER_STAGE)
_V13_SEMANTIC_INPUT_IDENTITY = (
    "complete_anonymous_timelines_plus_label_free_unranked_"
    "atomic_taxonomy_pair_llm_semantic_candidates"
)
_SUPPORTED_GATE_FIELDS = {
    "all_correct_minimum",
    "failed_prediction_maximum",
    "gold_isolation_required",
    "heldout_one_shot_required",
    "llm_arbiter_raw_root_required",
    "raw_chain_reconstruction_required",
    "semantic_mutation_maximum",
    "step_exact_minimum_correct",
    "step_module_exact_minimum_correct",
    "successful_prediction_minimum",
    "trajectory_denominator",
}
_CODE_PATHS = (
    "agentdebug/__init__.py",
    "agentdebug/diagnostics/__init__.py",
    "agentdebug/diagnostics/analyzer.py",
    "agentdebug/diagnostics/batched_causal_judge.py",
    "agentdebug/diagnostics/evidence_repair.py",
    "agentdebug/diagnostics/fresh_semantic_evidence.py",
    "agentdebug/diagnostics/fresh_semantic_judge.py",
    "agentdebug/diagnostics/global_critic.py",
    "agentdebug/diagnostics/handoff.py",
    "agentdebug/diagnostics/judge_view.py",
    "agentdebug/diagnostics/models.py",
    "agentdebug/diagnostics/parsing.py",
    "agentdebug/diagnostics/prompts.py",
    "agentdebug/diagnostics/providers.py",
    "agentdebug/diagnostics/redaction.py",
    "agentdebug/diagnostics/taxonomy.py",
    "agentdebug/diagnostics/validator.py",
    "agentdebug/benchmark/__init__.py",
    "agentdebug/benchmark/adapter.py",
    "agentdebug/benchmark/batched_causal_cli.py",
    "agentdebug/benchmark/batched_causal_preregistration.py",
    "agentdebug/benchmark/batched_causal_workflow.py",
    "agentdebug/benchmark/cli.py",
    "agentdebug/benchmark/cohort.py",
    "agentdebug/benchmark/dataset.py",
    "agentdebug/benchmark/fresh_semantic_workflow.py",
    "agentdebug/benchmark/metrics.py",
    "agentdebug/benchmark/models.py",
    "agentdebug/benchmark/prediction_manifest.py",
    "agentdebug/benchmark/prompts.py",
    "agentdebug/benchmark/reporting.py",
    "agentdebug/benchmark/runner.py",
    "agentdebug/benchmark/stage_cache.py",
    "agentdebug/trace/__init__.py",
    "agentdebug/trace/_common.py",
    "agentdebug/trace/artifacts.py",
    "agentdebug/trace/claw_eval.py",
    "agentdebug/trace/integrity.py",
    "agentdebug/trace/io.py",
    "agentdebug/trace/models.py",
    "agentdebug/trace/reconcile.py",
    "agentdebug/trace/runtime_v1.py",
    "agentdebug/trace/session_v3.py",
    "docs/experiments/e9-batched-causal-judge.md",
    "tests/test_batched_causal_judge.py",
    "tests/test_batched_causal_cli_bridge.py",
    "tests/test_batched_causal_preregistration.py",
    "tests/test_batched_causal_workflow.py",
    "tests/test_stage_cache.py",
)


class BatchedCausalPreregistrationError(ValueError):
    """An E9 artifact differs from the frozen formal experiment identity."""


def _workflow() -> Any:
    # Kept local so importing this module remains useful while the E9 workflow
    # and this preregistration module are developed in parallel.
    from . import batched_causal_workflow

    return batched_causal_workflow


def _file_sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).expanduser().resolve().open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _atomic_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def _exclusive_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError as error:
        raise BatchedCausalPreregistrationError(
            "E9 authorization phase was already claimed"
        ) from error
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    directory_fd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def _read(path: str | Path, *, location: str) -> dict[str, Any]:
    try:
        value = json.loads(
            Path(path).expanduser().resolve().read_text(encoding="utf-8")
        )
    except (OSError, json.JSONDecodeError) as error:
        raise BatchedCausalPreregistrationError(
            f"{location} is missing or corrupt"
        ) from error
    if not isinstance(value, dict):
        raise BatchedCausalPreregistrationError(
            f"{location} must be an object"
        )
    return value


def _directory_state(
    root: str | Path,
    *,
    excluded_paths: Sequence[str | Path] = (),
) -> dict[str, Any]:
    resolved_root = Path(root).expanduser().resolve()
    excluded = {
        Path(value).expanduser().resolve() for value in excluded_paths
    }
    files: dict[str, str] = {}
    if resolved_root.is_dir():
        for path in sorted(
            (item for item in resolved_root.rglob("*") if item.is_file()),
            key=lambda item: str(item),
        ):
            resolved = path.resolve()
            if resolved not in excluded:
                files[str(resolved.relative_to(resolved_root))] = (
                    _file_sha256(resolved)
                )
    return {
        "file_count": len(files),
        "files_sha256": stable_sha256(files),
    }


def _validated_hashed_document(
    path: str | Path,
    *,
    location: str,
    hash_field: str,
) -> dict[str, Any]:
    document = _read(path, location=location)
    body = dict(document)
    claimed = body.pop(hash_field, None)
    if claimed != stable_sha256(body):
        raise BatchedCausalPreregistrationError(
            f"{location} self-hash is invalid"
        )
    return document


def _repository_path(relative_path: str) -> Path:
    return (Path(__file__).resolve().parents[2] / relative_path).resolve()


def _resolve_v7_rejected_usage_anchor(
    *,
    config: BenchmarkRunConfig,
) -> dict[str, Any]:
    """Bind the rejected v7 dry only as proof that cumulative usage is 334."""

    root = _repository_path(_V7_REJECTED_DRY_RELATIVE_ROOT)
    paths = {
        "claim": _repository_path(_V7_REJECTED_CLAIM_RELATIVE_PATH),
        "preregistration": root / "preregistration.json",
        "predict_run": root / "predict-run.json",
        "ledger": root / "logical-completion-ledger.json",
        "promotion": root / "promotion.json",
    }
    expected_files = {
        "claim": _V7_REJECTED_CLAIM_FILE_SHA256,
        "preregistration": _V7_REJECTED_PREREGISTRATION_FILE_SHA256,
        "predict_run": _V7_REJECTED_PREDICT_RUN_FILE_SHA256,
        "ledger": _V7_REJECTED_LEDGER_FILE_SHA256,
        "promotion": _V7_REJECTED_PROMOTION_FILE_SHA256,
    }
    if any(
        not path.is_file()
        or _file_sha256(path) != expected_files[name]
        for name, path in paths.items()
    ):
        raise BatchedCausalPreregistrationError(
            "E9 rejected v7 usage-anchor bytes changed"
        )
    claim = _validated_hashed_document(
        paths["claim"],
        location="E9 rejected v7 claim",
        hash_field="claim_sha256",
    )
    preregistration = _validated_hashed_document(
        paths["preregistration"],
        location="E9 rejected v7 preregistration",
        hash_field="preregistration_sha256",
    )
    predict_run = _validated_hashed_document(
        paths["predict_run"],
        location="E9 rejected v7 predict run",
        hash_field="predict_run_sha256",
    )
    ledger = _validated_hashed_document(
        paths["ledger"],
        location="E9 rejected v7 ledger",
        hash_field="ledger_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion"],
        location="E9 rejected v7 promotion",
        hash_field="promotion_sha256",
    )
    budget = preregistration.get("logical_completion_budget")
    checks = promotion.get("checks")
    expected_ledger_entries = [
        {
            "ordinal": 1,
            "stage": BATCHED_ARBITER_STAGE,
            "request_sha256": _V7_REJECTED_ARBITER_REQUEST_SHA256,
        }
    ]
    if (
        claim.get("claim_sha256") != _V7_REJECTED_CLAIM_SHA256
        or claim.get("profile") != "dry3"
        or claim.get("preregistration_path")
        != str(paths["preregistration"])
        or claim.get("preregistration_sha256")
        != _V7_REJECTED_PREREGISTRATION_SHA256
        or claim.get("cumulative_before") != 333
        or claim.get("maximum_new") != 1
        or claim.get("hard_cumulative_stop") != 334
        or preregistration.get("preregistration_sha256")
        != _V7_REJECTED_PREREGISTRATION_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 333
        or budget.get("maximum_new") != 1
        or budget.get("hard_cumulative_stop") != 334
        or _provider_identity_without_cohort(
            preregistration.get("provider_config")
        )
        != _provider_identity_without_cohort(config.public_dict())
        or predict_run.get("predict_run_sha256")
        != _V7_REJECTED_PREDICT_RUN_SHA256
        or predict_run.get("preregistration_sha256")
        != _V7_REJECTED_PREREGISTRATION_SHA256
        or predict_run.get("logical_completion_budget_used") != 1
        or predict_run.get("max_logical_completions") != 1
        or predict_run.get("logical_completion_ledger_file_sha256")
        != _V7_REJECTED_LEDGER_FILE_SHA256
        or predict_run.get("logical_completion_ledger_sha256")
        != _V7_REJECTED_LEDGER_SHA256
        or ledger.get("ledger_sha256") != _V7_REJECTED_LEDGER_SHA256
        or ledger.get("preregistration_sha256")
        != _V7_REJECTED_PREREGISTRATION_SHA256
        or ledger.get("entries") != expected_ledger_entries
        or promotion.get("promotion_sha256")
        != _V7_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or promotion.get("preregistration_path")
        != str(paths["preregistration"])
        or promotion.get("preregistration_sha256")
        != _V7_REJECTED_PREREGISTRATION_SHA256
        or promotion.get("predict_run_path") != str(paths["predict_run"])
        or promotion.get("predict_run_file_sha256")
        != _V7_REJECTED_PREDICT_RUN_FILE_SHA256
        or not isinstance(checks, Mapping)
        or checks.get("runtime_budget_exactly_preregistered") is not True
        or checks.get("dry_reuses_only_verified_scout_seed") is not True
        or checks.get("step_exact_minimum_correct") is not False
    ):
        raise BatchedCausalPreregistrationError(
            "E9 rejected v7 run is not a valid usage-only anchor"
        )
    anchor: dict[str, Any] = {
        "role": "usage_only_rejected_not_semantic_predecessor",
        "cumulative_before": 333,
        "logical_completions_used": 1,
        "cumulative_after": 334,
        "claim": {
            "path": str(paths["claim"]),
            "file_sha256": _V7_REJECTED_CLAIM_FILE_SHA256,
            "content_sha256": _V7_REJECTED_CLAIM_SHA256,
        },
        "preregistration": {
            "path": str(paths["preregistration"]),
            "file_sha256": _V7_REJECTED_PREREGISTRATION_FILE_SHA256,
            "content_sha256": _V7_REJECTED_PREREGISTRATION_SHA256,
        },
        "predict_run": {
            "path": str(paths["predict_run"]),
            "file_sha256": _V7_REJECTED_PREDICT_RUN_FILE_SHA256,
            "content_sha256": _V7_REJECTED_PREDICT_RUN_SHA256,
        },
        "logical_completion_ledger": {
            "path": str(paths["ledger"]),
            "file_sha256": _V7_REJECTED_LEDGER_FILE_SHA256,
            "content_sha256": _V7_REJECTED_LEDGER_SHA256,
            "entries": expected_ledger_entries,
        },
        "rejected_promotion": {
            "path": str(paths["promotion"]),
            "file_sha256": _V7_REJECTED_PROMOTION_FILE_SHA256,
            "content_sha256": _V7_REJECTED_PROMOTION_SHA256,
            "accepted": False,
        },
    }
    anchor["usage_anchor_sha256"] = stable_sha256(anchor)
    return anchor


def _resolve_v8_rejected_usage_anchor(
    *,
    config: BenchmarkRunConfig,
) -> dict[str, Any]:
    """Bind rejected v8, plus its v7 anchor, only as proof of usage 335."""

    previous_usage_anchor = _resolve_v7_rejected_usage_anchor(config=config)
    root = _repository_path(_V8_REJECTED_DRY_RELATIVE_ROOT)
    paths = {
        "claim": _repository_path(_V8_REJECTED_CLAIM_RELATIVE_PATH),
        "preregistration": root / "preregistration.json",
        "predict_run": root / "predict-run.json",
        "ledger": root / "logical-completion-ledger.json",
        "promotion": root / "promotion.json",
    }
    expected_files = {
        "claim": _V8_REJECTED_CLAIM_FILE_SHA256,
        "preregistration": _V8_REJECTED_PREREGISTRATION_FILE_SHA256,
        "predict_run": _V8_REJECTED_PREDICT_RUN_FILE_SHA256,
        "ledger": _V8_REJECTED_LEDGER_FILE_SHA256,
        "promotion": _V8_REJECTED_PROMOTION_FILE_SHA256,
    }
    if any(
        not path.is_file()
        or _file_sha256(path) != expected_files[name]
        for name, path in paths.items()
    ):
        raise BatchedCausalPreregistrationError(
            "E9 rejected v8 usage-anchor bytes changed"
        )
    claim = _validated_hashed_document(
        paths["claim"],
        location="E9 rejected v8 claim",
        hash_field="claim_sha256",
    )
    preregistration = _validated_hashed_document(
        paths["preregistration"],
        location="E9 rejected v8 preregistration",
        hash_field="preregistration_sha256",
    )
    predict_run = _validated_hashed_document(
        paths["predict_run"],
        location="E9 rejected v8 predict run",
        hash_field="predict_run_sha256",
    )
    ledger = _validated_hashed_document(
        paths["ledger"],
        location="E9 rejected v8 ledger",
        hash_field="ledger_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion"],
        location="E9 rejected v8 promotion",
        hash_field="promotion_sha256",
    )
    budget = preregistration.get("logical_completion_budget")
    checks = promotion.get("checks")
    summary = promotion.get("summary")
    expected_ledger_entries = [
        {
            "ordinal": 1,
            "stage": BATCHED_ARBITER_STAGE,
            "request_sha256": _V8_REJECTED_ARBITER_REQUEST_SHA256,
        }
    ]
    if (
        claim.get("claim_sha256") != _V8_REJECTED_CLAIM_SHA256
        or claim.get("profile") != "dry3"
        or claim.get("preregistration_path")
        != str(paths["preregistration"])
        or claim.get("preregistration_sha256")
        != _V8_REJECTED_PREREGISTRATION_SHA256
        or claim.get("cumulative_before") != 334
        or claim.get("maximum_new") != 1
        or claim.get("hard_cumulative_stop") != 335
        or claim.get("predecessor_claim_sha256") is not None
        or claim.get("predecessor_promotion_sha256") is not None
        or preregistration.get("preregistration_sha256")
        != _V8_REJECTED_PREREGISTRATION_SHA256
        or preregistration.get("predecessor") is not None
        or preregistration.get("prior_usage_anchor")
        != previous_usage_anchor
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 334
        or budget.get("maximum_new") != 1
        or budget.get("hard_cumulative_stop") != 335
        or budget.get("authorized_cumulative_ceiling")
        != _V8_TO_V11_AUTHORIZED_CUMULATIVE_CEILING
        or _provider_identity_without_cohort(
            preregistration.get("provider_config")
        )
        != _provider_identity_without_cohort(config.public_dict())
        or predict_run.get("predict_run_sha256")
        != _V8_REJECTED_PREDICT_RUN_SHA256
        or predict_run.get("preregistration_sha256")
        != _V8_REJECTED_PREREGISTRATION_SHA256
        or predict_run.get("logical_completion_budget_used") != 1
        or predict_run.get("max_logical_completions") != 1
        or predict_run.get("logical_completion_ledger_file_sha256")
        != _V8_REJECTED_LEDGER_FILE_SHA256
        or predict_run.get("logical_completion_ledger_sha256")
        != _V8_REJECTED_LEDGER_SHA256
        or ledger.get("ledger_sha256") != _V8_REJECTED_LEDGER_SHA256
        or ledger.get("preregistration_sha256")
        != _V8_REJECTED_PREREGISTRATION_SHA256
        or ledger.get("cumulative_logical_completions_before") != 334
        or ledger.get("maximum_new_logical_completions") != 1
        or ledger.get("hard_cumulative_stop") != 335
        or ledger.get("entries") != expected_ledger_entries
        or promotion.get("promotion_sha256")
        != _V8_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or promotion.get("preregistration_path")
        != str(paths["preregistration"])
        or promotion.get("preregistration_sha256")
        != _V8_REJECTED_PREREGISTRATION_SHA256
        or promotion.get("predict_run_path") != str(paths["predict_run"])
        or promotion.get("predict_run_file_sha256")
        != _V8_REJECTED_PREDICT_RUN_FILE_SHA256
        or not isinstance(checks, Mapping)
        or checks.get("runtime_budget_exactly_preregistered") is not True
        or checks.get("dry_reuses_only_verified_scout_seed") is not True
        or checks.get("step_exact_minimum_correct") is not False
        or not isinstance(summary, Mapping)
        or summary.get("trajectory_count") != 3
        or summary.get("step_correct") != 1
        or summary.get("step_denominator") != 3
        or summary.get("step_module_correct") != 1
        or summary.get("all_correct") != 1
        or summary.get("failed_prediction_count") != 0
        or summary.get("logical_completion_budget_used") != 1
    ):
        raise BatchedCausalPreregistrationError(
            "E9 rejected v8 run is not a valid usage-only anchor"
        )
    anchor: dict[str, Any] = {
        "role": "usage_only_rejected_not_semantic_predecessor",
        "cumulative_before": 334,
        "logical_completions_used": 1,
        "cumulative_after": 335,
        "previous_usage_anchor": previous_usage_anchor,
        "claim": {
            "path": str(paths["claim"]),
            "file_sha256": _V8_REJECTED_CLAIM_FILE_SHA256,
            "content_sha256": _V8_REJECTED_CLAIM_SHA256,
        },
        "preregistration": {
            "path": str(paths["preregistration"]),
            "file_sha256": _V8_REJECTED_PREREGISTRATION_FILE_SHA256,
            "content_sha256": _V8_REJECTED_PREREGISTRATION_SHA256,
        },
        "predict_run": {
            "path": str(paths["predict_run"]),
            "file_sha256": _V8_REJECTED_PREDICT_RUN_FILE_SHA256,
            "content_sha256": _V8_REJECTED_PREDICT_RUN_SHA256,
        },
        "logical_completion_ledger": {
            "path": str(paths["ledger"]),
            "file_sha256": _V8_REJECTED_LEDGER_FILE_SHA256,
            "content_sha256": _V8_REJECTED_LEDGER_SHA256,
            "entries": expected_ledger_entries,
        },
        "rejected_promotion": {
            "path": str(paths["promotion"]),
            "file_sha256": _V8_REJECTED_PROMOTION_FILE_SHA256,
            "content_sha256": _V8_REJECTED_PROMOTION_SHA256,
            "accepted": False,
        },
    }
    anchor["usage_anchor_sha256"] = stable_sha256(anchor)
    return anchor


def _resolve_v9_rejected_usage_anchor(
    *,
    config: BenchmarkRunConfig,
) -> dict[str, Any]:
    """Bind rejected v9 and its v8→v7 chain only as proof of usage 336."""

    previous_usage_anchor = _resolve_v8_rejected_usage_anchor(config=config)
    root = _repository_path(_V9_REJECTED_DRY_RELATIVE_ROOT)
    paths = {
        "claim": _repository_path(_V9_REJECTED_CLAIM_RELATIVE_PATH),
        "preregistration": root / "preregistration.json",
        "predict_run": root / "predict-run.json",
        "ledger": root / "logical-completion-ledger.json",
        "promotion": root / "promotion.json",
    }
    expected_files = {
        "claim": _V9_REJECTED_CLAIM_FILE_SHA256,
        "preregistration": _V9_REJECTED_PREREGISTRATION_FILE_SHA256,
        "predict_run": _V9_REJECTED_PREDICT_RUN_FILE_SHA256,
        "ledger": _V9_REJECTED_LEDGER_FILE_SHA256,
        "promotion": _V9_REJECTED_PROMOTION_FILE_SHA256,
    }
    if any(
        not path.is_file()
        or _file_sha256(path) != expected_files[name]
        for name, path in paths.items()
    ):
        raise BatchedCausalPreregistrationError(
            "E9 rejected v9 usage-anchor bytes changed"
        )
    claim = _validated_hashed_document(
        paths["claim"],
        location="E9 rejected v9 claim",
        hash_field="claim_sha256",
    )
    preregistration = _validated_hashed_document(
        paths["preregistration"],
        location="E9 rejected v9 preregistration",
        hash_field="preregistration_sha256",
    )
    predict_run = _validated_hashed_document(
        paths["predict_run"],
        location="E9 rejected v9 predict run",
        hash_field="predict_run_sha256",
    )
    ledger = _validated_hashed_document(
        paths["ledger"],
        location="E9 rejected v9 ledger",
        hash_field="ledger_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion"],
        location="E9 rejected v9 promotion",
        hash_field="promotion_sha256",
    )
    budget = preregistration.get("logical_completion_budget")
    checks = promotion.get("checks")
    summary = promotion.get("summary")
    expected_ledger_entries = [
        {
            "ordinal": 1,
            "stage": BATCHED_ARBITER_STAGE,
            "request_sha256": _V9_REJECTED_ARBITER_REQUEST_SHA256,
        }
    ]
    if (
        claim.get("claim_sha256") != _V9_REJECTED_CLAIM_SHA256
        or claim.get("profile") != "dry3"
        or claim.get("preregistration_path")
        != str(paths["preregistration"])
        or claim.get("preregistration_sha256")
        != _V9_REJECTED_PREREGISTRATION_SHA256
        or claim.get("cumulative_before") != 335
        or claim.get("maximum_new") != 1
        or claim.get("hard_cumulative_stop") != 336
        or claim.get("predecessor_claim_sha256") is not None
        or claim.get("predecessor_promotion_sha256") is not None
        or preregistration.get("schema_version")
        != _V9_PREREGISTRATION_SCHEMA_VERSION
        or preregistration.get("preregistration_sha256")
        != _V9_REJECTED_PREREGISTRATION_SHA256
        or preregistration.get("predecessor") is not None
        or preregistration.get("prior_usage_anchor")
        != previous_usage_anchor
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 335
        or budget.get("maximum_new") != 1
        or budget.get("hard_cumulative_stop") != 336
        or budget.get("authorized_cumulative_ceiling")
        != _V8_TO_V11_AUTHORIZED_CUMULATIVE_CEILING
        or _provider_identity_without_cohort(
            preregistration.get("provider_config")
        )
        != _provider_identity_without_cohort(config.public_dict())
        or predict_run.get("predict_run_sha256")
        != _V9_REJECTED_PREDICT_RUN_SHA256
        or predict_run.get("preregistration_sha256")
        != _V9_REJECTED_PREREGISTRATION_SHA256
        or predict_run.get("logical_completion_budget_used") != 1
        or predict_run.get("max_logical_completions") != 1
        or predict_run.get("logical_completion_ledger_file_sha256")
        != _V9_REJECTED_LEDGER_FILE_SHA256
        or predict_run.get("logical_completion_ledger_sha256")
        != _V9_REJECTED_LEDGER_SHA256
        or ledger.get("ledger_sha256") != _V9_REJECTED_LEDGER_SHA256
        or ledger.get("preregistration_sha256")
        != _V9_REJECTED_PREREGISTRATION_SHA256
        or ledger.get("cumulative_logical_completions_before") != 335
        or ledger.get("maximum_new_logical_completions") != 1
        or ledger.get("hard_cumulative_stop") != 336
        or ledger.get("entries") != expected_ledger_entries
        or promotion.get("schema_version") != _V9_PROMOTION_SCHEMA_VERSION
        or promotion.get("promotion_sha256")
        != _V9_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or promotion.get("preregistration_path")
        != str(paths["preregistration"])
        or promotion.get("preregistration_sha256")
        != _V9_REJECTED_PREREGISTRATION_SHA256
        or promotion.get("predict_run_path") != str(paths["predict_run"])
        or promotion.get("predict_run_file_sha256")
        != _V9_REJECTED_PREDICT_RUN_FILE_SHA256
        or not isinstance(checks, Mapping)
        or checks.get("runtime_budget_exactly_preregistered") is not True
        or checks.get("dry_reuses_only_verified_scout_seed") is not True
        or checks.get("step_exact_minimum_correct") is not False
        or not isinstance(summary, Mapping)
        or summary.get("trajectory_count") != 3
        or summary.get("step_correct") != 1
        or summary.get("step_denominator") != 3
        or summary.get("step_module_correct") != 1
        or summary.get("all_correct") != 1
        or summary.get("failed_prediction_count") != 0
        or summary.get("logical_completion_budget_used") != 1
    ):
        raise BatchedCausalPreregistrationError(
            "E9 rejected v9 run is not a valid usage-only anchor"
        )
    anchor: dict[str, Any] = {
        "role": "usage_only_rejected_not_semantic_predecessor",
        "cumulative_before": 335,
        "logical_completions_used": 1,
        "cumulative_after": 336,
        "previous_usage_anchor": previous_usage_anchor,
        "claim": {
            "path": str(paths["claim"]),
            "file_sha256": _V9_REJECTED_CLAIM_FILE_SHA256,
            "content_sha256": _V9_REJECTED_CLAIM_SHA256,
        },
        "preregistration": {
            "path": str(paths["preregistration"]),
            "file_sha256": _V9_REJECTED_PREREGISTRATION_FILE_SHA256,
            "content_sha256": _V9_REJECTED_PREREGISTRATION_SHA256,
        },
        "predict_run": {
            "path": str(paths["predict_run"]),
            "file_sha256": _V9_REJECTED_PREDICT_RUN_FILE_SHA256,
            "content_sha256": _V9_REJECTED_PREDICT_RUN_SHA256,
        },
        "logical_completion_ledger": {
            "path": str(paths["ledger"]),
            "file_sha256": _V9_REJECTED_LEDGER_FILE_SHA256,
            "content_sha256": _V9_REJECTED_LEDGER_SHA256,
            "entries": expected_ledger_entries,
        },
        "rejected_promotion": {
            "path": str(paths["promotion"]),
            "file_sha256": _V9_REJECTED_PROMOTION_FILE_SHA256,
            "content_sha256": _V9_REJECTED_PROMOTION_SHA256,
            "accepted": False,
        },
    }
    anchor["usage_anchor_sha256"] = stable_sha256(anchor)
    return anchor


def _resolve_v10_rejected_usage_anchor(
    *,
    config: BenchmarkRunConfig,
) -> dict[str, Any]:
    """Bind rejected v10 and its v9→v8→v7 chain as proof of usage 337."""

    previous_usage_anchor = _resolve_v9_rejected_usage_anchor(config=config)
    root = _repository_path(_V10_REJECTED_DRY_RELATIVE_ROOT)
    paths = {
        "claim": _repository_path(_V10_REJECTED_CLAIM_RELATIVE_PATH),
        "preregistration": root / "preregistration.json",
        "predict_run": root / "predict-run.json",
        "ledger": root / "logical-completion-ledger.json",
        "promotion": root / "promotion.json",
    }
    expected_files = {
        "claim": _V10_REJECTED_CLAIM_FILE_SHA256,
        "preregistration": _V10_REJECTED_PREREGISTRATION_FILE_SHA256,
        "predict_run": _V10_REJECTED_PREDICT_RUN_FILE_SHA256,
        "ledger": _V10_REJECTED_LEDGER_FILE_SHA256,
        "promotion": _V10_REJECTED_PROMOTION_FILE_SHA256,
    }
    if any(
        not path.is_file()
        or _file_sha256(path) != expected_files[name]
        for name, path in paths.items()
    ):
        raise BatchedCausalPreregistrationError(
            "E9 rejected v10 usage-anchor bytes changed"
        )
    claim = _validated_hashed_document(
        paths["claim"],
        location="E9 rejected v10 claim",
        hash_field="claim_sha256",
    )
    preregistration = _validated_hashed_document(
        paths["preregistration"],
        location="E9 rejected v10 preregistration",
        hash_field="preregistration_sha256",
    )
    predict_run = _validated_hashed_document(
        paths["predict_run"],
        location="E9 rejected v10 predict run",
        hash_field="predict_run_sha256",
    )
    ledger = _validated_hashed_document(
        paths["ledger"],
        location="E9 rejected v10 ledger",
        hash_field="ledger_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion"],
        location="E9 rejected v10 promotion",
        hash_field="promotion_sha256",
    )
    budget = preregistration.get("logical_completion_budget")
    checks = promotion.get("checks")
    summary = promotion.get("summary")
    expected_ledger_entries = [
        {
            "ordinal": 1,
            "stage": BATCHED_ARBITER_STAGE,
            "request_sha256": _V10_REJECTED_ARBITER_REQUEST_SHA256,
        }
    ]
    if (
        claim.get("claim_sha256") != _V10_REJECTED_CLAIM_SHA256
        or claim.get("profile") != "dry3"
        or claim.get("preregistration_path")
        != str(paths["preregistration"])
        or claim.get("preregistration_sha256")
        != _V10_REJECTED_PREREGISTRATION_SHA256
        or claim.get("cumulative_before") != 336
        or claim.get("maximum_new") != 1
        or claim.get("hard_cumulative_stop") != 337
        or claim.get("predecessor_claim_sha256") is not None
        or claim.get("predecessor_promotion_sha256") is not None
        or preregistration.get("schema_version")
        != _V10_PREREGISTRATION_SCHEMA_VERSION
        or preregistration.get("preregistration_sha256")
        != _V10_REJECTED_PREREGISTRATION_SHA256
        or preregistration.get("predecessor") is not None
        or preregistration.get("prior_usage_anchor")
        != previous_usage_anchor
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 336
        or budget.get("maximum_new") != 1
        or budget.get("hard_cumulative_stop") != 337
        or budget.get("authorized_cumulative_ceiling")
        != _V8_TO_V11_AUTHORIZED_CUMULATIVE_CEILING
        or _provider_identity_without_cohort(
            preregistration.get("provider_config")
        )
        != _provider_identity_without_cohort(config.public_dict())
        or predict_run.get("predict_run_sha256")
        != _V10_REJECTED_PREDICT_RUN_SHA256
        or predict_run.get("preregistration_sha256")
        != _V10_REJECTED_PREREGISTRATION_SHA256
        or predict_run.get("logical_completion_budget_used") != 1
        or predict_run.get("max_logical_completions") != 1
        or predict_run.get("logical_completion_ledger_file_sha256")
        != _V10_REJECTED_LEDGER_FILE_SHA256
        or predict_run.get("logical_completion_ledger_sha256")
        != _V10_REJECTED_LEDGER_SHA256
        or ledger.get("ledger_sha256") != _V10_REJECTED_LEDGER_SHA256
        or ledger.get("preregistration_sha256")
        != _V10_REJECTED_PREREGISTRATION_SHA256
        or ledger.get("cumulative_logical_completions_before") != 336
        or ledger.get("maximum_new_logical_completions") != 1
        or ledger.get("hard_cumulative_stop") != 337
        or ledger.get("entries") != expected_ledger_entries
        or promotion.get("schema_version") != _V10_PROMOTION_SCHEMA_VERSION
        or promotion.get("promotion_sha256")
        != _V10_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or promotion.get("preregistration_path")
        != str(paths["preregistration"])
        or promotion.get("preregistration_sha256")
        != _V10_REJECTED_PREREGISTRATION_SHA256
        or promotion.get("predict_run_path") != str(paths["predict_run"])
        or promotion.get("predict_run_file_sha256")
        != _V10_REJECTED_PREDICT_RUN_FILE_SHA256
        or not isinstance(checks, Mapping)
        or checks.get("runtime_budget_exactly_preregistered") is not True
        or checks.get("dry_reuses_only_verified_scout_seed") is not True
        or checks.get("step_exact_minimum_correct") is not False
        or not isinstance(summary, Mapping)
        or summary.get("trajectory_count") != 3
        or summary.get("step_correct") != 0
        or summary.get("step_denominator") != 3
        or summary.get("step_module_correct") != 0
        or summary.get("all_correct") != 0
        or summary.get("failed_prediction_count") != 1
        or summary.get("logical_completion_budget_used") != 1
    ):
        raise BatchedCausalPreregistrationError(
            "E9 rejected v10 run is not a valid usage-only anchor"
        )
    anchor: dict[str, Any] = {
        "role": "usage_only_rejected_not_semantic_predecessor",
        "cumulative_before": 336,
        "logical_completions_used": 1,
        "cumulative_after": 337,
        "previous_usage_anchor": previous_usage_anchor,
        "claim": {
            "path": str(paths["claim"]),
            "file_sha256": _V10_REJECTED_CLAIM_FILE_SHA256,
            "content_sha256": _V10_REJECTED_CLAIM_SHA256,
        },
        "preregistration": {
            "path": str(paths["preregistration"]),
            "file_sha256": _V10_REJECTED_PREREGISTRATION_FILE_SHA256,
            "content_sha256": _V10_REJECTED_PREREGISTRATION_SHA256,
        },
        "predict_run": {
            "path": str(paths["predict_run"]),
            "file_sha256": _V10_REJECTED_PREDICT_RUN_FILE_SHA256,
            "content_sha256": _V10_REJECTED_PREDICT_RUN_SHA256,
        },
        "logical_completion_ledger": {
            "path": str(paths["ledger"]),
            "file_sha256": _V10_REJECTED_LEDGER_FILE_SHA256,
            "content_sha256": _V10_REJECTED_LEDGER_SHA256,
            "entries": expected_ledger_entries,
        },
        "rejected_promotion": {
            "path": str(paths["promotion"]),
            "file_sha256": _V10_REJECTED_PROMOTION_FILE_SHA256,
            "content_sha256": _V10_REJECTED_PROMOTION_SHA256,
            "accepted": False,
        },
    }
    anchor["usage_anchor_sha256"] = stable_sha256(anchor)
    return anchor


def _resolve_v11_rejected_usage_anchor(
    *,
    config: BenchmarkRunConfig,
) -> dict[str, Any]:
    """Bind rejected v11 only as proof that cumulative usage reached 338."""

    previous_usage_anchor = _resolve_v10_rejected_usage_anchor(config=config)
    root = _repository_path(_V11_REJECTED_DRY_RELATIVE_ROOT)
    paths = {
        "claim": _repository_path(_V11_REJECTED_CLAIM_RELATIVE_PATH),
        "preregistration": root / "preregistration.json",
        "predict_run": root / "predict-run.json",
        "ledger": root / "logical-completion-ledger.json",
        "promotion": root / "promotion.json",
    }
    expected_files = {
        "claim": _V11_REJECTED_CLAIM_FILE_SHA256,
        "preregistration": _V11_REJECTED_PREREGISTRATION_FILE_SHA256,
        "predict_run": _V11_REJECTED_PREDICT_RUN_FILE_SHA256,
        "ledger": _V11_REJECTED_LEDGER_FILE_SHA256,
        "promotion": _V11_REJECTED_PROMOTION_FILE_SHA256,
    }
    if any(
        not path.is_file()
        or _file_sha256(path) != expected_files[name]
        for name, path in paths.items()
    ):
        raise BatchedCausalPreregistrationError(
            "E9 rejected v11 usage-anchor bytes changed"
        )
    claim = _validated_hashed_document(
        paths["claim"],
        location="E9 rejected v11 claim",
        hash_field="claim_sha256",
    )
    preregistration = _validated_hashed_document(
        paths["preregistration"],
        location="E9 rejected v11 preregistration",
        hash_field="preregistration_sha256",
    )
    predict_run = _validated_hashed_document(
        paths["predict_run"],
        location="E9 rejected v11 predict run",
        hash_field="predict_run_sha256",
    )
    ledger = _validated_hashed_document(
        paths["ledger"],
        location="E9 rejected v11 ledger",
        hash_field="ledger_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion"],
        location="E9 rejected v11 promotion",
        hash_field="promotion_sha256",
    )
    budget = preregistration.get("logical_completion_budget")
    scout_seed = preregistration.get("scout_seed")
    validated_seed = (
        scout_seed.get("validated_binding")
        if isinstance(scout_seed, Mapping)
        else None
    )
    checks = promotion.get("checks")
    summary = promotion.get("summary")
    expected_ledger_entries = [
        {
            "ordinal": 1,
            "stage": BATCHED_ARBITER_STAGE,
            "request_sha256": _V11_REJECTED_ARBITER_REQUEST_SHA256,
        }
    ]
    if (
        claim.get("claim_sha256") != _V11_REJECTED_CLAIM_SHA256
        or claim.get("profile") != "dry3"
        or claim.get("preregistration_path")
        != str(paths["preregistration"])
        or claim.get("preregistration_sha256")
        != _V11_REJECTED_PREREGISTRATION_SHA256
        or claim.get("cumulative_before") != 337
        or claim.get("maximum_new") != 1
        or claim.get("hard_cumulative_stop") != 338
        or claim.get("predecessor_claim_sha256") is not None
        or claim.get("predecessor_promotion_sha256") is not None
        or preregistration.get("schema_version")
        != _V11_PREREGISTRATION_SCHEMA_VERSION
        or preregistration.get("preregistration_sha256")
        != _V11_REJECTED_PREREGISTRATION_SHA256
        or preregistration.get("predecessor") is not None
        or preregistration.get("prior_usage_anchor")
        != previous_usage_anchor
        or not isinstance(validated_seed, Mapping)
        or validated_seed.get("request_sha256")
        != _V11_REJECTED_SCOUT_REQUEST_SHA256
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 337
        or budget.get("maximum_new") != 1
        or budget.get("hard_cumulative_stop") != 338
        or budget.get("authorized_cumulative_ceiling")
        != _V8_TO_V11_AUTHORIZED_CUMULATIVE_CEILING
        or _provider_identity_without_cohort(
            preregistration.get("provider_config")
        )
        != _provider_identity_without_cohort(config.public_dict())
        or predict_run.get("predict_run_sha256")
        != _V11_REJECTED_PREDICT_RUN_SHA256
        or predict_run.get("preregistration_sha256")
        != _V11_REJECTED_PREREGISTRATION_SHA256
        or predict_run.get("logical_completion_budget_used") != 1
        or predict_run.get("max_logical_completions") != 1
        or predict_run.get("logical_completion_ledger_file_sha256")
        != _V11_REJECTED_LEDGER_FILE_SHA256
        or predict_run.get("logical_completion_ledger_sha256")
        != _V11_REJECTED_LEDGER_SHA256
        or ledger.get("ledger_sha256") != _V11_REJECTED_LEDGER_SHA256
        or ledger.get("preregistration_sha256")
        != _V11_REJECTED_PREREGISTRATION_SHA256
        or ledger.get("cumulative_logical_completions_before") != 337
        or ledger.get("maximum_new_logical_completions") != 1
        or ledger.get("hard_cumulative_stop") != 338
        or ledger.get("entries") != expected_ledger_entries
        or promotion.get("schema_version") != _V11_PROMOTION_SCHEMA_VERSION
        or promotion.get("promotion_sha256")
        != _V11_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or promotion.get("preregistration_path")
        != str(paths["preregistration"])
        or promotion.get("preregistration_sha256")
        != _V11_REJECTED_PREREGISTRATION_SHA256
        or promotion.get("predict_run_path") != str(paths["predict_run"])
        or promotion.get("predict_run_file_sha256")
        != _V11_REJECTED_PREDICT_RUN_FILE_SHA256
        or not isinstance(checks, Mapping)
        or checks.get("runtime_budget_exactly_preregistered") is not True
        or checks.get("dry_reuses_only_verified_scout_seed") is not True
        or checks.get("step_exact_minimum_correct") is not False
        or not isinstance(summary, Mapping)
        or summary.get("trajectory_count") != 3
        or summary.get("step_correct") != 0
        or summary.get("step_denominator") != 3
        or summary.get("step_module_correct") != 0
        or summary.get("all_correct") != 0
        or summary.get("failed_prediction_count") != 2
        or summary.get("logical_completion_budget_used") != 1
    ):
        raise BatchedCausalPreregistrationError(
            "E9 rejected v11 run is not a valid usage-only anchor"
        )
    anchor: dict[str, Any] = {
        "role": "usage_only_rejected_not_semantic_predecessor",
        "cumulative_before": 337,
        "logical_completions_used": 1,
        "cumulative_after": 338,
        "previous_usage_anchor": previous_usage_anchor,
        "claim": {
            "path": str(paths["claim"]),
            "file_sha256": _V11_REJECTED_CLAIM_FILE_SHA256,
            "content_sha256": _V11_REJECTED_CLAIM_SHA256,
        },
        "preregistration": {
            "path": str(paths["preregistration"]),
            "file_sha256": _V11_REJECTED_PREREGISTRATION_FILE_SHA256,
            "content_sha256": _V11_REJECTED_PREREGISTRATION_SHA256,
        },
        "predict_run": {
            "path": str(paths["predict_run"]),
            "file_sha256": _V11_REJECTED_PREDICT_RUN_FILE_SHA256,
            "content_sha256": _V11_REJECTED_PREDICT_RUN_SHA256,
        },
        "logical_completion_ledger": {
            "path": str(paths["ledger"]),
            "file_sha256": _V11_REJECTED_LEDGER_FILE_SHA256,
            "content_sha256": _V11_REJECTED_LEDGER_SHA256,
            "entries": expected_ledger_entries,
        },
        "rejected_promotion": {
            "path": str(paths["promotion"]),
            "file_sha256": _V11_REJECTED_PROMOTION_FILE_SHA256,
            "content_sha256": _V11_REJECTED_PROMOTION_SHA256,
            "accepted": False,
        },
    }
    anchor["usage_anchor_sha256"] = stable_sha256(anchor)
    return anchor


def _resolve_v12_rejected_usage_anchor(
    *,
    config: BenchmarkRunConfig,
) -> dict[str, Any]:
    """Bind rejected v12 only as proof that cumulative usage reached 340."""

    previous_usage_anchor = _resolve_v11_rejected_usage_anchor(config=config)
    root = _repository_path(_V12_REJECTED_DRY_RELATIVE_ROOT)
    paths = {
        "claim": _repository_path(_V12_REJECTED_CLAIM_RELATIVE_PATH),
        "preregistration": root / "preregistration.json",
        "predict_run": root / "predict-run.json",
        "ledger": root / "logical-completion-ledger.json",
        "promotion": root / "promotion.json",
    }
    expected_files = {
        "claim": _V12_REJECTED_CLAIM_FILE_SHA256,
        "preregistration": _V12_REJECTED_PREREGISTRATION_FILE_SHA256,
        "predict_run": _V12_REJECTED_PREDICT_RUN_FILE_SHA256,
        "ledger": _V12_REJECTED_LEDGER_FILE_SHA256,
        "promotion": _V12_REJECTED_PROMOTION_FILE_SHA256,
    }
    if any(
        not path.is_file()
        or _file_sha256(path) != expected_files[name]
        for name, path in paths.items()
    ):
        raise BatchedCausalPreregistrationError(
            "E9 rejected v12 usage-anchor bytes changed"
        )
    claim = _validated_hashed_document(
        paths["claim"],
        location="E9 rejected v12 claim",
        hash_field="claim_sha256",
    )
    preregistration = _validated_hashed_document(
        paths["preregistration"],
        location="E9 rejected v12 preregistration",
        hash_field="preregistration_sha256",
    )
    predict_run = _validated_hashed_document(
        paths["predict_run"],
        location="E9 rejected v12 predict run",
        hash_field="predict_run_sha256",
    )
    ledger = _validated_hashed_document(
        paths["ledger"],
        location="E9 rejected v12 ledger",
        hash_field="ledger_sha256",
    )
    promotion = _validated_hashed_document(
        paths["promotion"],
        location="E9 rejected v12 promotion",
        hash_field="promotion_sha256",
    )
    budget = preregistration.get("logical_completion_budget")
    checks = promotion.get("checks")
    summary = promotion.get("summary")
    expected_ledger_entries = [
        {
            "ordinal": 1,
            "stage": BATCHED_SCOUT_STAGE,
            "request_sha256": _V12_REJECTED_SCOUT_REQUEST_SHA256,
        },
        {
            "ordinal": 2,
            "stage": BATCHED_ARBITER_STAGE,
            "request_sha256": _V12_REJECTED_ARBITER_REQUEST_SHA256,
        },
    ]
    if (
        claim.get("schema_version")
        != E9_AUTHORIZATION_CLAIM_SCHEMA_VERSION
        or claim.get("claim_sha256") != _V12_REJECTED_CLAIM_SHA256
        or claim.get("profile") != "dry3"
        or claim.get("preregistration_path")
        != str(paths["preregistration"])
        or claim.get("preregistration_sha256")
        != _V12_REJECTED_PREREGISTRATION_SHA256
        or claim.get("cumulative_before") != 338
        or claim.get("maximum_new") != 2
        or claim.get("hard_cumulative_stop") != 340
        or claim.get("authorized_cumulative_ceiling")
        != _V12_AUTHORIZED_CUMULATIVE_CEILING
        or claim.get("predecessor_claim_sha256") is not None
        or claim.get("predecessor_promotion_sha256") is not None
        or preregistration.get("schema_version")
        != _V12_PREREGISTRATION_SCHEMA_VERSION
        or preregistration.get("preregistration_sha256")
        != _V12_REJECTED_PREREGISTRATION_SHA256
        or preregistration.get("predecessor") is not None
        or preregistration.get("prior_usage_anchor")
        != previous_usage_anchor
        or preregistration.get("scout_seed") is not None
        or not isinstance(budget, Mapping)
        or budget.get("cumulative_before") != 338
        or budget.get("maximum_new") != 2
        or budget.get("hard_cumulative_stop") != 340
        or budget.get("authorized_cumulative_ceiling")
        != _V12_AUTHORIZED_CUMULATIVE_CEILING
        or _provider_identity_without_cohort(
            preregistration.get("provider_config")
        )
        != _provider_identity_without_cohort(config.public_dict())
        or predict_run.get("predict_run_sha256")
        != _V12_REJECTED_PREDICT_RUN_SHA256
        or predict_run.get("preregistration_sha256")
        != _V12_REJECTED_PREREGISTRATION_SHA256
        or predict_run.get("logical_completion_budget_used") != 2
        or predict_run.get("max_logical_completions") != 2
        or predict_run.get("logical_completion_ledger_file_sha256")
        != _V12_REJECTED_LEDGER_FILE_SHA256
        or predict_run.get("logical_completion_ledger_sha256")
        != _V12_REJECTED_LEDGER_SHA256
        or ledger.get("ledger_sha256") != _V12_REJECTED_LEDGER_SHA256
        or ledger.get("preregistration_sha256")
        != _V12_REJECTED_PREREGISTRATION_SHA256
        or ledger.get("cumulative_logical_completions_before") != 338
        or ledger.get("maximum_new_logical_completions") != 2
        or ledger.get("hard_cumulative_stop") != 340
        or ledger.get("authorized_cumulative_ceiling")
        != _V12_AUTHORIZED_CUMULATIVE_CEILING
        or ledger.get("entries") != expected_ledger_entries
        or promotion.get("schema_version") != _V12_PROMOTION_SCHEMA_VERSION
        or promotion.get("promotion_sha256")
        != _V12_REJECTED_PROMOTION_SHA256
        or promotion.get("accepted") is not False
        or promotion.get("preregistration_path")
        != str(paths["preregistration"])
        or promotion.get("preregistration_sha256")
        != _V12_REJECTED_PREREGISTRATION_SHA256
        or promotion.get("predict_run_path") != str(paths["predict_run"])
        or promotion.get("predict_run_file_sha256")
        != _V12_REJECTED_PREDICT_RUN_FILE_SHA256
        or not isinstance(checks, Mapping)
        or checks.get("runtime_budget_exactly_preregistered") is not True
        or checks.get("dry_all_stages_cache_miss") is not True
        or checks.get("step_exact_minimum_correct") is not False
        or not isinstance(summary, Mapping)
        or summary.get("trajectory_count") != 3
        or summary.get("step_correct") != 1
        or summary.get("step_denominator") != 3
        or summary.get("logical_completion_budget_used") != 2
    ):
        raise BatchedCausalPreregistrationError(
            "E9 rejected v12 run is not a valid usage-only anchor"
        )
    anchor: dict[str, Any] = {
        "role": "usage_only_rejected_not_semantic_predecessor",
        "cumulative_before": 338,
        "logical_completions_used": 2,
        "cumulative_after": 340,
        "previous_usage_anchor": previous_usage_anchor,
        "claim": {
            "path": str(paths["claim"]),
            "file_sha256": _V12_REJECTED_CLAIM_FILE_SHA256,
            "content_sha256": _V12_REJECTED_CLAIM_SHA256,
        },
        "preregistration": {
            "path": str(paths["preregistration"]),
            "file_sha256": _V12_REJECTED_PREREGISTRATION_FILE_SHA256,
            "content_sha256": _V12_REJECTED_PREREGISTRATION_SHA256,
        },
        "predict_run": {
            "path": str(paths["predict_run"]),
            "file_sha256": _V12_REJECTED_PREDICT_RUN_FILE_SHA256,
            "content_sha256": _V12_REJECTED_PREDICT_RUN_SHA256,
        },
        "logical_completion_ledger": {
            "path": str(paths["ledger"]),
            "file_sha256": _V12_REJECTED_LEDGER_FILE_SHA256,
            "content_sha256": _V12_REJECTED_LEDGER_SHA256,
            "entries": expected_ledger_entries,
        },
        "rejected_promotion": {
            "path": str(paths["promotion"]),
            "file_sha256": _V12_REJECTED_PROMOTION_FILE_SHA256,
            "content_sha256": _V12_REJECTED_PROMOTION_SHA256,
            "accepted": False,
        },
    }
    anchor["usage_anchor_sha256"] = stable_sha256(anchor)
    return anchor


def _resolve_prior_usage_anchor(
    *,
    profile: str,
    cumulative_before: int,
    config: BenchmarkRunConfig,
) -> dict[str, Any] | None:
    """Bind rejected history only as v13 dry cumulative-usage proof."""

    if profile != "dry3":
        return None
    if cumulative_before != E9_CUMULATIVE_LOGICAL_COMPLETIONS_BEFORE:
        raise BatchedCausalPreregistrationError(
            "E9 v13 dry usage anchor starts at the wrong cumulative count"
        )
    return _resolve_v12_rejected_usage_anchor(config=config)


def _profile_contract(profile: str) -> dict[str, Any]:
    contract = E9_EVALUATION_PROFILES.get(profile)
    if not isinstance(contract, Mapping):
        raise BatchedCausalPreregistrationError(
            "E9 evaluation profile is unsupported"
        )
    return dict(contract)


def frozen_batched_causal_promotion_gate(
    profile: str,
    *,
    selected_trajectory_ids: Sequence[str],
) -> dict[str, Any]:
    """Return the sole authorized metric/integrity gate for an E9 phase."""

    selected = [str(value) for value in selected_trajectory_ids]
    common = {
        "semantic_mutation_maximum": 0,
        "llm_arbiter_raw_root_required": True,
        "raw_chain_reconstruction_required": True,
        "gold_isolation_required": True,
    }
    if profile == "dry3":
        if tuple(selected) != E9_DRY3_IDS_MANIFEST_ORDER:
            raise BatchedCausalPreregistrationError(
                "dry3 gate requires the frozen three tuning IDs"
            )
        return {
            "trajectory_denominator": 3,
            "successful_prediction_minimum": 3,
            "failed_prediction_maximum": 0,
            "step_exact_minimum_correct": 2,
            "step_module_exact_minimum_correct": 1,
            "all_correct_minimum": 1,
            "heldout_one_shot_required": False,
            **common,
        }
    if profile not in {"full30", "smoke30"} or len(selected) != 30:
        raise BatchedCausalPreregistrationError(
            "formal E9 full/smoke gate requires exactly 30 trajectories"
        )
    return {
        "trajectory_denominator": 30,
        "successful_prediction_minimum": 29,
        "failed_prediction_maximum": 1,
        "step_exact_minimum_correct": 12,
        "step_module_exact_minimum_correct": 3,
        "all_correct_minimum": 3,
        "heldout_one_shot_required": profile == "smoke30",
        **common,
    }


def _validate_formal_provider_config(
    *,
    profile: str,
    config: BenchmarkRunConfig,
) -> None:
    if profile not in _FORMAL_PROFILES:
        return
    expected = {
        "model": "gpt-4.1",
        "temperature": 0,
        "provider": "openai-compatible",
        "endpoint": "https://api.sophnet.com/v1/chat/completions",
        "timeout": 600,
        "max_output_tokens": 8192,
        "max_retries": 5,
        "retry_backoff": 2,
        "cohort_sha256": _profile_contract(profile)["cohort_sha256"],
        "api_key_env": "API_KEY",
    }
    if config.public_dict() != expected:
        raise BatchedCausalPreregistrationError(
            "formal E9 provider configuration is not the frozen GPT-4.1 "
            "identity"
        )


def _load_gold_free_cohort_header(path: Path) -> dict[str, Any]:
    """Validate the cohort's public identity without opening benchmark gold."""

    document = _read(path, location="E9 cohort manifest")
    body = dict(document)
    claimed = body.pop("cohort_sha256", None)
    trajectory_ids = document.get("trajectory_ids")
    if (
        claimed != stable_sha256(body)
        or not isinstance(trajectory_ids, list)
        or not trajectory_ids
        or any(not isinstance(value, str) or not value for value in trajectory_ids)
        or len(set(trajectory_ids)) != len(trajectory_ids)
        or not isinstance(document.get("cohort_name"), str)
        or not isinstance(document.get("dataset_manifest_sha256"), str)
    ):
        raise BatchedCausalPreregistrationError(
            "E9 cohort manifest public identity is invalid"
        )
    return document


def _validate_profile_binding(
    *,
    profile: str,
    cohort: Mapping[str, Any],
    manifest: Mapping[str, Any],
    manifest_ids: Sequence[str],
    selected_ids: Sequence[str],
    gate: Mapping[str, Any],
) -> dict[str, Any]:
    contract = _profile_contract(profile)
    selected = [str(value) for value in selected_ids]
    ids = [str(value) for value in manifest_ids]
    frozen_gate = frozen_batched_causal_promotion_gate(
        profile,
        selected_trajectory_ids=selected,
    )
    if (
        cohort.get("cohort_name") != contract["cohort_name"]
        or cohort.get("cohort_sha256") != contract["cohort_sha256"]
        or len(cohort.get("trajectory_ids", [])) != contract["cohort_count"]
        or list(cohort.get("trajectory_ids", [])) != ids
        or manifest.get("cohort_name") != contract["cohort_name"]
        or manifest.get("cohort_sha256") != contract["cohort_sha256"]
        or manifest.get("dataset_manifest_sha256")
        != cohort.get("dataset_manifest_sha256")
        or len(selected) != contract["selection_count"]
        or dict(gate) != frozen_gate
    ):
        raise BatchedCausalPreregistrationError(
            "E9 evaluation profile/cohort/manifest/gate binding is invalid"
        )
    if contract["full_cohort"]:
        if selected != ids:
            raise BatchedCausalPreregistrationError(
                "E9 full profile requires the complete cohort in manifest order"
            )
    elif selected != list(contract["selection_ids"] or ()):
        raise BatchedCausalPreregistrationError(
            "E9 dry profile requires the frozen three cases"
        )
    return contract


def _current_code_bundle() -> dict[str, str]:
    root = Path(__file__).resolve().parents[2]
    bundle: dict[str, str] = {}
    for relative in _CODE_PATHS:
        path = root / relative
        if not path.is_file():
            raise BatchedCausalPreregistrationError(
                f"E9 code bundle file is missing: {relative}"
            )
        bundle[relative] = _file_sha256(path)
    return bundle


def _phase_identity(profile: str) -> tuple[int, str | None]:
    values = {
        "dry3": (1, None),
        "full30": (2, "dry3"),
        "smoke30": (3, "full30"),
    }
    return values.get(profile, (1, None))


def _authorization_directory(
    *,
    profile: str,
    requested: str | Path | None,
    run_output_dir: Path,
) -> Path:
    root = Path(__file__).resolve().parents[2]
    formal = (root / E9_AUTHORIZATION_CHAIN_RELATIVE_PATH).resolve()
    if profile in _FORMAL_PROFILES:
        resolved = (
            formal
            if requested is None
            else Path(requested).expanduser().resolve()
        )
        if resolved != formal:
            raise BatchedCausalPreregistrationError(
                "formal E9 runs require the fixed authorization chain"
            )
        return resolved
    return (
        (run_output_dir.parent / ".e9-test-authorization-chain").resolve()
        if requested is None
        else Path(requested).expanduser().resolve()
    )


def _claim_path(directory: Path, *, profile: str) -> Path:
    return directory / f"{_phase_identity(profile)[0]:02d}-{profile}.json"


def _ledger_lock_path(path: Path) -> Path:
    return path.with_suffix(f"{path.suffix}.lock")


def _batch_plan_loader(path: Path) -> tuple[dict[str, Any], Sequence[Any]]:
    loader = getattr(_workflow(), "load_batched_causal_batch_plan", None)
    if not callable(loader):
        raise BatchedCausalPreregistrationError(
            "E9 workflow lacks load_batched_causal_batch_plan"
        )
    try:
        value = loader(path)
    except (OSError, TypeError, ValueError) as error:
        raise BatchedCausalPreregistrationError(
            "E9 batch plan is invalid"
        ) from error
    if isinstance(value, tuple) and len(value) == 2:
        document, batches = value
    else:
        serializer = getattr(value, "to_dict", None)
        document = serializer() if callable(serializer) else None
        batches = getattr(value, "batches", None)
    if not isinstance(document, dict) or not isinstance(batches, Sequence):
        raise BatchedCausalPreregistrationError(
            "E9 batch plan loader returned an invalid result"
        )
    return document, batches


def _batch_trajectory_ids(batch: Any) -> tuple[str, ...]:
    for attribute in ("trajectory_ids", "case_trajectory_ids"):
        values = getattr(batch, attribute, None)
        if isinstance(values, (list, tuple)) and all(
            isinstance(value, str) and value for value in values
        ):
            return tuple(values)
    if isinstance(batch, Mapping):
        for key in ("trajectory_ids", "case_trajectory_ids"):
            values = batch.get(key)
            if isinstance(values, list) and all(
                isinstance(value, str) and value for value in values
            ):
                return tuple(values)
    raise BatchedCausalPreregistrationError(
        "E9 batch plan lacks trajectory membership"
    )


def _batch_identity(batch: Any) -> str:
    for attribute in ("batch_sha256", "batch_input_sha256", "batch_id"):
        value = getattr(batch, attribute, None)
        if isinstance(value, str) and value:
            return value
    if isinstance(batch, Mapping):
        for key in ("batch_sha256", "batch_input_sha256", "batch_id"):
            value = batch.get(key)
            if isinstance(value, str) and value:
                return value
    return stable_sha256({"trajectory_ids": list(_batch_trajectory_ids(batch))})


def _validate_batch_plan_binding(
    *,
    plan: Mapping[str, Any],
    batches: Sequence[Any],
    selected_ids: Sequence[str],
) -> dict[str, Any]:
    if not batches:
        raise BatchedCausalPreregistrationError("E9 batch plan is empty")
    memberships = [_batch_trajectory_ids(batch) for batch in batches]
    flattened = [value for batch in memberships for value in batch]
    selected = [str(value) for value in selected_ids]
    required_prefix = plan.get("required_prefix_batch_plan_sha256")
    if (
        plan.get("selected_trajectory_ids") != selected
        or len(flattened) != len(selected)
        or len(set(flattened)) != len(flattened)
        or set(flattened) != set(selected)
        or (
            required_prefix is None
            and flattened != selected
        )
        or (
            required_prefix is not None
            and (
                not isinstance(required_prefix, str)
                or len(required_prefix) != 64
            )
        )
        or any(not 1 <= len(batch) <= 3 for batch in memberships)
        or len({_batch_identity(batch) for batch in batches}) != len(batches)
    ):
        raise BatchedCausalPreregistrationError(
            "E9 batch plan does not partition the selected cases exactly"
        )
    content_hash = plan.get("batch_plan_sha256")
    body = dict(plan)
    body.pop("batch_plan_sha256", None)
    if content_hash != stable_sha256(body):
        raise BatchedCausalPreregistrationError(
            "E9 batch plan self-hash is invalid"
        )
    return {
        "batch_count": len(batches),
        "batch_identities": [_batch_identity(batch) for batch in batches],
        "batch_memberships": [list(batch) for batch in memberships],
        "execution_trajectory_ids": flattened,
        "content_sha256": content_hash,
    }


def _workflow_contract() -> dict[str, Any]:
    workflow = _workflow()
    names = (
        "E9_EXPERIMENT",
        "E9_METHOD",
        "E9_PREDICTION_SCHEMA_VERSION",
        "E9_PREDICT_RUN_SCHEMA_VERSION",
        "E9_BATCH_PLAN_SCHEMA_VERSION",
        "E9_SEMANTIC_CLASSIFIER",
    )
    values = {name: getattr(workflow, name, None) for name in names}
    if any(not isinstance(value, str) or not value for value in values.values()):
        raise BatchedCausalPreregistrationError(
            "E9 workflow implementation contract is incomplete"
        )
    return values


def _validate_scout_seed_binding(
    *,
    profile: str,
    scout_seed_manifest_path: str | Path | None,
    prediction_manifest_path: Path,
    batch_plan_path: Path,
    cache_dir: Path,
    config: BenchmarkRunConfig,
    require_exact_cache: bool,
    frozen_binding: Mapping[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Reject every legacy Scout seed: v13 starts from a fresh cache."""

    del (
        profile,
        prediction_manifest_path,
        batch_plan_path,
        cache_dir,
        config,
        require_exact_cache,
    )
    if scout_seed_manifest_path is not None or frozen_binding is not None:
        raise BatchedCausalPreregistrationError(
            "E9 v13 forbids Scout seed manifests; dry must pay for a new "
            "Scout completion"
        )
    return None


def _expected_budget(profile: str, *, batch_count: int) -> tuple[int, int]:
    expected = {
        "dry3": (1, E9_CUMULATIVE_LOGICAL_COMPLETIONS_BEFORE, 2),
        "full30": (11, 342, 20),
        "smoke30": (11, 362, 22),
    }
    if profile not in expected:
        raise BatchedCausalPreregistrationError(
            "E9 formal budget profile is unsupported"
        )
    expected_batches, cumulative_before, maximum_new = expected[profile]
    if batch_count != expected_batches:
        raise BatchedCausalPreregistrationError(
            f"E9 {profile} requires exactly {expected_batches} frozen batches"
        )
    return cumulative_before, maximum_new


def _validate_phase_budget(
    *,
    profile: str,
    batch_count: int,
    cumulative_before: Any,
    maximum_new: Any,
    hard_cumulative_stop: Any,
    authorized_cumulative_ceiling: Any,
    predecessor_cumulative_after: int | None,
) -> None:
    if (
        isinstance(cumulative_before, bool)
        or not isinstance(cumulative_before, int)
        or cumulative_before < 0
        or isinstance(maximum_new, bool)
        or not isinstance(maximum_new, int)
        or maximum_new < 1
        or hard_cumulative_stop != cumulative_before + maximum_new
        or isinstance(authorized_cumulative_ceiling, bool)
        or not isinstance(authorized_cumulative_ceiling, int)
        or authorized_cumulative_ceiling < 0
        or authorized_cumulative_ceiling
        > E9_IMPLEMENTATION_CUMULATIVE_CEILING
        or hard_cumulative_stop > authorized_cumulative_ceiling
    ):
        raise BatchedCausalPreregistrationError(
            "E9 logical-completion budget arithmetic is invalid"
        )
    if profile in _FORMAL_PROFILES:
        expected_before, expected_maximum = _expected_budget(
            profile,
            batch_count=batch_count,
        )
        if (
            cumulative_before != expected_before
            or maximum_new != expected_maximum
            or (
                profile != "dry3"
                and predecessor_cumulative_after != expected_before
            )
            or (
                profile == "dry3"
                and predecessor_cumulative_after is not None
            )
        ):
            raise BatchedCausalPreregistrationError(
                "E9 profile-specific exact call budget is invalid"
            )


def _provider_identity_without_cohort(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, Mapping):
        return None
    identity = dict(value)
    identity.pop("cohort_sha256", None)
    return identity


def _read_claim(path: Path, *, expected_profile: str) -> dict[str, Any]:
    claim = _validated_hashed_document(
        path,
        location="E9 authorization claim",
        hash_field="claim_sha256",
    )
    required = {
        "schema_version",
        "ordinal",
        "profile",
        "preregistration_path",
        "preregistration_sha256",
        "cumulative_before",
        "maximum_new",
        "hard_cumulative_stop",
        "authorized_cumulative_ceiling",
        "predecessor_claim_sha256",
        "predecessor_promotion_sha256",
        "claim_sha256",
    }
    ordinal, _ = _phase_identity(expected_profile)
    if (
        set(claim) != required
        or claim.get("schema_version")
        != E9_AUTHORIZATION_CLAIM_SCHEMA_VERSION
        or claim.get("profile") != expected_profile
        or claim.get("ordinal") != ordinal
        or claim.get("hard_cumulative_stop")
        != claim.get("cumulative_before") + claim.get("maximum_new")
        or isinstance(claim.get("authorized_cumulative_ceiling"), bool)
        or not isinstance(claim.get("authorized_cumulative_ceiling"), int)
        or claim.get("hard_cumulative_stop")
        > claim.get("authorized_cumulative_ceiling")
        or claim.get("authorized_cumulative_ceiling")
        > E9_IMPLEMENTATION_CUMULATIVE_CEILING
    ):
        raise BatchedCausalPreregistrationError(
            "E9 authorization claim identity is invalid"
        )
    return claim


def _claim_for_preregistration(
    preregistration: Mapping[str, Any],
) -> dict[str, Any]:
    authorization = preregistration["authorization_chain"]
    predecessor = preregistration.get("predecessor")
    body: dict[str, Any] = {
        "schema_version": E9_AUTHORIZATION_CLAIM_SCHEMA_VERSION,
        "ordinal": authorization["ordinal"],
        "profile": preregistration["evaluation"]["profile"],
        "preregistration_path": preregistration["preregistration_path"],
        "preregistration_sha256": preregistration[
            "preregistration_sha256"
        ],
        "cumulative_before": preregistration[
            "logical_completion_budget"
        ]["cumulative_before"],
        "maximum_new": preregistration["logical_completion_budget"][
            "maximum_new"
        ],
        "hard_cumulative_stop": preregistration[
            "logical_completion_budget"
        ]["hard_cumulative_stop"],
        "authorized_cumulative_ceiling": preregistration[
            "logical_completion_budget"
        ]["authorized_cumulative_ceiling"],
        "predecessor_claim_sha256": authorization[
            "predecessor_claim_sha256"
        ],
        "predecessor_promotion_sha256": (
            None if predecessor is None else predecessor["promotion_sha256"]
        ),
    }
    body["claim_sha256"] = stable_sha256(body)
    return body


def _validate_claim(preregistration: Mapping[str, Any]) -> dict[str, Any]:
    authorization = preregistration.get("authorization_chain")
    if not isinstance(authorization, Mapping):
        raise BatchedCausalPreregistrationError(
            "E9 authorization-chain binding is missing"
        )
    claim = _read_claim(
        Path(str(authorization.get("claim_path"))).expanduser().resolve(),
        expected_profile=str(preregistration["evaluation"]["profile"]),
    )
    if claim != _claim_for_preregistration(preregistration):
        raise BatchedCausalPreregistrationError(
            "E9 authorization claim diverges from preregistration"
        )
    return claim


def _load_ledger(
    *,
    execution: Mapping[str, Any],
    budget: Mapping[str, Any],
    preregistration_sha256: str,
) -> dict[str, Any]:
    try:
        return load_fresh_semantic_completion_ledger(
            str(execution["logical_completion_ledger_path"]),
            preregistration_sha256=preregistration_sha256,
            cumulative_before=budget["cumulative_before"],
            maximum_new=budget["maximum_new"],
            authorized_cumulative_ceiling=budget[
                "authorized_cumulative_ceiling"
            ],
            allowed_stages=_STAGES,
        )
    except (FreshSemanticWorkflowError, KeyError, TypeError) as error:
        raise BatchedCausalPreregistrationError(
            "E9 logical-completion ledger is invalid"
        ) from error


def _resolve_predecessor_binding(
    *,
    profile: str,
    authorization_dir: Path,
    cumulative_before: int,
    code_bundle: Mapping[str, str],
    config: BenchmarkRunConfig,
    cache_dir: Path,
    current_prediction_manifest_path: Path,
    current_prediction_manifest: Mapping[str, Any],
    current_batch_plan: Mapping[str, Any],
    current_batches: Sequence[Any],
    require_predecessor_cache_state: bool = True,
) -> tuple[dict[str, Any] | None, str | None]:
    """Validate accepted lineage without opening labels before prediction."""

    _, predecessor_profile = _phase_identity(profile)
    if predecessor_profile is None:
        return None, None
    predecessor_claim_path = _claim_path(
        authorization_dir,
        profile=predecessor_profile,
    )
    claim = _read_claim(
        predecessor_claim_path,
        expected_profile=predecessor_profile,
    )
    preregistration_path = Path(
        str(claim["preregistration_path"])
    ).expanduser().resolve()
    preregistration = _validated_hashed_document(
        preregistration_path,
        location="E9 predecessor preregistration",
        hash_field="preregistration_sha256",
    )
    if _validate_claim(preregistration) != claim:
        raise BatchedCausalPreregistrationError(
            "E9 predecessor claim does not bind its preregistration"
        )
    execution = preregistration.get("execution")
    budget = preregistration.get("logical_completion_budget")
    evaluation = preregistration.get("evaluation")
    manifest_record = preregistration.get("prediction_manifest")
    plan_record = preregistration.get("batch_plan")
    if not all(
        isinstance(value, Mapping)
        for value in (
            execution,
            budget,
            evaluation,
            manifest_record,
            plan_record,
        )
    ):
        raise BatchedCausalPreregistrationError(
            "E9 predecessor preregistration envelope is invalid"
        )
    promotion_path = (
        Path(str(execution["run_output_dir"])).expanduser().resolve()
        / "promotion.json"
    )
    promotion = _validated_hashed_document(
        promotion_path,
        location="E9 predecessor promotion",
        hash_field="promotion_sha256",
    )
    predecessor_output_dir = Path(
        str(execution["run_output_dir"])
    ).expanduser().resolve()
    predict_run_path = Path(
        str(execution["predict_run_metadata_path"])
    ).expanduser().resolve()
    predict_run = _validated_hashed_document(
        predict_run_path,
        location="E9 predecessor predict run",
        hash_field="predict_run_sha256",
    )
    ledger = _load_ledger(
        execution=execution,
        budget=budget,
        preregistration_sha256=preregistration["preregistration_sha256"],
    )
    used = len(ledger["entries"])
    predecessor_plan_path = Path(
        str(plan_record["path"])
    ).expanduser().resolve()
    predecessor_plan, predecessor_batches = _batch_plan_loader(
        predecessor_plan_path
    )
    predecessor_plan_binding = _validate_batch_plan_binding(
        plan=predecessor_plan,
        batches=predecessor_batches,
        selected_ids=preregistration["selection"]["trajectory_ids"],
    )
    checks = promotion.get("checks")
    expected_cumulative = budget["cumulative_before"] + used
    if (
        preregistration.get("schema_version")
        != E9_PREREGISTRATION_SCHEMA_VERSION
        or evaluation.get("profile") != predecessor_profile
        or preregistration.get("code_bundle") != dict(code_bundle)
        or preregistration.get("code_bundle_sha256")
        != stable_sha256(dict(code_bundle))
        or _provider_identity_without_cohort(
            preregistration.get("provider_config")
        )
        != _provider_identity_without_cohort(config.public_dict())
        or promotion.get("schema_version") != E9_PROMOTION_SCHEMA_VERSION
        or promotion.get("accepted") is not True
        or not isinstance(checks, Mapping)
        or not checks
        or not all(value is True for value in checks.values())
        or promotion.get("preregistration_sha256")
        != preregistration.get("preregistration_sha256")
        or promotion.get("preregistration_path") != str(preregistration_path)
        or promotion.get("predictions_path")
        != str(predecessor_output_dir / "predictions.jsonl")
        or promotion.get("metrics_path")
        != str(predecessor_output_dir / "metrics.json")
        or promotion.get("predict_run_path") != str(predict_run_path)
        or promotion.get("predict_run_file_sha256")
        != _file_sha256(predict_run_path)
        or predict_run.get("preregistration_sha256")
        != preregistration.get("preregistration_sha256")
        or predict_run.get("logical_completion_budget_used") != used
        or predict_run.get("logical_completion_ledger_sha256")
        != ledger["ledger_sha256"]
        or used != budget.get("maximum_new")
        or not isinstance(promotion.get("cache_final_state"), Mapping)
        or promotion.get("summary", {}).get(
            "logical_completion_budget_used"
        )
        != used
        or cumulative_before != expected_cumulative
        or (
            require_predecessor_cache_state
            and promotion.get("cache_final_state")
            != _directory_state(execution["cache_dir"])
        )
        or plan_record.get("path") != str(predecessor_plan_path)
        or plan_record.get("file_sha256")
        != _file_sha256(predecessor_plan_path)
        or plan_record.get("content_sha256")
        != predecessor_plan_binding["content_sha256"]
    ):
        raise BatchedCausalPreregistrationError(
            "E9 predecessor promotion/ledger/code lineage is invalid"
        )
    if profile == "full30":
        current_binding = _validate_batch_plan_binding(
            plan=current_batch_plan,
            batches=current_batches,
            selected_ids=[
                case["trajectory_id"]
                for case in current_prediction_manifest["entries"]
            ],
        )
        if (
            manifest_record.get("path")
            != str(current_prediction_manifest_path)
            or manifest_record.get("file_sha256")
            != _file_sha256(current_prediction_manifest_path)
            or manifest_record.get("content_sha256")
            != current_prediction_manifest.get(
                "prediction_manifest_sha256"
            )
            or execution.get("cache_dir") != str(cache_dir)
            or predecessor_plan_binding["batch_memberships"][0]
            != current_binding["batch_memberships"][0]
            or predecessor_plan_binding["batch_identities"][0]
            != current_binding["batch_identities"][0]
        ):
            raise BatchedCausalPreregistrationError(
                "E9 full tuning does not exactly reuse the dry first batch/cache"
            )
    return (
        {
            "profile": predecessor_profile,
            "claim_path": str(predecessor_claim_path),
            "claim_sha256": claim["claim_sha256"],
            "preregistration_path": str(preregistration_path),
            "preregistration_sha256": preregistration[
                "preregistration_sha256"
            ],
            "promotion_path": str(promotion_path),
            "promotion_file_sha256": _file_sha256(promotion_path),
            "promotion_sha256": promotion["promotion_sha256"],
            "predict_run_path": str(predict_run_path),
            "predict_run_file_sha256": _file_sha256(predict_run_path),
            "logical_completion_ledger_path": str(
                execution["logical_completion_ledger_path"]
            ),
            "logical_completion_ledger_sha256": ledger["ledger_sha256"],
            "logical_completion_budget_used": used,
            "cumulative_after": expected_cumulative,
            "cache_final_state": promotion["cache_final_state"],
            "batch_plan_sha256": predecessor_plan_binding[
                "content_sha256"
            ],
            "first_batch_identity": predecessor_plan_binding[
                "batch_identities"
            ][0],
            "first_batch_membership": predecessor_plan_binding[
                "batch_memberships"
            ][0],
        },
        claim["claim_sha256"],
    )


def _validate_frozen_namespace(
    *,
    profile: str,
    run_output_initial_state: Any,
    cache_initial_state: Any,
    predecessor: Mapping[str, Any] | None,
    scout_seed: Mapping[str, Any] | None,
) -> None:
    if not isinstance(run_output_initial_state, Mapping) or not isinstance(
        cache_initial_state,
        Mapping,
    ):
        raise BatchedCausalPreregistrationError(
            "E9 frozen namespace state is invalid"
        )
    if (
        profile in _FORMAL_PROFILES
        and run_output_initial_state.get("file_count") != 0
    ):
        raise BatchedCausalPreregistrationError(
            "formal E9 output namespace was not fresh"
        )
    if profile == "dry3":
        if (
            scout_seed is not None
            or predecessor is not None
            or cache_initial_state.get("file_count") != 0
        ):
            raise BatchedCausalPreregistrationError(
                "E9 v13 dry requires a fresh empty cache and no predecessor"
            )
    if profile == "smoke30" and (
        scout_seed is not None
        or cache_initial_state.get("file_count") != 0
    ):
        raise BatchedCausalPreregistrationError(
            "E9 smoke cache namespace was not fresh"
        )
    if profile == "full30":
        if scout_seed is not None:
            raise BatchedCausalPreregistrationError(
                "E9 full run forbids a Scout seed manifest"
            )
        if (
            not isinstance(predecessor, Mapping)
            or cache_initial_state != predecessor.get("cache_final_state")
        ):
            raise BatchedCausalPreregistrationError(
                "E9 full cache is not the exact accepted dry cache snapshot"
            )


def write_batched_causal_preregistration(
    *,
    experiment_name: str,
    evaluation_profile: str,
    dataset_path: str | Path,
    cohort_manifest_path: str | Path,
    prediction_manifest_path: str | Path,
    batch_plan_path: str | Path,
    output_path: str | Path,
    run_output_dir: str | Path,
    cache_dir: str | Path,
    config: BenchmarkRunConfig,
    selected_trajectory_ids: Sequence[str],
    selection_rule: str,
    hypothesis: str,
    promotion_gate: Mapping[str, Any],
    cumulative_logical_completions_before: int,
    maximum_new_logical_completions: int,
    authorized_cumulative_ceiling: int,
    authorization_chain_dir: str | Path | None = None,
    scout_seed_manifest_path: str | Path | None = None,
) -> dict[str, Any]:
    """Freeze the E9 formal identity before any provider completion."""

    for name, value in (
        ("experiment_name", experiment_name),
        ("selection_rule", selection_rule),
        ("hypothesis", hypothesis),
    ):
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"{name} must be non-empty text")
    selected = [str(value) for value in selected_trajectory_ids]
    if (
        not selected
        or any(not value for value in selected)
        or len(set(selected)) != len(selected)
    ):
        raise ValueError("selected trajectory IDs must be unique and non-empty")
    if not isinstance(promotion_gate, Mapping) or not promotion_gate:
        raise ValueError("E9 promotion gate must be a non-empty object")
    gate = dict(promotion_gate)
    unknown = sorted(set(gate) - _SUPPORTED_GATE_FIELDS)
    if unknown:
        raise ValueError(
            "E9 promotion gate contains unsupported fields: "
            + ", ".join(unknown)
        )
    if not isinstance(config, BenchmarkRunConfig) or not config.api_key_env:
        raise ValueError(
            "E9 preregistration requires a public BenchmarkRunConfig and "
            "API-key environment-variable name"
        )
    _validate_formal_provider_config(
        profile=evaluation_profile,
        config=config,
    )

    prediction_path = Path(prediction_manifest_path).expanduser().resolve()
    plan_path = Path(batch_plan_path).expanduser().resolve()
    dataset_resolved = Path(dataset_path).expanduser().resolve()
    cohort_resolved = Path(cohort_manifest_path).expanduser().resolve()
    destination = Path(output_path).expanduser().resolve()
    run_output_resolved = Path(run_output_dir).expanduser().resolve()
    cache_resolved = Path(cache_dir).expanduser().resolve()
    prediction, cases = load_prediction_manifest(prediction_path)
    cohort = _load_gold_free_cohort_header(cohort_resolved)
    plan, batches = _batch_plan_loader(plan_path)
    manifest_ids = [case.trajectory_id for case in cases]
    contract = _validate_profile_binding(
        profile=evaluation_profile,
        cohort=cohort,
        manifest=prediction,
        manifest_ids=manifest_ids,
        selected_ids=selected,
        gate=gate,
    )
    selected_set = set(selected)
    if selected != [value for value in manifest_ids if value in selected_set]:
        raise BatchedCausalPreregistrationError(
            "selected IDs must follow PredictionManifest order"
        )
    plan_binding = _validate_batch_plan_binding(
        plan=plan,
        batches=batches,
        selected_ids=selected,
    )
    if (
        config.cohort_sha256 != prediction["cohort_sha256"]
        or prediction["dataset_manifest_sha256"]
        != cohort["dataset_manifest_sha256"]
    ):
        raise BatchedCausalPreregistrationError(
            "E9 input/provider/cohort lineage is invalid"
        )
    expected_before, expected_maximum = _expected_budget(
        evaluation_profile,
        batch_count=plan_binding["batch_count"],
    )
    if (
        cumulative_logical_completions_before != expected_before
        or maximum_new_logical_completions != expected_maximum
    ):
        raise BatchedCausalPreregistrationError(
            "E9 requested budget differs from the exact frozen batch plan"
        )
    hard_stop = (
        cumulative_logical_completions_before
        + maximum_new_logical_completions
    )

    code_bundle = _current_code_bundle()
    workflow_contract = _workflow_contract()
    authorization_dir = _authorization_directory(
        profile=evaluation_profile,
        requested=authorization_chain_dir,
        run_output_dir=run_output_resolved,
    )
    claim_path = _claim_path(
        authorization_dir,
        profile=evaluation_profile,
    )
    predecessor, predecessor_claim_sha256 = _resolve_predecessor_binding(
        profile=evaluation_profile,
        authorization_dir=authorization_dir,
        cumulative_before=cumulative_logical_completions_before,
        code_bundle=code_bundle,
        config=config,
        cache_dir=cache_resolved,
        current_prediction_manifest_path=prediction_path,
        current_prediction_manifest=prediction,
        current_batch_plan=plan,
        current_batches=batches,
    )
    _validate_phase_budget(
        profile=evaluation_profile,
        batch_count=plan_binding["batch_count"],
        cumulative_before=cumulative_logical_completions_before,
        maximum_new=maximum_new_logical_completions,
        hard_cumulative_stop=hard_stop,
        authorized_cumulative_ceiling=authorized_cumulative_ceiling,
        predecessor_cumulative_after=(
            None if predecessor is None else predecessor["cumulative_after"]
        ),
    )
    prior_usage_anchor = _resolve_prior_usage_anchor(
        profile=evaluation_profile,
        cumulative_before=cumulative_logical_completions_before,
        config=config,
    )

    run_output_initial_state = _directory_state(
        run_output_resolved,
        excluded_paths=(destination,),
    )
    cache_initial_state = _directory_state(cache_resolved)
    scout_seed = _validate_scout_seed_binding(
        profile=evaluation_profile,
        scout_seed_manifest_path=scout_seed_manifest_path,
        prediction_manifest_path=prediction_path,
        batch_plan_path=plan_path,
        cache_dir=cache_resolved,
        config=config,
        require_exact_cache=True,
    )
    _validate_frozen_namespace(
        profile=evaluation_profile,
        run_output_initial_state=run_output_initial_state,
        cache_initial_state=cache_initial_state,
        predecessor=predecessor,
        scout_seed=scout_seed,
    )
    ledger_path = run_output_resolved / "logical-completion-ledger.json"
    ledger_lock_path = _ledger_lock_path(ledger_path)
    if (
        (ledger_path.is_file() or ledger_lock_path.is_file())
        and not destination.is_file()
    ):
        raise BatchedCausalPreregistrationError(
            "E9 logical-completion ledger path is not fresh"
        )
    document: dict[str, Any] = {
        "schema_version": E9_PREREGISTRATION_SCHEMA_VERSION,
        "preregistration_path": str(destination),
        "authorization_chain": {
            "directory": str(authorization_dir),
            "claim_path": str(claim_path),
            "ordinal": _phase_identity(evaluation_profile)[0],
            "predecessor_claim_sha256": predecessor_claim_sha256,
        },
        "predecessor": predecessor,
        "prior_usage_anchor": prior_usage_anchor,
        "scout_seed": scout_seed,
        "experiment_name": experiment_name.strip(),
        "hypothesis": hypothesis.strip(),
        "selection": {
            "rule": selection_rule.strip(),
            "trajectory_ids": selected,
            "count": len(selected),
        },
        "prediction_manifest": {
            "path": str(prediction_path),
            "file_sha256": _file_sha256(prediction_path),
            "content_sha256": prediction["prediction_manifest_sha256"],
            "dataset_manifest_sha256": prediction[
                "dataset_manifest_sha256"
            ],
            "cohort_name": prediction["cohort_name"],
            "cohort_sha256": prediction["cohort_sha256"],
            "entry_count": len(cases),
        },
        "batch_plan": {
            "path": str(plan_path),
            "file_sha256": _file_sha256(plan_path),
            **plan_binding,
        },
        "evaluation": {
            "profile": evaluation_profile,
            "heldout": bool(contract["heldout"]),
            "dataset_path": str(dataset_resolved),
            "dataset_manifest_sha256": prediction[
                "dataset_manifest_sha256"
            ],
            "cohort_manifest_path": str(cohort_resolved),
            "cohort_manifest_file_sha256": _file_sha256(cohort_resolved),
            "cohort_name": cohort["cohort_name"],
            "cohort_sha256": cohort["cohort_sha256"],
            "trajectory_count": len(manifest_ids),
        },
        "implementation": {
            "experiment": workflow_contract["E9_EXPERIMENT"],
            "method": workflow_contract["E9_METHOD"],
            "pipeline_version": BATCHED_CAUSAL_PIPELINE_VERSION,
            "scout_prompt_protocol_version": (
                BATCHED_SCOUT_PROMPT_PROTOCOL_VERSION
            ),
            "arbiter_prompt_protocol_version": (
                BATCHED_ARBITER_PROMPT_PROTOCOL_VERSION
            ),
            "judge_view_version": JUDGE_VIEW_VERSION,
            "transport_policy_version": TRANSPORT_POLICY_VERSION,
            "prediction_schema_version": workflow_contract[
                "E9_PREDICTION_SCHEMA_VERSION"
            ],
            "predict_run_schema_version": workflow_contract[
                "E9_PREDICT_RUN_SCHEMA_VERSION"
            ],
            "batch_plan_schema_version": workflow_contract[
                "E9_BATCH_PLAN_SCHEMA_VERSION"
            ],
            "stage_cache_schema_version": STAGE_CACHE_SCHEMA_VERSION,
            "raw_stage_schema_version": RAW_STAGE_SCHEMA_VERSION,
            "raw_response_sidecar_schema_version": (
                RAW_RESPONSE_SIDECAR_SCHEMA_VERSION
            ),
            "logical_completion_ledger_schema_version": (
                E8_LOGICAL_COMPLETION_LEDGER_SCHEMA_VERSION
            ),
            "semantic_classifier": workflow_contract[
                "E9_SEMANTIC_CLASSIFIER"
            ],
            "semantic_input": _V13_SEMANTIC_INPUT_IDENTITY,
            "deterministic_root_fallback": False,
            "deterministic_semantic_mutation": False,
            "confidence_score_weight_vote": False,
        },
        "provider_config": config.public_dict(),
        "execution": {
            "run_output_dir": str(run_output_resolved),
            "unscored_predictions_path": str(
                run_output_resolved / "unscored-predictions.jsonl"
            ),
            "predict_run_metadata_path": str(
                run_output_resolved / "predict-run.json"
            ),
            "scored_output_dir": str(run_output_resolved),
            "run_output_initial_state": run_output_initial_state,
            "cache_dir": str(cache_resolved),
            "cache_initial_state": cache_initial_state,
            "logical_completion_ledger_path": str(ledger_path),
            "logical_completion_ledger_lock_path": str(ledger_lock_path),
            "workers": 1,
            "retry_failures": False,
            "stages_per_batch": list(_STAGES),
            "logical_completions_per_uncached_batch": 2,
            "evidence_repair_enabled": False,
        },
        "logical_completion_budget": {
            "cumulative_before": cumulative_logical_completions_before,
            "maximum_new": maximum_new_logical_completions,
            "hard_cumulative_stop": hard_stop,
            "authorized_cumulative_ceiling": authorized_cumulative_ceiling,
            "http_transport_retries_are_not_logical_completions": True,
            "derived_from_frozen_batch_plan": True,
        },
        "promotion_gate": gate,
        "code_bundle_sha256": stable_sha256(code_bundle),
        "code_bundle": code_bundle,
    }
    document["preregistration_sha256"] = stable_sha256(document)
    if destination.is_file():
        existing = _read(destination, location="E9 preregistration")
        if existing != document:
            raise BatchedCausalPreregistrationError(
                "existing E9 preregistration conflicts with current identity"
            )
    elif claim_path.is_file():
        raise BatchedCausalPreregistrationError(
            "E9 authorization phase was already claimed"
        )
    else:
        _atomic_json(destination, document)
    claim = _claim_for_preregistration(document)
    if claim_path.is_file():
        if _read_claim(
            claim_path,
            expected_profile=evaluation_profile,
        ) != claim:
            raise BatchedCausalPreregistrationError(
                "existing E9 claim conflicts with preregistration"
            )
    else:
        _exclusive_json(claim_path, claim)
    initialize_fresh_semantic_completion_ledger(
        ledger_path,
        preregistration_sha256=document["preregistration_sha256"],
        cumulative_before=cumulative_logical_completions_before,
        maximum_new=maximum_new_logical_completions,
        authorized_cumulative_ceiling=authorized_cumulative_ceiling,
        allowed_stages=_STAGES,
    )
    return document


def verify_batched_causal_preregistration(
    *,
    preregistration_path: str | Path,
    prediction_manifest_path: str | Path,
    batch_plan_path: str | Path,
    run_output_dir: str | Path,
    cache_dir: str | Path,
    unscored_output_path: str | Path,
    predict_run_metadata_path: str | Path,
    config: BenchmarkRunConfig,
    selected_trajectory_ids: Sequence[str],
    maximum_new_logical_completions: int,
) -> dict[str, Any]:
    """Recompute the gold-free write-once identity immediately before calls."""

    path = Path(preregistration_path).expanduser().resolve()
    document = _validated_hashed_document(
        path,
        location="E9 preregistration",
        hash_field="preregistration_sha256",
    )
    if document.get("schema_version") != E9_PREREGISTRATION_SCHEMA_VERSION:
        raise BatchedCausalPreregistrationError(
            "E9 preregistration schema is invalid"
        )
    selection = document.get("selection")
    budget = document.get("logical_completion_budget")
    execution = document.get("execution")
    evaluation = document.get("evaluation")
    manifest_record = document.get("prediction_manifest")
    plan_record = document.get("batch_plan")
    implementation = document.get("implementation")
    stored_scout_seed = document.get("scout_seed")
    stored_prior_usage_anchor = document.get("prior_usage_anchor")
    if not all(
        isinstance(value, Mapping)
        for value in (
            selection,
            budget,
            execution,
            evaluation,
            manifest_record,
            plan_record,
            implementation,
        )
    ) or (
        stored_scout_seed is not None
        and not isinstance(stored_scout_seed, Mapping)
    ) or (
        stored_prior_usage_anchor is not None
        and not isinstance(stored_prior_usage_anchor, Mapping)
    ):
        raise BatchedCausalPreregistrationError(
            "E9 preregistration envelope is invalid"
        )
    selected = [str(value) for value in selected_trajectory_ids]
    prediction_path = Path(prediction_manifest_path).expanduser().resolve()
    plan_path = Path(batch_plan_path).expanduser().resolve()
    run_output_resolved = Path(run_output_dir).expanduser().resolve()
    cache_resolved = Path(cache_dir).expanduser().resolve()
    unscored_path = Path(unscored_output_path).expanduser().resolve()
    run_path = Path(predict_run_metadata_path).expanduser().resolve()
    prediction, cases = load_prediction_manifest(prediction_path)
    cohort_path = Path(
        str(evaluation.get("cohort_manifest_path"))
    ).expanduser().resolve()
    cohort = _load_gold_free_cohort_header(cohort_path)
    plan, batches = _batch_plan_loader(plan_path)
    plan_binding = _validate_batch_plan_binding(
        plan=plan,
        batches=batches,
        selected_ids=selected,
    )
    contract = _validate_profile_binding(
        profile=str(evaluation.get("profile")),
        cohort=cohort,
        manifest=prediction,
        manifest_ids=[case.trajectory_id for case in cases],
        selected_ids=selected,
        gate=document.get("promotion_gate", {}),
    )
    profile = str(evaluation["profile"])
    _validate_formal_provider_config(profile=profile, config=config)
    ledger_path = Path(
        str(execution.get("logical_completion_ledger_path"))
    ).expanduser().resolve()
    ledger_lock_path = _ledger_lock_path(ledger_path)
    if (
        selection.get("trajectory_ids") != selected
        or selection.get("count") != len(selected)
        or selection.get("count") != contract["selection_count"]
        or budget.get("maximum_new") != maximum_new_logical_completions
        or execution.get("unscored_predictions_path") != str(unscored_path)
        or execution.get("predict_run_metadata_path") != str(run_path)
        or ledger_path
        != run_output_resolved / "logical-completion-ledger.json"
        or execution.get("logical_completion_ledger_lock_path")
        != str(ledger_lock_path)
    ):
        raise BatchedCausalPreregistrationError(
            "runtime E9 selection/path/budget differs from preregistration"
        )
    ledger = _load_ledger(
        execution=execution,
        budget=budget,
        preregistration_sha256=document["preregistration_sha256"],
    )
    current_bundle = _current_code_bundle()
    authorization = document.get("authorization_chain")
    if not isinstance(authorization, Mapping):
        raise BatchedCausalPreregistrationError(
            "E9 authorization-chain envelope is invalid"
        )
    authorization_dir = _authorization_directory(
        profile=profile,
        requested=authorization.get("directory"),
        run_output_dir=run_output_resolved,
    )
    predecessor, predecessor_claim_sha256 = _resolve_predecessor_binding(
        profile=profile,
        authorization_dir=authorization_dir,
        cumulative_before=budget["cumulative_before"],
        code_bundle=current_bundle,
        config=config,
        cache_dir=cache_resolved,
        current_prediction_manifest_path=prediction_path,
        current_prediction_manifest=prediction,
        current_batch_plan=plan,
        current_batches=batches,
    )
    _validate_phase_budget(
        profile=profile,
        batch_count=plan_binding["batch_count"],
        cumulative_before=budget.get("cumulative_before"),
        maximum_new=budget.get("maximum_new"),
        hard_cumulative_stop=budget.get("hard_cumulative_stop"),
        authorized_cumulative_ceiling=budget.get(
            "authorized_cumulative_ceiling"
        ),
        predecessor_cumulative_after=(
            None if predecessor is None else predecessor["cumulative_after"]
        ),
    )
    prior_usage_anchor = _resolve_prior_usage_anchor(
        profile=profile,
        cumulative_before=budget["cumulative_before"],
        config=config,
    )
    scout_seed = _validate_scout_seed_binding(
        profile=profile,
        scout_seed_manifest_path=(
            stored_scout_seed.get("manifest_path")
            if isinstance(stored_scout_seed, Mapping)
            else None
        ),
        prediction_manifest_path=prediction_path,
        batch_plan_path=plan_path,
        cache_dir=cache_resolved,
        config=config,
        require_exact_cache=True,
        frozen_binding=stored_scout_seed,
    )
    _validate_frozen_namespace(
        profile=profile,
        run_output_initial_state=execution.get("run_output_initial_state"),
        cache_initial_state=execution.get("cache_initial_state"),
        predecessor=predecessor,
        scout_seed=scout_seed,
    )
    workflow_contract = _workflow_contract()
    checks = (
        document.get("preregistration_path") == str(path),
        document.get("code_bundle") == current_bundle,
        document.get("code_bundle_sha256")
        == stable_sha256(current_bundle),
        manifest_record.get("path") == str(prediction_path),
        manifest_record.get("file_sha256")
        == _file_sha256(prediction_path),
        manifest_record.get("content_sha256")
        == prediction["prediction_manifest_sha256"],
        manifest_record.get("entry_count") == len(cases),
        plan_record.get("path") == str(plan_path),
        plan_record.get("file_sha256") == _file_sha256(plan_path),
        plan_record.get("content_sha256")
        == plan_binding["content_sha256"],
        plan_record.get("batch_identities")
        == plan_binding["batch_identities"],
        plan_record.get("batch_memberships")
        == plan_binding["batch_memberships"],
        plan_record.get("execution_trajectory_ids")
        == plan_binding["execution_trajectory_ids"],
        evaluation.get("heldout") is contract["heldout"],
        evaluation.get("dataset_manifest_sha256")
        == prediction["dataset_manifest_sha256"],
        evaluation.get("cohort_manifest_file_sha256")
        == _file_sha256(cohort_path),
        config.public_dict() == document.get("provider_config"),
        execution.get("run_output_dir") == str(run_output_resolved),
        execution.get("cache_dir") == str(cache_resolved),
        execution.get("workers") == 1,
        implementation.get("experiment")
        == workflow_contract["E9_EXPERIMENT"],
        implementation.get("method") == workflow_contract["E9_METHOD"],
        implementation.get("pipeline_version")
        == BATCHED_CAUSAL_PIPELINE_VERSION,
        implementation.get("scout_prompt_protocol_version")
        == BATCHED_SCOUT_PROMPT_PROTOCOL_VERSION,
        implementation.get("arbiter_prompt_protocol_version")
        == BATCHED_ARBITER_PROMPT_PROTOCOL_VERSION,
        authorization.get("claim_path")
        == str(_claim_path(authorization_dir, profile=profile)),
        authorization.get("ordinal") == _phase_identity(profile)[0],
        authorization.get("predecessor_claim_sha256")
        == predecessor_claim_sha256,
        document.get("predecessor") == predecessor,
        "prior_usage_anchor" in document,
        document.get("prior_usage_anchor") == prior_usage_anchor,
        "scout_seed" in document,
        document.get("scout_seed") == scout_seed,
    )
    if not all(checks):
        raise BatchedCausalPreregistrationError(
            "runtime E9 code/input/provider/path identity differs from "
            "preregistration"
        )
    _validate_claim(document)
    if run_path.is_file():
        raise BatchedCausalPreregistrationError(
            "E9 prediction run is already complete"
        )
    current_output = _directory_state(
        run_output_resolved,
        excluded_paths=(path, ledger_path, ledger_lock_path, unscored_path),
    )
    if current_output != execution.get("run_output_initial_state"):
        raise BatchedCausalPreregistrationError(
            "E9 output directory contains unregistered artifacts"
        )
    if not ledger["entries"]:
        clean_unscored_state = (
            not unscored_path.exists()
            or (
                unscored_path.is_file()
                and unscored_path.stat().st_size == 0
            )
        )
        if not clean_unscored_state or (
            execution.get("cache_initial_state")
            != _directory_state(cache_resolved)
        ):
            raise BatchedCausalPreregistrationError(
                "E9 clean-start state differs from preregistration"
            )
    else:
        validator = getattr(
            _workflow(),
            "validate_partial_batched_causal_predictions",
            None,
        )
        if not callable(validator):
            raise BatchedCausalPreregistrationError(
                "E9 workflow cannot validate a partially completed run"
            )
        try:
            validator(
                prediction_manifest_path=prediction_path,
                batch_plan_path=plan_path,
                unscored_predictions_path=unscored_path,
                preregistration_sha256=document["preregistration_sha256"],
                cache_dir=cache_resolved,
                config=config,
            )
        except (TypeError, ValueError) as error:
            raise BatchedCausalPreregistrationError(
                "E9 partial raw chain is invalid"
            ) from error
    return document


def _read_jsonl(path: Path, *, location: str) -> list[dict[str, Any]]:
    try:
        values = [
            json.loads(line)
            for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
    except (OSError, json.JSONDecodeError) as error:
        raise BatchedCausalPreregistrationError(
            f"{location} is missing or corrupt"
        ) from error
    if not values or any(not isinstance(value, dict) for value in values):
        raise BatchedCausalPreregistrationError(
            f"{location} must contain JSON objects"
        )
    return values


def _validate_prediction_manifest_against_dataset(
    *,
    prediction_manifest: Mapping[str, Any],
    dataset: Any,
    cohort: Any,
) -> None:
    expected_entries = [
        build_prediction_case(example.trace, example.mapping)
        for example in cohort.examples_from(dataset)
    ]
    expected_selection_identity = {
        "selection_name": cohort.cohort_name,
        "cohort_sha256": cohort.cohort_sha256,
        "trajectory_ids": list(cohort.trajectory_ids),
        "execution_order": "cohort-manifest",
        "expected_count": len(cohort.trajectory_ids),
    }
    if (
        prediction_manifest.get("dataset_manifest_sha256")
        != dataset.dataset_sha256
        or prediction_manifest.get("cohort_name") != cohort.cohort_name
        or prediction_manifest.get("cohort_sha256") != cohort.cohort_sha256
        or prediction_manifest.get("entry_count") != len(expected_entries)
        or prediction_manifest.get("selection_identity")
        != expected_selection_identity
        or prediction_manifest.get("entries") != expected_entries
    ):
        raise BatchedCausalPreregistrationError(
            "E9 PredictionManifest is not the exact gold-free dataset "
            "projection"
        )


def _unique_batch_stage_records(
    rows: Sequence[Mapping[str, Any]],
    *,
    batch_memberships: Sequence[Sequence[str]],
) -> list[dict[str, Any]]:
    trajectory_to_batch: dict[str, int] = {}
    for batch_index, membership in enumerate(batch_memberships):
        for trajectory_id in membership:
            if trajectory_id in trajectory_to_batch:
                raise BatchedCausalPreregistrationError(
                    "E9 batch plan repeats a trajectory"
                )
            trajectory_to_batch[str(trajectory_id)] = batch_index
    per_key: dict[tuple[int, str], dict[str, Any]] = {}
    for row in rows:
        trajectory_id = row.get("trajectory_id")
        if trajectory_id not in trajectory_to_batch:
            raise BatchedCausalPreregistrationError(
                "E9 raw row is absent from the batch plan"
            )
        attempted = row.get("stage_attempted")
        hits = row.get("stage_cache_hits")
        identities = row.get("stage_identities")
        if not all(
            isinstance(value, Mapping)
            for value in (attempted, hits, identities)
        ):
            raise BatchedCausalPreregistrationError(
                "E9 raw stage maps are invalid"
            )
        for stage in _STAGES:
            identity = identities.get(stage)
            request_sha256 = (
                identity.get("request_sha256")
                if isinstance(identity, Mapping)
                else None
            )
            record = {
                "batch_index": trajectory_to_batch[str(trajectory_id)],
                "stage": stage,
                "attempted": attempted.get(stage),
                "cache_hit": hits.get(stage),
                "request_sha256": request_sha256,
            }
            if (
                record["attempted"] is not True
                or not isinstance(record["cache_hit"], bool)
                or not isinstance(request_sha256, str)
                or len(request_sha256) != 64
            ):
                raise BatchedCausalPreregistrationError(
                    "E9 raw batch stage record is invalid"
                )
            key = (record["batch_index"], stage)
            prior = per_key.setdefault(key, record)
            if prior != record:
                raise BatchedCausalPreregistrationError(
                    "E9 rows disagree about their shared batch stage"
                )
    expected_keys = {
        (batch_index, stage)
        for batch_index in range(len(batch_memberships))
        for stage in _STAGES
    }
    if set(per_key) != expected_keys:
        raise BatchedCausalPreregistrationError(
            "E9 raw rows do not cover every frozen batch stage"
        )
    return [per_key[key] for key in sorted(per_key)]


def _ledger_matches_cache_misses(
    *,
    records: Sequence[Mapping[str, Any]],
    ledger_entries: Sequence[Mapping[str, Any]],
) -> bool:
    misses = Counter(
        (record["stage"], record["request_sha256"])
        for record in records
        if not record["cache_hit"]
    )
    reservations = Counter(
        (entry.get("stage"), entry.get("request_sha256"))
        for entry in ledger_entries
    )
    return misses == reservations


def _dry_all_stages_are_new(
    *,
    records: Sequence[Mapping[str, Any]],
    ledger_entries: Sequence[Mapping[str, Any]],
) -> bool:
    records_by_stage = {
        (record.get("batch_index"), record.get("stage")): record
        for record in records
    }
    scout_record = records_by_stage.get((0, BATCHED_SCOUT_STAGE))
    arbiter_record = records_by_stage.get((0, BATCHED_ARBITER_STAGE))
    return bool(
        len(records) == 2
        and isinstance(scout_record, Mapping)
        and scout_record.get("cache_hit") is False
        and isinstance(arbiter_record, Mapping)
        and arbiter_record.get("cache_hit") is False
        and len(ledger_entries) == 2
        and _ledger_matches_cache_misses(
            records=records,
            ledger_entries=ledger_entries,
        )
    )


def _contains_forbidden_semantic_input(value: Any) -> bool:
    forbidden = {
        "confidence",
        "deterministic_finding",
        "deterministic_findings",
        "prior_root",
        "score",
        "scores",
        "vote",
        "votes",
        "weight",
        "weights",
    }
    if isinstance(value, Mapping):
        return any(
            str(key).casefold() in forbidden
            or str(key).casefold().startswith("gold_")
            or _contains_forbidden_semantic_input(item)
            for key, item in value.items()
        )
    if isinstance(value, (list, tuple)):
        return any(_contains_forbidden_semantic_input(item) for item in value)
    return False


def verify_batched_causal_promotion(
    *,
    preregistration_path: str | Path,
    predictions_path: str | Path,
    metrics_path: str | Path,
    predict_run_path: str | Path,
    output_path: str | Path,
    persist: bool = True,
    validate_cache_state: bool = True,
) -> dict[str, Any]:
    """Reconstruct scores from raw E9 artifacts and apply the frozen gate."""

    prereg_path = Path(preregistration_path).expanduser().resolve()
    predictions_resolved = Path(predictions_path).expanduser().resolve()
    metrics_resolved = Path(metrics_path).expanduser().resolve()
    run_resolved = Path(predict_run_path).expanduser().resolve()
    output_resolved = Path(output_path).expanduser().resolve()
    prereg = _validated_hashed_document(
        prereg_path,
        location="E9 preregistration",
        hash_field="preregistration_sha256",
    )
    if prereg.get("schema_version") != E9_PREREGISTRATION_SCHEMA_VERSION:
        raise BatchedCausalPreregistrationError(
            "E9 preregistration schema is invalid"
        )
    current_bundle = _current_code_bundle()
    if (
        prereg.get("code_bundle") != current_bundle
        or prereg.get("code_bundle_sha256")
        != stable_sha256(current_bundle)
    ):
        raise BatchedCausalPreregistrationError(
            "E9 code bundle changed after preregistration"
        )
    selection = prereg.get("selection")
    gate = prereg.get("promotion_gate")
    budget = prereg.get("logical_completion_budget")
    implementation = prereg.get("implementation")
    execution = prereg.get("execution")
    manifest_record = prereg.get("prediction_manifest")
    plan_record = prereg.get("batch_plan")
    evaluation = prereg.get("evaluation")
    stored_scout_seed = prereg.get("scout_seed")
    stored_prior_usage_anchor = prereg.get("prior_usage_anchor")
    if not all(
        isinstance(value, Mapping)
        for value in (
            selection,
            gate,
            budget,
            implementation,
            execution,
            manifest_record,
            plan_record,
            evaluation,
        )
    ) or (
        stored_scout_seed is not None
        and not isinstance(stored_scout_seed, Mapping)
    ) or (
        stored_prior_usage_anchor is not None
        and not isinstance(stored_prior_usage_anchor, Mapping)
    ):
        raise BatchedCausalPreregistrationError(
            "E9 promotion preregistration envelope is invalid"
        )
    unknown = sorted(set(gate) - _SUPPORTED_GATE_FIELDS)
    if unknown:
        raise BatchedCausalPreregistrationError(
            "E9 promotion gate contains unsupported fields: "
            + ", ".join(unknown)
        )
    profile = str(evaluation.get("profile"))
    authorization = prereg.get("authorization_chain")
    if not isinstance(authorization, Mapping):
        raise BatchedCausalPreregistrationError(
            "E9 authorization-chain envelope is invalid"
        )
    authorization_dir = _authorization_directory(
        profile=profile,
        requested=authorization.get("directory"),
        run_output_dir=Path(str(execution["run_output_dir"])).resolve(),
    )
    prediction_path = Path(
        str(manifest_record["path"])
    ).expanduser().resolve()
    plan_path = Path(str(plan_record["path"])).expanduser().resolve()
    prediction_manifest, cases = load_prediction_manifest(prediction_path)
    batch_plan, batches = _batch_plan_loader(plan_path)
    plan_binding = _validate_batch_plan_binding(
        plan=batch_plan,
        batches=batches,
        selected_ids=selection["trajectory_ids"],
    )
    config = BenchmarkRunConfig(**dict(prereg["provider_config"]))
    _validate_formal_provider_config(profile=profile, config=config)
    predecessor, predecessor_claim_sha256 = _resolve_predecessor_binding(
        profile=profile,
        authorization_dir=authorization_dir,
        cumulative_before=budget["cumulative_before"],
        code_bundle=current_bundle,
        config=config,
        cache_dir=Path(str(execution["cache_dir"])).resolve(),
        current_prediction_manifest_path=prediction_path,
        current_prediction_manifest=prediction_manifest,
        current_batch_plan=batch_plan,
        current_batches=batches,
        require_predecessor_cache_state=False,
    )
    _validate_phase_budget(
        profile=profile,
        batch_count=plan_binding["batch_count"],
        cumulative_before=budget.get("cumulative_before"),
        maximum_new=budget.get("maximum_new"),
        hard_cumulative_stop=budget.get("hard_cumulative_stop"),
        authorized_cumulative_ceiling=budget.get(
            "authorized_cumulative_ceiling"
        ),
        predecessor_cumulative_after=(
            None if predecessor is None else predecessor["cumulative_after"]
        ),
    )
    prior_usage_anchor = _resolve_prior_usage_anchor(
        profile=profile,
        cumulative_before=budget["cumulative_before"],
        config=config,
    )
    scout_seed = _validate_scout_seed_binding(
        profile=profile,
        scout_seed_manifest_path=(
            stored_scout_seed.get("manifest_path")
            if isinstance(stored_scout_seed, Mapping)
            else None
        ),
        prediction_manifest_path=prediction_path,
        batch_plan_path=plan_path,
        cache_dir=Path(str(execution["cache_dir"])).resolve(),
        config=config,
        require_exact_cache=False,
        frozen_binding=stored_scout_seed,
    )
    _validate_frozen_namespace(
        profile=profile,
        run_output_initial_state=execution.get("run_output_initial_state"),
        cache_initial_state=execution.get("cache_initial_state"),
        predecessor=predecessor,
        scout_seed=scout_seed,
    )
    if (
        authorization.get("claim_path")
        != str(_claim_path(authorization_dir, profile=profile))
        or authorization.get("ordinal") != _phase_identity(profile)[0]
        or authorization.get("predecessor_claim_sha256")
        != predecessor_claim_sha256
        or prereg.get("predecessor") != predecessor
        or "prior_usage_anchor" not in prereg
        or prereg.get("prior_usage_anchor") != prior_usage_anchor
        or "scout_seed" not in prereg
        or prereg.get("scout_seed") != scout_seed
    ):
        raise BatchedCausalPreregistrationError(
            "E9 promotion authorization lineage is invalid"
        )
    _validate_claim(prereg)
    expected_output_dir = Path(
        str(execution["run_output_dir"])
    ).expanduser().resolve()
    expected_paths = {
        "predictions": expected_output_dir / "predictions.jsonl",
        "metrics": expected_output_dir / "metrics.json",
        "predict_run": Path(
            str(execution["predict_run_metadata_path"])
        ).expanduser().resolve(),
        "promotion": expected_output_dir / "promotion.json",
    }
    if {
        "predictions": predictions_resolved,
        "metrics": metrics_resolved,
        "predict_run": run_resolved,
        "promotion": output_resolved,
    } != expected_paths:
        raise BatchedCausalPreregistrationError(
            "E9 promotion artifact paths differ from preregistration"
        )
    prediction_rows = _read_jsonl(
        predictions_resolved,
        location="E9 scored predictions",
    )
    metrics_document = _read(metrics_resolved, location="E9 metrics")
    predict_run = _validated_hashed_document(
        run_resolved,
        location="E9 predict run",
        hash_field="predict_run_sha256",
    )
    if (
        manifest_record.get("path") != str(prediction_path)
        or manifest_record.get("file_sha256")
        != _file_sha256(prediction_path)
        or manifest_record.get("content_sha256")
        != prediction_manifest.get("prediction_manifest_sha256")
        or manifest_record.get("entry_count") != len(cases)
        or plan_record.get("path") != str(plan_path)
        or plan_record.get("file_sha256") != _file_sha256(plan_path)
        or plan_record.get("content_sha256")
        != plan_binding["content_sha256"]
        or plan_record.get("batch_identities")
        != plan_binding["batch_identities"]
        or plan_record.get("batch_memberships")
        != plan_binding["batch_memberships"]
        or plan_record.get("execution_trajectory_ids")
        != plan_binding["execution_trajectory_ids"]
    ):
        raise BatchedCausalPreregistrationError(
            "E9 prediction manifest or batch plan changed after "
            "preregistration"
        )
    ledger = _load_ledger(
        execution=execution,
        budget=budget,
        preregistration_sha256=prereg["preregistration_sha256"],
    )
    if (
        predict_run.get("preregistration_sha256")
        != prereg["preregistration_sha256"]
        or predict_run.get("batch_plan_sha256")
        != plan_binding["content_sha256"]
        or predict_run.get("cache_dir") != execution.get("cache_dir")
        or predict_run.get("max_logical_completions")
        != budget.get("maximum_new")
        or predict_run.get("logical_completion_budget_used")
        != len(ledger["entries"])
        or predict_run.get("logical_completion_ledger_sha256")
        != ledger["ledger_sha256"]
    ):
        raise BatchedCausalPreregistrationError(
            "E9 predict run/plan/ledger binding is invalid"
        )

    workflow = _workflow()
    validator = getattr(workflow, "validate_batched_causal_artifacts", None)
    scorer = getattr(workflow, "score_batched_causal_predictions", None)
    if not callable(validator) or not callable(scorer):
        raise BatchedCausalPreregistrationError(
            "E9 workflow lacks raw validation/scoring entry points"
        )
    try:
        validator(
            prediction_manifest_path=prediction_path,
            batch_plan_path=plan_path,
            unscored_predictions_path=execution[
                "unscored_predictions_path"
            ],
            predict_run_metadata_path=run_resolved,
        )
    except (TypeError, ValueError) as error:
        raise BatchedCausalPreregistrationError(
            "E9 raw prediction chain is invalid"
        ) from error
    unscored_rows = _read_jsonl(
        Path(str(execution["unscored_predictions_path"])).resolve(),
        location="E9 unscored predictions",
    )
    stage_records = _unique_batch_stage_records(
        unscored_rows,
        batch_memberships=plan_binding["batch_memberships"],
    )
    if not _ledger_matches_cache_misses(
        records=stage_records,
        ledger_entries=ledger["entries"],
    ):
        raise BatchedCausalPreregistrationError(
            "E9 ledger reservations do not exactly match cache-miss stages"
        )

    dataset_path = Path(str(evaluation["dataset_path"])).resolve()
    cohort_path = Path(str(evaluation["cohort_manifest_path"])).resolve()
    dataset = load_agent_error_bench(dataset_path)
    cohort = load_cohort_manifest(cohort_path, dataset=dataset)
    _validate_prediction_manifest_against_dataset(
        prediction_manifest=prediction_manifest,
        dataset=dataset,
        cohort=cohort,
    )
    contract = _validate_profile_binding(
        profile=profile,
        cohort=cohort.document,
        manifest=prediction_manifest,
        manifest_ids=[case.trajectory_id for case in cases],
        selected_ids=selection["trajectory_ids"],
        gate=gate,
    )
    if (
        dataset.dataset_sha256 != evaluation["dataset_manifest_sha256"]
        or cohort.cohort_sha256 != evaluation["cohort_sha256"]
        or _file_sha256(cohort_path)
        != evaluation["cohort_manifest_file_sha256"]
        or evaluation.get("heldout") is not contract["heldout"]
    ):
        raise BatchedCausalPreregistrationError(
            "E9 dataset/cohort changed after preregistration"
        )
    try:
        rescored, raw_metrics, raw_run = scorer(
            dataset=dataset,
            cohort=cohort,
            prediction_manifest_path=prediction_path,
            batch_plan_path=plan_path,
            unscored_predictions_path=execution[
                "unscored_predictions_path"
            ],
            predict_run_metadata_path=run_resolved,
        )
    except (TypeError, ValueError) as error:
        raise BatchedCausalPreregistrationError(
            "E9 raw-derived scoring failed"
        ) from error
    recomputed_metrics = compute_metrics(prediction_rows)
    if (
        rescored != prediction_rows
        or raw_metrics != recomputed_metrics
        or raw_run != predict_run
        or metrics_document.get("metrics") != recomputed_metrics
        or [row.get("trajectory_id") for row in prediction_rows]
        != selection["trajectory_ids"]
    ):
        raise BatchedCausalPreregistrationError(
            "E9 scored artifacts are not an exact raw-derived evaluation"
        )
    workflow_contract = _workflow_contract()
    method = workflow_contract["E9_METHOD"]
    try:
        overall = recomputed_metrics["by_method"][method]["overall"]
    except KeyError as error:
        raise BatchedCausalPreregistrationError(
            "E9 metrics lack the frozen method"
        ) from error

    checks: dict[str, bool] = {}

    def check(name: str, passed: bool) -> None:
        checks[name] = bool(passed)

    check(
        "trajectory_denominator",
        overall["trajectory_count"] == gate["trajectory_denominator"],
    )
    check(
        "successful_prediction_minimum",
        overall["successful_prediction_count"]
        >= gate["successful_prediction_minimum"],
    )
    check(
        "failed_prediction_maximum",
        overall["failed_prediction_count"]
        <= gate["failed_prediction_maximum"],
    )
    check(
        "step_exact_minimum_correct",
        overall["step_exact"]["correct"]
        >= gate["step_exact_minimum_correct"],
    )
    check(
        "step_module_exact_minimum_correct",
        overall["step_module_exact"]["correct"]
        >= gate["step_module_exact_minimum_correct"],
    )
    check(
        "all_correct_minimum",
        overall["all_correct"]["correct"] >= gate["all_correct_minimum"],
    )
    check(
        "semantic_mutation_maximum",
        predict_run.get("semantic_mutation_count")
        <= gate["semantic_mutation_maximum"],
    )
    if gate.get("raw_chain_reconstruction_required"):
        check(
            "raw_chain_reconstruction_required",
            len(rescored) == len(unscored_rows)
            and raw_run == predict_run
            and raw_metrics == recomputed_metrics,
        )
    if gate.get("gold_isolation_required"):
        check(
            "gold_isolation_required",
            implementation.get("semantic_input")
            == _V13_SEMANTIC_INPUT_IDENTITY
            and implementation.get("deterministic_root_fallback") is False
            and implementation.get("deterministic_semantic_mutation") is False
            and not _contains_forbidden_semantic_input(unscored_rows),
        )
    if gate.get("llm_arbiter_raw_root_required"):
        check(
            "llm_arbiter_raw_root_required",
            all(
                row.get("semantic_classifier")
                == workflow_contract["E9_SEMANTIC_CLASSIFIER"]
                and isinstance(
                    row.get("raw_judge_outputs", {}).get(
                        BATCHED_ARBITER_STAGE
                    ),
                    str,
                )
                for row in unscored_rows
                if row.get("status") in SUCCESS_STATUSES
            ),
        )
    used = predict_run.get("logical_completion_budget_used")
    check(
        "runtime_budget_exactly_preregistered",
        isinstance(used, int)
        and not isinstance(used, bool)
        and used == budget["maximum_new"]
        and len(ledger["entries"]) == budget["maximum_new"]
        and budget["cumulative_before"] + used
        == budget["hard_cumulative_stop"]
        <= budget["authorized_cumulative_ceiling"],
    )
    cache_hits = [
        record["cache_hit"] for record in stage_records
    ]
    if profile == "dry3":
        check(
            "dry_all_stages_cache_miss",
            _dry_all_stages_are_new(
                records=stage_records,
                ledger_entries=ledger["entries"],
            ),
        )
    elif profile == "full30":
        check(
            "full_reuses_only_dry_first_batch",
            all(
                record["cache_hit"] is (record["batch_index"] == 0)
                for record in stage_records
            )
            and predecessor is not None
            and plan_binding["batch_identities"][0]
            == predecessor["first_batch_identity"],
        )
    elif profile == "smoke30":
        check("smoke_all_stages_cache_miss", not any(cache_hits))
    if gate.get("heldout_one_shot_required"):
        check(
            "heldout_one_shot_required",
            execution.get("run_output_initial_state", {}).get("file_count")
            == 0
            and execution.get("cache_initial_state", {}).get("file_count")
            == 0
            and profile == "smoke30"
            and evaluation.get("heldout") is True
            and selection.get("count") == 30
            and predict_run.get("prediction_count") == 30
            and not any(cache_hits),
        )
    accepted = bool(checks) and all(checks.values())
    cache_final_state = _directory_state(execution["cache_dir"])
    if not validate_cache_state:
        existing = _read(
            output_resolved,
            location="E9 existing promotion",
        )
        frozen = existing.get("cache_final_state")
        if not isinstance(frozen, Mapping):
            raise BatchedCausalPreregistrationError(
                "E9 frozen predecessor cache state is invalid"
            )
        cache_final_state = dict(frozen)
    document = {
        "schema_version": E9_PROMOTION_SCHEMA_VERSION,
        "accepted": accepted,
        "preregistration_path": str(prereg_path),
        "preregistration_sha256": prereg["preregistration_sha256"],
        "predictions_path": str(predictions_resolved),
        "predictions_file_sha256": _file_sha256(predictions_resolved),
        "metrics_path": str(metrics_resolved),
        "metrics_file_sha256": _file_sha256(metrics_resolved),
        "predict_run_path": str(run_resolved),
        "predict_run_file_sha256": _file_sha256(run_resolved),
        "cache_final_state": cache_final_state,
        "checks": checks,
        "summary": {
            "trajectory_count": overall["trajectory_count"],
            "step_correct": overall["step_exact"]["correct"],
            "step_denominator": overall["step_exact"]["denominator"],
            "step_module_correct": overall["step_module_exact"]["correct"],
            "all_correct": overall["all_correct"]["correct"],
            "all_denominator": overall["all_correct"]["denominator"],
            "failed_prediction_count": overall["failed_prediction_count"],
            "logical_completion_budget_used": used,
        },
    }
    document["promotion_sha256"] = stable_sha256(document)
    if persist:
        # Failure is intentionally durable: the next phase cannot reinterpret
        # a rejected predecessor or silently rerun the same formal claim.
        _atomic_json(output_resolved, document)
    else:
        if _read(
            output_resolved,
            location="E9 existing promotion",
        ) != document:
            raise BatchedCausalPreregistrationError(
                "E9 predecessor promotion does not reproduce exactly"
            )
    if not accepted:
        failed = sorted(name for name, passed in checks.items() if not passed)
        raise BatchedCausalPreregistrationError(
            "E9 promotion gate failed: " + ", ".join(failed)
        )
    return document


__all__ = [
    "BatchedCausalPreregistrationError",
    "E9_AUTHORIZATION_CHAIN_RELATIVE_PATH",
    "E9_AUTHORIZATION_CLAIM_SCHEMA_VERSION",
    "E9_CUMULATIVE_LOGICAL_COMPLETIONS_BEFORE",
    "E9_DRY3_IDS_MANIFEST_ORDER",
    "E9_EVALUATION_PROFILES",
    "E9_IMPLEMENTATION_CUMULATIVE_CEILING",
    "E9_PREREGISTRATION_SCHEMA_VERSION",
    "E9_PROMOTION_SCHEMA_VERSION",
    "frozen_batched_causal_promotion_gate",
    "verify_batched_causal_preregistration",
    "verify_batched_causal_promotion",
    "write_batched_causal_preregistration",
]

"""Gold-isolated E5d one-shot evidence-format repair replay."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping

from agentdebug.diagnostics import (
    EVIDENCE_REPAIR_MAX_ATTEMPTS,
    EVIDENCE_REPAIR_PIPELINE_VERSION,
    EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION,
    EVIDENCE_VALIDATION_VERSION,
    JUDGE_VIEW_VERSION,
    EvidenceRepairRequest,
    JudgeOutputError,
    JudgeView,
    RootCauseJudgment,
    build_evidence_repair_request,
    build_judge_view,
    evidence_repair_messages,
    evidence_repair_messages_sha256,
    parse_evidence_repair,
    validate_evidence,
)
from agentdebug.trace import CanonicalTrace

from .cohort import CohortManifest
from .metrics import compute_metrics
from .models import BenchmarkDataset
from .replay_critic import (
    CriticReplayError,
    _assert_gold_free,
    _atomic_write_json,
    _atomic_write_jsonl,
    _document_with_hash,
    _read_jsonl,
    _root_from_dict,
    _sha256_file,
    _sha256_value,
    load_replay_manifest,
    replay_artifact_sha256,
    validate_predict_run_metadata,
)
from .replay_handoff import (
    HANDOFF_REPLAY_METHOD,
    _validate_handoff_prediction_record,
)
from .runner import (
    TRANSPORT_POLICY_VERSION,
    BenchmarkRunConfig,
    _apply_root,
    _base_record,
)
from .stage_cache import (
    StageCacheError,
    build_stage_request,
    run_cached_stage,
    stable_sha256,
    sum_stage_telemetry,
)


E5D_METHOD = "e5d_evidence_format_repair"
E5D_PIPELINE_VERSION = "e5d_one_shot_evidence_only_repair_v1"
E5D_MANIFEST_SCHEMA_VERSION = (
    "agentdebug.benchmark.e5d-repair-manifest.v1"
)
E5D_ATTEMPT_SCHEMA_VERSION = (
    "agentdebug.benchmark.e5d-repair-attempt.v1"
)
E5D_PREDICT_RUN_SCHEMA_VERSION = (
    "agentdebug.benchmark.e5d-repair-predict-run.v1"
)
E5D_FINAL_SCHEMA_VERSION = (
    "agentdebug.benchmark.e5d-unscored-prediction.v1"
)
E5D_FINAL_RUN_SCHEMA_VERSION = (
    "agentdebug.benchmark.e5d-finalize-run.v1"
)
E5D_SOURCE_TRANSPORT_POLICY_VERSION = (
    "judge-http-json-object-v4-telemetry"
)
_ROOT_FIELDS = {
    "critical_event_id",
    "critical_step",
    "module",
    "error_type",
    "root_cause",
    "evidence_quote",
    "evidence_event_ids",
}


def _read_object(path: str | Path, *, location: str) -> dict[str, Any]:
    resolved = Path(path).expanduser().resolve()
    try:
        value = json.loads(resolved.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise CriticReplayError(f"{location} is corrupt") from error
    if not isinstance(value, dict):
        raise CriticReplayError(f"{location} must be a JSON object")
    return value


def _assert_sha(value: Any, *, field: str) -> str:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise CriticReplayError(f"{field} must be a lowercase SHA-256")
    return value


def _root(value: Any) -> RootCauseJudgment:
    if not isinstance(value, Mapping) or set(value) != _ROOT_FIELDS:
        raise CriticReplayError("E5d source root fields are invalid")
    try:
        return _root_from_dict(value)
    except (KeyError, TypeError, ValueError) as error:
        raise CriticReplayError("E5d source root is invalid") from error


def _request_snapshot(request: EvidenceRepairRequest) -> dict[str, Any]:
    return {
        "trace_id": request.trace_id,
        "judge_view_version": request.judge_view_version,
        "step_count": request.step_count,
        "critical_event_id": request.critical_event_id,
        "evidence_event_ids": list(request.evidence_event_ids),
        "semantic_root": request.semantic_root.to_dict(),
        "invalid_evidence": request.invalid_evidence,
        "source_strings": list(request.source_strings),
    }


def _load_strict_source(
    *,
    replay_manifest_path: str | Path,
    source_unscored_path: str | Path,
    source_predict_run_path: str | Path,
    expected_replay_manifest_sha256: str | None = None,
    expected_source_unscored_sha256: str | None = None,
    expected_source_predict_run_sha256: str | None = None,
) -> tuple[
    dict[str, Any],
    list[dict[str, Any]],
    dict[str, Any],
]:
    manifest_path = Path(replay_manifest_path).expanduser().resolve()
    unscored_path = Path(source_unscored_path).expanduser().resolve()
    run_path = Path(source_predict_run_path).expanduser().resolve()
    manifest = load_replay_manifest(manifest_path)
    if (
        expected_replay_manifest_sha256 is not None
        and manifest["replay_manifest_sha256"]
        != expected_replay_manifest_sha256
    ):
        raise CriticReplayError("E5d replay manifest SHA-256 mismatch")
    unscored_sha = _sha256_file(unscored_path)
    run_sha = _sha256_file(run_path)
    if (
        expected_source_unscored_sha256 is not None
        and unscored_sha != expected_source_unscored_sha256
    ):
        raise CriticReplayError("E5d source unscored SHA-256 mismatch")
    if (
        expected_source_predict_run_sha256 is not None
        and run_sha != expected_source_predict_run_sha256
    ):
        raise CriticReplayError("E5d source predict-run SHA-256 mismatch")
    rows = _read_jsonl(unscored_path)
    metadata = _read_object(run_path, location="strict E5c predict run")
    if (
        metadata.get("transport_policy_version")
        != E5D_SOURCE_TRANSPORT_POLICY_VERSION
    ):
        raise CriticReplayError(
            "E5d source transport policy does not match the frozen "
            "strict E5c artifact"
        )
    method = validate_predict_run_metadata(
        metadata,
        manifest=manifest,
        manifest_path=manifest_path,
        unscored_predictions_path=unscored_path,
        rows=rows,
        expected_transport_policy_version=(
            E5D_SOURCE_TRANSPORT_POLICY_VERSION
        ),
    )
    if method != HANDOFF_REPLAY_METHOD:
        raise CriticReplayError("E5d source must be strict E5c handoff")
    entries = {
        entry["trajectory_id"]: entry for entry in manifest["entries"]
    }
    if (
        len(rows) != len(entries)
        or [row.get("trajectory_id") for row in rows]
        != [entry["trajectory_id"] for entry in manifest["entries"]]
    ):
        raise CriticReplayError(
            "E5d source rows do not exactly match replay manifest order"
        )
    for row in rows:
        _assert_gold_free(row, location="strict E5c source row")
        entry = entries[str(row["trajectory_id"])]
        config_data = row.get("provider_config")
        if not isinstance(config_data, Mapping):
            raise CriticReplayError("strict E5c provider config is missing")
        try:
            config = BenchmarkRunConfig(**dict(config_data))
        except (TypeError, ValueError) as error:
            raise CriticReplayError(
                "strict E5c provider config is invalid"
            ) from error
        _validate_handoff_prediction_record(
            row,
            entry=entry,
            manifest=manifest,
            config=config,
            transport_policy_version=(
                E5D_SOURCE_TRANSPORT_POLICY_VERSION
            ),
        )
    return manifest, rows, metadata


def prepare_evidence_repair(
    *,
    replay_manifest_path: str | Path,
    source_unscored_path: str | Path,
    source_predict_run_path: str | Path,
    expected_replay_manifest_sha256: str,
    expected_source_unscored_sha256: str,
    expected_source_predict_run_sha256: str,
    output_path: str | Path,
    expected_eligible_count: int = 1,
) -> dict[str, Any]:
    """Select only uniquely evidence-format-invalid E5c rows, without gold."""

    manifest, rows, metadata = _load_strict_source(
        replay_manifest_path=replay_manifest_path,
        source_unscored_path=source_unscored_path,
        source_predict_run_path=source_predict_run_path,
        expected_replay_manifest_sha256=(
            expected_replay_manifest_sha256
        ),
        expected_source_unscored_sha256=(
            expected_source_unscored_sha256
        ),
        expected_source_predict_run_sha256=(
            expected_source_predict_run_sha256
        ),
    )
    entries_by_id = {
        entry["trajectory_id"]: entry for entry in manifest["entries"]
    }
    eligible: list[dict[str, Any]] = []
    for row in rows:
        if row.get("status") != "evidence_invalid":
            if not str(row.get("status", "")).startswith("success"):
                raise CriticReplayError(
                    "E5d cannot repair a non-evidence E5c failure"
                )
            continue
        issues = row.get("evidence_validation_issues")
        if (
            row.get("failure_stage") != "evidence_validation"
            or row.get("failure_code") != "invalid_evidence"
            or not isinstance(issues, list)
            or len(issues) != 1
            or issues[0].get("code") != "evidence_quote_not_found"
            or issues[0].get("level") != "error"
        ):
            raise CriticReplayError(
                "E5d eligibility requires one evidence_quote_not_found issue"
            )
        entry = entries_by_id[str(row["trajectory_id"])]
        trace = CanonicalTrace.from_dict(entry["trace"])
        source_root = _root(row.get("root_cause"))
        validation = validate_evidence(
            trace,
            source_root,
            stage="handoff_selector",
        )
        if (
            validation.valid
            or [issue.to_dict() for issue in validation.issues] != issues
        ):
            raise CriticReplayError(
                "E5d eligibility does not match raw-derived validation"
            )
        view = build_judge_view(trace)
        request = build_evidence_repair_request(view, source_root)
        messages = evidence_repair_messages(request)
        item: dict[str, Any] = {
            "trajectory_id": entry["trajectory_id"],
            "trajectory_sha256": entry["trajectory_sha256"],
            "case_input_sha256": entry["case_input_sha256"],
            "source_row_sha256": _sha256_value(row),
            "source_selector_raw_sha256": _sha256_value(
                row["raw_handoff_selector_output"]
            ),
            "trace": trace.to_dict(),
            "trace_sha256": _sha256_value(trace.to_dict()),
            "judge_view": view.to_dict(),
            "judge_view_sha256": _sha256_value(view.to_dict()),
            "source_root": source_root.to_dict(),
            "source_issue": issues[0],
            "repair_request": _request_snapshot(request),
            "prompt_sha256": evidence_repair_messages_sha256(messages),
        }
        item["repair_input_sha256"] = _sha256_value(item)
        eligible.append(item)
    if len(eligible) != expected_eligible_count:
        raise CriticReplayError(
            "E5d eligible count does not match the predeclared count"
        )
    source_unscored = Path(source_unscored_path).expanduser().resolve()
    source_run = Path(source_predict_run_path).expanduser().resolve()
    replay_path = Path(replay_manifest_path).expanduser().resolve()
    document = _document_with_hash(
        {
            "schema_version": E5D_MANIFEST_SCHEMA_VERSION,
            "method": E5D_METHOD,
            "replay_pipeline_version": E5D_PIPELINE_VERSION,
            "repair_protocol_version": (
                EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
            ),
            "repair_core_pipeline_version": (
                EVIDENCE_REPAIR_PIPELINE_VERSION
            ),
            "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
            "judge_view_version": JUDGE_VIEW_VERSION,
            "max_repair_attempts": EVIDENCE_REPAIR_MAX_ATTEMPTS,
            "source_replay_manifest_path": str(replay_path),
            "source_replay_manifest_file_sha256": _sha256_file(
                replay_path
            ),
            "source_replay_manifest_sha256": manifest[
                "replay_manifest_sha256"
            ],
            "source_unscored_path": str(source_unscored),
            "source_unscored_sha256": _sha256_file(source_unscored),
            "source_predict_run_path": str(source_run),
            "source_predict_run_sha256": _sha256_file(source_run),
            "source_prediction_schema_version": metadata[
                "prediction_schema_version"
            ],
            "dataset_manifest_sha256": manifest[
                "dataset_manifest_sha256"
            ],
            "parent_cohort_name": manifest["parent_cohort_name"],
            "parent_cohort_sha256": manifest["parent_cohort_sha256"],
            "source_row_count": len(rows),
            "entry_count": len(eligible),
            "entries": eligible,
        },
        hash_field="repair_manifest_sha256",
    )
    _assert_gold_free(document, location="E5d repair manifest")
    _atomic_write_json(Path(output_path).expanduser().resolve(), document)
    return document


def load_evidence_repair_manifest(
    path: str | Path,
) -> dict[str, Any]:
    document = _read_object(path, location="E5d repair manifest")
    expected_top = {
        "schema_version",
        "method",
        "replay_pipeline_version",
        "repair_protocol_version",
        "repair_core_pipeline_version",
        "evidence_validation_version",
        "judge_view_version",
        "max_repair_attempts",
        "source_replay_manifest_path",
        "source_replay_manifest_file_sha256",
        "source_replay_manifest_sha256",
        "source_unscored_path",
        "source_unscored_sha256",
        "source_predict_run_path",
        "source_predict_run_sha256",
        "source_prediction_schema_version",
        "dataset_manifest_sha256",
        "parent_cohort_name",
        "parent_cohort_sha256",
        "source_row_count",
        "entry_count",
        "entries",
        "repair_manifest_sha256",
    }
    if set(document) != expected_top:
        raise CriticReplayError("E5d repair manifest fields are invalid")
    expected_identity = {
        "schema_version": E5D_MANIFEST_SCHEMA_VERSION,
        "method": E5D_METHOD,
        "replay_pipeline_version": E5D_PIPELINE_VERSION,
        "repair_protocol_version": EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION,
        "repair_core_pipeline_version": EVIDENCE_REPAIR_PIPELINE_VERSION,
        "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
        "judge_view_version": JUDGE_VIEW_VERSION,
        "max_repair_attempts": 1,
    }
    for field, expected in expected_identity.items():
        if document.get(field) != expected:
            raise CriticReplayError(
                f"E5d repair manifest {field} mismatch"
            )
    body = dict(document)
    claimed = body.pop("repair_manifest_sha256")
    if claimed != _sha256_value(body):
        raise CriticReplayError("E5d repair manifest hash is invalid")
    entries = document.get("entries")
    if (
        not isinstance(entries, list)
        or len(entries) != document.get("entry_count")
        or len(entries) != 1
    ):
        raise CriticReplayError("E5d repair manifest entry count is invalid")
    for entry in entries:
        if not isinstance(entry, dict):
            raise CriticReplayError("E5d repair entry must be an object")
        entry_body = dict(entry)
        item_hash = entry_body.pop("repair_input_sha256", None)
        if item_hash != _sha256_value(entry_body):
            raise CriticReplayError("E5d repair input hash is invalid")
        view = JudgeView.from_dict(entry["judge_view"])
        trace = CanonicalTrace.from_dict(entry["trace"])
        if (
            entry["trace_sha256"] != _sha256_value(trace.to_dict())
            or view.to_dict() != build_judge_view(trace).to_dict()
        ):
            raise CriticReplayError("E5d embedded trace/view is invalid")
        if entry["judge_view_sha256"] != _sha256_value(view.to_dict()):
            raise CriticReplayError("E5d JudgeView hash is invalid")
        source_root = _root(entry["source_root"])
        request = build_evidence_repair_request(view, source_root)
        if entry["repair_request"] != _request_snapshot(request):
            raise CriticReplayError("E5d repair request snapshot is invalid")
        messages = evidence_repair_messages(request)
        if entry["prompt_sha256"] != evidence_repair_messages_sha256(
            messages
        ):
            raise CriticReplayError("E5d repair prompt hash is invalid")
    _assert_gold_free(document, location="E5d repair manifest")
    return document


def _stage_request(
    *,
    manifest: Mapping[str, Any],
    entry: Mapping[str, Any],
    request: EvidenceRepairRequest,
    config: BenchmarkRunConfig,
):
    messages = evidence_repair_messages(request)
    identity = {
        "method": E5D_METHOD,
        "prediction_schema_version": E5D_ATTEMPT_SCHEMA_VERSION,
        "replay_pipeline_version": E5D_PIPELINE_VERSION,
        "repair_core_pipeline_version": EVIDENCE_REPAIR_PIPELINE_VERSION,
        "repair_protocol_version": EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION,
        "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "judge_view_version": JUDGE_VIEW_VERSION,
        "max_repair_attempts": EVIDENCE_REPAIR_MAX_ATTEMPTS,
        "repair_manifest_sha256": manifest["repair_manifest_sha256"],
        "repair_input_sha256": entry["repair_input_sha256"],
        "trajectory_id": entry["trajectory_id"],
        "trajectory_sha256": entry["trajectory_sha256"],
        "case_input_sha256": entry["case_input_sha256"],
        "frozen_semantic_root_sha256": stable_sha256(
            request.semantic_root.to_dict()
        ),
        "invalid_evidence_sha256": stable_sha256(
            request.invalid_evidence
        ),
        "source_strings_sha256": stable_sha256(request.source_strings),
        "provider_config": config.public_dict(),
    }
    stage = build_stage_request(
        stage="evidence_repair",
        messages=messages,
        identity=identity,
        dependency_sha256=entry["source_selector_raw_sha256"],
    )
    if stage.prompt_sha256 != evidence_repair_messages_sha256(messages):
        raise CriticReplayError("E5d stage prompt identity mismatch")
    return stage, messages


def _rebuild_request(
    entry: Mapping[str, Any],
) -> EvidenceRepairRequest:
    return build_evidence_repair_request(
        JudgeView.from_dict(entry["judge_view"]),
        _root(entry["source_root"]),
    )


def predict_evidence_repair(
    *,
    repair_manifest_path: str | Path,
    complete: Callable[[list[dict[str, str]]], Any],
    config: BenchmarkRunConfig,
    cache_dir: str | Path,
    attempts_output_path: str | Path,
    run_metadata_path: str | Path,
    telemetry_snapshotter: Callable[
        [], Mapping[str, Any] | None
    ],
    capability_snapshotter: Callable[
        [], Mapping[str, Any] | None
    ]
    | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Run exactly one repair completion over the one-entry manifest."""

    if not callable(complete) or not callable(telemetry_snapshotter):
        raise TypeError("E5d predict requires completion and telemetry callables")
    started = datetime.now(timezone.utc)
    manifest_path = Path(repair_manifest_path).expanduser().resolve()
    manifest = load_evidence_repair_manifest(manifest_path)
    if config.cohort_sha256 != manifest["parent_cohort_sha256"]:
        raise CriticReplayError("E5d provider config cohort mismatch")
    entry = manifest["entries"][0]
    request = _rebuild_request(entry)
    stage_request, messages = _stage_request(
        manifest=manifest,
        entry=entry,
        request=request,
        config=config,
    )
    trace = CanonicalTrace.from_dict(entry["trace"])

    def parse_and_validate(raw: Any) -> dict[str, Any]:
        root = parse_evidence_repair(raw, request=request)
        validation = validate_evidence(
            trace,
            root,
            stage="evidence_repair",
        )
        if not validation.valid:
            raise JudgeOutputError(
                "evidence_repair",
                "evidence_quote_not_found",
                "Repaired evidence failed strict trace validation.",
                raw_output=raw,
            )
        return root.to_dict()

    try:
        stage, cache_hit = run_cached_stage(
            request=stage_request,
            messages=messages,
            complete=complete,
            parser=parse_and_validate,
            cache_root=cache_dir,
            retry_failures=False,
            telemetry_snapshotter=telemetry_snapshotter,
        )
    except StageCacheError as error:
        raise CriticReplayError("E5d stage cache is invalid") from error
    repaired = stage.get("parsed_output")
    row: dict[str, Any] = {
        "schema_version": E5D_ATTEMPT_SCHEMA_VERSION,
        "method": E5D_METHOD,
        "replay_pipeline_version": E5D_PIPELINE_VERSION,
        "repair_manifest_sha256": manifest["repair_manifest_sha256"],
        "trajectory_id": entry["trajectory_id"],
        "trajectory_sha256": entry["trajectory_sha256"],
        "case_input_sha256": entry["case_input_sha256"],
        "source_row_sha256": entry["source_row_sha256"],
        "source_selector_raw_sha256": entry[
            "source_selector_raw_sha256"
        ],
        "repair_input_sha256": entry["repair_input_sha256"],
        "request_sha256": stage_request.request_sha256,
        "prompt_sha256": stage_request.prompt_sha256,
        "repair_protocol_version": EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION,
        "repair_core_pipeline_version": EVIDENCE_REPAIR_PIPELINE_VERSION,
        "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "max_repair_attempts": 1,
        "provider_config": config.public_dict(),
        "frozen_semantic_root": request.semantic_root.to_dict(),
        "invalid_evidence": request.invalid_evidence,
        "raw_evidence_repair_output": stage["raw_response"],
        "raw_response_sha256": stage["raw_response_sha256"],
        "repaired_root": repaired,
        "status": stage["status"],
        "failure_stage": stage["failure_stage"],
        "failure_code": stage["failure_code"],
        "failure_message": stage["failure_message"],
        "stage_telemetry": stage["stage_telemetry"],
        "latency_seconds": stage["latency_seconds"],
        "cache_hit": cache_hit,
    }
    row["attempt_sha256"] = _sha256_value(row)
    _assert_gold_free(row, location="E5d repair attempt")
    _atomic_write_jsonl(
        Path(attempts_output_path).expanduser().resolve(),
        [row],
    )
    persisted_telemetry = sum_stage_telemetry([stage["stage_telemetry"]])
    if persisted_telemetry is None:
        raise CriticReplayError("E5d repair telemetry is required")
    capabilities = (
        capability_snapshotter()
        if capability_snapshotter is not None
        else None
    )
    if capabilities is not None and not isinstance(capabilities, Mapping):
        raise CriticReplayError(
            "E5d provider capability snapshot must be a mapping"
        )
    persisted_capabilities = (
        dict(capabilities) if capabilities is not None else None
    )
    finished = datetime.now(timezone.utc)
    attempts_path = Path(attempts_output_path).expanduser().resolve()
    metadata = _document_with_hash(
        {
            "schema_version": E5D_PREDICT_RUN_SCHEMA_VERSION,
            "method": E5D_METHOD,
            "replay_pipeline_version": E5D_PIPELINE_VERSION,
            "repair_manifest_path": str(manifest_path),
            "repair_manifest_sha256": manifest["repair_manifest_sha256"],
            "started_at": started.isoformat(),
            "finished_at": finished.isoformat(),
            "duration_seconds": (finished - started).total_seconds(),
            "provider_config": config.public_dict(),
            "repair_protocol_version": (
                EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
            ),
            "repair_core_pipeline_version": (
                EVIDENCE_REPAIR_PIPELINE_VERSION
            ),
            "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
            "transport_policy_version": TRANSPORT_POLICY_VERSION,
            "max_repair_attempts": 1,
            "attempt_count": 1,
            "cache_hit_count": int(cache_hit),
            "status_counts": {str(row["status"]): 1},
            "provider_telemetry": persisted_telemetry,
            "provider_capabilities": persisted_capabilities,
            "attempts_path": str(attempts_path),
            "attempts_sha256": replay_artifact_sha256(attempts_path),
            "cache_dir": str(Path(cache_dir).expanduser().resolve()),
        },
        hash_field="predict_run_sha256",
    )
    _assert_gold_free(metadata, location="E5d predict run")
    _atomic_write_json(Path(run_metadata_path).expanduser().resolve(), metadata)
    return [row], metadata


def _load_attempts(
    *,
    repair_manifest: Mapping[str, Any],
    attempts_path: str | Path,
    predict_run_path: str | Path,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    attempts_resolved = Path(attempts_path).expanduser().resolve()
    rows = _read_jsonl(attempts_resolved)
    run = _read_object(predict_run_path, location="E5d predict run")
    body = dict(run)
    claimed = body.pop("predict_run_sha256", None)
    if claimed != _sha256_value(body):
        raise CriticReplayError("E5d predict-run hash is invalid")
    if (
        run.get("schema_version") != E5D_PREDICT_RUN_SCHEMA_VERSION
        or run.get("method") != E5D_METHOD
        or run.get("repair_manifest_sha256")
        != repair_manifest["repair_manifest_sha256"]
        or run.get("attempts_path") != str(attempts_resolved)
        or run.get("attempts_sha256") != _sha256_file(attempts_resolved)
        or len(rows) != 1
    ):
        raise CriticReplayError("E5d predict artifacts are inconsistent")
    row = rows[0]
    row_body = dict(row)
    if row_body.pop("attempt_sha256", None) != _sha256_value(row_body):
        raise CriticReplayError("E5d attempt hash is invalid")
    entry = repair_manifest["entries"][0]
    config = BenchmarkRunConfig(**dict(row["provider_config"]))
    request = _rebuild_request(entry)
    stage, messages = _stage_request(
        manifest=repair_manifest,
        entry=entry,
        request=request,
        config=config,
    )
    if (
        row.get("request_sha256") != stage.request_sha256
        or row.get("prompt_sha256") != stage.prompt_sha256
        or row.get("raw_response_sha256")
        != stable_sha256(row.get("raw_evidence_repair_output"))
    ):
        raise CriticReplayError("E5d attempt request/raw identity mismatch")
    try:
        parsed_root = parse_evidence_repair(
            row.get("raw_evidence_repair_output"),
            request=request,
        )
        validation = validate_evidence(
            CanonicalTrace.from_dict(entry["trace"]),
            parsed_root,
            stage="evidence_repair",
        )
        if not validation.valid:
            raise CriticReplayError(
                "E5d attempt evidence fails strict validation"
            )
        parsed = parsed_root.to_dict()
    except Exception as error:
        if row.get("status") == "success":
            raise CriticReplayError(
                "E5d successful attempt raw cannot be reparsed"
            ) from error
    else:
        if row.get("status") != "success" or row.get("repaired_root") != parsed:
            raise CriticReplayError("E5d repaired root does not match raw")
    _assert_gold_free(rows, location="E5d attempts")
    return rows, run


def _build_final_rows(
    *,
    repair_manifest: Mapping[str, Any],
    replay_manifest: Mapping[str, Any],
    source_rows: list[dict[str, Any]],
    attempt: Mapping[str, Any],
) -> list[dict[str, Any]]:
    selected_id = repair_manifest["entries"][0]["trajectory_id"]
    entries = {
        entry["trajectory_id"]: entry
        for entry in replay_manifest["entries"]
    }
    results: list[dict[str, Any]] = []
    for source in source_rows:
        trajectory_id = str(source["trajectory_id"])
        entry = entries[trajectory_id]
        trace = CanonicalTrace.from_dict(entry["trace"])
        source_root = _root(source["root_cause"])
        attempted = trajectory_id == selected_id
        if attempted and (
            _sha256_value(source) != attempt.get("source_row_sha256")
            or _sha256_value(source)
            != repair_manifest["entries"][0]["source_row_sha256"]
        ):
            raise CriticReplayError(
                "E5d eligible source row does not match repair attempt"
            )
        applied = attempted and attempt.get("status") == "success"
        final_root = (
            _root(attempt["repaired_root"]) if applied else source_root
        )
        source_data = source_root.to_dict()
        final_data = final_root.to_dict()
        for field in _ROOT_FIELDS - {"evidence_quote"}:
            if final_data[field] != source_data[field]:
                raise CriticReplayError(
                    "E5d repair changed a frozen root field"
                )
        if applied and final_data["evidence_quote"] == source_data[
            "evidence_quote"
        ]:
            raise CriticReplayError("E5d repair did not change evidence")
        if not applied and final_data != source_data:
            raise CriticReplayError("E5d pass-through root changed")
        validation = validate_evidence(
            trace,
            final_root,
            stage="evidence_repair",
        )
        if applied and not validation.valid:
            raise CriticReplayError("E5d repaired evidence remains invalid")
        if not attempted and not validation.valid:
            raise CriticReplayError("E5d valid pass-through became invalid")
        status = "success" if validation.valid else "evidence_invalid"
        issues = [issue.to_dict() for issue in validation.issues]
        row: dict[str, Any] = {
            "schema_version": E5D_FINAL_SCHEMA_VERSION,
            "method": E5D_METHOD,
            "replay_pipeline_version": E5D_PIPELINE_VERSION,
            "prepared_manifest_sha256": replay_manifest[
                "replay_manifest_sha256"
            ],
            "repair_manifest_sha256": repair_manifest[
                "repair_manifest_sha256"
            ],
            "trajectory_id": trajectory_id,
            "trajectory_sha256": entry["trajectory_sha256"],
            "case_input_sha256": entry["case_input_sha256"],
            "source_row_sha256": _sha256_value(source),
            "provider_config": dict(attempt["provider_config"]),
            "repair_protocol_version": (
                EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
            ),
            "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
            "repair_attempted": attempted,
            "repair_applied": applied,
            "repair_request_sha256": (
                attempt["request_sha256"] if attempted else None
            ),
            "repair_prompt_sha256": (
                attempt["prompt_sha256"] if attempted else None
            ),
            "raw_evidence_repair_output": (
                attempt["raw_evidence_repair_output"]
                if attempted
                else None
            ),
            "root_cause": final_data,
            "evidence_validation_issues": issues,
            "status": status,
            "failure_stage": (
                None if validation.valid else "evidence_validation"
            ),
            "failure_code": (
                None if validation.valid else "invalid_evidence"
            ),
            "failure_message": (
                None
                if validation.valid
                else "Evidence repair did not produce valid evidence."
            ),
            "latency_seconds": (
                attempt["latency_seconds"] if attempted else 0.0
            ),
            "cache_hit": (
                attempt["cache_hit"] if attempted else True
            ),
        }
        row["prediction_sha256"] = _sha256_value(row)
        _assert_gold_free(row, location="E5d final prediction")
        results.append(row)
    return results


def finalize_evidence_repair(
    *,
    repair_manifest_path: str | Path,
    replay_manifest_path: str | Path,
    source_unscored_path: str | Path,
    source_predict_run_path: str | Path,
    attempts_path: str | Path,
    predict_run_path: str | Path,
    output_path: str | Path,
    run_metadata_path: str | Path,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Materialize all source rows, changing only eligible evidence."""

    repair_manifest = load_evidence_repair_manifest(repair_manifest_path)
    manifest, source_rows, _ = _load_strict_source(
        replay_manifest_path=replay_manifest_path,
        source_unscored_path=source_unscored_path,
        source_predict_run_path=source_predict_run_path,
        expected_replay_manifest_sha256=repair_manifest[
            "source_replay_manifest_sha256"
        ],
        expected_source_unscored_sha256=repair_manifest[
            "source_unscored_sha256"
        ],
        expected_source_predict_run_sha256=repair_manifest[
            "source_predict_run_sha256"
        ],
    )
    attempts, predict_run = _load_attempts(
        repair_manifest=repair_manifest,
        attempts_path=attempts_path,
        predict_run_path=predict_run_path,
    )
    attempt = attempts[0]
    config = dict(attempt["provider_config"])
    results = _build_final_rows(
        repair_manifest=repair_manifest,
        replay_manifest=manifest,
        source_rows=source_rows,
        attempt=attempt,
    )
    output = Path(output_path).expanduser().resolve()
    _atomic_write_jsonl(output, results)
    metadata = _document_with_hash(
        {
            "schema_version": E5D_FINAL_RUN_SCHEMA_VERSION,
            "method": E5D_METHOD,
            "replay_pipeline_version": E5D_PIPELINE_VERSION,
            "prepared_manifest_path": str(
                Path(replay_manifest_path).expanduser().resolve()
            ),
            "prepared_manifest_sha256": manifest[
                "replay_manifest_sha256"
            ],
            "repair_manifest_path": str(
                Path(repair_manifest_path).expanduser().resolve()
            ),
            "repair_manifest_sha256": repair_manifest[
                "repair_manifest_sha256"
            ],
            "source_unscored_path": str(
                Path(source_unscored_path).expanduser().resolve()
            ),
            "source_unscored_sha256": repair_manifest[
                "source_unscored_sha256"
            ],
            "source_predict_run_path": str(
                Path(source_predict_run_path).expanduser().resolve()
            ),
            "source_predict_run_sha256": repair_manifest[
                "source_predict_run_sha256"
            ],
            "attempts_path": str(
                Path(attempts_path).expanduser().resolve()
            ),
            "attempts_sha256": _sha256_file(
                Path(attempts_path).expanduser().resolve()
            ),
            "predict_run_path": str(
                Path(predict_run_path).expanduser().resolve()
            ),
            "predict_run_sha256": predict_run["predict_run_sha256"],
            "provider_config": config,
            "started_at": predict_run["started_at"],
            "finished_at": predict_run["finished_at"],
            "duration_seconds": predict_run["duration_seconds"],
            "provider": config["provider"],
            "endpoint": config["endpoint"],
            "model": config["model"],
            "temperature": config["temperature"],
            "timeout": config["timeout"],
            "max_output_tokens": config["max_output_tokens"],
            "max_retries": config["max_retries"],
            "retry_backoff": config["retry_backoff"],
            "repair_protocol_version": (
                EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
            ),
            "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
            "transport_policy_version": attempt[
                "transport_policy_version"
            ],
            "provider_telemetry": predict_run["provider_telemetry"],
            "provider_capabilities": predict_run.get(
                "provider_capabilities"
            ),
            "prediction_count": len(results),
            "repair_count": 1,
            "status_counts": {
                status: sum(row["status"] == status for row in results)
                for status in sorted({row["status"] for row in results})
            },
            "unscored_predictions_path": str(output),
            "unscored_predictions_sha256": _sha256_file(output),
            "offline_finalize": True,
        },
        hash_field="finalize_run_sha256",
    )
    _assert_gold_free(metadata, location="E5d finalize run")
    _atomic_write_json(Path(run_metadata_path).expanduser().resolve(), metadata)
    return results, metadata


def score_evidence_repair(
    *,
    dataset: BenchmarkDataset,
    cohort: CohortManifest,
    replay_manifest_path: str | Path,
    unscored_predictions_path: str | Path,
    finalize_run_path: str | Path,
) -> tuple[list[dict[str, Any]], dict[str, Any], dict[str, Any]]:
    """Load gold only here, after validating the finalized gold-free file."""

    manifest = load_replay_manifest(replay_manifest_path)
    run = _read_object(finalize_run_path, location="E5d finalize run")
    run_body = dict(run)
    if run_body.pop("finalize_run_sha256", None) != _sha256_value(run_body):
        raise CriticReplayError("E5d finalize-run hash is invalid")
    unscored_path = Path(unscored_predictions_path).expanduser().resolve()
    rows = _read_jsonl(unscored_path)
    if (
        run.get("schema_version") != E5D_FINAL_RUN_SCHEMA_VERSION
        or run.get("method") != E5D_METHOD
        or run.get("prepared_manifest_sha256")
        != manifest["replay_manifest_sha256"]
        or run.get("unscored_predictions_path") != str(unscored_path)
        or run.get("unscored_predictions_sha256")
        != _sha256_file(unscored_path)
        or len(rows) != len(manifest["entries"])
    ):
        raise CriticReplayError("E5d finalized artifacts are inconsistent")
    repair_manifest = load_evidence_repair_manifest(
        run["repair_manifest_path"]
    )
    if (
        run.get("repair_manifest_sha256")
        != repair_manifest["repair_manifest_sha256"]
        or run.get("prepared_manifest_sha256")
        != repair_manifest["source_replay_manifest_sha256"]
        or run.get("source_unscored_sha256")
        != repair_manifest["source_unscored_sha256"]
        or run.get("source_predict_run_sha256")
        != repair_manifest["source_predict_run_sha256"]
    ):
        raise CriticReplayError("E5d finalize lineage is invalid")
    source_manifest, source_rows, _ = _load_strict_source(
        replay_manifest_path=run["prepared_manifest_path"],
        source_unscored_path=run["source_unscored_path"],
        source_predict_run_path=run["source_predict_run_path"],
        expected_replay_manifest_sha256=repair_manifest[
            "source_replay_manifest_sha256"
        ],
        expected_source_unscored_sha256=repair_manifest[
            "source_unscored_sha256"
        ],
        expected_source_predict_run_sha256=repair_manifest[
            "source_predict_run_sha256"
        ],
    )
    attempts, predict_run = _load_attempts(
        repair_manifest=repair_manifest,
        attempts_path=run["attempts_path"],
        predict_run_path=run["predict_run_path"],
    )
    if predict_run["predict_run_sha256"] != run["predict_run_sha256"]:
        raise CriticReplayError("E5d upstream predict-run identity mismatch")
    expected_rows = _build_final_rows(
        repair_manifest=repair_manifest,
        replay_manifest=source_manifest,
        source_rows=source_rows,
        attempt=attempts[0],
    )
    if rows != expected_rows:
        raise CriticReplayError(
            "E5d final predictions do not match selector/repair raw chain"
        )
    if (
        dataset.dataset_sha256 != manifest["dataset_manifest_sha256"]
        or cohort.dataset_manifest_sha256
        != manifest["dataset_manifest_sha256"]
        or cohort.cohort_sha256 != manifest["parent_cohort_sha256"]
        or cohort.cohort_name != manifest["parent_cohort_name"]
    ):
        raise CriticReplayError("E5d score dataset/cohort identity mismatch")
    by_entry = {
        entry["trajectory_id"]: entry for entry in manifest["entries"]
    }
    by_example = {
        example.label.trajectory_id: example for example in dataset.examples
    }
    if {row.get("trajectory_id") for row in rows} != set(by_entry):
        raise CriticReplayError("E5d score row identities mismatch")
    config = BenchmarkRunConfig(**dict(run["provider_config"]))
    scored: list[dict[str, Any]] = []
    for row in rows:
        _assert_gold_free(row, location="E5d unscored prediction")
        row_body = dict(row)
        if row_body.pop("prediction_sha256", None) != _sha256_value(row_body):
            raise CriticReplayError("E5d prediction hash is invalid")
        trajectory_id = str(row["trajectory_id"])
        entry = by_entry[trajectory_id]
        if (
            row.get("schema_version") != E5D_FINAL_SCHEMA_VERSION
            or row.get("method") != E5D_METHOD
            or row.get("trajectory_sha256") != entry["trajectory_sha256"]
            or row.get("case_input_sha256") != entry["case_input_sha256"]
        ):
            raise CriticReplayError("E5d prediction identity mismatch")
        trace = CanonicalTrace.from_dict(entry["trace"])
        root = _root(row["root_cause"])
        validation = validate_evidence(trace, root, stage="evidence_repair")
        expected_status = (
            "success" if validation.valid else "evidence_invalid"
        )
        if (
            row.get("status") != expected_status
            or row.get("evidence_validation_issues")
            != [issue.to_dict() for issue in validation.issues]
        ):
            raise CriticReplayError("E5d prediction semantics are invalid")
        example = by_example[trajectory_id]
        record = _base_record(example, method=E5D_METHOD, config=config)
        record.update(
            {
                "status": row["status"],
                "failure_stage": row["failure_stage"],
                "failure_code": row["failure_code"],
                "failure_message": row["failure_message"],
                "evidence_validation_issues": row[
                    "evidence_validation_issues"
                ],
                "raw_judge_outputs": {
                    "evidence_repair": row.get(
                        "raw_evidence_repair_output"
                    )
                },
                "latency_seconds": row.get("latency_seconds"),
                "cache_hit": row.get("cache_hit"),
                "prompt_version": EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION,
            }
        )
        _apply_root(record, example=example, root=root)
        scored.append(record)
    scored.sort(key=lambda item: str(item["trajectory_id"]))
    metrics = compute_metrics(scored)
    return scored, metrics, run


__all__ = [
    "E5D_ATTEMPT_SCHEMA_VERSION",
    "E5D_FINAL_RUN_SCHEMA_VERSION",
    "E5D_FINAL_SCHEMA_VERSION",
    "E5D_MANIFEST_SCHEMA_VERSION",
    "E5D_METHOD",
    "E5D_PIPELINE_VERSION",
    "E5D_PREDICT_RUN_SCHEMA_VERSION",
    "finalize_evidence_repair",
    "load_evidence_repair_manifest",
    "predict_evidence_repair",
    "prepare_evidence_repair",
    "score_evidence_repair",
]

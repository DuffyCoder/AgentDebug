"""Two-call, gold-isolated handoff-ledger replay for the E5c experiment.

The first semantic completion audits information handoffs without choosing a
root.  The second completion receives a fresh Canonical JudgeView plus the
normalized ledger and makes the only final semantic judgment.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Mapping

from agentdebug.diagnostics import (
    DIAGNOSTIC_PIPELINE_VERSION,
    EVIDENCE_VALIDATION_VERSION,
    HANDOFF_PIPELINE_VERSION,
    HANDOFF_PROMPT_PROTOCOL_VERSION,
    JUDGE_VIEW_VERSION,
    HandoffLedger,
    JudgeOutputError,
    JudgeTransportError,
    handoff_ledger_messages,
    handoff_selector_messages,
    parse_handoff_ledger,
    parse_handoff_selector,
)
from agentdebug.diagnostics.validator import validate_evidence
from agentdebug.trace import CanonicalTrace

from .replay_critic import (
    CriticReplayError,
    _assert_gold_free,
    _atomic_write_json,
    _atomic_write_jsonl,
    _json_safe,
    _read_raw_artifact,
    _sha256_value,
    load_replay_manifest,
)
from .runner import BenchmarkRunConfig, TRANSPORT_POLICY_VERSION


HANDOFF_REPLAY_METHOD = "e5c_handoff_selector_replay"
HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e5c-handoff-selector-replay-prediction.v2"
)
HANDOFF_REPLAY_RUN_SCHEMA_VERSION = (
    "agentdebug.benchmark.e5c-predict-run.v2"
)
HANDOFF_REPLAY_PIPELINE_VERSION = HANDOFF_PIPELINE_VERSION


def _stage_identity(
    *,
    stage: str,
    entry: Mapping[str, Any],
    prepared_manifest_sha256: str,
    messages: list[dict[str, str]],
    config: BenchmarkRunConfig,
    dependency_sha256: str | None = None,
    transport_policy_version: str = TRANSPORT_POLICY_VERSION,
) -> tuple[str, str]:
    prompt_sha256 = _sha256_value(messages)
    identity = {
        "method": HANDOFF_REPLAY_METHOD,
        "prediction_schema_version": (
            HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION
        ),
        "replay_pipeline_version": HANDOFF_REPLAY_PIPELINE_VERSION,
        "prompt_protocol_version": HANDOFF_PROMPT_PROTOCOL_VERSION,
        "stage": stage,
        "prepared_manifest_sha256": prepared_manifest_sha256,
        "case_input_sha256": entry["case_input_sha256"],
        "trajectory_sha256": entry["trajectory_sha256"],
        "judge_view_version": JUDGE_VIEW_VERSION,
        "diagnostic_pipeline_version": DIAGNOSTIC_PIPELINE_VERSION,
        "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
        "transport_policy_version": transport_policy_version,
        "prompt_sha256": prompt_sha256,
        "dependency_sha256": dependency_sha256,
        "provider_config": config.public_dict(),
    }
    return _sha256_value(identity), prompt_sha256


def _stage_expected(
    *,
    stage: str,
    manifest_sha256: str,
    entry: Mapping[str, Any],
    request_sha256: str,
    prompt_sha256: str,
    config: BenchmarkRunConfig,
) -> dict[str, Any]:
    return {
        "schema_version": HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION,
        "method": HANDOFF_REPLAY_METHOD,
        "replay_pipeline_version": HANDOFF_REPLAY_PIPELINE_VERSION,
        "stage": stage,
        "prepared_manifest_sha256": manifest_sha256,
        "trajectory_id": entry["trajectory_id"],
        "trajectory_sha256": entry["trajectory_sha256"],
        "case_input_sha256": entry["case_input_sha256"],
        "request_sha256": request_sha256,
        "prompt_sha256": prompt_sha256,
        "prompt_protocol_version": HANDOFF_PROMPT_PROTOCOL_VERSION,
        "judge_view_version": JUDGE_VIEW_VERSION,
        "diagnostic_pipeline_version": DIAGNOSTIC_PIPELINE_VERSION,
        "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "provider_config": config.public_dict(),
    }


def _load_stage_cache(
    path: Path,
    *,
    raw_path: Path,
    expected: Mapping[str, Any],
) -> dict[str, Any] | None:
    if not path.is_file():
        return None
    try:
        record = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise CriticReplayError("E5c stage cache is corrupt") from error
    if not isinstance(record, dict):
        raise CriticReplayError("E5c stage cache must be a JSON object")
    for field, value in expected.items():
        if record.get(field) != value:
            raise CriticReplayError(
                f"E5c stage cache {field} does not match this request"
            )
    _assert_gold_free(record, location="cached E5c stage")
    raw = _read_raw_artifact(
        raw_path,
        request_sha256=str(expected["request_sha256"]),
        expected_schema_version=HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION,
        expected_evidence_validation_version=(
            EVIDENCE_VALIDATION_VERSION
        ),
    )
    if record.get("raw_output") != raw:
        raise CriticReplayError(
            "E5c stage cache raw output does not match raw artifact"
        )
    if record.get("raw_response_sha256") != _sha256_value(raw):
        raise CriticReplayError("E5c stage cache raw hash mismatch")
    return record


def _failure_status(error: JudgeOutputError) -> str:
    if error.code in {"invalid_taxonomy", "invalid_taxonomy_pair"}:
        return "invalid_taxonomy"
    if error.code in {
        "malformed_json",
        "empty_response",
        "invalid_top_level",
    }:
        return "invalid_json"
    return error.code


def _validate_stage_record(
    record: Mapping[str, Any],
    *,
    stage: str,
    parser: Any,
) -> None:
    """Re-derive one stage's parsed fields from its persisted raw output."""

    raw = record.get("raw_output")
    status = record.get("status")
    parsed_output = record.get("parsed_output")
    if (
        raw is None
        and record.get("failure_stage") == stage
        and isinstance(record.get("failure_code"), str)
        and record.get("failure_code")
        and status != "success"
    ):
        if parsed_output is not None:
            raise CriticReplayError(
                f"failed E5c {stage} cache contains parsed output"
            )
        return
    try:
        parsed = parser(raw)
    except JudgeOutputError as error:
        if (
            parsed_output is not None
            or status != _failure_status(error)
            or record.get("failure_stage") != error.stage
            or record.get("failure_code") != error.code
        ):
            raise CriticReplayError(
                f"E5c {stage} cache parse fields do not match raw output"
            )
        return
    if (
        parsed_output != parsed
        or status != "success"
        or record.get("failure_stage") is not None
        or record.get("failure_code") is not None
    ):
        raise CriticReplayError(
            f"E5c {stage} cache semantics do not match raw output"
        )


def _run_stage(
    *,
    stage: str,
    messages: list[dict[str, str]],
    complete: Any,
    expected: Mapping[str, Any],
    cache_path: Path,
    raw_path: Path,
    parser: Any,
    retry_failures: bool,
) -> tuple[dict[str, Any], bool]:
    cached = _load_stage_cache(
        cache_path,
        raw_path=raw_path,
        expected=expected,
    )
    if cached is not None and (
        not retry_failures
        or str(cached.get("status", "")).startswith("success")
    ):
        _validate_stage_record(cached, stage=stage, parser=parser)
        return cached, True

    # A process may stop after the raw-first write but before the parsed cache
    # write. Reconstruct from that immutable raw artifact instead of issuing a
    # duplicate paid completion. A raw null cannot recover the original
    # transport failure code, so fail closed rather than overwrite it.
    if cached is None and raw_path.is_file():
        persisted = _read_raw_artifact(
            raw_path,
            request_sha256=str(expected["request_sha256"]),
            expected_schema_version=(
                HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION
            ),
            expected_evidence_validation_version=(
                EVIDENCE_VALIDATION_VERSION
            ),
        )
        if persisted is None:
            raise CriticReplayError(
                f"orphan E5c {stage} raw artifact has no recoverable response"
            )
        recovered: dict[str, Any] = {
            **dict(expected),
            "raw_output": persisted,
            "raw_response_sha256": _sha256_value(persisted),
            "parsed_output": None,
            "status": None,
            "failure_stage": None,
            "failure_code": None,
            "failure_message": None,
            "latency_seconds": 0.0,
        }
        try:
            recovered["parsed_output"] = parser(persisted)
            recovered["status"] = "success"
        except JudgeOutputError as error:
            recovered.update(
                {
                    "status": _failure_status(error),
                    "failure_stage": error.stage,
                    "failure_code": error.code,
                    "failure_message": error.safe_message,
                }
            )
        _assert_gold_free(
            recovered,
            location=f"recovered unscored E5c {stage} stage",
        )
        _validate_stage_record(
            recovered,
            stage=stage,
            parser=parser,
        )
        _atomic_write_json(cache_path, recovered)
        return recovered, True

    started = time.monotonic()
    failure: dict[str, Any] | None = None
    try:
        raw = complete(messages)
    except JudgeTransportError as error:
        raw = None
        failure = {
            "status": error.code,
            "failure_stage": stage,
            "failure_code": error.code,
            "failure_message": error.safe_message,
        }
    except Exception:
        raw = None
        failure = {
            "status": "judge_exception",
            "failure_stage": stage,
            "failure_code": "judge_exception",
            "failure_message": (
                f"{stage} judge raised an unexpected exception; its message "
                "was omitted because it may contain sensitive data."
            ),
        }
    raw = _json_safe(raw)
    _atomic_write_json(
        raw_path,
        {
            "schema_version": HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION,
            "evidence_validation_version": (
                EVIDENCE_VALIDATION_VERSION
            ),
            "stage": stage,
            "request_sha256": expected["request_sha256"],
            "response_sha256": _sha256_value(raw),
            "raw_response": raw,
        },
    )
    persisted = _read_raw_artifact(
        raw_path,
        request_sha256=str(expected["request_sha256"]),
        expected_schema_version=HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION,
        expected_evidence_validation_version=(
            EVIDENCE_VALIDATION_VERSION
        ),
    )
    record: dict[str, Any] = {
        **dict(expected),
        "raw_output": persisted,
        "raw_response_sha256": _sha256_value(persisted),
        "parsed_output": None,
        "status": None,
        "failure_stage": None,
        "failure_code": None,
        "failure_message": None,
        "latency_seconds": time.monotonic() - started,
    }
    if failure is not None:
        record.update(failure)
    else:
        try:
            parsed = parser(persisted)
            record["parsed_output"] = parsed
            record["status"] = "success"
        except JudgeOutputError as error:
            record.update(
                {
                    "status": _failure_status(error),
                    "failure_stage": error.stage,
                    "failure_code": error.code,
                    "failure_message": error.safe_message,
                }
            )
    _assert_gold_free(record, location=f"unscored E5c {stage} stage")
    _validate_stage_record(record, stage=stage, parser=parser)
    _atomic_write_json(cache_path, record)
    return record, False


def _validate_handoff_prediction_record(
    row: Mapping[str, Any],
    *,
    entry: Mapping[str, Any],
    manifest: Mapping[str, Any],
    config: BenchmarkRunConfig,
    transport_policy_version: str = TRANSPORT_POLICY_VERSION,
) -> None:
    """Reconstruct every E5c identity and semantic field from raw outputs."""

    if (
        row.get("evidence_validation_version")
        != EVIDENCE_VALIDATION_VERSION
    ):
        raise CriticReplayError(
            "unscored E5c prediction evidence_validation_version mismatch: "
            f"expected {EVIDENCE_VALIDATION_VERSION!r}"
        )
    expected_fields = {
        "schema_version",
        "method",
        "replay_pipeline_version",
        "prepared_manifest_sha256",
        "trajectory_id",
        "trajectory_sha256",
        "case_input_sha256",
        "request_sha256",
        "ledger_request_sha256",
        "selector_request_sha256",
        "prompt_sha256",
        "ledger_prompt_sha256",
        "selector_prompt_sha256",
        "prompt_protocol_version",
        "judge_view_version",
        "diagnostic_pipeline_version",
        "evidence_validation_version",
        "transport_policy_version",
        "provider_config",
        "handoff_ledger",
        "raw_handoff_ledger_output",
        "raw_handoff_selector_output",
        "raw_response_sha256",
        "root_cause",
        "candidate_evidence_validation_issues",
        "evidence_validation_issues",
        "status",
        "failure_stage",
        "failure_code",
        "failure_message",
        "latency_seconds",
        "cache_hit",
        "stage_cache_hits",
        "stage_attempted",
    }
    if set(row) != expected_fields:
        raise CriticReplayError(
            "unscored E5c prediction fields do not match its schema"
        )
    expected_envelope = {
        "schema_version": HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION,
        "method": HANDOFF_REPLAY_METHOD,
        "replay_pipeline_version": HANDOFF_REPLAY_PIPELINE_VERSION,
        "prepared_manifest_sha256": manifest["replay_manifest_sha256"],
        "trajectory_id": entry["trajectory_id"],
        "trajectory_sha256": entry["trajectory_sha256"],
        "case_input_sha256": entry["case_input_sha256"],
        "prompt_protocol_version": HANDOFF_PROMPT_PROTOCOL_VERSION,
        "judge_view_version": JUDGE_VIEW_VERSION,
        "diagnostic_pipeline_version": DIAGNOSTIC_PIPELINE_VERSION,
        "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
        "transport_policy_version": transport_policy_version,
        "provider_config": config.public_dict(),
    }
    for field, expected in expected_envelope.items():
        if row.get(field) != expected:
            raise CriticReplayError(
                f"unscored E5c prediction {field} does not match its request"
            )
    stage_hits = row.get("stage_cache_hits")
    stage_attempted = row.get("stage_attempted")
    if (
        not isinstance(stage_hits, Mapping)
        or set(stage_hits) != {"handoff_ledger", "handoff_selector"}
        or any(not isinstance(value, bool) for value in stage_hits.values())
        or not isinstance(stage_attempted, Mapping)
        or set(stage_attempted) != {"handoff_ledger", "handoff_selector"}
        or any(
            not isinstance(value, bool)
            for value in stage_attempted.values()
        )
        or stage_attempted["handoff_ledger"] is not True
        or (
            stage_attempted["handoff_selector"]
            != (row.get("selector_request_sha256") is not None)
        )
        or any(
            stage_hits[name] and not stage_attempted[name]
            for name in stage_hits
        )
        or not isinstance(row.get("cache_hit"), bool)
        or row.get("cache_hit") != all(stage_hits.values())
    ):
        raise CriticReplayError(
            "unscored E5c prediction cache-hit fields are inconsistent"
        )
    combined_raw = {
        "handoff_ledger": row.get("raw_handoff_ledger_output"),
        "handoff_selector": row.get("raw_handoff_selector_output"),
    }
    if row.get("raw_response_sha256") != _sha256_value(combined_raw):
        raise CriticReplayError(
            "unscored E5c prediction combined raw hash is invalid"
        )
    _assert_gold_free(row, location="unscored E5c prediction")

    trace = CanonicalTrace.from_dict(entry["trace"])
    ledger_messages = handoff_ledger_messages(trace)
    ledger_request_sha256, ledger_prompt_sha256 = _stage_identity(
        stage="handoff_ledger",
        entry=entry,
        prepared_manifest_sha256=manifest["replay_manifest_sha256"],
        messages=ledger_messages,
        config=config,
        transport_policy_version=transport_policy_version,
    )
    if (
        row.get("ledger_request_sha256") != ledger_request_sha256
        or row.get("ledger_prompt_sha256") != ledger_prompt_sha256
    ):
        raise CriticReplayError(
            "unscored E5c ledger request identity is invalid"
        )

    raw_ledger = row.get("raw_handoff_ledger_output")
    if raw_ledger is None:
        if (
            row.get("request_sha256") != ledger_request_sha256
            or row.get("prompt_sha256") != ledger_prompt_sha256
            or row.get("selector_request_sha256") is not None
            or row.get("selector_prompt_sha256") is not None
            or row.get("raw_handoff_selector_output") is not None
            or row.get("handoff_ledger") is not None
            or row.get("root_cause") is not None
            or row.get("candidate_evidence_validation_issues") != []
            or row.get("evidence_validation_issues") != []
            or row.get("failure_stage") != "handoff_ledger"
            or not isinstance(row.get("failure_code"), str)
            or not row.get("failure_code")
            or row.get("status") in {"success", "success_needs_review"}
        ):
            raise CriticReplayError(
                "failed E5c ledger envelope is inconsistent"
            )
        return

    try:
        ledger = parse_handoff_ledger(raw_ledger, trace=trace)
    except JudgeOutputError as error:
        if (
            row.get("request_sha256") != ledger_request_sha256
            or row.get("prompt_sha256") != ledger_prompt_sha256
            or row.get("selector_request_sha256") is not None
            or row.get("selector_prompt_sha256") is not None
            or row.get("raw_handoff_selector_output") is not None
            or row.get("handoff_ledger") is not None
            or row.get("root_cause") is not None
            or row.get("candidate_evidence_validation_issues") != []
            or row.get("evidence_validation_issues") != []
            or row.get("status") != _failure_status(error)
            or row.get("failure_stage") != error.stage
            or row.get("failure_code") != error.code
        ):
            raise CriticReplayError(
                "failed E5c ledger semantics do not match raw output"
            )
        return

    if row.get("handoff_ledger") != ledger.to_dict():
        raise CriticReplayError(
            "unscored E5c ledger does not match raw output"
        )
    candidate_issues: list[dict[str, Any]] = []
    for index, candidate in enumerate(ledger.candidates):
        candidate_validation = validate_evidence(
            trace,
            candidate,
            stage=f"handoff_ledger.candidates[{index}]",
        )
        candidate_issues.extend(
            issue.to_dict() for issue in candidate_validation.issues
        )
    if row.get("candidate_evidence_validation_issues") != candidate_issues:
        raise CriticReplayError(
            "unscored E5c candidate evidence audit is invalid"
        )

    selector_messages = handoff_selector_messages(trace, ledger)
    selector_request_sha256, selector_prompt_sha256 = _stage_identity(
        stage="handoff_selector",
        entry=entry,
        prepared_manifest_sha256=manifest["replay_manifest_sha256"],
        messages=selector_messages,
        config=config,
        dependency_sha256=_sha256_value(raw_ledger),
        transport_policy_version=transport_policy_version,
    )
    if (
        row.get("selector_request_sha256") != selector_request_sha256
        or row.get("selector_prompt_sha256") != selector_prompt_sha256
        or row.get("request_sha256") != selector_request_sha256
        or row.get("prompt_sha256") != selector_prompt_sha256
    ):
        raise CriticReplayError(
            "unscored E5c selector request identity is invalid"
        )

    raw_selector = row.get("raw_handoff_selector_output")
    if raw_selector is None:
        if (
            row.get("root_cause") is not None
            or row.get("evidence_validation_issues") != []
            or row.get("failure_stage") != "handoff_selector"
            or not isinstance(row.get("failure_code"), str)
            or not row.get("failure_code")
            or row.get("status") in {"success", "success_needs_review"}
        ):
            raise CriticReplayError(
                "failed E5c selector envelope is inconsistent"
            )
        return

    try:
        root = parse_handoff_selector(raw_selector, trace=trace)
    except JudgeOutputError as error:
        if (
            row.get("root_cause") is not None
            or row.get("evidence_validation_issues") != []
            or row.get("status") != _failure_status(error)
            or row.get("failure_stage") != error.stage
            or row.get("failure_code") != error.code
        ):
            raise CriticReplayError(
                "failed E5c selector semantics do not match raw output"
            )
        return

    validation = validate_evidence(
        trace,
        root,
        stage="handoff_selector",
    )
    expected_status = (
        "evidence_invalid"
        if not validation.valid
        else "success_needs_review"
        if validation.needs_review
        else "success"
    )
    expected_failure_stage = (
        "evidence_validation" if not validation.valid else None
    )
    expected_failure_code = "invalid_evidence" if not validation.valid else None
    if (
        row.get("root_cause") != root.to_dict()
        or row.get("evidence_validation_issues")
        != [issue.to_dict() for issue in validation.issues]
        or row.get("status") != expected_status
        or row.get("failure_stage") != expected_failure_stage
        or row.get("failure_code") != expected_failure_code
    ):
        raise CriticReplayError(
            "unscored E5c final semantics do not match raw selector output"
        )


def predict_handoff_replay(
    *,
    manifest_path: str | Path,
    complete: Any,
    config: BenchmarkRunConfig,
    cache_dir: str | Path,
    unscored_output_path: str | Path,
    retry_failures: bool = False,
) -> list[dict[str, Any]]:
    """Run one ledger and one independent selector completion per entry."""

    if not callable(complete):
        raise TypeError("E5c handoff replay requires complete(messages)")
    manifest = load_replay_manifest(manifest_path)
    manifest_sha256 = manifest["replay_manifest_sha256"]
    cache_root = Path(cache_dir).expanduser().resolve()
    ledger_cache_root = cache_root / "handoff_ledger"
    selector_cache_root = cache_root / "handoff_selector"
    ledger_raw_root = cache_root / "raw_handoff_ledger"
    selector_raw_root = cache_root / "raw_handoff_selector"
    for path in (
        ledger_cache_root,
        selector_cache_root,
        ledger_raw_root,
        selector_raw_root,
    ):
        path.mkdir(parents=True, exist_ok=True)
    output_path = Path(unscored_output_path).expanduser().resolve()
    results: list[dict[str, Any]] = []

    for entry in manifest["entries"]:
        started = time.monotonic()
        trace = CanonicalTrace.from_dict(entry["trace"])
        ledger_messages = handoff_ledger_messages(trace)
        ledger_request_sha256, ledger_prompt_sha256 = _stage_identity(
            stage="handoff_ledger",
            entry=entry,
            prepared_manifest_sha256=manifest_sha256,
            messages=ledger_messages,
            config=config,
        )
        ledger_expected = _stage_expected(
            stage="handoff_ledger",
            manifest_sha256=manifest_sha256,
            entry=entry,
            request_sha256=ledger_request_sha256,
            prompt_sha256=ledger_prompt_sha256,
            config=config,
        )
        ledger_record, ledger_cache_hit = _run_stage(
            stage="handoff_ledger",
            messages=ledger_messages,
            complete=complete,
            expected=ledger_expected,
            cache_path=ledger_cache_root
            / f"{ledger_request_sha256}.json",
            raw_path=ledger_raw_root / f"{ledger_request_sha256}.json",
            parser=lambda raw: parse_handoff_ledger(
                raw,
                trace=trace,
            ).to_dict(),
            retry_failures=retry_failures,
        )

        selector_record: dict[str, Any] | None = None
        selector_cache_hit = False
        ledger: HandoffLedger | None = None
        if str(ledger_record.get("status", "")).startswith("success"):
            ledger = parse_handoff_ledger(
                ledger_record["raw_output"],
                trace=trace,
            )
            selector_messages = handoff_selector_messages(trace, ledger)
            selector_request_sha256, selector_prompt_sha256 = _stage_identity(
                stage="handoff_selector",
                entry=entry,
                prepared_manifest_sha256=manifest_sha256,
                messages=selector_messages,
                config=config,
                dependency_sha256=ledger_record["raw_response_sha256"],
            )
            selector_expected = _stage_expected(
                stage="handoff_selector",
                manifest_sha256=manifest_sha256,
                entry=entry,
                request_sha256=selector_request_sha256,
                prompt_sha256=selector_prompt_sha256,
                config=config,
            )
            selector_record, selector_cache_hit = _run_stage(
                stage="handoff_selector",
                messages=selector_messages,
                complete=complete,
                expected=selector_expected,
                cache_path=selector_cache_root
                / f"{selector_request_sha256}.json",
                raw_path=selector_raw_root
                / f"{selector_request_sha256}.json",
                parser=lambda raw: parse_handoff_selector(
                    raw,
                    trace=trace,
                ).to_dict(),
                retry_failures=retry_failures,
            )

        final_stage = selector_record or ledger_record
        record: dict[str, Any] = {
            "schema_version": HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION,
            "method": HANDOFF_REPLAY_METHOD,
            "replay_pipeline_version": HANDOFF_REPLAY_PIPELINE_VERSION,
            "prepared_manifest_sha256": manifest_sha256,
            "trajectory_id": entry["trajectory_id"],
            "trajectory_sha256": entry["trajectory_sha256"],
            "case_input_sha256": entry["case_input_sha256"],
            "request_sha256": (
                selector_record["request_sha256"]
                if selector_record is not None
                else ledger_record["request_sha256"]
            ),
            "ledger_request_sha256": ledger_record["request_sha256"],
            "selector_request_sha256": (
                selector_record["request_sha256"]
                if selector_record is not None
                else None
            ),
            "prompt_sha256": (
                selector_record["prompt_sha256"]
                if selector_record is not None
                else ledger_record["prompt_sha256"]
            ),
            "ledger_prompt_sha256": ledger_record["prompt_sha256"],
            "selector_prompt_sha256": (
                selector_record["prompt_sha256"]
                if selector_record is not None
                else None
            ),
            "prompt_protocol_version": HANDOFF_PROMPT_PROTOCOL_VERSION,
            "judge_view_version": JUDGE_VIEW_VERSION,
            "diagnostic_pipeline_version": DIAGNOSTIC_PIPELINE_VERSION,
            "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
            "transport_policy_version": TRANSPORT_POLICY_VERSION,
            "provider_config": config.public_dict(),
            "handoff_ledger": (
                ledger.to_dict() if ledger is not None else None
            ),
            "raw_handoff_ledger_output": ledger_record["raw_output"],
            "raw_handoff_selector_output": (
                selector_record["raw_output"]
                if selector_record is not None
                else None
            ),
            "raw_response_sha256": _sha256_value(
                {
                    "handoff_ledger": ledger_record["raw_output"],
                    "handoff_selector": (
                        selector_record["raw_output"]
                        if selector_record is not None
                        else None
                    ),
                }
            ),
            "root_cause": None,
            "candidate_evidence_validation_issues": [],
            "evidence_validation_issues": [],
            "status": final_stage.get("status"),
            "failure_stage": final_stage.get("failure_stage"),
            "failure_code": final_stage.get("failure_code"),
            "failure_message": final_stage.get("failure_message"),
            "latency_seconds": time.monotonic() - started,
            "cache_hit": ledger_cache_hit and selector_cache_hit,
            "stage_cache_hits": {
                "handoff_ledger": ledger_cache_hit,
                "handoff_selector": selector_cache_hit,
            },
            "stage_attempted": {
                "handoff_ledger": True,
                "handoff_selector": selector_record is not None,
            },
        }
        if ledger is not None:
            candidate_issues: list[dict[str, Any]] = []
            for index, candidate in enumerate(ledger.candidates):
                validation = validate_evidence(
                    trace,
                    candidate,
                    stage=f"handoff_ledger.candidates[{index}]",
                )
                candidate_issues.extend(
                    issue.to_dict() for issue in validation.issues
                )
            record["candidate_evidence_validation_issues"] = (
                candidate_issues
            )
        if (
            selector_record is not None
            and str(selector_record.get("status", "")).startswith("success")
        ):
            root = parse_handoff_selector(
                selector_record["raw_output"],
                trace=trace,
            )
            validation = validate_evidence(
                trace,
                root,
                stage="handoff_selector",
            )
            record["root_cause"] = root.to_dict()
            record["evidence_validation_issues"] = [
                issue.to_dict() for issue in validation.issues
            ]
            if not validation.valid:
                record.update(
                    {
                        "status": "evidence_invalid",
                        "failure_stage": "evidence_validation",
                        "failure_code": "invalid_evidence",
                    }
                )
            elif validation.needs_review:
                record["status"] = "success_needs_review"
            else:
                record["status"] = "success"
        _assert_gold_free(record, location="unscored E5c prediction")
        _validate_handoff_prediction_record(
            record,
            entry=entry,
            manifest=manifest,
            config=config,
        )
        results.append(record)
        _atomic_write_jsonl(output_path, results)
    return results


__all__ = [
    "HANDOFF_PROMPT_PROTOCOL_VERSION",
    "HANDOFF_REPLAY_METHOD",
    "HANDOFF_REPLAY_PIPELINE_VERSION",
    "HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION",
    "HANDOFF_REPLAY_RUN_SCHEMA_VERSION",
    "HandoffLedger",
    "handoff_ledger_messages",
    "handoff_selector_messages",
    "parse_handoff_ledger",
    "parse_handoff_selector",
    "predict_handoff_replay",
]

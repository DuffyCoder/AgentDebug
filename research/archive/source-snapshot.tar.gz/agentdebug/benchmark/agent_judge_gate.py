"""Gold-free deterministic slices for inexpensive Agent Judge gates.

The gate is derived only from a frozen public cohort and its matching
prediction manifest.  It selects the first ``N`` ranked entries in each
environment, then rewrites every identity that depends on cohort membership.
No benchmark label or scored prediction is accepted by this module.

Only first-stage cohorts (currently ``tuning-v1``) are sliceable.  A cohort
with prior reservations cannot be truncated safely from its own public files:
rebuilding that cohort at a smaller size changes the prior reservation set.
Failing closed keeps every emitted cohort compatible with the benchmark's
deterministic :func:`load_cohort_manifest` validation.
"""

from __future__ import annotations

import copy
import json
import os
from pathlib import Path
from typing import Any, Mapping

from .cohort import COHORT_SCHEMA_VERSION, SELECTION_ALGORITHM
from .prediction_manifest import load_prediction_manifest, stable_sha256


DEFAULT_GATE_PER_ENVIRONMENT = 3
GATE_COHORT_FILENAME = "cohort.json"
GATE_PREDICTION_MANIFEST_FILENAME = "prediction-manifest.json"


class AgentJudgeGateError(ValueError):
    """A gold-free Agent Judge gate cannot be derived safely."""


_FORBIDDEN_KEYS = {
    "all_correct",
    "confidence",
    "critical_failure_module",
    "critical_failure_step",
    "critical_failure_type",
    "gold_error_type",
    "gold_event_id",
    "gold_module",
    "gold_normalization_notes",
    "gold_raw_error_type",
    "gold_raw_module",
    "gold_reasoning",
    "gold_step",
    "predicted_error_type",
    "predicted_event_id",
    "predicted_module",
    "predicted_step",
    "score",
    "step_annotations",
    "step_exact",
    "step_module_exact",
}


def _read_json(path: Path, *, role: str) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise AgentJudgeGateError(f"{role} is missing or invalid JSON") from error


def _assert_gold_free(value: Any, *, location: str) -> None:
    if isinstance(value, Mapping):
        for key, item in value.items():
            normalized = str(key).casefold()
            if normalized in _FORBIDDEN_KEYS or normalized.startswith("gold_"):
                raise AgentJudgeGateError(
                    f"{location} contains forbidden gold/scored field {key!r}"
                )
            _assert_gold_free(item, location=f"{location}.{key}")
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _assert_gold_free(item, location=f"{location}[{index}]")


def _nonempty_text(value: Any, *, location: str) -> str:
    if not isinstance(value, str) or not value:
        raise AgentJudgeGateError(f"{location} must be non-empty text")
    return value


def _load_and_validate_cohort(path: Path) -> dict[str, Any]:
    document = _read_json(path, role="source cohort manifest")
    if not isinstance(document, dict):
        raise AgentJudgeGateError("source cohort manifest must be an object")
    _assert_gold_free(document, location="source cohort manifest")
    expected_fields = {
        "schema_version",
        "cohort_name",
        "dataset_manifest_sha256",
        "selection",
        "trajectory_ids",
        "entries",
        "conversion_exclusions",
        "cohort_sha256",
    }
    if set(document) != expected_fields:
        raise AgentJudgeGateError(
            "source cohort manifest fields do not match the public schema"
        )
    if document["schema_version"] != COHORT_SCHEMA_VERSION:
        raise AgentJudgeGateError("source cohort schema version is unsupported")

    claimed_hash = document["cohort_sha256"]
    body = dict(document)
    body.pop("cohort_sha256")
    if claimed_hash != stable_sha256(body):
        raise AgentJudgeGateError("source cohort content hash is invalid")

    cohort_name = _nonempty_text(
        document["cohort_name"], location="source cohort cohort_name"
    )
    dataset_sha = _nonempty_text(
        document["dataset_manifest_sha256"],
        location="source cohort dataset_manifest_sha256",
    )
    selection = document["selection"]
    if not isinstance(selection, Mapping):
        raise AgentJudgeGateError("source cohort selection must be an object")
    expected_selection_fields = {
        "algorithm",
        "rank_input_fields",
        "salt",
        "environments",
        "per_environment",
        "disjoint_from",
        "reserved_trajectory_ids",
        "eligibility_rule",
    }
    if set(selection) != expected_selection_fields:
        raise AgentJudgeGateError(
            "source cohort selection fields do not match the public schema"
        )
    if selection.get("algorithm") != SELECTION_ALGORITHM:
        raise AgentJudgeGateError("source cohort selection algorithm is unsupported")
    if selection.get("rank_input_fields") != [
        "environment",
        "trajectory_id",
        "dataset_manifest_sha256",
        "salt",
    ]:
        raise AgentJudgeGateError("source cohort rank input fields are invalid")
    salt = _nonempty_text(
        selection.get("salt"), location="source cohort selection salt"
    )
    environments = selection.get("environments")
    source_per_environment = selection.get("per_environment")
    if (
        not isinstance(environments, list)
        or not environments
        or any(not isinstance(item, str) or not item for item in environments)
        or len(set(environments)) != len(environments)
    ):
        raise AgentJudgeGateError("source cohort environments are invalid")
    if (
        isinstance(source_per_environment, bool)
        or not isinstance(source_per_environment, int)
        or source_per_environment < 1
    ):
        raise AgentJudgeGateError("source cohort per_environment is invalid")

    # With a prior cohort, reducing N changes which IDs are reserved before
    # this cohort is ranked.  The source cohort alone cannot prove the smaller
    # deterministic selection, so fail instead of emitting a misleading gate.
    if selection.get("disjoint_from") not in (None, []):
        raise AgentJudgeGateError(
            f"cohort {cohort_name!r} has prior disjoint reservations and "
            "cannot be sliced from public inputs alone"
        )
    if selection.get("reserved_trajectory_ids") not in (None, []):
        raise AgentJudgeGateError(
            f"cohort {cohort_name!r} has reserved trajectory IDs and cannot "
            "be sliced from public inputs alone"
        )

    trajectory_ids = document["trajectory_ids"]
    entries = document["entries"]
    expected_count = len(environments) * source_per_environment
    if (
        not isinstance(trajectory_ids, list)
        or len(trajectory_ids) != expected_count
        or any(not isinstance(item, str) or not item for item in trajectory_ids)
        or len(set(trajectory_ids)) != len(trajectory_ids)
    ):
        raise AgentJudgeGateError("source cohort trajectory order/count is invalid")
    if not isinstance(entries, list) or len(entries) != expected_count:
        raise AgentJudgeGateError("source cohort entries/count is invalid")

    cursor = 0
    for environment in environments:
        for rank in range(1, source_per_environment + 1):
            entry = entries[cursor]
            trajectory_id = trajectory_ids[cursor]
            if not isinstance(entry, Mapping) or set(entry) != {
                "environment",
                "trajectory_id",
                "rank",
                "selection_sha256",
            }:
                raise AgentJudgeGateError(
                    f"source cohort entry {cursor} does not match the schema"
                )
            if (
                entry.get("environment") != environment
                or entry.get("trajectory_id") != trajectory_id
                or entry.get("rank") != rank
            ):
                raise AgentJudgeGateError(
                    "source cohort entries are not in environment/rank order"
                )
            expected_selection_sha = stable_sha256(
                [environment, trajectory_id, dataset_sha, salt]
            )
            if entry.get("selection_sha256") != expected_selection_sha:
                raise AgentJudgeGateError(
                    f"source cohort selection digest is invalid for {trajectory_id!r}"
                )
            cursor += 1
    return document


def _expected_selection_identity(
    cohort: Mapping[str, Any],
) -> dict[str, Any]:
    trajectory_ids = list(cohort["trajectory_ids"])
    return {
        "selection_name": cohort["cohort_name"],
        "cohort_sha256": cohort["cohort_sha256"],
        "trajectory_ids": trajectory_ids,
        "execution_order": "cohort-manifest",
        "expected_count": len(trajectory_ids),
    }


def _build_gate_documents(
    *,
    manifest: Mapping[str, Any],
    cohort: Mapping[str, Any],
    per_environment: int,
) -> tuple[dict[str, Any], dict[str, Any]]:
    if (
        isinstance(per_environment, bool)
        or not isinstance(per_environment, int)
        or per_environment < 1
    ):
        raise AgentJudgeGateError("per_environment must be a positive integer")
    source_per_environment = cohort["selection"]["per_environment"]
    if per_environment > source_per_environment:
        raise AgentJudgeGateError(
            "per_environment exceeds the frozen source cohort size"
        )

    selected_entries = [
        copy.deepcopy(entry)
        for entry in cohort["entries"]
        if entry["rank"] <= per_environment
    ]
    selected_ids = [entry["trajectory_id"] for entry in selected_entries]

    gate_cohort = copy.deepcopy(dict(cohort))
    gate_cohort["selection"]["per_environment"] = per_environment
    gate_cohort["trajectory_ids"] = selected_ids
    gate_cohort["entries"] = selected_entries
    gate_cohort.pop("cohort_sha256", None)
    gate_cohort["cohort_sha256"] = stable_sha256(gate_cohort)

    source_by_id = {
        entry["trajectory_id"]: entry for entry in manifest["entries"]
    }
    gate_manifest = copy.deepcopy(dict(manifest))
    gate_manifest["cohort_sha256"] = gate_cohort["cohort_sha256"]
    gate_manifest["selection_identity"] = _expected_selection_identity(
        gate_cohort
    )
    gate_manifest["entry_count"] = len(selected_ids)
    gate_manifest["entries"] = [source_by_id[item] for item in selected_ids]
    gate_manifest.pop("prediction_manifest_sha256", None)
    gate_manifest["prediction_manifest_sha256"] = stable_sha256(gate_manifest)
    return gate_cohort, gate_manifest


def _json_text(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n"


def _preflight_write_once(path: Path, text: str, *, role: str) -> bool:
    """Return whether a new file is needed; reject any existing conflict."""

    if not path.exists():
        return True
    if not path.is_file():
        raise AgentJudgeGateError(f"existing {role} is not a file")
    try:
        existing = path.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as error:
        raise AgentJudgeGateError(f"existing {role} is unreadable") from error
    if existing != text:
        raise AgentJudgeGateError(
            f"existing {role} conflicts with the deterministic gate slice"
        )
    return False


def _atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(text, encoding="utf-8")
    temporary.replace(path)


def create_agent_judge_gate_slice(
    *,
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    output_dir: str | Path,
    per_environment: int = DEFAULT_GATE_PER_ENVIRONMENT,
) -> dict[str, Any]:
    """Create a write-once, label-free prefix gate from frozen public inputs.

    The output files are ``cohort.json`` and ``prediction-manifest.json`` in
    ``output_dir``.  Repeating the same call is idempotent; any existing file
    with different bytes causes the operation to fail before either output is
    mutated.
    """

    prediction_path = Path(prediction_manifest_path).expanduser().resolve()
    cohort_path = Path(cohort_manifest_path).expanduser().resolve()
    root = Path(output_dir).expanduser().resolve()
    if root.exists() and not root.is_dir():
        raise AgentJudgeGateError("gate output path is not a directory")

    cohort = _load_and_validate_cohort(cohort_path)
    try:
        manifest, cases = load_prediction_manifest(prediction_path)
    except (OSError, TypeError, ValueError) as error:
        raise AgentJudgeGateError(
            "source prediction manifest failed closed validation"
        ) from error
    _assert_gold_free(manifest, location="source prediction manifest")

    cohort_ids = cohort["trajectory_ids"]
    manifest_ids = [case.trajectory_id for case in cases]
    if manifest_ids != cohort_ids:
        raise AgentJudgeGateError(
            "source prediction manifest and cohort case order differ"
        )
    if (
        manifest["dataset_manifest_sha256"]
        != cohort["dataset_manifest_sha256"]
        or manifest["cohort_name"] != cohort["cohort_name"]
        or manifest["cohort_sha256"] != cohort["cohort_sha256"]
    ):
        raise AgentJudgeGateError(
            "source prediction manifest and cohort lineage differ"
        )
    if manifest["selection_identity"] != _expected_selection_identity(cohort):
        raise AgentJudgeGateError(
            "source prediction manifest selection identity is not canonical"
        )

    gate_cohort, gate_manifest = _build_gate_documents(
        manifest=manifest,
        cohort=cohort,
        per_environment=per_environment,
    )
    cohort_output = root / GATE_COHORT_FILENAME
    prediction_output = root / GATE_PREDICTION_MANIFEST_FILENAME
    if cohort_output == prediction_output:
        raise AgentJudgeGateError("gate output paths collide")
    cohort_text = _json_text(gate_cohort)
    prediction_text = _json_text(gate_manifest)

    # Check both destinations before writing either one.  A conflicting rerun
    # therefore cannot leave a half-updated gate pair.
    write_cohort = _preflight_write_once(
        cohort_output, cohort_text, role="gate cohort manifest"
    )
    write_prediction = _preflight_write_once(
        prediction_output,
        prediction_text,
        role="gate prediction manifest",
    )
    if write_cohort:
        _atomic_text(cohort_output, cohort_text)
    if write_prediction:
        _atomic_text(prediction_output, prediction_text)

    return {
        "gold_free": True,
        "source_prediction_manifest_path": str(prediction_path),
        "source_cohort_manifest_path": str(cohort_path),
        "per_environment": per_environment,
        "entry_count": gate_manifest["entry_count"],
        "cohort_path": str(cohort_output),
        "cohort_sha256": gate_cohort["cohort_sha256"],
        "prediction_manifest_path": str(prediction_output),
        "prediction_manifest_sha256": gate_manifest[
            "prediction_manifest_sha256"
        ],
    }


__all__ = [
    "DEFAULT_GATE_PER_ENVIRONMENT",
    "GATE_COHORT_FILENAME",
    "GATE_PREDICTION_MANIFEST_FILENAME",
    "AgentJudgeGateError",
    "create_agent_judge_gate_slice",
]

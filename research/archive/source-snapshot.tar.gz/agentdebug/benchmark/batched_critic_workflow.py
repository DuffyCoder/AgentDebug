"""Gold-free cache and budget boundary for candidate-plus-selector diagnosis.

V14 deliberately treats the already-paid v13 Scout and Arbiter responses as
an immutable, untrusted semantic predecessor.  The predecessor cache is never
opened through the mutating recovery path in :mod:`stage_cache`; every source
file is hash checked and read only.  A separate content-addressed cache is
used for candidate generation and independent final selection.

This module contains no Critic prompt.  The judge layer supplies the messages
and raw-output parser.  Consequently prompt iteration cannot accidentally
weaken the source-cache, gold-isolation, or logical-completion boundary.
"""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Literal, Mapping, Sequence

from agentdebug.diagnostics.batched_causal_judge import (
    BATCHED_ARBITER_STAGE,
    BATCHED_SCOUT_STAGE,
    BatchedAdjudication,
    BatchedCase,
    parse_batched_arbiter_isolated,
    parse_batched_scout_isolated,
)
from agentdebug.diagnostics.batched_critic_judge import (
    BATCHED_CRITIC_PIPELINE_VERSION as V14_PIPELINE_VERSION,
    BATCHED_CRITIC_PROMPT_PROTOCOL_VERSION as V14_CRITIC_PROMPT_PROTOCOL_VERSION,
    BATCHED_CRITIC_STAGE as V14_CRITIC_STAGE,
    BATCHED_SELECTOR_PROMPT_PROTOCOL_VERSION as V14_SELECTOR_PROMPT_PROTOCOL_VERSION,
    BATCHED_SELECTOR_STAGE as V14_SELECTOR_STAGE,
    BatchedModuleCensus,
    batched_critic_messages,
    batched_selector_messages,
    build_selector_candidate_bundles,
    parse_batched_critic_isolated,
    parse_batched_selector_isolated,
)
from agentdebug.diagnostics.judge_view import JUDGE_VIEW_VERSION
from agentdebug.diagnostics.parsing import JudgeOutputError

from . import batched_causal_workflow as _v13
from .cohort import CohortManifest
from .fresh_semantic_workflow import (
    DurableLogicalCompletionBudget,
    load_fresh_semantic_completion_ledger,
)
from .metrics import compute_metrics
from .models import BenchmarkDataset
from .prediction_manifest import PredictionCase, load_prediction_manifest
from .runner import (
    TRANSPORT_POLICY_VERSION,
    BenchmarkRunConfig,
    _apply_root,
    _base_record,
)

from .stage_cache import (
    RAW_RESPONSE_SIDECAR_SCHEMA_VERSION,
    RAW_STAGE_SCHEMA_VERSION,
    STAGE_CACHE_SCHEMA_VERSION,
    StageRequest,
    build_stage_request,
    run_cached_stage,
    stable_sha256,
    sum_stage_telemetry,
)


V14_EXPERIMENT = (
    "e9_v54_contradiction_first_planning_deepseek_v4_flash_default_body"
)
V14_SEMANTIC_CLASSIFIER = "raw_independent_batch_selector_output"
V14_PREDICTION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-unscored-prediction.v26"
)
V14_PREDICT_RUN_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-v54-contradiction-first-planning-predict-run.v1"
)
V14_EVIDENCE_VALIDATION_VERSION = (
    "e9-v54-raw-selector-contradiction-first-planning-source-id-no-fallback"
)
V14_FROZEN_PREDECESSOR_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-v14-frozen-v13-predecessor.v1"
)
V14_FROZEN_PREDECESSOR_ROLE = (
    "rejected_v13_gold_free_llm_semantic_predecessor"
)
# User authorization is cumulative-unbounded.  Every phase remains bounded by
# its exact topology-derived hard stop and durable logical-completion ledger.
V14_IMPLEMENTATION_CUMULATIVE_CEILING: None = None
V14_MAXIMUM_CRITIC_REQUEST_CHARS = _v13.MAXIMUM_REQUEST_CHARS
V14_MAXIMUM_SELECTOR_REQUEST_CHARS = 900_000
V14_UPSTREAM_FROZEN = "frozen_v13_tuning"
V14_UPSTREAM_FRESH = "fresh_four_stage_smoke"
V14_UPSTREAM_MODES = (V14_UPSTREAM_FROZEN, V14_UPSTREAM_FRESH)
V52_RECOVERY_CONTRACT_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-v52-http402-full30-recovery-contract.v1"
)

V13_EXPERIMENT = (
    "e9_v13_atomic_taxonomy_pair_scout_causal_arbiter_judge"
)
V13_PIPELINE_VERSION = "e9-batched-semantic-candidate-scout-arbiter-v13"
V13_PREDICTION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-unscored-prediction.v11"
)
V13_SCOUT_STAGE = "batched_causal_scout"
V13_ARBITER_STAGE = "batched_causal_arbiter"
V13_SCOUT_PROMPT_PROTOCOL_VERSION = (
    "agentdebug-e9-scout-v13-atomic-taxonomy-pair"
)
V13_ARBITER_PROMPT_PROTOCOL_VERSION = (
    "agentdebug-e9-arbiter-v12-independent-review-capability-history"
)
V13_EVIDENCE_VALIDATION_VERSION = (
    "e9-raw-arbiter-same-step-owner-exact-substring-no-length-cap-v13"
)
V13_SCOUT_CACHE_COMPATIBILITY_VERSION = (
    "e9-v13-fresh-atomic-taxonomy-pair-scout-v13"
)
V13_SOURCE_STAGES = (V13_SCOUT_STAGE, V13_ARBITER_STAGE)
V14_ACTIVE_STAGES = (V14_CRITIC_STAGE, V14_SELECTOR_STAGE)
V14_ALL_STAGES = (*V13_SOURCE_STAGES, *V14_ACTIVE_STAGES)

_SHA256_CHARACTERS = frozenset("0123456789abcdef")
_PRIOR_ROOT_FIELDS = {
    "critical_step",
    "module",
    "error_type",
    "evidence_quote",
    "root_cause",
}
_FORBIDDEN_KEYS = {
    "all_correct",
    "confidence",
    "critical_failure_module",
    "critical_failure_step",
    "critical_failure_type",
    "deterministic_finding",
    "gold_error_type",
    "gold_event_id",
    "gold_module",
    "gold_normalization_notes",
    "gold_raw_error_type",
    "gold_raw_module",
    "gold_reasoning",
    "gold_step",
    "likelihood",
    "likelihoods",
    "priority",
    "priorities",
    "probabilities",
    "probability",
    "rank",
    "rating",
    "ratings",
    "score",
    "scores",
    "severity",
    "step_annotations",
    "step_exact",
    "step_module_exact",
    "vote",
    "votes",
    "weight",
    "weights",
}


class BatchedCriticWorkflowError(ValueError):
    """A v14 source, request, cache, or budget binding is unsafe."""


@dataclass(frozen=True)
class FrozenV13StageSpec:
    """One exact v13 request used while freezing the read-only source."""

    batch_id: str
    case_keys: tuple[str, ...]
    ordered_case_input_sha256s: tuple[str, ...]
    request: StageRequest
    messages: tuple[Mapping[str, str], ...]


@dataclass(frozen=True)
class FrozenV13StageResponse:
    """One verified immutable v13 response and its normalized sidecar."""

    stage: str
    request_sha256: str
    prompt_sha256: str
    dependency_sha256: str
    raw_response_sha256: str
    raw_response: Any
    parsed_output: Any
    status: str
    failure_stage: str | None
    failure_code: str | None
    failure_message: str | None
    identity: dict[str, Any]
    stage_telemetry: dict[str, Any] | None
    latency_seconds: float


@dataclass(frozen=True)
class FrozenV13BatchSource:
    """The exact two-stage source for one anonymous v13 batch."""

    predecessor_manifest_sha256: str
    batch_binding_sha256: str
    batch_id: str
    case_keys: tuple[str, ...]
    ordered_case_input_sha256s: tuple[str, ...]
    scout: FrozenV13StageResponse
    arbiter: FrozenV13StageResponse
    upstream_mode: str = V14_UPSTREAM_FROZEN

    def critic_dependency(self) -> dict[str, Any]:
        """Return the complete semantic-source dependency for a Critic key."""

        return {
            "upstream_mode": self.upstream_mode,
            "predecessor_manifest_sha256": (
                self.predecessor_manifest_sha256
            ),
            "batch_binding_sha256": self.batch_binding_sha256,
            "batch_id": self.batch_id,
            "case_keys": list(self.case_keys),
            "ordered_case_input_sha256s": list(
                self.ordered_case_input_sha256s
            ),
            "stages": {
                V13_SCOUT_STAGE: {
                    "request_sha256": self.scout.request_sha256,
                    "prompt_sha256": self.scout.prompt_sha256,
                    "dependency_sha256": self.scout.dependency_sha256,
                    "raw_response_sha256": self.scout.raw_response_sha256,
                    "status": self.scout.status,
                },
                V13_ARBITER_STAGE: {
                    "request_sha256": self.arbiter.request_sha256,
                    "prompt_sha256": self.arbiter.prompt_sha256,
                    "dependency_sha256": self.arbiter.dependency_sha256,
                    "raw_response_sha256": self.arbiter.raw_response_sha256,
                    "status": self.arbiter.status,
                },
            },
        }


@dataclass(frozen=True)
class FrozenV13Predecessor:
    """A loaded v13 source manifest whose cache must remain immutable."""

    manifest_path: Path
    source_cache_dir: Path
    document: dict[str, Any]
    upstream_mode: str = V14_UPSTREAM_FROZEN

    @property
    def manifest_sha256(self) -> str:
        return str(self.document["predecessor_manifest_sha256"])

    def load_batch(
        self,
        *,
        batch_id: str,
        case_keys: Sequence[str],
        ordered_case_input_sha256s: Sequence[str],
    ) -> FrozenV13BatchSource:
        """Read one source batch without any recovery write or completion."""

        _assert_directory_state(
            self.source_cache_dir,
            self.document["source_cache_state"],
        )
        expected_keys = tuple(str(value) for value in case_keys)
        expected_inputs = tuple(
            _sha256(value, field="ordered_case_input_sha256")
            for value in ordered_case_input_sha256s
        )
        matching = [
            item
            for item in self.document["batches"]
            if item["batch_id"] == batch_id
        ]
        if len(matching) != 1:
            raise BatchedCriticWorkflowError(
                "frozen v13 predecessor lacks the exact batch identity"
            )
        batch = matching[0]
        if (
            tuple(batch["case_keys"]) != expected_keys
            or tuple(batch["ordered_case_input_sha256s"]) != expected_inputs
        ):
            raise BatchedCriticWorkflowError(
                "frozen v13 predecessor batch/case binding diverged"
            )
        stages = batch["stages"]
        scout = _read_frozen_stage(
            cache_dir=self.source_cache_dir,
            binding=stages[V13_SCOUT_STAGE],
        )
        arbiter = _read_frozen_stage(
            cache_dir=self.source_cache_dir,
            binding=stages[V13_ARBITER_STAGE],
        )
        _validate_source_stage_pair(
            batch_id=batch_id,
            case_keys=expected_keys,
            ordered_case_input_sha256s=expected_inputs,
            scout=scout,
            arbiter=arbiter,
            scout_identity=stages[V13_SCOUT_STAGE]["identity"],
            arbiter_identity=stages[V13_ARBITER_STAGE]["identity"],
        )
        # Close the check/read race for any other source file in the frozen
        # directory.  Individual file hashes already close it for this pair.
        _assert_directory_state(
            self.source_cache_dir,
            self.document["source_cache_state"],
        )
        return FrozenV13BatchSource(
            predecessor_manifest_sha256=self.manifest_sha256,
            batch_binding_sha256=batch["batch_binding_sha256"],
            batch_id=batch_id,
            case_keys=expected_keys,
            ordered_case_input_sha256s=expected_inputs,
            scout=scout,
            arbiter=arbiter,
            upstream_mode=self.upstream_mode,
        )


@dataclass(frozen=True)
class V14BudgetContract:
    """Exact preregisterable logical-completion budget for one phase."""

    profile: str
    batch_count: int
    cumulative_before: int
    maximum_new: int
    hard_cumulative_stop: int
    authorized_cumulative_ceiling: int
    implementation_cumulative_ceiling: int | None = (
        V14_IMPLEMENTATION_CUMULATIVE_CEILING
    )

    def to_dict(self) -> dict[str, Any]:
        return {
            "profile": self.profile,
            "batch_count": self.batch_count,
            "cumulative_before": self.cumulative_before,
            "maximum_new": self.maximum_new,
            "hard_cumulative_stop": self.hard_cumulative_stop,
            "authorized_cumulative_ceiling": (
                self.authorized_cumulative_ceiling
            ),
            "implementation_cumulative_ceiling": (
                self.implementation_cumulative_ceiling
            ),
        }


def _validated_v52_recovery_contract(value: Any) -> dict[str, Any]:
    """Validate the narrow post-402 full30 recovery authorization."""

    if not isinstance(value, Mapping):
        raise BatchedCriticWorkflowError("v52 recovery contract is invalid")
    document = dict(value)
    expected_fields = {
        "schema_version",
        "source_attempt_preregistration_sha256",
        "source_attempt_ledger_sha256",
        "source_partial_predictions_sha256",
        "source_case_study_sha256",
        "source_cache_state",
        "recovery_cache_initial_state",
        "source_logical_reservations",
        "successful_row_count",
        "failed_row_count",
        "failed_batch_id",
        "failed_critic_request_sha256",
        "failed_selector_request_sha256",
        "cumulative_before",
        "maximum_new",
        "first_batch_index",
        "retry_failures",
        "contract_sha256",
    }
    body = dict(document)
    claimed = body.pop("contract_sha256", None)
    cache_state = document.get("source_cache_state")
    recovery_cache_state = document.get("recovery_cache_initial_state")
    digest_fields = (
        "source_attempt_preregistration_sha256",
        "source_attempt_ledger_sha256",
        "source_partial_predictions_sha256",
        "source_case_study_sha256",
        "failed_critic_request_sha256",
        "failed_selector_request_sha256",
    )
    if (
        set(document) != expected_fields
        or document.get("schema_version")
        != V52_RECOVERY_CONTRACT_SCHEMA_VERSION
        or claimed != stable_sha256(body)
        or any(
            not isinstance(document.get(field), str)
            or len(document[field]) != 64
            or any(character not in "0123456789abcdef" for character in document[field])
            for field in digest_fields
        )
        or not isinstance(cache_state, Mapping)
        or set(cache_state) != {"file_count", "files_sha256"}
        or cache_state.get("file_count") != 48
        or not isinstance(cache_state.get("files_sha256"), str)
        or len(cache_state["files_sha256"]) != 64
        or any(
            character not in _SHA256_CHARACTERS
            for character in cache_state["files_sha256"]
        )
        or not isinstance(recovery_cache_state, Mapping)
        or set(recovery_cache_state) != {"file_count", "files_sha256"}
        or recovery_cache_state.get("file_count") != 42
        or not isinstance(recovery_cache_state.get("files_sha256"), str)
        or len(recovery_cache_state["files_sha256"]) != 64
        or any(
            character not in _SHA256_CHARACTERS
            for character in recovery_cache_state["files_sha256"]
        )
        or document.get("source_logical_reservations") != 14
        or document.get("successful_row_count") != 18
        or document.get("failed_row_count") != 3
        or document.get("failed_batch_id") != "B264a53a2d3d40ffd4a50"
        or document.get("cumulative_before") != 632
        or document.get("maximum_new") != 8
        or document.get("first_batch_index") != 8
        or document.get("retry_failures") is not True
    ):
        raise BatchedCriticWorkflowError("v52 recovery contract is invalid")
    return document


@dataclass(frozen=True)
class BatchedCriticStageResult:
    """One final-Critic stage outcome plus its immutable source binding."""

    record: dict[str, Any]
    cache_hit: bool
    request: StageRequest
    predecessor: FrozenV13BatchSource
    semantic_classifier: str = V14_SEMANTIC_CLASSIFIER


@dataclass(frozen=True)
class ValidatedBatchedCriticArtifacts:
    """Complete gold-free proof reconstructed before scoring labels."""

    prediction_manifest: dict[str, Any]
    cases: tuple[PredictionCase, ...]
    plan: _v13.BatchPlan
    source_plan: _v13.BatchPlan
    rows: tuple[dict[str, Any], ...]
    run: dict[str, Any]
    config: BenchmarkRunConfig
    predecessor: FrozenV13Predecessor


def _sha256(value: Any, *, field: str) -> str:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or value != value.lower()
        or any(character not in _SHA256_CHARACTERS for character in value)
    ):
        raise BatchedCriticWorkflowError(
            f"{field} must be one lowercase SHA-256 digest"
        )
    return value


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _read_object(path: Path, *, location: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise BatchedCriticWorkflowError(f"{location} is corrupt") from error
    if not isinstance(value, dict):
        raise BatchedCriticWorkflowError(f"{location} must be an object")
    return value


def _atomic_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def _directory_state(root: Path) -> dict[str, Any]:
    files: dict[str, str] = {}
    if root.is_dir():
        for path in sorted(
            (item for item in root.rglob("*") if item.is_file()),
            key=lambda item: str(item),
        ):
            files[str(path.relative_to(root))] = _file_sha256(path)
    return {
        "file_count": len(files),
        "files_sha256": stable_sha256(files),
    }


def _assert_directory_state(root: Path, expected: Any) -> None:
    if (
        not isinstance(expected, Mapping)
        or set(expected) != {"file_count", "files_sha256"}
        or isinstance(expected.get("file_count"), bool)
        or not isinstance(expected.get("file_count"), int)
        or expected["file_count"] < 0
    ):
        raise BatchedCriticWorkflowError(
            "frozen v13 source-cache state is invalid"
        )
    _sha256(expected.get("files_sha256"), field="source files_sha256")
    if _directory_state(root) != dict(expected):
        raise BatchedCriticWorkflowError(
            "frozen v13 source cache is missing or drifted"
        )


def _assert_gold_free(value: Any, *, location: str) -> None:
    if isinstance(value, Mapping):
        for key, item in value.items():
            normalized = str(key).casefold()
            if normalized.startswith("gold_") or normalized in _FORBIDDEN_KEYS:
                raise BatchedCriticWorkflowError(
                    f"{location} contains forbidden evaluator field {key!r}"
                )
            _assert_gold_free(item, location=f"{location}.{key}")
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _assert_gold_free(item, location=f"{location}[{index}]")


def _safe_relative_path(root: Path, value: Any, *, field: str) -> Path:
    if not isinstance(value, str) or not value:
        raise BatchedCriticWorkflowError(f"{field} is invalid")
    relative = Path(value)
    if relative.is_absolute() or ".." in relative.parts:
        raise BatchedCriticWorkflowError(f"{field} escapes the source cache")
    resolved = (root / relative).resolve()
    if not resolved.is_relative_to(root):
        raise BatchedCriticWorkflowError(f"{field} escapes the source cache")
    return resolved


def _validate_v13_request(
    spec: FrozenV13StageSpec,
) -> None:
    request = spec.request
    if request.stage not in V13_SOURCE_STAGES:
        raise BatchedCriticWorkflowError(
            "frozen v13 source contains an unsupported stage"
        )
    if (
        not spec.batch_id
        or not spec.case_keys
        or len(spec.case_keys) != len(spec.ordered_case_input_sha256s)
        or len(set(spec.case_keys)) != len(spec.case_keys)
    ):
        raise BatchedCriticWorkflowError(
            "frozen v13 stage has an invalid batch/case binding"
        )
    case_hashes = tuple(
        _sha256(value, field="ordered_case_input_sha256")
        for value in spec.ordered_case_input_sha256s
    )
    trajectory_hashes = tuple(
        _sha256(value, field="ordered_trajectory_sha256")
        for value in request.identity.get(
            "ordered_trajectory_sha256s", ()
        )
    )
    view_hashes = tuple(
        _sha256(value, field="ordered_judge_view_sha256")
        for value in request.identity.get(
            "ordered_judge_view_sha256s", ()
        )
    )
    messages = [dict(value) for value in spec.messages]
    if (
        not messages
        or any(set(value) != {"role", "content"} for value in messages)
        or request.prompt_sha256 != stable_sha256(messages)
        or request.request_sha256 != stable_sha256(request.identity)
        or request.identity.get("stage") != request.stage
        or request.identity.get("prompt_sha256") != request.prompt_sha256
        or request.identity.get("batch_id") != spec.batch_id
        or tuple(request.identity.get("case_keys", ())) != spec.case_keys
        or tuple(
            request.identity.get("ordered_case_input_sha256s", ())
        )
        != case_hashes
        or len(trajectory_hashes) != len(spec.case_keys)
        or len(view_hashes) != len(spec.case_keys)
        or not isinstance(request.identity.get("provider_config"), Mapping)
    ):
        raise BatchedCriticWorkflowError(
            "frozen v13 StageRequest identity is invalid"
        )
    expected_contract = {
        "method": "two_stage",
        "experiment": V13_EXPERIMENT,
        "prediction_schema_version": V13_PREDICTION_SCHEMA_VERSION,
        "pipeline_version": V13_PIPELINE_VERSION,
        "scout_prompt_protocol_version": (
            V13_SCOUT_PROMPT_PROTOCOL_VERSION
        ),
        "arbiter_prompt_protocol_version": (
            V13_ARBITER_PROMPT_PROTOCOL_VERSION
        ),
        "evidence_validation_version": V13_EVIDENCE_VALIDATION_VERSION,
        "scout_cache_compatibility_version": (
            V13_SCOUT_CACHE_COMPATIBILITY_VERSION
        ),
    }
    if any(request.identity.get(key) != value for key, value in expected_contract.items()):
        raise BatchedCriticWorkflowError(
            "source request is not the exact frozen v13 protocol"
        )
    _sha256(
        request.identity.get("dependency_sha256"),
        field="v13 dependency_sha256",
    )
    _assert_gold_free(request.identity, location="frozen v13 identity")


def _source_paths(cache_dir: Path, request: StageRequest) -> dict[str, Path]:
    root = cache_dir / "semantic_stages"
    suffix = Path(request.stage) / f"{request.request_sha256}.json"
    return {
        "raw": root / "raw" / suffix,
        "response_sidecar": root / "response_sidecar" / suffix,
        "parsed": root / "parsed" / suffix,
    }


def _validate_raw_wrapper(
    value: Mapping[str, Any],
    *,
    request: StageRequest,
) -> None:
    expected_fields = {
        "schema_version",
        "stage",
        "request_sha256",
        "response_sha256",
        "raw_response",
        "failure",
        "telemetry_delta",
        "prior_telemetry",
        "cumulative_telemetry",
        "artifact_sha256",
    }
    body = dict(value)
    claimed = body.pop("artifact_sha256", None)
    if (
        set(value) != expected_fields
        or value.get("schema_version") != RAW_STAGE_SCHEMA_VERSION
        or value.get("stage") != request.stage
        or value.get("request_sha256") != request.request_sha256
        or value.get("response_sha256")
        != stable_sha256(value.get("raw_response"))
        or claimed != stable_sha256(body)
    ):
        raise BatchedCriticWorkflowError(
            "frozen v13 raw stage artifact is invalid"
        )


def _validate_sidecar(
    value: Mapping[str, Any],
    *,
    request: StageRequest,
) -> None:
    expected_fields = {
        "schema_version",
        "stage",
        "request_sha256",
        "response_sha256",
        "raw_response",
        "failure",
        "artifact_sha256",
    }
    body = dict(value)
    claimed = body.pop("artifact_sha256", None)
    if (
        set(value) != expected_fields
        or value.get("schema_version")
        != RAW_RESPONSE_SIDECAR_SCHEMA_VERSION
        or value.get("stage") != request.stage
        or value.get("request_sha256") != request.request_sha256
        or value.get("response_sha256")
        != stable_sha256(value.get("raw_response"))
        or claimed != stable_sha256(body)
    ):
        raise BatchedCriticWorkflowError(
            "frozen v13 response sidecar is invalid"
        )


def _validate_parsed_record(
    value: Mapping[str, Any],
    *,
    request: StageRequest,
    raw: Mapping[str, Any],
) -> None:
    required = {
        "schema_version",
        "stage",
        "request_sha256",
        "prompt_sha256",
        "identity",
        "raw_response_sha256",
        "raw_response",
        "parsed_output",
        "status",
        "failure_stage",
        "failure_code",
        "failure_message",
        "stage_telemetry",
        "latency_seconds",
    }
    if (
        set(value) != required
        or value.get("schema_version") != STAGE_CACHE_SCHEMA_VERSION
        or value.get("stage") != request.stage
        or value.get("request_sha256") != request.request_sha256
        or value.get("prompt_sha256") != request.prompt_sha256
        or value.get("identity") != request.identity
        or value.get("raw_response_sha256") != raw.get("response_sha256")
        or value.get("raw_response") != raw.get("raw_response")
        or value.get("stage_telemetry") != raw.get("cumulative_telemetry")
        or not isinstance(value.get("status"), str)
        or not value.get("status")
    ):
        raise BatchedCriticWorkflowError(
            "frozen v13 parsed stage artifact is invalid"
        )


def _stage_binding(
    *,
    cache_dir: Path,
    spec: FrozenV13StageSpec,
) -> tuple[dict[str, Any], FrozenV13StageResponse]:
    _validate_v13_request(spec)
    paths = _source_paths(cache_dir, spec.request)
    if any(not path.is_file() for path in paths.values()):
        raise BatchedCriticWorkflowError(
            "frozen v13 source cache omits a required stage artifact"
        )
    raw = _read_object(paths["raw"], location="frozen v13 raw stage")
    sidecar = _read_object(
        paths["response_sidecar"],
        location="frozen v13 response sidecar",
    )
    parsed = _read_object(
        paths["parsed"],
        location="frozen v13 parsed stage",
    )
    _validate_raw_wrapper(raw, request=spec.request)
    _validate_sidecar(sidecar, request=spec.request)
    _validate_parsed_record(parsed, request=spec.request, raw=raw)
    if (
        raw["raw_response"] != sidecar["raw_response"]
        or raw["response_sha256"] != sidecar["response_sha256"]
        or raw["failure"] != sidecar["failure"]
    ):
        raise BatchedCriticWorkflowError(
            "frozen v13 raw stage and sidecar diverge"
        )
    files = {
        name: {
            "path": str(path.relative_to(cache_dir)),
            "file_sha256": _file_sha256(path),
        }
        for name, path in paths.items()
    }
    binding: dict[str, Any] = {
        "stage": spec.request.stage,
        "request_sha256": spec.request.request_sha256,
        "prompt_sha256": spec.request.prompt_sha256,
        "dependency_sha256": spec.request.identity["dependency_sha256"],
        "raw_response_sha256": raw["response_sha256"],
        "identity": dict(spec.request.identity),
        "identity_sha256": stable_sha256(spec.request.identity),
        "files": files,
    }
    binding["stage_binding_sha256"] = stable_sha256(binding)
    response = FrozenV13StageResponse(
        stage=spec.request.stage,
        request_sha256=spec.request.request_sha256,
        prompt_sha256=spec.request.prompt_sha256,
        dependency_sha256=spec.request.identity["dependency_sha256"],
        raw_response_sha256=raw["response_sha256"],
        raw_response=raw["raw_response"],
        parsed_output=parsed["parsed_output"],
        status=parsed["status"],
        failure_stage=parsed["failure_stage"],
        failure_code=parsed["failure_code"],
        failure_message=parsed["failure_message"],
        identity=dict(parsed["identity"]),
        stage_telemetry=(
            None
            if parsed["stage_telemetry"] is None
            else dict(parsed["stage_telemetry"])
        ),
        latency_seconds=float(parsed["latency_seconds"]),
    )
    return binding, response


def _validate_source_stage_pair(
    *,
    batch_id: str,
    case_keys: tuple[str, ...],
    ordered_case_input_sha256s: tuple[str, ...],
    scout: FrozenV13StageResponse,
    arbiter: FrozenV13StageResponse,
    scout_identity: Mapping[str, Any],
    arbiter_identity: Mapping[str, Any],
) -> None:
    shared_identity_fields = {
        "method",
        "experiment",
        "prediction_schema_version",
        "pipeline_version",
        "scout_prompt_protocol_version",
        "arbiter_prompt_protocol_version",
        "evidence_validation_version",
        "scout_cache_compatibility_version",
        "judge_view_version",
        "transport_policy_version",
        "prediction_manifest_sha256",
        "batch_id",
        "case_keys",
        "ordered_case_input_sha256s",
        "ordered_trajectory_sha256s",
        "ordered_judge_view_sha256s",
        "provider_config",
    }
    if any(
        scout_identity.get(field) != arbiter_identity.get(field)
        for field in shared_identity_fields
    ):
        raise BatchedCriticWorkflowError(
            "frozen v13 Scout and Arbiter shared identities diverge"
        )
    shared = (batch_id, case_keys, ordered_case_input_sha256s)
    for identity in (scout_identity, arbiter_identity):
        actual = (
            identity.get("batch_id"),
            tuple(identity.get("case_keys", ())),
            tuple(identity.get("ordered_case_input_sha256s", ())),
        )
        if actual != shared:
            raise BatchedCriticWorkflowError(
                "frozen v13 source stages do not bind the same cases"
            )
    scout_dependency = stable_sha256(
        {
            "ordered_case_input_sha256s": ordered_case_input_sha256s,
            "no_prior_semantic_candidates": True,
        }
    )
    arbiter_dependency_body = {
        "scout_request_sha256": scout.request_sha256,
        "scout_raw_sha256": scout.raw_response_sha256,
        "scout_status": scout.status,
    }
    if (
        scout.stage != V13_SCOUT_STAGE
        or arbiter.stage != V13_ARBITER_STAGE
        or scout.dependency_sha256 != scout_dependency
        or arbiter_identity.get("scout_request_sha256")
        != scout.request_sha256
        or arbiter_identity.get("scout_raw_sha256")
        != scout.raw_response_sha256
        or arbiter_identity.get("scout_status") != scout.status
        or arbiter.dependency_sha256
        != stable_sha256(arbiter_dependency_body)
    ):
        raise BatchedCriticWorkflowError(
            "frozen v13 Arbiter does not depend on the exact Scout response"
        )


def freeze_v13_predecessor_manifest(
    *,
    source_cache_dir: str | Path,
    prediction_manifest_sha256: str,
    batch_plan_sha256: str,
    stage_specs: Sequence[FrozenV13StageSpec],
    output_path: str | Path | None = None,
) -> dict[str, Any]:
    """Freeze exact v13 source bytes without reading labels or making calls."""

    cache_dir = Path(source_cache_dir).expanduser().resolve()
    if not cache_dir.is_dir():
        raise BatchedCriticWorkflowError(
            "frozen v13 source-cache directory is missing"
        )
    manifest_sha = _sha256(
        prediction_manifest_sha256,
        field="prediction_manifest_sha256",
    )
    plan_sha = _sha256(batch_plan_sha256, field="batch_plan_sha256")
    if not stage_specs:
        raise BatchedCriticWorkflowError(
            "frozen v13 predecessor requires source stages"
        )
    grouped: dict[str, list[FrozenV13StageSpec]] = {}
    order: list[str] = []
    for spec in stage_specs:
        _validate_v13_request(spec)
        if (
            spec.request.identity.get("prediction_manifest_sha256")
            != manifest_sha
        ):
            raise BatchedCriticWorkflowError(
                "frozen v13 stage belongs to another prediction manifest"
            )
        if spec.batch_id not in grouped:
            order.append(spec.batch_id)
            grouped[spec.batch_id] = []
        grouped[spec.batch_id].append(spec)

    batches: list[dict[str, Any]] = []
    for batch_id in order:
        specs = grouped[batch_id]
        by_stage = {spec.request.stage: spec for spec in specs}
        if len(specs) != 2 or set(by_stage) != set(V13_SOURCE_STAGES):
            raise BatchedCriticWorkflowError(
                "each frozen v13 batch requires exactly Scout and Arbiter"
            )
        scout_binding, scout = _stage_binding(
            cache_dir=cache_dir,
            spec=by_stage[V13_SCOUT_STAGE],
        )
        arbiter_binding, arbiter = _stage_binding(
            cache_dir=cache_dir,
            spec=by_stage[V13_ARBITER_STAGE],
        )
        first = by_stage[V13_SCOUT_STAGE]
        second = by_stage[V13_ARBITER_STAGE]
        if (
            first.case_keys != second.case_keys
            or first.ordered_case_input_sha256s
            != second.ordered_case_input_sha256s
        ):
            raise BatchedCriticWorkflowError(
                "frozen v13 Scout and Arbiter case bindings differ"
            )
        _validate_source_stage_pair(
            batch_id=batch_id,
            case_keys=first.case_keys,
            ordered_case_input_sha256s=(
                first.ordered_case_input_sha256s
            ),
            scout=scout,
            arbiter=arbiter,
            scout_identity=scout_binding["identity"],
            arbiter_identity=arbiter_binding["identity"],
        )
        batch: dict[str, Any] = {
            "batch_id": batch_id,
            "case_keys": list(first.case_keys),
            "ordered_case_input_sha256s": list(
                first.ordered_case_input_sha256s
            ),
            "stages": {
                V13_SCOUT_STAGE: scout_binding,
                V13_ARBITER_STAGE: arbiter_binding,
            },
        }
        batch["batch_binding_sha256"] = stable_sha256(batch)
        batches.append(batch)

    document: dict[str, Any] = {
        "schema_version": V14_FROZEN_PREDECESSOR_SCHEMA_VERSION,
        "role": V14_FROZEN_PREDECESSOR_ROLE,
        "source_experiment": V13_EXPERIMENT,
        "source_pipeline_version": V13_PIPELINE_VERSION,
        "prediction_manifest_sha256": manifest_sha,
        "batch_plan_sha256": plan_sha,
        "source_cache_dir": str(cache_dir),
        "source_cache_state": _directory_state(cache_dir),
        "batch_count": len(batches),
        "batches": batches,
    }
    _assert_gold_free(document, location="frozen v13 predecessor")
    document["predecessor_manifest_sha256"] = stable_sha256(document)
    if output_path is not None:
        destination = Path(output_path).expanduser().resolve()
        if destination.is_relative_to(cache_dir):
            raise BatchedCriticWorkflowError(
                "predecessor manifest must be outside the frozen source cache"
            )
        if destination.exists():
            raise BatchedCriticWorkflowError(
                "frozen predecessor manifest is write-once"
            )
        _atomic_json(destination, document)
    return document


def _validate_stage_binding(binding: Any, *, stage: str) -> None:
    required = {
        "stage",
        "request_sha256",
        "prompt_sha256",
        "dependency_sha256",
        "raw_response_sha256",
        "identity",
        "identity_sha256",
        "files",
        "stage_binding_sha256",
    }
    if not isinstance(binding, Mapping) or set(binding) != required:
        raise BatchedCriticWorkflowError(
            "frozen v13 stage binding fields are invalid"
        )
    body = dict(binding)
    claimed = body.pop("stage_binding_sha256")
    if binding.get("stage") != stage or claimed != stable_sha256(body):
        raise BatchedCriticWorkflowError(
            "frozen v13 stage binding hash is invalid"
        )
    for field in (
        "request_sha256",
        "prompt_sha256",
        "dependency_sha256",
        "raw_response_sha256",
        "identity_sha256",
    ):
        _sha256(binding.get(field), field=f"source {field}")
    identity = binding.get("identity")
    if (
        not isinstance(identity, Mapping)
        or stable_sha256(identity) != binding["identity_sha256"]
        or stable_sha256(identity) != binding["request_sha256"]
        or identity.get("stage") != stage
        or identity.get("prompt_sha256") != binding["prompt_sha256"]
        or identity.get("dependency_sha256")
        != binding["dependency_sha256"]
    ):
        raise BatchedCriticWorkflowError(
            "frozen v13 request identity binding is invalid"
        )
    files = binding.get("files")
    if not isinstance(files, Mapping) or set(files) != {
        "raw",
        "response_sidecar",
        "parsed",
    }:
        raise BatchedCriticWorkflowError(
            "frozen v13 source-file binding is invalid"
        )
    for value in files.values():
        if not isinstance(value, Mapping) or set(value) != {
            "path",
            "file_sha256",
        }:
            raise BatchedCriticWorkflowError(
                "frozen v13 source-file record is invalid"
            )
        _sha256(value.get("file_sha256"), field="source file_sha256")


def load_frozen_v13_predecessor(
    manifest_path: str | Path,
    *,
    source_cache_dir: str | Path,
    prediction_manifest_sha256: str,
    batch_plan_sha256: str,
    upstream_mode: str = V14_UPSTREAM_FROZEN,
) -> FrozenV13Predecessor:
    """Load and verify a write-once v13 semantic-source manifest."""

    if upstream_mode not in V14_UPSTREAM_MODES:
        raise BatchedCriticWorkflowError(
            "frozen predecessor upstream_mode is invalid"
        )
    path = Path(manifest_path).expanduser().resolve()
    cache_dir = Path(source_cache_dir).expanduser().resolve()
    document = _read_object(path, location="frozen v13 predecessor manifest")
    body = dict(document)
    claimed = body.pop("predecessor_manifest_sha256", None)
    if (
        set(document)
        != {
            "schema_version",
            "role",
            "source_experiment",
            "source_pipeline_version",
            "prediction_manifest_sha256",
            "batch_plan_sha256",
            "source_cache_dir",
            "source_cache_state",
            "batch_count",
            "batches",
            "predecessor_manifest_sha256",
        }
        or document.get("schema_version")
        != V14_FROZEN_PREDECESSOR_SCHEMA_VERSION
        or document.get("role") != V14_FROZEN_PREDECESSOR_ROLE
        or document.get("source_experiment") != V13_EXPERIMENT
        or document.get("source_pipeline_version") != V13_PIPELINE_VERSION
        or claimed != stable_sha256(body)
        or document.get("source_cache_dir") != str(cache_dir)
        or document.get("prediction_manifest_sha256")
        != _sha256(
            prediction_manifest_sha256,
            field="prediction_manifest_sha256",
        )
        or document.get("batch_plan_sha256")
        != _sha256(batch_plan_sha256, field="batch_plan_sha256")
    ):
        raise BatchedCriticWorkflowError(
            "frozen v13 predecessor manifest identity is invalid"
        )
    batches = document.get("batches")
    if (
        not isinstance(batches, list)
        or not batches
        or document.get("batch_count") != len(batches)
        or len({item.get("batch_id") for item in batches}) != len(batches)
    ):
        raise BatchedCriticWorkflowError(
            "frozen v13 predecessor batches are invalid"
        )
    for batch in batches:
        if not isinstance(batch, Mapping):
            raise BatchedCriticWorkflowError(
                "frozen v13 predecessor batch must be an object"
            )
        batch_body = dict(batch)
        batch_claimed = batch_body.pop("batch_binding_sha256", None)
        stages = batch.get("stages")
        if (
            set(batch)
            != {
                "batch_id",
                "case_keys",
                "ordered_case_input_sha256s",
                "stages",
                "batch_binding_sha256",
            }
            or not isinstance(batch.get("batch_id"), str)
            or not batch["batch_id"]
            or not isinstance(batch.get("case_keys"), list)
            or not batch["case_keys"]
            or len(set(batch["case_keys"])) != len(batch["case_keys"])
            or not isinstance(
                batch.get("ordered_case_input_sha256s"), list
            )
            or len(batch["case_keys"])
            != len(batch["ordered_case_input_sha256s"])
            or batch_claimed != stable_sha256(batch_body)
            or not isinstance(stages, Mapping)
            or set(stages) != set(V13_SOURCE_STAGES)
        ):
            raise BatchedCriticWorkflowError(
                "frozen v13 predecessor batch binding is invalid"
            )
        for value in batch["ordered_case_input_sha256s"]:
            _sha256(value, field="ordered_case_input_sha256")
        for stage in V13_SOURCE_STAGES:
            _validate_stage_binding(stages[stage], stage=stage)
    _assert_gold_free(document, location="frozen v13 predecessor")
    _assert_directory_state(cache_dir, document.get("source_cache_state"))
    predecessor = FrozenV13Predecessor(
        manifest_path=path,
        source_cache_dir=cache_dir,
        document=document,
        upstream_mode=upstream_mode,
    )
    # Verify every pair now, not only lazily selected batches.  A corrupt
    # unused full-tuning source must not pass dry preregistration.
    for batch in batches:
        predecessor.load_batch(
            batch_id=batch["batch_id"],
            case_keys=batch["case_keys"],
            ordered_case_input_sha256s=(
                batch["ordered_case_input_sha256s"]
            ),
        )
    return predecessor


def _read_frozen_stage(
    *,
    cache_dir: Path,
    binding: Mapping[str, Any],
) -> FrozenV13StageResponse:
    stage = str(binding["stage"])
    _validate_stage_binding(binding, stage=stage)
    request = StageRequest(
        stage=stage,
        request_sha256=binding["request_sha256"],
        prompt_sha256=binding["prompt_sha256"],
        identity=dict(binding["identity"]),
    )
    paths: dict[str, Path] = {}
    for name, record in binding["files"].items():
        path = _safe_relative_path(
            cache_dir,
            record["path"],
            field=f"source {name} path",
        )
        if not path.is_file() or _file_sha256(path) != record["file_sha256"]:
            raise BatchedCriticWorkflowError(
                "frozen v13 source file is missing or drifted"
            )
        paths[name] = path
    raw = _read_object(paths["raw"], location="frozen v13 raw stage")
    sidecar = _read_object(
        paths["response_sidecar"],
        location="frozen v13 response sidecar",
    )
    parsed = _read_object(
        paths["parsed"],
        location="frozen v13 parsed stage",
    )
    _validate_raw_wrapper(raw, request=request)
    _validate_sidecar(sidecar, request=request)
    _validate_parsed_record(parsed, request=request, raw=raw)
    if (
        raw["response_sha256"] != binding["raw_response_sha256"]
        or raw["response_sha256"] != sidecar["response_sha256"]
        or raw["raw_response"] != sidecar["raw_response"]
        or raw["failure"] != sidecar["failure"]
    ):
        raise BatchedCriticWorkflowError(
            "frozen v13 semantic response binding is invalid"
        )
    return FrozenV13StageResponse(
        stage=stage,
        request_sha256=request.request_sha256,
        prompt_sha256=request.prompt_sha256,
        dependency_sha256=request.identity["dependency_sha256"],
        raw_response_sha256=raw["response_sha256"],
        raw_response=raw["raw_response"],
        parsed_output=parsed["parsed_output"],
        status=parsed["status"],
        failure_stage=parsed["failure_stage"],
        failure_code=parsed["failure_code"],
        failure_message=parsed["failure_message"],
        identity=dict(parsed["identity"]),
        stage_telemetry=(
            None
            if parsed["stage_telemetry"] is None
            else dict(parsed["stage_telemetry"])
        ),
        latency_seconds=float(parsed["latency_seconds"]),
    )


def rebuild_prior_root_bundles(
    source: FrozenV13BatchSource,
    *,
    rebuild_arbiter_roots: Callable[
        [Any], Sequence[Mapping[str, Any] | None]
    ],
) -> tuple[dict[str, Any], ...]:
    """Rebuild only prior roots from Arbiter raw and reject stale parsing.

    Scout content is deliberately not returned to the Critic.  The Scout is
    still fully verified because the frozen Arbiter request depends on its
    exact request, raw response, and status.
    """

    if source.arbiter.status != "success":
        if source.arbiter.parsed_output is not None:
            raise BatchedCriticWorkflowError(
                "failed v13 Arbiter unexpectedly has parsed semantics"
            )
        return tuple(
            {"case_key": case_key, "prior_root": None}
            for case_key in source.case_keys
        )

    try:
        rebuilt = list(rebuild_arbiter_roots(source.arbiter.raw_response))
    except BatchedCriticWorkflowError:
        raise
    except Exception as error:
        raise BatchedCriticWorkflowError(
            "frozen v13 Arbiter raw reconstruction failed"
        ) from error
    if len(rebuilt) != len(source.case_keys):
        raise BatchedCriticWorkflowError(
            "rebuilt v13 prior roots do not cover the source batch"
        )
    parsed = source.arbiter.parsed_output
    if not isinstance(parsed, Mapping) or set(parsed) != {"cases"}:
        raise BatchedCriticWorkflowError(
            "frozen v13 parsed Arbiter envelope is invalid"
        )
    parsed_cases = parsed["cases"]
    if not isinstance(parsed_cases, list) or len(parsed_cases) != len(
        source.case_keys
    ):
        raise BatchedCriticWorkflowError(
            "frozen v13 parsed Arbiter cases are invalid"
        )
    bundles: list[dict[str, Any]] = []
    for index, (case_key, prior_root) in enumerate(
        zip(source.case_keys, rebuilt, strict=True)
    ):
        item = parsed_cases[index]
        if (
            not isinstance(item, Mapping)
            or item.get("case_key") != case_key
            or set(item) != {"case_key", "adjudication", "failure"}
        ):
            raise BatchedCriticWorkflowError(
                "frozen v13 parsed Arbiter case ordering is invalid"
            )
        adjudication = item["adjudication"]
        frozen_root: Any = None
        if adjudication is not None:
            if not isinstance(adjudication, Mapping):
                raise BatchedCriticWorkflowError(
                    "frozen v13 parsed adjudication is invalid"
                )
            frozen_root = adjudication.get("decision")
        if prior_root is None:
            normalized_root = None
        elif not isinstance(prior_root, Mapping) or set(prior_root) != (
            _PRIOR_ROOT_FIELDS
        ):
            raise BatchedCriticWorkflowError(
                "rebuilt v13 prior root fields are invalid"
            )
        else:
            normalized_root = dict(prior_root)
            _assert_gold_free(
                normalized_root,
                location="rebuilt v13 prior root",
            )
        if normalized_root != frozen_root:
            raise BatchedCriticWorkflowError(
                "Arbiter raw reconstruction diverges from frozen parsing"
            )
        bundles.append(
            {"case_key": case_key, "prior_root": normalized_root}
        )
    return tuple(bundles)


def build_batched_critic_request(
    *,
    messages: Sequence[Mapping[str, str]],
    source: FrozenV13BatchSource,
    predecessor_bundles: Sequence[Mapping[str, Any]],
    prediction_manifest_sha256: str,
    ordered_trajectory_sha256s: Sequence[str],
    ordered_judge_view_sha256s: Sequence[str],
    provider_config: Mapping[str, Any],
    judge_view_version: str,
    transport_policy_version: str,
    critic_prompt_protocol_version: str = (
        V14_CRITIC_PROMPT_PROTOCOL_VERSION
    ),
) -> StageRequest:
    """Build a Critic key containing every source/input/provider identity."""

    if source.upstream_mode not in V14_UPSTREAM_MODES:
        raise BatchedCriticWorkflowError("Critic upstream_mode is invalid")
    if not isinstance(judge_view_version, str) or not judge_view_version:
        raise BatchedCriticWorkflowError("judge_view_version is invalid")
    if not isinstance(transport_policy_version, str) or not transport_policy_version:
        raise BatchedCriticWorkflowError(
            "transport_policy_version is invalid"
        )
    if (
        not isinstance(critic_prompt_protocol_version, str)
        or not critic_prompt_protocol_version
    ):
        raise BatchedCriticWorkflowError(
            "critic_prompt_protocol_version is invalid"
        )
    trajectory_hashes = [
        _sha256(value, field="ordered_trajectory_sha256")
        for value in ordered_trajectory_sha256s
    ]
    view_hashes = [
        _sha256(value, field="ordered_judge_view_sha256")
        for value in ordered_judge_view_sha256s
    ]
    if (
        len(trajectory_hashes) != len(source.case_keys)
        or len(view_hashes) != len(source.case_keys)
    ):
        raise BatchedCriticWorkflowError(
            "Critic trace/view hashes do not cover the source cases"
        )
    normalized_bundles = [dict(value) for value in predecessor_bundles]
    if (
        len(normalized_bundles) != len(source.case_keys)
        or [value.get("case_key") for value in normalized_bundles]
        != list(source.case_keys)
        or any(set(value) != {"case_key", "prior_root"} for value in normalized_bundles)
    ):
        raise BatchedCriticWorkflowError(
            "Critic predecessor bundles do not match the frozen cases"
        )
    for value in normalized_bundles:
        prior_root = value["prior_root"]
        if prior_root is not None and (
            not isinstance(prior_root, Mapping)
            or set(prior_root) != _PRIOR_ROOT_FIELDS
        ):
            raise BatchedCriticWorkflowError(
                "Critic predecessor prior_root fields are invalid"
            )
    _assert_gold_free(
        normalized_bundles,
        location="Critic predecessor bundles",
    )
    dependency = {
        **source.critic_dependency(),
        "predecessor_bundles_sha256": stable_sha256(normalized_bundles),
    }
    identity = {
        "method": "two_stage",
        "experiment": V14_EXPERIMENT,
        "prediction_schema_version": V14_PREDICTION_SCHEMA_VERSION,
        "pipeline_version": V14_PIPELINE_VERSION,
        "critic_prompt_protocol_version": critic_prompt_protocol_version,
        "semantic_classifier": V14_SEMANTIC_CLASSIFIER,
        "judge_view_version": judge_view_version,
        "transport_policy_version": transport_policy_version,
        "prediction_manifest_sha256": _sha256(
            prediction_manifest_sha256,
            field="prediction_manifest_sha256",
        ),
        "batch_id": source.batch_id,
        "case_keys": list(source.case_keys),
        "ordered_case_input_sha256s": list(
            source.ordered_case_input_sha256s
        ),
        "ordered_trajectory_sha256s": trajectory_hashes,
        "ordered_judge_view_sha256s": view_hashes,
        "provider_config": dict(provider_config),
        "upstream_mode": source.upstream_mode,
        "v13_predecessor_identity_sha256": (
            source.predecessor_manifest_sha256
        ),
        "v13_source_batch_sha256": (
            source.batch_binding_sha256
        ),
        "predecessor_bundles_sha256": stable_sha256(normalized_bundles),
    }
    _assert_gold_free(identity, location="Critic request identity")
    normalized_messages = [dict(value) for value in messages]
    if (
        not normalized_messages
        or any(set(value) != {"role", "content"} for value in normalized_messages)
    ):
        raise BatchedCriticWorkflowError("Critic messages are invalid")
    return build_stage_request(
        stage=V14_CRITIC_STAGE,
        messages=normalized_messages,
        identity=identity,
        dependency_sha256=stable_sha256(dependency),
    )


def build_batched_selector_request(
    *,
    messages: Sequence[Mapping[str, str]],
    source: FrozenV13BatchSource,
    candidate_bundles: Sequence[Mapping[str, Any]],
    critic_request_sha256: str,
    critic_raw_response: Any,
    prediction_manifest_sha256: str,
    ordered_trajectory_sha256s: Sequence[str],
    ordered_judge_view_sha256s: Sequence[str],
    provider_config: Mapping[str, Any],
    judge_view_version: str,
    transport_policy_version: str,
    selector_prompt_protocol_version: str = (
        V14_SELECTOR_PROMPT_PROTOCOL_VERSION
    ),
) -> StageRequest:
    """Build the final Selector key from trace and exact Critic raw bytes."""

    if source.upstream_mode not in V14_UPSTREAM_MODES:
        raise BatchedCriticWorkflowError("Selector upstream_mode is invalid")
    normalized_bundles = [dict(value) for value in candidate_bundles]
    _assert_gold_free(normalized_bundles, location="Selector candidate bundles")
    trajectory_hashes = [
        _sha256(value, field="ordered_trajectory_sha256")
        for value in ordered_trajectory_sha256s
    ]
    view_hashes = [
        _sha256(value, field="ordered_judge_view_sha256")
        for value in ordered_judge_view_sha256s
    ]
    if (
        len(trajectory_hashes) != len(source.case_keys)
        or len(view_hashes) != len(source.case_keys)
        or len(normalized_bundles) != len(source.case_keys)
        or [value.get("case_key") for value in normalized_bundles]
        != list(source.case_keys)
    ):
        raise BatchedCriticWorkflowError(
            "Selector inputs do not cover the frozen source cases"
        )
    critic_digest = _sha256(
        critic_request_sha256,
        field="critic_request_sha256",
    )
    raw_digest = stable_sha256(critic_raw_response)
    bundles_digest = stable_sha256(normalized_bundles)
    identity = {
        "method": "two_stage",
        "experiment": V14_EXPERIMENT,
        "prediction_schema_version": V14_PREDICTION_SCHEMA_VERSION,
        "pipeline_version": V14_PIPELINE_VERSION,
        "selector_prompt_protocol_version": selector_prompt_protocol_version,
        "semantic_classifier": V14_SEMANTIC_CLASSIFIER,
        "judge_view_version": judge_view_version,
        "transport_policy_version": transport_policy_version,
        "prediction_manifest_sha256": _sha256(
            prediction_manifest_sha256,
            field="prediction_manifest_sha256",
        ),
        "batch_id": source.batch_id,
        "case_keys": list(source.case_keys),
        "ordered_case_input_sha256s": list(
            source.ordered_case_input_sha256s
        ),
        "ordered_trajectory_sha256s": trajectory_hashes,
        "ordered_judge_view_sha256s": view_hashes,
        "provider_config": dict(provider_config),
        "upstream_mode": source.upstream_mode,
        "critic_request_sha256": critic_digest,
        "critic_raw_response_sha256": raw_digest,
        "candidate_bundles_sha256": bundles_digest,
    }
    _assert_gold_free(identity, location="Selector request identity")
    normalized_messages = [dict(value) for value in messages]
    if (
        not normalized_messages
        or any(
            set(value) != {"role", "content"}
            for value in normalized_messages
        )
    ):
        raise BatchedCriticWorkflowError("Selector messages are invalid")
    dependency = {
        "critic_request_sha256": critic_digest,
        "critic_raw_response_sha256": raw_digest,
        "candidate_bundles_sha256": bundles_digest,
    }
    return build_stage_request(
        stage=V14_SELECTOR_STAGE,
        messages=normalized_messages,
        identity=identity,
        dependency_sha256=stable_sha256(dependency),
    )


def _assert_disjoint_cache_roots(
    source_cache_dir: Path,
    critic_cache_dir: Path,
) -> None:
    if (
        source_cache_dir == critic_cache_dir
        or source_cache_dir.is_relative_to(critic_cache_dir)
        or critic_cache_dir.is_relative_to(source_cache_dir)
    ):
        raise BatchedCriticWorkflowError(
            "v13 predecessor and v14 Critic caches must be disjoint"
        )


def run_batched_critic_stage(
    *,
    predecessor: FrozenV13Predecessor,
    batch_id: str,
    case_keys: Sequence[str],
    ordered_case_input_sha256s: Sequence[str],
    ordered_trajectory_sha256s: Sequence[str],
    ordered_judge_view_sha256s: Sequence[str],
    predecessor_bundles: Sequence[Mapping[str, Any]],
    prediction_manifest_sha256: str,
    messages: Sequence[Mapping[str, str]],
    provider_config: Mapping[str, Any],
    judge_view_version: str,
    transport_policy_version: str,
    complete: Callable[[list[dict[str, str]]], Any],
    parser: Callable[[Any], Any],
    critic_cache_dir: str | Path,
    completion_guard: Callable[[], None],
    telemetry_snapshotter: (
        Callable[[], Mapping[str, Any] | None] | None
    ) = None,
) -> BatchedCriticStageResult:
    """Run only the final Critic after fail-closed predecessor validation."""

    if not callable(complete) or not callable(parser):
        raise TypeError("v14 Critic requires complete and parser callables")
    if not callable(completion_guard):
        raise TypeError("v14 Critic requires a durable completion guard")
    critic_dir = Path(critic_cache_dir).expanduser().resolve()
    _assert_disjoint_cache_roots(predecessor.source_cache_dir, critic_dir)

    # This validation intentionally precedes both the durable ledger guard and
    # provider callable.  There is no live-upstream fallback in tuning.
    source = predecessor.load_batch(
        batch_id=batch_id,
        case_keys=case_keys,
        ordered_case_input_sha256s=ordered_case_input_sha256s,
    )
    normalized_messages = [dict(value) for value in messages]
    request = build_batched_critic_request(
        messages=normalized_messages,
        source=source,
        predecessor_bundles=predecessor_bundles,
        prediction_manifest_sha256=prediction_manifest_sha256,
        ordered_trajectory_sha256s=ordered_trajectory_sha256s,
        ordered_judge_view_sha256s=ordered_judge_view_sha256s,
        provider_config=provider_config,
        judge_view_version=judge_view_version,
        transport_policy_version=transport_policy_version,
    )
    record, cache_hit = run_cached_stage(
        request=request,
        messages=normalized_messages,
        complete=complete,
        parser=parser,
        cache_root=critic_dir / "semantic_stages",
        retry_failures=False,
        telemetry_snapshotter=telemetry_snapshotter,
        completion_guard=completion_guard,
    )
    return BatchedCriticStageResult(
        record=record,
        cache_hit=cache_hit,
        request=request,
        predecessor=source,
    )


def load_batched_critic_batch_plan(
    path: str | Path,
    *,
    prediction_manifest_path: str | Path | None = None,
) -> _v13.BatchPlan:
    """Load the v13-format gold-free partition used by v14."""

    try:
        return _v13.load_batched_causal_batch_plan(
            path,
            prediction_manifest_path=prediction_manifest_path,
        )
    except _v13.BatchedCausalWorkflowError as error:
        raise BatchedCriticWorkflowError(
            "v14 batch plan is invalid"
        ) from error


def _assert_exact_plan_order(plan: _v13.BatchPlan) -> None:
    flattened = tuple(
        trajectory_id
        for batch in plan.batches
        for trajectory_id in batch.trajectory_ids
    )
    selected = tuple(plan.selected_trajectory_ids)
    if (
        len(flattened) != len(set(flattened))
        or set(flattened) != set(selected)
    ):
        raise BatchedCriticWorkflowError(
            "v14 batch plan order is not an exact unique partition"
        )
    if plan.required_prefix_batch_plan_sha256 is None:
        if (
            plan.execution_order != "caller_selected_order"
            or flattened != selected
        ):
            raise BatchedCriticWorkflowError(
                "v14 non-prefix plan order is invalid"
            )
        return
    _sha256(
        plan.required_prefix_batch_plan_sha256,
        field="required_prefix_batch_plan_sha256",
    )
    if (
        plan.execution_order
        != "required_seed_batch_then_remaining_manifest_order"
        or not plan.batches
        or len(plan.batches[0].trajectory_ids) != 3
    ):
        raise BatchedCriticWorkflowError(
            "v14 prefix-plan execution identity is invalid"
        )
    seed = tuple(plan.batches[0].trajectory_ids)
    expected = seed + tuple(value for value in selected if value not in set(seed))
    if flattened != expected:
        raise BatchedCriticWorkflowError(
            "v14 prefix plan is not seed-then-manifest order"
        )


def _assert_manifest_selection_order(
    plan: _v13.BatchPlan,
    *,
    cases: Sequence[PredictionCase],
) -> None:
    selected = set(plan.selected_trajectory_ids)
    expected = tuple(
        case.trajectory_id
        for case in cases
        if case.trajectory_id in selected
    )
    if tuple(plan.selected_trajectory_ids) != expected:
        raise BatchedCriticWorkflowError(
            "v14 plan selection is not in prediction-manifest order"
        )


def _fixed_provider_config(cohort_sha256: str) -> BenchmarkRunConfig:
    return BenchmarkRunConfig(
        model="deepseek-v4-flash",
        temperature=0.0,
        provider="openai-compatible",
        endpoint="https://api.deepseek.com/v1/chat/completions",
        timeout=600.0,
        max_output_tokens=8192,
        max_retries=5,
        retry_backoff=2.0,
        cohort_sha256=cohort_sha256,
        api_key_env="DEEPSEEK_API_KEY",
        request_body_mode="default",
    )


def _assert_fixed_provider_config(
    config: BenchmarkRunConfig,
    *,
    cohort_sha256: str,
) -> None:
    expected = _fixed_provider_config(cohort_sha256).public_dict()
    if config.public_dict() != expected:
        raise BatchedCriticWorkflowError(
            "v25 provider configuration is not the frozen DeepSeek V4 "
            "Flash default-body setup"
        )


def freeze_batched_critic_predecessor(
    *,
    prediction_manifest_path: str | Path,
    batch_plan_path: str | Path,
    source_cache_dir: str | Path,
    output_path: str | Path,
) -> dict[str, Any]:
    """Reconstruct and freeze the unique full30 v13 request chain.

    The helper never opens a dataset or label file and never calls a provider.
    It regenerates all 22 requests from the gold-free prediction manifest,
    validates their content-addressed artifacts, and writes one immutable
    full predecessor manifest shared by v14 dry and full tuning.
    """

    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    plan_path = Path(batch_plan_path).expanduser().resolve()
    prediction_manifest, cases = load_prediction_manifest(manifest_path)
    plan = load_batched_critic_batch_plan(
        plan_path,
        prediction_manifest_path=manifest_path,
    )
    _assert_exact_plan_order(plan)
    _assert_manifest_selection_order(plan, cases=cases)
    if len(plan.selected_trajectory_ids) != 30 or len(plan.batches) != 11:
        raise BatchedCriticWorkflowError(
            "v14 predecessor must use the unique full30 eleven-batch plan"
        )
    config = _fixed_provider_config(
        str(prediction_manifest["cohort_sha256"])
    )
    by_id = {case.trajectory_id: case for case in cases}
    cache_dir = Path(source_cache_dir).expanduser().resolve()
    if _directory_state(cache_dir)["file_count"] != 66:
        raise BatchedCriticWorkflowError(
            "v14 predecessor source must contain exactly 66 stage files"
        )
    stage_specs: list[FrozenV13StageSpec] = []
    for spec in plan.batches:
        source_cases = [by_id[value] for value in spec.trajectory_ids]
        batched_cases = _v13._cases_for_spec(spec, by_id=by_id)
        scout_request, scout_messages = _v13._scout_stage_request(
            spec=spec,
            source_cases=source_cases,
            batched_cases=batched_cases,
            prediction_manifest=prediction_manifest,
            config=config,
        )
        scout_spec = FrozenV13StageSpec(
            batch_id=spec.batch_id,
            case_keys=spec.case_keys,
            ordered_case_input_sha256s=(
                spec.ordered_case_input_sha256s
            ),
            request=scout_request,
            messages=tuple(dict(value) for value in scout_messages),
        )
        _binding, scout_response = _stage_binding(
            cache_dir=cache_dir,
            spec=scout_spec,
        )
        normalized_scout: list[dict[str, Any] | None] | None = None
        if scout_response.status == "success":
            try:
                normalized_scout, _failures = (
                    parse_batched_scout_isolated(
                        scout_response.raw_response,
                        cases=batched_cases,
                    )
                )
            except JudgeOutputError as error:
                raise BatchedCriticWorkflowError(
                    "successful frozen v13 Scout cannot be reconstructed"
                ) from error
        arbiter_request, arbiter_messages = _v13._arbiter_stage_request(
            spec=spec,
            source_cases=source_cases,
            batched_cases=batched_cases,
            prediction_manifest=prediction_manifest,
            config=config,
            normalized_scout_bundles=normalized_scout,
            scout_request_sha256=scout_request.request_sha256,
            scout_raw_sha256=scout_response.raw_response_sha256,
            scout_status=scout_response.status,
        )
        stage_specs.extend(
            (
                scout_spec,
                FrozenV13StageSpec(
                    batch_id=spec.batch_id,
                    case_keys=spec.case_keys,
                    ordered_case_input_sha256s=(
                        spec.ordered_case_input_sha256s
                    ),
                    request=arbiter_request,
                    messages=tuple(
                        dict(value) for value in arbiter_messages
                    ),
                ),
            )
        )
    document = freeze_v13_predecessor_manifest(
        source_cache_dir=cache_dir,
        prediction_manifest_sha256=prediction_manifest[
            "prediction_manifest_sha256"
        ],
        batch_plan_sha256=plan.batch_plan_sha256,
        stage_specs=stage_specs,
        output_path=output_path,
    )
    if document["batch_count"] != 11:
        raise BatchedCriticWorkflowError(
            "v14 predecessor did not bind all eleven source batches"
        )
    loaded = load_frozen_v13_predecessor(
        output_path,
        source_cache_dir=cache_dir,
        prediction_manifest_sha256=prediction_manifest[
            "prediction_manifest_sha256"
        ],
        batch_plan_sha256=plan.batch_plan_sha256,
    )
    _assert_source_plan_binding(predecessor=loaded, source_plan=plan)
    return document


def _outcome(stage: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "status": stage["status"],
        "failure_stage": stage["failure_stage"],
        "failure_code": stage["failure_code"],
        "failure_message": stage["failure_message"],
    }


def _stage_identity(stage: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "request_sha256": stage["request_sha256"],
        "prompt_sha256": stage["prompt_sha256"],
        "raw_response_sha256": stage["raw_response_sha256"],
        "dependency_sha256": stage["identity"]["dependency_sha256"],
    }


def _frozen_stage_identity(
    stage: FrozenV13StageResponse,
) -> dict[str, Any]:
    return {
        "request_sha256": stage.request_sha256,
        "prompt_sha256": stage.prompt_sha256,
        "raw_response_sha256": stage.raw_response_sha256,
        "dependency_sha256": stage.dependency_sha256,
    }


def _case_parse_outcome(error: JudgeOutputError) -> dict[str, Any]:
    return {
        "status": (
            "invalid_taxonomy"
            if error.code in {"invalid_taxonomy", "invalid_taxonomy_pair"}
            else "invalid_output"
        ),
        "failure_stage": error.stage,
        "failure_code": error.code,
        "failure_message": error.safe_message,
    }


def _adjudication_dict(value: BatchedAdjudication) -> dict[str, Any]:
    return {
        "case_key": value.case_key,
        "audit": value.audit,
        "decision": value.decision.to_dict(),
        "root": value.root.to_dict(),
    }


def _isolated_critic_document(
    raw: Any,
    *,
    cases: Sequence[BatchedCase],
) -> dict[str, Any]:
    values, failures = parse_batched_critic_isolated(raw, cases=cases)
    return {
        "cases": [
            {
                "case_key": case.case_key,
                "adjudication": (
                    None if value is None else value.to_dict()
                ),
                "failure": (
                    None
                    if failure is None
                    else _case_parse_outcome(failure)
                ),
            }
            for case, value, failure in zip(
                cases,
                values,
                failures,
                strict=True,
            )
        ]
    }


def _isolated_selector_document(
    raw: Any,
    *,
    cases: Sequence[BatchedCase],
) -> dict[str, Any]:
    values, failures = parse_batched_selector_isolated(raw, cases=cases)
    return {
        "cases": [
            {
                "case_key": case.case_key,
                "adjudication": (
                    None if value is None else _adjudication_dict(value)
                ),
                "failure": (
                    None
                    if failure is None
                    else _case_parse_outcome(failure)
                ),
            }
            for case, value, failure in zip(
                cases,
                values,
                failures,
                strict=True,
            )
        ]
    }


def _empty_semantics(outcome: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "status": outcome["status"],
        "failure_stage": outcome["failure_stage"],
        "failure_code": outcome["failure_code"],
        "failure_message": outcome["failure_message"],
        "root_cause_judgment": None,
        "judge_reported_step": None,
        "predicted_step": None,
        "predicted_event_id": None,
        "predicted_module": None,
        "predicted_error_type": None,
        "root_cause": None,
        "selector_audit": None,
        "decision": None,
        "evidence_source_id": None,
        "evidence_quote": None,
        "judge_step_matches_event_mapping": None,
    }


def _success_semantics(
    *,
    case: PredictionCase,
    adjudication: BatchedAdjudication,
) -> dict[str, Any]:
    root = adjudication.root
    mapped_step = case.step_for_event(root.critical_event_id)
    return {
        "status": "success",
        "failure_stage": None,
        "failure_code": None,
        "failure_message": None,
        "root_cause_judgment": root.to_dict(),
        "judge_reported_step": root.critical_step,
        "predicted_step": mapped_step,
        "predicted_event_id": root.critical_event_id,
        "predicted_module": root.module.value,
        "predicted_error_type": root.error_type.value,
        "root_cause": root.root_cause,
        "selector_audit": adjudication.audit,
        "decision": adjudication.decision.to_dict(),
        "evidence_source_id": adjudication.decision.evidence_source_id,
        "evidence_quote": root.evidence_quote,
        "judge_step_matches_event_mapping": (
            mapped_step is not None and mapped_step == root.critical_step
        ),
    }


def _frozen_outcome(
    stage: FrozenV13StageResponse,
) -> dict[str, Any]:
    return {
        "status": stage.status,
        "failure_stage": stage.failure_stage,
        "failure_code": stage.failure_code,
        "failure_message": stage.failure_message,
    }


def _rebuild_prior_bundles(
    source: FrozenV13BatchSource,
    *,
    cases: Sequence[BatchedCase],
) -> tuple[dict[str, Any], ...]:
    def rebuild(raw: Any) -> list[dict[str, Any] | None]:
        values, _failures = parse_batched_arbiter_isolated(
            raw,
            cases=cases,
        )
        return [
            None if value is None else value.decision.to_dict()
            for value in values
        ]

    return rebuild_prior_root_bundles(
        source,
        rebuild_arbiter_roots=rebuild,
    )


def _critic_request_for_batch(
    *,
    source: FrozenV13BatchSource,
    source_cases: Sequence[PredictionCase],
    batched_cases: Sequence[BatchedCase],
    predecessor_bundles: Sequence[Mapping[str, Any]],
    prediction_manifest_sha256: str,
    config: BenchmarkRunConfig,
) -> tuple[StageRequest, list[dict[str, str]]]:
    messages = batched_critic_messages(
        batched_cases,
        predecessor_bundles=predecessor_bundles,
    )
    if _v13._message_chars(messages) > V14_MAXIMUM_CRITIC_REQUEST_CHARS:
        raise BatchedCriticWorkflowError(
            "v14 Critic request exceeds the frozen character cap"
        )
    request = build_batched_critic_request(
        messages=messages,
        source=source,
        predecessor_bundles=predecessor_bundles,
        prediction_manifest_sha256=prediction_manifest_sha256,
        ordered_trajectory_sha256s=[
            case.trajectory_sha256 for case in source_cases
        ],
        ordered_judge_view_sha256s=[
            stable_sha256(case.judge_view.to_dict())
            for case in source_cases
        ],
        provider_config=config.public_dict(),
        judge_view_version=JUDGE_VIEW_VERSION,
        transport_policy_version=TRANSPORT_POLICY_VERSION,
    )
    return request, messages


def _selector_request_for_batch(
    *,
    source: FrozenV13BatchSource,
    source_cases: Sequence[PredictionCase],
    batched_cases: Sequence[BatchedCase],
    candidate_bundles: Sequence[Mapping[str, Any]],
    critic_request: StageRequest,
    critic_raw_response: Any,
    prediction_manifest_sha256: str,
    config: BenchmarkRunConfig,
) -> tuple[StageRequest, list[dict[str, str]]]:
    messages = batched_selector_messages(
        batched_cases,
        candidate_bundles=candidate_bundles,
    )
    if _v13._message_chars(messages) > V14_MAXIMUM_SELECTOR_REQUEST_CHARS:
        raise BatchedCriticWorkflowError(
            "v50 Selector request exceeds the frozen character cap"
        )
    request = build_batched_selector_request(
        messages=messages,
        source=source,
        candidate_bundles=candidate_bundles,
        critic_request_sha256=critic_request.request_sha256,
        critic_raw_response=critic_raw_response,
        prediction_manifest_sha256=prediction_manifest_sha256,
        ordered_trajectory_sha256s=[
            case.trajectory_sha256 for case in source_cases
        ],
        ordered_judge_view_sha256s=[
            stable_sha256(case.judge_view.to_dict())
            for case in source_cases
        ],
        provider_config=config.public_dict(),
        judge_view_version=JUDGE_VIEW_VERSION,
        transport_policy_version=TRANSPORT_POLICY_VERSION,
    )
    return request, messages


def _candidate_bundles_from_record(
    record: Mapping[str, Any],
    *,
    cases: Sequence[BatchedCase],
    incumbent_bundles: Sequence[Mapping[str, Any]],
    scout_bundles: Sequence[Mapping[str, Any] | None] | None = None,
) -> tuple[
    list[dict[str, Any]],
    list[BatchedModuleCensus | None],
    list[JudgeOutputError | None],
]:
    adjudications: list[BatchedModuleCensus | None] = [None for _ in cases]
    failures: list[JudgeOutputError | None] = [None for _ in cases]
    if record.get("status") == "success":
        try:
            adjudications, failures = parse_batched_critic_isolated(
                record.get("raw_response"),
                cases=cases,
            )
        except JudgeOutputError:
            adjudications = [None for _ in cases]
            failures = [None for _ in cases]
    return (
        build_selector_candidate_bundles(
            cases,
            adjudications,
            incumbent_bundles=incumbent_bundles,
            scout_bundles=scout_bundles,
        ),
        adjudications,
        failures,
    )


def _scout_bundles_from_source(
    source: FrozenV13BatchSource,
    *,
    cases: Sequence[BatchedCase],
) -> list[dict[str, Any] | None]:
    """Reparse the exact frozen Scout response into case-local hypotheses."""

    if source.scout.status != "success":
        return [None for _ in cases]
    try:
        values, _failures = parse_batched_scout_isolated(
            source.scout.raw_response,
            cases=cases,
        )
    except JudgeOutputError:
        return [None for _ in cases]
    return values


def _read_cached_stage_record(
    *,
    cache_dir: Path,
    request: StageRequest,
) -> dict[str, Any]:
    paths = _source_paths(cache_dir, request)
    if any(not path.is_file() for path in paths.values()):
        raise BatchedCriticWorkflowError(
            "required v14 stage cache artifact is missing"
        )
    raw = _read_object(paths["raw"], location="v14 raw stage")
    sidecar = _read_object(
        paths["response_sidecar"],
        location="v14 response sidecar",
    )
    parsed = _read_object(paths["parsed"], location="v14 parsed stage")
    _validate_raw_wrapper(raw, request=request)
    _validate_sidecar(sidecar, request=request)
    _validate_parsed_record(parsed, request=request, raw=raw)
    if (
        raw["raw_response"] != sidecar["raw_response"]
        or raw["response_sha256"] != sidecar["response_sha256"]
        or raw["failure"] != sidecar["failure"]
    ):
        raise BatchedCriticWorkflowError(
            "v14 cached raw response and sidecar diverge"
        )
    return parsed


def _cache_state_for_requests(
    *,
    cache_dir: Path,
    requests: Sequence[StageRequest],
) -> dict[str, Any]:
    files: dict[str, str] = {}
    for request in requests:
        for path in _source_paths(cache_dir, request).values():
            if not path.is_file():
                raise BatchedCriticWorkflowError(
                    "v14 phase-origin cache artifact is missing"
                )
            relative = str(path.relative_to(cache_dir))
            files[relative] = _file_sha256(path)
    return {
        "file_count": len(files),
        "files_sha256": stable_sha256(files),
    }


def _assert_source_plan_binding(
    *,
    predecessor: FrozenV13Predecessor,
    source_plan: _v13.BatchPlan,
) -> None:
    batches = predecessor.document["batches"]
    expected = [
        (
            spec.batch_id,
            list(spec.case_keys),
            list(spec.ordered_case_input_sha256s),
        )
        for spec in source_plan.batches
    ]
    actual = [
        (
            item["batch_id"],
            item["case_keys"],
            item["ordered_case_input_sha256s"],
        )
        for item in batches
    ]
    if actual != expected:
        raise BatchedCriticWorkflowError(
            "v14 predecessor does not exactly cover the source plan"
        )


def _assert_current_plan_prefix(
    *,
    current_plan: _v13.BatchPlan,
    source_plan: _v13.BatchPlan,
) -> None:
    if tuple(source_plan.batches[: len(current_plan.batches)]) != tuple(
        current_plan.batches
    ):
        raise BatchedCriticWorkflowError(
            "v14 current plan is not an exact source-plan batch prefix"
        )


def _document_with_hash(
    value: Mapping[str, Any],
    *,
    hash_field: str,
) -> dict[str, Any]:
    document = dict(value)
    document[hash_field] = stable_sha256(document)
    return document


def _atomic_jsonl(
    path: Path,
    values: Sequence[Mapping[str, Any]],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        "".join(
            json.dumps(value, ensure_ascii=False, sort_keys=True) + "\n"
            for value in values
        ),
        encoding="utf-8",
    )
    temporary.replace(path)


def _read_jsonl(path: str | Path) -> list[dict[str, Any]]:
    try:
        lines = Path(path).expanduser().resolve().read_text(
            encoding="utf-8"
        ).splitlines()
        values = [json.loads(line) for line in lines if line.strip()]
    except (OSError, json.JSONDecodeError) as error:
        raise BatchedCriticWorkflowError(
            "v14 predictions are missing or corrupt"
        ) from error
    if any(not isinstance(value, dict) for value in values):
        raise BatchedCriticWorkflowError(
            "v14 prediction rows must be objects"
        )
    return values


def _provider_capability_snapshot(judge: Any) -> dict[str, Any] | None:
    snapshotter = getattr(judge, "capability_snapshot", None)
    if not callable(snapshotter):
        return None
    value = snapshotter()
    if not isinstance(value, Mapping):
        raise BatchedCriticWorkflowError(
            "v14 provider capability snapshot must be an object"
        )
    result = dict(value)
    _assert_gold_free(result, location="v14 provider capabilities")
    return result


def _sum_available_telemetry(
    values: Sequence[Mapping[str, Any] | None],
) -> dict[str, Any] | None:
    """Return an aggregate only when every requested stage is covered.

    Sidecar-only recovery deliberately reconstructs a paid response without
    inventing telemetry for it.  A batch that mixes such a stage with stages
    that do have telemetry therefore has incomplete coverage: its aggregate
    must remain unavailable instead of summing only the observable subset.
    """

    if not values or any(value is None for value in values):
        return None
    return sum_stage_telemetry(
        [dict(value) for value in values if value is not None]
    )


def _fresh_origin_path(run_path: Path) -> Path:
    return run_path.with_name("fresh-cache-origin.json")


def _ensure_fresh_cache_origin(
    *,
    run_path: Path,
    preregistration_sha256: str,
    upstream_cache_dir: Path,
    critic_cache_dir: Path,
) -> dict[str, Any]:
    marker_path = _fresh_origin_path(run_path)
    expected_body = {
        "schema_version": "agentdebug.benchmark.e9-v14-fresh-cache-origin.v1",
        "preregistration_sha256": preregistration_sha256,
        "upstream_cache_dir": str(upstream_cache_dir),
        "critic_cache_dir": str(critic_cache_dir),
        "upstream_initial_state": {"file_count": 0, "files_sha256": stable_sha256({})},
        "critic_initial_state": {"file_count": 0, "files_sha256": stable_sha256({})},
    }
    expected = _document_with_hash(
        expected_body,
        hash_field="fresh_cache_origin_sha256",
    )
    if marker_path.is_file():
        actual = _read_object(marker_path, location="fresh cache origin")
        if actual != expected:
            raise BatchedCriticWorkflowError(
                "fresh cache origin marker identity diverged"
            )
        return actual
    if (
        _directory_state(upstream_cache_dir)["file_count"] != 0
        or _directory_state(critic_cache_dir)["file_count"] != 0
    ):
        raise BatchedCriticWorkflowError(
            "fresh Smoke caches must be empty before the first stage"
        )
    _atomic_json(marker_path, expected)
    return expected


def _run_fresh_v13_upstream(
    *,
    prediction_manifest: Mapping[str, Any],
    plan: _v13.BatchPlan,
    cases: Sequence[PredictionCase],
    config: BenchmarkRunConfig,
    complete: Callable[[list[dict[str, str]]], Any],
    telemetry_snapshotter: Callable[[], Mapping[str, Any] | None] | None,
    budget: DurableLogicalCompletionBudget,
    upstream_cache_dir: Path,
    source_manifest_path: Path,
) -> FrozenV13Predecessor:
    """Run all 22 fresh v13 stages, then freeze them before Critic calls."""

    by_id = {case.trajectory_id: case for case in cases}
    stage_specs: list[FrozenV13StageSpec] = []
    for spec in plan.batches:
        source_cases = [by_id[value] for value in spec.trajectory_ids]
        batched_cases = _v13._cases_for_spec(spec, by_id=by_id)
        scout_request, scout_messages = _v13._scout_stage_request(
            spec=spec,
            source_cases=source_cases,
            batched_cases=batched_cases,
            prediction_manifest=prediction_manifest,
            config=config,
        )
        _v13._validate_actual_request_chars(
            spec=spec,
            stage=V13_SCOUT_STAGE,
            messages=scout_messages,
        )
        scout_record, _scout_runtime_hit = run_cached_stage(
            request=scout_request,
            messages=scout_messages,
            complete=complete,
            parser=lambda raw, batch=tuple(batched_cases): (
                _v13._isolated_scout_document(raw, cases=batch)
            ),
            cache_root=upstream_cache_dir / "semantic_stages",
            retry_failures=False,
            telemetry_snapshotter=telemetry_snapshotter,
            completion_guard=lambda request=scout_request: (
                budget.before_complete(
                    stage=V13_SCOUT_STAGE,
                    request_sha256=request.request_sha256,
                )
            ),
        )
        normalized_scout: list[dict[str, Any] | None] | None = None
        if scout_record["status"] == "success":
            normalized_scout, _failures = parse_batched_scout_isolated(
                scout_record["raw_response"],
                cases=batched_cases,
            )
        arbiter_request, arbiter_messages = _v13._arbiter_stage_request(
            spec=spec,
            source_cases=source_cases,
            batched_cases=batched_cases,
            prediction_manifest=prediction_manifest,
            config=config,
            normalized_scout_bundles=normalized_scout,
            scout_request_sha256=scout_request.request_sha256,
            scout_raw_sha256=scout_record["raw_response_sha256"],
            scout_status=scout_record["status"],
        )
        _v13._validate_actual_request_chars(
            spec=spec,
            stage=V13_ARBITER_STAGE,
            messages=arbiter_messages,
        )
        _arbiter_record, _arbiter_runtime_hit = run_cached_stage(
            request=arbiter_request,
            messages=arbiter_messages,
            complete=complete,
            parser=lambda raw, batch=tuple(batched_cases): (
                _v13._isolated_arbiter_document(raw, cases=batch)
            ),
            cache_root=upstream_cache_dir / "semantic_stages",
            retry_failures=False,
            telemetry_snapshotter=telemetry_snapshotter,
            completion_guard=lambda request=arbiter_request: (
                budget.before_complete(
                    stage=V13_ARBITER_STAGE,
                    request_sha256=request.request_sha256,
                )
            ),
        )
        stage_specs.extend(
            (
                FrozenV13StageSpec(
                    batch_id=spec.batch_id,
                    case_keys=spec.case_keys,
                    ordered_case_input_sha256s=(
                        spec.ordered_case_input_sha256s
                    ),
                    request=scout_request,
                    messages=tuple(dict(value) for value in scout_messages),
                ),
                FrozenV13StageSpec(
                    batch_id=spec.batch_id,
                    case_keys=spec.case_keys,
                    ordered_case_input_sha256s=(
                        spec.ordered_case_input_sha256s
                    ),
                    request=arbiter_request,
                    messages=tuple(dict(value) for value in arbiter_messages),
                ),
            )
        )
    if source_manifest_path.is_file():
        predecessor = load_frozen_v13_predecessor(
            source_manifest_path,
            source_cache_dir=upstream_cache_dir,
            prediction_manifest_sha256=prediction_manifest[
                "prediction_manifest_sha256"
            ],
            batch_plan_sha256=plan.batch_plan_sha256,
            upstream_mode=V14_UPSTREAM_FRESH,
        )
    else:
        freeze_v13_predecessor_manifest(
            source_cache_dir=upstream_cache_dir,
            prediction_manifest_sha256=prediction_manifest[
                "prediction_manifest_sha256"
            ],
            batch_plan_sha256=plan.batch_plan_sha256,
            stage_specs=stage_specs,
            output_path=source_manifest_path,
        )
        predecessor = load_frozen_v13_predecessor(
            source_manifest_path,
            source_cache_dir=upstream_cache_dir,
            prediction_manifest_sha256=prediction_manifest[
                "prediction_manifest_sha256"
            ],
            batch_plan_sha256=plan.batch_plan_sha256,
            upstream_mode=V14_UPSTREAM_FRESH,
        )
    _assert_source_plan_binding(
        predecessor=predecessor,
        source_plan=plan,
    )
    return predecessor


def _prediction_profile(
    *,
    upstream_mode: str,
    batch_count: int,
) -> str:
    if upstream_mode == V14_UPSTREAM_FRESH and batch_count == 11:
        return "smoke30"
    if upstream_mode == V14_UPSTREAM_FROZEN and batch_count == 1:
        return "dry3"
    if upstream_mode == V14_UPSTREAM_FROZEN and batch_count == 11:
        return "full30"
    raise BatchedCriticWorkflowError(
        "v14 execution shape has no preregistered budget profile"
    )


def _enforce_failure_study_boundary(
    batch_rows: Sequence[Mapping[str, Any]],
    *,
    has_next_batch: bool,
) -> None:
    """Stop before another batch whenever the persisted batch has a failure."""

    if has_next_batch and any(
        row.get("status") != "success" for row in batch_rows
    ):
        raise BatchedCriticWorkflowError(
            "v54 stopped after a failed batch; complete its case study "
            "before another LLM call"
        )


def predict_batched_critic_cases(
    *,
    prediction_manifest_path: str | Path,
    batch_plan_path: str | Path,
    preregistration_sha256: str,
    judge: Any,
    config: BenchmarkRunConfig,
    critic_cache_dir: str | Path,
    unscored_output_path: str | Path,
    predict_run_metadata_path: str | Path,
    max_logical_completions: int,
    upstream_mode: Literal[
        "frozen_v13_tuning", "fresh_four_stage_smoke"
    ] = V14_UPSTREAM_FROZEN,
    source_batch_plan_path: str | Path | None = None,
    v13_predecessor_manifest_path: str | Path | None = None,
    source_cache_dir: str | Path | None = None,
    fresh_upstream_cache_dir: str | Path | None = None,
    selected_trajectory_ids: Sequence[str] | None = None,
    logical_completion_ledger_path: str | Path | None = None,
    cumulative_logical_completions_before: int = 0,
    authorized_cumulative_ceiling: int | None = None,
    recovery_contract: Mapping[str, Any] | None = None,
    on_batch: Callable[[Mapping[str, Any]], None] | None = None,
    on_result: Callable[[Mapping[str, Any]], None] | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Run the gold-free v14 prediction phase in frozen or fresh mode."""

    if upstream_mode not in V14_UPSTREAM_MODES:
        raise BatchedCriticWorkflowError("v14 upstream_mode is invalid")
    preregistration_digest = _sha256(
        preregistration_sha256,
        field="preregistration_sha256",
    )
    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    plan_path = Path(batch_plan_path).expanduser().resolve()
    prediction_manifest, cases = load_prediction_manifest(manifest_path)
    plan = load_batched_critic_batch_plan(
        plan_path,
        prediction_manifest_path=manifest_path,
    )
    _assert_exact_plan_order(plan)
    _assert_manifest_selection_order(plan, cases=cases)
    requested = (
        tuple(plan.selected_trajectory_ids)
        if selected_trajectory_ids is None
        else tuple(str(value) for value in selected_trajectory_ids)
    )
    if requested != tuple(plan.selected_trajectory_ids):
        raise BatchedCriticWorkflowError(
            "v14 selection differs from the frozen batch plan"
        )
    _assert_fixed_provider_config(
        config,
        cohort_sha256=str(prediction_manifest["cohort_sha256"]),
    )
    complete = getattr(judge, "complete", None)
    if not callable(complete):
        raise TypeError("v14 prediction requires judge.complete(messages)")
    raw_snapshotter = getattr(judge, "telemetry_snapshot", None)
    telemetry_snapshotter = (
        raw_snapshotter if callable(raw_snapshotter) else None
    )
    output_path = Path(unscored_output_path).expanduser().resolve()
    run_path = Path(predict_run_metadata_path).expanduser().resolve()
    if output_path.parent != run_path.parent:
        raise BatchedCriticWorkflowError(
            "v14 predictions and run metadata must share a directory"
        )
    critic_dir = Path(critic_cache_dir).expanduser().resolve()
    ledger_path = (
        Path(logical_completion_ledger_path).expanduser().resolve()
        if logical_completion_ledger_path is not None
        else run_path.with_name("logical-completion-ledger.json")
    )
    if ledger_path.parent != output_path.parent:
        raise BatchedCriticWorkflowError(
            "v14 completion ledger must share the prediction directory"
        )
    profile = _prediction_profile(
        upstream_mode=upstream_mode,
        batch_count=len(plan.batches),
    )
    recovery = (
        None
        if recovery_contract is None
        else _validated_v52_recovery_contract(recovery_contract)
    )
    if recovery is not None:
        if profile != "full30" or upstream_mode != V14_UPSTREAM_FROZEN:
            raise BatchedCriticWorkflowError(
                "v52 recovery requires frozen full30"
            )
        recovery_stop = recovery["cumulative_before"] + recovery["maximum_new"]
        if authorized_cumulative_ceiling not in {None, recovery_stop}:
            raise BatchedCriticWorkflowError(
                "v52 recovery phase stop differs from exact topology"
            )
        contract = V14BudgetContract(
            profile="full30_recovery",
            batch_count=len(plan.batches),
            cumulative_before=recovery["cumulative_before"],
            maximum_new=recovery["maximum_new"],
            hard_cumulative_stop=recovery_stop,
            authorized_cumulative_ceiling=recovery_stop,
        )
    else:
        contract = frozen_v14_budget_contract(
            profile,
            batch_count=len(plan.batches),
            authorized_cumulative_ceiling=authorized_cumulative_ceiling,
        )
    phase_ledger_stop = contract.hard_cumulative_stop
    if (
        cumulative_logical_completions_before
        != contract.cumulative_before
        or max_logical_completions != contract.maximum_new
    ):
        raise BatchedCriticWorkflowError(
            "v14 runtime budget differs from the frozen profile"
        )

    source_plan_path: Path | None = None
    predecessor_path: Path | None = None
    fresh_marker: dict[str, Any] | None = None
    source_plan: _v13.BatchPlan
    upstream_dir: Path
    critic_initial_state = _directory_state(critic_dir)
    upstream_initial_state: dict[str, Any]
    fresh_source_manifest_path: Path | None = None
    if upstream_mode == V14_UPSTREAM_FROZEN:
        if (
            source_batch_plan_path is None
            or v13_predecessor_manifest_path is None
            or source_cache_dir is None
            or fresh_upstream_cache_dir is not None
        ):
            raise BatchedCriticWorkflowError(
                "frozen v14 mode requires only its source plan/cache/manifest"
            )
        source_plan_path = Path(source_batch_plan_path).expanduser().resolve()
        predecessor_path = Path(
            v13_predecessor_manifest_path
        ).expanduser().resolve()
        upstream_dir = Path(source_cache_dir).expanduser().resolve()
        _assert_disjoint_cache_roots(upstream_dir, critic_dir)
        source_plan = load_batched_critic_batch_plan(
            source_plan_path,
            prediction_manifest_path=manifest_path,
        )
        _assert_exact_plan_order(source_plan)
        _assert_manifest_selection_order(source_plan, cases=cases)
        if (
            len(source_plan.selected_trajectory_ids) != 30
            or len(source_plan.batches) != 11
        ):
            raise BatchedCriticWorkflowError(
                "frozen v14 source must be the full30 eleven-batch plan"
            )
        _assert_current_plan_prefix(
            current_plan=plan,
            source_plan=source_plan,
        )
        predecessor = load_frozen_v13_predecessor(
            predecessor_path,
            source_cache_dir=upstream_dir,
            prediction_manifest_sha256=prediction_manifest[
                "prediction_manifest_sha256"
            ],
            batch_plan_sha256=source_plan.batch_plan_sha256,
        )
        _assert_source_plan_binding(
            predecessor=predecessor,
            source_plan=source_plan,
        )
        upstream_initial_state = _directory_state(upstream_dir)
        if profile == "dry3":
            critic_initial_state = {
                "file_count": 0,
                "files_sha256": stable_sha256({}),
            }
        allowed_stages = V14_ACTIVE_STAGES
    else:
        if (
            fresh_upstream_cache_dir is None
            or source_batch_plan_path is not None
            or v13_predecessor_manifest_path is not None
            or source_cache_dir is not None
        ):
            raise BatchedCriticWorkflowError(
                "fresh v14 mode requires only fresh upstream/critic caches"
            )
        if len(plan.selected_trajectory_ids) != 30:
            raise BatchedCriticWorkflowError(
                "fresh Smoke must cover all thirty frozen trajectories"
            )
        upstream_dir = Path(
            fresh_upstream_cache_dir
        ).expanduser().resolve()
        _assert_disjoint_cache_roots(upstream_dir, critic_dir)
        source_plan = plan
        upstream_initial_state = _directory_state(upstream_dir)
        fresh_marker = _ensure_fresh_cache_origin(
            run_path=run_path,
            preregistration_sha256=preregistration_digest,
            upstream_cache_dir=upstream_dir,
            critic_cache_dir=critic_dir,
        )
        upstream_initial_state = dict(
            fresh_marker["upstream_initial_state"]
        )
        critic_initial_state = dict(
            fresh_marker["critic_initial_state"]
        )
        fresh_source_manifest_path = run_path.with_name(
            "fresh-v13-source-manifest.json"
        )
        allowed_stages = V14_ALL_STAGES

    budget = DurableLogicalCompletionBudget(
        max_logical_completions,
        ledger_path=ledger_path,
        preregistration_sha256=preregistration_digest,
        cumulative_before=cumulative_logical_completions_before,
        authorized_cumulative_ceiling=phase_ledger_stop,
        allowed_stages=allowed_stages,
    )
    if upstream_mode == V14_UPSTREAM_FRESH:
        predecessor = _run_fresh_v13_upstream(
            prediction_manifest=prediction_manifest,
            plan=plan,
            cases=cases,
            config=config,
            complete=complete,
            telemetry_snapshotter=telemetry_snapshotter,
            budget=budget,
            upstream_cache_dir=upstream_dir,
            source_manifest_path=fresh_source_manifest_path,
        )

    by_id = {case.trajectory_id: case for case in cases}
    contexts: list[dict[str, Any]] = []
    for spec in plan.batches:
        source_cases = [by_id[value] for value in spec.trajectory_ids]
        batched_cases = _v13._cases_for_spec(spec, by_id=by_id)
        source = predecessor.load_batch(
            batch_id=spec.batch_id,
            case_keys=spec.case_keys,
            ordered_case_input_sha256s=(
                spec.ordered_case_input_sha256s
            ),
        )
        bundles = _rebuild_prior_bundles(
            source,
            cases=batched_cases,
        )
        critic_request, critic_messages = _critic_request_for_batch(
            source=source,
            source_cases=source_cases,
            batched_cases=batched_cases,
            predecessor_bundles=bundles,
            prediction_manifest_sha256=prediction_manifest[
                "prediction_manifest_sha256"
            ],
            config=config,
        )
        contexts.append(
            {
                "spec": spec,
                "source_cases": source_cases,
                "batched_cases": batched_cases,
                "source": source,
                "bundles": bundles,
                "scout_bundles": _scout_bundles_from_source(
                    source,
                    cases=batched_cases,
                ),
                "critic_request": critic_request,
                "critic_messages": critic_messages,
            }
        )
    if profile == "full30":
        # Full tuning reuses both exact dry-stage requests. Prove the complete
        # candidate→selector dependency before any full-run provider call.
        dry_critic_record = _read_cached_stage_record(
            cache_dir=critic_dir,
            request=contexts[0]["critic_request"],
        )
        dry_candidate_bundles, _dry_candidates, _dry_failures = (
            _candidate_bundles_from_record(
                dry_critic_record,
                cases=contexts[0]["batched_cases"],
                incumbent_bundles=contexts[0]["bundles"],
                scout_bundles=contexts[0]["scout_bundles"],
            )
        )
        dry_selector_request, dry_selector_messages = (
            _selector_request_for_batch(
                source=contexts[0]["source"],
                source_cases=contexts[0]["source_cases"],
                batched_cases=contexts[0]["batched_cases"],
                candidate_bundles=dry_candidate_bundles,
                critic_request=contexts[0]["critic_request"],
                critic_raw_response=dry_critic_record["raw_response"],
                prediction_manifest_sha256=prediction_manifest[
                    "prediction_manifest_sha256"
                ],
                config=config,
            )
        )
        _read_cached_stage_record(
            cache_dir=critic_dir,
            request=dry_selector_request,
        )
        contexts[0]["selector_request"] = dry_selector_request
        contexts[0]["selector_messages"] = dry_selector_messages
        if recovery is None:
            critic_initial_state = _cache_state_for_requests(
                cache_dir=critic_dir,
                requests=[
                    contexts[0]["critic_request"],
                    dry_selector_request,
                ],
            )
        elif critic_initial_state != recovery["recovery_cache_initial_state"]:
            raise BatchedCriticWorkflowError(
                "v52 recovery cache differs from its bound imported origin"
            )

    rows: list[dict[str, Any]] = []
    _atomic_jsonl(output_path, rows)
    for batch_index, context in enumerate(contexts, 1):
        spec = context["spec"]
        source_cases = context["source_cases"]
        batched_cases = context["batched_cases"]
        source = context["source"]
        bundles = context["bundles"]
        critic_request = context["critic_request"]
        critic_messages = context["critic_messages"]
        critic_record, _critic_runtime_hit = run_cached_stage(
            request=critic_request,
            messages=critic_messages,
            complete=complete,
            parser=lambda raw, batch=tuple(batched_cases): (
                _isolated_critic_document(raw, cases=batch)
            ),
            cache_root=critic_dir / "semantic_stages",
            retry_failures=recovery is not None,
            telemetry_snapshotter=telemetry_snapshotter,
            completion_guard=lambda request=critic_request: (
                budget.before_complete(
                    stage=V14_CRITIC_STAGE,
                    request_sha256=request.request_sha256,
                )
            ),
        )
        candidate_bundles, _candidate_adjudications, _candidate_failures = (
            _candidate_bundles_from_record(
                critic_record,
                cases=batched_cases,
                incumbent_bundles=bundles,
                scout_bundles=context["scout_bundles"],
            )
        )
        selector_request, selector_messages = _selector_request_for_batch(
            source=source,
            source_cases=source_cases,
            batched_cases=batched_cases,
            candidate_bundles=candidate_bundles,
            critic_request=critic_request,
            critic_raw_response=critic_record["raw_response"],
            prediction_manifest_sha256=prediction_manifest[
                "prediction_manifest_sha256"
            ],
            config=config,
        )
        context["selector_request"] = selector_request
        context["selector_messages"] = selector_messages
        selector_record, _selector_runtime_hit = run_cached_stage(
            request=selector_request,
            messages=selector_messages,
            complete=complete,
            parser=lambda raw, batch=tuple(batched_cases): (
                _isolated_selector_document(raw, cases=batch)
            ),
            cache_root=critic_dir / "semantic_stages",
            retry_failures=recovery is not None,
            telemetry_snapshotter=telemetry_snapshotter,
            completion_guard=lambda request=selector_request: (
                budget.before_complete(
                    stage=V14_SELECTOR_STAGE,
                    request_sha256=request.request_sha256,
                )
            ),
        )
        adjudications: list[BatchedAdjudication | None] = [
            None for _case in batched_cases
        ]
        selector_failures: list[JudgeOutputError | None] = [
            None for _case in batched_cases
        ]
        if selector_record["status"] == "success":
            adjudications, selector_failures = parse_batched_selector_isolated(
                selector_record["raw_response"],
                cases=batched_cases,
            )
        origins = {
            V13_SCOUT_STAGE: (
                "frozen_predecessor"
                if upstream_mode == V14_UPSTREAM_FROZEN
                else "active_fresh"
            ),
            V13_ARBITER_STAGE: (
                "frozen_predecessor"
                if upstream_mode == V14_UPSTREAM_FROZEN
                else "active_fresh"
            ),
            V14_CRITIC_STAGE: "active",
            V14_SELECTOR_STAGE: "active",
        }
        attempted = {
            V13_SCOUT_STAGE: upstream_mode == V14_UPSTREAM_FRESH,
            V13_ARBITER_STAGE: upstream_mode == V14_UPSTREAM_FRESH,
            V14_CRITIC_STAGE: True,
            V14_SELECTOR_STAGE: True,
        }
        phase_reservations = {
            (entry["stage"], entry["request_sha256"])
            for entry in budget.snapshot["entries"]
        }
        cache_hits: dict[str, bool | None] = {
            V13_SCOUT_STAGE: (
                None
                if upstream_mode == V14_UPSTREAM_FROZEN
                else (
                    V13_SCOUT_STAGE,
                    source.scout.request_sha256,
                )
                not in phase_reservations
            ),
            V13_ARBITER_STAGE: (
                None
                if upstream_mode == V14_UPSTREAM_FROZEN
                else (
                    V13_ARBITER_STAGE,
                    source.arbiter.request_sha256,
                )
                not in phase_reservations
            ),
            V14_CRITIC_STAGE: (
                V14_CRITIC_STAGE,
                critic_request.request_sha256,
            )
            not in phase_reservations,
            V14_SELECTOR_STAGE: (
                V14_SELECTOR_STAGE,
                selector_request.request_sha256,
            )
            not in phase_reservations,
        }
        identities = {
            V13_SCOUT_STAGE: _frozen_stage_identity(source.scout),
            V13_ARBITER_STAGE: _frozen_stage_identity(source.arbiter),
            V14_CRITIC_STAGE: _stage_identity(critic_record),
            V14_SELECTOR_STAGE: _stage_identity(selector_record),
        }
        outcomes = {
            V13_SCOUT_STAGE: _frozen_outcome(source.scout),
            V13_ARBITER_STAGE: _frozen_outcome(source.arbiter),
            V14_CRITIC_STAGE: _outcome(critic_record),
            V14_SELECTOR_STAGE: _outcome(selector_record),
        }
        raw_outputs = {
            V13_SCOUT_STAGE: source.scout.raw_response,
            V13_ARBITER_STAGE: source.arbiter.raw_response,
            V14_CRITIC_STAGE: critic_record["raw_response"],
            V14_SELECTOR_STAGE: selector_record["raw_response"],
        }
        stage_telemetry = {
            V13_SCOUT_STAGE: source.scout.stage_telemetry,
            V13_ARBITER_STAGE: source.arbiter.stage_telemetry,
            V14_CRITIC_STAGE: critic_record["stage_telemetry"],
            V14_SELECTOR_STAGE: selector_record["stage_telemetry"],
        }
        current_telemetry = _sum_available_telemetry(
            [
                stage_telemetry[stage]
                for stage in V14_ALL_STAGES
                if attempted[stage] and cache_hits[stage] is False
            ]
        )
        reused_telemetry = (
            _sum_available_telemetry(
                [source.scout.stage_telemetry, source.arbiter.stage_telemetry]
            )
            if upstream_mode == V14_UPSTREAM_FROZEN
            else None
        )
        current_latency = (
            0.0
            if cache_hits[V14_CRITIC_STAGE]
            else float(critic_record["latency_seconds"])
        )
        if cache_hits[V14_SELECTOR_STAGE] is False:
            current_latency += float(selector_record["latency_seconds"])
        reused_latency = 0.0
        if upstream_mode == V14_UPSTREAM_FRESH:
            if cache_hits[V13_SCOUT_STAGE] is False:
                current_latency += source.scout.latency_seconds
            if cache_hits[V13_ARBITER_STAGE] is False:
                current_latency += source.arbiter.latency_seconds
        else:
            reused_latency = (
                source.scout.latency_seconds + source.arbiter.latency_seconds
            )
        batch_rows: list[dict[str, Any]] = []
        for case_offset, (source_case, batched_case) in enumerate(
            zip(source_cases, batched_cases, strict=True)
        ):
            adjudication = adjudications[case_offset]
            failure = selector_failures[case_offset]
            semantics = (
                _success_semantics(
                    case=source_case,
                    adjudication=adjudication,
                )
                if adjudication is not None
                else _empty_semantics(
                    _case_parse_outcome(failure)
                    if failure is not None
                    else outcomes[V14_SELECTOR_STAGE]
                )
            )
            row: dict[str, Any] = {
                "schema_version": V14_PREDICTION_SCHEMA_VERSION,
                "method": "two_stage",
                "experiment": V14_EXPERIMENT,
                "pipeline_version": V14_PIPELINE_VERSION,
                "critic_prompt_protocol_version": (
                    V14_CRITIC_PROMPT_PROTOCOL_VERSION
                ),
                "selector_prompt_protocol_version": (
                    V14_SELECTOR_PROMPT_PROTOCOL_VERSION
                ),
                "evidence_validation_version": (
                    V14_EVIDENCE_VALIDATION_VERSION
                ),
                "semantic_classifier": V14_SEMANTIC_CLASSIFIER,
                "transport_policy_version": TRANSPORT_POLICY_VERSION,
                "upstream_mode": upstream_mode,
                "preregistration_sha256": preregistration_digest,
                "prediction_manifest_sha256": prediction_manifest[
                    "prediction_manifest_sha256"
                ],
                "batch_plan_sha256": plan.batch_plan_sha256,
                "source_batch_plan_sha256": source_plan.batch_plan_sha256,
                "predecessor_manifest_sha256": predecessor.manifest_sha256,
                "batch_id": spec.batch_id,
                "batch_index": batch_index,
                "case_key": batched_case.case_key,
                "batch_case_keys": list(spec.case_keys),
                "batch_trajectory_ids": list(spec.trajectory_ids),
                "ordered_case_input_sha256s": list(
                    spec.ordered_case_input_sha256s
                ),
                "trajectory_id": source_case.trajectory_id,
                "trajectory_sha256": source_case.trajectory_sha256,
                "case_input_sha256": source_case.case_input_sha256,
                "provider_config": config.public_dict(),
                "upstream_cache_dir": str(upstream_dir),
                "critic_cache_dir": str(critic_dir),
                "stage_origins": origins,
                "stage_attempted": attempted,
                "stage_cache_hits": cache_hits,
                "stage_identities": identities,
                "stage_outcomes": outcomes,
                "stage_provider_telemetry": stage_telemetry,
                "raw_judge_outputs": raw_outputs,
                "provider_telemetry": current_telemetry,
                "provider_telemetry_current_run": current_telemetry,
                "reused_predecessor_telemetry": reused_telemetry,
                "latency_seconds": current_latency,
                "reused_predecessor_latency_seconds": reused_latency,
                "cache_hit": all(
                    value is True
                    for stage, value in cache_hits.items()
                    if attempted[stage]
                ),
                "critic_cache_hit": cache_hits[V14_CRITIC_STAGE],
                "selector_cache_hit": cache_hits[V14_SELECTOR_STAGE],
                "predecessor_bundle": dict(bundles[case_offset]),
                "candidate_bundle": dict(candidate_bundles[case_offset]),
                **semantics,
            }
            _assert_gold_free(row, location="v14 unscored prediction")
            row["unscored_prediction_sha256"] = stable_sha256(row)
            batch_rows.append(row)
        rows.extend(batch_rows)
        _atomic_jsonl(output_path, rows)
        for row in batch_rows:
            if on_result is not None:
                on_result(row)
        if on_batch is not None:
            on_batch(
                {
                    "batch_index": batch_index,
                    "batch_id": spec.batch_id,
                    "status": outcomes[V14_SELECTOR_STAGE]["status"],
                    "stage_cache_hits": cache_hits,
                    "unscored_prediction_sha256s": [
                        row["unscored_prediction_sha256"]
                        for row in batch_rows
                    ],
                }
            )
        _enforce_failure_study_boundary(
            batch_rows,
            has_next_batch=batch_index < len(contexts),
        )

    ledger = budget.snapshot
    if len(ledger["entries"]) != contract.maximum_new:
        raise BatchedCriticWorkflowError(
            "completed v14 phase did not consume its exact call budget"
        )
    first_by_batch: dict[str, Mapping[str, Any]] = {}
    for row in rows:
        first_by_batch.setdefault(str(row["batch_id"]), row)
    current_values = [
        row["provider_telemetry_current_run"]
        for row in first_by_batch.values()
        if row["provider_telemetry_current_run"] is not None
    ]
    telemetry = (
        sum_stage_telemetry(current_values) if current_values else None
    )
    coverage = {
        "batch_count": len(first_by_batch),
        "covered_batch_count": len(current_values),
        "complete": len(current_values) == len(first_by_batch),
    }
    metadata = _document_with_hash(
        {
            "schema_version": V14_PREDICT_RUN_SCHEMA_VERSION,
            "method": "two_stage",
            "experiment": V14_EXPERIMENT,
            "pipeline_version": V14_PIPELINE_VERSION,
            "critic_prompt_protocol_version": (
                V14_CRITIC_PROMPT_PROTOCOL_VERSION
            ),
            "selector_prompt_protocol_version": (
                V14_SELECTOR_PROMPT_PROTOCOL_VERSION
            ),
            "evidence_validation_version": V14_EVIDENCE_VALIDATION_VERSION,
            "semantic_classifier": V14_SEMANTIC_CLASSIFIER,
            "transport_policy_version": TRANSPORT_POLICY_VERSION,
            "upstream_mode": upstream_mode,
            "preregistration_sha256": preregistration_digest,
            "prediction_manifest_path": str(manifest_path),
            "prediction_manifest_file_sha256": _file_sha256(manifest_path),
            "prediction_manifest_sha256": prediction_manifest[
                "prediction_manifest_sha256"
            ],
            "batch_plan_path": str(plan_path),
            "batch_plan_file_sha256": _file_sha256(plan_path),
            "batch_plan_sha256": plan.batch_plan_sha256,
            "source_batch_plan_path": (
                None if source_plan_path is None else str(source_plan_path)
            ),
            "source_batch_plan_file_sha256": (
                None
                if source_plan_path is None
                else _file_sha256(source_plan_path)
            ),
            "source_batch_plan_sha256": source_plan.batch_plan_sha256,
            "predecessor_manifest_path": str(predecessor.manifest_path),
            "predecessor_manifest_file_sha256": _file_sha256(
                predecessor.manifest_path
            ),
            "predecessor_manifest_sha256": predecessor.manifest_sha256,
            "unscored_predictions_path": str(output_path),
            "unscored_predictions_sha256": _file_sha256(output_path),
            "predict_run_metadata_path": str(run_path),
            "run_output_dir": str(output_path.parent),
            "upstream_cache_dir": str(upstream_dir),
            "upstream_cache_initial_state": upstream_initial_state,
            "upstream_cache_final_state": _directory_state(upstream_dir),
            "critic_cache_dir": str(critic_dir),
            "critic_cache_initial_state": critic_initial_state,
            "critic_cache_final_state": _directory_state(critic_dir),
            "fresh_cache_origin": fresh_marker,
            "selected_trajectory_ids": list(plan.selected_trajectory_ids),
            "prediction_count": len(rows),
            "batch_count": len(plan.batches),
            "provider_config": config.public_dict(),
            "provider_telemetry": telemetry,
            "provider_telemetry_current_run": telemetry,
            "provider_telemetry_coverage": coverage,
            "provider_capabilities": _provider_capability_snapshot(judge),
            "semantic_mutation_count": 0,
            "max_logical_completions": max_logical_completions,
            "logical_completion_budget_used": len(ledger["entries"]),
            "logical_completion_ledger_path": str(ledger_path),
            "logical_completion_ledger_file_sha256": _file_sha256(
                ledger_path
            ),
            "logical_completion_ledger_sha256": ledger["ledger_sha256"],
            "cumulative_logical_completions_before": (
                cumulative_logical_completions_before
            ),
            "authorized_cumulative_ceiling": (
                phase_ledger_stop
            ),
            "implementation_cumulative_ceiling": (
                V14_IMPLEMENTATION_CUMULATIVE_CEILING
            ),
            "capabilities": {
                "frozen_v13_tuning": True,
                "fresh_four_stage_smoke": True,
                "fresh_smoke_stage_count": 44,
            },
            "retry_failures": recovery is not None,
            "recovery_contract": recovery,
        },
        hash_field="predict_run_sha256",
    )
    _assert_gold_free(metadata, location="v14 predict run")
    _atomic_json(run_path, metadata)
    return rows, metadata


_OUTCOME_FIELDS = {
    "status",
    "failure_stage",
    "failure_code",
    "failure_message",
}
_SEMANTIC_FIELDS = {
    "status",
    "failure_stage",
    "failure_code",
    "failure_message",
    "root_cause_judgment",
    "judge_reported_step",
    "predicted_step",
    "predicted_event_id",
    "predicted_module",
    "predicted_error_type",
    "root_cause",
    "selector_audit",
    "decision",
    "evidence_source_id",
    "evidence_quote",
    "judge_step_matches_event_mapping",
}
_ROW_FIELDS = {
    "schema_version",
    "method",
    "experiment",
    "pipeline_version",
    "critic_prompt_protocol_version",
    "selector_prompt_protocol_version",
    "evidence_validation_version",
    "semantic_classifier",
    "transport_policy_version",
    "upstream_mode",
    "preregistration_sha256",
    "prediction_manifest_sha256",
    "batch_plan_sha256",
    "source_batch_plan_sha256",
    "predecessor_manifest_sha256",
    "batch_id",
    "batch_index",
    "case_key",
    "batch_case_keys",
    "batch_trajectory_ids",
    "ordered_case_input_sha256s",
    "trajectory_id",
    "trajectory_sha256",
    "case_input_sha256",
    "provider_config",
    "upstream_cache_dir",
    "critic_cache_dir",
    "stage_origins",
    "stage_attempted",
    "stage_cache_hits",
    "stage_identities",
    "stage_outcomes",
    "stage_provider_telemetry",
    "raw_judge_outputs",
    "provider_telemetry",
    "provider_telemetry_current_run",
    "reused_predecessor_telemetry",
    "latency_seconds",
    "reused_predecessor_latency_seconds",
    "cache_hit",
    "critic_cache_hit",
    "selector_cache_hit",
    "predecessor_bundle",
    "candidate_bundle",
    *_SEMANTIC_FIELDS,
    "unscored_prediction_sha256",
}
_RUN_FIELDS = {
    "schema_version",
    "method",
    "experiment",
    "pipeline_version",
    "critic_prompt_protocol_version",
    "selector_prompt_protocol_version",
    "evidence_validation_version",
    "semantic_classifier",
    "transport_policy_version",
    "upstream_mode",
    "preregistration_sha256",
    "prediction_manifest_path",
    "prediction_manifest_file_sha256",
    "prediction_manifest_sha256",
    "batch_plan_path",
    "batch_plan_file_sha256",
    "batch_plan_sha256",
    "source_batch_plan_path",
    "source_batch_plan_file_sha256",
    "source_batch_plan_sha256",
    "predecessor_manifest_path",
    "predecessor_manifest_file_sha256",
    "predecessor_manifest_sha256",
    "unscored_predictions_path",
    "unscored_predictions_sha256",
    "predict_run_metadata_path",
    "run_output_dir",
    "upstream_cache_dir",
    "upstream_cache_initial_state",
    "upstream_cache_final_state",
    "critic_cache_dir",
    "critic_cache_initial_state",
    "critic_cache_final_state",
    "fresh_cache_origin",
    "selected_trajectory_ids",
    "prediction_count",
    "batch_count",
    "provider_config",
    "provider_telemetry",
    "provider_telemetry_current_run",
    "provider_telemetry_coverage",
    "provider_capabilities",
    "semantic_mutation_count",
    "max_logical_completions",
    "logical_completion_budget_used",
    "logical_completion_ledger_path",
    "logical_completion_ledger_file_sha256",
    "logical_completion_ledger_sha256",
    "cumulative_logical_completions_before",
    "authorized_cumulative_ceiling",
    "implementation_cumulative_ceiling",
    "capabilities",
    "retry_failures",
    "recovery_contract",
    "predict_run_sha256",
}


def _validate_outcome(
    outcome: Any,
    *,
    stage: str,
    parsed: bool,
) -> None:
    if not isinstance(outcome, Mapping) or set(outcome) != _OUTCOME_FIELDS:
        raise BatchedCriticWorkflowError(
            f"v14 {stage} outcome fields are invalid"
        )
    if parsed:
        if outcome != {
            "status": "success",
            "failure_stage": None,
            "failure_code": None,
            "failure_message": None,
        }:
            raise BatchedCriticWorkflowError(
                f"v14 {stage} valid raw response has a failed outcome"
            )
    elif (
        outcome.get("status") == "success"
        or outcome.get("failure_stage") != stage
        or not isinstance(outcome.get("failure_code"), str)
        or not outcome["failure_code"]
        or not isinstance(outcome.get("failure_message"), str)
        or not outcome["failure_message"]
    ):
        raise BatchedCriticWorkflowError(
            f"v14 {stage} invalid raw response has a wrong outcome"
        )


def _validate_source_raw_reconstruction(
    *,
    source: FrozenV13BatchSource,
    cases: Sequence[BatchedCase],
) -> None:
    try:
        scout_document = _v13._isolated_scout_document(
            source.scout.raw_response,
            cases=cases,
        )
    except JudgeOutputError:
        scout_valid = False
        scout_document = None
    else:
        scout_valid = True
    _validate_outcome(
        _frozen_outcome(source.scout),
        stage=V13_SCOUT_STAGE,
        parsed=scout_valid,
    )
    if source.scout.parsed_output != scout_document:
        raise BatchedCriticWorkflowError(
            "v13 Scout parsed cache diverges from its raw response"
        )
    try:
        arbiter_document = _v13._isolated_arbiter_document(
            source.arbiter.raw_response,
            cases=cases,
        )
    except JudgeOutputError:
        arbiter_valid = False
        arbiter_document = None
    else:
        arbiter_valid = True
    _validate_outcome(
        _frozen_outcome(source.arbiter),
        stage=V13_ARBITER_STAGE,
        parsed=arbiter_valid,
    )
    if source.arbiter.parsed_output != arbiter_document:
        raise BatchedCriticWorkflowError(
            "v13 Arbiter parsed cache diverges from its raw response"
        )


def _validate_stage_identity(
    *,
    persisted: Any,
    request: StageRequest,
    raw: Any,
) -> None:
    expected = {
        "request_sha256": request.request_sha256,
        "prompt_sha256": request.prompt_sha256,
        "raw_response_sha256": stable_sha256(raw),
        "dependency_sha256": request.identity["dependency_sha256"],
    }
    if persisted != expected:
        raise BatchedCriticWorkflowError(
            "v14 stage identity diverges from request/raw bytes"
        )


def _load_validation_predecessor(
    *,
    upstream_mode: str,
    manifest_path: Path,
    prediction_manifest: Mapping[str, Any],
    cases: Sequence[PredictionCase],
    current_plan: _v13.BatchPlan,
    predict_run_path: Path,
    source_batch_plan_path: str | Path | None,
    v13_predecessor_manifest_path: str | Path | None,
    source_cache_dir: str | Path | None,
    fresh_upstream_cache_dir: str | Path | None,
) -> tuple[
    _v13.BatchPlan,
    FrozenV13Predecessor,
    Path,
    Path | None,
]:
    if upstream_mode == V14_UPSTREAM_FROZEN:
        if (
            source_batch_plan_path is None
            or v13_predecessor_manifest_path is None
            or source_cache_dir is None
            or fresh_upstream_cache_dir is not None
        ):
            raise BatchedCriticWorkflowError(
                "frozen validation source arguments are invalid"
            )
        source_plan_path = Path(
            source_batch_plan_path
        ).expanduser().resolve()
        source_plan = load_batched_critic_batch_plan(
            source_plan_path,
            prediction_manifest_path=manifest_path,
        )
        _assert_exact_plan_order(source_plan)
        _assert_manifest_selection_order(source_plan, cases=cases)
        if (
            len(source_plan.selected_trajectory_ids) != 30
            or len(source_plan.batches) != 11
        ):
            raise BatchedCriticWorkflowError(
                "frozen validation source is not full30/11"
            )
        _assert_current_plan_prefix(
            current_plan=current_plan,
            source_plan=source_plan,
        )
        upstream_dir = Path(source_cache_dir).expanduser().resolve()
        predecessor_path = Path(
            v13_predecessor_manifest_path
        ).expanduser().resolve()
        predecessor = load_frozen_v13_predecessor(
            predecessor_path,
            source_cache_dir=upstream_dir,
            prediction_manifest_sha256=prediction_manifest[
                "prediction_manifest_sha256"
            ],
            batch_plan_sha256=source_plan.batch_plan_sha256,
        )
    elif upstream_mode == V14_UPSTREAM_FRESH:
        if (
            fresh_upstream_cache_dir is None
            or source_batch_plan_path is not None
            or v13_predecessor_manifest_path is not None
            or source_cache_dir is not None
        ):
            raise BatchedCriticWorkflowError(
                "fresh validation source arguments are invalid"
            )
        if (
            len(current_plan.selected_trajectory_ids) != 30
            or len(current_plan.batches) != 11
        ):
            raise BatchedCriticWorkflowError(
                "fresh validation requires the complete smoke plan"
            )
        source_plan_path = None
        source_plan = current_plan
        upstream_dir = Path(
            fresh_upstream_cache_dir
        ).expanduser().resolve()
        predecessor_path = predict_run_path.with_name(
            "fresh-v13-source-manifest.json"
        )
        predecessor = load_frozen_v13_predecessor(
            predecessor_path,
            source_cache_dir=upstream_dir,
            prediction_manifest_sha256=prediction_manifest[
                "prediction_manifest_sha256"
            ],
            batch_plan_sha256=source_plan.batch_plan_sha256,
            upstream_mode=V14_UPSTREAM_FRESH,
        )
    else:
        raise BatchedCriticWorkflowError("v14 upstream_mode is invalid")
    _assert_source_plan_binding(
        predecessor=predecessor,
        source_plan=source_plan,
    )
    return source_plan, predecessor, upstream_dir, source_plan_path


def _validate_rows(
    rows: Sequence[Mapping[str, Any]],
    *,
    prediction_manifest: Mapping[str, Any],
    cases: Sequence[PredictionCase],
    plan: _v13.BatchPlan,
    source_plan: _v13.BatchPlan,
    predecessor: FrozenV13Predecessor,
    upstream_mode: str,
    config: BenchmarkRunConfig,
    preregistration_sha256: str,
    upstream_cache_dir: Path,
    critic_cache_dir: Path,
    require_complete: bool,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    by_id = {case.trajectory_id: case for case in cases}
    validated: list[dict[str, Any]] = []
    details: list[dict[str, Any]] = []
    offset = 0
    for batch_index, spec in enumerate(plan.batches, 1):
        if offset == len(rows):
            if require_complete:
                raise BatchedCriticWorkflowError(
                    "v14 predictions end before the batch plan"
                )
            break
        batch_size = len(spec.trajectory_ids)
        if len(rows) - offset < batch_size:
            raise BatchedCriticWorkflowError(
                "v14 partial predictions end inside a batch"
            )
        raw_batch_rows = [
            dict(value) for value in rows[offset : offset + batch_size]
        ]
        offset += batch_size
        first = raw_batch_rows[0]
        shared_fields = {
            "stage_origins",
            "stage_attempted",
            "stage_cache_hits",
            "stage_identities",
            "stage_outcomes",
            "stage_provider_telemetry",
            "raw_judge_outputs",
            "provider_telemetry",
            "provider_telemetry_current_run",
            "reused_predecessor_telemetry",
            "latency_seconds",
            "reused_predecessor_latency_seconds",
            "cache_hit",
            "critic_cache_hit",
            "selector_cache_hit",
        }
        for row in raw_batch_rows:
            if set(row) != _ROW_FIELDS:
                raise BatchedCriticWorkflowError(
                    "v14 unscored prediction fields are invalid"
                )
            body = dict(row)
            claimed = body.pop("unscored_prediction_sha256", None)
            if claimed != stable_sha256(body):
                raise BatchedCriticWorkflowError(
                    "v14 unscored prediction hash is invalid"
                )
            if any(row[field] != first[field] for field in shared_fields):
                raise BatchedCriticWorkflowError(
                    "v14 rows in a batch have divergent stage envelopes"
                )
        source_cases = [by_id[value] for value in spec.trajectory_ids]
        batched_cases = _v13._cases_for_spec(spec, by_id=by_id)
        identity_base = {
            "schema_version": V14_PREDICTION_SCHEMA_VERSION,
            "method": "two_stage",
            "experiment": V14_EXPERIMENT,
            "pipeline_version": V14_PIPELINE_VERSION,
            "critic_prompt_protocol_version": (
                V14_CRITIC_PROMPT_PROTOCOL_VERSION
            ),
            "selector_prompt_protocol_version": (
                V14_SELECTOR_PROMPT_PROTOCOL_VERSION
            ),
            "evidence_validation_version": V14_EVIDENCE_VALIDATION_VERSION,
            "semantic_classifier": V14_SEMANTIC_CLASSIFIER,
            "transport_policy_version": TRANSPORT_POLICY_VERSION,
            "upstream_mode": upstream_mode,
            "preregistration_sha256": preregistration_sha256,
            "prediction_manifest_sha256": prediction_manifest[
                "prediction_manifest_sha256"
            ],
            "batch_plan_sha256": plan.batch_plan_sha256,
            "source_batch_plan_sha256": source_plan.batch_plan_sha256,
            "predecessor_manifest_sha256": predecessor.manifest_sha256,
            "batch_id": spec.batch_id,
            "batch_index": batch_index,
            "batch_case_keys": list(spec.case_keys),
            "batch_trajectory_ids": list(spec.trajectory_ids),
            "ordered_case_input_sha256s": list(
                spec.ordered_case_input_sha256s
            ),
            "provider_config": config.public_dict(),
            "upstream_cache_dir": str(upstream_cache_dir),
            "critic_cache_dir": str(critic_cache_dir),
        }
        for row, source_case, batched_case in zip(
            raw_batch_rows,
            source_cases,
            batched_cases,
            strict=True,
        ):
            checks = {
                **identity_base,
                "case_key": batched_case.case_key,
                "trajectory_id": source_case.trajectory_id,
                "trajectory_sha256": source_case.trajectory_sha256,
                "case_input_sha256": source_case.case_input_sha256,
            }
            if any(row.get(field) != expected for field, expected in checks.items()):
                raise BatchedCriticWorkflowError(
                    "v14 unscored prediction identity is invalid"
                )

        source = predecessor.load_batch(
            batch_id=spec.batch_id,
            case_keys=spec.case_keys,
            ordered_case_input_sha256s=spec.ordered_case_input_sha256s,
        )
        _validate_source_raw_reconstruction(
            source=source,
            cases=batched_cases,
        )
        bundles = _rebuild_prior_bundles(source, cases=batched_cases)
        critic_request, _critic_messages = _critic_request_for_batch(
            source=source,
            source_cases=source_cases,
            batched_cases=batched_cases,
            predecessor_bundles=bundles,
            prediction_manifest_sha256=prediction_manifest[
                "prediction_manifest_sha256"
            ],
            config=config,
        )
        maps = [
            first.get("stage_origins"),
            first.get("stage_attempted"),
            first.get("stage_cache_hits"),
            first.get("stage_identities"),
            first.get("stage_outcomes"),
            first.get("stage_provider_telemetry"),
            first.get("raw_judge_outputs"),
        ]
        if any(
            not isinstance(value, Mapping)
            or set(value) != set(V14_ALL_STAGES)
            for value in maps
        ):
            raise BatchedCriticWorkflowError(
                "v14 stage envelopes are invalid"
            )
        attempted = first["stage_attempted"]
        origins = first["stage_origins"]
        cache_hits = first["stage_cache_hits"]
        expected_attempted = {
            V13_SCOUT_STAGE: upstream_mode == V14_UPSTREAM_FRESH,
            V13_ARBITER_STAGE: upstream_mode == V14_UPSTREAM_FRESH,
            V14_CRITIC_STAGE: True,
            V14_SELECTOR_STAGE: True,
        }
        expected_origins = {
            V13_SCOUT_STAGE: (
                "frozen_predecessor"
                if upstream_mode == V14_UPSTREAM_FROZEN
                else "active_fresh"
            ),
            V13_ARBITER_STAGE: (
                "frozen_predecessor"
                if upstream_mode == V14_UPSTREAM_FROZEN
                else "active_fresh"
            ),
            V14_CRITIC_STAGE: "active",
            V14_SELECTOR_STAGE: "active",
        }
        if attempted != expected_attempted or origins != expected_origins:
            raise BatchedCriticWorkflowError(
                "v14 stage attempt/origin flags are invalid"
            )
        if any(
            not isinstance(cache_hits[stage], bool)
            for stage in V14_ACTIVE_STAGES
        ):
            raise BatchedCriticWorkflowError(
                "v14 active-stage cache-hit flag is invalid"
            )
        for stage in V13_SOURCE_STAGES:
            expected_type = (
                isinstance(cache_hits[stage], bool)
                if upstream_mode == V14_UPSTREAM_FRESH
                else cache_hits[stage] is None
            )
            if not expected_type:
                raise BatchedCriticWorkflowError(
                    "v14 source cache-hit flags are invalid"
                )
        raw_outputs = first["raw_judge_outputs"]
        if (
            raw_outputs[V13_SCOUT_STAGE] != source.scout.raw_response
            or raw_outputs[V13_ARBITER_STAGE] != source.arbiter.raw_response
        ):
            raise BatchedCriticWorkflowError(
                "v14 rows diverge from frozen source raw responses"
            )
        identities = first["stage_identities"]
        if (
            identities[V13_SCOUT_STAGE]
            != _frozen_stage_identity(source.scout)
            or identities[V13_ARBITER_STAGE]
            != _frozen_stage_identity(source.arbiter)
        ):
            raise BatchedCriticWorkflowError(
                "v14 rows diverge from source stage identities"
            )
        _validate_stage_identity(
            persisted=identities[V14_CRITIC_STAGE],
            request=critic_request,
            raw=raw_outputs[V14_CRITIC_STAGE],
        )
        cached_critic = _read_cached_stage_record(
            cache_dir=critic_cache_dir,
            request=critic_request,
        )
        if cached_critic["raw_response"] != raw_outputs[V14_CRITIC_STAGE]:
            raise BatchedCriticWorkflowError(
                "v14 Critic cache diverges from persisted raw output"
            )
        try:
            critic_document = _isolated_critic_document(
                raw_outputs[V14_CRITIC_STAGE],
                cases=batched_cases,
            )
        except JudgeOutputError:
            critic_valid = False
            critic_document = None
        else:
            critic_valid = True
        candidate_bundles, _candidate_values, _candidate_failures = (
            _candidate_bundles_from_record(
                cached_critic,
                cases=batched_cases,
                incumbent_bundles=bundles,
                scout_bundles=_scout_bundles_from_source(
                    source,
                    cases=batched_cases,
                ),
            )
        )
        selector_request, _selector_messages = _selector_request_for_batch(
            source=source,
            source_cases=source_cases,
            batched_cases=batched_cases,
            candidate_bundles=candidate_bundles,
            critic_request=critic_request,
            critic_raw_response=raw_outputs[V14_CRITIC_STAGE],
            prediction_manifest_sha256=prediction_manifest[
                "prediction_manifest_sha256"
            ],
            config=config,
        )
        _validate_stage_identity(
            persisted=identities[V14_SELECTOR_STAGE],
            request=selector_request,
            raw=raw_outputs[V14_SELECTOR_STAGE],
        )
        cached_selector = _read_cached_stage_record(
            cache_dir=critic_cache_dir,
            request=selector_request,
        )
        if cached_selector["raw_response"] != raw_outputs[V14_SELECTOR_STAGE]:
            raise BatchedCriticWorkflowError(
                "v14 Selector cache diverges from persisted raw output"
            )
        adjudications: list[BatchedAdjudication | None] = [
            None for _case in batched_cases
        ]
        failures: list[JudgeOutputError | None] = [
            None for _case in batched_cases
        ]
        try:
            selector_document = _isolated_selector_document(
                raw_outputs[V14_SELECTOR_STAGE],
                cases=batched_cases,
            )
            adjudications, failures = parse_batched_selector_isolated(
                raw_outputs[V14_SELECTOR_STAGE],
                cases=batched_cases,
            )
        except JudgeOutputError:
            selector_valid = False
            selector_document = None
        else:
            selector_valid = True
        outcomes = first["stage_outcomes"]
        if (
            outcomes[V13_SCOUT_STAGE] != _frozen_outcome(source.scout)
            or outcomes[V13_ARBITER_STAGE] != _frozen_outcome(source.arbiter)
        ):
            raise BatchedCriticWorkflowError(
                "v14 source outcomes diverge from frozen cache"
            )
        _validate_outcome(
            outcomes[V14_CRITIC_STAGE],
            stage=V14_CRITIC_STAGE,
            parsed=critic_valid,
        )
        _validate_outcome(
            outcomes[V14_SELECTOR_STAGE],
            stage=V14_SELECTOR_STAGE,
            parsed=selector_valid,
        )
        if cached_critic["parsed_output"] != critic_document:
            raise BatchedCriticWorkflowError(
                "v14 Critic parsed cache diverges from raw response"
            )
        if cached_selector["parsed_output"] != selector_document:
            raise BatchedCriticWorkflowError(
                "v14 Selector parsed cache diverges from raw response"
            )
        expected_stage_telemetry = {
            V13_SCOUT_STAGE: source.scout.stage_telemetry,
            V13_ARBITER_STAGE: source.arbiter.stage_telemetry,
            V14_CRITIC_STAGE: cached_critic["stage_telemetry"],
            V14_SELECTOR_STAGE: cached_selector["stage_telemetry"],
        }
        if first["stage_provider_telemetry"] != expected_stage_telemetry:
            raise BatchedCriticWorkflowError(
                "v14 stage telemetry diverges from stage caches"
            )
        expected_current_telemetry = _sum_available_telemetry(
            [
                expected_stage_telemetry[stage]
                for stage in V14_ALL_STAGES
                if attempted[stage] and cache_hits[stage] is False
            ]
        )
        expected_reused_telemetry = (
            _sum_available_telemetry(
                [source.scout.stage_telemetry, source.arbiter.stage_telemetry]
            )
            if upstream_mode == V14_UPSTREAM_FROZEN
            else None
        )
        if (
            first["provider_telemetry"] != expected_current_telemetry
            or first["provider_telemetry_current_run"]
            != expected_current_telemetry
            or first["reused_predecessor_telemetry"]
            != expected_reused_telemetry
        ):
            raise BatchedCriticWorkflowError(
                "v14 current/reused telemetry separation is invalid"
            )
        expected_current_latency = (
            0.0
            if cache_hits[V14_CRITIC_STAGE]
            else float(cached_critic["latency_seconds"])
        )
        if cache_hits[V14_SELECTOR_STAGE] is False:
            expected_current_latency += float(
                cached_selector["latency_seconds"]
            )
        expected_reused_latency = 0.0
        if upstream_mode == V14_UPSTREAM_FRESH:
            if cache_hits[V13_SCOUT_STAGE] is False:
                expected_current_latency += source.scout.latency_seconds
            if cache_hits[V13_ARBITER_STAGE] is False:
                expected_current_latency += source.arbiter.latency_seconds
        else:
            expected_reused_latency = (
                source.scout.latency_seconds + source.arbiter.latency_seconds
            )
        if (
            first["latency_seconds"] != expected_current_latency
            or first["reused_predecessor_latency_seconds"]
            != expected_reused_latency
            or first["critic_cache_hit"]
            != cache_hits[V14_CRITIC_STAGE]
            or first["selector_cache_hit"]
            != cache_hits[V14_SELECTOR_STAGE]
            or first["cache_hit"]
            is not all(
                value is True
                for stage, value in cache_hits.items()
                if attempted[stage]
            )
        ):
            raise BatchedCriticWorkflowError(
                "v14 cache-hit or latency summary is invalid"
            )
        for index, (row, source_case) in enumerate(
            zip(raw_batch_rows, source_cases, strict=True)
        ):
            if row["predecessor_bundle"] != dict(bundles[index]):
                raise BatchedCriticWorkflowError(
                    "v14 predecessor bundle diverges from raw v13 Arbiter"
                )
            if row["candidate_bundle"] != dict(candidate_bundles[index]):
                raise BatchedCriticWorkflowError(
                    "v14 candidate bundle diverges from raw Critic output"
                )
            adjudication = adjudications[index]
            failure = failures[index]
            semantics = (
                _success_semantics(
                    case=source_case,
                    adjudication=adjudication,
                )
                if adjudication is not None
                else _empty_semantics(
                    _case_parse_outcome(failure)
                    if failure is not None
                    else outcomes[V14_SELECTOR_STAGE]
                )
            )
            if any(row[field] != expected for field, expected in semantics.items()):
                raise BatchedCriticWorkflowError(
                    "v14 final semantics diverge from raw Selector output"
                )
            _assert_gold_free(row, location="v14 unscored prediction")
            validated.append(row)
        details.append(
            {
                "spec": spec,
                "critic_request": critic_request,
                "selector_request": selector_request,
                "source": source,
                "rows": raw_batch_rows,
            }
        )
    if offset != len(rows):
        raise BatchedCriticWorkflowError(
            "v14 predictions exceed the frozen batch plan"
        )
    if require_complete and len(validated) != len(
        plan.selected_trajectory_ids
    ):
        raise BatchedCriticWorkflowError(
            "v14 prediction count is incomplete"
        )
    return validated, details


def _validate_predict_run(
    *,
    path: Path,
    prediction_manifest_path: Path,
    batch_plan_path: Path,
    source_batch_plan_path: Path | None,
    unscored_path: Path,
    rows: Sequence[Mapping[str, Any]],
    details: Sequence[Mapping[str, Any]],
    prediction_manifest: Mapping[str, Any],
    plan: _v13.BatchPlan,
    source_plan: _v13.BatchPlan,
    predecessor: FrozenV13Predecessor,
    upstream_mode: str,
    upstream_cache_dir: Path,
    critic_cache_dir: Path,
    config: BenchmarkRunConfig,
    preregistration_sha256: str,
) -> dict[str, Any]:
    run = _read_object(path, location="v14 predict run")
    if set(run) != _RUN_FIELDS:
        raise BatchedCriticWorkflowError(
            "v14 predict-run fields are invalid"
        )
    body = dict(run)
    claimed = body.pop("predict_run_sha256", None)
    if claimed != stable_sha256(body):
        raise BatchedCriticWorkflowError(
            "v14 predict-run hash is invalid"
        )
    raw_recovery = run.get("recovery_contract")
    recovery = (
        None
        if raw_recovery is None
        else _validated_v52_recovery_contract(raw_recovery)
    )
    expected_identity = {
        "schema_version": V14_PREDICT_RUN_SCHEMA_VERSION,
        "method": "two_stage",
        "experiment": V14_EXPERIMENT,
        "pipeline_version": V14_PIPELINE_VERSION,
        "critic_prompt_protocol_version": V14_CRITIC_PROMPT_PROTOCOL_VERSION,
        "selector_prompt_protocol_version": (
            V14_SELECTOR_PROMPT_PROTOCOL_VERSION
        ),
        "evidence_validation_version": V14_EVIDENCE_VALIDATION_VERSION,
        "semantic_classifier": V14_SEMANTIC_CLASSIFIER,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "upstream_mode": upstream_mode,
        "preregistration_sha256": preregistration_sha256,
        "prediction_manifest_path": str(prediction_manifest_path),
        "prediction_manifest_file_sha256": _file_sha256(
            prediction_manifest_path
        ),
        "prediction_manifest_sha256": prediction_manifest[
            "prediction_manifest_sha256"
        ],
        "batch_plan_path": str(batch_plan_path),
        "batch_plan_file_sha256": _file_sha256(batch_plan_path),
        "batch_plan_sha256": plan.batch_plan_sha256,
        "source_batch_plan_path": (
            None
            if source_batch_plan_path is None
            else str(source_batch_plan_path)
        ),
        "source_batch_plan_file_sha256": (
            None
            if source_batch_plan_path is None
            else _file_sha256(source_batch_plan_path)
        ),
        "source_batch_plan_sha256": source_plan.batch_plan_sha256,
        "predecessor_manifest_path": str(predecessor.manifest_path),
        "predecessor_manifest_file_sha256": _file_sha256(
            predecessor.manifest_path
        ),
        "predecessor_manifest_sha256": predecessor.manifest_sha256,
        "unscored_predictions_path": str(unscored_path),
        "unscored_predictions_sha256": _file_sha256(unscored_path),
        "predict_run_metadata_path": str(path),
        "run_output_dir": str(unscored_path.parent),
        "upstream_cache_dir": str(upstream_cache_dir),
        "upstream_cache_final_state": _directory_state(
            upstream_cache_dir
        ),
        "critic_cache_dir": str(critic_cache_dir),
        "critic_cache_final_state": _directory_state(critic_cache_dir),
        "selected_trajectory_ids": list(plan.selected_trajectory_ids),
        "prediction_count": len(rows),
        "batch_count": len(plan.batches),
        "provider_config": config.public_dict(),
        "semantic_mutation_count": 0,
        "implementation_cumulative_ceiling": (
            V14_IMPLEMENTATION_CUMULATIVE_CEILING
        ),
        "capabilities": {
            "frozen_v13_tuning": True,
            "fresh_four_stage_smoke": True,
            "fresh_smoke_stage_count": 44,
        },
        "retry_failures": recovery is not None,
        "recovery_contract": recovery,
    }
    if any(run.get(field) != expected for field, expected in expected_identity.items()):
        raise BatchedCriticWorkflowError(
            "v14 predict-run identity is invalid"
        )
    for field in (
        "upstream_cache_initial_state",
        "upstream_cache_final_state",
        "critic_cache_initial_state",
        "critic_cache_final_state",
    ):
        value = run.get(field)
        if (
            not isinstance(value, Mapping)
            or set(value) != {"file_count", "files_sha256"}
            or isinstance(value.get("file_count"), bool)
            or not isinstance(value.get("file_count"), int)
            or value["file_count"] < 0
        ):
            raise BatchedCriticWorkflowError(
                f"v14 {field} is invalid"
            )
        _sha256(value.get("files_sha256"), field=f"{field}.files_sha256")

    profile = _prediction_profile(
        upstream_mode=upstream_mode,
        batch_count=len(plan.batches),
    )
    maximum = run.get("max_logical_completions")
    cumulative_before = run.get("cumulative_logical_completions_before")
    authorized_ceiling = run.get("authorized_cumulative_ceiling")
    if any(
        isinstance(value, bool) or not isinstance(value, int)
        for value in (maximum, cumulative_before, authorized_ceiling)
    ):
        raise BatchedCriticWorkflowError(
            "v14 logical completion budget fields are invalid"
        )
    if recovery is None:
        contract = frozen_v14_budget_contract(
            profile,
            batch_count=len(plan.batches),
            authorized_cumulative_ceiling=authorized_ceiling,
        )
    else:
        if profile != "full30" or upstream_mode != V14_UPSTREAM_FROZEN:
            raise BatchedCriticWorkflowError(
                "v52 recovery predict-run is not frozen full30"
            )
        contract = V14BudgetContract(
            profile="full30_recovery",
            batch_count=len(plan.batches),
            cumulative_before=recovery["cumulative_before"],
            maximum_new=recovery["maximum_new"],
            hard_cumulative_stop=(
                recovery["cumulative_before"] + recovery["maximum_new"]
            ),
            authorized_cumulative_ceiling=(
                recovery["cumulative_before"] + recovery["maximum_new"]
            ),
        )
    if (
        maximum != contract.maximum_new
        or cumulative_before != contract.cumulative_before
        or authorized_ceiling != contract.authorized_cumulative_ceiling
        or run.get("logical_completion_budget_used") != contract.maximum_new
    ):
        raise BatchedCriticWorkflowError(
            "v14 predict-run budget diverges from its profile"
        )
    raw_ledger_path = run.get("logical_completion_ledger_path")
    if not isinstance(raw_ledger_path, str):
        raise BatchedCriticWorkflowError(
            "v14 logical completion ledger path is invalid"
        )
    ledger_path = Path(raw_ledger_path).expanduser().resolve()
    if ledger_path.parent != path.parent or str(ledger_path) != raw_ledger_path:
        raise BatchedCriticWorkflowError(
            "v14 logical completion ledger escaped the run directory"
        )
    allowed_stages = (
        V14_ACTIVE_STAGES
        if upstream_mode == V14_UPSTREAM_FROZEN
        else V14_ALL_STAGES
    )
    ledger = load_fresh_semantic_completion_ledger(
        ledger_path,
        preregistration_sha256=preregistration_sha256,
        cumulative_before=cumulative_before,
        maximum_new=maximum,
        authorized_cumulative_ceiling=authorized_ceiling,
        allowed_stages=allowed_stages,
    )
    if (
        run.get("logical_completion_ledger_file_sha256")
        != _file_sha256(ledger_path)
        or run.get("logical_completion_ledger_sha256")
        != ledger["ledger_sha256"]
    ):
        raise BatchedCriticWorkflowError(
            "v14 ledger hashes diverge from the predict run"
        )
    if upstream_mode == V14_UPSTREAM_FROZEN:
        expected_requests: list[tuple[str, str]] = []
        for detail in details:
            expected_requests.extend(
                (
                    (
                        V14_CRITIC_STAGE,
                        detail["critic_request"].request_sha256,
                    ),
                    (
                        V14_SELECTOR_STAGE,
                        detail["selector_request"].request_sha256,
                    ),
                )
            )
        if recovery is not None:
            expected_requests = expected_requests[
                2 * (recovery["first_batch_index"] - 1) :
            ]
        elif profile == "full30":
            if not (
                details[0]["rows"][0]["critic_cache_hit"]
                and details[0]["rows"][0]["selector_cache_hit"]
            ):
                raise BatchedCriticWorkflowError(
                    "v14 full tuning did not reuse both exact dry stages"
                )
            expected_requests = expected_requests[2:]
    else:
        expected_requests = [
            (V13_SCOUT_STAGE, detail["source"].scout.request_sha256)
            for detail in details
        ]
        interleaved: list[tuple[str, str]] = []
        for detail in details:
            interleaved.extend(
                (
                    (
                        V13_SCOUT_STAGE,
                        detail["source"].scout.request_sha256,
                    ),
                    (
                        V13_ARBITER_STAGE,
                        detail["source"].arbiter.request_sha256,
                    ),
                )
            )
        active: list[tuple[str, str]] = []
        for detail in details:
            active.extend(
                (
                    (
                        V14_CRITIC_STAGE,
                        detail["critic_request"].request_sha256,
                    ),
                    (
                        V14_SELECTOR_STAGE,
                        detail["selector_request"].request_sha256,
                    ),
                )
            )
        expected_requests = interleaved + active
    actual_requests = [
        (entry["stage"], entry["request_sha256"])
        for entry in ledger["entries"]
    ]
    if (
        actual_requests != expected_requests
        or len(set(actual_requests)) != len(actual_requests)
    ):
        raise BatchedCriticWorkflowError(
            "v14 ledger does not exactly cover the authorized stage misses"
        )

    if recovery is None:
        expected_initial_counts = {
            "dry3": (66, 0),
            "full30": (66, 6),
            "smoke30": (0, 0),
        }[profile]
        expected_final_counts = {
            "dry3": (66, 6),
            "full30": (66, 66),
            "smoke30": (66, 66),
        }[profile]
        if (
            (
                run["upstream_cache_initial_state"]["file_count"],
                run["critic_cache_initial_state"]["file_count"],
            )
            != expected_initial_counts
            or (
                run["upstream_cache_final_state"]["file_count"],
                run["critic_cache_final_state"]["file_count"],
            )
            != expected_final_counts
        ):
            raise BatchedCriticWorkflowError(
                "v14 cache cardinalities violate the phase topology"
            )
    elif run["critic_cache_initial_state"] != recovery[
        "recovery_cache_initial_state"
    ]:
        raise BatchedCriticWorkflowError(
            "v52 recovery cache origin differs from the imported prefix"
        )
    elif run["critic_cache_final_state"]["file_count"] != 66:
        raise BatchedCriticWorkflowError(
            "v52 recovery cache does not contain all eleven stage pairs"
        )
    if profile == "dry3" and run["critic_cache_initial_state"] != {
        "file_count": 0,
        "files_sha256": stable_sha256({}),
    }:
        raise BatchedCriticWorkflowError(
            "v14 dry Critic cache did not originate empty"
        )
    if recovery is None and profile == "full30" and run["critic_cache_initial_state"] != (
        _cache_state_for_requests(
            cache_dir=critic_cache_dir,
            requests=[
                details[0]["critic_request"],
                details[0]["selector_request"],
            ],
        )
    ):
        raise BatchedCriticWorkflowError(
            "v14 full Critic cache origin is not the exact dry request"
        )
    if upstream_mode == V14_UPSTREAM_FROZEN:
        if (
            run.get("fresh_cache_origin") is not None
            or run["upstream_cache_initial_state"]
            != predecessor.document["source_cache_state"]
            or run["upstream_cache_final_state"]
            != predecessor.document["source_cache_state"]
        ):
            raise BatchedCriticWorkflowError(
                "frozen v14 source cache was not immutable"
            )
    else:
        marker_path = _fresh_origin_path(path)
        marker = _read_object(marker_path, location="fresh cache origin")
        marker_body = dict(marker)
        marker_hash = marker_body.pop("fresh_cache_origin_sha256", None)
        if (
            marker_hash != stable_sha256(marker_body)
            or run.get("fresh_cache_origin") != marker
            or marker.get("preregistration_sha256")
            != preregistration_sha256
            or marker.get("upstream_cache_dir")
            != str(upstream_cache_dir)
            or marker.get("critic_cache_dir") != str(critic_cache_dir)
            or marker.get("upstream_initial_state")
            != run["upstream_cache_initial_state"]
            or marker.get("critic_initial_state")
            != run["critic_cache_initial_state"]
        ):
            raise BatchedCriticWorkflowError(
                "fresh cache origin proof is invalid"
            )

    first_by_batch: dict[str, Mapping[str, Any]] = {}
    for row in rows:
        first_by_batch.setdefault(str(row["batch_id"]), row)
    telemetry_values = [
        row["provider_telemetry_current_run"]
        for row in first_by_batch.values()
        if row["provider_telemetry_current_run"] is not None
    ]
    expected_telemetry = (
        sum_stage_telemetry(telemetry_values)
        if telemetry_values
        else None
    )
    expected_coverage = {
        "batch_count": len(first_by_batch),
        "covered_batch_count": len(telemetry_values),
        "complete": len(telemetry_values) == len(first_by_batch),
    }
    if (
        run.get("provider_telemetry") != expected_telemetry
        or run.get("provider_telemetry_current_run")
        != expected_telemetry
        or run.get("provider_telemetry_coverage") != expected_coverage
    ):
        raise BatchedCriticWorkflowError(
            "v14 predict-run telemetry aggregates are invalid"
        )
    capabilities = run.get("provider_capabilities")
    if capabilities is not None and not isinstance(capabilities, Mapping):
        raise BatchedCriticWorkflowError(
            "v14 provider capabilities are invalid"
        )
    _assert_gold_free(run, location="v14 predict run")
    return run


def validate_partial_batched_critic_predictions(
    *,
    prediction_manifest_path: str | Path,
    batch_plan_path: str | Path,
    unscored_predictions_path: str | Path,
    preregistration_sha256: str,
    config: BenchmarkRunConfig,
    upstream_mode: str = V14_UPSTREAM_FROZEN,
    source_batch_plan_path: str | Path | None = None,
    v13_predecessor_manifest_path: str | Path | None = None,
    source_cache_dir: str | Path | None = None,
    fresh_upstream_cache_dir: str | Path | None = None,
    critic_cache_dir: str | Path,
) -> list[dict[str, Any]]:
    """Validate a complete-batch crash-recovery prefix without gold."""

    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    plan_path = Path(batch_plan_path).expanduser().resolve()
    prediction_manifest, cases = load_prediction_manifest(manifest_path)
    plan = load_batched_critic_batch_plan(
        plan_path,
        prediction_manifest_path=manifest_path,
    )
    _assert_exact_plan_order(plan)
    _assert_manifest_selection_order(plan, cases=cases)
    run_stub = Path(unscored_predictions_path).expanduser().resolve().with_name(
        "predict-run.json"
    )
    source_plan, predecessor, upstream_dir, _source_plan_path = (
        _load_validation_predecessor(
            upstream_mode=upstream_mode,
            manifest_path=manifest_path,
            prediction_manifest=prediction_manifest,
            cases=cases,
            current_plan=plan,
            predict_run_path=run_stub,
            source_batch_plan_path=source_batch_plan_path,
            v13_predecessor_manifest_path=v13_predecessor_manifest_path,
            source_cache_dir=source_cache_dir,
            fresh_upstream_cache_dir=fresh_upstream_cache_dir,
        )
    )
    path = Path(unscored_predictions_path).expanduser().resolve()
    if not path.is_file() or not path.read_text(encoding="utf-8"):
        return []
    rows = _read_jsonl(path)
    validated, _details = _validate_rows(
        rows,
        prediction_manifest=prediction_manifest,
        cases=cases,
        plan=plan,
        source_plan=source_plan,
        predecessor=predecessor,
        upstream_mode=upstream_mode,
        config=config,
        preregistration_sha256=_sha256(
            preregistration_sha256,
            field="preregistration_sha256",
        ),
        upstream_cache_dir=upstream_dir,
        critic_cache_dir=Path(critic_cache_dir).expanduser().resolve(),
        require_complete=False,
    )
    return validated


def validate_batched_critic_artifacts(
    *,
    prediction_manifest_path: str | Path,
    batch_plan_path: str | Path,
    unscored_predictions_path: str | Path,
    predict_run_metadata_path: str | Path,
    upstream_mode: str | None = None,
    source_batch_plan_path: str | Path | None = None,
    v13_predecessor_manifest_path: str | Path | None = None,
    source_cache_dir: str | Path | None = None,
    fresh_upstream_cache_dir: str | Path | None = None,
    critic_cache_dir: str | Path | None = None,
) -> ValidatedBatchedCriticArtifacts:
    """Reconstruct the complete v14 raw chain before any gold is loaded."""

    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    plan_path = Path(batch_plan_path).expanduser().resolve()
    unscored_path = Path(unscored_predictions_path).expanduser().resolve()
    run_path = Path(predict_run_metadata_path).expanduser().resolve()
    prediction_manifest, cases = load_prediction_manifest(manifest_path)
    plan = load_batched_critic_batch_plan(
        plan_path,
        prediction_manifest_path=manifest_path,
    )
    _assert_exact_plan_order(plan)
    _assert_manifest_selection_order(plan, cases=cases)
    rows = _read_jsonl(unscored_path)
    if not rows:
        raise BatchedCriticWorkflowError("v14 predictions are empty")
    row_mode = rows[0].get("upstream_mode")
    mode = row_mode if upstream_mode is None else upstream_mode
    if mode != row_mode or mode not in V14_UPSTREAM_MODES:
        raise BatchedCriticWorkflowError(
            "v14 requested and persisted upstream modes differ"
        )
    first_config = rows[0].get("provider_config")
    if not isinstance(first_config, Mapping):
        raise BatchedCriticWorkflowError(
            "v14 prediction provider config is missing"
        )
    try:
        config = BenchmarkRunConfig(**dict(first_config))
    except (TypeError, ValueError) as error:
        raise BatchedCriticWorkflowError(
            "v14 prediction provider config is invalid"
        ) from error
    _assert_fixed_provider_config(
        config,
        cohort_sha256=str(prediction_manifest["cohort_sha256"]),
    )
    source_plan, predecessor, upstream_dir, source_plan_path = (
        _load_validation_predecessor(
            upstream_mode=mode,
            manifest_path=manifest_path,
            prediction_manifest=prediction_manifest,
            cases=cases,
            current_plan=plan,
            predict_run_path=run_path,
            source_batch_plan_path=source_batch_plan_path,
            v13_predecessor_manifest_path=v13_predecessor_manifest_path,
            source_cache_dir=source_cache_dir,
            fresh_upstream_cache_dir=fresh_upstream_cache_dir,
        )
    )
    row_critic_dir = rows[0].get("critic_cache_dir")
    critic_dir = (
        Path(row_critic_dir).expanduser().resolve()
        if critic_cache_dir is None and isinstance(row_critic_dir, str)
        else Path(critic_cache_dir).expanduser().resolve()
        if critic_cache_dir is not None
        else run_path.parent / "<invalid-critic-cache>"
    )
    if str(critic_dir) != row_critic_dir:
        raise BatchedCriticWorkflowError(
            "v14 Critic cache path is missing or non-canonical"
        )
    _assert_disjoint_cache_roots(upstream_dir, critic_dir)
    preregistration_sha256 = _sha256(
        rows[0].get("preregistration_sha256"),
        field="preregistration_sha256",
    )
    validated, details = _validate_rows(
        rows,
        prediction_manifest=prediction_manifest,
        cases=cases,
        plan=plan,
        source_plan=source_plan,
        predecessor=predecessor,
        upstream_mode=mode,
        config=config,
        preregistration_sha256=preregistration_sha256,
        upstream_cache_dir=upstream_dir,
        critic_cache_dir=critic_dir,
        require_complete=True,
    )
    run = _validate_predict_run(
        path=run_path,
        prediction_manifest_path=manifest_path,
        batch_plan_path=plan_path,
        source_batch_plan_path=source_plan_path,
        unscored_path=unscored_path,
        rows=validated,
        details=details,
        prediction_manifest=prediction_manifest,
        plan=plan,
        source_plan=source_plan,
        predecessor=predecessor,
        upstream_mode=mode,
        upstream_cache_dir=upstream_dir,
        critic_cache_dir=critic_dir,
        config=config,
        preregistration_sha256=preregistration_sha256,
    )
    return ValidatedBatchedCriticArtifacts(
        prediction_manifest=dict(prediction_manifest),
        cases=tuple(cases),
        plan=plan,
        source_plan=source_plan,
        rows=tuple(validated),
        run=run,
        config=config,
        predecessor=predecessor,
    )


def score_batched_critic_predictions(
    *,
    dataset: BenchmarkDataset,
    cohort: CohortManifest,
    prediction_manifest_path: str | Path,
    batch_plan_path: str | Path,
    unscored_predictions_path: str | Path,
    predict_run_metadata_path: str | Path,
    upstream_mode: str | None = None,
    source_batch_plan_path: str | Path | None = None,
    v13_predecessor_manifest_path: str | Path | None = None,
    source_cache_dir: str | Path | None = None,
    fresh_upstream_cache_dir: str | Path | None = None,
    critic_cache_dir: str | Path | None = None,
    validated_artifacts: ValidatedBatchedCriticArtifacts | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any], dict[str, Any]]:
    """Join labels only after the complete raw Critic chain is proven."""

    artifacts = validated_artifacts
    if artifacts is None:
        artifacts = validate_batched_critic_artifacts(
            prediction_manifest_path=prediction_manifest_path,
            batch_plan_path=batch_plan_path,
            upstream_mode=upstream_mode,
            source_batch_plan_path=source_batch_plan_path,
            v13_predecessor_manifest_path=(
                v13_predecessor_manifest_path
            ),
            source_cache_dir=source_cache_dir,
            fresh_upstream_cache_dir=fresh_upstream_cache_dir,
            critic_cache_dir=critic_cache_dir,
            unscored_predictions_path=unscored_predictions_path,
            predict_run_metadata_path=predict_run_metadata_path,
        )
    if not isinstance(artifacts, ValidatedBatchedCriticArtifacts):
        raise BatchedCriticWorkflowError(
            "v14 validated artifact proof has the wrong type"
        )
    prediction_manifest = artifacts.prediction_manifest
    plan = artifacts.plan
    cases = artifacts.cases
    validated = artifacts.rows
    config = artifacts.config
    if (
        dataset.dataset_sha256
        != prediction_manifest["dataset_manifest_sha256"]
        or cohort.dataset_manifest_sha256
        != prediction_manifest["dataset_manifest_sha256"]
        or cohort.cohort_name != prediction_manifest["cohort_name"]
        or cohort.cohort_sha256 != prediction_manifest["cohort_sha256"]
    ):
        raise BatchedCriticWorkflowError(
            "v14 scoring dataset/cohort lineage is invalid"
        )
    if not set(plan.selected_trajectory_ids) <= set(cohort.trajectory_ids):
        raise BatchedCriticWorkflowError(
            "v14 predictions are outside the scoring cohort"
        )

    # This is the first point that touches benchmark examples/labels.  Raw
    # Critic parsing, cache bytes, rows, run hashes, and ledger were already
    # validated above (or by the opaque proof passed from the CLI).
    by_case = {case.trajectory_id: case for case in cases}
    examples = {
        example.label.trajectory_id: example for example in dataset.examples
    }
    by_id = {case.trajectory_id: case for case in cases}
    parsed_by_batch: dict[str, dict[str, BatchedAdjudication]] = {}
    for spec in plan.batches:
        batch_rows = [
            row for row in validated if row["batch_id"] == spec.batch_id
        ]
        batched_cases = _v13._cases_for_spec(spec, by_id=by_id)
        try:
            adjudications, _failures = parse_batched_selector_isolated(
                batch_rows[0]["raw_judge_outputs"][V14_SELECTOR_STAGE],
                cases=batched_cases,
            )
        except JudgeOutputError:
            adjudications = [None for _case in batched_cases]
        parsed_by_batch[spec.batch_id] = {
            value.case_key: value
            for value in adjudications
            if value is not None
        }
    validated_by_id = {
        str(row["trajectory_id"]): row for row in validated
    }
    scoring_rows = [
        validated_by_id[trajectory_id]
        for trajectory_id in plan.selected_trajectory_ids
    ]
    scored: list[dict[str, Any]] = []
    for row in scoring_rows:
        trajectory_id = str(row["trajectory_id"])
        example = examples.get(trajectory_id)
        if example is None:
            raise BatchedCriticWorkflowError(
                "v14 trajectory has no benchmark scoring example"
            )
        case = by_case[trajectory_id]
        if (
            example.mapping.trajectory_sha256 != case.trajectory_sha256
            or tuple(
                (value.original_step, value.critical_event_id)
                for value in example.mapping.steps
            )
            != case.step_event_mapping
        ):
            raise BatchedCriticWorkflowError(
                "v14 scoring adaptation diverges from prediction manifest"
            )
        record = _base_record(example, method="two_stage", config=config)
        record.update(
            {
                "status": row["status"],
                "failure_stage": row["failure_stage"],
                "failure_code": row["failure_code"],
                "failure_message": row["failure_message"],
                "root_cause_judgment": row["root_cause_judgment"],
                "raw_judge_outputs": row["raw_judge_outputs"],
                "stage_origins": row["stage_origins"],
                "stage_attempted": row["stage_attempted"],
                "stage_cache_hits": row["stage_cache_hits"],
                "stage_identities": row["stage_identities"],
                "stage_outcomes": row["stage_outcomes"],
                "stage_provider_telemetry": row[
                    "stage_provider_telemetry"
                ],
                "provider_telemetry": row["provider_telemetry"],
                "provider_telemetry_current_run": row[
                    "provider_telemetry_current_run"
                ],
                "reused_predecessor_telemetry": row[
                    "reused_predecessor_telemetry"
                ],
                "latency_seconds": row["latency_seconds"],
                "cache_hit": row["cache_hit"],
                "prompt_version": V14_SELECTOR_PROMPT_PROTOCOL_VERSION,
                "pipeline_version": V14_PIPELINE_VERSION,
                "experiment": V14_EXPERIMENT,
                "semantic_classifier": V14_SEMANTIC_CLASSIFIER,
                "upstream_mode": row["upstream_mode"],
                "prior_root": row["predecessor_bundle"]["prior_root"],
                "preregistration_sha256": row[
                    "preregistration_sha256"
                ],
                "prediction_manifest_sha256": row[
                    "prediction_manifest_sha256"
                ],
                "batch_plan_sha256": row["batch_plan_sha256"],
                "source_batch_plan_sha256": row[
                    "source_batch_plan_sha256"
                ],
                "predecessor_manifest_sha256": row[
                    "predecessor_manifest_sha256"
                ],
                "batch_id": row["batch_id"],
                "batch_index": row["batch_index"],
                "case_key": row["case_key"],
                "critic_cache_dir": row["critic_cache_dir"],
                "unscored_prediction_sha256": row[
                    "unscored_prediction_sha256"
                ],
                "evidence_source_id": row["evidence_source_id"],
                "evidence_quote": row["evidence_quote"],
                "selector_audit": row["selector_audit"],
                "decision": row["decision"],
                "judge_step_matches_event_mapping": row[
                    "judge_step_matches_event_mapping"
                ],
            }
        )
        adjudication = parsed_by_batch.get(
            str(row["batch_id"]), {}
        ).get(str(row["case_key"]))
        if adjudication is not None:
            _apply_root(record, example=example, root=adjudication.root)
        scored.append(record)
    metrics = compute_metrics(scored)
    return scored, metrics, artifacts.run


def frozen_v14_budget_contract(
    profile: str,
    *,
    batch_count: int,
    authorized_cumulative_ceiling: int | None = None,
) -> V14BudgetContract:
    """Return an exact topology budget; no cumulative user ceiling exists."""

    expected = {
        "dry3": (1, 642, 2),
        "full30": (11, 644, 20),
        # Held-out smoke has Scout, Arbiter, candidate, and Selector misses.
        "smoke30": (11, 664, 44),
    }
    if profile not in expected:
        raise BatchedCriticWorkflowError(
            "v14 budget profile is unsupported"
        )
    expected_batches, cumulative_before, maximum_new = expected[profile]
    if (
        isinstance(batch_count, bool)
        or not isinstance(batch_count, int)
        or batch_count != expected_batches
    ):
        raise BatchedCriticWorkflowError(
            "v14 profile-specific budget identity is invalid"
        )
    hard_stop = cumulative_before + maximum_new
    if authorized_cumulative_ceiling is not None and (
        isinstance(authorized_cumulative_ceiling, bool)
        or not isinstance(authorized_cumulative_ceiling, int)
        or authorized_cumulative_ceiling != hard_stop
    ):
        raise BatchedCriticWorkflowError(
            "v14 supplied phase stop differs from exact topology"
        )
    return V14BudgetContract(
        profile=profile,
        batch_count=batch_count,
        cumulative_before=cumulative_before,
        maximum_new=maximum_new,
        hard_cumulative_stop=hard_stop,
        # The shared durable-ledger schema still names this field
        # "authorized". It is only this phase's exact mechanical hard stop.
        authorized_cumulative_ceiling=hard_stop,
    )


__all__ = [
    "BatchedCriticStageResult",
    "BatchedCriticWorkflowError",
    "FrozenV13BatchSource",
    "FrozenV13Predecessor",
    "FrozenV13StageResponse",
    "FrozenV13StageSpec",
    "ValidatedBatchedCriticArtifacts",
    "V14BudgetContract",
    "V14_CRITIC_PROMPT_PROTOCOL_VERSION",
    "V14_CRITIC_STAGE",
    "V14_SELECTOR_PROMPT_PROTOCOL_VERSION",
    "V14_SELECTOR_STAGE",
    "V14_EXPERIMENT",
    "V14_EVIDENCE_VALIDATION_VERSION",
    "V14_FROZEN_PREDECESSOR_ROLE",
    "V14_FROZEN_PREDECESSOR_SCHEMA_VERSION",
    "V14_IMPLEMENTATION_CUMULATIVE_CEILING",
    "V14_MAXIMUM_CRITIC_REQUEST_CHARS",
    "V14_MAXIMUM_SELECTOR_REQUEST_CHARS",
    "V14_PIPELINE_VERSION",
    "V14_PREDICTION_SCHEMA_VERSION",
    "V14_PREDICT_RUN_SCHEMA_VERSION",
    "V14_SEMANTIC_CLASSIFIER",
    "V14_UPSTREAM_FRESH",
    "V14_UPSTREAM_FROZEN",
    "V14_UPSTREAM_MODES",
    "build_batched_critic_request",
    "build_batched_selector_request",
    "freeze_batched_critic_predecessor",
    "freeze_v13_predecessor_manifest",
    "frozen_v14_budget_contract",
    "load_batched_critic_batch_plan",
    "load_frozen_v13_predecessor",
    "predict_batched_critic_cases",
    "rebuild_prior_root_bundles",
    "run_batched_critic_stage",
    "score_batched_critic_predictions",
    "validate_batched_critic_artifacts",
    "validate_partial_batched_critic_predictions",
]

"""Deterministic, write-once production experiment preregistration."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any

from agentdebug.diagnostics import (
    EVIDENCE_REPAIR_MAX_ATTEMPTS,
    EVIDENCE_REPAIR_PIPELINE_VERSION,
    EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION,
    EVIDENCE_VALIDATION_VERSION,
    JUDGE_VIEW_VERSION,
)
from agentdebug.diagnostics.handoff import (
    HANDOFF_PIPELINE_VERSION,
    HANDOFF_PROMPT_PROTOCOL_VERSION,
)

from .adapter import ADAPTER_VERSION
from .prediction_manifest import (
    PREDICTION_MANIFEST_SCHEMA_VERSION,
    load_prediction_manifest,
    stable_sha256,
)
from .production_workflow import (
    PREDICT_RUN_SCHEMA_VERSION,
    PRODUCTION_TWO_STAGE_PIPELINE_VERSION,
    UNSCORED_PREDICTION_SCHEMA_VERSION,
)
from .prompts import (
    TWO_STAGE_PIPELINE_VERSION,
    TWO_STAGE_PROMPT_VERSION,
)
from .runner import BenchmarkRunConfig, TRANSPORT_POLICY_VERSION
from .stage_cache import (
    RAW_RESPONSE_SIDECAR_SCHEMA_VERSION,
    RAW_STAGE_SCHEMA_VERSION,
    STAGE_CACHE_SCHEMA_VERSION,
)


PREREGISTRATION_SCHEMA_VERSION = (
    "agentdebug.benchmark.production-preregistration.v1"
)
_CODE_PATHS = (
    "agentdebug/diagnostics/evidence_repair.py",
    "agentdebug/diagnostics/handoff.py",
    "agentdebug/diagnostics/judge_view.py",
    "agentdebug/diagnostics/providers.py",
    "agentdebug/diagnostics/taxonomy.py",
    "agentdebug/diagnostics/validator.py",
    "agentdebug/benchmark/acceptance.py",
    "agentdebug/benchmark/adapter.py",
    "agentdebug/benchmark/cli.py",
    "agentdebug/benchmark/cohort.py",
    "agentdebug/benchmark/dataset.py",
    "agentdebug/benchmark/metrics.py",
    "agentdebug/benchmark/prediction_manifest.py",
    "agentdebug/benchmark/prediction_worker.py",
    "agentdebug/benchmark/preregistration.py",
    "agentdebug/benchmark/production_workflow.py",
    "agentdebug/benchmark/prompts.py",
    "agentdebug/benchmark/reporting.py",
    "agentdebug/benchmark/runner.py",
    "agentdebug/benchmark/stage_cache.py",
)


class PreregistrationError(ValueError):
    """A production experiment cannot be frozen safely."""


def _reject_duplicate_keys(
    pairs: list[tuple[str, Any]],
) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, item in pairs:
        if key in value:
            raise PreregistrationError(
                f"preregistration contains duplicate key: {key}"
            )
        value[key] = item
    return value


def _read_preregistration(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(
            path.read_text(encoding="utf-8"),
            object_pairs_hook=_reject_duplicate_keys,
        )
    except (OSError, json.JSONDecodeError) as error:
        raise PreregistrationError(
            "preregistration is missing or invalid"
        ) from error
    if not isinstance(value, dict):
        raise PreregistrationError(
            "preregistration must be an object"
        )
    return value


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def write_production_preregistration(
    *,
    experiment_name: str,
    prediction_manifest_path: str | Path,
    output_path: str | Path,
    run_output_dir: str | Path,
    cache_dir: str | Path,
    config: BenchmarkRunConfig,
    expected_count: int,
    cumulative_logical_completions_before: int,
    maximum_new_logical_completions: int,
) -> dict[str, Any]:
    """Freeze all identities and the maximum paid-call envelope."""

    if not isinstance(experiment_name, str) or not experiment_name.strip():
        raise ValueError("experiment_name must be non-empty text")
    for field, value in (
        ("expected_count", expected_count),
        (
            "cumulative_logical_completions_before",
            cumulative_logical_completions_before,
        ),
        ("maximum_new_logical_completions", maximum_new_logical_completions),
    ):
        if (
            isinstance(value, bool)
            or not isinstance(value, int)
            or value < (1 if field != "cumulative_logical_completions_before" else 0)
        ):
            raise ValueError(f"{field} is invalid")
    if maximum_new_logical_completions > 3 * expected_count:
        raise ValueError(
            "maximum_new_logical_completions exceeds three stages per case"
        )
    if not config.api_key_env:
        raise ValueError(
            "preregistration requires an API-key environment-variable name"
        )

    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    manifest, cases = load_prediction_manifest(manifest_path)
    if len(cases) != expected_count:
        raise PreregistrationError(
            "prediction manifest count does not match the preregistration"
        )
    if config.cohort_sha256 != manifest["cohort_sha256"]:
        raise PreregistrationError(
            "provider config cohort does not match prediction manifest"
        )

    repository_root = Path(__file__).resolve().parents[2]
    code_bundle: dict[str, str] = {}
    for relative in _CODE_PATHS:
        path = repository_root / relative
        if not path.is_file():
            raise PreregistrationError(
                f"production code bundle file is missing: {relative}"
            )
        code_bundle[relative] = _file_sha256(path)

    document: dict[str, Any] = {
        "schema_version": PREREGISTRATION_SCHEMA_VERSION,
        "experiment_name": experiment_name.strip(),
        "prediction_manifest": {
            "path": str(manifest_path),
            "file_sha256": _file_sha256(manifest_path),
            "schema_version": PREDICTION_MANIFEST_SCHEMA_VERSION,
            "content_sha256": manifest["prediction_manifest_sha256"],
            "dataset_manifest_sha256": manifest[
                "dataset_manifest_sha256"
            ],
            "cohort_name": manifest["cohort_name"],
            "cohort_sha256": manifest["cohort_sha256"],
            "entry_count": len(cases),
            "trajectory_ids": [case.trajectory_id for case in cases],
            "case_input_sha256": [
                case.case_input_sha256 for case in cases
            ],
        },
        "implementation": {
            "adapter_version": ADAPTER_VERSION,
            "judge_view_version": JUDGE_VIEW_VERSION,
            "handoff_pipeline_version": HANDOFF_PIPELINE_VERSION,
            "handoff_prompt_protocol_version": (
                HANDOFF_PROMPT_PROTOCOL_VERSION
            ),
            "evidence_repair_pipeline_version": (
                EVIDENCE_REPAIR_PIPELINE_VERSION
            ),
            "evidence_repair_prompt_protocol_version": (
                EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
            ),
            "evidence_repair_max_attempts": EVIDENCE_REPAIR_MAX_ATTEMPTS,
            "two_stage_pipeline_version": TWO_STAGE_PIPELINE_VERSION,
            "two_stage_prompt_version": TWO_STAGE_PROMPT_VERSION,
            "production_pipeline_version": (
                PRODUCTION_TWO_STAGE_PIPELINE_VERSION
            ),
            "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
            "transport_policy_version": TRANSPORT_POLICY_VERSION,
            "unscored_prediction_schema_version": (
                UNSCORED_PREDICTION_SCHEMA_VERSION
            ),
            "predict_run_schema_version": PREDICT_RUN_SCHEMA_VERSION,
            "stage_cache_schema_version": STAGE_CACHE_SCHEMA_VERSION,
            "raw_stage_schema_version": RAW_STAGE_SCHEMA_VERSION,
            "raw_response_sidecar_schema_version": (
                RAW_RESPONSE_SIDECAR_SCHEMA_VERSION
            ),
        },
        "provider_config": config.public_dict(),
        "execution": {
            "run_output_dir": str(
                Path(run_output_dir).expanduser().resolve()
            ),
            "cache_dir": str(Path(cache_dir).expanduser().resolve()),
            "workers": 1,
            "retry_failures": False,
            "ledger_max_per_case": 1,
            "selector_max_per_parseable_ledger": 1,
            "repair_max_per_mechanically_eligible_selector": 1,
            "repair_eligibility": {
                "selector_mapped": True,
                "validation_issue_count": 1,
                "validation_issue_level": "error",
                "validation_issue_code": "evidence_quote_not_found",
            },
        },
        "logical_completion_budget": {
            "cumulative_before": cumulative_logical_completions_before,
            "maximum_new": maximum_new_logical_completions,
            "hard_cumulative_stop": (
                cumulative_logical_completions_before
                + maximum_new_logical_completions
            ),
            "http_transport_retries_are_not_logical_completions": True,
        },
        "promotion_gate": {
            "trajectory_denominator": expected_count,
            "step_exact_minimum_correct": 12,
            "step_module_exact_minimum_correct": 12,
            "evidence_invalid_maximum": 0,
            "other_hard_failures_maximum": 1,
            "eligible_repair_completion_rate": 1.0,
            "semantic_mutation_maximum": 0,
            "telemetry_coverage_complete": True,
            "gold_isolation_required": True,
            "raw_chain_reconstruction_required": True,
        },
        "code_bundle_sha256": stable_sha256(code_bundle),
        "code_bundle": code_bundle,
    }
    document["preregistration_sha256"] = stable_sha256(document)

    destination = Path(output_path).expanduser().resolve()
    if destination.is_file():
        try:
            existing = json.loads(destination.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as error:
            raise PreregistrationError(
                "existing preregistration is corrupt"
            ) from error
        if existing != document:
            differing = sorted(
                key
                for key in set(existing) | set(document)
                if existing.get(key) != document.get(key)
            )
            raise PreregistrationError(
                "existing preregistration conflicts with current identities: "
                + ", ".join(differing)
            )
        return document
    _atomic_json(destination, document)
    return document


def verify_production_preregistration(
    *,
    preregistration_path: str | Path,
    prediction_manifest_path: str | Path,
    run_output_dir: str | Path,
    cache_dir: str | Path,
    config: BenchmarkRunConfig,
    maximum_new_logical_completions: int,
) -> dict[str, Any]:
    """Recompute every frozen identity before a credentialed run starts."""

    path = Path(preregistration_path).expanduser().resolve()
    document = _read_preregistration(path)
    expected_fields = {
        "schema_version",
        "experiment_name",
        "prediction_manifest",
        "implementation",
        "provider_config",
        "execution",
        "logical_completion_budget",
        "promotion_gate",
        "code_bundle_sha256",
        "code_bundle",
        "preregistration_sha256",
    }
    if (
        set(document) != expected_fields
        or document.get("schema_version")
        != PREREGISTRATION_SCHEMA_VERSION
    ):
        raise PreregistrationError(
            "preregistration field set or schema is invalid"
        )
    body = dict(document)
    claimed_hash = body.pop("preregistration_sha256", None)
    if claimed_hash != stable_sha256(body):
        raise PreregistrationError(
            "preregistration self-hash is invalid"
        )
    budget = document.get("logical_completion_budget")
    if (
        not isinstance(budget, dict)
        or budget.get("maximum_new")
        != maximum_new_logical_completions
    ):
        raise PreregistrationError(
            "runtime logical-completion budget differs from preregistration"
        )
    prediction_manifest, cases = load_prediction_manifest(
        prediction_manifest_path
    )
    prediction_identity = document.get("prediction_manifest")
    if (
        not isinstance(prediction_identity, dict)
        or prediction_identity.get("content_sha256")
        != prediction_manifest["prediction_manifest_sha256"]
        or prediction_identity.get("entry_count")
        != len(cases)
    ):
        raise PreregistrationError(
            "runtime prediction manifest differs from preregistration"
        )
    cumulative_before = budget.get("cumulative_before")
    if (
        isinstance(cumulative_before, bool)
        or not isinstance(cumulative_before, int)
        or cumulative_before < 0
    ):
        raise PreregistrationError(
            "preregistration cumulative budget is invalid"
        )
    # The write-once constructor regenerates the complete implementation,
    # code-bundle, prompt, provider, artifact-path, gate, and budget identity.
    # Because the destination already exists it performs a strict equality
    # comparison and never rewrites the approved document.
    return write_production_preregistration(
        experiment_name=str(document.get("experiment_name", "")),
        prediction_manifest_path=prediction_manifest_path,
        output_path=path,
        run_output_dir=run_output_dir,
        cache_dir=cache_dir,
        config=config,
        expected_count=len(cases),
        cumulative_logical_completions_before=cumulative_before,
        maximum_new_logical_completions=(
            maximum_new_logical_completions
        ),
    )


__all__ = [
    "PREREGISTRATION_SCHEMA_VERSION",
    "PreregistrationError",
    "verify_production_preregistration",
    "write_production_preregistration",
]

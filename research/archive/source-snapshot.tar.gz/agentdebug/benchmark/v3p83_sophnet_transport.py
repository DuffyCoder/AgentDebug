"""Neutral Sophnet Chat Completions transport primitives for GAIA v3.83.

This module deliberately stops below experiment orchestration.  It provides:

* a gold-free, single-copy projection of one :class:`PredictionCase`;
* strict JSON response parsing and write-once stage artifact materialization;
* audited synchronous/asynchronous HTTP calls to the frozen Sophnet endpoint.

The host owns input projection, artifact writes, and validation.  The model is
not given a virtual filesystem or tools, and no function in this module reads
labels, scores, historical predictions, or other experiment artifacts.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import re
import socket
import time
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from agentdebug.benchmark.prediction_manifest import (
    PredictionCase,
    PredictionManifestError,
    _assert_gold_free,
)


SOPHNET_CHAT_COMPLETIONS_ENDPOINT = (
    "https://api.sophnet.com/v1/chat/completions"
)
V3P83_REQUESTED_MODEL = "gpt-5.5"
V3P83_REASONING_EFFORT = "medium"
V3P83_PROJECTION_SCHEMA_VERSION = (
    "agentdebug.v3p83-deduplicated-judge-view.v1"
)
V3P83_RESPONSE_CONTRACT_VERSION = "strict-stage-json-envelope.v1"

ANCHOR_STAGE = "packet-state-anchor"
CHALLENGER_STAGE = "earliest-causal-challenger"
ARBITER_STAGE = "default-keep-arbiter"
STAGE_NAMES = (ANCHOR_STAGE, CHALLENGER_STAGE, ARBITER_STAGE)

STEP_CANDIDATES_FILENAME = "step-candidates.json"
STEP_FREEZE_FILENAME = "step-freeze.json"
ANCHOR_PREDICTIONS_FILENAME = "anchor-predictions.json"
CHALLENGER_FILENAME = "challenger.json"
ARBITER_FILENAME = "arbiter.json"

ANCHOR_ENVELOPE_FIELDS = (
    "step_candidates",
    "step_freeze",
    "anchor_predictions",
)
CHALLENGER_ENVELOPE_FIELDS = ("challenger",)
ARBITER_ENVELOPE_FIELDS = ("arbiter",)

_SECRET_ENVIRONMENT_NAME = re.compile(
    r"^[A-Za-z_][A-Za-z0-9_]*$"
)
_BEARER_SECRET = re.compile(
    r"(?i)\bBearer\s+[A-Za-z0-9._~+\-/=]{12,}"
)
_RETRYABLE_HTTP_STATUSES = frozenset({408, 429, *range(500, 600)})


class DuplicateJsonKeyError(ValueError):
    """A provider response contains an ambiguous duplicate JSON key."""


class StageEnvelopeError(ValueError):
    """A response envelope cannot be materialized without semantic repair."""


class SophnetTransportError(RuntimeError):
    """A direct Chat Completions request failed closed."""

    def __init__(
        self,
        code: str,
        message: str,
        *,
        status_code: int | None = None,
        attempts: Sequence["HttpAttemptAudit"] = (),
    ) -> None:
        self.code = code
        self.status_code = status_code
        self.attempts = tuple(attempts)
        super().__init__(f"{code}: {message}")


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _pairs_without_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, item in pairs:
        if key in value:
            raise DuplicateJsonKeyError(f"duplicate JSON key: {key}")
        value[key] = item
    return value


def _reject_nonstandard_constant(value: str) -> None:
    raise ValueError(f"non-standard JSON constant: {value}")


def parse_strict_json_object(text: str) -> dict[str, Any]:
    """Parse exactly one JSON object, rejecting fences, NaN, and duplicate keys."""

    if not isinstance(text, str) or not text.strip():
        raise ValueError("model response must be non-empty JSON text")
    try:
        value = json.loads(
            text,
            object_pairs_hook=_pairs_without_duplicates,
            parse_constant=_reject_nonstandard_constant,
        )
    except json.JSONDecodeError as error:
        raise ValueError("model response is not strict JSON") from error
    if not isinstance(value, dict):
        raise ValueError("model response must contain exactly one JSON object")
    return value


def _observation_excerpt(observation: Any) -> str:
    """Remove only reconstructible cumulative wrapper history from an input."""

    projection = observation.benchmark_input
    if projection is not None:
        pieces = (
            observation.text[
                projection.step_marker_start_char : projection.step_marker_end_char
            ],
            observation.text[
                projection.observation_start_char : projection.observation_end_char
            ],
            observation.text[
                projection.interface_start_char : projection.interface_end_char
            ],
            observation.text[
                projection.suffix_start_char : projection.suffix_end_char
            ],
        )
        return "\n".join(piece.strip() for piece in pieces if piece.strip())
    if observation.repeated_prefix_chars > 0:
        return observation.incremental_text.strip()
    return observation.text.strip()


def _project_observation(observation: Any) -> dict[str, Any] | None:
    text = _observation_excerpt(observation)
    if not text:
        return None
    raw = observation
    return {
        "event_id": raw.event_id,
        "message_id": raw.message_id,
        "role": raw.role,
        "text": text,
        "linked_tool_result_ids": list(raw.linked_tool_result_ids),
        "source_refs": [asdict(item) for item in raw.source_refs],
        "projection": (
            "benchmark_current_observation_without_cumulative_history"
            if raw.benchmark_input is not None
            else (
                "incremental_suffix_without_exact_repeated_prefix"
                if raw.repeated_prefix_chars > 0
                else "complete_observation"
            )
        ),
        "original_text_chars": len(raw.text),
        "original_text_sha256": _sha256_bytes(raw.text.encode("utf-8")),
    }


def _project_observations(values: Sequence[Any]) -> list[dict[str, Any]]:
    projected: list[dict[str, Any]] = []
    for value in values:
        item = _project_observation(value)
        if item is not None:
            projected.append(item)
    return projected


def build_deduplicated_judge_view(case: PredictionCase) -> dict[str, Any]:
    """Build one complete decision-source projection without wrapper copies.

    Every assistant source range and tool-call object is retained verbatim via
    ``JudgeView.to_dict``.  For Step N > 1, current input must project exactly
    to Step N-1's adjacent feedback and is represented by a backward pointer.
    The only omitted text is cumulative benchmark history or a byte-identical
    repeated prefix already present elsewhere in the same projected case.
    """

    if not isinstance(case, PredictionCase):
        raise TypeError("v3.83 projection requires one PredictionCase")
    view = case.judge_view
    if not view.steps:
        raise PredictionManifestError("v3.83 projection requires at least one step")
    view_document = view.to_dict()
    steps_document = view_document.get("steps")
    if not isinstance(steps_document, list) or len(steps_document) != len(view.steps):
        raise PredictionManifestError("JudgeView step serialization changed")

    compact_steps: list[dict[str, Any]] = []
    prior_feedback: list[dict[str, Any]] | None = None
    input_before_first_step: list[dict[str, Any]] | None = None
    for index, (step, raw_step) in enumerate(
        zip(view.steps, steps_document, strict=True),
        start=1,
    ):
        current = _project_observations(step.current_input)
        feedback = _project_observations(step.adjacent_feedback)
        if index == 1:
            input_before_first_step = current
            input_binding: dict[str, Any] = {
                "kind": "input_before_first_step",
            }
        else:
            if current != prior_feedback:
                raise PredictionManifestError(
                    "deduplicated current input differs from prior feedback "
                    f"at step {index}"
                )
            input_binding = {
                "kind": "prior_step_feedback",
                "step": index - 1,
            }

        # Retain the serialized step in its original field order while replacing
        # only the duplicated current/feedback messages with explicit bindings.
        compact_step: dict[str, Any] = {}
        for key, value in raw_step.items():
            if key == "current_input":
                compact_step["current_input_binding"] = input_binding
            elif key == "adjacent_feedback":
                compact_step["feedback_after_step"] = feedback
            else:
                compact_step[key] = value
        if "module_spans" not in compact_step or "tool_calls" not in compact_step:
            raise PredictionManifestError(
                "deduplicated step omitted module spans or tool calls"
            )
        compact_steps.append(compact_step)
        prior_feedback = feedback

    projection: dict[str, Any] = {
        "schema_version": V3P83_PROJECTION_SCHEMA_VERSION,
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "case_input_sha256": case.case_input_sha256,
        "judge_view_version": view.version,
        "task": view_document.get("task"),
        "execution_facts": view_document.get("execution_facts"),
        "step_event_mapping": [
            {"step": step, "assistant_event_id": event_id}
            for step, event_id in case.step_event_mapping
        ],
        "input_before_first_step": input_before_first_step,
        "step_count": len(compact_steps),
        "steps": compact_steps,
        "deduplication_contract": {
            "omitted_content": (
                "only cumulative benchmark history or byte-identical repeated "
                "prefix text already represented in this case"
            ),
            "post_step_feedback_is_next_step_input": True,
            "assistant_raw_output_preserved": True,
            "complete_module_spans_preserved": True,
            "complete_tool_calls_and_results_preserved": True,
        },
    }
    _assert_gold_free(projection, location="v3.83 Sophnet input projection")
    return projection


def projection_audit(case: PredictionCase, projection: Mapping[str, Any]) -> dict[str, Any]:
    """Rebuild and hash a projection without consulting any scored artifact."""

    expected = build_deduplicated_judge_view(case)
    if dict(projection) != expected:
        raise PredictionManifestError("v3.83 Sophnet projection is not reproducible")
    serialized = _canonical_json_bytes(expected)
    return {
        "schema_version": "agentdebug.v3p83-sophnet-projection-audit.v1",
        "gold_free_validation": True,
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "projection_schema_version": V3P83_PROJECTION_SCHEMA_VERSION,
        "projection_sha256": _sha256_bytes(serialized),
        "projection_bytes": len(serialized),
        "step_count": len(case.judge_view.steps),
        "complete_module_spans_preserved": True,
        "complete_tool_calls_and_results_preserved": True,
    }


def _write_once_json(path: Path, value: Any) -> None:
    if path.exists():
        raise StageEnvelopeError(f"refusing to overwrite stage artifact: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    try:
        temporary.write_text(
            json.dumps(value, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        temporary.replace(path)
    finally:
        if temporary.exists():
            temporary.unlink()


def _one_record(value: Any, *, role: str) -> list[dict[str, Any]]:
    if (
        not isinstance(value, list)
        or len(value) != 1
        or not isinstance(value[0], dict)
    ):
        raise StageEnvelopeError(f"{role} must be a one-record JSON array")
    return value


def materialize_stage_envelope(
    stage: str,
    envelope: Mapping[str, Any],
    attempt_dir: str | Path,
) -> dict[str, Path]:
    """Write an exact provider envelope to frozen v3.83 stage filenames.

    No identity, hash, status, field order, or semantic value is normalized or
    repaired.  Existing protocol validators remain the sole legality authority.
    """

    if not isinstance(envelope, Mapping):
        raise StageEnvelopeError("stage response must be one JSON object")
    root = Path(attempt_dir).expanduser().resolve()

    if stage == ANCHOR_STAGE:
        if tuple(envelope) != ANCHOR_ENVELOPE_FIELDS:
            raise StageEnvelopeError("anchor response envelope fields/order differ")
        ledger = envelope["step_candidates"]
        checkpoint = envelope["step_freeze"]
        predictions = _one_record(
            envelope["anchor_predictions"], role="anchor_predictions"
        )
        if not isinstance(ledger, dict) or not isinstance(checkpoint, dict):
            raise StageEnvelopeError("anchor ledger/checkpoint must be JSON objects")
        paths = {
            STEP_CANDIDATES_FILENAME: root / STEP_CANDIDATES_FILENAME,
            STEP_FREEZE_FILENAME: root / STEP_FREEZE_FILENAME,
            ANCHOR_PREDICTIONS_FILENAME: root / ANCHOR_PREDICTIONS_FILENAME,
        }
        if any(path.exists() for path in paths.values()):
            raise StageEnvelopeError("refusing to overwrite stage artifact")
        _write_once_json(paths[STEP_CANDIDATES_FILENAME], ledger)
        _write_once_json(paths[STEP_FREEZE_FILENAME], checkpoint)
        _write_once_json(paths[ANCHOR_PREDICTIONS_FILENAME], predictions)
        return paths

    if stage == CHALLENGER_STAGE:
        if tuple(envelope) != CHALLENGER_ENVELOPE_FIELDS:
            raise StageEnvelopeError("challenger response envelope fields/order differ")
        challenger = _one_record(envelope["challenger"], role="challenger")
        path = root / CHALLENGER_FILENAME
        if path.exists():
            raise StageEnvelopeError("refusing to overwrite stage artifact")
        _write_once_json(path, challenger)
        return {CHALLENGER_FILENAME: path}

    if stage == ARBITER_STAGE:
        if tuple(envelope) != ARBITER_ENVELOPE_FIELDS:
            raise StageEnvelopeError("arbiter response envelope fields/order differ")
        arbiter = _one_record(envelope["arbiter"], role="arbiter")
        path = root / ARBITER_FILENAME
        if path.exists():
            raise StageEnvelopeError("refusing to overwrite stage artifact")
        _write_once_json(path, arbiter)
        return {ARBITER_FILENAME: path}

    raise StageEnvelopeError(f"unknown v3.83 stage: {stage}")


def redact_secret(value: str, secret: str | None = None) -> str:
    """Remove an exact credential and bearer-shaped values from audit text."""

    result = str(value)
    if secret:
        result = result.replace(secret, "[REDACTED]")
    return _BEARER_SECRET.sub("Bearer [REDACTED]", result)


def _usage_integer(*values: Any) -> int | None:
    for value in values:
        if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
            return value
    return None


def normalize_chat_usage(value: Any) -> dict[str, Any]:
    """Normalize OpenAI-compatible token names while preserving raw usage."""

    usage = dict(value) if isinstance(value, Mapping) else {}
    prompt_details = usage.get("prompt_tokens_details")
    completion_details = usage.get("completion_tokens_details")
    input_details = usage.get("input_tokens_details")
    output_details = usage.get("output_tokens_details")
    prompt_details = dict(prompt_details) if isinstance(prompt_details, Mapping) else {}
    completion_details = (
        dict(completion_details) if isinstance(completion_details, Mapping) else {}
    )
    input_details = dict(input_details) if isinstance(input_details, Mapping) else {}
    output_details = dict(output_details) if isinstance(output_details, Mapping) else {}
    return {
        "input_tokens": _usage_integer(
            usage.get("input_tokens"), usage.get("prompt_tokens")
        ),
        "output_tokens": _usage_integer(
            usage.get("output_tokens"), usage.get("completion_tokens")
        ),
        "total_tokens": _usage_integer(usage.get("total_tokens")),
        "cached_tokens": _usage_integer(
            input_details.get("cached_tokens"),
            prompt_details.get("cached_tokens"),
        ),
        "reasoning_tokens": _usage_integer(
            output_details.get("reasoning_tokens"),
            completion_details.get("reasoning_tokens"),
        ),
        "raw": usage,
    }


@dataclass(frozen=True)
class HttpAttemptAudit:
    attempt: int
    request_sha256: str
    elapsed_seconds: float
    status_code: int | None
    outcome: str
    retryable: bool
    error_code: str | None = None
    error_message: str | None = None


@dataclass(frozen=True)
class AuditedChatCompletion:
    endpoint: str
    wire_api: str
    requested_model: str
    resolved_model: str
    reasoning_effort: str
    request_sha256: str
    request_bytes: int
    response_sha256: str
    response_content_sha256: str
    finish_reason: str | None
    elapsed_seconds: float
    usage: dict[str, Any]
    content: str
    parsed_content: dict[str, Any]
    attempts: tuple[HttpAttemptAudit, ...]

    def audit_document(self) -> dict[str, Any]:
        """Return provenance without response content or authorization data."""

        return {
            "schema_version": "agentdebug.v3p83-sophnet-call-audit.v1",
            "endpoint": self.endpoint,
            "wire_api": self.wire_api,
            "requested_model": self.requested_model,
            "resolved_model": self.resolved_model,
            "reasoning_effort": self.reasoning_effort,
            "request_sha256": self.request_sha256,
            "request_bytes": self.request_bytes,
            "response_sha256": self.response_sha256,
            "response_content_sha256": self.response_content_sha256,
            "finish_reason": self.finish_reason,
            "elapsed_seconds": self.elapsed_seconds,
            "usage": self.usage,
            "http_attempts": [asdict(item) for item in self.attempts],
            "authorization_persisted": False,
            "fresh_stateless_request": True,
        }


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(  # type: ignore[override]
        self,
        req: urllib.request.Request,
        fp: Any,
        code: int,
        msg: str,
        headers: Any,
        newurl: str,
    ) -> None:
        del req, fp, code, msg, headers, newurl
        return None


def _default_open(request: urllib.request.Request, *, timeout: float) -> Any:
    opener = urllib.request.build_opener(_NoRedirectHandler())
    return opener.open(request, timeout=timeout)


def _retry_after_seconds(headers: Any) -> float | None:
    if headers is None:
        return None
    try:
        value = headers.get("Retry-After")
    except AttributeError:
        return None
    try:
        seconds = float(value)
    except (TypeError, ValueError):
        return None
    return seconds if seconds >= 0 else None


class SophnetChatCompletionsClient:
    """Audited, stateless direct HTTP client for the frozen v3.83 model config."""

    def __init__(
        self,
        *,
        api_key_env: str = "SOPHNET_API_KEY",
        endpoint: str = SOPHNET_CHAT_COMPLETIONS_ENDPOINT,
        model: str = V3P83_REQUESTED_MODEL,
        reasoning_effort: str = V3P83_REASONING_EFFORT,
        timeout_seconds: float = 600.0,
        max_http_attempts: int = 3,
        retry_backoff_seconds: float = 2.0,
        max_retry_delay_seconds: float = 65.0,
        open_request: Callable[..., Any] | None = None,
        sleep: Callable[[float], None] = time.sleep,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        if not _SECRET_ENVIRONMENT_NAME.fullmatch(api_key_env) or "=" in api_key_env:
            raise ValueError("API key environment-variable name is invalid")
        api_key = os.environ.get(api_key_env)
        if not api_key:
            raise ValueError(f"API key environment variable {api_key_env!r} is not set")
        if endpoint != SOPHNET_CHAT_COMPLETIONS_ENDPOINT:
            raise ValueError("v3.83 Sophnet endpoint must remain frozen")
        if model != V3P83_REQUESTED_MODEL:
            raise ValueError("v3.83 Sophnet model must remain gpt-5.5")
        if reasoning_effort != V3P83_REASONING_EFFORT:
            raise ValueError("v3.83 Sophnet reasoning effort must remain medium")
        if timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be positive")
        if max_http_attempts < 1 or max_http_attempts > 5:
            raise ValueError("max_http_attempts must be between 1 and 5")
        if retry_backoff_seconds < 0 or max_retry_delay_seconds < 0:
            raise ValueError("retry delays must not be negative")
        self.endpoint = endpoint
        self.model = model
        self.reasoning_effort = reasoning_effort
        self.timeout_seconds = float(timeout_seconds)
        self.max_http_attempts = int(max_http_attempts)
        self.retry_backoff_seconds = float(retry_backoff_seconds)
        self.max_retry_delay_seconds = float(max_retry_delay_seconds)
        self._api_key = api_key
        self._open_request = open_request or _default_open
        self._sleep = sleep
        self._monotonic = monotonic

    def request_payload(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
    ) -> dict[str, Any]:
        if not isinstance(system_prompt, str) or not system_prompt.strip():
            raise ValueError("system_prompt must be non-empty text")
        if not isinstance(user_prompt, str) or not user_prompt.strip():
            raise ValueError("user_prompt must be non-empty text")
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "reasoning_effort": self.reasoning_effort,
            "response_format": {"type": "json_object"},
        }
        if self._api_key in json.dumps(payload, ensure_ascii=False):
            raise SophnetTransportError(
                "secret_in_request_body",
                "the model request unexpectedly contains the API credential",
            )
        return payload

    def _delay(self, attempt: int, retry_after: float | None) -> None:
        exponential = self.retry_backoff_seconds * (2 ** max(0, attempt - 1))
        requested = retry_after if retry_after is not None else exponential
        delay = min(requested, self.max_retry_delay_seconds)
        if delay > 0:
            self._sleep(delay)

    def complete(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
    ) -> AuditedChatCompletion:
        """Perform one logical stateless completion with transport-only retries."""

        payload = self.request_payload(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
        )
        request_body = _canonical_json_bytes(payload)
        request_sha256 = _sha256_bytes(request_body)
        attempts: list[HttpAttemptAudit] = []
        logical_started = self._monotonic()

        for attempt in range(1, self.max_http_attempts + 1):
            started = self._monotonic()
            request = urllib.request.Request(
                self.endpoint,
                data=request_body,
                method="POST",
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                },
            )
            try:
                with self._open_request(
                    request,
                    timeout=self.timeout_seconds,
                ) as response:
                    status_value = getattr(response, "status", None)
                    status = int(
                        status_value
                        if status_value is not None
                        else response.getcode()
                    )
                    raw_response = response.read()
                elapsed = self._monotonic() - started
            except urllib.error.HTTPError as error:
                elapsed = self._monotonic() - started
                status = int(error.code)
                retryable = status in _RETRYABLE_HTTP_STATUSES
                # Provider error bodies are untrusted and can encode secrets in
                # ways that evade a raw substring scan.  Persist only the
                # status classification, never the body.
                message = f"Sophnet returned HTTP {status}"
                attempts.append(
                    HttpAttemptAudit(
                        attempt=attempt,
                        request_sha256=request_sha256,
                        elapsed_seconds=elapsed,
                        status_code=status,
                        outcome="http_error",
                        retryable=retryable,
                        error_code="http_error",
                        error_message=message,
                    )
                )
                if retryable and attempt < self.max_http_attempts:
                    self._delay(attempt, _retry_after_seconds(error.headers))
                    continue
                raise SophnetTransportError(
                    "http_error",
                    f"Sophnet returned HTTP {status}: {message}",
                    status_code=status,
                    attempts=attempts,
                ) from None
            except (urllib.error.URLError, TimeoutError, socket.timeout) as error:
                elapsed = self._monotonic() - started
                message = redact_secret(str(error), self._api_key)
                attempts.append(
                    HttpAttemptAudit(
                        attempt=attempt,
                        request_sha256=request_sha256,
                        elapsed_seconds=elapsed,
                        status_code=None,
                        outcome="transport_error",
                        retryable=True,
                        error_code="transport_error",
                        error_message=message,
                    )
                )
                if attempt < self.max_http_attempts:
                    self._delay(attempt, None)
                    continue
                raise SophnetTransportError(
                    "transport_error",
                    f"Sophnet request failed: {message}",
                    attempts=attempts,
                ) from None

            if not 200 <= status < 300:
                # A custom injected opener may not raise HTTPError.
                message = f"unexpected HTTP status {status}"
                attempts.append(
                    HttpAttemptAudit(
                        attempt=attempt,
                        request_sha256=request_sha256,
                        elapsed_seconds=elapsed,
                        status_code=status,
                        outcome="http_error",
                        retryable=status in _RETRYABLE_HTTP_STATUSES,
                        error_code="http_error",
                        error_message=message,
                    )
                )
                if status in _RETRYABLE_HTTP_STATUSES and attempt < self.max_http_attempts:
                    self._delay(attempt, None)
                    continue
                raise SophnetTransportError(
                    "http_error",
                    message,
                    status_code=status,
                    attempts=attempts,
                )

            if self._api_key.encode("utf-8") in raw_response:
                attempts.append(
                    HttpAttemptAudit(
                        attempt=attempt,
                        request_sha256=request_sha256,
                        elapsed_seconds=elapsed,
                        status_code=status,
                        outcome="secret_in_provider_response",
                        retryable=False,
                        error_code="secret_in_provider_response",
                        error_message=(
                            "provider response contained the request credential"
                        ),
                    )
                )
                raise SophnetTransportError(
                    "secret_in_provider_response",
                    "the provider response unexpectedly contained the API credential",
                    status_code=status,
                    attempts=attempts,
                )
            try:
                response_text = raw_response.decode("utf-8")
                provider = parse_strict_json_object(response_text)
                if self._api_key in json.dumps(provider, ensure_ascii=False):
                    raise ValueError(
                        "decoded provider response contained the request credential"
                    )
                choices = provider["choices"]
                if not isinstance(choices, list) or len(choices) != 1:
                    raise ValueError("provider response must contain exactly one choice")
                choice = choices[0]
                if not isinstance(choice, dict) or not isinstance(
                    choice.get("message"), dict
                ):
                    raise ValueError("provider response omitted assistant message")
                message = choice["message"]
                if message.get("role") != "assistant":
                    raise ValueError("provider response message role is not assistant")
                content = message.get("content")
                if not isinstance(content, str) or not content.strip():
                    raise ValueError("provider assistant content is empty or non-text")
                finish_reason = choice.get("finish_reason")
                if finish_reason != "stop":
                    raise ValueError(
                        f"provider finish_reason is not stop: {finish_reason!r}"
                    )
                resolved_model = provider.get("model")
                if resolved_model != self.model:
                    raise ValueError(
                        "resolved model mismatch: "
                        f"expected {self.model}, got {resolved_model!r}"
                    )
                parsed_content = parse_strict_json_object(content)
                usage = normalize_chat_usage(provider.get("usage"))
                if any(
                    not isinstance(usage.get(name), int)
                    for name in ("input_tokens", "output_tokens", "total_tokens")
                ):
                    raise ValueError("provider response omitted complete token usage")
            except (KeyError, TypeError, UnicodeDecodeError, ValueError) as error:
                attempts.append(
                    HttpAttemptAudit(
                        attempt=attempt,
                        request_sha256=request_sha256,
                        elapsed_seconds=elapsed,
                        status_code=status,
                        outcome="invalid_provider_response",
                        retryable=False,
                        error_code="invalid_provider_response",
                        error_message=redact_secret(str(error), self._api_key),
                    )
                )
                raise SophnetTransportError(
                    "invalid_provider_response",
                    redact_secret(str(error), self._api_key),
                    status_code=status,
                    attempts=attempts,
                ) from None

            attempts.append(
                HttpAttemptAudit(
                    attempt=attempt,
                    request_sha256=request_sha256,
                    elapsed_seconds=elapsed,
                    status_code=status,
                    outcome="success",
                    retryable=False,
                )
            )
            return AuditedChatCompletion(
                endpoint=self.endpoint,
                wire_api="chat_completions",
                requested_model=self.model,
                resolved_model=resolved_model,
                reasoning_effort=self.reasoning_effort,
                request_sha256=request_sha256,
                request_bytes=len(request_body),
                response_sha256=_sha256_bytes(raw_response),
                response_content_sha256=_sha256_bytes(content.encode("utf-8")),
                finish_reason=(
                    str(finish_reason) if finish_reason is not None else None
                ),
                elapsed_seconds=self._monotonic() - logical_started,
                usage=usage,
                content=content,
                parsed_content=parsed_content,
                attempts=tuple(attempts),
            )

        raise AssertionError("unreachable Sophnet HTTP retry state")

    async def acomplete(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
    ) -> AuditedChatCompletion:
        """Async facade with identical request bytes and validation semantics."""

        return await asyncio.to_thread(
            self.complete,
            system_prompt=system_prompt,
            user_prompt=user_prompt,
        )


__all__ = [
    "ANCHOR_ENVELOPE_FIELDS",
    "ANCHOR_PREDICTIONS_FILENAME",
    "ANCHOR_STAGE",
    "ARBITER_ENVELOPE_FIELDS",
    "ARBITER_FILENAME",
    "ARBITER_STAGE",
    "AuditedChatCompletion",
    "CHALLENGER_ENVELOPE_FIELDS",
    "CHALLENGER_FILENAME",
    "CHALLENGER_STAGE",
    "DuplicateJsonKeyError",
    "HttpAttemptAudit",
    "SOPHNET_CHAT_COMPLETIONS_ENDPOINT",
    "STEP_CANDIDATES_FILENAME",
    "STEP_FREEZE_FILENAME",
    "SophnetChatCompletionsClient",
    "SophnetTransportError",
    "StageEnvelopeError",
    "V3P83_PROJECTION_SCHEMA_VERSION",
    "V3P83_REASONING_EFFORT",
    "V3P83_REQUESTED_MODEL",
    "V3P83_RESPONSE_CONTRACT_VERSION",
    "build_deduplicated_judge_view",
    "materialize_stage_envelope",
    "normalize_chat_usage",
    "parse_strict_json_object",
    "projection_audit",
    "redact_secret",
]

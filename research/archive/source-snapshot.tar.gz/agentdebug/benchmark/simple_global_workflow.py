"""Minimal gold-isolated workflow for the one-call global semantic judge.

The production path has one semantic stage per batch.  The benchmark keeps the
historical ``two_stage`` metric slot only so existing acceptance reports remain
comparable; ``semantic_topology`` records the actual one-stage architecture.
"""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from agentdebug.diagnostics.batched_causal_judge import (
    BatchedAdjudication,
    BatchedCase,
    build_batched_case,
)
from agentdebug.diagnostics.batched_global_judge import (
    BATCHED_GLOBAL_PIPELINE_VERSION,
    BATCHED_GLOBAL_PROMPT_PROTOCOL_VERSION,
    BATCHED_GLOBAL_STAGE,
    batched_global_messages,
    parse_batched_global_isolated,
)
from agentdebug.diagnostics.judge_view import JUDGE_VIEW_VERSION
from agentdebug.diagnostics.parsing import JudgeOutputError

from .cohort import CohortManifest
from .fresh_semantic_workflow import (
    DurableLogicalCompletionBudget,
    load_fresh_semantic_completion_ledger,
)
from .metrics import compute_metrics
from .models import BenchmarkDataset
from .prediction_manifest import PredictionCase, load_prediction_manifest
from .runner import (
    TRANSPORT_POLICY_VERSION,
    BenchmarkRunConfig,
    _apply_root,
    _base_record,
)
from .stage_cache import (
    build_stage_request,
    run_cached_stage,
    stable_sha256,
    sum_stage_telemetry,
)


SIMPLE_GLOBAL_EXPERIMENT = "e9_v55_one_stage_global_judge"
SIMPLE_GLOBAL_METHOD = "two_stage"
SIMPLE_GLOBAL_TOPOLOGY = "one_stage_global"
SIMPLE_GLOBAL_SEMANTIC_CLASSIFIER = "raw_global_judge_output"
SIMPLE_GLOBAL_PLAN_SCHEMA_VERSION = "agentdebug.benchmark.e9-v55-plan.v1"
SIMPLE_GLOBAL_PREDICTION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-v55-unscored-prediction.v1"
)
SIMPLE_GLOBAL_RUN_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-v55-predict-run.v1"
)
SIMPLE_GLOBAL_EVIDENCE_VALIDATION_VERSION = (
    "e9-v55-source-id-step-module-owner-no-semantic-repair"
)
MAX_BATCH_SIZE = 3
MAX_REQUEST_CHARS = 800_000
_STAGES = (BATCHED_GLOBAL_STAGE,)


class SimpleGlobalWorkflowError(ValueError):
    """A v55 plan, prediction artifact, or scoring join is unsafe."""


@dataclass(frozen=True)
class GlobalBatchSpec:
    batch_id: str
    case_keys: tuple[str, ...]
    trajectory_ids: tuple[str, ...]
    ordered_case_input_sha256s: tuple[str, ...]
    request_chars: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "batch_id": self.batch_id,
            "case_keys": list(self.case_keys),
            "trajectory_ids": list(self.trajectory_ids),
            "ordered_case_input_sha256s": list(
                self.ordered_case_input_sha256s
            ),
            "request_chars": self.request_chars,
        }


@dataclass(frozen=True)
class GlobalBatchPlan:
    prediction_manifest_sha256: str
    selected_trajectory_ids: tuple[str, ...]
    batches: tuple[GlobalBatchSpec, ...]

    def to_dict(self) -> dict[str, Any]:
        body: dict[str, Any] = {
            "schema_version": SIMPLE_GLOBAL_PLAN_SCHEMA_VERSION,
            "pipeline_version": BATCHED_GLOBAL_PIPELINE_VERSION,
            "prompt_protocol_version": (
                BATCHED_GLOBAL_PROMPT_PROTOCOL_VERSION
            ),
            "semantic_topology": SIMPLE_GLOBAL_TOPOLOGY,
            "prediction_manifest_sha256": (
                self.prediction_manifest_sha256
            ),
            "selected_trajectory_ids": list(
                self.selected_trajectory_ids
            ),
            "maximum_batch_size": MAX_BATCH_SIZE,
            "maximum_request_chars": MAX_REQUEST_CHARS,
            "batch_count": len(self.batches),
            "batches": [batch.to_dict() for batch in self.batches],
        }
        body["batch_plan_sha256"] = stable_sha256(body)
        return body

    @property
    def batch_plan_sha256(self) -> str:
        return self.to_dict()["batch_plan_sha256"]


def _atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def _atomic_jsonl(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        "".join(
            json.dumps(row, ensure_ascii=False, default=str) + "\n"
            for row in rows
        ),
        encoding="utf-8",
    )
    temporary.replace(path)


def _read_object(path: Path, *, location: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise SimpleGlobalWorkflowError(f"{location} is unreadable") from error
    if not isinstance(value, Mapping):
        raise SimpleGlobalWorkflowError(f"{location} must be an object")
    return dict(value)


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as error:
        raise SimpleGlobalWorkflowError("prediction JSONL is unreadable") from error
    for line in lines:
        try:
            value = json.loads(line)
        except json.JSONDecodeError as error:
            raise SimpleGlobalWorkflowError("prediction JSONL is invalid") from error
        if not isinstance(value, Mapping):
            raise SimpleGlobalWorkflowError("prediction row must be an object")
        rows.append(dict(value))
    return rows


def _file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _assert_sha256(value: str, *, field: str) -> str:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise SimpleGlobalWorkflowError(f"{field} is not a SHA-256 digest")
    return value


def _assert_gold_free(value: Any, *, location: str) -> None:
    forbidden = {
        "all_correct",
        "confidence",
        "gold_error_type",
        "gold_event_id",
        "gold_module",
        "gold_reasoning",
        "gold_step",
        "score",
        "step_exact",
        "step_module_exact",
    }
    if isinstance(value, Mapping):
        for key, item in value.items():
            normalized = str(key).casefold()
            if normalized in forbidden or normalized.startswith("gold_"):
                raise SimpleGlobalWorkflowError(
                    f"{location} contains forbidden field {key}"
                )
            _assert_gold_free(item, location=f"{location}.{key}")
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _assert_gold_free(item, location=f"{location}[{index}]")


def _message_chars(messages: Sequence[Mapping[str, str]]) -> int:
    return sum(len(item["role"]) + len(item["content"]) for item in messages)


def _batched_cases(
    spec: GlobalBatchSpec,
    *,
    by_id: Mapping[str, PredictionCase],
) -> list[BatchedCase]:
    return [
        build_batched_case(case_key=key, view=by_id[trajectory_id].judge_view)
        for key, trajectory_id in zip(
            spec.case_keys,
            spec.trajectory_ids,
            strict=True,
        )
    ]


def _make_batch(cases: Sequence[PredictionCase]) -> GlobalBatchSpec:
    case_keys = tuple(f"C{index:02d}" for index in range(1, len(cases) + 1))
    temporary = GlobalBatchSpec(
        batch_id="pending",
        case_keys=case_keys,
        trajectory_ids=tuple(case.trajectory_id for case in cases),
        ordered_case_input_sha256s=tuple(
            case.case_input_sha256 for case in cases
        ),
        request_chars=0,
    )
    by_id = {case.trajectory_id: case for case in cases}
    request_chars = _message_chars(
        batched_global_messages(_batched_cases(temporary, by_id=by_id))
    )
    identity = {
        "case_keys": case_keys,
        "ordered_case_input_sha256s": temporary.ordered_case_input_sha256s,
        "prompt_protocol_version": BATCHED_GLOBAL_PROMPT_PROTOCOL_VERSION,
    }
    return GlobalBatchSpec(
        batch_id=f"GB_{stable_sha256(identity)[:20]}",
        case_keys=case_keys,
        trajectory_ids=temporary.trajectory_ids,
        ordered_case_input_sha256s=temporary.ordered_case_input_sha256s,
        request_chars=request_chars,
    )


def write_simple_global_batch_plan(
    *,
    prediction_manifest_path: str | Path,
    output_path: str | Path,
    selected_trajectory_ids: Sequence[str] | None = None,
) -> GlobalBatchPlan:
    """Freeze manifest-order cases into anonymous batches of at most three."""

    manifest, cases = load_prediction_manifest(prediction_manifest_path)
    by_id = {case.trajectory_id: case for case in cases}
    selected = (
        tuple(case.trajectory_id for case in cases)
        if selected_trajectory_ids is None
        else tuple(selected_trajectory_ids)
    )
    if (
        not selected
        or len(set(selected)) != len(selected)
        or any(trajectory_id not in by_id for trajectory_id in selected)
    ):
        raise SimpleGlobalWorkflowError("selected trajectory IDs are invalid")
    batches: list[GlobalBatchSpec] = []
    for start in range(0, len(selected), MAX_BATCH_SIZE):
        batch = _make_batch(
            [by_id[item] for item in selected[start : start + MAX_BATCH_SIZE]]
        )
        if batch.request_chars > MAX_REQUEST_CHARS:
            raise SimpleGlobalWorkflowError(
                "one v55 batch exceeds the request character limit"
            )
        batches.append(batch)
    plan = GlobalBatchPlan(
        prediction_manifest_sha256=manifest["prediction_manifest_sha256"],
        selected_trajectory_ids=selected,
        batches=tuple(batches),
    )
    _atomic_json(Path(output_path).expanduser().resolve(), plan.to_dict())
    return plan


def load_simple_global_batch_plan(
    path: str | Path,
    *,
    prediction_manifest_path: str | Path,
) -> GlobalBatchPlan:
    manifest, cases = load_prediction_manifest(prediction_manifest_path)
    value = _read_object(
        Path(path).expanduser().resolve(),
        location="v55 batch plan",
    )
    claimed = value.pop("batch_plan_sha256", None)
    if claimed != stable_sha256(value):
        raise SimpleGlobalWorkflowError("v55 batch plan hash is invalid")
    expected_headers = {
        "schema_version": SIMPLE_GLOBAL_PLAN_SCHEMA_VERSION,
        "pipeline_version": BATCHED_GLOBAL_PIPELINE_VERSION,
        "prompt_protocol_version": BATCHED_GLOBAL_PROMPT_PROTOCOL_VERSION,
        "semantic_topology": SIMPLE_GLOBAL_TOPOLOGY,
        "prediction_manifest_sha256": manifest["prediction_manifest_sha256"],
        "maximum_batch_size": MAX_BATCH_SIZE,
        "maximum_request_chars": MAX_REQUEST_CHARS,
    }
    if any(value.get(key) != item for key, item in expected_headers.items()):
        raise SimpleGlobalWorkflowError("v55 batch plan identity is invalid")
    selected = value.get("selected_trajectory_ids")
    raw_batches = value.get("batches")
    if not isinstance(selected, list) or not isinstance(raw_batches, list):
        raise SimpleGlobalWorkflowError("v55 batch plan shape is invalid")
    by_id = {case.trajectory_id: case for case in cases}
    if len(set(selected)) != len(selected) or any(item not in by_id for item in selected):
        raise SimpleGlobalWorkflowError("v55 plan selection is invalid")
    batches: list[GlobalBatchSpec] = []
    flattened: list[str] = []
    for raw in raw_batches:
        if not isinstance(raw, Mapping):
            raise SimpleGlobalWorkflowError("v55 batch must be an object")
        trajectory_ids = tuple(raw.get("trajectory_ids", ()))
        rebuilt = _make_batch([by_id[item] for item in trajectory_ids])
        if dict(raw) != rebuilt.to_dict():
            raise SimpleGlobalWorkflowError("v55 batch content is invalid")
        batches.append(rebuilt)
        flattened.extend(trajectory_ids)
    plan = GlobalBatchPlan(
        prediction_manifest_sha256=manifest["prediction_manifest_sha256"],
        selected_trajectory_ids=tuple(selected),
        batches=tuple(batches),
    )
    if (
        value.get("batch_count") != len(batches)
        or flattened != selected
        or plan.batch_plan_sha256 != claimed
    ):
        raise SimpleGlobalWorkflowError("v55 batch plan order is invalid")
    return plan


def _stage_request(
    *,
    spec: GlobalBatchSpec,
    source_cases: Sequence[PredictionCase],
    batched_cases: Sequence[BatchedCase],
    prediction_manifest: Mapping[str, Any],
    config: BenchmarkRunConfig,
):
    messages = batched_global_messages(batched_cases)
    identity = {
        "method": SIMPLE_GLOBAL_METHOD,
        "semantic_topology": SIMPLE_GLOBAL_TOPOLOGY,
        "experiment": SIMPLE_GLOBAL_EXPERIMENT,
        "pipeline_version": BATCHED_GLOBAL_PIPELINE_VERSION,
        "prompt_protocol_version": BATCHED_GLOBAL_PROMPT_PROTOCOL_VERSION,
        "evidence_validation_version": (
            SIMPLE_GLOBAL_EVIDENCE_VALIDATION_VERSION
        ),
        "judge_view_version": JUDGE_VIEW_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "prediction_manifest_sha256": prediction_manifest[
            "prediction_manifest_sha256"
        ],
        "batch_id": spec.batch_id,
        "case_keys": list(spec.case_keys),
        "ordered_case_input_sha256s": list(
            spec.ordered_case_input_sha256s
        ),
        "ordered_trajectory_sha256s": [
            case.trajectory_sha256 for case in source_cases
        ],
        "ordered_judge_view_sha256s": [
            stable_sha256(case.judge_view.to_dict()) for case in source_cases
        ],
        "provider_config": config.public_dict(),
    }
    request = build_stage_request(
        stage=BATCHED_GLOBAL_STAGE,
        messages=messages,
        identity=identity,
        dependency_sha256=stable_sha256(
            {
                "ordered_case_input_sha256s": (
                    spec.ordered_case_input_sha256s
                ),
                "no_prior_semantics": True,
            }
        ),
    )
    return request, messages


def _case_parse_outcome(error: JudgeOutputError) -> dict[str, Any]:
    return {
        "status": (
            "invalid_taxonomy"
            if error.code in {"invalid_taxonomy", "invalid_taxonomy_pair"}
            else "invalid_output"
        ),
        "failure_stage": error.stage,
        "failure_code": error.code,
        "failure_message": error.safe_message,
    }


def _outcome(stage: Mapping[str, Any]) -> dict[str, Any]:
    return {
        key: stage[key]
        for key in (
            "status",
            "failure_stage",
            "failure_code",
            "failure_message",
        )
    }


def _empty_semantics(outcome: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "status": outcome["status"],
        "failure_stage": outcome["failure_stage"],
        "failure_code": outcome["failure_code"],
        "failure_message": outcome["failure_message"],
        "root_cause_judgment": None,
        "judge_reported_step": None,
        "predicted_step": None,
        "predicted_event_id": None,
        "predicted_module": None,
        "predicted_error_type": None,
        "root_cause": None,
        "judge_audit": None,
        "decision": None,
        "evidence_source_id": None,
        "evidence_quote": None,
        "judge_step_matches_event_mapping": None,
    }


def _success_semantics(
    *,
    case: PredictionCase,
    adjudication: BatchedAdjudication,
) -> dict[str, Any]:
    root = adjudication.root
    mapped_step = case.step_for_event(root.critical_event_id)
    return {
        "status": "success",
        "failure_stage": None,
        "failure_code": None,
        "failure_message": None,
        "root_cause_judgment": root.to_dict(),
        "judge_reported_step": root.critical_step,
        "predicted_step": mapped_step,
        "predicted_event_id": root.critical_event_id,
        "predicted_module": root.module.value,
        "predicted_error_type": root.error_type.value,
        "root_cause": root.root_cause,
        "judge_audit": adjudication.audit,
        "decision": adjudication.decision.to_dict(),
        "evidence_source_id": adjudication.decision.evidence_source_id,
        "evidence_quote": root.evidence_quote,
        "judge_step_matches_event_mapping": (
            mapped_step is not None and mapped_step == root.critical_step
        ),
    }


def _isolated_document(raw: Any, *, cases: Sequence[BatchedCase]) -> dict[str, Any]:
    values, failures = parse_batched_global_isolated(raw, cases=cases)
    return {
        "cases": [
            {
                "case_key": case.case_key,
                "adjudication": (
                    None
                    if value is None
                    else {
                        "case_key": value.case_key,
                        "audit": value.audit,
                        "decision": value.decision.to_dict(),
                        "root": value.root.to_dict(),
                    }
                ),
                "failure": (
                    None if failure is None else _case_parse_outcome(failure)
                ),
            }
            for case, value, failure in zip(
                cases, values, failures, strict=True
            )
        ]
    }


def predict_simple_global_cases(
    *,
    prediction_manifest_path: str | Path,
    batch_plan_path: str | Path,
    preregistration_sha256: str,
    judge: Any,
    config: BenchmarkRunConfig,
    cache_dir: str | Path,
    unscored_output_path: str | Path,
    predict_run_metadata_path: str | Path,
    max_logical_completions: int,
    logical_completion_ledger_path: str | Path | None = None,
    cumulative_logical_completions_before: int = 0,
    authorized_cumulative_ceiling: int | None = None,
    on_batch: Callable[[Mapping[str, Any]], None] | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Predict from gold-free artifacts using exactly one stage per batch."""

    preregistration_digest = _assert_sha256(
        preregistration_sha256, field="preregistration_sha256"
    )
    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    plan_path = Path(batch_plan_path).expanduser().resolve()
    manifest, cases = load_prediction_manifest(manifest_path)
    plan = load_simple_global_batch_plan(
        plan_path, prediction_manifest_path=manifest_path
    )
    if config.cohort_sha256 != manifest["cohort_sha256"] or not config.api_key_env:
        raise SimpleGlobalWorkflowError("prediction/provider identity mismatch")
    if max_logical_completions < 1:
        raise SimpleGlobalWorkflowError("logical completion budget must be positive")
    complete = getattr(judge, "complete", None)
    if not callable(complete):
        raise TypeError("v55 prediction requires judge.complete(messages)")
    snapshotter = getattr(judge, "telemetry_snapshot", None)
    telemetry_snapshotter = snapshotter if callable(snapshotter) else None
    cache_resolved = Path(cache_dir).expanduser().resolve()
    cache_root = cache_resolved / "semantic_stages"
    output_path = Path(unscored_output_path).expanduser().resolve()
    run_path = Path(predict_run_metadata_path).expanduser().resolve()
    if output_path.parent != run_path.parent:
        raise SimpleGlobalWorkflowError("prediction artifacts must share a directory")
    ledger_path = (
        Path(logical_completion_ledger_path).expanduser().resolve()
        if logical_completion_ledger_path is not None
        else run_path.with_name("logical-completion-ledger.json")
    )
    if ledger_path.parent != output_path.parent:
        raise SimpleGlobalWorkflowError("ledger must share the prediction directory")
    ceiling = (
        cumulative_logical_completions_before + max_logical_completions
        if authorized_cumulative_ceiling is None
        else authorized_cumulative_ceiling
    )
    budget = DurableLogicalCompletionBudget(
        max_logical_completions,
        ledger_path=ledger_path,
        preregistration_sha256=preregistration_digest,
        cumulative_before=cumulative_logical_completions_before,
        authorized_cumulative_ceiling=ceiling,
        allowed_stages=_STAGES,
    )
    by_id = {case.trajectory_id: case for case in cases}
    rows: list[dict[str, Any]] = []
    _atomic_jsonl(output_path, rows)
    for batch_index, spec in enumerate(plan.batches, 1):
        source_cases = [by_id[item] for item in spec.trajectory_ids]
        batched_cases = _batched_cases(spec, by_id=by_id)
        request, messages = _stage_request(
            spec=spec,
            source_cases=source_cases,
            batched_cases=batched_cases,
            prediction_manifest=manifest,
            config=config,
        )
        if _message_chars(messages) != spec.request_chars:
            raise SimpleGlobalWorkflowError("request diverges from frozen plan")
        stage, cache_hit = run_cached_stage(
            request=request,
            messages=messages,
            complete=complete,
            parser=lambda raw, batch=tuple(batched_cases): _isolated_document(
                raw, cases=batch
            ),
            cache_root=cache_root,
            retry_failures=False,
            telemetry_snapshotter=telemetry_snapshotter,
            completion_guard=lambda request=request: budget.before_complete(
                stage=BATCHED_GLOBAL_STAGE,
                request_sha256=request.request_sha256,
            ),
        )
        adjudications: list[BatchedAdjudication | None] = [None] * len(batched_cases)
        failures: list[JudgeOutputError | None] = [None] * len(batched_cases)
        if stage["status"] == "success":
            adjudications, failures = parse_batched_global_isolated(
                stage["raw_response"], cases=batched_cases
            )
        stage_outcome = _outcome(stage)
        batch_rows: list[dict[str, Any]] = []
        for source_case, batched_case, adjudication, failure in zip(
            source_cases,
            batched_cases,
            adjudications,
            failures,
            strict=True,
        ):
            semantics = (
                _success_semantics(case=source_case, adjudication=adjudication)
                if adjudication is not None
                else _empty_semantics(
                    _case_parse_outcome(failure)
                    if failure is not None
                    else stage_outcome
                )
            )
            row: dict[str, Any] = {
                "schema_version": SIMPLE_GLOBAL_PREDICTION_SCHEMA_VERSION,
                "method": SIMPLE_GLOBAL_METHOD,
                "semantic_topology": SIMPLE_GLOBAL_TOPOLOGY,
                "experiment": SIMPLE_GLOBAL_EXPERIMENT,
                "pipeline_version": BATCHED_GLOBAL_PIPELINE_VERSION,
                "prompt_protocol_version": (
                    BATCHED_GLOBAL_PROMPT_PROTOCOL_VERSION
                ),
                "evidence_validation_version": (
                    SIMPLE_GLOBAL_EVIDENCE_VALIDATION_VERSION
                ),
                "semantic_classifier": SIMPLE_GLOBAL_SEMANTIC_CLASSIFIER,
                "transport_policy_version": TRANSPORT_POLICY_VERSION,
                "preregistration_sha256": preregistration_digest,
                "prediction_manifest_sha256": manifest[
                    "prediction_manifest_sha256"
                ],
                "batch_plan_sha256": plan.batch_plan_sha256,
                "batch_id": spec.batch_id,
                "batch_index": batch_index,
                "case_key": batched_case.case_key,
                "trajectory_id": source_case.trajectory_id,
                "trajectory_sha256": source_case.trajectory_sha256,
                "case_input_sha256": source_case.case_input_sha256,
                "provider_config": config.public_dict(),
                "cache_dir": str(cache_resolved),
                "stage_attempted": {BATCHED_GLOBAL_STAGE: True},
                "stage_cache_hits": {BATCHED_GLOBAL_STAGE: cache_hit},
                "stage_identity": {
                    "request_sha256": stage["request_sha256"],
                    "prompt_sha256": stage["prompt_sha256"],
                    "raw_response_sha256": stage["raw_response_sha256"],
                    "dependency_sha256": stage["identity"]["dependency_sha256"],
                },
                "stage_outcome": stage_outcome,
                "stage_provider_telemetry": stage["stage_telemetry"],
                "raw_judge_output": stage["raw_response"],
                "provider_telemetry": stage["stage_telemetry"],
                "latency_seconds": float(stage["latency_seconds"]),
                "cache_hit": cache_hit,
                **semantics,
            }
            _assert_gold_free(row, location="v55 unscored prediction")
            row["unscored_prediction_sha256"] = stable_sha256(row)
            batch_rows.append(row)
        rows.extend(batch_rows)
        _atomic_jsonl(output_path, rows)
        if on_batch is not None:
            on_batch(
                {
                    "batch_index": batch_index,
                    "batch_id": spec.batch_id,
                    "trajectory_ids": list(spec.trajectory_ids),
                    "cache_hit": cache_hit,
                    "stage_outcome": stage_outcome,
                }
            )
    first_by_batch: dict[str, dict[str, Any]] = {}
    for row in rows:
        first_by_batch.setdefault(row["batch_id"], row)
    telemetry_values = [
        row["provider_telemetry"]
        for row in first_by_batch.values()
        if row["provider_telemetry"] is not None
    ]
    ledger = budget.snapshot
    run_body: dict[str, Any] = {
        "schema_version": SIMPLE_GLOBAL_RUN_SCHEMA_VERSION,
        "method": SIMPLE_GLOBAL_METHOD,
        "semantic_topology": SIMPLE_GLOBAL_TOPOLOGY,
        "experiment": SIMPLE_GLOBAL_EXPERIMENT,
        "pipeline_version": BATCHED_GLOBAL_PIPELINE_VERSION,
        "prompt_protocol_version": BATCHED_GLOBAL_PROMPT_PROTOCOL_VERSION,
        "evidence_validation_version": SIMPLE_GLOBAL_EVIDENCE_VALIDATION_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "preregistration_sha256": preregistration_digest,
        "prediction_manifest_path": str(manifest_path),
        "prediction_manifest_file_sha256": _file_sha256(manifest_path),
        "prediction_manifest_sha256": manifest["prediction_manifest_sha256"],
        "batch_plan_path": str(plan_path),
        "batch_plan_file_sha256": _file_sha256(plan_path),
        "batch_plan_sha256": plan.batch_plan_sha256,
        "unscored_predictions_path": str(output_path),
        "unscored_predictions_sha256": _file_sha256(output_path),
        "predict_run_metadata_path": str(run_path),
        "cache_dir": str(cache_resolved),
        "selected_trajectory_ids": list(plan.selected_trajectory_ids),
        "prediction_count": len(rows),
        "batch_count": len(plan.batches),
        "provider_config": config.public_dict(),
        "provider_telemetry": (
            sum_stage_telemetry(telemetry_values) if telemetry_values else None
        ),
        "semantic_mutation_count": 0,
        "max_logical_completions": max_logical_completions,
        "logical_completion_budget_used": len(ledger["entries"]),
        "logical_completion_ledger_path": str(ledger_path),
        "logical_completion_ledger_file_sha256": _file_sha256(ledger_path),
        "logical_completion_ledger_sha256": ledger["ledger_sha256"],
        "retry_failures": False,
    }
    _assert_gold_free(run_body, location="v55 predict run")
    run_body["predict_run_sha256"] = stable_sha256(run_body)
    _atomic_json(run_path, run_body)
    return rows, run_body


def validate_simple_global_artifacts(
    *,
    prediction_manifest_path: str | Path,
    batch_plan_path: str | Path,
    unscored_predictions_path: str | Path,
    predict_run_metadata_path: str | Path,
) -> tuple[
    dict[str, Any],
    list[PredictionCase],
    GlobalBatchPlan,
    list[dict[str, Any]],
    dict[str, Any],
    BenchmarkRunConfig,
]:
    """Reconstruct every semantic field from raw output before scoring."""

    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    plan_path = Path(batch_plan_path).expanduser().resolve()
    output_path = Path(unscored_predictions_path).expanduser().resolve()
    run_path = Path(predict_run_metadata_path).expanduser().resolve()
    manifest, cases = load_prediction_manifest(manifest_path)
    plan = load_simple_global_batch_plan(plan_path, prediction_manifest_path=manifest_path)
    rows = _read_jsonl(output_path)
    run = _read_object(run_path, location="v55 predict run")
    claimed_run = run.pop("predict_run_sha256", None)
    if claimed_run != stable_sha256(run):
        raise SimpleGlobalWorkflowError("predict-run hash is invalid")
    run["predict_run_sha256"] = claimed_run
    if (
        run.get("unscored_predictions_sha256") != _file_sha256(output_path)
        or run.get("prediction_manifest_file_sha256") != _file_sha256(manifest_path)
        or run.get("batch_plan_file_sha256") != _file_sha256(plan_path)
        or run.get("selected_trajectory_ids") != list(plan.selected_trajectory_ids)
        or run.get("prediction_count") != len(rows)
        or run.get("batch_count") != len(plan.batches)
        or run.get("semantic_mutation_count") != 0
    ):
        raise SimpleGlobalWorkflowError("predict-run lineage is invalid")
    try:
        config = BenchmarkRunConfig(**run["provider_config"])
    except (KeyError, TypeError, ValueError) as error:
        raise SimpleGlobalWorkflowError("provider config is invalid") from error
    ledger_path = Path(run["logical_completion_ledger_path"]).resolve()
    ledger = load_fresh_semantic_completion_ledger(
        ledger_path,
        preregistration_sha256=run["preregistration_sha256"],
        maximum_new=run["max_logical_completions"],
        allowed_stages=_STAGES,
    )
    if (
        run["logical_completion_ledger_file_sha256"] != _file_sha256(ledger_path)
        or run["logical_completion_ledger_sha256"] != ledger["ledger_sha256"]
        or run["logical_completion_budget_used"] != len(ledger["entries"])
    ):
        raise SimpleGlobalWorkflowError("logical completion ledger is invalid")
    if len(rows) != len(plan.selected_trajectory_ids):
        raise SimpleGlobalWorkflowError("prediction count is incomplete")
    by_id = {case.trajectory_id: case for case in cases}
    validated: list[dict[str, Any]] = []
    offset = 0
    for batch_index, spec in enumerate(plan.batches, 1):
        count = len(spec.trajectory_ids)
        batch_rows = rows[offset : offset + count]
        offset += count
        if len(batch_rows) != count:
            raise SimpleGlobalWorkflowError("prediction ends inside a batch")
        source_cases = [by_id[item] for item in spec.trajectory_ids]
        batched_cases = _batched_cases(spec, by_id=by_id)
        request, messages = _stage_request(
            spec=spec,
            source_cases=source_cases,
            batched_cases=batched_cases,
            prediction_manifest=manifest,
            config=config,
        )
        first = batch_rows[0]
        raw = first.get("raw_judge_output")
        adjudications, failures = parse_batched_global_isolated(raw, cases=batched_cases)
        expected_shared = {
            "raw_judge_output",
            "stage_identity",
            "stage_outcome",
            "stage_provider_telemetry",
            "provider_telemetry",
            "latency_seconds",
            "cache_hit",
            "stage_cache_hits",
        }
        for row, source_case, batched_case, adjudication, failure in zip(
            batch_rows,
            source_cases,
            batched_cases,
            adjudications,
            failures,
            strict=True,
        ):
            body = dict(row)
            claimed = body.pop("unscored_prediction_sha256", None)
            if claimed != stable_sha256(body):
                raise SimpleGlobalWorkflowError("prediction row hash is invalid")
            if any(row.get(field) != first.get(field) for field in expected_shared):
                raise SimpleGlobalWorkflowError("batch stage envelopes diverge")
            identity = {
                "schema_version": SIMPLE_GLOBAL_PREDICTION_SCHEMA_VERSION,
                "method": SIMPLE_GLOBAL_METHOD,
                "semantic_topology": SIMPLE_GLOBAL_TOPOLOGY,
                "experiment": SIMPLE_GLOBAL_EXPERIMENT,
                "pipeline_version": BATCHED_GLOBAL_PIPELINE_VERSION,
                "prompt_protocol_version": BATCHED_GLOBAL_PROMPT_PROTOCOL_VERSION,
                "evidence_validation_version": SIMPLE_GLOBAL_EVIDENCE_VALIDATION_VERSION,
                "semantic_classifier": SIMPLE_GLOBAL_SEMANTIC_CLASSIFIER,
                "transport_policy_version": TRANSPORT_POLICY_VERSION,
                "preregistration_sha256": run["preregistration_sha256"],
                "prediction_manifest_sha256": manifest["prediction_manifest_sha256"],
                "batch_plan_sha256": plan.batch_plan_sha256,
                "batch_id": spec.batch_id,
                "batch_index": batch_index,
                "case_key": batched_case.case_key,
                "trajectory_id": source_case.trajectory_id,
                "trajectory_sha256": source_case.trajectory_sha256,
                "case_input_sha256": source_case.case_input_sha256,
                "provider_config": config.public_dict(),
                "cache_dir": run["cache_dir"],
                "stage_attempted": {BATCHED_GLOBAL_STAGE: True},
            }
            if any(row.get(key) != value for key, value in identity.items()):
                raise SimpleGlobalWorkflowError("prediction identity is invalid")
            stage_identity = row.get("stage_identity")
            if not isinstance(stage_identity, Mapping) or (
                stage_identity.get("request_sha256") != request.request_sha256
                or stage_identity.get("prompt_sha256") != request.prompt_sha256
                or stage_identity.get("raw_response_sha256") != stable_sha256(raw)
                or stage_identity.get("dependency_sha256")
                != request.identity["dependency_sha256"]
            ):
                raise SimpleGlobalWorkflowError("stage identity is invalid")
            semantics = (
                _success_semantics(case=source_case, adjudication=adjudication)
                if adjudication is not None
                else _empty_semantics(
                    _case_parse_outcome(failure)
                    if failure is not None
                    else row["stage_outcome"]
                )
            )
            if any(row.get(key) != value for key, value in semantics.items()):
                raise SimpleGlobalWorkflowError("semantics diverge from raw judge output")
            _assert_gold_free(row, location="v55 validated prediction")
            validated.append(row)
    return manifest, cases, plan, validated, run, config


def score_simple_global_predictions(
    *,
    dataset: BenchmarkDataset,
    cohort: CohortManifest,
    prediction_manifest_path: str | Path,
    batch_plan_path: str | Path,
    unscored_predictions_path: str | Path,
    predict_run_metadata_path: str | Path,
) -> tuple[list[dict[str, Any]], dict[str, Any], dict[str, Any]]:
    """Join gold only after raw responses and prediction lineage validate."""

    manifest, cases, plan, rows, run, config = validate_simple_global_artifacts(
        prediction_manifest_path=prediction_manifest_path,
        batch_plan_path=batch_plan_path,
        unscored_predictions_path=unscored_predictions_path,
        predict_run_metadata_path=predict_run_metadata_path,
    )
    if (
        dataset.dataset_sha256 != manifest["dataset_manifest_sha256"]
        or cohort.dataset_manifest_sha256 != manifest["dataset_manifest_sha256"]
        or cohort.cohort_name != manifest["cohort_name"]
        or cohort.cohort_sha256 != manifest["cohort_sha256"]
        or not set(plan.selected_trajectory_ids) <= set(cohort.trajectory_ids)
    ):
        raise SimpleGlobalWorkflowError("scoring dataset/cohort lineage is invalid")
    examples = {example.label.trajectory_id: example for example in dataset.examples}
    by_case = {case.trajectory_id: case for case in cases}
    by_row = {row["trajectory_id"]: row for row in rows}
    parsed_by_id: dict[str, BatchedAdjudication] = {}
    by_id = {case.trajectory_id: case for case in cases}
    for spec in plan.batches:
        batch_rows = [by_row[item] for item in spec.trajectory_ids]
        adjudications, _failures = parse_batched_global_isolated(
            batch_rows[0]["raw_judge_output"],
            cases=_batched_cases(spec, by_id=by_id),
        )
        for trajectory_id, adjudication in zip(
            spec.trajectory_ids, adjudications, strict=True
        ):
            if adjudication is not None:
                parsed_by_id[trajectory_id] = adjudication
    scored: list[dict[str, Any]] = []
    for trajectory_id in plan.selected_trajectory_ids:
        row = by_row[trajectory_id]
        example = examples.get(trajectory_id)
        case = by_case[trajectory_id]
        if example is None or (
            example.mapping.trajectory_sha256 != case.trajectory_sha256
            or tuple(
                (item.original_step, item.critical_event_id)
                for item in example.mapping.steps
            ) != case.step_event_mapping
        ):
            raise SimpleGlobalWorkflowError("scoring adaptation diverges")
        record = _base_record(example, method=SIMPLE_GLOBAL_METHOD, config=config)
        record.update(
            {
                "status": row["status"],
                "failure_stage": row["failure_stage"],
                "failure_code": row["failure_code"],
                "failure_message": row["failure_message"],
                "root_cause_judgment": row["root_cause_judgment"],
                "raw_judge_outputs": {BATCHED_GLOBAL_STAGE: row["raw_judge_output"]},
                "latency_seconds": row["latency_seconds"],
                "cache_hit": row["cache_hit"],
                "prompt_version": BATCHED_GLOBAL_PROMPT_PROTOCOL_VERSION,
                "pipeline_version": BATCHED_GLOBAL_PIPELINE_VERSION,
                "experiment": SIMPLE_GLOBAL_EXPERIMENT,
                "semantic_topology": SIMPLE_GLOBAL_TOPOLOGY,
                "semantic_classifier": SIMPLE_GLOBAL_SEMANTIC_CLASSIFIER,
                "preregistration_sha256": row["preregistration_sha256"],
                "prediction_manifest_sha256": row["prediction_manifest_sha256"],
                "batch_plan_sha256": row["batch_plan_sha256"],
                "batch_id": row["batch_id"],
                "batch_index": row["batch_index"],
                "case_key": row["case_key"],
                "evidence_source_id": row["evidence_source_id"],
                "evidence_quote": row["evidence_quote"],
                "judge_audit": row["judge_audit"],
                "decision": row["decision"],
            }
        )
        adjudication = parsed_by_id.get(trajectory_id)
        if adjudication is not None:
            _apply_root(record, example=example, root=adjudication.root)
        scored.append(record)
    return scored, compute_metrics(scored), run


__all__ = [
    "GlobalBatchPlan",
    "GlobalBatchSpec",
    "MAX_BATCH_SIZE",
    "MAX_REQUEST_CHARS",
    "SIMPLE_GLOBAL_EXPERIMENT",
    "SIMPLE_GLOBAL_METHOD",
    "SIMPLE_GLOBAL_TOPOLOGY",
    "SimpleGlobalWorkflowError",
    "load_simple_global_batch_plan",
    "predict_simple_global_cases",
    "score_simple_global_predictions",
    "validate_simple_global_artifacts",
    "write_simple_global_batch_plan",
]

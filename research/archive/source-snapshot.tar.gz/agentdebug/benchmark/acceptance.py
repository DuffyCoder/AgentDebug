"""Fail-closed verification for the fixed final AgentErrorBench smoke run."""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

from agentdebug.diagnostics import (
    EVIDENCE_VALIDATION_VERSION,
    JUDGE_VIEW_VERSION,
)

from .cohort import CohortManifest
from .metrics import compute_metrics
from .models import BenchmarkDataset
from .production_workflow import (
    PRODUCTION_TWO_STAGE_PIPELINE_VERSION,
    score_persisted_predictions,
)
from .prediction_manifest import stable_sha256
from .prompts import (
    TWO_STAGE_PIPELINE_VERSION,
    TWO_STAGE_PROMPT_VERSION,
)
from .reporting import (
    ARTIFACT_MANIFEST_SCHEMA_VERSION,
    render_report,
)
from .runner import TRANSPORT_POLICY_VERSION


FINAL_PROVIDER = "openai-compatible"
FINAL_ENDPOINT = "https://api.sophnet.com/v1/chat/completions"
FINAL_MODEL = "gpt-4.1"
FINAL_TEMPERATURE = 0
FINAL_TIMEOUT_SECONDS = 600
FINAL_MAX_OUTPUT_TOKENS = 8192
FINAL_MAX_RETRIES = 5
FINAL_RETRY_BACKOFF_SECONDS = 2
FINAL_WORKERS = 1
FINAL_METHOD = "two_stage"
FINAL_DENOMINATOR = 30
FINAL_ENVIRONMENT_DENOMINATOR = 10
FINAL_MAX_LOGICAL_COMPLETIONS = 90
MINIMUM_STEP_CORRECT = 12
BASELINE_STEP_MODULE_CORRECT = 2
FROZEN_BASELINE_METRICS_SHA256 = (
    "520749a1012b4187b455773ad5e8541216fd75e5588479af49132a0bacdafdd4"
)
FROZEN_BASELINE_METRICS_RELATIVE_PATH = (
    "output/agenterrorbench-gpt-4.1-smoke-v1-baseline/metrics.json"
)
MAXIMUM_FAILURE_RATE = 0.05
FINAL_ACCEPTANCE_SCHEMA_VERSION = (
    "agentdebug.benchmark.final-smoke-acceptance.v1"
)


class AcceptanceError(ValueError):
    """A purported final artifact does not satisfy the frozen contract."""


@dataclass(frozen=True)
class AcceptanceResult:
    accepted: bool
    checks: dict[str, bool]
    summary: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "accepted": self.accepted,
            "checks": dict(self.checks),
            "summary": dict(self.summary),
        }


def _nonnegative_int(value: Any) -> bool:
    return (
        isinstance(value, int)
        and not isinstance(value, bool)
        and value >= 0
    )


def _provider_telemetry_valid(
    telemetry: Any,
    *,
    max_retries: int,
) -> bool:
    if not isinstance(telemetry, Mapping):
        return False
    logical = telemetry.get("logical_completion_count")
    http = telemetry.get("http_attempt_count")
    retries = telemetry.get("retry_count")
    if not all(_nonnegative_int(item) for item in (logical, http, retries)):
        return False
    return (
        http == logical + retries
        and retries <= logical * max_retries
    )


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _reject_duplicate_keys(
    pairs: list[tuple[str, Any]],
) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, item in pairs:
        if key in value:
            raise AcceptanceError(
                f"artifact JSON contains duplicate key: {key}"
            )
        value[key] = item
    return value


def _read_json_object(path: Path, *, label: str) -> dict[str, Any]:
    try:
        value = json.loads(
            path.read_text(encoding="utf-8"),
            object_pairs_hook=_reject_duplicate_keys,
        )
    except (OSError, json.JSONDecodeError) as error:
        raise AcceptanceError(
            f"{label} is missing or invalid JSON"
        ) from error
    if not isinstance(value, dict):
        raise AcceptanceError(f"{label} must be a JSON object")
    return value


def _read_jsonl_objects(
    path: Path,
    *,
    label: str,
) -> list[dict[str, Any]]:
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as error:
        raise AcceptanceError(f"{label} is missing") from error
    values: list[dict[str, Any]] = []
    for line_number, line in enumerate(lines, 1):
        if not line.strip():
            continue
        try:
            value = json.loads(
                line,
                object_pairs_hook=_reject_duplicate_keys,
            )
        except json.JSONDecodeError as error:
            raise AcceptanceError(
                f"{label} line {line_number} is invalid JSON"
            ) from error
        if not isinstance(value, dict):
            raise AcceptanceError(
                f"{label} line {line_number} is not an object"
            )
        values.append(value)
    return values


def _verify_frozen_smoke_baseline(
    *,
    dataset: BenchmarkDataset,
    cohort: CohortManifest,
) -> dict[str, Any]:
    path = (
        Path(__file__).resolve().parents[2]
        / FROZEN_BASELINE_METRICS_RELATIVE_PATH
    )
    if _file_sha256(path) != FROZEN_BASELINE_METRICS_SHA256:
        raise AcceptanceError(
            "frozen smoke baseline metrics file hash is invalid"
        )
    document = _read_json_object(
        path,
        label="frozen smoke baseline metrics",
    )
    try:
        run = document["run"]
        overall = document["metrics"]["by_method"][FINAL_METHOD][
            "overall"
        ]
        selection = run["selection"]
    except (KeyError, TypeError) as error:
        raise AcceptanceError(
            "frozen smoke baseline is structurally incomplete"
        ) from error
    checks = {
        "methods": run.get("methods") == [FINAL_METHOD],
        "provider": run.get("provider") == FINAL_PROVIDER,
        "endpoint": run.get("endpoint") == FINAL_ENDPOINT,
        "model": run.get("model") == FINAL_MODEL,
        "temperature": run.get("temperature") == FINAL_TEMPERATURE,
        "timeout": run.get("timeout") == FINAL_TIMEOUT_SECONDS,
        "max_output_tokens": run.get("max_output_tokens")
        == FINAL_MAX_OUTPUT_TOKENS,
        "max_retries": run.get("max_retries") == FINAL_MAX_RETRIES,
        "retry_backoff": run.get("retry_backoff")
        == FINAL_RETRY_BACKOFF_SECONDS,
        "workers": run.get("workers") == FINAL_WORKERS,
        "dataset": selection.get("dataset_manifest_sha256")
        == dataset.dataset_sha256,
        "cohort_name": selection.get("cohort") == "smoke-v1",
        "cohort_hash": selection.get("cohort_sha256")
        == cohort.cohort_sha256,
        "trajectory_count": overall.get("trajectory_count")
        == FINAL_DENOMINATOR,
        "step_denominator": overall.get("step_exact", {}).get(
            "denominator"
        )
        == FINAL_DENOMINATOR,
        "step_module_denominator": overall.get(
            "step_module_exact",
            {},
        ).get("denominator")
        == FINAL_DENOMINATOR,
        "step_module_correct": overall.get(
            "step_module_exact",
            {},
        ).get("correct")
        == BASELINE_STEP_MODULE_CORRECT,
    }
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise AcceptanceError(
            "frozen smoke baseline identity failed: "
            + ", ".join(failed)
        )
    return {
        "path": str(path),
        "file_sha256": FROZEN_BASELINE_METRICS_SHA256,
        "step_correct": overall["step_exact"]["correct"],
        "step_denominator": overall["step_exact"]["denominator"],
        "step_module_correct": overall["step_module_exact"]["correct"],
        "step_module_denominator": overall[
            "step_module_exact"
        ]["denominator"],
        "all_correct": overall["all_correct"]["correct"],
        "all_denominator": overall["all_correct"]["denominator"],
        "failed_prediction_count": overall["failed_prediction_count"],
    }


def verify_final_smoke(
    *,
    metrics: Mapping[str, Any],
    run_metadata: Mapping[str, Any],
    expected_dataset_sha256: str,
    expected_cohort_sha256: str,
    minimum_step_module_correct: int,
) -> AcceptanceResult:
    """Verify identities and frozen thresholds without reading per-case gold."""

    if not _nonnegative_int(minimum_step_module_correct):
        raise ValueError(
            "minimum_step_module_correct must be a non-negative integer"
        )
    try:
        overall = metrics["by_method"][FINAL_METHOD]["overall"]
        step = overall["step_exact"]
        step_module = overall["step_module_exact"]
        selection = run_metadata["selection"]
    except (KeyError, TypeError) as error:
        raise AcceptanceError(
            "final smoke metrics or metadata are structurally incomplete"
        ) from error

    max_failures = math.floor(
        FINAL_DENOMINATOR * MAXIMUM_FAILURE_RATE
    )
    capabilities = run_metadata.get("provider_capabilities")
    telemetry_coverage = run_metadata.get(
        "provider_telemetry_coverage"
    )
    response_format_capability = (
        capabilities.get("response_format_json_object")
        if isinstance(capabilities, Mapping)
        else None
    )
    gold_isolation = run_metadata.get("gold_isolation")
    pipeline_versions = run_metadata.get("pipeline_versions")
    prompt_versions = run_metadata.get("prompt_versions")
    checks = {
        "metrics_only_two_stage": set(metrics.get("by_method", {}))
        == {FINAL_METHOD},
        "only_two_stage": run_metadata.get("methods") == [FINAL_METHOD],
        "provider": run_metadata.get("provider") == FINAL_PROVIDER,
        "endpoint": run_metadata.get("endpoint") == FINAL_ENDPOINT,
        "model": run_metadata.get("model") == FINAL_MODEL,
        "temperature": run_metadata.get("temperature")
        == FINAL_TEMPERATURE,
        "timeout": run_metadata.get("timeout") == FINAL_TIMEOUT_SECONDS,
        "max_output_tokens": run_metadata.get("max_output_tokens")
        == FINAL_MAX_OUTPUT_TOKENS,
        "max_retries": run_metadata.get("max_retries")
        == FINAL_MAX_RETRIES,
        "retry_backoff": run_metadata.get("retry_backoff")
        == FINAL_RETRY_BACKOFF_SECONDS,
        "workers": run_metadata.get("workers") == FINAL_WORKERS,
        "execution_order": run_metadata.get("execution_order")
        == "dataset",
        "retry_failures_disabled": run_metadata.get("retry_failures")
        is False,
        "fresh_run_not_resume": run_metadata.get("resume") is False,
        "logical_completion_budget": run_metadata.get(
            "max_logical_completions"
        )
        == FINAL_MAX_LOGICAL_COMPLETIONS,
        "judge_view_version": run_metadata.get("judge_view_version")
        == JUDGE_VIEW_VERSION,
        "two_stage_prompt_version": (
            isinstance(prompt_versions, Mapping)
            and prompt_versions.get(FINAL_METHOD)
            == TWO_STAGE_PROMPT_VERSION
        ),
        "two_stage_pipeline_version": (
            run_metadata.get("diagnostic_pipeline_version")
            == TWO_STAGE_PIPELINE_VERSION
            and isinstance(pipeline_versions, Mapping)
            and pipeline_versions.get(FINAL_METHOD)
            == TWO_STAGE_PIPELINE_VERSION
        ),
        "production_pipeline_version": run_metadata.get(
            "production_two_stage_pipeline_version"
        )
        == PRODUCTION_TWO_STAGE_PIPELINE_VERSION,
        "transport_policy_version": run_metadata.get(
            "transport_policy_version"
        )
        == TRANSPORT_POLICY_VERSION,
        "evidence_validation_version": run_metadata.get(
            "evidence_validation_version"
        )
        == EVIDENCE_VALIDATION_VERSION,
        "gold_isolation": (
            isinstance(gold_isolation, Mapping)
            and gold_isolation.get("enabled") is True
            and gold_isolation.get("prediction_input_type")
            == "hash_locked_gold_free_judge_view_manifest"
            and gold_isolation.get("raw_first_stage_cache") is True
            and gold_isolation.get(
                "provider_process_isolated_from_dataset"
            )
            is True
            and gold_isolation.get(
                "unscored_persisted_before_gold_scoring"
            )
            is True
            and isinstance(
                gold_isolation.get("prediction_manifest_sha256"),
                str,
            )
            and isinstance(
                gold_isolation.get("unscored_predictions_sha256"),
                str,
            )
            and isinstance(
                gold_isolation.get("predict_run_sha256"),
                str,
            )
        ),
        "dataset_sha256": selection.get("dataset_manifest_sha256")
        == expected_dataset_sha256,
        "cohort_name": selection.get("cohort") == "smoke-v1",
        "cohort_sha256": selection.get("cohort_sha256")
        == expected_cohort_sha256,
        "trajectory_count": overall.get("trajectory_count")
        == FINAL_DENOMINATOR,
        "step_denominator": step.get("denominator") == FINAL_DENOMINATOR,
        "step_correct": _nonnegative_int(step.get("correct"))
        and step["correct"] >= MINIMUM_STEP_CORRECT,
        "step_module_denominator": step_module.get("denominator")
        == FINAL_DENOMINATOR,
        "step_module_not_regressed": _nonnegative_int(
            step_module.get("correct")
        )
        and step_module["correct"] >= minimum_step_module_correct,
        "failed_outputs": _nonnegative_int(
            overall.get("failed_prediction_count")
        )
        and overall["failed_prediction_count"] <= max_failures,
        "provider_telemetry": _provider_telemetry_valid(
            run_metadata.get("provider_telemetry"),
            max_retries=int(run_metadata.get("max_retries", -1)),
        )
        if _nonnegative_int(run_metadata.get("max_retries"))
        else False,
        "provider_telemetry_complete": (
            isinstance(telemetry_coverage, Mapping)
            and telemetry_coverage.get("complete") is True
            and _nonnegative_int(
                telemetry_coverage.get("attempted_stage_count")
            )
            and telemetry_coverage.get("recorded_stage_count")
            == telemetry_coverage.get("attempted_stage_count")
            and telemetry_coverage.get("missing_stage_count") == 0
            and telemetry_coverage.get("missing_stage_refs") == []
        ),
        "json_mode_capability_recorded": (
            isinstance(capabilities, Mapping)
            and response_format_capability
            in {"supported", "unsupported"}
            and capabilities.get("fallback_output_contract")
            == "strict_json_prompt"
            and _nonnegative_int(
                capabilities.get("response_format_fallback_count")
            )
        ),
        "prediction_count": run_metadata.get("prediction_count")
        == FINAL_DENOMINATOR,
        "metric_cohort_count": run_metadata.get("metric_cohort_count")
        == FINAL_DENOMINATOR,
        "judge_input_count": run_metadata.get("judge_input_count")
        == FINAL_DENOMINATOR,
        "repair_completion": (
            _nonnegative_int(run_metadata.get("repair_eligible_count"))
            and run_metadata.get("repair_attempt_count")
            == run_metadata.get("repair_eligible_count")
            and _nonnegative_int(run_metadata.get("repair_applied_count"))
            and run_metadata.get("repair_applied_count")
            <= run_metadata.get("repair_attempt_count")
        ),
    }
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise AcceptanceError(
            "final smoke acceptance failed: " + ", ".join(failed)
        )
    return AcceptanceResult(
        accepted=True,
        checks=checks,
        summary={
            "step_correct": step["correct"],
            "step_denominator": step["denominator"],
            "step_module_correct": step_module["correct"],
            "step_module_denominator": step_module["denominator"],
            "failed_prediction_count": overall[
                "failed_prediction_count"
            ],
        },
    )


def verify_final_smoke_artifacts(
    *,
    dataset: BenchmarkDataset,
    cohort: CohortManifest,
    output_dir: str | Path,
    minimum_step_module_correct: int | None = None,
) -> AcceptanceResult:
    """Rebuild the final result from persisted raw stages before accepting it."""

    root = Path(output_dir).expanduser().resolve()
    baseline = (
        _verify_frozen_smoke_baseline(
            dataset=dataset,
            cohort=cohort,
        )
        if minimum_step_module_correct is None
        else {
            "step_module_correct": minimum_step_module_correct,
            "test_override": True,
        }
    )
    minimum_step_module_correct = baseline["step_module_correct"]
    paths = {
        "prediction_manifest": root / "prediction-manifest.json",
        "unscored_predictions": root / "unscored-predictions.jsonl",
        "predict_run": root / "predict-run.json",
        "predictions": root / "predictions.jsonl",
        "per_example": root / "per_example.csv",
        "metrics": root / "metrics.json",
        "report": root / "report.md",
        "artifact_manifest": root / "artifact-manifest.json",
    }
    metrics_document = _read_json_object(
        paths["metrics"],
        label="final metrics",
    )
    if set(metrics_document) != {"run", "dataset", "metrics"}:
        raise AcceptanceError(
            "final metrics document has an invalid field set"
        )
    run_metadata = metrics_document.get("run")
    reported_metrics = metrics_document.get("metrics")
    if not isinstance(run_metadata, Mapping) or not isinstance(
        reported_metrics,
        Mapping,
    ):
        raise AcceptanceError(
            "final metrics run or metric payload is invalid"
        )
    if cohort.path is None:
        raise AcceptanceError(
            "final smoke requires a persisted cohort manifest"
        )
    scored_predictions, predict_metadata = score_persisted_predictions(
        dataset=dataset,
        cohort=cohort,
        manifest_path=paths["prediction_manifest"],
        unscored_predictions_path=paths["unscored_predictions"],
        predict_run_metadata_path=paths["predict_run"],
    )
    persisted_predictions = _read_jsonl_objects(
        paths["predictions"],
        label="final scored predictions",
    )
    recomputed_metrics = compute_metrics(
        scored_predictions,
        phase1_gold_available=dataset.phase1_gold_available,
        phase1_gold_reason=dataset.phase1_gold_reason,
    )
    expected_prediction_text = "".join(
        json.dumps(row, ensure_ascii=False, default=str) + "\n"
        for row in scored_predictions
    )
    try:
        persisted_prediction_text = paths["predictions"].read_text(
            encoding="utf-8"
        )
        persisted_report = paths["report"].read_text(encoding="utf-8")
    except OSError as error:
        raise AcceptanceError(
            "final predictions or report is missing"
        ) from error
    expected_report = render_report(
        dataset=dataset,
        predictions=scored_predictions,
        metrics=recomputed_metrics,
        run_metadata=run_metadata,
    )
    artifact_manifest = _read_json_object(
        paths["artifact_manifest"],
        label="final artifact manifest",
    )
    claimed_artifact_manifest_sha256 = artifact_manifest.get(
        "artifact_manifest_sha256"
    )
    artifact_manifest_body = dict(artifact_manifest)
    artifact_manifest_body.pop("artifact_manifest_sha256", None)
    final_file_names = (
        "predictions",
        "per_example",
        "metrics",
        "report",
    )
    upstream_names = (
        "prediction_manifest",
        "unscored_predictions",
        "predict_run",
    )
    expected_artifact_files = {
        name: {
            "path": str(paths[name]),
            "file_sha256": _file_sha256(paths[name]),
        }
        for name in final_file_names
    }
    expected_upstream_files = {
        name: {
            "path": str(paths[name]),
            "file_sha256": _file_sha256(paths[name]),
        }
        for name in upstream_names
    }

    selection = run_metadata.get("selection")
    isolation = run_metadata.get("gold_isolation")
    by_method = recomputed_metrics.get("by_method", {})
    two_stage = (
        by_method.get(FINAL_METHOD)
        if isinstance(by_method, Mapping)
        else None
    )
    by_environment = (
        two_stage.get("by_environment")
        if isinstance(two_stage, Mapping)
        else None
    )
    environment_denominators = (
        isinstance(by_environment, Mapping)
        and all(
            isinstance(by_environment.get(environment), Mapping)
            and by_environment[environment].get("trajectory_count")
            == FINAL_ENVIRONMENT_DENOMINATOR
            and by_environment[environment]
            .get("step_exact", {})
            .get("denominator")
            == FINAL_ENVIRONMENT_DENOMINATOR
            and by_environment[environment]
            .get("step_module_exact", {})
            .get("denominator")
            == FINAL_ENVIRONMENT_DENOMINATOR
            for environment in ("alfworld", "gaia", "webshop")
        )
    )
    semantic_mutations = sum(
        (
            row.get("evidence_repair", {}).get("failure_code")
            == "semantic_mutation"
        )
        for row in scored_predictions
        if isinstance(row.get("evidence_repair"), Mapping)
    )
    expected_provider_config = {
        "model": FINAL_MODEL,
        "temperature": float(FINAL_TEMPERATURE),
        "provider": FINAL_PROVIDER,
        "endpoint": FINAL_ENDPOINT,
        "timeout": float(FINAL_TIMEOUT_SECONDS),
        "max_output_tokens": FINAL_MAX_OUTPUT_TOKENS,
        "max_retries": FINAL_MAX_RETRIES,
        "retry_backoff": float(FINAL_RETRY_BACKOFF_SECONDS),
        "cohort_sha256": cohort.cohort_sha256,
        "api_key_env": "API_KEY",
    }
    upstream_match = (
        isinstance(isolation, Mapping)
        and isolation.get("prediction_manifest_path")
        == str(paths["prediction_manifest"])
        and isolation.get("unscored_predictions_path")
        == str(paths["unscored_predictions"])
        and isolation.get("predict_run_metadata_path")
        == str(paths["predict_run"])
        and isolation.get("prediction_manifest_sha256")
        == predict_metadata.get("prediction_manifest_sha256")
        and isolation.get("unscored_predictions_sha256")
        == predict_metadata.get("unscored_predictions_sha256")
        and isolation.get("predict_run_sha256")
        == predict_metadata.get("predict_run_sha256")
    )
    metadata_match = all(
        run_metadata.get(field) == predict_metadata.get(field)
        for field in (
            "provider_telemetry",
            "provider_telemetry_known_subtotal",
            "provider_telemetry_coverage",
            "provider_capabilities",
            "repair_eligible_count",
            "repair_attempt_count",
            "repair_applied_count",
            "max_logical_completions",
            "logical_completion_budget_used",
        )
    )
    artifact_checks = {
        "dataset_audit_recomputed": metrics_document.get("dataset")
        == dataset.audit_dict(),
        "cohort_manifest_path": (
            isinstance(selection, Mapping)
            and selection.get("cohort_manifest_path")
            == str(cohort.path.resolve())
        ),
        "cohort_exact_selection": (
            isinstance(selection, Mapping)
            and selection.get("trajectory_ids") == []
            and selection.get("limit") is None
        ),
        "scored_prediction_count": len(scored_predictions)
        == FINAL_DENOMINATOR,
        "predictions_rebuilt_from_raw": persisted_predictions
        == scored_predictions,
        "predictions_byte_exact": persisted_prediction_text
        == expected_prediction_text,
        "metrics_recomputed": dict(reported_metrics)
        == recomputed_metrics,
        "report_recomputed": persisted_report == expected_report,
        "artifact_manifest_self_hash": (
            isinstance(claimed_artifact_manifest_sha256, str)
            and claimed_artifact_manifest_sha256
            == stable_sha256(artifact_manifest_body)
        ),
        "artifact_manifest_bound": (
            artifact_manifest.get("schema_version")
            == ARTIFACT_MANIFEST_SCHEMA_VERSION
            and artifact_manifest.get("dataset_manifest_sha256")
            == dataset.dataset_sha256
            and artifact_manifest.get("cohort_sha256")
            == cohort.cohort_sha256
            and artifact_manifest.get("production_pipeline_version")
            == PRODUCTION_TWO_STAGE_PIPELINE_VERSION
            and artifact_manifest.get("predict_run_sha256")
            == predict_metadata.get("predict_run_sha256")
            and artifact_manifest.get("files")
            == expected_artifact_files
            and artifact_manifest.get("upstream")
            == expected_upstream_files
        ),
        "environment_denominators": environment_denominators,
        "predict_metadata_bound": metadata_match,
        "upstream_hash_chain_bound": upstream_match,
        "provider_config_exact": predict_metadata.get("provider_config")
        == expected_provider_config,
        "predict_retry_failures_disabled": predict_metadata.get(
            "retry_failures"
        )
        is False,
        "predict_budget_exact": (
            predict_metadata.get("max_logical_completions")
            == FINAL_MAX_LOGICAL_COMPLETIONS
            and _nonnegative_int(
                predict_metadata.get("logical_completion_budget_used")
            )
            and predict_metadata["logical_completion_budget_used"]
            <= FINAL_MAX_LOGICAL_COMPLETIONS
        ),
        "repair_semantics_frozen": semantic_mutations == 0,
    }
    failed_artifact_checks = [
        name
        for name, passed in artifact_checks.items()
        if not passed
    ]
    if failed_artifact_checks:
        raise AcceptanceError(
            "final smoke artifact verification failed: "
            + ", ".join(failed_artifact_checks)
        )
    aggregate = verify_final_smoke(
        metrics=recomputed_metrics,
        run_metadata=run_metadata,
        expected_dataset_sha256=dataset.dataset_sha256,
        expected_cohort_sha256=cohort.cohort_sha256,
        minimum_step_module_correct=minimum_step_module_correct,
    )
    hashes = {
        name: _file_sha256(path)
        for name, path in paths.items()
    }
    return AcceptanceResult(
        accepted=True,
        checks={**artifact_checks, **aggregate.checks},
        summary={
            **aggregate.summary,
            "schema_version": FINAL_ACCEPTANCE_SCHEMA_VERSION,
            "dataset_manifest_sha256": dataset.dataset_sha256,
            "cohort_sha256": cohort.cohort_sha256,
            "minimum_step_module_correct": minimum_step_module_correct,
            "frozen_baseline": baseline,
            "baseline_delta": {
                "step_correct": (
                    aggregate.summary["step_correct"]
                    - baseline.get(
                        "step_correct",
                        aggregate.summary["step_correct"],
                    )
                ),
                "step_module_correct": (
                    aggregate.summary["step_module_correct"]
                    - baseline["step_module_correct"]
                ),
                "failed_prediction_count": (
                    aggregate.summary["failed_prediction_count"]
                    - baseline.get(
                        "failed_prediction_count",
                        aggregate.summary["failed_prediction_count"],
                    )
                ),
            },
            "artifact_sha256": hashes,
            "predict_run_sha256": predict_metadata.get(
                "predict_run_sha256"
            ),
        },
    )


__all__ = [
    "AcceptanceError",
    "AcceptanceResult",
    "BASELINE_STEP_MODULE_CORRECT",
    "FINAL_ACCEPTANCE_SCHEMA_VERSION",
    "FROZEN_BASELINE_METRICS_SHA256",
    "verify_final_smoke",
    "verify_final_smoke_artifacts",
]

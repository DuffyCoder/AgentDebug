"""CLI for the gold-isolated E9 batched causal judge experiment.

The command boundary is intentional:

* ``plan`` reads only the gold-free prediction manifest.
* ``predict`` cannot accept a dataset, cohort, or scored artifact.
* ``score`` is the first command that loads released benchmark labels.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from agentdebug.diagnostics.batched_causal_judge import (
    BATCHED_ARBITER_PROMPT_PROTOCOL_VERSION,
    BATCHED_CAUSAL_PIPELINE_VERSION,
    BATCHED_SCOUT_PROMPT_PROTOCOL_VERSION,
)
from agentdebug.diagnostics.judge_view import JUDGE_VIEW_VERSION
from agentdebug.diagnostics.providers import (
    GeminiGenerateContentJudge,
    JudgeTransportError,
    OpenAICompatibleJudge,
    resolve_judge_endpoint,
)

from .batched_causal_preregistration import (
    BatchedCausalPreregistrationError,
    frozen_batched_causal_promotion_gate,
    verify_batched_causal_preregistration,
    verify_batched_causal_promotion,
    write_batched_causal_preregistration,
)
from .batched_causal_workflow import (
    E9_EXPERIMENT,
    BatchedCausalWorkflowError,
    predict_batched_causal_cases,
    score_batched_causal_predictions,
    write_batched_causal_batch_plan,
)
from .cohort import load_cohort_manifest
from .dataset import load_agent_error_bench
from .fresh_semantic_workflow import FreshSemanticWorkflowError
from .prediction_manifest import (
    PredictionManifestError,
    load_prediction_manifest,
)
from .reporting import write_outputs
from .runner import TRANSPORT_POLICY_VERSION, BenchmarkRunConfig
from .stage_cache import StageCacheError


def _provider_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--judge-provider",
        choices=("openai-compatible", "gemini-generate-content"),
        required=True,
    )
    parser.add_argument("--judge-base-url", required=True)
    parser.add_argument("--judge-api-key-env", required=True)
    parser.add_argument("--judge-model", required=True)
    parser.add_argument("--judge-temperature", type=float, required=True)
    parser.add_argument("--judge-timeout", type=float, required=True)
    parser.add_argument("--judge-max-output-tokens", type=int, required=True)
    parser.add_argument("--judge-max-retries", type=int, required=True)
    parser.add_argument("--judge-retry-backoff", type=float, required=True)


def _selection_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--trajectory-id",
        action="append",
        default=[],
        help=(
            "Select a manifest trajectory; repeat as needed. The frozen "
            "selection follows manifest order. Omit to select all cases."
        ),
    )


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m agentdebug.benchmark.batched_causal_cli",
        description=(
            "Plan, preregister, predict, and independently score the "
            "gold-isolated E9 batched causal experiment."
        ),
    )
    commands = parser.add_subparsers(dest="command", required=True)

    plan = commands.add_parser(
        "plan",
        help=(
            "Freeze deterministic batches from a gold-free prediction "
            "manifest without calling a provider."
        ),
    )
    plan.add_argument("--prediction-manifest", required=True)
    plan.add_argument("--output", required=True)
    plan.add_argument(
        "--required-prefix-plan",
        help=(
            "Require every batch in this earlier plan to be an exact prefix "
            "of the new plan, enabling dry-run cache reuse."
        ),
    )
    _selection_arguments(plan)

    preregister = commands.add_parser(
        "preregister",
        help=(
            "Freeze E9 code, prompts, inputs, batch plan, gate, paths, and "
            "logical-completion budget."
        ),
    )
    preregister.add_argument("--experiment-name", required=True)
    preregister.add_argument("--dataset", required=True)
    preregister.add_argument("--cohort-manifest", required=True)
    preregister.add_argument("--prediction-manifest", required=True)
    preregister.add_argument("--batch-plan", required=True)
    preregister.add_argument("--run-output-dir", required=True)
    preregister.add_argument("--cache-dir", required=True)
    preregister.add_argument("--output", required=True)
    preregister.add_argument("--selection-rule", required=True)
    preregister.add_argument("--hypothesis", required=True)
    preregister.add_argument(
        "--gate-profile",
        choices=("dry3", "full30", "smoke30"),
        required=True,
    )
    preregister.add_argument(
        "--cumulative-logical-completions-before",
        type=int,
        required=True,
    )
    preregister.add_argument(
        "--maximum-new-logical-completions",
        type=int,
        required=True,
    )
    preregister.add_argument(
        "--authorized-cumulative-ceiling",
        type=int,
        required=True,
        help=(
            "Explicit user-authorized cumulative ceiling frozen into the "
            "v13 claim. Current authorization is 380; smoke requires a "
            "future explicit authorization of at least 384."
        ),
    )
    _selection_arguments(preregister)
    _provider_arguments(preregister)

    predict = commands.add_parser(
        "predict",
        help=(
            "Run E9 from gold-free artifacts only. This command deliberately "
            "has no dataset, cohort, label, or scored-artifact argument."
        ),
    )
    predict.add_argument("--prediction-manifest", required=True)
    predict.add_argument("--batch-plan", required=True)
    predict.add_argument("--cache-dir", required=True)
    predict.add_argument("--output", required=True)
    predict.add_argument("--run-metadata", required=True)
    predict.add_argument("--preregistration", required=True)
    predict.add_argument(
        "--max-logical-completions",
        type=int,
        required=True,
    )
    _selection_arguments(predict)
    _provider_arguments(predict)

    score = commands.add_parser(
        "score",
        help=(
            "Validate the closed raw E9 chain, then load released gold and "
            "write standard benchmark artifacts."
        ),
    )
    score.add_argument("--dataset", required=True)
    score.add_argument("--cohort-manifest", required=True)
    score.add_argument("--prediction-manifest", required=True)
    score.add_argument("--batch-plan", required=True)
    score.add_argument("--unscored-predictions", required=True)
    score.add_argument("--predict-run", required=True)
    score.add_argument("--output-dir", required=True)

    gate = commands.add_parser(
        "verify-gate",
        help="Apply the write-once E9 promotion gate to scored artifacts.",
    )
    gate.add_argument("--preregistration", required=True)
    gate.add_argument("--predictions", required=True)
    gate.add_argument("--metrics", required=True)
    gate.add_argument("--predict-run", required=True)
    gate.add_argument("--output", required=True)
    return parser


def _config_from_args(
    args: argparse.Namespace,
    *,
    endpoint: str,
    cohort_sha256: str,
) -> BenchmarkRunConfig:
    return BenchmarkRunConfig(
        model=args.judge_model,
        temperature=args.judge_temperature,
        provider=args.judge_provider,
        endpoint=endpoint,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
        cohort_sha256=cohort_sha256,
        api_key_env=args.judge_api_key_env,
    )


def _ordered_selection(
    *,
    prediction_manifest_path: str,
    requested: list[str],
) -> tuple[dict[str, Any], list[str]]:
    manifest, cases = load_prediction_manifest(prediction_manifest_path)
    if not requested:
        return manifest, [case.trajectory_id for case in cases]
    selected_set = set(requested)
    selected = [
        case.trajectory_id
        for case in cases
        if case.trajectory_id in selected_set
    ]
    if (
        len(selected_set) != len(requested)
        or len(selected) != len(requested)
    ):
        raise ValueError(
            "trajectory IDs are duplicated or absent from the prediction "
            "manifest"
        )
    return manifest, selected


def _required(
    value: Mapping[str, Any],
    key: str,
    *,
    location: str,
) -> Any:
    if key not in value:
        raise BatchedCausalWorkflowError(
            f"{location} omits required field {key!r}"
        )
    return value[key]


def _plan(args: argparse.Namespace) -> int:
    _, selected = _ordered_selection(
        prediction_manifest_path=args.prediction_manifest,
        requested=args.trajectory_id,
    )
    document = write_batched_causal_batch_plan(
        prediction_manifest_path=args.prediction_manifest,
        output_path=args.output,
        selected_trajectory_ids=selected,
        required_prefix_plan_path=args.required_prefix_plan,
    )
    batches = _required(document, "batches", location="batch plan")
    if not isinstance(batches, list):
        raise BatchedCausalWorkflowError(
            "batch plan batches must be a list"
        )
    print(
        json.dumps(
            {
                "output": str(Path(args.output).expanduser().resolve()),
                "batch_plan_sha256": _required(
                    document,
                    "batch_plan_sha256",
                    location="batch plan",
                ),
                "selected_count": len(selected),
                "batch_count": len(batches),
                "required_prefix_plan": (
                    str(
                        Path(args.required_prefix_plan)
                        .expanduser()
                        .resolve()
                    )
                    if args.required_prefix_plan
                    else None
                ),
                "external_calls": 0,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _preregister(args: argparse.Namespace) -> int:
    manifest, selected = _ordered_selection(
        prediction_manifest_path=args.prediction_manifest,
        requested=args.trajectory_id,
    )
    endpoint = resolve_judge_endpoint(
        provider=args.judge_provider,
        base_url=args.judge_base_url,
        model=args.judge_model,
    )
    config = _config_from_args(
        args,
        endpoint=endpoint,
        cohort_sha256=manifest["cohort_sha256"],
    )
    document = write_batched_causal_preregistration(
        experiment_name=args.experiment_name,
        evaluation_profile=args.gate_profile,
        dataset_path=args.dataset,
        cohort_manifest_path=args.cohort_manifest,
        prediction_manifest_path=args.prediction_manifest,
        batch_plan_path=args.batch_plan,
        output_path=args.output,
        run_output_dir=args.run_output_dir,
        cache_dir=args.cache_dir,
        config=config,
        selected_trajectory_ids=selected,
        selection_rule=args.selection_rule,
        hypothesis=args.hypothesis,
        promotion_gate=frozen_batched_causal_promotion_gate(
            args.gate_profile,
            selected_trajectory_ids=selected,
        ),
        cumulative_logical_completions_before=(
            args.cumulative_logical_completions_before
        ),
        maximum_new_logical_completions=(
            args.maximum_new_logical_completions
        ),
        authorized_cumulative_ceiling=args.authorized_cumulative_ceiling,
    )
    budget = _required(
        document,
        "logical_completion_budget",
        location="preregistration",
    )
    selection = _required(
        document,
        "selection",
        location="preregistration",
    )
    batch_plan = _required(
        document,
        "batch_plan",
        location="preregistration",
    )
    print(
        json.dumps(
            {
                "output": str(Path(args.output).expanduser().resolve()),
                "preregistration_sha256": _required(
                    document,
                    "preregistration_sha256",
                    location="preregistration",
                ),
                "code_bundle_sha256": _required(
                    document,
                    "code_bundle_sha256",
                    location="preregistration",
                ),
                "batch_plan_sha256": _required(
                    batch_plan,
                    "content_sha256",
                    location="preregistration.batch_plan",
                ),
                "selected_count": _required(
                    selection,
                    "count",
                    location="preregistration.selection",
                ),
                "hard_cumulative_stop": _required(
                    budget,
                    "hard_cumulative_stop",
                    location="preregistration.logical_completion_budget",
                ),
                "authorized_cumulative_ceiling": _required(
                    budget,
                    "authorized_cumulative_ceiling",
                    location="preregistration.logical_completion_budget",
                ),
                "external_calls": 0,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _judge_from_args(args: argparse.Namespace) -> Any:
    judge_class = (
        GeminiGenerateContentJudge
        if args.judge_provider == "gemini-generate-content"
        else OpenAICompatibleJudge
    )
    return judge_class(
        base_url=args.judge_base_url,
        api_key_env=args.judge_api_key_env,
        model=args.judge_model,
        temperature=args.judge_temperature,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
    )


def _predict(args: argparse.Namespace) -> int:
    manifest, selected = _ordered_selection(
        prediction_manifest_path=args.prediction_manifest,
        requested=args.trajectory_id,
    )
    judge = _judge_from_args(args)
    config = _config_from_args(
        args,
        endpoint=judge.endpoint,
        cohort_sha256=manifest["cohort_sha256"],
    )
    preregistration = verify_batched_causal_preregistration(
        preregistration_path=args.preregistration,
        prediction_manifest_path=args.prediction_manifest,
        batch_plan_path=args.batch_plan,
        run_output_dir=Path(args.output).expanduser().resolve().parent,
        cache_dir=args.cache_dir,
        unscored_output_path=args.output,
        predict_run_metadata_path=args.run_metadata,
        config=config,
        selected_trajectory_ids=selected,
        maximum_new_logical_completions=args.max_logical_completions,
    )
    progress_state = {"batch": 0, "row": 0}

    def batch_progress(event: Mapping[str, Any]) -> None:
        progress_state["batch"] += 1
        batch_id = event.get("batch_id", progress_state["batch"])
        status = event.get("status", "complete")
        print(
            f"[E9 batch {progress_state['batch']}] {batch_id} {status}",
            flush=True,
        )

    def row_progress(row: Mapping[str, Any]) -> None:
        progress_state["row"] += 1
        print(
            f"[E9 row {progress_state['row']}] "
            f"{row.get('trajectory_id', '<unknown>')} "
            f"{row.get('status', '<unknown>')}",
            flush=True,
        )

    rows, metadata = predict_batched_causal_cases(
        prediction_manifest_path=args.prediction_manifest,
        batch_plan_path=args.batch_plan,
        preregistration_sha256=preregistration[
            "preregistration_sha256"
        ],
        judge=judge,
        config=config,
        cache_dir=args.cache_dir,
        unscored_output_path=args.output,
        predict_run_metadata_path=args.run_metadata,
        max_logical_completions=args.max_logical_completions,
        logical_completion_ledger_path=preregistration["execution"][
            "logical_completion_ledger_path"
        ],
        cumulative_logical_completions_before=preregistration[
            "logical_completion_budget"
        ]["cumulative_before"],
        authorized_cumulative_ceiling=preregistration[
            "logical_completion_budget"
        ]["authorized_cumulative_ceiling"],
        on_batch=batch_progress,
        on_result=row_progress,
    )
    print(
        json.dumps(
            {
                "prediction_count": len(rows),
                "batch_count": _required(
                    metadata,
                    "batch_count",
                    location="predict run",
                ),
                "unscored_predictions_sha256": _required(
                    metadata,
                    "unscored_predictions_sha256",
                    location="predict run",
                ),
                "predict_run_sha256": _required(
                    metadata,
                    "predict_run_sha256",
                    location="predict run",
                ),
                "logical_completion_budget_used": _required(
                    metadata,
                    "logical_completion_budget_used",
                    location="predict run",
                ),
                "provider_telemetry": _required(
                    metadata,
                    "provider_telemetry",
                    location="predict run",
                ),
                "preregistration_sha256": preregistration[
                    "preregistration_sha256"
                ],
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _score(args: argparse.Namespace) -> int:
    started = datetime.now(timezone.utc)
    dataset = load_agent_error_bench(args.dataset)
    cohort = load_cohort_manifest(
        args.cohort_manifest,
        dataset=dataset,
    )
    predictions, metrics, predict_run = score_batched_causal_predictions(
        dataset=dataset,
        cohort=cohort,
        prediction_manifest_path=args.prediction_manifest,
        batch_plan_path=args.batch_plan,
        unscored_predictions_path=args.unscored_predictions,
        predict_run_metadata_path=args.predict_run,
    )
    finished = datetime.now(timezone.utc)
    config = _required(
        predict_run,
        "provider_config",
        location="predict run",
    )
    if not isinstance(config, Mapping):
        raise BatchedCausalWorkflowError(
            "predict run provider_config must be an object"
        )
    selected_ids = _required(
        predict_run,
        "selected_trajectory_ids",
        location="predict run",
    )
    batch_plan_sha256 = _required(
        predict_run,
        "batch_plan_sha256",
        location="predict run",
    )
    run_metadata = {
        "started_at": started.isoformat(),
        "finished_at": finished.isoformat(),
        "duration_seconds": (finished - started).total_seconds(),
        "experiment": E9_EXPERIMENT,
        "model": _required(config, "model", location="provider_config"),
        "temperature": _required(
            config,
            "temperature",
            location="provider_config",
        ),
        "provider": _required(
            config,
            "provider",
            location="provider_config",
        ),
        "endpoint": _required(
            config,
            "endpoint",
            location="provider_config",
        ),
        "timeout": _required(
            config,
            "timeout",
            location="provider_config",
        ),
        "max_output_tokens": _required(
            config,
            "max_output_tokens",
            location="provider_config",
        ),
        "max_retries": _required(
            config,
            "max_retries",
            location="provider_config",
        ),
        "retry_backoff": _required(
            config,
            "retry_backoff",
            location="provider_config",
        ),
        "workers": 1,
        "execution_order": "frozen-batch-plan",
        "methods": ["two_stage"],
        "prompt_versions": {
            "two_stage": {
                "scout": BATCHED_SCOUT_PROMPT_PROTOCOL_VERSION,
                "arbiter": BATCHED_ARBITER_PROMPT_PROTOCOL_VERSION,
            },
        },
        "judge_view_version": JUDGE_VIEW_VERSION,
        "diagnostic_pipeline_version": BATCHED_CAUSAL_PIPELINE_VERSION,
        "pipeline_versions": {
            "two_stage": BATCHED_CAUSAL_PIPELINE_VERSION,
        },
        "production_two_stage_pipeline_version": (
            BATCHED_CAUSAL_PIPELINE_VERSION
        ),
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "evidence_validation_version": _required(
            predict_run,
            "evidence_validation_version",
            location="predict run",
        ),
        "provider_telemetry": _required(
            predict_run,
            "provider_telemetry",
            location="predict run",
        ),
        "provider_telemetry_coverage": _required(
            predict_run,
            "provider_telemetry_coverage",
            location="predict run",
        ),
        "provider_capabilities": _required(
            predict_run,
            "provider_capabilities",
            location="predict run",
        ),
        "semantic_mutation_count": _required(
            predict_run,
            "semantic_mutation_count",
            location="predict run",
        ),
        "batch_count": _required(
            predict_run,
            "batch_count",
            location="predict run",
        ),
        "batch_plan": {
            "path": str(Path(args.batch_plan).expanduser().resolve()),
            "file_sha256": _required(
                predict_run,
                "batch_plan_file_sha256",
                location="predict run",
            ),
            "batch_plan_sha256": batch_plan_sha256,
            "batch_count": _required(
                predict_run,
                "batch_count",
                location="predict run",
            ),
            "maximum_batch_size": _required(
                predict_run,
                "maximum_batch_size",
                location="predict run",
            ),
            "maximum_request_chars": _required(
                predict_run,
                "maximum_request_chars",
                location="predict run",
            ),
            "arbiter_candidate_reserve_chars": _required(
                predict_run,
                "arbiter_candidate_reserve_chars",
                location="predict run",
            ),
        },
        "released_label_count": len(dataset.labels),
        "available_trajectory_count": len(dataset.examples),
        "judge_input_count": len(predictions),
        "metric_cohort_count": len(predictions),
        "prediction_count": len(predictions),
        "selection": {
            "trajectory_ids": selected_ids,
            "cohort_manifest_path": str(cohort.path),
            "cohort_name": cohort.cohort_name,
            "cohort_sha256": cohort.cohort_sha256,
            "dataset_manifest_sha256": dataset.dataset_sha256,
            "cohort": cohort.cohort_name,
        },
        "cache_dir": _required(
            predict_run,
            "cache_dir",
            location="predict run",
        ),
        "retry_failures": _required(
            predict_run,
            "retry_failures",
            location="predict run",
        ),
        "resume": False,
        "max_logical_completions": _required(
            predict_run,
            "max_logical_completions",
            location="predict run",
        ),
        "logical_completion_budget_used": _required(
            predict_run,
            "logical_completion_budget_used",
            location="predict run",
        ),
        "logical_completion_ledger": {
            "path": _required(
                predict_run,
                "logical_completion_ledger_path",
                location="predict run",
            ),
            "file_sha256": _required(
                predict_run,
                "logical_completion_ledger_file_sha256",
                location="predict run",
            ),
            "content_sha256": _required(
                predict_run,
                "logical_completion_ledger_sha256",
                location="predict run",
            ),
        },
        "preregistration": {
            "sha256": _required(
                predict_run,
                "preregistration_sha256",
                location="predict run",
            ),
        },
        "gold_isolation": {
            "enabled": True,
            "prediction_input_type": (
                "hash_locked_gold_free_complete_judge_views"
            ),
            "batch_plan_is_gold_free": True,
            "batch_plan_path": str(
                Path(args.batch_plan).expanduser().resolve()
            ),
            "batch_plan_sha256": batch_plan_sha256,
            "batch_plan_file_sha256": _required(
                predict_run,
                "batch_plan_file_sha256",
                location="predict run",
            ),
            "raw_first_stage_cache": True,
            "provider_process_isolated_from_dataset": True,
            "unscored_persisted_before_gold_scoring": True,
            "prediction_manifest_path": str(
                Path(args.prediction_manifest).expanduser().resolve()
            ),
            "prediction_manifest_sha256": _required(
                predict_run,
                "prediction_manifest_sha256",
                location="predict run",
            ),
            "unscored_predictions_path": str(
                Path(args.unscored_predictions).expanduser().resolve()
            ),
            "unscored_predictions_sha256": _required(
                predict_run,
                "unscored_predictions_sha256",
                location="predict run",
            ),
            "predict_run_metadata_path": str(
                Path(args.predict_run).expanduser().resolve()
            ),
            "predict_run_sha256": _required(
                predict_run,
                "predict_run_sha256",
                location="predict run",
            ),
        },
    }
    paths = write_outputs(
        output_dir=args.output_dir,
        dataset=dataset,
        predictions=predictions,
        metrics=metrics,
        run_metadata=run_metadata,
    )
    print(json.dumps(paths, ensure_ascii=False, indent=2))
    return 0


def _verify_gate(args: argparse.Namespace) -> int:
    document = verify_batched_causal_promotion(
        preregistration_path=args.preregistration,
        predictions_path=args.predictions,
        metrics_path=args.metrics,
        predict_run_path=args.predict_run,
        output_path=args.output,
    )
    print(
        json.dumps(
            {
                "accepted": _required(
                    document,
                    "accepted",
                    location="promotion",
                ),
                "output": str(Path(args.output).expanduser().resolve()),
                "promotion_sha256": _required(
                    document,
                    "promotion_sha256",
                    location="promotion",
                ),
                "summary": _required(
                    document,
                    "summary",
                    location="promotion",
                ),
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.command == "plan":
            return _plan(args)
        if args.command == "preregister":
            return _preregister(args)
        if args.command == "predict":
            return _predict(args)
        if args.command == "score":
            return _score(args)
        if args.command == "verify-gate":
            return _verify_gate(args)
        raise ValueError("unsupported E9 command")
    except (
        BatchedCausalWorkflowError,
        BatchedCausalPreregistrationError,
        FreshSemanticWorkflowError,
        JudgeTransportError,
        PredictionManifestError,
        StageCacheError,
        KeyError,
        OSError,
        TypeError,
        ValueError,
    ) as error:
        print(f"agentdebug-e9: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

"""Gold-isolated E9 semantic-Scout and causal-Arbiter workflow.

Prediction consumes only a hash-locked :class:`PredictionManifest` and a
size-aware, frozen :class:`BatchPlan`.  Scout candidate bundles are advisory
LLM input: the Arbiter is always called, even when Scout parsing fails, and
every final semantic field is reconstructed solely from the Arbiter's raw
response.  Workflow code never ranks, selects, or repairs Scout candidates.
"""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from agentdebug.diagnostics.batched_causal_judge import (
    BATCHED_ARBITER_PROMPT_PROTOCOL_VERSION,
    BATCHED_ARBITER_STAGE,
    BATCHED_CAUSAL_PIPELINE_VERSION,
    BATCHED_SCOUT_PROMPT_PROTOCOL_VERSION,
    BATCHED_SCOUT_STAGE,
    BATCH_SIZE,
    MAX_TRANSPORT_ENCODED_SCOUT_CASE_CHARS,
    BatchedAdjudication,
    BatchedCase,
    batched_arbiter_messages,
    batched_scout_messages,
    build_batched_case,
    parse_batched_arbiter_isolated,
    parse_batched_scout_isolated,
)
from agentdebug.diagnostics.judge_view import JUDGE_VIEW_VERSION
from agentdebug.diagnostics.parsing import JudgeOutputError

from .cohort import CohortManifest
from .fresh_semantic_workflow import (
    DurableLogicalCompletionBudget,
    load_fresh_semantic_completion_ledger,
)
from .metrics import compute_metrics
from .models import BenchmarkDataset
from .prediction_manifest import (
    PredictionCase,
    load_prediction_manifest,
    stable_sha256,
)
from .runner import (
    TRANSPORT_POLICY_VERSION,
    BenchmarkRunConfig,
    _apply_root,
    _base_record,
)
from .stage_cache import (
    build_stage_request,
    run_cached_stage,
    stable_sha256 as stage_sha256,
    sum_stage_telemetry,
)


E9_EXPERIMENT = (
    "e9_v13_atomic_taxonomy_pair_scout_causal_arbiter_judge"
)
E9_METHOD = "two_stage"
E9_SEMANTIC_CLASSIFIER = "raw_independent_batch_arbiter_output"
E9_BATCH_PLAN_SCHEMA_VERSION = "agentdebug.benchmark.e9-batch-plan.v1"
E9_PREDICTION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-unscored-prediction.v11"
)
E9_PREDICT_RUN_SCHEMA_VERSION = "agentdebug.benchmark.e9-predict-run.v1"
E9_BATCH_PLANNER_VERSION = (
    "e9-v13-gold-free-manifest-order-greedy-char-cap-v13"
)
E9_EVIDENCE_VALIDATION_VERSION = (
    "e9-raw-arbiter-same-step-owner-exact-substring-no-length-cap-v13"
)
# V13 intentionally gives the atomic-pair semantic Scout a fresh identity.
# Neither its request nor its cache key is compatible with the split-field
# v12 Scout or any chronology-only predecessor.
E9_SCOUT_CACHE_COMPATIBILITY_VERSION = (
    "e9-v13-fresh-atomic-taxonomy-pair-scout-v13"
)
MAXIMUM_REQUEST_CHARS = 800_000
ARBITER_CANDIDATE_RESERVE_CHARS = 40_960
MAX_BATCH_SIZE = BATCH_SIZE
if (
    MAX_BATCH_SIZE * MAX_TRANSPORT_ENCODED_SCOUT_CASE_CHARS
    > ARBITER_CANDIDATE_RESERVE_CHARS
):
    raise RuntimeError("E9 Scout bundle case cap exceeds the arbiter reserve")
_STAGES = (BATCHED_SCOUT_STAGE, BATCHED_ARBITER_STAGE)
_OUTCOME_FIELDS = {
    "status",
    "failure_stage",
    "failure_code",
    "failure_message",
}
_FORBIDDEN_KEYS = {
    "all_correct",
    "confidence",
    "critical_failure_module",
    "critical_failure_step",
    "critical_failure_type",
    "deterministic_finding",
    "gold_error_type",
    "gold_event_id",
    "gold_module",
    "gold_normalization_notes",
    "gold_raw_error_type",
    "gold_raw_module",
    "gold_reasoning",
    "gold_step",
    "rank",
    "score",
    "scores",
    "severity",
    "step_annotations",
    "step_exact",
    "step_module_exact",
    "vote",
    "votes",
    "weight",
    "weights",
}


class BatchedCausalWorkflowError(ValueError):
    """An E9 plan or prediction artifact is unsafe or inconsistent."""


@dataclass(frozen=True)
class BatchSpec:
    """One immutable, anonymous provider batch."""

    batch_id: str
    case_keys: tuple[str, ...]
    trajectory_ids: tuple[str, ...]
    ordered_case_input_sha256s: tuple[str, ...]
    scout_request_chars: int
    arbiter_base_request_chars: int
    maximum_estimated_request_chars: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "batch_id": self.batch_id,
            "case_keys": list(self.case_keys),
            "trajectory_ids": list(self.trajectory_ids),
            "ordered_case_input_sha256s": list(
                self.ordered_case_input_sha256s
            ),
            "scout_request_chars": self.scout_request_chars,
            "arbiter_base_request_chars": self.arbiter_base_request_chars,
            "maximum_estimated_request_chars": (
                self.maximum_estimated_request_chars
            ),
        }


@dataclass(frozen=True)
class BatchPlan:
    """A hash-locked, gold-free partition of manifest-order cases."""

    prediction_manifest_sha256: str
    selected_trajectory_ids: tuple[str, ...]
    execution_order: str
    required_prefix_batch_plan_sha256: str | None
    batches: tuple[BatchSpec, ...]
    maximum_request_chars: int = MAXIMUM_REQUEST_CHARS
    arbiter_candidate_reserve_chars: int = (
        ARBITER_CANDIDATE_RESERVE_CHARS
    )
    maximum_batch_size: int = MAX_BATCH_SIZE
    planner_version: str = E9_BATCH_PLANNER_VERSION

    def to_dict(self) -> dict[str, Any]:
        body: dict[str, Any] = {
            "schema_version": E9_BATCH_PLAN_SCHEMA_VERSION,
            "pipeline_version": BATCHED_CAUSAL_PIPELINE_VERSION,
            "planner_version": self.planner_version,
            "maximum_request_chars": self.maximum_request_chars,
            "arbiter_candidate_reserve_chars": (
                self.arbiter_candidate_reserve_chars
            ),
            "maximum_batch_size": self.maximum_batch_size,
            "prediction_manifest_sha256": (
                self.prediction_manifest_sha256
            ),
            "selected_trajectory_ids": list(
                self.selected_trajectory_ids
            ),
            "execution_order": self.execution_order,
            "required_prefix_batch_plan_sha256": (
                self.required_prefix_batch_plan_sha256
            ),
            "batch_count": len(self.batches),
            "batches": [batch.to_dict() for batch in self.batches],
        }
        body["batch_plan_sha256"] = stable_sha256(body)
        return body

    @property
    def batch_plan_sha256(self) -> str:
        return self.to_dict()["batch_plan_sha256"]


def _assert_gold_free(value: Any, *, location: str) -> None:
    if isinstance(value, Mapping):
        forbidden = sorted(
            str(key)
            for key in value
            if str(key).casefold() in _FORBIDDEN_KEYS
            or str(key).casefold().startswith("gold_")
        )
        if forbidden:
            raise BatchedCausalWorkflowError(
                f"{location} contains forbidden evaluator fields: "
                + ", ".join(forbidden)
            )
        for key, item in value.items():
            _assert_gold_free(item, location=f"{location}.{key}")
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _assert_gold_free(item, location=f"{location}[{index}]")


def _assert_sha256(value: Any, *, field: str) -> str:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise BatchedCausalWorkflowError(
            f"E9 {field} must be one lowercase SHA-256 digest"
        )
    return value


def _file_sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _atomic_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(value, encoding="utf-8")
    temporary.replace(path)


def _atomic_json(path: Path, value: Any) -> None:
    _atomic_text(
        path,
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
    )


def _atomic_jsonl(
    path: Path,
    values: Sequence[Mapping[str, Any]],
) -> None:
    _atomic_text(
        path,
        "".join(
            json.dumps(value, ensure_ascii=False, sort_keys=True) + "\n"
            for value in values
        ),
    )


def _read_object(path: str | Path, *, location: str) -> dict[str, Any]:
    try:
        value = json.loads(
            Path(path).expanduser().resolve().read_text(encoding="utf-8")
        )
    except (OSError, json.JSONDecodeError) as error:
        raise BatchedCausalWorkflowError(
            f"{location} is missing or invalid JSON"
        ) from error
    if not isinstance(value, dict):
        raise BatchedCausalWorkflowError(
            f"{location} must be one JSON object"
        )
    return value


def _read_jsonl(path: str | Path) -> list[dict[str, Any]]:
    resolved = Path(path).expanduser().resolve()
    try:
        lines = resolved.read_text(encoding="utf-8").splitlines()
    except OSError as error:
        raise BatchedCausalWorkflowError(
            "E9 unscored predictions are missing"
        ) from error
    if not lines or any(not line.strip() for line in lines):
        raise BatchedCausalWorkflowError(
            "E9 unscored predictions must be non-empty strict JSONL"
        )
    rows: list[dict[str, Any]] = []
    for line in lines:
        try:
            value = json.loads(line)
        except json.JSONDecodeError as error:
            raise BatchedCausalWorkflowError(
                "E9 unscored predictions contain invalid JSON"
            ) from error
        if not isinstance(value, dict):
            raise BatchedCausalWorkflowError(
                "E9 unscored prediction must be an object"
            )
        rows.append(value)
    return rows


def _document_with_hash(
    body: Mapping[str, Any],
    *,
    hash_field: str,
) -> dict[str, Any]:
    result = dict(body)
    result[hash_field] = stable_sha256(result)
    return result


def _message_chars(messages: Sequence[Mapping[str, str]]) -> int:
    return len(
        json.dumps(
            list(messages),
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
    )


def _cases_for_spec(
    spec: BatchSpec,
    *,
    by_id: Mapping[str, PredictionCase],
) -> list[BatchedCase]:
    return [
        build_batched_case(
            case_key=case_key,
            view=by_id[trajectory_id].judge_view,
        )
        for case_key, trajectory_id in zip(
            spec.case_keys,
            spec.trajectory_ids,
            strict=True,
        )
    ]


def _batch_identity(
    cases: Sequence[PredictionCase],
) -> str:
    return "B" + stable_sha256(
        {
            "pipeline_version": BATCHED_CAUSAL_PIPELINE_VERSION,
            "scout_prompt_protocol_version": (
                BATCHED_SCOUT_PROMPT_PROTOCOL_VERSION
            ),
            "arbiter_prompt_protocol_version": (
                BATCHED_ARBITER_PROMPT_PROTOCOL_VERSION
            ),
            "scout_cache_compatibility_version": (
                E9_SCOUT_CACHE_COMPATIBILITY_VERSION
            ),
            "ordered_case_input_sha256s": [
                case.case_input_sha256 for case in cases
            ],
        }
    )[:20]


def _make_batch_spec(cases: Sequence[PredictionCase]) -> BatchSpec:
    if not cases or len(cases) > MAX_BATCH_SIZE:
        raise BatchedCausalWorkflowError(
            "E9 batches must contain one to three cases"
        )
    keys = tuple(f"C{index:02d}" for index in range(1, len(cases) + 1))
    batched = [
        build_batched_case(case_key=key, view=case.judge_view)
        for key, case in zip(keys, cases, strict=True)
    ]
    scout_chars = _message_chars(batched_scout_messages(batched))
    arbiter_base_chars = _message_chars(
        batched_arbiter_messages(
            batched,
            normalized_scout_bundles=None,
        )
    )
    estimated = max(
        scout_chars,
        arbiter_base_chars + ARBITER_CANDIDATE_RESERVE_CHARS,
    )
    if estimated > MAXIMUM_REQUEST_CHARS:
        raise BatchedCausalWorkflowError(
            "E9 batch exceeds the frozen request-character cap"
        )
    return BatchSpec(
        batch_id=_batch_identity(cases),
        case_keys=keys,
        trajectory_ids=tuple(case.trajectory_id for case in cases),
        ordered_case_input_sha256s=tuple(
            case.case_input_sha256 for case in cases
        ),
        scout_request_chars=scout_chars,
        arbiter_base_request_chars=arbiter_base_chars,
        maximum_estimated_request_chars=estimated,
    )


def _plan_from_document(value: Mapping[str, Any]) -> BatchPlan:
    expected = {
        "schema_version",
        "pipeline_version",
        "planner_version",
        "maximum_request_chars",
        "arbiter_candidate_reserve_chars",
        "maximum_batch_size",
        "prediction_manifest_sha256",
        "selected_trajectory_ids",
        "execution_order",
        "required_prefix_batch_plan_sha256",
        "batch_count",
        "batches",
        "batch_plan_sha256",
    }
    document = dict(value)
    if set(document) != expected:
        raise BatchedCausalWorkflowError("E9 batch-plan fields are invalid")
    body = dict(document)
    claimed = body.pop("batch_plan_sha256", None)
    if claimed != stable_sha256(body):
        raise BatchedCausalWorkflowError("E9 batch-plan hash is invalid")
    fixed = {
        "schema_version": E9_BATCH_PLAN_SCHEMA_VERSION,
        "pipeline_version": BATCHED_CAUSAL_PIPELINE_VERSION,
        "planner_version": E9_BATCH_PLANNER_VERSION,
        "maximum_request_chars": MAXIMUM_REQUEST_CHARS,
        "arbiter_candidate_reserve_chars": (
            ARBITER_CANDIDATE_RESERVE_CHARS
        ),
        "maximum_batch_size": MAX_BATCH_SIZE,
    }
    if any(document.get(key) != item for key, item in fixed.items()):
        raise BatchedCausalWorkflowError(
            "E9 batch-plan policy is unsupported"
        )
    selected = document.get("selected_trajectory_ids")
    execution_order = document.get("execution_order")
    raw_batches = document.get("batches")
    prefix_sha = document.get("required_prefix_batch_plan_sha256")
    if (
        not isinstance(selected, list)
        or not selected
        or any(not isinstance(item, str) or not item for item in selected)
        or len(set(selected)) != len(selected)
        or execution_order
        not in {
            "caller_selected_order",
            "required_seed_batch_then_remaining_manifest_order",
        }
        or not isinstance(raw_batches, list)
        or not raw_batches
        or document.get("batch_count") != len(raw_batches)
        or (
            prefix_sha is not None
            and _assert_sha256(
                prefix_sha,
                field="required_prefix_batch_plan_sha256",
            )
            != prefix_sha
        )
    ):
        raise BatchedCausalWorkflowError(
            "E9 batch-plan selection is invalid"
        )
    batches: list[BatchSpec] = []
    batch_fields = {
        "batch_id",
        "case_keys",
        "trajectory_ids",
        "ordered_case_input_sha256s",
        "scout_request_chars",
        "arbiter_base_request_chars",
        "maximum_estimated_request_chars",
    }
    for raw in raw_batches:
        if not isinstance(raw, Mapping) or set(raw) != batch_fields:
            raise BatchedCausalWorkflowError(
                "E9 batch specification fields are invalid"
            )
        size = len(raw["trajectory_ids"]) if isinstance(
            raw.get("trajectory_ids"), list
        ) else 0
        expected_keys = [f"C{index:02d}" for index in range(1, size + 1)]
        counters = [
            raw.get("scout_request_chars"),
            raw.get("arbiter_base_request_chars"),
            raw.get("maximum_estimated_request_chars"),
        ]
        if (
            size < 1
            or size > MAX_BATCH_SIZE
            or not isinstance(raw.get("batch_id"), str)
            or not raw["batch_id"]
            or any(
                not isinstance(item, str) or not item
                for item in raw.get("trajectory_ids", [])
            )
            or raw.get("case_keys") != expected_keys
            or not isinstance(raw.get("ordered_case_input_sha256s"), list)
            or len(raw["ordered_case_input_sha256s"]) != size
            or any(
                not isinstance(counter, int)
                or isinstance(counter, bool)
                or counter < 1
                for counter in counters
            )
            or raw["maximum_estimated_request_chars"]
            != max(
                raw["scout_request_chars"],
                raw["arbiter_base_request_chars"]
                + ARBITER_CANDIDATE_RESERVE_CHARS,
            )
            or raw["maximum_estimated_request_chars"]
            > MAXIMUM_REQUEST_CHARS
        ):
            raise BatchedCausalWorkflowError(
                "E9 batch specification is invalid"
            )
        for digest in raw["ordered_case_input_sha256s"]:
            _assert_sha256(digest, field="ordered case-input hash")
        batches.append(
            BatchSpec(
                batch_id=str(raw["batch_id"]),
                case_keys=tuple(raw["case_keys"]),
                trajectory_ids=tuple(raw["trajectory_ids"]),
                ordered_case_input_sha256s=tuple(
                    raw["ordered_case_input_sha256s"]
                ),
                scout_request_chars=raw["scout_request_chars"],
                arbiter_base_request_chars=raw[
                    "arbiter_base_request_chars"
                ],
                maximum_estimated_request_chars=raw[
                    "maximum_estimated_request_chars"
                ],
            )
        )
    plan = BatchPlan(
        prediction_manifest_sha256=_assert_sha256(
            document.get("prediction_manifest_sha256"),
            field="prediction_manifest_sha256",
        ),
        selected_trajectory_ids=tuple(selected),
        execution_order=execution_order,
        required_prefix_batch_plan_sha256=prefix_sha,
        batches=tuple(batches),
    )
    if (
        (prefix_sha is None)
        is not (execution_order == "caller_selected_order")
    ):
        raise BatchedCausalWorkflowError(
            "E9 batch-plan execution order and required prefix disagree"
        )
    if plan.to_dict() != document:
        raise BatchedCausalWorkflowError(
            "E9 batch-plan reconstruction diverges"
        )
    return plan


def _validate_plan_against_manifest(
    plan: BatchPlan,
    *,
    manifest: Mapping[str, Any],
    cases: Sequence[PredictionCase],
) -> None:
    if (
        plan.prediction_manifest_sha256
        != manifest["prediction_manifest_sha256"]
    ):
        raise BatchedCausalWorkflowError(
            "E9 plan and prediction manifest differ"
        )
    by_id = {case.trajectory_id: case for case in cases}
    selected_set = set(plan.selected_trajectory_ids)
    flattened = tuple(
        trajectory_id
        for batch in plan.batches
        for trajectory_id in batch.trajectory_ids
    )
    if (
        not selected_set <= set(by_id)
        or len(flattened) != len(selected_set)
        or set(flattened) != selected_set
        or len(set(flattened)) != len(flattened)
        or len(selected_set) != len(plan.selected_trajectory_ids)
    ):
        raise BatchedCausalWorkflowError(
            "E9 plan is not an exact manifest-order partition"
        )
    for batch in plan.batches:
        if any(item not in by_id for item in batch.trajectory_ids):
            raise BatchedCausalWorkflowError(
                "E9 plan contains an unknown trajectory"
            )
        source_cases = [by_id[item] for item in batch.trajectory_ids]
        expected = _make_batch_spec(source_cases)
        if expected != batch:
            raise BatchedCausalWorkflowError(
                "E9 batch plan diverges from gold-free prompt sizing"
            )


def load_batched_causal_batch_plan(
    path: str | Path,
    *,
    prediction_manifest_path: str | Path | None = None,
) -> BatchPlan:
    plan = _plan_from_document(
        _read_object(path, location="E9 batch plan")
    )
    if prediction_manifest_path is not None:
        manifest, cases = load_prediction_manifest(
            prediction_manifest_path
        )
        _validate_plan_against_manifest(
            plan,
            manifest=manifest,
            cases=cases,
        )
    return plan


def write_batched_causal_batch_plan(
    *,
    prediction_manifest_path: str | Path,
    selected_trajectory_ids: Sequence[str],
    output_path: str | Path,
    required_prefix_plan_path: str | Path | None = None,
) -> dict[str, Any]:
    """Freeze a gold-free greedy plan, optionally preserving prior batches."""

    manifest, cases = load_prediction_manifest(prediction_manifest_path)
    requested = tuple(str(item) for item in selected_trajectory_ids)
    requested_set = set(requested)
    if (
        not requested
        or len(requested_set) != len(requested)
        or not requested_set <= {case.trajectory_id for case in cases}
    ):
        raise BatchedCausalWorkflowError(
            "E9 plan selection must be unique and in manifest order"
        )
    by_id = {case.trajectory_id: case for case in cases}
    batches: list[BatchSpec] = []
    prefix_sha: str | None = None
    consumed = 0
    if required_prefix_plan_path is not None:
        prefix = load_batched_causal_batch_plan(
            required_prefix_plan_path,
            prediction_manifest_path=prediction_manifest_path,
        )
        prefix_ids = prefix.selected_trajectory_ids
        if not set(prefix_ids) <= requested_set:
            raise BatchedCausalWorkflowError(
                "E9 required prefix plan is outside the selection"
            )
        batches.extend(prefix.batches)
        prefix_sha = prefix.batch_plan_sha256
        consumed = len(prefix_ids)

    current: list[PredictionCase] = []
    remaining_ids = (
        requested[consumed:]
        if required_prefix_plan_path is None
        else tuple(
            trajectory_id
            for trajectory_id in requested
            if trajectory_id not in set(prefix.selected_trajectory_ids)
        )
    )
    for trajectory_id in remaining_ids:
        candidate = [*current, by_id[trajectory_id]]
        if len(candidate) <= MAX_BATCH_SIZE:
            try:
                _make_batch_spec(candidate)
            except BatchedCausalWorkflowError:
                pass
            else:
                current = candidate
                continue
        if not current:
            raise BatchedCausalWorkflowError(
                "E9 one-case request exceeds the frozen character cap"
            )
        batches.append(_make_batch_spec(current))
        current = [by_id[trajectory_id]]
        _make_batch_spec(current)
    if current:
        batches.append(_make_batch_spec(current))
    plan = BatchPlan(
        prediction_manifest_sha256=manifest[
            "prediction_manifest_sha256"
        ],
        selected_trajectory_ids=requested,
        execution_order=(
            "caller_selected_order"
            if required_prefix_plan_path is None
            else "required_seed_batch_then_remaining_manifest_order"
        ),
        required_prefix_batch_plan_sha256=prefix_sha,
        batches=tuple(batches),
    )
    _validate_plan_against_manifest(
        plan,
        manifest=manifest,
        cases=cases,
    )
    document = plan.to_dict()
    _assert_gold_free(document, location="E9 batch plan")
    _atomic_json(Path(output_path).expanduser().resolve(), document)
    return document


def _stage_input_identity(
    *,
    spec: BatchSpec,
    source_cases: Sequence[PredictionCase],
    prediction_manifest: Mapping[str, Any],
    config: BenchmarkRunConfig,
) -> dict[str, Any]:
    """Gold-free case/provider identity shared across compatible stages."""

    return {
        "judge_view_version": JUDGE_VIEW_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "prediction_manifest_sha256": prediction_manifest[
            "prediction_manifest_sha256"
        ],
        "batch_id": spec.batch_id,
        "case_keys": list(spec.case_keys),
        "ordered_case_input_sha256s": [
            case.case_input_sha256 for case in source_cases
        ],
        "ordered_trajectory_sha256s": [
            case.trajectory_sha256 for case in source_cases
        ],
        "ordered_judge_view_sha256s": [
            stable_sha256(case.judge_view.to_dict())
            for case in source_cases
        ],
        "provider_config": config.public_dict(),
    }


def _scout_stage_identity(
    *,
    spec: BatchSpec,
    source_cases: Sequence[PredictionCase],
    prediction_manifest: Mapping[str, Any],
    config: BenchmarkRunConfig,
) -> dict[str, Any]:
    """Bind the fresh v12 semantic-candidate Scout implementation."""

    return {
        "method": E9_METHOD,
        "experiment": E9_EXPERIMENT,
        "prediction_schema_version": E9_PREDICTION_SCHEMA_VERSION,
        "pipeline_version": BATCHED_CAUSAL_PIPELINE_VERSION,
        "scout_prompt_protocol_version": (
            BATCHED_SCOUT_PROMPT_PROTOCOL_VERSION
        ),
        "arbiter_prompt_protocol_version": (
            BATCHED_ARBITER_PROMPT_PROTOCOL_VERSION
        ),
        "evidence_validation_version": E9_EVIDENCE_VALIDATION_VERSION,
        "scout_cache_compatibility_version": (
            E9_SCOUT_CACHE_COMPATIBILITY_VERSION
        ),
        **_stage_input_identity(
            spec=spec,
            source_cases=source_cases,
            prediction_manifest=prediction_manifest,
            config=config,
        ),
    }


def _arbiter_stage_identity(
    *,
    spec: BatchSpec,
    source_cases: Sequence[PredictionCase],
    prediction_manifest: Mapping[str, Any],
    config: BenchmarkRunConfig,
) -> dict[str, Any]:
    """Bind the current v12 final semantic causal Arbiter."""

    return {
        "method": E9_METHOD,
        "experiment": E9_EXPERIMENT,
        "prediction_schema_version": E9_PREDICTION_SCHEMA_VERSION,
        "pipeline_version": BATCHED_CAUSAL_PIPELINE_VERSION,
        "scout_prompt_protocol_version": (
            BATCHED_SCOUT_PROMPT_PROTOCOL_VERSION
        ),
        "arbiter_prompt_protocol_version": (
            BATCHED_ARBITER_PROMPT_PROTOCOL_VERSION
        ),
        "evidence_validation_version": E9_EVIDENCE_VALIDATION_VERSION,
        "scout_cache_compatibility_version": (
            E9_SCOUT_CACHE_COMPATIBILITY_VERSION
        ),
        **_stage_input_identity(
            spec=spec,
            source_cases=source_cases,
            prediction_manifest=prediction_manifest,
            config=config,
        ),
    }


def _scout_stage_request(
    *,
    spec: BatchSpec,
    source_cases: Sequence[PredictionCase],
    batched_cases: Sequence[BatchedCase],
    prediction_manifest: Mapping[str, Any],
    config: BenchmarkRunConfig,
):
    messages = batched_scout_messages(batched_cases)
    request = build_stage_request(
        stage=BATCHED_SCOUT_STAGE,
        messages=messages,
        identity=_scout_stage_identity(
            spec=spec,
            source_cases=source_cases,
            prediction_manifest=prediction_manifest,
            config=config,
        ),
        dependency_sha256=stable_sha256(
            {
                "ordered_case_input_sha256s": (
                    spec.ordered_case_input_sha256s
                ),
                "no_prior_semantic_candidates": True,
            }
        ),
    )
    return request, messages


def _arbiter_stage_request(
    *,
    spec: BatchSpec,
    source_cases: Sequence[PredictionCase],
    batched_cases: Sequence[BatchedCase],
    prediction_manifest: Mapping[str, Any],
    config: BenchmarkRunConfig,
    normalized_scout_bundles: (
        Sequence[Mapping[str, Any] | None] | None
    ),
    scout_request_sha256: str,
    scout_raw_sha256: str,
    scout_status: str,
):
    messages = batched_arbiter_messages(
        batched_cases,
        normalized_scout_bundles=normalized_scout_bundles,
    )
    request = build_stage_request(
        stage=BATCHED_ARBITER_STAGE,
        messages=messages,
        identity={
            **_arbiter_stage_identity(
                spec=spec,
                source_cases=source_cases,
                prediction_manifest=prediction_manifest,
                config=config,
            ),
            "scout_request_sha256": scout_request_sha256,
            "scout_raw_sha256": scout_raw_sha256,
            "scout_status": scout_status,
        },
        dependency_sha256=stable_sha256(
            {
                "scout_request_sha256": scout_request_sha256,
                "scout_raw_sha256": scout_raw_sha256,
                "scout_status": scout_status,
            }
        ),
    )
    return request, messages


def _outcome(stage: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "status": stage["status"],
        "failure_stage": stage["failure_stage"],
        "failure_code": stage["failure_code"],
        "failure_message": stage["failure_message"],
    }


def _stage_identity(stage: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "request_sha256": stage["request_sha256"],
        "prompt_sha256": stage["prompt_sha256"],
        "raw_response_sha256": stage["raw_response_sha256"],
        "dependency_sha256": stage["identity"]["dependency_sha256"],
    }


def _adjudication_dict(value: BatchedAdjudication) -> dict[str, Any]:
    return {
        "case_key": value.case_key,
        "audit": value.audit,
        "decision": value.decision.to_dict(),
        "root": value.root.to_dict(),
    }


def _case_parse_outcome(error: JudgeOutputError) -> dict[str, Any]:
    status = (
        "invalid_taxonomy"
        if error.code in {"invalid_taxonomy", "invalid_taxonomy_pair"}
        else "invalid_output"
    )
    return {
        "status": status,
        "failure_stage": error.stage,
        "failure_code": error.code,
        "failure_message": error.safe_message,
    }


def _isolated_scout_document(
    raw: Any,
    *,
    cases: Sequence[BatchedCase],
) -> dict[str, Any]:
    values, failures = parse_batched_scout_isolated(raw, cases=cases)
    return {
        "cases": [
            {
                "case_key": case.case_key,
                "candidate_bundle": value,
                "failure": (
                    None
                    if failure is None
                    else _case_parse_outcome(failure)
                ),
            }
            for case, value, failure in zip(
                cases,
                values,
                failures,
                strict=True,
            )
        ]
    }


def _isolated_arbiter_document(
    raw: Any,
    *,
    cases: Sequence[BatchedCase],
) -> dict[str, Any]:
    values, failures = parse_batched_arbiter_isolated(raw, cases=cases)
    return {
        "cases": [
            {
                "case_key": case.case_key,
                "adjudication": (
                    None if value is None else _adjudication_dict(value)
                ),
                "failure": (
                    None
                    if failure is None
                    else _case_parse_outcome(failure)
                ),
            }
            for case, value, failure in zip(
                cases,
                values,
                failures,
                strict=True,
            )
        ]
    }


def _empty_semantics(
    outcome: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "status": outcome["status"],
        "failure_stage": outcome["failure_stage"],
        "failure_code": outcome["failure_code"],
        "failure_message": outcome["failure_message"],
        "root_cause_judgment": None,
        "judge_reported_step": None,
        "predicted_step": None,
        "predicted_event_id": None,
        "predicted_module": None,
        "predicted_error_type": None,
        "root_cause": None,
        "arbiter_audit": None,
        "decision": None,
        "evidence_source_id": None,
        "evidence_quote": None,
        "judge_step_matches_event_mapping": None,
    }


def _success_semantics(
    *,
    case: PredictionCase,
    adjudication: BatchedAdjudication,
) -> dict[str, Any]:
    root = adjudication.root
    mapped_step = case.step_for_event(root.critical_event_id)
    return {
        "status": "success",
        "failure_stage": None,
        "failure_code": None,
        "failure_message": None,
        "root_cause_judgment": root.to_dict(),
        "judge_reported_step": root.critical_step,
        "predicted_step": mapped_step,
        "predicted_event_id": root.critical_event_id,
        "predicted_module": root.module.value,
        "predicted_error_type": root.error_type.value,
        "root_cause": root.root_cause,
        "arbiter_audit": adjudication.audit,
        "decision": adjudication.decision.to_dict(),
        "evidence_source_id": adjudication.decision.evidence_source_id,
        "evidence_quote": root.evidence_quote,
        "judge_step_matches_event_mapping": (
            mapped_step is not None and mapped_step == root.critical_step
        ),
    }


def _provider_capability_snapshot(judge: Any) -> dict[str, Any] | None:
    snapshotter = getattr(judge, "capability_snapshot", None)
    if not callable(snapshotter):
        return None
    value = snapshotter()
    if not isinstance(value, Mapping):
        raise BatchedCausalWorkflowError(
            "E9 provider capability snapshot must be an object"
        )
    result = dict(value)
    _assert_gold_free(result, location="E9 provider capabilities")
    return result


def _batch_telemetry(
    stage_telemetry: Mapping[str, Any],
) -> dict[str, Any] | None:
    values = [stage_telemetry[stage] for stage in _STAGES]
    return sum_stage_telemetry(values)


def _aggregate_batch_telemetry(
    rows: Sequence[Mapping[str, Any]],
) -> tuple[dict[str, Any] | None, dict[str, Any]]:
    first_by_batch: dict[str, Mapping[str, Any]] = {}
    for row in rows:
        first_by_batch.setdefault(str(row["batch_id"]), row)
    values = [
        row["provider_telemetry"]
        for row in first_by_batch.values()
        if row.get("provider_telemetry") is not None
    ]
    coverage = {
        "batch_count": len(first_by_batch),
        "covered_batch_count": len(values),
        "complete": len(values) == len(first_by_batch),
    }
    return (
        sum_stage_telemetry(values) if values else None,
        coverage,
    )


def _validate_actual_request_chars(
    *,
    spec: BatchSpec,
    stage: str,
    messages: Sequence[Mapping[str, str]],
) -> None:
    actual = _message_chars(messages)
    if actual > MAXIMUM_REQUEST_CHARS:
        raise BatchedCausalWorkflowError(
            f"E9 {stage} actual request exceeds the frozen character cap"
        )
    if stage == BATCHED_SCOUT_STAGE:
        expected = spec.scout_request_chars
        if actual != expected:
            raise BatchedCausalWorkflowError(
                "E9 scout request size diverges from the frozen plan"
            )
    else:
        if (
            actual < spec.arbiter_base_request_chars
            or actual
            > spec.arbiter_base_request_chars
            + ARBITER_CANDIDATE_RESERVE_CHARS
        ):
            raise BatchedCausalWorkflowError(
            "E9 Arbiter Scout-bundle payload exceeds its frozen reserve"
            )


def predict_batched_causal_cases(
    *,
    prediction_manifest_path: str | Path,
    batch_plan_path: str | Path,
    preregistration_sha256: str,
    judge: Any,
    config: BenchmarkRunConfig,
    cache_dir: str | Path,
    unscored_output_path: str | Path,
    predict_run_metadata_path: str | Path,
    max_logical_completions: int,
    logical_completion_ledger_path: str | Path | None = None,
    cumulative_logical_completions_before: int = 0,
    authorized_cumulative_ceiling: int | None = None,
    on_batch: Callable[[Mapping[str, Any]], None] | None = None,
    on_result: Callable[[Mapping[str, Any]], None] | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Run every frozen batch without loading benchmark labels."""

    preregistration_digest = _assert_sha256(
        preregistration_sha256,
        field="preregistration_sha256",
    )
    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    plan_path = Path(batch_plan_path).expanduser().resolve()
    prediction_manifest, cases = load_prediction_manifest(manifest_path)
    plan = load_batched_causal_batch_plan(
        plan_path,
        prediction_manifest_path=manifest_path,
    )
    if (
        config.cohort_sha256 != prediction_manifest["cohort_sha256"]
        or not config.api_key_env
    ):
        raise BatchedCausalWorkflowError(
            "E9 prediction/provider identities do not match"
        )
    if (
        isinstance(max_logical_completions, bool)
        or not isinstance(max_logical_completions, int)
        or max_logical_completions < 1
    ):
        raise BatchedCausalWorkflowError(
            "E9 max_logical_completions must be positive"
        )
    complete = getattr(judge, "complete", None)
    if not callable(complete):
        raise TypeError("E9 prediction requires judge.complete(messages)")
    raw_snapshotter = getattr(judge, "telemetry_snapshot", None)
    telemetry_snapshotter = (
        raw_snapshotter if callable(raw_snapshotter) else None
    )
    cache_resolved = Path(cache_dir).expanduser().resolve()
    cache_root = cache_resolved / "semantic_stages"
    output_path = Path(unscored_output_path).expanduser().resolve()
    run_path = Path(predict_run_metadata_path).expanduser().resolve()
    if output_path.parent != run_path.parent:
        raise BatchedCausalWorkflowError(
            "E9 unscored and predict-run artifacts must share a directory"
        )
    ledger_path = (
        Path(logical_completion_ledger_path).expanduser().resolve()
        if logical_completion_ledger_path is not None
        else run_path.with_name("logical-completion-ledger.json")
    )
    if ledger_path.parent != output_path.parent:
        raise BatchedCausalWorkflowError(
            "E9 completion ledger must share the prediction directory"
        )
    ceiling = (
        cumulative_logical_completions_before + max_logical_completions
        if authorized_cumulative_ceiling is None
        else authorized_cumulative_ceiling
    )
    budget = DurableLogicalCompletionBudget(
        max_logical_completions,
        ledger_path=ledger_path,
        preregistration_sha256=preregistration_digest,
        cumulative_before=cumulative_logical_completions_before,
        authorized_cumulative_ceiling=ceiling,
        allowed_stages=_STAGES,
    )
    by_id = {case.trajectory_id: case for case in cases}
    rows: list[dict[str, Any]] = []
    _atomic_jsonl(output_path, rows)

    for batch_index, spec in enumerate(plan.batches, 1):
        source_cases = [by_id[item] for item in spec.trajectory_ids]
        batched_cases = _cases_for_spec(spec, by_id=by_id)
        scout_request, scout_messages = _scout_stage_request(
            spec=spec,
            source_cases=source_cases,
            batched_cases=batched_cases,
            prediction_manifest=prediction_manifest,
            config=config,
        )
        _validate_actual_request_chars(
            spec=spec,
            stage=BATCHED_SCOUT_STAGE,
            messages=scout_messages,
        )
        scout_stage, scout_cache_hit = run_cached_stage(
            request=scout_request,
            messages=scout_messages,
            complete=complete,
            parser=lambda raw, batch=tuple(batched_cases): (
                _isolated_scout_document(raw, cases=batch)
            ),
            cache_root=cache_root,
            retry_failures=False,
            telemetry_snapshotter=telemetry_snapshotter,
            completion_guard=lambda request=scout_request: (
                budget.before_complete(
                    stage=BATCHED_SCOUT_STAGE,
                    request_sha256=request.request_sha256,
                )
            ),
        )
        scout_candidate_bundles: list[dict[str, Any] | None] = [
            None for _case in batched_cases
        ]
        normalized_scout_input: (
            list[dict[str, Any] | None] | None
        ) = None
        if scout_stage["status"] == "success":
            scout_candidate_bundles, _scout_case_failures = (
                parse_batched_scout_isolated(
                    scout_stage["raw_response"],
                    cases=batched_cases,
                )
            )
            normalized_scout_input = scout_candidate_bundles

        arbiter_request, arbiter_messages = _arbiter_stage_request(
            spec=spec,
            source_cases=source_cases,
            batched_cases=batched_cases,
            prediction_manifest=prediction_manifest,
            config=config,
            normalized_scout_bundles=normalized_scout_input,
            scout_request_sha256=scout_request.request_sha256,
            scout_raw_sha256=scout_stage["raw_response_sha256"],
            scout_status=scout_stage["status"],
        )
        _validate_actual_request_chars(
            spec=spec,
            stage=BATCHED_ARBITER_STAGE,
            messages=arbiter_messages,
        )
        arbiter_stage, arbiter_cache_hit = run_cached_stage(
            request=arbiter_request,
            messages=arbiter_messages,
            complete=complete,
            parser=lambda raw, batch=tuple(batched_cases): (
                _isolated_arbiter_document(raw, cases=batch)
            ),
            cache_root=cache_root,
            retry_failures=False,
            telemetry_snapshotter=telemetry_snapshotter,
            completion_guard=lambda request=arbiter_request: (
                budget.before_complete(
                    stage=BATCHED_ARBITER_STAGE,
                    request_sha256=request.request_sha256,
                )
            ),
        )
        adjudications: list[BatchedAdjudication | None] = [
            None for _case in batched_cases
        ]
        arbiter_case_failures: list[JudgeOutputError | None] = [
            None for _case in batched_cases
        ]
        if arbiter_stage["status"] == "success":
            adjudications, arbiter_case_failures = (
                parse_batched_arbiter_isolated(
                    arbiter_stage["raw_response"],
                    cases=batched_cases,
                )
            )

        cache_hits = {
            BATCHED_SCOUT_STAGE: scout_cache_hit,
            BATCHED_ARBITER_STAGE: arbiter_cache_hit,
        }
        identities = {
            BATCHED_SCOUT_STAGE: _stage_identity(scout_stage),
            BATCHED_ARBITER_STAGE: _stage_identity(arbiter_stage),
        }
        outcomes = {
            BATCHED_SCOUT_STAGE: _outcome(scout_stage),
            BATCHED_ARBITER_STAGE: _outcome(arbiter_stage),
        }
        raw_outputs = {
            BATCHED_SCOUT_STAGE: scout_stage["raw_response"],
            BATCHED_ARBITER_STAGE: arbiter_stage["raw_response"],
        }
        stage_telemetry = {
            BATCHED_SCOUT_STAGE: scout_stage["stage_telemetry"],
            BATCHED_ARBITER_STAGE: arbiter_stage["stage_telemetry"],
        }
        provider_telemetry = _batch_telemetry(stage_telemetry)
        latency = float(scout_stage["latency_seconds"]) + float(
            arbiter_stage["latency_seconds"]
        )
        batch_rows: list[dict[str, Any]] = []
        for case_offset, (source_case, batched_case) in enumerate(
            zip(source_cases, batched_cases, strict=True)
        ):
            adjudication = adjudications[case_offset]
            case_failure = arbiter_case_failures[case_offset]
            semantics = (
                _success_semantics(
                    case=source_case,
                    adjudication=adjudication,
                )
                if adjudication is not None
                else _empty_semantics(
                    _case_parse_outcome(case_failure)
                    if case_failure is not None
                    else outcomes[BATCHED_ARBITER_STAGE]
                )
            )
            row: dict[str, Any] = {
                "schema_version": E9_PREDICTION_SCHEMA_VERSION,
                "method": E9_METHOD,
                "experiment": E9_EXPERIMENT,
                "pipeline_version": BATCHED_CAUSAL_PIPELINE_VERSION,
                "scout_prompt_protocol_version": (
                    BATCHED_SCOUT_PROMPT_PROTOCOL_VERSION
                ),
                "arbiter_prompt_protocol_version": (
                    BATCHED_ARBITER_PROMPT_PROTOCOL_VERSION
                ),
                "evidence_validation_version": (
                    E9_EVIDENCE_VALIDATION_VERSION
                ),
                "semantic_classifier": E9_SEMANTIC_CLASSIFIER,
                "transport_policy_version": TRANSPORT_POLICY_VERSION,
                "preregistration_sha256": preregistration_digest,
                "prediction_manifest_sha256": prediction_manifest[
                    "prediction_manifest_sha256"
                ],
                "batch_plan_sha256": plan.batch_plan_sha256,
                "batch_id": spec.batch_id,
                "batch_index": batch_index,
                "case_key": batched_case.case_key,
                "batch_case_keys": list(spec.case_keys),
                "batch_trajectory_ids": list(spec.trajectory_ids),
                "ordered_case_input_sha256s": list(
                    spec.ordered_case_input_sha256s
                ),
                "trajectory_id": source_case.trajectory_id,
                "trajectory_sha256": source_case.trajectory_sha256,
                "case_input_sha256": source_case.case_input_sha256,
                "provider_config": config.public_dict(),
                "cache_dir": str(cache_resolved),
                "stage_attempted": {
                    BATCHED_SCOUT_STAGE: True,
                    BATCHED_ARBITER_STAGE: True,
                },
                "stage_cache_hits": cache_hits,
                "stage_identities": identities,
                "stage_outcomes": outcomes,
                "stage_provider_telemetry": stage_telemetry,
                "raw_judge_outputs": raw_outputs,
                "scout_candidate_bundle": (
                    scout_candidate_bundles[case_offset]
                ),
                "provider_telemetry": provider_telemetry,
                "latency_seconds": latency,
                "cache_hit": all(cache_hits.values()),
                **semantics,
            }
            _assert_gold_free(row, location="E9 unscored prediction")
            row["unscored_prediction_sha256"] = stable_sha256(row)
            batch_rows.append(row)
        rows.extend(batch_rows)
        _atomic_jsonl(output_path, rows)
        for row in batch_rows:
            if on_result is not None:
                on_result(row)
        if on_batch is not None:
            on_batch(
                {
                    "batch_index": batch_index,
                    "batch_id": spec.batch_id,
                    "trajectory_ids": list(spec.trajectory_ids),
                    "stage_cache_hits": cache_hits,
                    "stage_outcomes": outcomes,
                    "unscored_prediction_sha256s": [
                        row["unscored_prediction_sha256"]
                        for row in batch_rows
                    ],
                }
            )

    telemetry, coverage = _aggregate_batch_telemetry(rows)
    ledger = budget.snapshot
    metadata = _document_with_hash(
        {
            "schema_version": E9_PREDICT_RUN_SCHEMA_VERSION,
            "method": E9_METHOD,
            "experiment": E9_EXPERIMENT,
            "pipeline_version": BATCHED_CAUSAL_PIPELINE_VERSION,
            "scout_prompt_protocol_version": (
                BATCHED_SCOUT_PROMPT_PROTOCOL_VERSION
            ),
            "arbiter_prompt_protocol_version": (
                BATCHED_ARBITER_PROMPT_PROTOCOL_VERSION
            ),
            "evidence_validation_version": (
                E9_EVIDENCE_VALIDATION_VERSION
            ),
            "transport_policy_version": TRANSPORT_POLICY_VERSION,
            "preregistration_sha256": preregistration_digest,
            "prediction_manifest_path": str(manifest_path),
            "prediction_manifest_file_sha256": _file_sha256(manifest_path),
            "prediction_manifest_sha256": prediction_manifest[
                "prediction_manifest_sha256"
            ],
            "batch_plan_path": str(plan_path),
            "batch_plan_file_sha256": _file_sha256(plan_path),
            "batch_plan_sha256": plan.batch_plan_sha256,
            "unscored_predictions_path": str(output_path),
            "unscored_predictions_sha256": _file_sha256(output_path),
            "predict_run_metadata_path": str(run_path),
            "run_output_dir": str(output_path.parent),
            "cache_dir": str(cache_resolved),
            "selected_trajectory_ids": list(
                plan.selected_trajectory_ids
            ),
            "prediction_count": len(rows),
            "batch_count": len(plan.batches),
            "maximum_batch_size": MAX_BATCH_SIZE,
            "maximum_request_chars": MAXIMUM_REQUEST_CHARS,
            "arbiter_candidate_reserve_chars": (
                ARBITER_CANDIDATE_RESERVE_CHARS
            ),
            "provider_config": config.public_dict(),
            "provider_telemetry": telemetry,
            "provider_telemetry_coverage": coverage,
            "provider_capabilities": _provider_capability_snapshot(judge),
            "semantic_mutation_count": 0,
            "max_logical_completions": max_logical_completions,
            "logical_completion_budget_used": len(ledger["entries"]),
            "logical_completion_ledger_path": str(ledger_path),
            "logical_completion_ledger_file_sha256": _file_sha256(
                ledger_path
            ),
            "logical_completion_ledger_sha256": ledger["ledger_sha256"],
            "retry_failures": False,
        },
        hash_field="predict_run_sha256",
    )
    _assert_gold_free(metadata, location="E9 predict run")
    _atomic_json(run_path, metadata)
    return rows, metadata


_SEMANTIC_FIELDS = {
    "status",
    "failure_stage",
    "failure_code",
    "failure_message",
    "root_cause_judgment",
    "judge_reported_step",
    "predicted_step",
    "predicted_event_id",
    "predicted_module",
    "predicted_error_type",
    "root_cause",
    "arbiter_audit",
    "decision",
    "evidence_source_id",
    "evidence_quote",
    "judge_step_matches_event_mapping",
}
_ROW_FIELDS = {
    "schema_version",
    "method",
    "experiment",
    "pipeline_version",
    "scout_prompt_protocol_version",
    "arbiter_prompt_protocol_version",
    "evidence_validation_version",
    "semantic_classifier",
    "transport_policy_version",
    "preregistration_sha256",
    "prediction_manifest_sha256",
    "batch_plan_sha256",
    "batch_id",
    "batch_index",
    "case_key",
    "batch_case_keys",
    "batch_trajectory_ids",
    "ordered_case_input_sha256s",
    "trajectory_id",
    "trajectory_sha256",
    "case_input_sha256",
    "provider_config",
    "cache_dir",
    "stage_attempted",
    "stage_cache_hits",
    "stage_identities",
    "stage_outcomes",
    "stage_provider_telemetry",
    "raw_judge_outputs",
    "scout_candidate_bundle",
    "provider_telemetry",
    "latency_seconds",
    "cache_hit",
    *_SEMANTIC_FIELDS,
    "unscored_prediction_sha256",
}
_RUN_FIELDS = {
    "schema_version",
    "method",
    "experiment",
    "pipeline_version",
    "scout_prompt_protocol_version",
    "arbiter_prompt_protocol_version",
    "evidence_validation_version",
    "transport_policy_version",
    "preregistration_sha256",
    "prediction_manifest_path",
    "prediction_manifest_file_sha256",
    "prediction_manifest_sha256",
    "batch_plan_path",
    "batch_plan_file_sha256",
    "batch_plan_sha256",
    "unscored_predictions_path",
    "unscored_predictions_sha256",
    "predict_run_metadata_path",
    "run_output_dir",
    "cache_dir",
    "selected_trajectory_ids",
    "prediction_count",
    "batch_count",
    "maximum_batch_size",
    "maximum_request_chars",
    "arbiter_candidate_reserve_chars",
    "provider_config",
    "provider_telemetry",
    "provider_telemetry_coverage",
    "provider_capabilities",
    "semantic_mutation_count",
    "max_logical_completions",
    "logical_completion_budget_used",
    "logical_completion_ledger_path",
    "logical_completion_ledger_file_sha256",
    "logical_completion_ledger_sha256",
    "retry_failures",
    "predict_run_sha256",
}


def _validate_stage_identity(
    *,
    persisted: Any,
    request: Any,
    raw: Any,
) -> None:
    expected = {
        "request_sha256": request.request_sha256,
        "prompt_sha256": request.prompt_sha256,
        "raw_response_sha256": stage_sha256(raw),
        "dependency_sha256": request.identity["dependency_sha256"],
    }
    if persisted != expected:
        raise BatchedCausalWorkflowError(
            "E9 stage identity diverges from raw request"
        )


def _validate_outcome(
    outcome: Any,
    *,
    stage: str,
    parsed: bool,
) -> None:
    if not isinstance(outcome, Mapping) or set(outcome) != _OUTCOME_FIELDS:
        raise BatchedCausalWorkflowError(
            f"E9 {stage} outcome fields are invalid"
        )
    if parsed:
        if outcome != {
            "status": "success",
            "failure_stage": None,
            "failure_code": None,
            "failure_message": None,
        }:
            raise BatchedCausalWorkflowError(
                f"E9 {stage} successful raw response has wrong outcome"
            )
        return
    if (
        outcome.get("status") == "success"
        or outcome.get("failure_stage") != stage
        or not isinstance(outcome.get("failure_code"), str)
        or not outcome["failure_code"]
        or not isinstance(outcome.get("failure_message"), str)
        or not outcome["failure_message"]
    ):
        raise BatchedCausalWorkflowError(
            f"E9 {stage} failed raw response has wrong outcome"
        )


def _validate_rows(
    rows: Sequence[Mapping[str, Any]],
    *,
    prediction_manifest: Mapping[str, Any],
    cases: Sequence[PredictionCase],
    plan: BatchPlan,
    config: BenchmarkRunConfig,
    preregistration_sha256: str,
    cache_dir: Path,
    require_complete: bool,
) -> list[dict[str, Any]]:
    by_id = {case.trajectory_id: case for case in cases}
    validated: list[dict[str, Any]] = []
    offset = 0
    for batch_index, spec in enumerate(plan.batches, 1):
        if offset == len(rows):
            if require_complete:
                raise BatchedCausalWorkflowError(
                    "E9 unscored predictions end before the plan"
                )
            break
        batch_size = len(spec.trajectory_ids)
        if len(rows) - offset < batch_size:
            raise BatchedCausalWorkflowError(
                "E9 partial predictions end inside a batch"
            )
        raw_batch_rows = [
            dict(item) for item in rows[offset : offset + batch_size]
        ]
        offset += batch_size
        source_cases = [by_id[item] for item in spec.trajectory_ids]
        batched_cases = _cases_for_spec(spec, by_id=by_id)
        first = raw_batch_rows[0]
        shared_fields = {
            "stage_attempted",
            "stage_cache_hits",
            "stage_identities",
            "stage_outcomes",
            "stage_provider_telemetry",
            "raw_judge_outputs",
            "provider_telemetry",
            "latency_seconds",
            "cache_hit",
        }
        for row in raw_batch_rows:
            if set(row) != _ROW_FIELDS:
                raise BatchedCausalWorkflowError(
                    "E9 unscored prediction fields are invalid"
                )
            body = dict(row)
            claimed = body.pop("unscored_prediction_sha256", None)
            if claimed != stable_sha256(body):
                raise BatchedCausalWorkflowError(
                    "E9 unscored prediction hash is invalid"
                )
            if any(row.get(field) != first.get(field) for field in shared_fields):
                raise BatchedCausalWorkflowError(
                    "E9 rows in one batch have divergent stage envelopes"
                )

        identity_base = {
            "schema_version": E9_PREDICTION_SCHEMA_VERSION,
            "method": E9_METHOD,
            "experiment": E9_EXPERIMENT,
            "pipeline_version": BATCHED_CAUSAL_PIPELINE_VERSION,
            "scout_prompt_protocol_version": (
                BATCHED_SCOUT_PROMPT_PROTOCOL_VERSION
            ),
            "arbiter_prompt_protocol_version": (
                BATCHED_ARBITER_PROMPT_PROTOCOL_VERSION
            ),
            "evidence_validation_version": (
                E9_EVIDENCE_VALIDATION_VERSION
            ),
            "semantic_classifier": E9_SEMANTIC_CLASSIFIER,
            "transport_policy_version": TRANSPORT_POLICY_VERSION,
            "preregistration_sha256": preregistration_sha256,
            "prediction_manifest_sha256": prediction_manifest[
                "prediction_manifest_sha256"
            ],
            "batch_plan_sha256": plan.batch_plan_sha256,
            "batch_id": spec.batch_id,
            "batch_index": batch_index,
            "batch_case_keys": list(spec.case_keys),
            "batch_trajectory_ids": list(spec.trajectory_ids),
            "ordered_case_input_sha256s": list(
                spec.ordered_case_input_sha256s
            ),
            "provider_config": config.public_dict(),
            "cache_dir": str(cache_dir),
        }
        for row, source_case, batched_case in zip(
            raw_batch_rows,
            source_cases,
            batched_cases,
            strict=True,
        ):
            checks = {
                **identity_base,
                "case_key": batched_case.case_key,
                "trajectory_id": source_case.trajectory_id,
                "trajectory_sha256": source_case.trajectory_sha256,
                "case_input_sha256": source_case.case_input_sha256,
            }
            if any(
                row.get(field) != expected
                for field, expected in checks.items()
            ):
                raise BatchedCausalWorkflowError(
                    "E9 unscored prediction identity is invalid"
                )

        attempted = first.get("stage_attempted")
        cache_hits = first.get("stage_cache_hits")
        identities = first.get("stage_identities")
        outcomes = first.get("stage_outcomes")
        stage_telemetry = first.get("stage_provider_telemetry")
        raw_outputs = first.get("raw_judge_outputs")
        maps = (
            attempted,
            cache_hits,
            identities,
            outcomes,
            stage_telemetry,
            raw_outputs,
        )
        if any(
            not isinstance(item, Mapping) or set(item) != set(_STAGES)
            for item in maps
        ):
            raise BatchedCausalWorkflowError(
                "E9 stage envelopes are invalid"
            )
        if attempted != {
            BATCHED_SCOUT_STAGE: True,
            BATCHED_ARBITER_STAGE: True,
        } or any(
            not isinstance(cache_hits[stage], bool) for stage in _STAGES
        ):
            raise BatchedCausalWorkflowError("E9 stage flags are invalid")

        scout_request, scout_messages = _scout_stage_request(
            spec=spec,
            source_cases=source_cases,
            batched_cases=batched_cases,
            prediction_manifest=prediction_manifest,
            config=config,
        )
        _validate_actual_request_chars(
            spec=spec,
            stage=BATCHED_SCOUT_STAGE,
            messages=scout_messages,
        )
        _validate_stage_identity(
            persisted=identities[BATCHED_SCOUT_STAGE],
            request=scout_request,
            raw=raw_outputs[BATCHED_SCOUT_STAGE],
        )
        scout_candidate_bundles: list[dict[str, Any] | None] = [
            None for _case in batched_cases
        ]
        normalized_scout_input: (
            list[dict[str, Any] | None] | None
        )
        scout_envelope_valid = False
        try:
            scout_candidate_bundles, _scout_case_failures = (
                parse_batched_scout_isolated(
                    raw_outputs[BATCHED_SCOUT_STAGE],
                    cases=batched_cases,
                )
            )
        except JudgeOutputError:
            normalized_scout_input = None
        else:
            normalized_scout_input = scout_candidate_bundles
            scout_envelope_valid = True
        _validate_outcome(
            outcomes[BATCHED_SCOUT_STAGE],
            stage=BATCHED_SCOUT_STAGE,
            parsed=scout_envelope_valid,
        )

        arbiter_request, arbiter_messages = _arbiter_stage_request(
            spec=spec,
            source_cases=source_cases,
            batched_cases=batched_cases,
            prediction_manifest=prediction_manifest,
            config=config,
            normalized_scout_bundles=normalized_scout_input,
            scout_request_sha256=scout_request.request_sha256,
            scout_raw_sha256=stage_sha256(
                raw_outputs[BATCHED_SCOUT_STAGE]
            ),
            scout_status=outcomes[BATCHED_SCOUT_STAGE]["status"],
        )
        _validate_actual_request_chars(
            spec=spec,
            stage=BATCHED_ARBITER_STAGE,
            messages=arbiter_messages,
        )
        _validate_stage_identity(
            persisted=identities[BATCHED_ARBITER_STAGE],
            request=arbiter_request,
            raw=raw_outputs[BATCHED_ARBITER_STAGE],
        )
        adjudications: list[BatchedAdjudication | None] = [
            None for _case in batched_cases
        ]
        arbiter_case_failures: list[JudgeOutputError | None] = [
            None for _case in batched_cases
        ]
        arbiter_envelope_valid = False
        try:
            adjudications, arbiter_case_failures = (
                parse_batched_arbiter_isolated(
                    raw_outputs[BATCHED_ARBITER_STAGE],
                    cases=batched_cases,
                )
            )
        except JudgeOutputError:
            pass
        else:
            arbiter_envelope_valid = True
        _validate_outcome(
            outcomes[BATCHED_ARBITER_STAGE],
            stage=BATCHED_ARBITER_STAGE,
            parsed=arbiter_envelope_valid,
        )

        expected_telemetry = _batch_telemetry(stage_telemetry)
        if first.get("provider_telemetry") != expected_telemetry:
            raise BatchedCausalWorkflowError(
                "E9 batch telemetry diverges from its stages"
            )
        if first.get("cache_hit") is not all(cache_hits.values()):
            raise BatchedCausalWorkflowError(
                "E9 batch cache-hit summary is invalid"
            )
        latency = first.get("latency_seconds")
        if (
            isinstance(latency, bool)
            or not isinstance(latency, (int, float))
            or latency < 0
        ):
            raise BatchedCausalWorkflowError("E9 latency is invalid")

        for index, (row, source_case) in enumerate(
            zip(raw_batch_rows, source_cases, strict=True)
        ):
            if (
                row.get("scout_candidate_bundle")
                != scout_candidate_bundles[index]
            ):
                raise BatchedCausalWorkflowError(
                    "E9 Scout candidate bundle diverges from raw Scout output"
                )
            adjudication = adjudications[index]
            case_failure = arbiter_case_failures[index]
            semantics = (
                _success_semantics(
                    case=source_case,
                    adjudication=adjudication,
                )
                if adjudication is not None
                else _empty_semantics(
                    _case_parse_outcome(case_failure)
                    if case_failure is not None
                    else outcomes[BATCHED_ARBITER_STAGE]
                )
            )
            for field, expected in semantics.items():
                if row.get(field) != expected:
                    raise BatchedCausalWorkflowError(
                        f"E9 {field} diverges from raw arbiter output"
                    )
            _assert_gold_free(row, location="E9 unscored prediction")
            validated.append(row)
    if offset != len(rows):
        raise BatchedCausalWorkflowError(
            "E9 unscored predictions exceed the frozen plan"
        )
    if require_complete and len(validated) != len(
        plan.selected_trajectory_ids
    ):
        raise BatchedCausalWorkflowError(
            "E9 unscored prediction count is incomplete"
        )
    return validated


def validate_partial_batched_causal_predictions(
    *,
    prediction_manifest_path: str | Path,
    batch_plan_path: str | Path,
    unscored_predictions_path: str | Path,
    preregistration_sha256: str,
    cache_dir: str | Path,
    config: BenchmarkRunConfig,
) -> list[dict[str, Any]]:
    """Validate a crash-recovery prefix without loading benchmark gold."""

    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    manifest, cases = load_prediction_manifest(manifest_path)
    plan = load_batched_causal_batch_plan(
        batch_plan_path,
        prediction_manifest_path=manifest_path,
    )
    path = Path(unscored_predictions_path).expanduser().resolve()
    if not path.is_file() or not path.read_text(encoding="utf-8"):
        return []
    rows = _read_jsonl(path)
    return _validate_rows(
        rows,
        prediction_manifest=manifest,
        cases=cases,
        plan=plan,
        config=config,
        preregistration_sha256=_assert_sha256(
            preregistration_sha256,
            field="preregistration_sha256",
        ),
        cache_dir=Path(cache_dir).expanduser().resolve(),
        require_complete=False,
    )


def _load_predict_run(
    *,
    path: str | Path,
    prediction_manifest_path: Path,
    batch_plan_path: Path,
    unscored_path: Path,
    rows: Sequence[Mapping[str, Any]],
    prediction_manifest: Mapping[str, Any],
    plan: BatchPlan,
    config: BenchmarkRunConfig,
    preregistration_sha256: str,
    cache_dir: Path,
) -> dict[str, Any]:
    run_path = Path(path).expanduser().resolve()
    run = _read_object(run_path, location="E9 predict run")
    if set(run) != _RUN_FIELDS:
        raise BatchedCausalWorkflowError(
            "E9 predict-run fields are invalid"
        )
    body = dict(run)
    claimed = body.pop("predict_run_sha256", None)
    if claimed != stable_sha256(body):
        raise BatchedCausalWorkflowError("E9 predict-run hash is invalid")
    checks = {
        "schema_version": E9_PREDICT_RUN_SCHEMA_VERSION,
        "method": E9_METHOD,
        "experiment": E9_EXPERIMENT,
        "pipeline_version": BATCHED_CAUSAL_PIPELINE_VERSION,
        "scout_prompt_protocol_version": (
            BATCHED_SCOUT_PROMPT_PROTOCOL_VERSION
        ),
        "arbiter_prompt_protocol_version": (
            BATCHED_ARBITER_PROMPT_PROTOCOL_VERSION
        ),
        "evidence_validation_version": E9_EVIDENCE_VALIDATION_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "preregistration_sha256": preregistration_sha256,
        "prediction_manifest_path": str(prediction_manifest_path),
        "prediction_manifest_file_sha256": _file_sha256(
            prediction_manifest_path
        ),
        "prediction_manifest_sha256": prediction_manifest[
            "prediction_manifest_sha256"
        ],
        "batch_plan_path": str(batch_plan_path),
        "batch_plan_file_sha256": _file_sha256(batch_plan_path),
        "batch_plan_sha256": plan.batch_plan_sha256,
        "unscored_predictions_path": str(unscored_path),
        "unscored_predictions_sha256": _file_sha256(unscored_path),
        "predict_run_metadata_path": str(run_path),
        "run_output_dir": str(unscored_path.parent),
        "cache_dir": str(cache_dir),
        "selected_trajectory_ids": list(plan.selected_trajectory_ids),
        "prediction_count": len(rows),
        "batch_count": len(plan.batches),
        "maximum_batch_size": MAX_BATCH_SIZE,
        "maximum_request_chars": MAXIMUM_REQUEST_CHARS,
        "arbiter_candidate_reserve_chars": (
            ARBITER_CANDIDATE_RESERVE_CHARS
        ),
        "provider_config": config.public_dict(),
        "semantic_mutation_count": 0,
        "retry_failures": False,
    }
    if any(run.get(field) != expected for field, expected in checks.items()):
        raise BatchedCausalWorkflowError(
            "E9 predict-run identity is invalid"
        )
    telemetry, coverage = _aggregate_batch_telemetry(rows)
    if (
        run.get("provider_telemetry") != telemetry
        or run.get("provider_telemetry_coverage") != coverage
    ):
        raise BatchedCausalWorkflowError(
            "E9 predict-run telemetry aggregates are invalid"
        )
    capabilities = run.get("provider_capabilities")
    if capabilities is not None and not isinstance(capabilities, Mapping):
        raise BatchedCausalWorkflowError(
            "E9 provider capabilities are invalid"
        )
    maximum = run.get("max_logical_completions")
    used = run.get("logical_completion_budget_used")
    raw_ledger_path = run.get("logical_completion_ledger_path")
    ledger_path = (
        Path(raw_ledger_path).expanduser().resolve()
        if isinstance(raw_ledger_path, str)
        else run_path.parent / "<invalid-ledger>"
    )
    if (
        isinstance(maximum, bool)
        or not isinstance(maximum, int)
        or maximum < 1
        or isinstance(used, bool)
        or not isinstance(used, int)
        or used < 0
        or used > maximum
        or ledger_path.parent != run_path.parent
        or raw_ledger_path != str(ledger_path)
    ):
        raise BatchedCausalWorkflowError(
            "E9 logical-completion budget metadata is invalid"
        )
    ledger = load_fresh_semantic_completion_ledger(
        ledger_path,
        preregistration_sha256=preregistration_sha256,
        maximum_new=maximum,
        allowed_stages=_STAGES,
    )
    if (
        run.get("logical_completion_ledger_file_sha256")
        != _file_sha256(ledger_path)
        or run.get("logical_completion_ledger_sha256")
        != ledger["ledger_sha256"]
        or used != len(ledger["entries"])
    ):
        raise BatchedCausalWorkflowError(
            "E9 ledger diverges from predict-run metadata"
        )
    first_by_batch: dict[str, Mapping[str, Any]] = {}
    for row in rows:
        first_by_batch.setdefault(str(row["batch_id"]), row)
    attempted_requests = {
        (
            stage,
            row["stage_identities"][stage]["request_sha256"],
        )
        for row in first_by_batch.values()
        for stage in _STAGES
    }
    cache_miss_requests = {
        (
            stage,
            row["stage_identities"][stage]["request_sha256"],
        )
        for row in first_by_batch.values()
        for stage in _STAGES
        if not row["stage_cache_hits"][stage]
    }
    ledger_requests = [
        (entry["stage"], entry["request_sha256"])
        for entry in ledger["entries"]
    ]
    if (
        any(request not in attempted_requests for request in ledger_requests)
        or not cache_miss_requests <= set(ledger_requests)
    ):
        raise BatchedCausalWorkflowError(
            "E9 ledger diverges from attempted batched stages"
        )
    _assert_gold_free(run, location="E9 predict run")
    return run


def validate_batched_causal_artifacts(
    *,
    prediction_manifest_path: str | Path,
    batch_plan_path: str | Path,
    unscored_predictions_path: str | Path,
    predict_run_metadata_path: str | Path,
) -> tuple[
    dict[str, Any],
    list[PredictionCase],
    BatchPlan,
    list[dict[str, Any]],
    dict[str, Any],
    BenchmarkRunConfig,
]:
    """Reconstruct the complete gold-free E9 raw prediction chain."""

    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    plan_path = Path(batch_plan_path).expanduser().resolve()
    unscored_path = Path(unscored_predictions_path).expanduser().resolve()
    prediction_manifest, cases = load_prediction_manifest(manifest_path)
    plan = load_batched_causal_batch_plan(
        plan_path,
        prediction_manifest_path=manifest_path,
    )
    rows = _read_jsonl(unscored_path)
    first_config = rows[0].get("provider_config")
    if not isinstance(first_config, Mapping):
        raise BatchedCausalWorkflowError(
            "E9 prediction provider config is missing"
        )
    try:
        config = BenchmarkRunConfig(**dict(first_config))
    except (TypeError, ValueError) as error:
        raise BatchedCausalWorkflowError(
            "E9 prediction provider config is invalid"
        ) from error
    if config.cohort_sha256 != prediction_manifest["cohort_sha256"]:
        raise BatchedCausalWorkflowError(
            "E9 prediction provider/cohort identity is invalid"
        )
    preregistration_sha256 = _assert_sha256(
        rows[0].get("preregistration_sha256"),
        field="preregistration_sha256",
    )
    raw_cache_dir = rows[0].get("cache_dir")
    if not isinstance(raw_cache_dir, str) or not raw_cache_dir:
        raise BatchedCausalWorkflowError(
            "E9 prediction cache directory is missing"
        )
    cache_dir = Path(raw_cache_dir).expanduser().resolve()
    if str(cache_dir) != raw_cache_dir:
        raise BatchedCausalWorkflowError(
            "E9 prediction cache directory is not canonical"
        )
    validated = _validate_rows(
        rows,
        prediction_manifest=prediction_manifest,
        cases=cases,
        plan=plan,
        config=config,
        preregistration_sha256=preregistration_sha256,
        cache_dir=cache_dir,
        require_complete=True,
    )
    run = _load_predict_run(
        path=predict_run_metadata_path,
        prediction_manifest_path=manifest_path,
        batch_plan_path=plan_path,
        unscored_path=unscored_path,
        rows=validated,
        prediction_manifest=prediction_manifest,
        plan=plan,
        config=config,
        preregistration_sha256=preregistration_sha256,
        cache_dir=cache_dir,
    )
    return prediction_manifest, cases, plan, validated, run, config


def score_batched_causal_predictions(
    *,
    dataset: BenchmarkDataset,
    cohort: CohortManifest,
    prediction_manifest_path: str | Path,
    batch_plan_path: str | Path,
    unscored_predictions_path: str | Path,
    predict_run_metadata_path: str | Path,
) -> tuple[list[dict[str, Any]], dict[str, Any], dict[str, Any]]:
    """Validate all raw artifacts before joining benchmark gold."""

    (
        prediction_manifest,
        cases,
        plan,
        validated,
        run,
        config,
    ) = validate_batched_causal_artifacts(
        prediction_manifest_path=prediction_manifest_path,
        batch_plan_path=batch_plan_path,
        unscored_predictions_path=unscored_predictions_path,
        predict_run_metadata_path=predict_run_metadata_path,
    )
    if (
        dataset.dataset_sha256
        != prediction_manifest["dataset_manifest_sha256"]
        or cohort.dataset_manifest_sha256
        != prediction_manifest["dataset_manifest_sha256"]
        or cohort.cohort_name != prediction_manifest["cohort_name"]
        or cohort.cohort_sha256 != prediction_manifest["cohort_sha256"]
    ):
        raise BatchedCausalWorkflowError(
            "E9 scoring dataset/cohort lineage is invalid"
        )
    if not set(plan.selected_trajectory_ids) <= set(
        cohort.trajectory_ids
    ):
        raise BatchedCausalWorkflowError(
            "E9 predictions are outside the scoring cohort"
        )

    # Gold is first touched below, after plan, request, raw output, semantic
    # reconstruction, file hashes, run aggregates, and ledger all validate.
    by_case = {case.trajectory_id: case for case in cases}
    examples = {
        example.label.trajectory_id: example for example in dataset.examples
    }
    parsed_by_batch: dict[str, dict[str, BatchedAdjudication]] = {}
    by_id = {case.trajectory_id: case for case in cases}
    for spec in plan.batches:
        batch_rows = [
            row for row in validated if row["batch_id"] == spec.batch_id
        ]
        batched_cases = _cases_for_spec(spec, by_id=by_id)
        try:
            adjudications, _case_failures = (
                parse_batched_arbiter_isolated(
                    batch_rows[0]["raw_judge_outputs"][
                        BATCHED_ARBITER_STAGE
                    ],
                    cases=batched_cases,
                )
            )
        except JudgeOutputError:
            adjudications = [None for _case in batched_cases]
        parsed_by_batch[spec.batch_id] = {
            item.case_key: item
            for item in adjudications
            if item is not None
        }

    validated_by_id = {
        str(row["trajectory_id"]): row for row in validated
    }
    scoring_rows = [
        validated_by_id[trajectory_id]
        for trajectory_id in plan.selected_trajectory_ids
    ]
    scored: list[dict[str, Any]] = []
    for row in scoring_rows:
        trajectory_id = str(row["trajectory_id"])
        example = examples.get(trajectory_id)
        if example is None:
            raise BatchedCausalWorkflowError(
                "E9 trajectory has no benchmark scoring example"
            )
        case = by_case[trajectory_id]
        if (
            example.mapping.trajectory_sha256 != case.trajectory_sha256
            or tuple(
                (item.original_step, item.critical_event_id)
                for item in example.mapping.steps
            )
            != case.step_event_mapping
        ):
            raise BatchedCausalWorkflowError(
                "E9 scoring adaptation diverges from the prediction manifest"
            )
        record = _base_record(
            example,
            method=E9_METHOD,
            config=config,
        )
        record.update(
            {
                "status": row["status"],
                "failure_stage": row["failure_stage"],
                "failure_code": row["failure_code"],
                "failure_message": row["failure_message"],
                "root_cause_judgment": row[
                    "root_cause_judgment"
                ],
                "raw_judge_outputs": row["raw_judge_outputs"],
                "stage_attempted": row["stage_attempted"],
                "stage_cache_hits": row["stage_cache_hits"],
                "stage_identities": row["stage_identities"],
                "stage_outcomes": row["stage_outcomes"],
                "stage_provider_telemetry": row[
                    "stage_provider_telemetry"
                ],
                "provider_telemetry": row["provider_telemetry"],
                "latency_seconds": row["latency_seconds"],
                "cache_hit": row["cache_hit"],
                "prompt_version": (
                    BATCHED_ARBITER_PROMPT_PROTOCOL_VERSION
                ),
                "pipeline_version": BATCHED_CAUSAL_PIPELINE_VERSION,
                "experiment": E9_EXPERIMENT,
                "semantic_classifier": E9_SEMANTIC_CLASSIFIER,
                "prior_root": None,
                "preregistration_sha256": row[
                    "preregistration_sha256"
                ],
                "prediction_manifest_sha256": row[
                    "prediction_manifest_sha256"
                ],
                "batch_plan_sha256": row["batch_plan_sha256"],
                "batch_id": row["batch_id"],
                "batch_index": row["batch_index"],
                "case_key": row["case_key"],
                "cache_dir": row["cache_dir"],
                "unscored_prediction_sha256": row[
                    "unscored_prediction_sha256"
                ],
                "evidence_source_id": row["evidence_source_id"],
                "evidence_quote": row["evidence_quote"],
                "scout_candidate_bundle": row[
                    "scout_candidate_bundle"
                ],
                "arbiter_audit": row["arbiter_audit"],
                "decision": row["decision"],
                "judge_step_matches_event_mapping": row[
                    "judge_step_matches_event_mapping"
                ],
            }
        )
        adjudication = parsed_by_batch.get(
            str(row["batch_id"]), {}
        ).get(str(row["case_key"]))
        if adjudication is not None:
            _apply_root(
                record,
                example=example,
                root=adjudication.root,
            )
        scored.append(record)
    metrics = compute_metrics(scored)
    return scored, metrics, run


__all__ = [
    "ARBITER_CANDIDATE_RESERVE_CHARS",
    "E9_BATCH_PLAN_SCHEMA_VERSION",
    "E9_BATCH_PLANNER_VERSION",
    "E9_EVIDENCE_VALIDATION_VERSION",
    "E9_EXPERIMENT",
    "E9_METHOD",
    "E9_PREDICTION_SCHEMA_VERSION",
    "E9_PREDICT_RUN_SCHEMA_VERSION",
    "E9_SCOUT_CACHE_COMPATIBILITY_VERSION",
    "E9_SEMANTIC_CLASSIFIER",
    "MAXIMUM_REQUEST_CHARS",
    "MAX_BATCH_SIZE",
    "BatchPlan",
    "BatchSpec",
    "BatchedCausalWorkflowError",
    "load_batched_causal_batch_plan",
    "predict_batched_causal_cases",
    "score_batched_causal_predictions",
    "validate_batched_causal_artifacts",
    "validate_partial_batched_causal_predictions",
    "write_batched_causal_batch_plan",
]

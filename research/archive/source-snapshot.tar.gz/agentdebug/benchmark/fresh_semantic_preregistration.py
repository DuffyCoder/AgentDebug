"""Write-once preregistration and promotion gates for E8."""

from __future__ import annotations

import hashlib
import json
import os
from collections import Counter
from pathlib import Path
from typing import Any, Mapping, Sequence

from agentdebug.diagnostics.fresh_semantic_evidence import (
    FRESH_EVIDENCE_REPAIR_MAX_ATTEMPTS,
    FRESH_EVIDENCE_REPAIR_PIPELINE_VERSION,
    FRESH_EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION,
    FRESH_EVIDENCE_VALIDATION_VERSION,
)
from agentdebug.diagnostics.fresh_semantic_judge import (
    FRESH_SEMANTIC_PIPELINE_VERSION,
    FRESH_SEMANTIC_PROMPT_PROTOCOL_VERSION,
)
from agentdebug.diagnostics.judge_view import JUDGE_VIEW_VERSION

from .fresh_semantic_workflow import (
    E8_EXPERIMENT,
    E8_LOGICAL_COMPLETION_LEDGER_SCHEMA_VERSION,
    E8_METHOD,
    E8_PREDICTION_SCHEMA_VERSION,
    E8_PREDICT_RUN_SCHEMA_VERSION,
    E8_STAGE,
    FreshSemanticWorkflowError,
    fresh_semantic_judge_request_sha256s,
    initialize_fresh_semantic_completion_ledger,
    load_fresh_semantic_completion_ledger,
    score_fresh_semantic_predictions,
    validate_fresh_semantic_artifacts,
    validate_fresh_semantic_judge_cache,
    validate_partial_fresh_semantic_predictions,
)
from .cohort import load_cohort_manifest
from .dataset import load_agent_error_bench
from .metrics import SUCCESS_STATUSES, compute_metrics
from .prediction_manifest import (
    build_prediction_case,
    load_prediction_manifest,
    stable_sha256,
)
from .runner import TRANSPORT_POLICY_VERSION, BenchmarkRunConfig
from .stage_cache import (
    RAW_RESPONSE_SIDECAR_SCHEMA_VERSION,
    RAW_STAGE_SCHEMA_VERSION,
    STAGE_CACHE_SCHEMA_VERSION,
)


E8_PREREGISTRATION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e8-preregistration.v4"
)
E8_PROMOTION_SCHEMA_VERSION = "agentdebug.benchmark.e8-promotion.v4"
E8_AUTHORIZED_CUMULATIVE_CEILING = 380
E8_CUMULATIVE_LOGICAL_COMPLETIONS_BEFORE = 312
E8_AUTHORIZATION_CHAIN_RELATIVE_PATH = (
    "output/agenterrorbench-gpt-4.1-e8-v3-authorization-chain"
)
E8_AUTHORIZATION_CLAIM_SCHEMA_VERSION = (
    "agentdebug.benchmark.e8-authorization-claim.v1"
)
E8_DRY5_IDS_MANIFEST_ORDER = (
    "Qwen3-8B_024_id_24___chat_b013_t00_e01-5b8f974f",
    "Llama3.3-70B-Turbo_015_memory_b001_t00_e06-71f77595",
    "GPT-4o_011_memory_b001_t00_e03-21a3a421",
    "GPT-4o_008_chat_b000_t00_e07-d50ae81f",
    "GPT-4o_004_chat_b000_t00_e03-21a3a421",
)
E8_EVALUATION_PROFILES: dict[str, dict[str, Any]] = {
    "dry5": {
        "cohort_name": "tuning-v1",
        "cohort_sha256": (
            "e21b1034470577688b68aad2a0e006facc658fed28bdb986f"
            "ed039bc0347bd6f"
        ),
        "cohort_count": 30,
        "selection_count": 5,
        "full_cohort": False,
        "heldout": False,
        "selection_ids": E8_DRY5_IDS_MANIFEST_ORDER,
    },
    "full30": {
        "cohort_name": "tuning-v1",
        "cohort_sha256": (
            "e21b1034470577688b68aad2a0e006facc658fed28bdb986f"
            "ed039bc0347bd6f"
        ),
        "cohort_count": 30,
        "selection_count": 30,
        "full_cohort": True,
        "heldout": False,
        "selection_ids": None,
    },
    "smoke30": {
        "cohort_name": "smoke-v1",
        "cohort_sha256": (
            "6dfbc06b27a64f80719787b0cd56736a26ae97a98ba7714d"
            "af6a571808d11fe0"
        ),
        "cohort_count": 30,
        "selection_count": 30,
        "full_cohort": True,
        "heldout": True,
        "selection_ids": None,
    },
}
_SUPPORTED_GATE_FIELDS = {
    "all_correct_minimum",
    "evidence_valid_minimum",
    "failed_prediction_maximum",
    "fresh_llm_raw_root_required",
    "gold_isolation_required",
    "hard_failure_maximum",
    "heldout_one_shot_required",
    "minimum_step_exact_by_groups",
    "raw_chain_reconstruction_required",
    "required_step_module_exact_trajectory_ids",
    "semantic_mutation_maximum",
    "step_exact_minimum_correct",
    "step_module_exact_minimum_correct",
    "successful_prediction_minimum",
    "telemetry_logical_equals_judge_plus_repair",
    "trajectory_denominator",
}
_CODE_PATHS = (
    "agentdebug/__init__.py",
    # Current-checkout import closure after public API consolidation. Previously
    # recorded bundles/hashes are not rewritten by extending this source list.
    "agentdebug/method.py",
    "agentdebug/benchmark/agent_judge_shards.py",
    "agentdebug/diagnostics/agent_judge_gaia_v3_83_clean_v3p20_model_only_gpt55_medium.py",
    "agentdebug/diagnostics/agent_judge_luna_gaia_v1.py",
    "agentdebug/diagnostics/agent_judge_luna_gaia_v2.py",
    "agentdebug/diagnostics/agent_judge_luna_gaia_v2_1.py",
    "agentdebug/diagnostics/agent_judge_luna_gaia_v3.py",
    "agentdebug/diagnostics/agent_judge_luna_gaia_v3_1.py",
    "agentdebug/diagnostics/agent_judge_luna_gaia_v3_13_conservative_challenger.py",
    "agentdebug/diagnostics/agent_judge_luna_gaia_v3_14_earliest_causal_challenger.py",
    "agentdebug/diagnostics/agent_judge_luna_gaia_v3_20_packet_state_closure.py",
    "agentdebug/diagnostics/agent_judge_luna_gaia_v3_4.py",
    "agentdebug/diagnostics/agent_judge_luna_v3.py",
    "agentdebug/diagnostics/agent_judge_v2_4.py",
    "agentdebug/diagnostics/agent_judge.py",
    "agentdebug/diagnostics/agent_judge_v2.py",
    "agentdebug/diagnostics/agent_judge_v2_1.py",
    "agentdebug/diagnostics/agent_judge_v2_2.py",
    "agentdebug/benchmark/__init__.py",
    "agentdebug/diagnostics/__init__.py",
    "agentdebug/diagnostics/analyzer.py",
    "agentdebug/diagnostics/evidence_repair.py",
    "agentdebug/diagnostics/fresh_semantic_evidence.py",
    "agentdebug/diagnostics/fresh_semantic_judge.py",
    "agentdebug/diagnostics/global_critic.py",
    "agentdebug/diagnostics/handoff.py",
    "agentdebug/diagnostics/judge_view.py",
    "agentdebug/diagnostics/models.py",
    "agentdebug/diagnostics/parsing.py",
    "agentdebug/diagnostics/prompts.py",
    "agentdebug/diagnostics/providers.py",
    "agentdebug/diagnostics/redaction.py",
    "agentdebug/diagnostics/taxonomy.py",
    "agentdebug/diagnostics/validator.py",
    "agentdebug/benchmark/cohort.py",
    "agentdebug/benchmark/adapter.py",
    "agentdebug/benchmark/dataset.py",
    "agentdebug/benchmark/fresh_semantic_cli.py",
    "agentdebug/benchmark/fresh_semantic_preregistration.py",
    "agentdebug/benchmark/fresh_semantic_workflow.py",
    "agentdebug/benchmark/metrics.py",
    "agentdebug/benchmark/models.py",
    "agentdebug/benchmark/prediction_manifest.py",
    "agentdebug/benchmark/prompts.py",
    "agentdebug/benchmark/reporting.py",
    "agentdebug/benchmark/runner.py",
    "agentdebug/benchmark/stage_cache.py",
    "agentdebug/trace/__init__.py",
    "agentdebug/trace/_common.py",
    "agentdebug/trace/artifacts.py",
    "agentdebug/trace/claw_eval.py",
    "agentdebug/trace/integrity.py",
    "agentdebug/trace/io.py",
    "agentdebug/trace/models.py",
    "agentdebug/trace/reconcile.py",
    "agentdebug/trace/runtime_v1.py",
    "agentdebug/trace/session_v3.py",
    "docs/experiments/e8-fresh-semantic-judge.md",
    "tests/test_fresh_semantic_workflow.py",
)


class FreshSemanticPreregistrationError(ValueError):
    """An E8 run differs from its frozen experiment identity."""


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _atomic_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def _exclusive_json(path: Path, value: Mapping[str, Any]) -> None:
    """Create one phase claim exactly once across concurrent preregistrations."""

    path.parent.mkdir(parents=True, exist_ok=True)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    try:
        descriptor = os.open(path, flags, 0o600)
    except FileExistsError as error:
        raise FreshSemanticPreregistrationError(
            "E8 authorization phase was already claimed"
        ) from error
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    directory_fd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def _read(path: Path, *, location: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise FreshSemanticPreregistrationError(
            f"{location} is missing or corrupt"
        ) from error
    if not isinstance(value, dict):
        raise FreshSemanticPreregistrationError(
            f"{location} must be an object"
        )
    return value


def _directory_state(
    root: Path,
    *,
    excluded_paths: Sequence[Path] = (),
) -> dict[str, Any]:
    """Hash a directory state byte-for-byte without parsing its content."""

    resolved_root = root.expanduser().resolve()
    excluded = {path.expanduser().resolve() for path in excluded_paths}
    files: dict[str, str] = {}
    if resolved_root.is_dir():
        for path in sorted(
            (item for item in resolved_root.rglob("*") if item.is_file()),
            key=lambda item: str(item),
        ):
            resolved = path.resolve()
            if resolved in excluded:
                continue
            files[str(resolved.relative_to(resolved_root))] = _file_sha256(
                resolved
            )
    return {
        "file_count": len(files),
        "files_sha256": stable_sha256(files),
    }


def _ledger_lock_path(path: Path) -> Path:
    return path.with_suffix(f"{path.suffix}.lock")


def _profile_contract(profile: str) -> dict[str, Any]:
    contract = E8_EVALUATION_PROFILES.get(profile)
    if not isinstance(contract, Mapping):
        raise FreshSemanticPreregistrationError(
            "E8 evaluation profile is unsupported"
        )
    required = {
        "cohort_name",
        "cohort_sha256",
        "cohort_count",
        "selection_count",
        "full_cohort",
        "heldout",
        "selection_ids",
    }
    if set(contract) != required:
        raise FreshSemanticPreregistrationError(
            "E8 evaluation profile contract is invalid"
        )
    return dict(contract)


def frozen_fresh_semantic_promotion_gate(
    profile: str,
    *,
    selected_trajectory_ids: Sequence[str],
) -> dict[str, Any]:
    """Return the only promotion gate authorized for a formal E8 phase."""

    selected = [str(value) for value in selected_trajectory_ids]
    if profile == "dry5":
        if tuple(selected) != E8_DRY5_IDS_MANIFEST_ORDER:
            raise FreshSemanticPreregistrationError(
                "dry5 gate requires the frozen five tuning IDs"
            )
        return {
            "trajectory_denominator": 5,
            "successful_prediction_minimum": 5,
            "step_exact_minimum_correct": 3,
            "step_module_exact_minimum_correct": 3,
            "all_correct_minimum": 2,
            "hard_failure_maximum": 0,
            "evidence_valid_minimum": 5,
            "semantic_mutation_maximum": 0,
            "fresh_llm_raw_root_required": True,
            "raw_chain_reconstruction_required": True,
            "gold_isolation_required": True,
            "telemetry_logical_equals_judge_plus_repair": True,
            "heldout_one_shot_required": False,
            "required_step_module_exact_trajectory_ids": [
                "Llama3.3-70B-Turbo_015_memory_b001_t00_e06-71f77595"
            ],
            "minimum_step_exact_by_groups": [
                {
                    "minimum": 1,
                    "trajectory_ids": [
                        "GPT-4o_004_chat_b000_t00_e03-21a3a421",
                        (
                            "Qwen3-8B_024_id_24___chat_b013_t00_e01-"
                            "5b8f974f"
                        ),
                    ],
                },
                {
                    "minimum": 1,
                    "trajectory_ids": [
                        "GPT-4o_008_chat_b000_t00_e07-d50ae81f",
                        "GPT-4o_011_memory_b001_t00_e03-21a3a421",
                    ],
                },
            ],
        }
    if profile not in {"full30", "smoke30"} or len(selected) != 30:
        raise FreshSemanticPreregistrationError(
            "formal E8 full/smoke gate requires exactly 30 trajectories"
        )
    return {
        "trajectory_denominator": 30,
        "successful_prediction_minimum": 29,
        "step_exact_minimum_correct": 12,
        "step_module_exact_minimum_correct": 3,
        "all_correct_minimum": 3,
        "failed_prediction_maximum": 1,
        "evidence_valid_minimum": 29,
        "semantic_mutation_maximum": 0,
        "fresh_llm_raw_root_required": True,
        "raw_chain_reconstruction_required": True,
        "gold_isolation_required": True,
        "telemetry_logical_equals_judge_plus_repair": True,
        "heldout_one_shot_required": profile == "smoke30",
    }


def _validate_formal_provider_config(
    *,
    profile: str,
    config: BenchmarkRunConfig,
) -> None:
    if profile not in {"dry5", "full30", "smoke30"}:
        return
    expected = {
        "model": "gpt-4.1",
        "temperature": 0,
        "provider": "openai-compatible",
        "endpoint": "https://api.sophnet.com/v1/chat/completions",
        "timeout": 600,
        "max_output_tokens": 8192,
        "max_retries": 5,
        "retry_backoff": 2,
        "cohort_sha256": _profile_contract(profile)["cohort_sha256"],
        "api_key_env": "API_KEY",
    }
    if config.public_dict() != expected:
        raise FreshSemanticPreregistrationError(
            "formal E8 provider configuration is not the frozen GPT-4.1 "
            "evaluation identity"
        )


def _validate_evaluation_profile_binding(
    *,
    profile: str,
    cohort_name: Any,
    cohort_sha256: Any,
    cohort_trajectory_ids: Sequence[str],
    manifest_trajectory_ids: Sequence[str],
    selected_trajectory_ids: Sequence[str],
    gate: Mapping[str, Any],
) -> dict[str, Any]:
    contract = _profile_contract(profile)
    cohort_ids = [str(value) for value in cohort_trajectory_ids]
    manifest_ids = [str(value) for value in manifest_trajectory_ids]
    selected = [str(value) for value in selected_trajectory_ids]
    heldout_flag = gate.get("heldout_one_shot_required")
    frozen_gate = (
        frozen_fresh_semantic_promotion_gate(
            profile,
            selected_trajectory_ids=selected,
        )
        if profile in {"dry5", "full30", "smoke30"}
        else None
    )
    if (
        cohort_name != contract["cohort_name"]
        or cohort_sha256 != contract["cohort_sha256"]
        or len(cohort_ids) != contract["cohort_count"]
        or manifest_ids != cohort_ids
        or len(manifest_ids) != contract["cohort_count"]
        or len(selected) != contract["selection_count"]
        or not isinstance(heldout_flag, bool)
        or heldout_flag is not contract["heldout"]
        or (frozen_gate is not None and dict(gate) != frozen_gate)
    ):
        raise FreshSemanticPreregistrationError(
            "E8 evaluation profile/cohort/gate binding is invalid"
        )
    if contract["full_cohort"]:
        if selected != manifest_ids:
            raise FreshSemanticPreregistrationError(
                "E8 full evaluation profile requires the complete cohort"
            )
    elif selected != list(contract["selection_ids"] or ()):
        raise FreshSemanticPreregistrationError(
            "E8 dry evaluation profile requires the frozen five cases"
        )
    return contract


def _validate_prediction_manifest_against_dataset(
    *,
    prediction_manifest: Mapping[str, Any],
    dataset: Any,
    cohort: Any,
) -> None:
    """Rebuild every gold-free case from the frozen released trajectory."""

    selected_examples = cohort.examples_from(dataset)
    expected_entries = [
        build_prediction_case(example.trace, example.mapping)
        for example in selected_examples
    ]
    expected_selection_identity = {
        "selection_name": cohort.cohort_name,
        "cohort_sha256": cohort.cohort_sha256,
        "trajectory_ids": list(cohort.trajectory_ids),
        "execution_order": "cohort-manifest",
        "expected_count": len(cohort.trajectory_ids),
    }
    if (
        prediction_manifest.get("dataset_manifest_sha256")
        != dataset.dataset_sha256
        or prediction_manifest.get("cohort_name") != cohort.cohort_name
        or prediction_manifest.get("cohort_sha256") != cohort.cohort_sha256
        or prediction_manifest.get("entry_count") != len(expected_entries)
        or prediction_manifest.get("selection_identity")
        != expected_selection_identity
        or prediction_manifest.get("entries") != expected_entries
    ):
        raise FreshSemanticPreregistrationError(
            "E8 PredictionManifest is not the exact gold-free projection of "
            "the frozen dataset/cohort"
        )


def _reservations_exactly_match_attempted_stages(
    rows: Sequence[Mapping[str, Any]],
    entries: Sequence[Mapping[str, Any]],
) -> bool:
    attempted = Counter(
        (
            stage,
            row["stage_identities"][stage]["request_sha256"],
        )
        for row in rows
        for stage in row["stage_attempted"]
        if row["stage_attempted"][stage]
    )
    reserved = Counter(
        (entry["stage"], entry["request_sha256"]) for entry in entries
    )
    return reserved == attempted


def _all_attempted_stages_are_cache_misses(
    rows: Sequence[Mapping[str, Any]],
) -> bool:
    return all(
        not row["stage_cache_hits"][stage]
        for row in rows
        for stage in row["stage_attempted"]
        if row["stage_attempted"][stage]
    )


def _adopted_cache_hits_are_authorized(
    rows: Sequence[Mapping[str, Any]],
    entries: Sequence[Mapping[str, Any]],
    *,
    predecessor_stage_requests: Sequence[Mapping[str, str]] = (),
) -> bool:
    predecessor = {
        (
            item["trajectory_id"],
            item["stage"],
            item["request_sha256"],
        )
        for item in predecessor_stage_requests
    }
    reserved = {
        (entry["stage"], entry["request_sha256"]) for entry in entries
    }
    adopted = {
        (
            row["trajectory_id"],
            stage,
            row["stage_identities"][stage]["request_sha256"],
        )
        for row in rows
        for stage in row["stage_attempted"]
        if row["stage_attempted"][stage]
        and row["stage_cache_hits"][stage]
    }
    return predecessor <= adopted and all(
        item in predecessor or (item[1], item[2]) in reserved
        for item in adopted
    )


def _validate_phase_budget(
    *,
    profile: str,
    cumulative_before: Any,
    maximum_new: Any,
    hard_cumulative_stop: Any,
    authorized_cumulative_ceiling: Any,
    predecessor_cumulative_after: int | None,
) -> None:
    if (
        isinstance(cumulative_before, bool)
        or not isinstance(cumulative_before, int)
        or cumulative_before < 0
        or isinstance(maximum_new, bool)
        or not isinstance(maximum_new, int)
        or maximum_new < 1
        or hard_cumulative_stop != cumulative_before + maximum_new
        or authorized_cumulative_ceiling
        != E8_AUTHORIZED_CUMULATIVE_CEILING
        or hard_cumulative_stop > E8_AUTHORIZED_CUMULATIVE_CEILING
    ):
        raise FreshSemanticPreregistrationError(
            "E8 phase budget arithmetic is invalid"
        )
    if profile == "dry5":
        valid = (
            cumulative_before
            == E8_CUMULATIVE_LOGICAL_COMPLETIONS_BEFORE
            and 5 <= maximum_new <= 10
        )
    elif profile == "full30":
        valid = (
            predecessor_cumulative_after is not None
            and cumulative_before == predecessor_cumulative_after
            and maximum_new >= 25
            and hard_cumulative_stop <= 350
        )
    elif profile == "smoke30":
        valid = (
            predecessor_cumulative_after is not None
            and cumulative_before == predecessor_cumulative_after
            and maximum_new
            == E8_AUTHORIZED_CUMULATIVE_CEILING - cumulative_before
            and maximum_new >= 30
        )
    else:
        valid = True
    if not valid:
        raise FreshSemanticPreregistrationError(
            "E8 profile-specific phase budget is invalid"
        )


def _validate_frozen_phase_namespace(
    *,
    profile: str,
    run_output_initial_state: Any,
    cache_initial_state: Any,
    predecessor: Mapping[str, Any] | None,
) -> None:
    if not isinstance(run_output_initial_state, Mapping) or not isinstance(
        cache_initial_state,
        Mapping,
    ):
        raise FreshSemanticPreregistrationError(
            "E8 frozen namespace state is invalid"
        )
    if (
        profile in {"dry5", "full30", "smoke30"}
        and run_output_initial_state.get("file_count") != 0
    ):
        raise FreshSemanticPreregistrationError(
            "formal E8 output namespace was not fresh"
        )
    if (
        profile in {"dry5", "smoke30"}
        and cache_initial_state.get("file_count") != 0
    ):
        raise FreshSemanticPreregistrationError(
            "E8 dry/smoke cache namespace was not fresh"
        )
    if profile == "full30" and (
        not isinstance(predecessor, Mapping)
        or cache_initial_state != predecessor.get("cache_final_state")
    ):
        raise FreshSemanticPreregistrationError(
            "E8 full cache is not the exact frozen dry cache snapshot"
        )


def _current_code_bundle() -> dict[str, str]:
    repository_root = Path(__file__).resolve().parents[2]
    bundle: dict[str, str] = {}
    for relative in _CODE_PATHS:
        path = repository_root / relative
        if not path.is_file():
            raise FreshSemanticPreregistrationError(
                f"E8 code bundle file is missing: {relative}"
            )
        bundle[relative] = _file_sha256(path)
    return bundle


def _authorization_directory(
    *,
    profile: str,
    requested: str | Path | None,
    run_output_dir: Path,
) -> Path:
    repository_root = Path(__file__).resolve().parents[2]
    formal = (
        repository_root / E8_AUTHORIZATION_CHAIN_RELATIVE_PATH
    ).resolve()
    if profile in {"dry5", "full30", "smoke30"}:
        resolved = (
            formal
            if requested is None
            else Path(requested).expanduser().resolve()
        )
        if resolved != formal:
            raise FreshSemanticPreregistrationError(
                "formal E8 runs require the fixed authorization chain"
            )
        return resolved
    return (
        (run_output_dir.parent / ".e8-test-authorization-chain").resolve()
        if requested is None
        else Path(requested).expanduser().resolve()
    )


def _phase_identity(profile: str) -> tuple[int, str | None]:
    phases = {
        "dry5": (1, None),
        "full30": (2, "dry5"),
        "smoke30": (3, "full30"),
    }
    return phases.get(profile, (1, None))


def _claim_path(directory: Path, *, profile: str) -> Path:
    ordinal, _ = _phase_identity(profile)
    return directory / f"{ordinal:02d}-{profile}.json"


def _validated_hashed_document(
    path: Path,
    *,
    location: str,
    hash_field: str,
) -> dict[str, Any]:
    document = _read(path, location=location)
    body = dict(document)
    claimed = body.pop(hash_field, None)
    if claimed != stable_sha256(body):
        raise FreshSemanticPreregistrationError(
            f"{location} self-hash is invalid"
        )
    return document


def _read_authorization_claim(
    path: Path,
    *,
    expected_profile: str,
) -> dict[str, Any]:
    claim = _validated_hashed_document(
        path,
        location="E8 authorization claim",
        hash_field="claim_sha256",
    )
    required = {
        "schema_version",
        "ordinal",
        "profile",
        "preregistration_path",
        "preregistration_sha256",
        "cumulative_before",
        "maximum_new",
        "hard_cumulative_stop",
        "predecessor_claim_sha256",
        "predecessor_promotion_sha256",
        "claim_sha256",
    }
    ordinal, _ = _phase_identity(expected_profile)
    if (
        set(claim) != required
        or claim.get("schema_version")
        != E8_AUTHORIZATION_CLAIM_SCHEMA_VERSION
        or claim.get("profile") != expected_profile
        or claim.get("ordinal") != ordinal
        or claim.get("hard_cumulative_stop")
        != claim.get("cumulative_before") + claim.get("maximum_new")
    ):
        raise FreshSemanticPreregistrationError(
            "E8 authorization claim identity is invalid"
        )
    return claim


def _provider_identity_without_cohort(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, Mapping):
        return None
    identity = dict(value)
    identity.pop("cohort_sha256", None)
    return identity


def _resolve_predecessor_binding(
    *,
    profile: str,
    authorization_dir: Path,
    cumulative_before: int,
    code_bundle: Mapping[str, str],
    config: BenchmarkRunConfig,
    cache_dir: Path,
    current_prediction_manifest_path: Path,
    current_prediction_manifest: Mapping[str, Any],
    require_predecessor_cache_state: bool = True,
    revalidate_predecessor_promotion: bool = True,
) -> tuple[dict[str, Any] | None, str | None]:
    _, predecessor_profile = _phase_identity(profile)
    if predecessor_profile is None:
        return None, None
    predecessor_claim_path = _claim_path(
        authorization_dir,
        profile=predecessor_profile,
    )
    predecessor_claim = _read_authorization_claim(
        predecessor_claim_path,
        expected_profile=predecessor_profile,
    )
    preregistration_path = Path(
        str(predecessor_claim["preregistration_path"])
    ).expanduser().resolve()
    preregistration = _validated_hashed_document(
        preregistration_path,
        location="E8 predecessor preregistration",
        hash_field="preregistration_sha256",
    )
    predecessor_evaluation = preregistration.get("evaluation")
    predecessor_execution = preregistration.get("execution")
    predecessor_budget = preregistration.get("logical_completion_budget")
    predecessor_authorization = preregistration.get("authorization_chain")
    if not all(
        isinstance(value, Mapping)
        for value in (
            predecessor_evaluation,
            predecessor_execution,
            predecessor_budget,
            predecessor_authorization,
        )
    ):
        raise FreshSemanticPreregistrationError(
            "E8 predecessor preregistration envelope is invalid"
        )
    validated_predecessor_claim = _validate_authorization_claim(
        preregistration
    )
    promotion_path = (
        Path(str(predecessor_execution["run_output_dir"]))
        .expanduser()
        .resolve()
        / "promotion.json"
    )
    promotion = _validated_hashed_document(
        promotion_path,
        location="E8 predecessor promotion",
        hash_field="promotion_sha256",
    )
    checks = promotion.get("checks")
    predict_run_path = Path(
        str(promotion.get("predict_run_path"))
    ).expanduser().resolve()
    predict_run = _validated_hashed_document(
        predict_run_path,
        location="E8 predecessor predict run",
        hash_field="predict_run_sha256",
    )
    try:
        ledger = load_fresh_semantic_completion_ledger(
            str(predecessor_execution["logical_completion_ledger_path"]),
            preregistration_sha256=preregistration[
                "preregistration_sha256"
            ],
            cumulative_before=predecessor_budget["cumulative_before"],
            maximum_new=predecessor_budget["maximum_new"],
            authorized_cumulative_ceiling=predecessor_budget[
                "authorized_cumulative_ceiling"
            ],
        )
    except FreshSemanticWorkflowError as error:
        raise FreshSemanticPreregistrationError(str(error)) from error
    used = len(ledger["entries"])
    expected_cumulative = predecessor_budget["cumulative_before"] + used
    predecessor_cache_path = Path(
        str(predecessor_execution["cache_dir"])
    ).expanduser().resolve()
    predecessor_output_dir = Path(
        str(predecessor_execution["run_output_dir"])
    ).expanduser().resolve()
    predecessor_predictions_path = (
        predecessor_output_dir / "predictions.jsonl"
    )
    predecessor_metrics_path = predecessor_output_dir / "metrics.json"
    predecessor_manifest_record = preregistration.get(
        "prediction_manifest"
    )
    predecessor_selection = preregistration.get("selection")
    if not isinstance(predecessor_manifest_record, Mapping) or not isinstance(
        predecessor_selection,
        Mapping,
    ):
        raise FreshSemanticPreregistrationError(
            "E8 predecessor input/selection envelope is invalid"
        )
    try:
        (
            predecessor_manifest,
            predecessor_cases,
            predecessor_rows,
            validated_predict_run,
            validated_predecessor_config,
        ) = validate_fresh_semantic_artifacts(
            prediction_manifest_path=str(
                predecessor_manifest_record["path"]
            ),
            unscored_predictions_path=str(
                predecessor_execution["unscored_predictions_path"]
            ),
            predict_run_metadata_path=predict_run_path,
        )
    except FreshSemanticWorkflowError as error:
        raise FreshSemanticPreregistrationError(str(error)) from error
    if (
        validated_predict_run != predict_run
        or validated_predecessor_config.public_dict()
        != preregistration.get("provider_config")
        or predecessor_manifest.get("prediction_manifest_sha256")
        != predecessor_manifest_record.get("content_sha256")
        or _file_sha256(
            Path(str(predecessor_manifest_record["path"])).expanduser().resolve()
        )
        != predecessor_manifest_record.get("file_sha256")
        or [row["trajectory_id"] for row in predecessor_rows]
        != predecessor_selection.get("trajectory_ids")
    ):
        raise FreshSemanticPreregistrationError(
            "E8 predecessor gold-free raw chain is invalid"
        )
    revalidated_promotion = (
        verify_fresh_semantic_promotion(
            preregistration_path=preregistration_path,
            predictions_path=predecessor_predictions_path,
            metrics_path=predecessor_metrics_path,
            predict_run_path=predict_run_path,
            output_path=promotion_path,
            persist=False,
            validate_cache_state=require_predecessor_cache_state,
        )
        if revalidate_predecessor_promotion
        else promotion
    )
    if (
        predecessor_claim.get("preregistration_sha256")
        != preregistration.get("preregistration_sha256")
        or validated_predecessor_claim != predecessor_claim
        or predecessor_authorization.get("claim_path")
        != str(predecessor_claim_path)
        or predecessor_authorization.get("directory")
        != str(authorization_dir)
        or predecessor_evaluation.get("profile") != predecessor_profile
        or preregistration.get("code_bundle") != dict(code_bundle)
        or preregistration.get("code_bundle_sha256")
        != stable_sha256(dict(code_bundle))
        or _provider_identity_without_cohort(
            preregistration.get("provider_config")
        )
        != _provider_identity_without_cohort(config.public_dict())
        or promotion.get("schema_version") != E8_PROMOTION_SCHEMA_VERSION
        or promotion.get("accepted") is not True
        or not isinstance(checks, Mapping)
        or not checks
        or not all(value is True for value in checks.values())
        or promotion.get("preregistration_sha256")
        != preregistration.get("preregistration_sha256")
        or promotion.get("preregistration_path") != str(preregistration_path)
        or promotion.get("predictions_path")
        != str(predecessor_predictions_path)
        or promotion.get("metrics_path") != str(predecessor_metrics_path)
        or (
            revalidate_predecessor_promotion
            and (
                promotion.get("predictions_file_sha256")
                != _file_sha256(predecessor_predictions_path)
                or promotion.get("metrics_file_sha256")
                != _file_sha256(predecessor_metrics_path)
            )
        )
        or promotion.get("predict_run_path") != str(predict_run_path)
        or promotion.get("predict_run_file_sha256")
        != _file_sha256(predict_run_path)
        or predict_run.get("preregistration_sha256")
        != preregistration.get("preregistration_sha256")
        or predict_run.get("logical_completion_budget_used") != used
        or predict_run.get("logical_completion_ledger_sha256")
        != ledger["ledger_sha256"]
        or promotion.get("summary", {}).get(
            "logical_completion_budget_used"
        )
        != used
        or cumulative_before != expected_cumulative
        or revalidated_promotion != promotion
        or (
            require_predecessor_cache_state
            and promotion.get("cache_final_state")
            != _directory_state(predecessor_cache_path)
        )
    ):
        raise FreshSemanticPreregistrationError(
            "E8 predecessor promotion/ledger/code lineage is invalid"
        )
    cached_requests: tuple[str, ...] = ()
    cached_stage_requests: list[dict[str, str]] = []
    if profile == "full30":
        predecessor_manifest = preregistration.get("prediction_manifest")
        if (
            not isinstance(predecessor_manifest, Mapping)
            or predecessor_manifest.get("path")
            != str(current_prediction_manifest_path)
            or predecessor_manifest.get("file_sha256")
            != _file_sha256(current_prediction_manifest_path)
            or predecessor_manifest.get("content_sha256")
            != current_prediction_manifest.get(
                "prediction_manifest_sha256"
            )
        ):
            raise FreshSemanticPreregistrationError(
                "E8 full tuning must reuse the exact dry PredictionManifest"
            )
        if predecessor_execution.get("cache_dir") != str(cache_dir):
            raise FreshSemanticPreregistrationError(
                "E8 full tuning must reuse the frozen dry cache"
            )
        try:
            cached_requests = validate_fresh_semantic_judge_cache(
                prediction_manifest_path=str(
                    preregistration["prediction_manifest"]["path"]
                ),
                unscored_predictions_path=str(
                    predecessor_execution["unscored_predictions_path"]
                ),
                predict_run_metadata_path=predict_run_path,
                cache_dir=cache_dir,
                selected_trajectory_ids=preregistration["selection"][
                    "trajectory_ids"
                ],
            )
        except FreshSemanticWorkflowError as error:
            raise FreshSemanticPreregistrationError(str(error)) from error
        if len(cached_requests) != 5:
            raise FreshSemanticPreregistrationError(
                "E8 full tuning lacks five frozen dry judge caches"
            )
        current_requests = fresh_semantic_judge_request_sha256s(
            prediction_manifest_path=current_prediction_manifest_path,
            config=config,
            selected_trajectory_ids=preregistration["selection"][
                "trajectory_ids"
            ],
        )
        if current_requests != cached_requests:
            raise FreshSemanticPreregistrationError(
                "E8 current full requests diverge from frozen dry caches"
            )
        cached_stage_requests = [
            {
                "trajectory_id": row["trajectory_id"],
                "stage": stage,
                "request_sha256": row["stage_identities"][stage][
                    "request_sha256"
                ],
            }
            for row in predecessor_rows
            for stage in row["stage_attempted"]
            if row["stage_attempted"][stage]
        ]
    binding = {
        "profile": predecessor_profile,
        "claim_path": str(predecessor_claim_path),
        "claim_sha256": predecessor_claim["claim_sha256"],
        "preregistration_path": str(preregistration_path),
        "preregistration_sha256": preregistration[
            "preregistration_sha256"
        ],
        "promotion_path": str(promotion_path),
        "promotion_file_sha256": _file_sha256(promotion_path),
        "promotion_sha256": promotion["promotion_sha256"],
        "predict_run_path": str(predict_run_path),
        "predict_run_file_sha256": _file_sha256(predict_run_path),
        "logical_completion_ledger_path": str(
            predecessor_execution["logical_completion_ledger_path"]
        ),
        "logical_completion_ledger_sha256": ledger["ledger_sha256"],
        "logical_completion_budget_used": used,
        "cumulative_after": expected_cumulative,
        "cache_final_state": promotion.get("cache_final_state"),
        "cached_judge_request_sha256": list(cached_requests),
        "cached_judge_trajectory_ids": list(
            preregistration["selection"]["trajectory_ids"]
        )
        if profile == "full30"
        else [],
        "cached_stage_requests": cached_stage_requests,
        "prediction_manifest_path": str(
            preregistration["prediction_manifest"]["path"]
        ),
        "prediction_manifest_file_sha256": preregistration[
            "prediction_manifest"
        ]["file_sha256"],
        "prediction_manifest_sha256": preregistration[
            "prediction_manifest"
        ]["content_sha256"],
    }
    return binding, predecessor_claim["claim_sha256"]


def _authorization_claim_for_preregistration(
    preregistration: Mapping[str, Any],
) -> dict[str, Any]:
    authorization = preregistration["authorization_chain"]
    predecessor = preregistration.get("predecessor")
    body: dict[str, Any] = {
        "schema_version": E8_AUTHORIZATION_CLAIM_SCHEMA_VERSION,
        "ordinal": authorization["ordinal"],
        "profile": preregistration["evaluation"]["profile"],
        "preregistration_path": preregistration["preregistration_path"],
        "preregistration_sha256": preregistration[
            "preregistration_sha256"
        ],
        "cumulative_before": preregistration[
            "logical_completion_budget"
        ]["cumulative_before"],
        "maximum_new": preregistration["logical_completion_budget"][
            "maximum_new"
        ],
        "hard_cumulative_stop": preregistration[
            "logical_completion_budget"
        ]["hard_cumulative_stop"],
        "predecessor_claim_sha256": authorization[
            "predecessor_claim_sha256"
        ],
        "predecessor_promotion_sha256": (
            None if predecessor is None else predecessor["promotion_sha256"]
        ),
    }
    body["claim_sha256"] = stable_sha256(body)
    return body


def _validate_authorization_claim(
    preregistration: Mapping[str, Any],
) -> dict[str, Any]:
    authorization = preregistration.get("authorization_chain")
    if not isinstance(authorization, Mapping):
        raise FreshSemanticPreregistrationError(
            "E8 authorization-chain binding is missing"
        )
    path = Path(str(authorization.get("claim_path"))).expanduser().resolve()
    claim = _read_authorization_claim(
        path,
        expected_profile=str(preregistration["evaluation"]["profile"]),
    )
    expected = _authorization_claim_for_preregistration(preregistration)
    if claim != expected:
        raise FreshSemanticPreregistrationError(
            "E8 authorization claim diverges from preregistration"
        )
    return claim


def write_fresh_semantic_preregistration(
    *,
    experiment_name: str,
    evaluation_profile: str,
    dataset_path: str | Path,
    cohort_manifest_path: str | Path,
    prediction_manifest_path: str | Path,
    output_path: str | Path,
    run_output_dir: str | Path,
    cache_dir: str | Path,
    config: BenchmarkRunConfig,
    selected_trajectory_ids: Sequence[str],
    selection_rule: str,
    hypothesis: str,
    promotion_gate: Mapping[str, Any],
    cumulative_logical_completions_before: int,
    maximum_new_logical_completions: int,
    authorization_chain_dir: str | Path | None = None,
) -> dict[str, Any]:
    """Freeze E8 code, prompt, inputs, paths, gate, and paid-call ceiling."""

    for name, value in (
        ("experiment_name", experiment_name),
        ("selection_rule", selection_rule),
        ("hypothesis", hypothesis),
    ):
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"{name} must be non-empty text")
    selected = [str(value) for value in selected_trajectory_ids]
    if not selected or len(set(selected)) != len(selected):
        raise ValueError(
            "selected trajectory IDs must be unique and non-empty"
        )
    if not isinstance(promotion_gate, Mapping) or not promotion_gate:
        raise ValueError("E8 promotion gate must be a non-empty object")
    gate = dict(promotion_gate)
    unknown_gate_fields = sorted(set(gate) - _SUPPORTED_GATE_FIELDS)
    if unknown_gate_fields:
        raise ValueError(
            "E8 promotion gate contains unsupported fields: "
            + ", ".join(unknown_gate_fields)
        )
    contract = _profile_contract(evaluation_profile)
    heldout = bool(contract["heldout"])
    if (
        isinstance(cumulative_logical_completions_before, bool)
        or not isinstance(cumulative_logical_completions_before, int)
        or cumulative_logical_completions_before < 0
        or isinstance(maximum_new_logical_completions, bool)
        or not isinstance(maximum_new_logical_completions, int)
        or maximum_new_logical_completions < 1
        or maximum_new_logical_completions > 2 * len(selected)
        or cumulative_logical_completions_before
        + maximum_new_logical_completions
        > E8_AUTHORIZED_CUMULATIVE_CEILING
    ):
        raise ValueError("E8 logical-completion budget is invalid")
    hard_stop = (
        cumulative_logical_completions_before
        + maximum_new_logical_completions
    )
    if evaluation_profile == "dry5" and (
        cumulative_logical_completions_before
        != E8_CUMULATIVE_LOGICAL_COMPLETIONS_BEFORE
        or maximum_new_logical_completions < 5
    ):
        raise ValueError(
            "E8 dry budget must begin at 312 and cover five judgments"
        )
    if evaluation_profile in {"full30", "smoke30"}:
        if evaluation_profile == "smoke30" and (
            maximum_new_logical_completions
            != E8_AUTHORIZED_CUMULATIVE_CEILING
            - cumulative_logical_completions_before
            or maximum_new_logical_completions < 30
        ):
            raise ValueError(
                "E8 held-out budget must reserve the exact authorized "
                "remainder and cover 30 base judgments"
            )
        if evaluation_profile == "full30" and (
            maximum_new_logical_completions < 25 or hard_stop > 350
        ):
            raise ValueError(
                "E8 full-tuning budget must cover 25 cache-miss judgments "
                "and reserve 30 completions for smoke"
            )
    if not config.api_key_env:
        raise ValueError(
            "E8 preregistration requires an API-key environment name"
        )
    _validate_formal_provider_config(
        profile=evaluation_profile,
        config=config,
    )

    prediction_path = Path(prediction_manifest_path).expanduser().resolve()
    dataset_resolved = Path(dataset_path).expanduser().resolve()
    cohort_resolved = Path(cohort_manifest_path).expanduser().resolve()
    destination = Path(output_path).expanduser().resolve()
    run_output_resolved = Path(run_output_dir).expanduser().resolve()
    cache_resolved = Path(cache_dir).expanduser().resolve()
    prediction, cases = load_prediction_manifest(prediction_path)
    dataset = load_agent_error_bench(dataset_resolved)
    cohort = load_cohort_manifest(cohort_resolved, dataset=dataset)
    if evaluation_profile in {"dry5", "full30", "smoke30"}:
        _validate_prediction_manifest_against_dataset(
            prediction_manifest=prediction,
            dataset=dataset,
            cohort=cohort,
        )
    if (
        dataset.dataset_sha256 != prediction["dataset_manifest_sha256"]
        or cohort.dataset_manifest_sha256
        != prediction["dataset_manifest_sha256"]
        or cohort.cohort_name != prediction["cohort_name"]
        or cohort.cohort_sha256 != prediction["cohort_sha256"]
        or tuple(case.trajectory_id for case in cases)
        != cohort.trajectory_ids
    ):
        raise FreshSemanticPreregistrationError(
            "E8 evaluation binding diverges from PredictionManifest"
        )
    contract = _validate_evaluation_profile_binding(
        profile=evaluation_profile,
        cohort_name=cohort.cohort_name,
        cohort_sha256=cohort.cohort_sha256,
        cohort_trajectory_ids=cohort.trajectory_ids,
        manifest_trajectory_ids=[
            case.trajectory_id for case in cases
        ],
        selected_trajectory_ids=selected,
        gate=gate,
    )
    known = [case.trajectory_id for case in cases]
    expected_selected = [
        value for value in known if value in set(selected)
    ]
    if selected != expected_selected:
        raise FreshSemanticPreregistrationError(
            "selected IDs must follow prediction-manifest order"
        )
    if config.cohort_sha256 != prediction["cohort_sha256"]:
        raise FreshSemanticPreregistrationError(
            "E8 preregistration input/provider lineage is invalid"
        )

    code_bundle = _current_code_bundle()
    authorization_dir = _authorization_directory(
        profile=evaluation_profile,
        requested=authorization_chain_dir,
        run_output_dir=run_output_resolved,
    )
    claim_path = _claim_path(
        authorization_dir,
        profile=evaluation_profile,
    )
    predecessor, predecessor_claim_sha256 = (
        _resolve_predecessor_binding(
            profile=evaluation_profile,
            authorization_dir=authorization_dir,
            cumulative_before=cumulative_logical_completions_before,
            code_bundle=code_bundle,
            config=config,
            cache_dir=cache_resolved,
            current_prediction_manifest_path=prediction_path,
            current_prediction_manifest=prediction,
        )
    )
    _validate_phase_budget(
        profile=evaluation_profile,
        cumulative_before=cumulative_logical_completions_before,
        maximum_new=maximum_new_logical_completions,
        hard_cumulative_stop=hard_stop,
        authorized_cumulative_ceiling=E8_AUTHORIZED_CUMULATIVE_CEILING,
        predecessor_cumulative_after=(
            None
            if predecessor is None
            else predecessor["cumulative_after"]
        ),
    )

    run_output_initial_state = _directory_state(
        run_output_resolved,
        excluded_paths=(destination,),
    )
    cache_initial_state = _directory_state(cache_resolved)
    _validate_frozen_phase_namespace(
        profile=evaluation_profile,
        run_output_initial_state=run_output_initial_state,
        cache_initial_state=cache_initial_state,
        predecessor=predecessor,
    )
    ledger_path = run_output_resolved / "logical-completion-ledger.json"
    ledger_lock_path = _ledger_lock_path(ledger_path)
    if (
        (ledger_path.is_file() or ledger_lock_path.is_file())
        and not destination.is_file()
    ):
        raise FreshSemanticPreregistrationError(
            "E8 logical-completion ledger path is not fresh"
        )
    document: dict[str, Any] = {
        "schema_version": E8_PREREGISTRATION_SCHEMA_VERSION,
        "preregistration_path": str(destination),
        "authorization_chain": {
            "directory": str(authorization_dir),
            "claim_path": str(claim_path),
            "ordinal": _phase_identity(evaluation_profile)[0],
            "predecessor_claim_sha256": predecessor_claim_sha256,
        },
        "predecessor": predecessor,
        "experiment_name": experiment_name.strip(),
        "hypothesis": hypothesis.strip(),
        "selection": {
            "rule": selection_rule.strip(),
            "trajectory_ids": selected,
            "count": len(selected),
        },
        "prediction_manifest": {
            "path": str(prediction_path),
            "file_sha256": _file_sha256(prediction_path),
            "content_sha256": prediction["prediction_manifest_sha256"],
            "dataset_manifest_sha256": prediction[
                "dataset_manifest_sha256"
            ],
            "cohort_name": prediction["cohort_name"],
            "cohort_sha256": prediction["cohort_sha256"],
            "entry_count": len(cases),
        },
        "evaluation": {
            "profile": evaluation_profile,
            "heldout": heldout,
            "dataset_path": str(dataset_resolved),
            "dataset_directory_state": _directory_state(dataset_resolved),
            "dataset_manifest_sha256": dataset.dataset_sha256,
            "cohort_manifest_path": str(cohort_resolved),
            "cohort_manifest_file_sha256": _file_sha256(cohort_resolved),
            "cohort_name": cohort.cohort_name,
            "cohort_sha256": cohort.cohort_sha256,
            "trajectory_count": len(cohort.trajectory_ids),
        },
        "implementation": {
            "experiment": E8_EXPERIMENT,
            "pipeline_version": FRESH_SEMANTIC_PIPELINE_VERSION,
            "prompt_protocol_version": (
                FRESH_SEMANTIC_PROMPT_PROTOCOL_VERSION
            ),
            "judge_view_version": JUDGE_VIEW_VERSION,
            "evidence_validation_version": (
                FRESH_EVIDENCE_VALIDATION_VERSION
            ),
            "evidence_repair_pipeline_version": (
                FRESH_EVIDENCE_REPAIR_PIPELINE_VERSION
            ),
            "evidence_repair_prompt_protocol_version": (
                FRESH_EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
            ),
            "evidence_repair_max_attempts": (
                FRESH_EVIDENCE_REPAIR_MAX_ATTEMPTS
            ),
            "transport_policy_version": TRANSPORT_POLICY_VERSION,
            "prediction_schema_version": E8_PREDICTION_SCHEMA_VERSION,
            "predict_run_schema_version": E8_PREDICT_RUN_SCHEMA_VERSION,
            "stage_cache_schema_version": STAGE_CACHE_SCHEMA_VERSION,
            "raw_stage_schema_version": RAW_STAGE_SCHEMA_VERSION,
            "raw_response_sidecar_schema_version": (
                RAW_RESPONSE_SIDECAR_SCHEMA_VERSION
            ),
            "logical_completion_ledger_schema_version": (
                E8_LOGICAL_COMPLETION_LEDGER_SCHEMA_VERSION
            ),
            "semantic_classifier": "single_fresh_llm_raw_output",
            "semantic_input": "complete_judge_view_without_prior_root",
            "deterministic_root_fallback": False,
            "confidence_score_weight_vote": False,
        },
        "provider_config": config.public_dict(),
        "execution": {
            "run_output_dir": str(run_output_resolved),
            "unscored_predictions_path": str(
                run_output_resolved / "unscored-predictions.jsonl"
            ),
            "predict_run_metadata_path": str(
                run_output_resolved / "predict-run.json"
            ),
            "scored_output_dir": str(run_output_resolved),
            "run_output_initial_state": run_output_initial_state,
            "cache_dir": str(cache_resolved),
            "cache_initial_state": cache_initial_state,
            "logical_completion_ledger_path": str(ledger_path),
            "logical_completion_ledger_lock_path": str(ledger_lock_path),
            "workers": 1,
            "retry_failures": False,
            "semantic_judge_max_per_case": 1,
            "repair_max_per_mechanically_eligible_judgment": 1,
            "repair_eligibility": {
                "validation_issue_count": 1,
                "validation_issue_level": "error",
                "validation_issue_code": (
                    "owner_evidence_quote_not_found"
                ),
            },
        },
        "logical_completion_budget": {
            "cumulative_before": cumulative_logical_completions_before,
            "maximum_new": maximum_new_logical_completions,
            "hard_cumulative_stop": (
                cumulative_logical_completions_before
                + maximum_new_logical_completions
            ),
            "authorized_cumulative_ceiling": (
                E8_AUTHORIZED_CUMULATIVE_CEILING
            ),
            "http_transport_retries_are_not_logical_completions": True,
        },
        "promotion_gate": gate,
        "code_bundle_sha256": stable_sha256(code_bundle),
        "code_bundle": code_bundle,
    }
    document["preregistration_sha256"] = stable_sha256(document)
    if destination.is_file():
        existing = _read(destination, location="E8 preregistration")
        if existing != document:
            differing = sorted(
                key
                for key in set(existing) | set(document)
                if existing.get(key) != document.get(key)
            )
            raise FreshSemanticPreregistrationError(
                "existing E8 preregistration conflicts with current identity: "
                + ", ".join(differing)
            )
    elif claim_path.is_file():
        raise FreshSemanticPreregistrationError(
            "E8 authorization phase was already claimed"
        )
    else:
        _atomic_json(destination, document)
    claim = _authorization_claim_for_preregistration(document)
    if claim_path.is_file():
        existing_claim = _read_authorization_claim(
            claim_path,
            expected_profile=evaluation_profile,
        )
        if existing_claim != claim:
            raise FreshSemanticPreregistrationError(
                "existing E8 authorization claim conflicts with preregistration"
            )
    else:
        _exclusive_json(claim_path, claim)
    initialize_fresh_semantic_completion_ledger(
        ledger_path,
        preregistration_sha256=document["preregistration_sha256"],
        cumulative_before=cumulative_logical_completions_before,
        maximum_new=maximum_new_logical_completions,
        authorized_cumulative_ceiling=E8_AUTHORIZED_CUMULATIVE_CEILING,
    )
    return document


def verify_fresh_semantic_preregistration(
    *,
    preregistration_path: str | Path,
    prediction_manifest_path: str | Path,
    run_output_dir: str | Path,
    cache_dir: str | Path,
    unscored_output_path: str | Path,
    predict_run_metadata_path: str | Path,
    config: BenchmarkRunConfig,
    selected_trajectory_ids: Sequence[str],
    maximum_new_logical_completions: int,
) -> dict[str, Any]:
    """Recompute the complete write-once identity immediately before calls."""

    path = Path(preregistration_path).expanduser().resolve()
    document = _read(path, location="E8 preregistration")
    body = dict(document)
    claimed = body.pop("preregistration_sha256", None)
    if (
        document.get("schema_version")
        != E8_PREREGISTRATION_SCHEMA_VERSION
        or claimed != stable_sha256(body)
    ):
        raise FreshSemanticPreregistrationError(
            "E8 preregistration schema or self-hash is invalid"
        )
    selection = document.get("selection")
    budget = document.get("logical_completion_budget")
    execution = document.get("execution")
    evaluation = document.get("evaluation")
    if (
        not isinstance(selection, Mapping)
        or not isinstance(budget, Mapping)
        or not isinstance(execution, Mapping)
        or not isinstance(evaluation, Mapping)
        or selection.get("trajectory_ids")
        != [str(value) for value in selected_trajectory_ids]
        or budget.get("maximum_new") != maximum_new_logical_completions
        or execution.get("unscored_predictions_path")
        != str(Path(unscored_output_path).expanduser().resolve())
        or execution.get("predict_run_metadata_path")
        != str(Path(predict_run_metadata_path).expanduser().resolve())
    ):
        raise FreshSemanticPreregistrationError(
            "runtime E8 selection or budget differs from preregistration"
        )
    prediction_path = Path(
        prediction_manifest_path
    ).expanduser().resolve()
    run_output_resolved = Path(run_output_dir).expanduser().resolve()
    cache_resolved = Path(cache_dir).expanduser().resolve()
    prediction, cases = load_prediction_manifest(prediction_path)
    manifest_record = document.get("prediction_manifest")
    implementation = document.get("implementation")
    if not isinstance(manifest_record, Mapping) or not isinstance(
        implementation,
        Mapping,
    ):
        raise FreshSemanticPreregistrationError(
            "E8 preregistration implementation envelope is invalid"
        )
    dataset_path = Path(
        str(evaluation.get("dataset_path"))
    ).expanduser().resolve()
    cohort_path = Path(
        str(evaluation.get("cohort_manifest_path"))
    ).expanduser().resolve()
    manifest_ids = [case.trajectory_id for case in cases]
    contract = _validate_evaluation_profile_binding(
        profile=str(evaluation.get("profile")),
        cohort_name=evaluation.get("cohort_name"),
        cohort_sha256=evaluation.get("cohort_sha256"),
        cohort_trajectory_ids=manifest_ids,
        manifest_trajectory_ids=manifest_ids,
        selected_trajectory_ids=selection["trajectory_ids"],
        gate=document.get("promotion_gate", {}),
    )
    if (
        evaluation.get("heldout") is not contract["heldout"]
        or selection.get("count") != len(selection["trajectory_ids"])
        or selection.get("count") != contract["selection_count"]
    ):
        raise FreshSemanticPreregistrationError(
            "E8 stored evaluation profile metadata is inconsistent"
        )
    ledger_path = Path(
        str(execution.get("logical_completion_ledger_path"))
    ).expanduser().resolve()
    expected_ledger_path = (
        run_output_resolved / "logical-completion-ledger.json"
    )
    ledger_lock_path = _ledger_lock_path(ledger_path)
    if (
        ledger_path != expected_ledger_path
        or execution.get("logical_completion_ledger_lock_path")
        != str(ledger_lock_path)
    ):
        raise FreshSemanticPreregistrationError(
            "E8 logical-completion ledger path identity is invalid"
        )
    try:
        ledger = load_fresh_semantic_completion_ledger(
            ledger_path,
            preregistration_sha256=claimed,
            cumulative_before=budget.get("cumulative_before"),
            maximum_new=budget.get("maximum_new"),
            authorized_cumulative_ceiling=budget.get(
                "authorized_cumulative_ceiling"
            ),
        )
    except FreshSemanticWorkflowError as error:
        raise FreshSemanticPreregistrationError(str(error)) from error
    current_bundle = _current_code_bundle()
    profile = str(evaluation.get("profile"))
    _validate_formal_provider_config(profile=profile, config=config)
    authorization = document.get("authorization_chain")
    if not isinstance(authorization, Mapping):
        raise FreshSemanticPreregistrationError(
            "E8 authorization-chain envelope is invalid"
        )
    authorization_dir = _authorization_directory(
        profile=profile,
        requested=authorization.get("directory"),
        run_output_dir=run_output_resolved,
    )
    current_predecessor, predecessor_claim_sha256 = (
        _resolve_predecessor_binding(
            profile=profile,
            authorization_dir=authorization_dir,
            cumulative_before=budget["cumulative_before"],
            code_bundle=current_bundle,
            config=config,
            cache_dir=cache_resolved,
            current_prediction_manifest_path=prediction_path,
            current_prediction_manifest=prediction,
            require_predecessor_cache_state=not bool(ledger["entries"]),
            revalidate_predecessor_promotion=False,
        )
    )
    _validate_phase_budget(
        profile=profile,
        cumulative_before=budget.get("cumulative_before"),
        maximum_new=budget.get("maximum_new"),
        hard_cumulative_stop=budget.get("hard_cumulative_stop"),
        authorized_cumulative_ceiling=budget.get(
            "authorized_cumulative_ceiling"
        ),
        predecessor_cumulative_after=(
            None
            if current_predecessor is None
            else current_predecessor["cumulative_after"]
        ),
    )
    _validate_frozen_phase_namespace(
        profile=profile,
        run_output_initial_state=execution.get(
            "run_output_initial_state"
        ),
        cache_initial_state=execution.get("cache_initial_state"),
        predecessor=current_predecessor,
    )
    if (
        authorization.get("claim_path")
        != str(_claim_path(authorization_dir, profile=profile))
        or authorization.get("ordinal") != _phase_identity(profile)[0]
        or authorization.get("predecessor_claim_sha256")
        != predecessor_claim_sha256
        or document.get("predecessor") != current_predecessor
        or (
            profile == "dry5"
            and (
                budget.get("cumulative_before")
                != E8_CUMULATIVE_LOGICAL_COMPLETIONS_BEFORE
                or budget.get("maximum_new", 0) < 5
            )
        )
    ):
        raise FreshSemanticPreregistrationError(
            "E8 authorization/predecessor budget lineage is invalid"
        )
    _validate_authorization_claim(document)
    checks = (
        document.get("preregistration_path") == str(path),
        document.get("code_bundle") == current_bundle,
        document.get("code_bundle_sha256")
        == stable_sha256(current_bundle),
        manifest_record.get("path") == str(prediction_path),
        manifest_record.get("file_sha256")
        == _file_sha256(prediction_path),
        manifest_record.get("content_sha256")
        == prediction["prediction_manifest_sha256"],
        manifest_record.get("entry_count") == len(cases),
        manifest_record.get("dataset_manifest_sha256")
        == prediction["dataset_manifest_sha256"],
        manifest_record.get("cohort_name") == prediction["cohort_name"],
        manifest_record.get("cohort_sha256")
        == prediction["cohort_sha256"],
        evaluation.get("dataset_directory_state")
        == _directory_state(dataset_path),
        evaluation.get("dataset_manifest_sha256")
        == prediction["dataset_manifest_sha256"],
        evaluation.get("cohort_manifest_file_sha256")
        == _file_sha256(cohort_path),
        evaluation.get("cohort_name") == prediction["cohort_name"],
        evaluation.get("cohort_sha256")
        == prediction["cohort_sha256"],
        evaluation.get("trajectory_count") == len(cases),
        config.public_dict() == document.get("provider_config"),
        execution.get("run_output_dir") == str(run_output_resolved),
        execution.get("cache_dir") == str(cache_resolved),
        implementation.get("experiment") == E8_EXPERIMENT,
        implementation.get("pipeline_version")
        == FRESH_SEMANTIC_PIPELINE_VERSION,
        implementation.get("prompt_protocol_version")
        == FRESH_SEMANTIC_PROMPT_PROTOCOL_VERSION,
    )
    if not all(checks):
        raise FreshSemanticPreregistrationError(
            "runtime E8 code/input/provider/path identity differs from "
            "preregistration"
        )
    unscored_path = Path(
        str(execution["unscored_predictions_path"])
    ).expanduser().resolve()
    predict_run_path = Path(
        str(execution["predict_run_metadata_path"])
    ).expanduser().resolve()
    if predict_run_path.is_file():
        raise FreshSemanticPreregistrationError(
            "E8 prediction run is already complete"
        )
    current_output_without_authorized_progress = _directory_state(
        run_output_resolved,
        excluded_paths=(
            path,
            ledger_path,
            ledger_lock_path,
            unscored_path,
        ),
    )
    if (
        current_output_without_authorized_progress
        != execution.get("run_output_initial_state")
    ):
        raise FreshSemanticPreregistrationError(
            "E8 output directory contains unregistered artifacts"
        )
    if not ledger["entries"]:
        if unscored_path.is_file() or (
            execution.get("cache_initial_state")
            != _directory_state(cache_resolved)
        ):
            raise FreshSemanticPreregistrationError(
                "E8 clean-start state differs from preregistration"
            )
    else:
        try:
            validate_partial_fresh_semantic_predictions(
                prediction_manifest_path=prediction_path,
                unscored_predictions_path=unscored_path,
                preregistration_sha256=claimed,
                cache_dir=cache_resolved,
                config=config,
                selected_trajectory_ids=selection["trajectory_ids"],
            )
        except FreshSemanticWorkflowError as error:
            raise FreshSemanticPreregistrationError(str(error)) from error
    return document


def verify_fresh_semantic_promotion(
    *,
    preregistration_path: str | Path,
    predictions_path: str | Path,
    metrics_path: str | Path,
    predict_run_path: str | Path,
    output_path: str | Path,
    persist: bool = True,
    validate_cache_state: bool = True,
) -> dict[str, Any]:
    """Apply the frozen E8 promotion gate to independently scored artifacts."""

    prereg_path = Path(preregistration_path).expanduser().resolve()
    predictions_resolved = Path(predictions_path).expanduser().resolve()
    metrics_resolved = Path(metrics_path).expanduser().resolve()
    run_resolved = Path(predict_run_path).expanduser().resolve()
    prereg = _read(prereg_path, location="E8 preregistration")
    prereg_body = dict(prereg)
    if (
        prereg.get("schema_version")
        != E8_PREREGISTRATION_SCHEMA_VERSION
        or prereg.get("preregistration_path") != str(prereg_path)
        or prereg_body.pop("preregistration_sha256", None)
        != stable_sha256(prereg_body)
    ):
        raise FreshSemanticPreregistrationError(
            "E8 preregistration identity or self-hash is invalid"
        )
    current_bundle = _current_code_bundle()
    if (
        prereg.get("code_bundle") != current_bundle
        or prereg.get("code_bundle_sha256")
        != stable_sha256(current_bundle)
    ):
        raise FreshSemanticPreregistrationError(
            "E8 code bundle changed after preregistration"
        )
    selection = prereg.get("selection")
    gate = prereg.get("promotion_gate")
    budget = prereg.get("logical_completion_budget")
    implementation = prereg.get("implementation")
    execution = prereg.get("execution")
    manifest_record = prereg.get("prediction_manifest")
    evaluation = prereg.get("evaluation")
    if not all(
        isinstance(value, Mapping)
        for value in (
            selection,
            gate,
            budget,
            implementation,
            execution,
            manifest_record,
            evaluation,
        )
    ):
        raise FreshSemanticPreregistrationError(
            "E8 preregistration gate envelope is invalid"
        )
    unknown_gate_fields = sorted(set(gate) - _SUPPORTED_GATE_FIELDS)
    if unknown_gate_fields:
        raise FreshSemanticPreregistrationError(
            "E8 promotion gate contains unsupported fields: "
            + ", ".join(unknown_gate_fields)
        )
    profile = str(evaluation.get("profile"))
    authorization = prereg.get("authorization_chain")
    if not isinstance(authorization, Mapping):
        raise FreshSemanticPreregistrationError(
            "E8 authorization-chain envelope is invalid"
        )
    authorization_dir = _authorization_directory(
        profile=profile,
        requested=authorization.get("directory"),
        run_output_dir=Path(
            str(execution["run_output_dir"])
        ).expanduser().resolve(),
    )
    current_manifest_path = Path(
        str(manifest_record["path"])
    ).expanduser().resolve()
    current_manifest, _ = load_prediction_manifest(current_manifest_path)
    current_config = BenchmarkRunConfig(**dict(prereg["provider_config"]))
    _validate_formal_provider_config(
        profile=profile,
        config=current_config,
    )
    current_predecessor, predecessor_claim_sha256 = (
        _resolve_predecessor_binding(
            profile=profile,
            authorization_dir=authorization_dir,
            cumulative_before=budget["cumulative_before"],
            code_bundle=current_bundle,
            config=current_config,
            cache_dir=Path(
                str(execution["cache_dir"])
            ).expanduser().resolve(),
            current_prediction_manifest_path=current_manifest_path,
            current_prediction_manifest=current_manifest,
            require_predecessor_cache_state=False,
        )
    )
    _validate_phase_budget(
        profile=profile,
        cumulative_before=budget.get("cumulative_before"),
        maximum_new=budget.get("maximum_new"),
        hard_cumulative_stop=budget.get("hard_cumulative_stop"),
        authorized_cumulative_ceiling=budget.get(
            "authorized_cumulative_ceiling"
        ),
        predecessor_cumulative_after=(
            None
            if current_predecessor is None
            else current_predecessor["cumulative_after"]
        ),
    )
    _validate_frozen_phase_namespace(
        profile=profile,
        run_output_initial_state=execution.get(
            "run_output_initial_state"
        ),
        cache_initial_state=execution.get("cache_initial_state"),
        predecessor=current_predecessor,
    )
    if (
        authorization.get("claim_path")
        != str(_claim_path(authorization_dir, profile=profile))
        or authorization.get("ordinal") != _phase_identity(profile)[0]
        or authorization.get("predecessor_claim_sha256")
        != predecessor_claim_sha256
        or prereg.get("predecessor") != current_predecessor
    ):
        raise FreshSemanticPreregistrationError(
            "E8 promotion authorization lineage is invalid"
        )
    _validate_authorization_claim(prereg)
    expected_output_dir = Path(
        str(execution["run_output_dir"])
    ).expanduser().resolve()
    expected_paths = {
        "predictions": expected_output_dir / "predictions.jsonl",
        "metrics": expected_output_dir / "metrics.json",
        "predict_run": Path(
            str(execution["predict_run_metadata_path"])
        ).expanduser().resolve(),
        "promotion": expected_output_dir / "promotion.json",
    }
    actual_paths = {
        "predictions": predictions_resolved,
        "metrics": metrics_resolved,
        "predict_run": run_resolved,
        "promotion": Path(output_path).expanduser().resolve(),
    }
    if actual_paths != expected_paths:
        raise FreshSemanticPreregistrationError(
            "E8 promotion artifact paths differ from preregistration"
        )
    try:
        prediction_rows = [
            json.loads(line)
            for line in predictions_resolved.read_text(
                encoding="utf-8"
            ).splitlines()
            if line.strip()
        ]
    except (OSError, json.JSONDecodeError) as error:
        raise FreshSemanticPreregistrationError(
            "E8 scored predictions are corrupt"
        ) from error
    if not prediction_rows or any(
        not isinstance(row, dict) for row in prediction_rows
    ):
        raise FreshSemanticPreregistrationError(
            "E8 scored predictions are invalid"
        )
    metrics_document = _read(metrics_resolved, location="E8 metrics")
    predict_run = _read(run_resolved, location="E8 predict run")
    if (
        predict_run.get("preregistration_sha256")
        != prereg["preregistration_sha256"]
        or predict_run.get("cache_dir") != execution.get("cache_dir")
        or predict_run.get("max_logical_completions")
        != budget.get("maximum_new")
    ):
        raise FreshSemanticPreregistrationError(
            "E8 predict-run is not bound to its preregistration"
        )
    try:
        ledger = load_fresh_semantic_completion_ledger(
            str(execution["logical_completion_ledger_path"]),
            preregistration_sha256=prereg["preregistration_sha256"],
            cumulative_before=budget.get("cumulative_before"),
            maximum_new=budget.get("maximum_new"),
            authorized_cumulative_ceiling=budget.get(
                "authorized_cumulative_ceiling"
            ),
        )
    except FreshSemanticWorkflowError as error:
        raise FreshSemanticPreregistrationError(str(error)) from error
    if (
        predict_run.get("logical_completion_ledger_path")
        != execution.get("logical_completion_ledger_path")
        or predict_run.get("logical_completion_budget_used")
        != len(ledger["entries"])
        or predict_run.get("logical_completion_ledger_sha256")
        != ledger["ledger_sha256"]
    ):
        raise FreshSemanticPreregistrationError(
            "E8 completion ledger diverges from preregistration"
        )
    (
        validated_manifest,
        validated_cases,
        validated_unscored,
        validated_run,
        validated_config,
    ) = validate_fresh_semantic_artifacts(
        prediction_manifest_path=str(manifest_record["path"]),
        unscored_predictions_path=str(
            execution["unscored_predictions_path"]
        ),
        predict_run_metadata_path=run_resolved,
    )
    if (
        validated_run != predict_run
        or validated_config.public_dict() != prereg.get("provider_config")
        or _file_sha256(Path(str(manifest_record["path"])))
        != manifest_record.get("file_sha256")
        or validated_manifest.get("prediction_manifest_sha256")
        != manifest_record.get("content_sha256")
        or validated_manifest.get("dataset_manifest_sha256")
        != manifest_record.get("dataset_manifest_sha256")
        or validated_manifest.get("cohort_sha256")
        != manifest_record.get("cohort_sha256")
    ):
        raise FreshSemanticPreregistrationError(
            "E8 raw prediction chain diverges from preregistration"
        )
    if profile == "full30":
        rows_by_id = {
            row["trajectory_id"]: row for row in validated_unscored
        }
        cached_ids = current_predecessor[
            "cached_judge_trajectory_ids"
        ]
        cached_requests = current_predecessor[
            "cached_judge_request_sha256"
        ]
        if any(
            trajectory_id not in rows_by_id
            or rows_by_id[trajectory_id]["stage_cache_hits"].get(
                E8_STAGE
            )
            is not True
            or rows_by_id[trajectory_id]["stage_identities"][E8_STAGE][
                "request_sha256"
            ]
            != request_sha256
            for trajectory_id, request_sha256 in zip(
                cached_ids,
                cached_requests,
                strict=True,
            )
        ):
            raise FreshSemanticPreregistrationError(
                "E8 full run did not reuse all five authorized dry caches"
            )
        if not _adopted_cache_hits_are_authorized(
            validated_unscored,
            ledger["entries"],
            predecessor_stage_requests=current_predecessor[
                "cached_stage_requests"
            ],
        ):
            raise FreshSemanticPreregistrationError(
                "E8 full run adopted an unauthorized cache hit"
            )
    if profile == "dry5" and not _adopted_cache_hits_are_authorized(
        validated_unscored,
        ledger["entries"],
    ):
        raise FreshSemanticPreregistrationError(
            "E8 dry run adopted an unreserved cache hit"
        )
    if len(prediction_rows) != len(validated_unscored):
        raise FreshSemanticPreregistrationError(
            "E8 scored/unscored prediction counts differ"
        )
    bound_fields = {
        "cache_dir",
        "evidence_repair",
        "evidence_validation_issues",
        "failure_code",
        "failure_message",
        "failure_stage",
        "judge_reported_step",
        "judge_step_matches_event_mapping",
        "latency_seconds",
        "prediction_manifest_sha256",
        "predicted_error_type",
        "predicted_event_id",
        "predicted_module",
        "predicted_step",
        "preregistration_sha256",
        "provider_telemetry",
        "raw_judge_outputs",
        "root_cause",
        "root_cause_judgment",
        "stage_attempted",
        "stage_cache_hits",
        "stage_identities",
        "stage_outcomes",
        "stage_provider_telemetry",
        "status",
        "trajectory_id",
        "unscored_prediction_sha256",
    }
    for scored, unscored in zip(
        prediction_rows,
        validated_unscored,
        strict=True,
    ):
        if any(
            scored.get(field) != unscored.get(field)
            for field in bound_fields
        ) or (
            scored.get("prompt_version")
            != unscored.get("prompt_protocol_version")
            or scored.get("pipeline_version")
            != unscored.get("pipeline_version")
            or scored.get("experiment") != unscored.get("experiment")
            or scored.get("semantic_classifier")
            != "fresh_llm_raw_output"
            or scored.get("prior_root") is not None
        ):
            raise FreshSemanticPreregistrationError(
                "E8 scored prediction diverges from validated raw chain"
            )
    dataset_path = Path(str(evaluation["dataset_path"])).expanduser().resolve()
    cohort_path = Path(
        str(evaluation["cohort_manifest_path"])
    ).expanduser().resolve()
    dataset = load_agent_error_bench(dataset_path)
    cohort = load_cohort_manifest(cohort_path, dataset=dataset)
    if profile in {"dry5", "full30", "smoke30"}:
        _validate_prediction_manifest_against_dataset(
            prediction_manifest=validated_manifest,
            dataset=dataset,
            cohort=cohort,
        )
    if (
        _directory_state(dataset_path)
        != evaluation.get("dataset_directory_state")
        or
        dataset.dataset_sha256
        != evaluation.get("dataset_manifest_sha256")
        or cohort.cohort_sha256 != evaluation.get("cohort_sha256")
        or cohort.cohort_name != evaluation.get("cohort_name")
        or _file_sha256(cohort_path)
        != evaluation.get("cohort_manifest_file_sha256")
    ):
        raise FreshSemanticPreregistrationError(
            "E8 evaluation dataset/cohort changed after preregistration"
        )
    contract = _validate_evaluation_profile_binding(
        profile=str(evaluation.get("profile")),
        cohort_name=cohort.cohort_name,
        cohort_sha256=cohort.cohort_sha256,
        cohort_trajectory_ids=cohort.trajectory_ids,
        manifest_trajectory_ids=[
            case.trajectory_id for case in validated_cases
        ],
        selected_trajectory_ids=selection["trajectory_ids"],
        gate=gate,
    )
    if (
        evaluation.get("heldout") is not contract["heldout"]
        or selection.get("count") != len(selection["trajectory_ids"])
        or selection.get("count") != contract["selection_count"]
    ):
        raise FreshSemanticPreregistrationError(
            "E8 stored evaluation profile metadata is inconsistent"
        )
    raw_rescored, raw_metrics, raw_run = score_fresh_semantic_predictions(
        dataset=dataset,
        cohort=cohort,
        prediction_manifest_path=str(manifest_record["path"]),
        unscored_predictions_path=str(
            execution["unscored_predictions_path"]
        ),
        predict_run_metadata_path=run_resolved,
    )
    if (
        raw_rescored != prediction_rows
        or raw_metrics != compute_metrics(prediction_rows)
        or raw_run != predict_run
    ):
        raise FreshSemanticPreregistrationError(
            "E8 scored artifacts are not an exact raw-derived evaluation"
        )
    recomputed_metrics = compute_metrics(prediction_rows)
    if metrics_document.get("metrics") != recomputed_metrics:
        raise FreshSemanticPreregistrationError(
            "E8 metrics do not match scored predictions"
        )
    selected = selection["trajectory_ids"]
    if [row.get("trajectory_id") for row in prediction_rows] != selected:
        raise FreshSemanticPreregistrationError(
            "E8 scored prediction order differs from preregistration"
        )
    if any(
        row.get("experiment") != E8_EXPERIMENT
        or row.get("pipeline_version")
        != FRESH_SEMANTIC_PIPELINE_VERSION
        or row.get("prompt_version")
        != FRESH_SEMANTIC_PROMPT_PROTOCOL_VERSION
        for row in prediction_rows
    ):
        raise FreshSemanticPreregistrationError(
            "E8 scored prediction semantic identity is invalid"
        )
    try:
        overall = recomputed_metrics["by_method"][E8_METHOD]["overall"]
    except KeyError as error:
        raise FreshSemanticPreregistrationError(
            "E8 metrics lack the two_stage method"
        ) from error

    checks: dict[str, bool] = {}

    def check(name: str, passed: bool) -> None:
        checks[name] = bool(passed)

    if "trajectory_denominator" in gate:
        check(
            "trajectory_denominator",
            overall["trajectory_count"] == gate["trajectory_denominator"],
        )
    if "successful_prediction_minimum" in gate:
        check(
            "successful_prediction_minimum",
            overall["successful_prediction_count"]
            >= gate["successful_prediction_minimum"],
        )
    if "step_exact_minimum_correct" in gate:
        check(
            "step_exact_minimum_correct",
            overall["step_exact"]["correct"]
            >= gate["step_exact_minimum_correct"],
        )
    if "step_module_exact_minimum_correct" in gate:
        check(
            "step_module_exact_minimum_correct",
            overall["step_module_exact"]["correct"]
            >= gate["step_module_exact_minimum_correct"],
        )
    if "all_correct_minimum" in gate:
        check(
            "all_correct_minimum",
            overall["all_correct"]["correct"]
            >= gate["all_correct_minimum"],
        )
    failed = overall["failed_prediction_count"]
    for field in ("hard_failure_maximum", "failed_prediction_maximum"):
        if field in gate:
            check(field, failed <= gate[field])
    if "evidence_valid_minimum" in gate:
        check(
            "evidence_valid_minimum",
            sum(
                row.get("status") in SUCCESS_STATUSES
                for row in prediction_rows
            )
            >= gate["evidence_valid_minimum"],
        )
    if gate.get("semantic_mutation_maximum") is not None:
        check(
            "semantic_mutation_maximum",
            predict_run.get("semantic_mutation_count")
            <= gate["semantic_mutation_maximum"],
        )
    by_id = {
        str(row.get("trajectory_id")): row for row in prediction_rows
    }
    for trajectory_id in gate.get(
        "required_step_module_exact_trajectory_ids",
        [],
    ):
        check(
            f"required_step_module_exact:{trajectory_id}",
            by_id.get(str(trajectory_id), {}).get("step_module_exact")
            is True,
        )
    for index, group in enumerate(
        gate.get("minimum_step_exact_by_groups", [])
    ):
        group_ids = group.get("trajectory_ids", [])
        check(
            f"minimum_step_exact_group:{index}",
            sum(
                by_id.get(str(trajectory_id), {}).get("step_exact") is True
                for trajectory_id in group_ids
            )
            >= group.get("minimum", 0),
        )
    if gate.get("telemetry_logical_equals_judge_plus_repair"):
        telemetry = predict_run.get("provider_telemetry")
        logical = (
            telemetry.get("logical_completion_count")
            if isinstance(telemetry, Mapping)
            else None
        )
        check(
            "telemetry_logical_equals_judge_plus_repair",
            logical
            == predict_run.get("prediction_count")
            + predict_run.get("repair_attempt_count"),
        )
    if gate.get("fresh_llm_raw_root_required"):
        check(
            "fresh_llm_raw_root_required",
            all(
                row.get("semantic_classifier") == "fresh_llm_raw_output"
                and row.get("prior_root") is None
                and isinstance(
                    row.get("raw_judge_outputs", {}).get(
                        E8_STAGE
                    ),
                    str,
                )
                for row in prediction_rows
                if row.get("status") in SUCCESS_STATUSES
            ),
        )
    if gate.get("raw_chain_reconstruction_required"):
        check(
            "raw_chain_reconstruction_required",
            len(validated_unscored) == len(prediction_rows)
            and validated_run == predict_run,
        )
    if gate.get("gold_isolation_required"):
        check(
            "gold_isolation_required",
            implementation.get("semantic_input")
            == "complete_judge_view_without_prior_root"
            and all(
                row.get("prior_root") is None
                and row.get("semantic_classifier")
                == "fresh_llm_raw_output"
                for row in prediction_rows
            ),
        )
    used = predict_run.get("logical_completion_budget_used")
    check(
        "runtime_budget_within_preregistration",
        isinstance(used, int)
        and not isinstance(used, bool)
        and used <= budget["maximum_new"]
        and predict_run.get("max_logical_completions")
        == budget["maximum_new"]
        and budget["cumulative_before"] + used
        <= budget["hard_cumulative_stop"]
        <= budget["authorized_cumulative_ceiling"],
    )
    if gate.get("heldout_one_shot_required"):
        run_initial = execution.get("run_output_initial_state")
        cache_initial = execution.get("cache_initial_state")
        check(
            "heldout_one_shot_required",
            isinstance(run_initial, Mapping)
            and isinstance(cache_initial, Mapping)
            and run_initial.get("file_count") == 0
            and cache_initial.get("file_count") == 0
            and selection.get("count") == 30
            and predict_run.get("prediction_count") == 30
            and evaluation.get("profile") == "smoke30"
            and evaluation.get("heldout") is True
            and evaluation.get("cohort_name") == "smoke-v1"
            and used
            == predict_run.get("prediction_count")
            + predict_run.get("repair_attempt_count")
            and _reservations_exactly_match_attempted_stages(
                validated_unscored,
                ledger["entries"],
            )
            and _all_attempted_stages_are_cache_misses(
                validated_unscored
            )
            and budget.get("maximum_new")
            == E8_AUTHORIZED_CUMULATIVE_CEILING
            - budget.get("cumulative_before"),
        )
    accepted = bool(checks) and all(checks.values())
    output_resolved = Path(output_path).expanduser().resolve()
    cache_final_state = _directory_state(
        Path(str(execution["cache_dir"])).expanduser().resolve()
    )
    if not validate_cache_state:
        existing_for_cache = _read(
            output_resolved,
            location="E8 existing promotion",
        )
        cache_final_state = existing_for_cache.get("cache_final_state")
        if not isinstance(cache_final_state, Mapping):
            raise FreshSemanticPreregistrationError(
                "E8 frozen predecessor cache state is invalid"
            )
        cache_final_state = dict(cache_final_state)
    document = {
        "schema_version": E8_PROMOTION_SCHEMA_VERSION,
        "accepted": accepted,
        "preregistration_path": str(prereg_path),
        "preregistration_sha256": prereg["preregistration_sha256"],
        "predictions_path": str(predictions_resolved),
        "predictions_file_sha256": _file_sha256(predictions_resolved),
        "metrics_path": str(metrics_resolved),
        "metrics_file_sha256": _file_sha256(metrics_resolved),
        "predict_run_path": str(run_resolved),
        "predict_run_file_sha256": _file_sha256(run_resolved),
        "cache_final_state": cache_final_state,
        "checks": checks,
        "summary": {
            "trajectory_count": overall["trajectory_count"],
            "step_correct": overall["step_exact"]["correct"],
            "step_denominator": overall["step_exact"]["denominator"],
            "step_module_correct": overall["step_module_exact"]["correct"],
            "all_correct": overall["all_correct"]["correct"],
            "all_denominator": overall["all_correct"]["denominator"],
            "failed_prediction_count": failed,
            "logical_completion_budget_used": used,
        },
    }
    document["promotion_sha256"] = stable_sha256(document)
    if persist:
        _atomic_json(output_resolved, document)
    else:
        existing = _read(
            output_resolved,
            location="E8 existing promotion",
        )
        if existing != document:
            raise FreshSemanticPreregistrationError(
                "E8 predecessor promotion does not reproduce exactly"
            )
    if not accepted:
        failed_checks = sorted(
            name for name, passed in checks.items() if not passed
        )
        raise FreshSemanticPreregistrationError(
            "E8 promotion gate failed: " + ", ".join(failed_checks)
        )
    return document


__all__ = [
    "E8_AUTHORIZATION_CHAIN_RELATIVE_PATH",
    "E8_AUTHORIZATION_CLAIM_SCHEMA_VERSION",
    "E8_AUTHORIZED_CUMULATIVE_CEILING",
    "E8_CUMULATIVE_LOGICAL_COMPLETIONS_BEFORE",
    "E8_DRY5_IDS_MANIFEST_ORDER",
    "E8_EVALUATION_PROFILES",
    "E8_PREREGISTRATION_SCHEMA_VERSION",
    "E8_PROMOTION_SCHEMA_VERSION",
    "FreshSemanticPreregistrationError",
    "frozen_fresh_semantic_promotion_gate",
    "verify_fresh_semantic_preregistration",
    "verify_fresh_semantic_promotion",
    "write_fresh_semantic_preregistration",
]

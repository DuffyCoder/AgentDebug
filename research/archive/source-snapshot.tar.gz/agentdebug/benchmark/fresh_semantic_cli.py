"""CLI for the gold-isolated E8 fresh semantic judge experiment."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

from agentdebug.diagnostics.fresh_semantic_judge import (
    FRESH_SEMANTIC_PIPELINE_VERSION,
    FRESH_SEMANTIC_PROMPT_PROTOCOL_VERSION,
)
from agentdebug.diagnostics.fresh_semantic_evidence import (
    FRESH_EVIDENCE_VALIDATION_VERSION,
)
from agentdebug.diagnostics.judge_view import JUDGE_VIEW_VERSION
from agentdebug.diagnostics.providers import (
    GeminiGenerateContentJudge,
    OpenAICompatibleJudge,
    resolve_judge_endpoint,
)

from .cohort import load_cohort_manifest
from .dataset import load_agent_error_bench
from .fresh_semantic_preregistration import (
    FreshSemanticPreregistrationError,
    frozen_fresh_semantic_promotion_gate,
    verify_fresh_semantic_preregistration,
    verify_fresh_semantic_promotion,
    write_fresh_semantic_preregistration,
)
from .fresh_semantic_workflow import (
    E8_EXPERIMENT,
    FreshSemanticWorkflowError,
    predict_fresh_semantic_cases,
    score_fresh_semantic_predictions,
)
from .prediction_manifest import load_prediction_manifest
from .reporting import write_outputs
from .runner import TRANSPORT_POLICY_VERSION, BenchmarkRunConfig
from .stage_cache import StageCacheError


def _provider_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--judge-provider",
        choices=("openai-compatible", "gemini-generate-content"),
        required=True,
    )
    parser.add_argument("--judge-base-url", required=True)
    parser.add_argument("--judge-api-key-env", required=True)
    parser.add_argument("--judge-model", required=True)
    parser.add_argument("--judge-temperature", type=float, required=True)
    parser.add_argument("--judge-timeout", type=float, required=True)
    parser.add_argument("--judge-max-output-tokens", type=int, required=True)
    parser.add_argument("--judge-max-retries", type=int, required=True)
    parser.add_argument("--judge-retry-backoff", type=float, required=True)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m agentdebug.benchmark.fresh_semantic_cli",
        description="Preregister, predict, and independently score E8.",
    )
    commands = parser.add_subparsers(dest="command", required=True)

    preregister = commands.add_parser(
        "preregister",
        help="Freeze E8 code, prompt, input, gate, paths, and call budget.",
    )
    preregister.add_argument("--experiment-name", required=True)
    preregister.add_argument("--dataset", required=True)
    preregister.add_argument("--cohort-manifest", required=True)
    preregister.add_argument("--prediction-manifest", required=True)
    preregister.add_argument("--run-output-dir", required=True)
    preregister.add_argument("--cache-dir", required=True)
    preregister.add_argument("--output", required=True)
    preregister.add_argument(
        "--trajectory-id",
        action="append",
        required=True,
    )
    preregister.add_argument("--selection-rule", required=True)
    preregister.add_argument("--hypothesis", required=True)
    preregister.add_argument(
        "--gate-profile",
        choices=("dry5", "full30", "smoke30"),
        required=True,
    )
    preregister.add_argument(
        "--cumulative-logical-completions-before",
        type=int,
        required=True,
    )
    preregister.add_argument(
        "--maximum-new-logical-completions",
        type=int,
        required=True,
    )
    _provider_arguments(preregister)

    predict = commands.add_parser(
        "predict",
        help=(
            "Call E8 using only a gold-free manifest; this command accepts "
            "no dataset, cohort label, or prior diagnosis path."
        ),
    )
    predict.add_argument("--prediction-manifest", required=True)
    predict.add_argument("--cache-dir", required=True)
    predict.add_argument("--output", required=True)
    predict.add_argument("--run-metadata", required=True)
    predict.add_argument("--preregistration", required=True)
    predict.add_argument(
        "--trajectory-id",
        action="append",
        default=[],
    )
    predict.add_argument(
        "--max-logical-completions",
        type=int,
        required=True,
    )
    _provider_arguments(predict)

    score = commands.add_parser(
        "score",
        help="Validate all raw E8 artifacts, then load gold and score.",
    )
    score.add_argument("--dataset", required=True)
    score.add_argument("--cohort-manifest", required=True)
    score.add_argument("--prediction-manifest", required=True)
    score.add_argument("--unscored-predictions", required=True)
    score.add_argument("--predict-run", required=True)
    score.add_argument("--output-dir", required=True)

    gate = commands.add_parser(
        "verify-gate",
        help="Apply the write-once E8 promotion gate to scored artifacts.",
    )
    gate.add_argument("--preregistration", required=True)
    gate.add_argument("--predictions", required=True)
    gate.add_argument("--metrics", required=True)
    gate.add_argument("--predict-run", required=True)
    gate.add_argument("--output", required=True)
    return parser


def _config_from_args(
    args: argparse.Namespace,
    *,
    endpoint: str,
    cohort_sha256: str,
) -> BenchmarkRunConfig:
    return BenchmarkRunConfig(
        model=args.judge_model,
        temperature=args.judge_temperature,
        provider=args.judge_provider,
        endpoint=endpoint,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
        cohort_sha256=cohort_sha256,
        api_key_env=args.judge_api_key_env,
    )


def _ordered_selection(
    *,
    prediction_manifest_path: str,
    requested: list[str],
) -> tuple[dict, list[str]]:
    manifest, cases = load_prediction_manifest(prediction_manifest_path)
    selected_set = set(requested)
    selected = [
        case.trajectory_id
        for case in cases
        if case.trajectory_id in selected_set
    ]
    if (
        len(selected) != len(requested)
        or len(selected_set) != len(requested)
    ):
        raise ValueError(
            "trajectory IDs are duplicated or absent from the manifest"
        )
    return manifest, selected


def _promotion_gate(
    profile: str,
    *,
    selected: list[str],
) -> dict:
    return frozen_fresh_semantic_promotion_gate(
        profile,
        selected_trajectory_ids=selected,
    )


def _preregister(args: argparse.Namespace) -> int:
    manifest, selected = _ordered_selection(
        prediction_manifest_path=args.prediction_manifest,
        requested=args.trajectory_id,
    )
    endpoint = resolve_judge_endpoint(
        provider=args.judge_provider,
        base_url=args.judge_base_url,
        model=args.judge_model,
    )
    config = _config_from_args(
        args,
        endpoint=endpoint,
        cohort_sha256=manifest["cohort_sha256"],
    )
    document = write_fresh_semantic_preregistration(
        experiment_name=args.experiment_name,
        evaluation_profile=args.gate_profile,
        dataset_path=args.dataset,
        cohort_manifest_path=args.cohort_manifest,
        prediction_manifest_path=args.prediction_manifest,
        output_path=args.output,
        run_output_dir=args.run_output_dir,
        cache_dir=args.cache_dir,
        config=config,
        selected_trajectory_ids=selected,
        selection_rule=args.selection_rule,
        hypothesis=args.hypothesis,
        promotion_gate=_promotion_gate(
            args.gate_profile,
            selected=selected,
        ),
        cumulative_logical_completions_before=(
            args.cumulative_logical_completions_before
        ),
        maximum_new_logical_completions=(
            args.maximum_new_logical_completions
        ),
    )
    print(
        json.dumps(
            {
                "output": str(Path(args.output).expanduser().resolve()),
                "preregistration_sha256": document[
                    "preregistration_sha256"
                ],
                "code_bundle_sha256": document["code_bundle_sha256"],
                "selected_count": document["selection"]["count"],
                "hard_cumulative_stop": document[
                    "logical_completion_budget"
                ]["hard_cumulative_stop"],
                "external_calls": 0,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _predict(args: argparse.Namespace) -> int:
    manifest, cases = load_prediction_manifest(args.prediction_manifest)
    judge_class = (
        GeminiGenerateContentJudge
        if args.judge_provider == "gemini-generate-content"
        else OpenAICompatibleJudge
    )
    judge = judge_class(
        base_url=args.judge_base_url,
        api_key_env=args.judge_api_key_env,
        model=args.judge_model,
        temperature=args.judge_temperature,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
    )
    config = _config_from_args(
        args,
        endpoint=judge.endpoint,
        cohort_sha256=manifest["cohort_sha256"],
    )
    selected = (
        args.trajectory_id
        if args.trajectory_id
        else [case.trajectory_id for case in cases]
    )
    preregistration = verify_fresh_semantic_preregistration(
        preregistration_path=args.preregistration,
        prediction_manifest_path=args.prediction_manifest,
        run_output_dir=Path(args.output).expanduser().resolve().parent,
        cache_dir=args.cache_dir,
        unscored_output_path=args.output,
        predict_run_metadata_path=args.run_metadata,
        config=config,
        selected_trajectory_ids=selected,
        maximum_new_logical_completions=args.max_logical_completions,
    )
    state = {"completed": 0}

    def progress(row):
        state["completed"] += 1
        print(
            f"[E8 {state['completed']}] {row['trajectory_id']} "
            f"{row['status']}",
            flush=True,
        )

    rows, metadata = predict_fresh_semantic_cases(
        prediction_manifest_path=args.prediction_manifest,
        preregistration_sha256=preregistration[
            "preregistration_sha256"
        ],
        judge=judge,
        config=config,
        cache_dir=args.cache_dir,
        unscored_output_path=args.output,
        predict_run_metadata_path=args.run_metadata,
        selected_trajectory_ids=selected,
        max_logical_completions=args.max_logical_completions,
        logical_completion_ledger_path=preregistration["execution"][
            "logical_completion_ledger_path"
        ],
        cumulative_logical_completions_before=preregistration[
            "logical_completion_budget"
        ]["cumulative_before"],
        authorized_cumulative_ceiling=preregistration[
            "logical_completion_budget"
        ]["authorized_cumulative_ceiling"],
        on_result=progress,
    )
    print(
        json.dumps(
            {
                "prediction_count": len(rows),
                "unscored_predictions_sha256": metadata[
                    "unscored_predictions_sha256"
                ],
                "predict_run_sha256": metadata["predict_run_sha256"],
                "logical_completion_budget_used": metadata[
                    "logical_completion_budget_used"
                ],
                "provider_telemetry": metadata["provider_telemetry"],
                "preregistration_sha256": preregistration[
                    "preregistration_sha256"
                ],
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _score(args: argparse.Namespace) -> int:
    started = datetime.now(timezone.utc)
    dataset = load_agent_error_bench(args.dataset)
    cohort = load_cohort_manifest(
        args.cohort_manifest,
        dataset=dataset,
    )
    predictions, metrics, predict_run = score_fresh_semantic_predictions(
        dataset=dataset,
        cohort=cohort,
        prediction_manifest_path=args.prediction_manifest,
        unscored_predictions_path=args.unscored_predictions,
        predict_run_metadata_path=args.predict_run,
    )
    finished = datetime.now(timezone.utc)
    config = predict_run["provider_config"]
    run_metadata = {
        "started_at": started.isoformat(),
        "finished_at": finished.isoformat(),
        "duration_seconds": (finished - started).total_seconds(),
        "experiment": E8_EXPERIMENT,
        "model": config["model"],
        "temperature": config["temperature"],
        "provider": config["provider"],
        "endpoint": config["endpoint"],
        "timeout": config["timeout"],
        "max_output_tokens": config["max_output_tokens"],
        "max_retries": config["max_retries"],
        "retry_backoff": config["retry_backoff"],
        "workers": 1,
        "execution_order": "prediction-manifest",
        "methods": ["two_stage"],
        "prompt_versions": {
            "two_stage": FRESH_SEMANTIC_PROMPT_PROTOCOL_VERSION,
        },
        "judge_view_version": JUDGE_VIEW_VERSION,
        "diagnostic_pipeline_version": FRESH_SEMANTIC_PIPELINE_VERSION,
        "pipeline_versions": {
            "two_stage": FRESH_SEMANTIC_PIPELINE_VERSION,
        },
        "production_two_stage_pipeline_version": (
            FRESH_SEMANTIC_PIPELINE_VERSION
        ),
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "evidence_validation_version": (
            FRESH_EVIDENCE_VALIDATION_VERSION
        ),
        "provider_telemetry": predict_run["provider_telemetry"],
        "provider_telemetry_coverage": predict_run[
            "provider_telemetry_coverage"
        ],
        "provider_capabilities": predict_run["provider_capabilities"],
        "repair_eligible_count": predict_run["repair_eligible_count"],
        "repair_attempt_count": predict_run["repair_attempt_count"],
        "repair_applied_count": predict_run["repair_applied_count"],
        "semantic_mutation_count": predict_run[
            "semantic_mutation_count"
        ],
        "released_label_count": len(dataset.labels),
        "available_trajectory_count": len(dataset.examples),
        "judge_input_count": len(predictions),
        "metric_cohort_count": len(predictions),
        "prediction_count": len(predictions),
        "selection": {
            "trajectory_ids": predict_run["selected_trajectory_ids"],
            "cohort_manifest_path": str(cohort.path),
            "cohort_name": cohort.cohort_name,
            "cohort_sha256": cohort.cohort_sha256,
            "dataset_manifest_sha256": dataset.dataset_sha256,
            "cohort": cohort.cohort_name,
        },
        "cache_dir": None,
        "retry_failures": False,
        "resume": False,
        "max_logical_completions": predict_run[
            "max_logical_completions"
        ],
        "logical_completion_budget_used": predict_run[
            "logical_completion_budget_used"
        ],
        "gold_isolation": {
            "enabled": True,
            "prediction_input_type": (
                "hash_locked_gold_free_judge_view_without_prior_root"
            ),
            "raw_first_stage_cache": True,
            "provider_process_isolated_from_dataset": True,
            "unscored_persisted_before_gold_scoring": True,
            "prediction_manifest_path": str(
                Path(args.prediction_manifest).expanduser().resolve()
            ),
            "prediction_manifest_sha256": predict_run[
                "prediction_manifest_sha256"
            ],
            "unscored_predictions_path": str(
                Path(args.unscored_predictions).expanduser().resolve()
            ),
            "unscored_predictions_sha256": predict_run[
                "unscored_predictions_sha256"
            ],
            "predict_run_metadata_path": str(
                Path(args.predict_run).expanduser().resolve()
            ),
            "predict_run_sha256": predict_run["predict_run_sha256"],
        },
    }
    paths = write_outputs(
        output_dir=args.output_dir,
        dataset=dataset,
        predictions=predictions,
        metrics=metrics,
        run_metadata=run_metadata,
    )
    print(json.dumps(paths, ensure_ascii=False, indent=2))
    return 0


def _verify_gate(args: argparse.Namespace) -> int:
    document = verify_fresh_semantic_promotion(
        preregistration_path=args.preregistration,
        predictions_path=args.predictions,
        metrics_path=args.metrics,
        predict_run_path=args.predict_run,
        output_path=args.output,
    )
    print(
        json.dumps(
            {
                "accepted": document["accepted"],
                "output": str(Path(args.output).expanduser().resolve()),
                "promotion_sha256": document["promotion_sha256"],
                "summary": document["summary"],
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.command == "preregister":
            return _preregister(args)
        if args.command == "predict":
            return _predict(args)
        if args.command == "score":
            return _score(args)
        return _verify_gate(args)
    except (
        FreshSemanticWorkflowError,
        FreshSemanticPreregistrationError,
        StageCacheError,
        OSError,
        TypeError,
        ValueError,
    ) as error:
        print(f"agentdebug-e8: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

"""Credential-bearing, gold-free production prediction worker.

This process accepts only a prepared JudgeView manifest.  It has no dataset or
label command-line argument and exits before the independent scoring process
loads benchmark gold.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from agentdebug.diagnostics import (
    GeminiGenerateContentJudge,
    OpenAICompatibleJudge,
)

from .prediction_manifest import PredictionManifestError
from .preregistration import (
    PreregistrationError,
    verify_production_preregistration,
)
from .production_workflow import (
    ProductionWorkflowError,
    predict_manifest_cases,
)
from .runner import BenchmarkRunConfig
from .stage_cache import StageCacheError


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m agentdebug.benchmark.prediction_worker",
        description="Run semantic prediction from a gold-free JudgeView manifest.",
    )
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--cache-dir", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--run-metadata", required=True)
    parser.add_argument(
        "--judge-provider",
        choices=("openai-compatible", "gemini-generate-content"),
        required=True,
    )
    parser.add_argument("--judge-base-url", required=True)
    parser.add_argument("--judge-api-key-env", required=True)
    parser.add_argument("--judge-model", required=True)
    parser.add_argument("--judge-temperature", type=float, required=True)
    parser.add_argument("--judge-timeout", type=float, required=True)
    parser.add_argument("--judge-max-output-tokens", type=int, required=True)
    parser.add_argument("--judge-max-retries", type=int, required=True)
    parser.add_argument("--judge-retry-backoff", type=float, required=True)
    parser.add_argument("--cohort-sha256", required=True)
    parser.add_argument("--preregistration")
    parser.add_argument("--max-logical-completions", type=int)
    parser.add_argument("--retry-failures", action="store_true")
    return parser


def _run(args: argparse.Namespace) -> dict:
    judge_class = (
        GeminiGenerateContentJudge
        if args.judge_provider == "gemini-generate-content"
        else OpenAICompatibleJudge
    )
    judge = judge_class(
        base_url=args.judge_base_url,
        api_key_env=args.judge_api_key_env,
        model=args.judge_model,
        temperature=args.judge_temperature,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
    )
    config = BenchmarkRunConfig(
        model=args.judge_model,
        temperature=args.judge_temperature,
        provider=args.judge_provider,
        endpoint=judge.endpoint,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
        cohort_sha256=args.cohort_sha256,
        api_key_env=args.judge_api_key_env,
    )
    if args.preregistration:
        if args.max_logical_completions is None:
            raise PreregistrationError(
                "preregistered prediction requires a logical-call budget"
            )
        verify_production_preregistration(
            preregistration_path=args.preregistration,
            prediction_manifest_path=args.manifest,
            run_output_dir=Path(args.output).expanduser().resolve().parent,
            cache_dir=args.cache_dir,
            config=config,
            maximum_new_logical_completions=(
                args.max_logical_completions
            ),
        )
    state = {"completed": 0}

    def progress(row):
        state["completed"] += 1
        print(
            f"[predict {state['completed']}] {row['trajectory_id']} "
            f"{row['status']}",
            flush=True,
        )

    rows, metadata = predict_manifest_cases(
        manifest_path=args.manifest,
        judge=judge,
        config=config,
        cache_dir=args.cache_dir,
        unscored_output_path=args.output,
        predict_run_metadata_path=args.run_metadata,
        retry_failures=args.retry_failures,
        max_logical_completions=args.max_logical_completions,
        on_result=progress,
    )
    return {
        "prediction_count": len(rows),
        "unscored_predictions_sha256": metadata[
            "unscored_predictions_sha256"
        ],
        "predict_run_sha256": metadata["predict_run_sha256"],
        "provider_telemetry": metadata["provider_telemetry"],
    }


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        result = _run(args)
    except (
        OSError,
        TypeError,
        ValueError,
        PredictionManifestError,
        PreregistrationError,
        ProductionWorkflowError,
        StageCacheError,
    ) as error:
        print(f"agentdebug-prediction-worker: {error}", file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

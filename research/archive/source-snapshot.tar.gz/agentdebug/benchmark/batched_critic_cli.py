"""Safe CLI boundary for the E9-v54 contradiction-first planning experiment.

The command split is part of the gold-isolation contract:

* ``plan`` reads only the gold-free prediction manifest;
* ``freeze-predecessor`` verifies the immutable v13 full30 stage cache;
* ``predict`` accepts no dataset, cohort, label, or scored artifact;
* ``score`` validates the raw semantic chain before loading released gold.

Every command that consumes an upstream semantic result names its mode
explicitly.  Tuning reuses a hash-locked v13 predecessor, while held-out
smoke creates fresh Scout and Arbiter results before candidate and Selector. The
two modes have disjoint, fail-closed path contracts; there is no implicit
fallback from fresh execution to the frozen tuning cache.

The batched-Critic workflow and preregistration modules are imported lazily. Their
public call sites are deliberately concentrated in this module so the CLI can
fail closed while those APIs evolve without weakening its argument boundary.
"""

from __future__ import annotations

import argparse
import importlib
import json
import os
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from types import ModuleType, SimpleNamespace
from typing import Any, Callable, Mapping, Sequence


V14_FIXED_PROVIDER = "openai-compatible"
V14_FIXED_BASE_URL = "https://api.deepseek.com/v1/chat/completions"
V14_FIXED_API_KEY_ENV = "DEEPSEEK_API_KEY"
V14_FIXED_MODEL = "deepseek-v4-flash"
V14_FIXED_TEMPERATURE = 0.0
V14_FIXED_THINKING_MODE = None
V14_FIXED_REQUEST_BODY_MODE = "default"
V14_FIXED_TIMEOUT = 600.0
V14_FIXED_MAX_OUTPUT_TOKENS = 8192
V14_FIXED_MAX_RETRIES = 5
V14_FIXED_RETRY_BACKOFF = 2.0

V14_PIPELINE_VERSION = (
    "e9-contradiction-first-planning-v54-deepseek-v4-flash-default"
)
V14_PROMPT_PROTOCOL_VERSION = (
    "agentdebug-e9-candidate-v54-contradiction-first-planning-source-id"
)
V14_SELECTOR_PROMPT_PROTOCOL_VERSION = (
    "agentdebug-e9-selector-v54-local-contradiction-precedence-source-id"
)
V14_SEMANTIC_CLASSIFIER = "raw_independent_batch_selector_output"
V14_CRITIC_STAGE = "batched_causal_critic"
V14_SELECTOR_STAGE = "batched_causal_selector"

V14_UPSTREAM_FROZEN = "frozen_v13_tuning"
V14_UPSTREAM_FRESH = "fresh_four_stage_smoke"
V14_UPSTREAM_MODES = (V14_UPSTREAM_FROZEN, V14_UPSTREAM_FRESH)


class BatchedCriticCLIError(ValueError):
    """One deliberately safe, user-facing CLI boundary failure."""


class _SafeArgumentParser(argparse.ArgumentParser):
    """Avoid echoing arbitrary rejected values in parser errors."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        kwargs.setdefault("allow_abbrev", False)
        super().__init__(*args, **kwargs)

    def error(self, message: str) -> None:  # noqa: ARG002
        raise BatchedCriticCLIError("invalid command arguments")


@dataclass(frozen=True)
class _WorkflowAPI:
    """Lazy public adapter for :mod:`batched_critic_workflow`."""

    freeze_predecessor: Callable[..., Mapping[str, Any]]
    load_batch_plan: Callable[..., Any]
    predict: Callable[..., Any]
    validate_artifacts: Callable[..., Any]
    score: Callable[..., Any]
    experiment: str
    pipeline_version: str
    prompt_protocol_version: str
    semantic_classifier: str


@dataclass(frozen=True)
class _PreregistrationAPI:
    """Lazy public adapter for v54 preregistration and promotion."""

    frozen_gate: Callable[..., Mapping[str, Any]]
    write_code_bundle: Callable[..., Mapping[str, Any]]
    write: Callable[..., Mapping[str, Any]]
    verify: Callable[..., Mapping[str, Any]]
    verify_promotion: Callable[..., Mapping[str, Any]]


def _module(name: str) -> ModuleType:
    try:
        return importlib.import_module(name)
    except (ImportError, AttributeError) as error:
        raise BatchedCriticCLIError(
            "required v54 implementation API is unavailable"
        ) from error


def _callable(module: ModuleType, name: str) -> Callable[..., Any]:
    value = getattr(module, name, None)
    if not callable(value):
        raise BatchedCriticCLIError(
            "required v54 implementation API is unavailable"
        )
    return value


def _workflow_api() -> _WorkflowAPI:
    """Resolve all workflow integration points in one lazy adapter."""

    workflow = _module("agentdebug.benchmark.batched_critic_workflow")
    diagnostics = _module("agentdebug.diagnostics.batched_critic_judge")
    pipeline = getattr(
        diagnostics,
        "BATCHED_CRITIC_PIPELINE_VERSION",
        None,
    )
    prompt = getattr(
        diagnostics,
        "BATCHED_CRITIC_PROMPT_PROTOCOL_VERSION",
        None,
    )
    selector_prompt = getattr(
        diagnostics,
        "BATCHED_SELECTOR_PROMPT_PROTOCOL_VERSION",
        None,
    )
    classifier = getattr(workflow, "V14_SEMANTIC_CLASSIFIER", None)
    if (
        pipeline != V14_PIPELINE_VERSION
        or prompt != V14_PROMPT_PROTOCOL_VERSION
        or selector_prompt != V14_SELECTOR_PROMPT_PROTOCOL_VERSION
        or classifier != V14_SEMANTIC_CLASSIFIER
        or getattr(workflow, "V14_CRITIC_STAGE", None)
        != V14_CRITIC_STAGE
        or getattr(workflow, "V14_SELECTOR_STAGE", None)
        != V14_SELECTOR_STAGE
    ):
        raise BatchedCriticCLIError(
            "v54 judge and workflow protocol identities diverged"
        )
    return _WorkflowAPI(
        freeze_predecessor=_callable(
            workflow,
            "freeze_batched_critic_predecessor",
        ),
        load_batch_plan=_callable(
            workflow,
            "load_batched_critic_batch_plan",
        ),
        predict=_callable(workflow, "predict_batched_critic_cases"),
        validate_artifacts=_callable(
            workflow,
            "validate_batched_critic_artifacts",
        ),
        score=_callable(
            workflow,
            "score_batched_critic_predictions",
        ),
        experiment=str(getattr(workflow, "V14_EXPERIMENT")),
        pipeline_version=pipeline,
        prompt_protocol_version=prompt,
        semantic_classifier=classifier,
    )


def _preregistration_api() -> _PreregistrationAPI:
    """Resolve all preregistration integration points lazily."""

    preregistration = _module(
        "agentdebug.benchmark.batched_critic_preregistration"
    )
    return _PreregistrationAPI(
        frozen_gate=_callable(
            preregistration,
            "frozen_batched_critic_promotion_gate",
        ),
        write_code_bundle=_callable(
            preregistration,
            "write_batched_critic_code_bundle_archive",
        ),
        write=_callable(
            preregistration,
            "write_batched_critic_preregistration",
        ),
        verify=_callable(
            preregistration,
            "verify_batched_critic_preregistration",
        ),
        verify_promotion=_callable(
            preregistration,
            "verify_batched_critic_promotion",
        ),
    )


def _core_api() -> SimpleNamespace:
    """Load stable shared helpers only when a command needs them."""

    causal_workflow = _module(
        "agentdebug.benchmark.batched_causal_workflow"
    )
    cohort = _module("agentdebug.benchmark.cohort")
    dataset = _module("agentdebug.benchmark.dataset")
    manifest = _module("agentdebug.benchmark.prediction_manifest")
    providers = _module("agentdebug.diagnostics.providers")
    reporting = _module("agentdebug.benchmark.reporting")
    runner = _module("agentdebug.benchmark.runner")
    judge_view = _module("agentdebug.diagnostics.judge_view")
    return SimpleNamespace(
        write_batch_plan=_callable(
            causal_workflow,
            "write_batched_causal_batch_plan",
        ),
        load_cohort_manifest=_callable(cohort, "load_cohort_manifest"),
        load_dataset=_callable(dataset, "load_agent_error_bench"),
        load_prediction_manifest=_callable(
            manifest,
            "load_prediction_manifest",
        ),
        OpenAICompatibleJudge=getattr(
            providers,
            "OpenAICompatibleJudge",
        ),
        resolve_judge_endpoint=_callable(
            providers,
            "resolve_judge_endpoint",
        ),
        write_outputs=_callable(reporting, "write_outputs"),
        BenchmarkRunConfig=getattr(runner, "BenchmarkRunConfig"),
        transport_policy_version=getattr(
            runner,
            "TRANSPORT_POLICY_VERSION",
        ),
        judge_view_version=getattr(judge_view, "JUDGE_VIEW_VERSION"),
    )


def _provider_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--judge-provider", required=True)
    parser.add_argument("--judge-base-url", required=True)
    parser.add_argument("--judge-api-key-env", required=True)
    parser.add_argument("--judge-model", required=True)
    parser.add_argument("--judge-temperature", type=float, required=True)
    parser.add_argument("--judge-timeout", type=float, required=True)
    parser.add_argument(
        "--judge-max-output-tokens",
        type=int,
        required=True,
    )
    parser.add_argument("--judge-max-retries", type=int, required=True)
    parser.add_argument(
        "--judge-retry-backoff",
        type=float,
        required=True,
    )


def _selection_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--trajectory-id",
        action="append",
        default=[],
        help=(
            "Select a manifest trajectory; repeat as needed. Selection "
            "always follows frozen manifest order."
        ),
    )


def _predecessor_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--predecessor-manifest")
    parser.add_argument(
        "--source-batch-plan",
        help=(
            "The unique frozen v13 full30 plan bound by the predecessor; "
            "this differs from a dry execution --batch-plan."
        ),
    )
    parser.add_argument("--source-cache-dir")


def _upstream_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--upstream-mode",
        choices=V14_UPSTREAM_MODES,
        required=True,
        help=(
            "Use a hash-locked v13 tuning predecessor or execute fresh "
            "Scout and Arbiter stages for held-out smoke."
        ),
    )
    _predecessor_arguments(parser)
    parser.add_argument("--fresh-upstream-cache-dir")
    parser.add_argument("--critic-cache-dir", required=True)


def _parser() -> argparse.ArgumentParser:
    parser = _SafeArgumentParser(
        prog="python -m agentdebug.benchmark.batched_critic_cli",
        description=(
            "Plan, freeze, preregister, predict, and independently score "
            "the gold-isolated E9-v54 Flash contradiction-first experiment."
        ),
    )
    commands = parser.add_subparsers(dest="command", required=True)

    plan = commands.add_parser(
        "plan",
        help="Write a deterministic gold-free v13-format batch plan.",
    )
    plan.add_argument("--prediction-manifest", required=True)
    plan.add_argument("--output", required=True)
    plan.add_argument("--required-prefix-plan")
    _selection_arguments(plan)

    freeze = commands.add_parser(
        "freeze-predecessor",
        help=(
            "Verify all 22 v13 full30 stage artifacts and write one "
            "immutable 11-batch predecessor manifest without provider calls."
        ),
    )
    freeze.add_argument("--prediction-manifest", required=True)
    freeze.add_argument("--batch-plan", required=True)
    freeze.add_argument("--source-cache-dir", required=True)
    freeze.add_argument("--output", required=True)

    freeze_code = commands.add_parser(
        "freeze-code-bundle",
        help=(
            "Write and byte-verify the deterministic v54 source archive "
            "before preregistration."
        ),
    )
    freeze_code.add_argument("--output", required=True)

    preregister = commands.add_parser(
        "preregister",
        help=(
            "Freeze v54 inputs, code, paths, gate, provider, and exact "
            "logical-completion budget."
        ),
    )
    preregister.add_argument("--experiment-name", required=True)
    preregister.add_argument("--dataset", required=True)
    preregister.add_argument("--cohort-manifest", required=True)
    preregister.add_argument("--prediction-manifest", required=True)
    preregister.add_argument("--batch-plan", required=True)
    _upstream_arguments(preregister)
    preregister.add_argument("--run-output-dir", required=True)
    preregister.add_argument("--code-bundle-archive", required=True)
    preregister.add_argument("--output", required=True)
    preregister.add_argument("--selection-rule", required=True)
    preregister.add_argument("--hypothesis", required=True)
    preregister.add_argument(
        "--gate-profile",
        choices=("dry3", "full30", "smoke30"),
        required=True,
    )
    preregister.add_argument(
        "--cumulative-logical-completions-before",
        type=int,
        required=True,
    )
    preregister.add_argument(
        "--maximum-new-logical-completions",
        type=int,
        required=True,
    )
    _selection_arguments(preregister)
    _provider_arguments(preregister)

    predict = commands.add_parser(
        "predict",
        help=(
            "Run v54 from gold-free artifacts only; no dataset, cohort, "
            "label, gold, or scored-artifact argument is accepted."
        ),
    )
    predict.add_argument("--prediction-manifest", required=True)
    predict.add_argument("--batch-plan", required=True)
    _upstream_arguments(predict)
    predict.add_argument("--output", required=True)
    predict.add_argument("--run-metadata", required=True)
    predict.add_argument("--preregistration", required=True)
    predict.add_argument(
        "--max-logical-completions",
        type=int,
        required=True,
    )
    _selection_arguments(predict)
    _provider_arguments(predict)

    score = commands.add_parser(
        "score",
        help=(
            "Validate the closed raw v54 chain first, then load released "
            "benchmark labels and write standard metrics."
        ),
    )
    score.add_argument("--dataset", required=True)
    score.add_argument("--cohort-manifest", required=True)
    score.add_argument("--prediction-manifest", required=True)
    score.add_argument("--batch-plan", required=True)
    _upstream_arguments(score)
    score.add_argument("--unscored-predictions", required=True)
    score.add_argument("--predict-run", required=True)
    score.add_argument("--output-dir", required=True)

    gate = commands.add_parser(
        "verify-gate",
        help="Apply the write-once v54 promotion gate to scored artifacts.",
    )
    gate.add_argument("--preregistration", required=True)
    gate.add_argument("--predictions", required=True)
    gate.add_argument("--metrics", required=True)
    gate.add_argument("--predict-run", required=True)
    gate.add_argument("--output", required=True)
    return parser


def _validate_fixed_provider(args: argparse.Namespace) -> None:
    expected = {
        "judge_provider": V14_FIXED_PROVIDER,
        "judge_base_url": V14_FIXED_BASE_URL,
        "judge_api_key_env": V14_FIXED_API_KEY_ENV,
        "judge_model": V14_FIXED_MODEL,
        "judge_temperature": V14_FIXED_TEMPERATURE,
        "judge_timeout": V14_FIXED_TIMEOUT,
        "judge_max_output_tokens": V14_FIXED_MAX_OUTPUT_TOKENS,
        "judge_max_retries": V14_FIXED_MAX_RETRIES,
        "judge_retry_backoff": V14_FIXED_RETRY_BACKOFF,
    }
    if any(getattr(args, key, None) != value for key, value in expected.items()):
        raise BatchedCriticCLIError(
            "provider arguments do not match the frozen E9-v54 configuration"
        )


def _validate_upstream_paths(args: argparse.Namespace) -> dict[str, Any]:
    """Validate and normalize the disjoint upstream-mode path contract.

    Returning both families with explicit ``None`` values keeps every lazy
    integration call structurally identical.  The workflow and
    preregistration layers independently repeat these checks against their
    frozen artifacts; the CLI check exists to reject ambiguous invocations
    before loading a provider or reading any benchmark labels.
    """

    mode = getattr(args, "upstream_mode", None)
    frozen_values = {
        "source_batch_plan_path": getattr(args, "source_batch_plan", None),
        "v13_predecessor_manifest_path": getattr(
            args,
            "predecessor_manifest",
            None,
        ),
        "source_cache_dir": getattr(args, "source_cache_dir", None),
    }
    fresh_cache = getattr(args, "fresh_upstream_cache_dir", None)
    critic_cache = getattr(args, "critic_cache_dir", None)

    if mode == V14_UPSTREAM_FROZEN:
        if not all(frozen_values.values()) or fresh_cache is not None:
            raise BatchedCriticCLIError(
                "frozen upstream mode requires only its predecessor, "
                "source plan, and source cache"
            )
    elif mode == V14_UPSTREAM_FRESH:
        if fresh_cache is None or any(
            value is not None for value in frozen_values.values()
        ):
            raise BatchedCriticCLIError(
                "fresh upstream mode requires only its fresh upstream cache"
            )
    else:
        raise BatchedCriticCLIError("upstream mode is invalid")
    if critic_cache is None:
        raise BatchedCriticCLIError("critic cache is required")

    return {
        "upstream_mode": mode,
        **frozen_values,
        "fresh_upstream_cache_dir": fresh_cache,
        "critic_cache_dir": critic_cache,
    }


def _validate_profile_mode(*, profile: str, upstream_mode: str) -> None:
    expected = {
        "dry3": V14_UPSTREAM_FROZEN,
        "full30": V14_UPSTREAM_FROZEN,
        "smoke30": V14_UPSTREAM_FRESH,
    }
    if expected.get(profile) != upstream_mode:
        raise BatchedCriticCLIError(
            "evaluation profile and upstream mode are incompatible"
        )


def _ordered_selection(
    *,
    prediction_manifest_path: str,
    requested: Sequence[str],
) -> tuple[dict[str, Any], list[str]]:
    core = _core_api()
    manifest, cases = core.load_prediction_manifest(
        prediction_manifest_path
    )
    if not isinstance(manifest, Mapping):
        raise BatchedCriticCLIError("prediction manifest is invalid")
    if not requested:
        return dict(manifest), [case.trajectory_id for case in cases]
    requested_list = list(requested)
    requested_set = set(requested_list)
    selected = [
        case.trajectory_id
        for case in cases
        if case.trajectory_id in requested_set
    ]
    if (
        len(requested_set) != len(requested_list)
        or len(selected) != len(requested_list)
    ):
        raise BatchedCriticCLIError(
            "trajectory selection is duplicated or absent from the manifest"
        )
    return dict(manifest), selected


def _required(
    value: Mapping[str, Any],
    key: str,
    *,
    location: str,
) -> Any:
    if key not in value:
        raise BatchedCriticCLIError(
            f"{location} omits required field {key!r}"
        )
    return value[key]


def _config_from_args(
    args: argparse.Namespace,
    *,
    endpoint: str,
    cohort_sha256: str,
) -> Any:
    core = _core_api()
    return core.BenchmarkRunConfig(
        model=args.judge_model,
        temperature=args.judge_temperature,
        provider=args.judge_provider,
        endpoint=endpoint,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
        cohort_sha256=cohort_sha256,
        api_key_env=args.judge_api_key_env,
        thinking_mode=V14_FIXED_THINKING_MODE,
        request_body_mode=V14_FIXED_REQUEST_BODY_MODE,
    )


def _judge_from_args(args: argparse.Namespace) -> Any:
    _validate_fixed_provider(args)
    core = _core_api()
    return core.OpenAICompatibleJudge(
        base_url=args.judge_base_url,
        api_key_env=args.judge_api_key_env,
        model=args.judge_model,
        temperature=args.judge_temperature,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
        thinking_mode=V14_FIXED_THINKING_MODE,
        request_body_mode=V14_FIXED_REQUEST_BODY_MODE,
    )


def _plan(args: argparse.Namespace) -> int:
    _, selected = _ordered_selection(
        prediction_manifest_path=args.prediction_manifest,
        requested=args.trajectory_id,
    )
    document = _core_api().write_batch_plan(
        prediction_manifest_path=args.prediction_manifest,
        output_path=args.output,
        selected_trajectory_ids=selected,
        required_prefix_plan_path=args.required_prefix_plan,
    )
    batches = _required(document, "batches", location="batch plan")
    if not isinstance(batches, list):
        raise BatchedCriticCLIError("batch plan batches must be a list")
    _print_json(
        {
            "output": str(Path(args.output).expanduser().resolve()),
            "batch_plan_sha256": _required(
                document,
                "batch_plan_sha256",
                location="batch plan",
            ),
            "selected_count": len(selected),
            "batch_count": len(batches),
            "required_prefix_plan": (
                str(Path(args.required_prefix_plan).expanduser().resolve())
                if args.required_prefix_plan
                else None
            ),
            "external_calls": 0,
        }
    )
    return 0


def _freeze_predecessor(args: argparse.Namespace) -> int:
    workflow = _workflow_api()
    document = workflow.freeze_predecessor(
        prediction_manifest_path=args.prediction_manifest,
        batch_plan_path=args.batch_plan,
        source_cache_dir=args.source_cache_dir,
        output_path=args.output,
    )
    batch_count = _required(
        document,
        "batch_count",
        location="predecessor manifest",
    )
    batches = _required(
        document,
        "batches",
        location="predecessor manifest",
    )
    if batch_count != 11 or not isinstance(batches, list) or len(batches) != 11:
        raise BatchedCriticCLIError(
            "predecessor must bind the unique v13 full30 eleven-batch plan"
        )
    stage_count = 0
    for batch in batches:
        stages = batch.get("stages") if isinstance(batch, Mapping) else None
        if not isinstance(stages, Mapping) or len(stages) != 2:
            raise BatchedCriticCLIError(
                "predecessor must bind exactly Scout and Arbiter per batch"
            )
        stage_count += len(stages)
    if stage_count != 22:
        raise BatchedCriticCLIError(
            "predecessor must bind exactly 22 verified v13 stages"
        )
    _print_json(
        {
            "output": str(Path(args.output).expanduser().resolve()),
            "predecessor_manifest_sha256": _required(
                document,
                "predecessor_manifest_sha256",
                location="predecessor manifest",
            ),
            "batch_count": batch_count,
            "source_stage_count": stage_count,
            "external_calls": 0,
            "gold_free": True,
        }
    )
    return 0


def _freeze_code_bundle(args: argparse.Namespace) -> int:
    binding = _preregistration_api().write_code_bundle(
        output_path=args.output,
    )
    _print_json(
        {
            "output": binding["path"],
            "archive_file_sha256": _required(
                binding,
                "file_sha256",
                location="code bundle archive",
            ),
            "code_bundle_sha256": _required(
                binding,
                "code_bundle_sha256",
                location="code bundle archive",
            ),
            "member_count": _required(
                binding,
                "member_count",
                location="code bundle archive",
            ),
            "external_calls": 0,
        }
    )
    return 0


def _preregister(args: argparse.Namespace) -> int:
    _validate_fixed_provider(args)
    upstream = _validate_upstream_paths(args)
    _validate_profile_mode(
        profile=args.gate_profile,
        upstream_mode=upstream["upstream_mode"],
    )
    manifest, selected = _ordered_selection(
        prediction_manifest_path=args.prediction_manifest,
        requested=args.trajectory_id,
    )
    core = _core_api()
    endpoint = core.resolve_judge_endpoint(
        provider=args.judge_provider,
        base_url=args.judge_base_url,
        model=args.judge_model,
    )
    config = _config_from_args(
        args,
        endpoint=endpoint,
        cohort_sha256=str(_required(
            manifest,
            "cohort_sha256",
            location="prediction manifest",
        )),
    )
    preregistration = _preregistration_api()
    gate = preregistration.frozen_gate(
        args.gate_profile,
        selected_trajectory_ids=selected,
    )
    document = preregistration.write(
        experiment_name=args.experiment_name,
        evaluation_profile=args.gate_profile,
        dataset_path=args.dataset,
        cohort_manifest_path=args.cohort_manifest,
        prediction_manifest_path=args.prediction_manifest,
        batch_plan_path=args.batch_plan,
        upstream_mode=upstream["upstream_mode"],
        source_batch_plan_path=upstream["source_batch_plan_path"],
        v13_predecessor_manifest_path=(
            upstream["v13_predecessor_manifest_path"]
        ),
        source_cache_dir=upstream["source_cache_dir"],
        fresh_upstream_cache_dir=(
            upstream["fresh_upstream_cache_dir"]
        ),
        code_bundle_archive_path=args.code_bundle_archive,
        output_path=args.output,
        run_output_dir=args.run_output_dir,
        critic_cache_dir=upstream["critic_cache_dir"],
        config=config,
        selected_trajectory_ids=selected,
        selection_rule=args.selection_rule,
        hypothesis=args.hypothesis,
        promotion_gate=gate,
        cumulative_logical_completions_before=(
            args.cumulative_logical_completions_before
        ),
        maximum_new_logical_completions=(
            args.maximum_new_logical_completions
        ),
    )
    budget = _required(
        document,
        "logical_completion_budget",
        location="preregistration",
    )
    selection = _required(
        document,
        "selection",
        location="preregistration",
    )
    _print_json(
        {
            "output": str(Path(args.output).expanduser().resolve()),
            "preregistration_sha256": _required(
                document,
                "preregistration_sha256",
                location="preregistration",
            ),
            "code_bundle_sha256": _required(
                document,
                "code_bundle_sha256",
                location="preregistration",
            ),
            "selected_count": _required(
                selection,
                "count",
                location="preregistration.selection",
            ),
            "upstream_mode": upstream["upstream_mode"],
            "hard_cumulative_stop": _required(
                budget,
                "hard_cumulative_stop",
                location="preregistration.logical_completion_budget",
            ),
            "external_calls": 0,
        }
    )
    return 0


def _predict(args: argparse.Namespace) -> int:
    _validate_fixed_provider(args)
    upstream = _validate_upstream_paths(args)
    manifest, selected = _ordered_selection(
        prediction_manifest_path=args.prediction_manifest,
        requested=args.trajectory_id,
    )
    endpoint = _core_api().resolve_judge_endpoint(
        provider=args.judge_provider,
        base_url=args.judge_base_url,
        model=args.judge_model,
    )
    config = _config_from_args(
        args,
        endpoint=endpoint,
        cohort_sha256=str(_required(
            manifest,
            "cohort_sha256",
            location="prediction manifest",
        )),
    )
    preregistration = _preregistration_api().verify(
        preregistration_path=args.preregistration,
        prediction_manifest_path=args.prediction_manifest,
        batch_plan_path=args.batch_plan,
        upstream_mode=upstream["upstream_mode"],
        source_batch_plan_path=upstream["source_batch_plan_path"],
        v13_predecessor_manifest_path=(
            upstream["v13_predecessor_manifest_path"]
        ),
        source_cache_dir=upstream["source_cache_dir"],
        fresh_upstream_cache_dir=(
            upstream["fresh_upstream_cache_dir"]
        ),
        run_output_dir=Path(args.output).expanduser().resolve().parent,
        critic_cache_dir=upstream["critic_cache_dir"],
        unscored_output_path=args.output,
        predict_run_metadata_path=args.run_metadata,
        config=config,
        selected_trajectory_ids=selected,
        maximum_new_logical_completions=args.max_logical_completions,
    )
    # Provider construction may read DEEPSEEK_API_KEY.  It happens only
    # after every code/input/cache/path/budget preregistration check succeeds.
    if not os.environ.get(args.judge_api_key_env):
        raise BatchedCriticCLIError(
            f"{args.judge_api_key_env} is not set in the current process"
        )
    judge = _judge_from_args(args)
    if getattr(judge, "endpoint", None) != endpoint:
        raise BatchedCriticCLIError(
            "provider endpoint differs from the verified configuration"
        )
    progress = {"batch": 0, "row": 0}

    def on_batch(event: Mapping[str, Any]) -> None:
        progress["batch"] += 1
        _print_progress(
            "batch",
            progress["batch"],
            event.get("batch_id"),
            event.get("status"),
        )

    def on_result(row: Mapping[str, Any]) -> None:
        progress["row"] += 1
        _print_progress(
            "row",
            progress["row"],
            row.get("trajectory_id"),
            row.get("status"),
        )

    rows, metadata = _workflow_api().predict(
        prediction_manifest_path=args.prediction_manifest,
        batch_plan_path=args.batch_plan,
        upstream_mode=upstream["upstream_mode"],
        source_batch_plan_path=upstream["source_batch_plan_path"],
        v13_predecessor_manifest_path=(
            upstream["v13_predecessor_manifest_path"]
        ),
        source_cache_dir=upstream["source_cache_dir"],
        fresh_upstream_cache_dir=(
            upstream["fresh_upstream_cache_dir"]
        ),
        critic_cache_dir=upstream["critic_cache_dir"],
        preregistration_sha256=_required(
            preregistration,
            "preregistration_sha256",
            location="preregistration",
        ),
        judge=judge,
        config=config,
        selected_trajectory_ids=selected,
        unscored_output_path=args.output,
        predict_run_metadata_path=args.run_metadata,
        max_logical_completions=args.max_logical_completions,
        logical_completion_ledger_path=_required(
            _required(
                preregistration,
                "execution",
                location="preregistration",
            ),
            "logical_completion_ledger_path",
            location="preregistration.execution",
        ),
        cumulative_logical_completions_before=_required(
            _required(
                preregistration,
                "logical_completion_budget",
                location="preregistration",
            ),
            "cumulative_before",
            location="preregistration.logical_completion_budget",
        ),
        authorized_cumulative_ceiling=_required(
            preregistration["logical_completion_budget"],
            "authorized_cumulative_ceiling",
            location="preregistration.logical_completion_budget",
        ),
        on_batch=on_batch,
        on_result=on_result,
    )
    _print_json(
        {
            "prediction_count": len(rows),
            "upstream_mode": upstream["upstream_mode"],
            "batch_count": _required(
                metadata,
                "batch_count",
                location="predict run",
            ),
            "unscored_predictions_sha256": _required(
                metadata,
                "unscored_predictions_sha256",
                location="predict run",
            ),
            "predict_run_sha256": _required(
                metadata,
                "predict_run_sha256",
                location="predict run",
            ),
            "logical_completion_budget_used": _required(
                metadata,
                "logical_completion_budget_used",
                location="predict run",
            ),
            "provider_telemetry": _required(
                metadata,
                "provider_telemetry",
                location="predict run",
            ),
            "preregistration_sha256": preregistration[
                "preregistration_sha256"
            ],
        }
    )
    return 0


def _score(args: argparse.Namespace) -> int:
    upstream = _validate_upstream_paths(args)
    workflow = _workflow_api()
    # This validation is intentionally complete before the first dataset or
    # cohort loader.  Gold cannot influence raw-chain acceptance.
    validated = workflow.validate_artifacts(
        prediction_manifest_path=args.prediction_manifest,
        batch_plan_path=args.batch_plan,
        upstream_mode=upstream["upstream_mode"],
        source_batch_plan_path=upstream["source_batch_plan_path"],
        v13_predecessor_manifest_path=(
            upstream["v13_predecessor_manifest_path"]
        ),
        source_cache_dir=upstream["source_cache_dir"],
        fresh_upstream_cache_dir=(
            upstream["fresh_upstream_cache_dir"]
        ),
        critic_cache_dir=upstream["critic_cache_dir"],
        unscored_predictions_path=args.unscored_predictions,
        predict_run_metadata_path=args.predict_run,
    )
    started = datetime.now(timezone.utc)
    core = _core_api()
    dataset = core.load_dataset(args.dataset)
    cohort = core.load_cohort_manifest(
        args.cohort_manifest,
        dataset=dataset,
    )
    predictions, metrics, predict_run = workflow.score(
        dataset=dataset,
        cohort=cohort,
        prediction_manifest_path=args.prediction_manifest,
        batch_plan_path=args.batch_plan,
        upstream_mode=upstream["upstream_mode"],
        source_batch_plan_path=upstream["source_batch_plan_path"],
        v13_predecessor_manifest_path=(
            upstream["v13_predecessor_manifest_path"]
        ),
        source_cache_dir=upstream["source_cache_dir"],
        fresh_upstream_cache_dir=(
            upstream["fresh_upstream_cache_dir"]
        ),
        critic_cache_dir=upstream["critic_cache_dir"],
        unscored_predictions_path=args.unscored_predictions,
        predict_run_metadata_path=args.predict_run,
        validated_artifacts=validated,
    )
    finished = datetime.now(timezone.utc)
    metadata = _score_run_metadata(
        args=args,
        workflow=workflow,
        dataset=dataset,
        cohort=cohort,
        predictions=predictions,
        predict_run=predict_run,
        started=started,
        finished=finished,
        core=core,
        upstream=upstream,
    )
    paths = core.write_outputs(
        output_dir=args.output_dir,
        dataset=dataset,
        predictions=predictions,
        metrics=metrics,
        run_metadata=metadata,
    )
    _print_json(paths)
    return 0


def _score_run_metadata(
    *,
    args: argparse.Namespace,
    workflow: _WorkflowAPI,
    dataset: Any,
    cohort: Any,
    predictions: Sequence[Any],
    predict_run: Mapping[str, Any],
    started: datetime,
    finished: datetime,
    core: SimpleNamespace,
    upstream: Mapping[str, Any],
) -> dict[str, Any]:
    config = _required(
        predict_run,
        "provider_config",
        location="predict run",
    )
    if not isinstance(config, Mapping):
        raise BatchedCriticCLIError(
            "predict run provider_config must be an object"
        )
    selected = list(predict_run.get("selected_trajectory_ids", ()))
    upstream_mode = str(upstream["upstream_mode"])
    is_fresh = upstream_mode == V14_UPSTREAM_FRESH
    return {
        "started_at": started.isoformat(),
        "finished_at": finished.isoformat(),
        "duration_seconds": (finished - started).total_seconds(),
        "experiment": workflow.experiment,
        "model": config.get("model"),
        "temperature": config.get("temperature"),
        "provider": config.get("provider"),
        "endpoint": config.get("endpoint"),
        "timeout": config.get("timeout"),
        "max_output_tokens": config.get("max_output_tokens"),
        "max_retries": config.get("max_retries"),
        "retry_backoff": config.get("retry_backoff"),
        "workers": 1,
        "execution_order": (
            "fresh-scout-arbiter-critic-batch-plan"
            if is_fresh
            else "frozen-v13-predecessor-critic-batch-plan"
        ),
        "upstream_mode": upstream_mode,
        "methods": ["two_stage"],
        "prompt_versions": {
            "two_stage": {"critic": workflow.prompt_protocol_version}
        },
        "judge_view_version": core.judge_view_version,
        "diagnostic_pipeline_version": workflow.pipeline_version,
        "pipeline_versions": {
            "two_stage": workflow.pipeline_version,
        },
        "production_two_stage_pipeline_version": (
            workflow.pipeline_version
        ),
        "semantic_classifier": workflow.semantic_classifier,
        "transport_policy_version": core.transport_policy_version,
        "evidence_validation_version": predict_run.get(
            "evidence_validation_version"
        ),
        "provider_telemetry": predict_run.get("provider_telemetry"),
        "provider_telemetry_coverage": predict_run.get(
            "provider_telemetry_coverage"
        ),
        "provider_capabilities": predict_run.get(
            "provider_capabilities"
        ),
        "semantic_mutation_count": predict_run.get(
            "semantic_mutation_count",
            0,
        ),
        "batch_count": predict_run.get("batch_count"),
        "released_label_count": len(dataset.labels),
        "available_trajectory_count": len(dataset.examples),
        "judge_input_count": len(predictions),
        "metric_cohort_count": len(predictions),
        "prediction_count": len(predictions),
        "selection": {
            "trajectory_ids": selected,
            "cohort_manifest_path": str(cohort.path),
            "cohort_name": cohort.cohort_name,
            "cohort_sha256": cohort.cohort_sha256,
            "dataset_manifest_sha256": dataset.dataset_sha256,
            "cohort": cohort.cohort_name,
        },
        "cache_dir": str(
            Path(upstream["critic_cache_dir"]).expanduser().resolve()
        ),
        "retry_failures": bool(predict_run.get("retry_failures")),
        "resume": predict_run.get("recovery_contract") is not None,
        "max_logical_completions": predict_run.get(
            "max_logical_completions"
        ),
        "logical_completion_budget_used": predict_run.get(
            "logical_completion_budget_used"
        ),
        "preregistration": {
            "sha256": predict_run.get("preregistration_sha256")
        },
        "gold_isolation": {
            "enabled": True,
            "prediction_input_type": (
                "gold_free_complete_judge_views_plus_fresh_"
                "scout_arbiter_raw_prior_root"
                if is_fresh
                else
                "hash_locked_gold_free_complete_judge_views_plus_"
                "frozen_v13_raw_prior_root"
            ),
            "upstream_mode": upstream_mode,
            "batch_plan_is_gold_free": True,
            "provider_process_isolated_from_dataset": True,
            "unscored_persisted_before_gold_scoring": True,
            "prediction_manifest_path": str(
                Path(args.prediction_manifest).expanduser().resolve()
            ),
            "batch_plan_path": str(
                Path(args.batch_plan).expanduser().resolve()
            ),
            "source_batch_plan_path": (
                str(
                    Path(upstream["source_batch_plan_path"])
                    .expanduser()
                    .resolve()
                )
                if upstream["source_batch_plan_path"] is not None
                else None
            ),
            "predecessor_manifest_path": (
                str(
                    Path(upstream["v13_predecessor_manifest_path"])
                    .expanduser()
                    .resolve()
                )
                if upstream["v13_predecessor_manifest_path"] is not None
                else None
            ),
            "source_cache_dir": (
                str(
                    Path(upstream["source_cache_dir"])
                    .expanduser()
                    .resolve()
                )
                if upstream["source_cache_dir"] is not None
                else None
            ),
            "fresh_upstream_cache_dir": (
                str(
                    Path(upstream["fresh_upstream_cache_dir"])
                    .expanduser()
                    .resolve()
                )
                if upstream["fresh_upstream_cache_dir"] is not None
                else None
            ),
            "unscored_predictions_path": str(
                Path(args.unscored_predictions).expanduser().resolve()
            ),
            "unscored_predictions_sha256": predict_run.get(
                "unscored_predictions_sha256"
            ),
            "predict_run_metadata_path": str(
                Path(args.predict_run).expanduser().resolve()
            ),
            "predict_run_sha256": predict_run.get("predict_run_sha256"),
        },
    }


def _verify_gate(args: argparse.Namespace) -> int:
    document = _preregistration_api().verify_promotion(
        preregistration_path=args.preregistration,
        predictions_path=args.predictions,
        metrics_path=args.metrics,
        predict_run_path=args.predict_run,
        output_path=args.output,
    )
    _print_json(
        {
            "accepted": _required(
                document,
                "accepted",
                location="promotion",
            ),
            "output": str(Path(args.output).expanduser().resolve()),
            "promotion_sha256": _required(
                document,
                "promotion_sha256",
                location="promotion",
            ),
            "summary": _required(
                document,
                "summary",
                location="promotion",
            ),
        }
    )
    return 0


def _print_json(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2))


def _print_progress(
    kind: str,
    ordinal: int,
    identity: Any,
    status: Any,
) -> None:
    safe_identity = identity if isinstance(identity, str) else "<unknown>"
    safe_status = status if isinstance(status, str) else "<unknown>"
    print(
        f"[E9-v54 {kind} {ordinal}] {safe_identity} {safe_status}",
        flush=True,
    )


def _safe_failure(command: str | None, error: Exception) -> None:
    # Only errors created by this module contain deliberately public text.
    # Imported workflow/provider errors may include remote bodies, arguments,
    # or environment-derived values, so their messages are never echoed.
    message = (
        str(error)
        if isinstance(error, BatchedCriticCLIError)
        else "operation failed closed; inspect the bound local artifacts"
    )
    print(
        json.dumps(
            {
                "status": "error",
                "command": command,
                "error_type": type(error).__name__,
                "message": message,
            },
            ensure_ascii=False,
        ),
        file=sys.stderr,
    )


def main(argv: list[str] | None = None) -> int:
    args: argparse.Namespace | None = None
    try:
        args = _parser().parse_args(argv)
        if args.command == "plan":
            return _plan(args)
        if args.command == "freeze-predecessor":
            return _freeze_predecessor(args)
        if args.command == "freeze-code-bundle":
            return _freeze_code_bundle(args)
        if args.command == "preregister":
            return _preregister(args)
        if args.command == "predict":
            return _predict(args)
        if args.command == "score":
            return _score(args)
        if args.command == "verify-gate":
            return _verify_gate(args)
        raise BatchedCriticCLIError("unsupported E9-v54 command")
    except Exception as error:  # noqa: BLE001 - security boundary
        _safe_failure(getattr(args, "command", None), error)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

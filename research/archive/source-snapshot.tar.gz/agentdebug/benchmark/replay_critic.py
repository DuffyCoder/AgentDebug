"""Gold-isolated critic replay for controlled tuning experiments.

The workflow is intentionally split:

``prepare_replay_inputs`` may read benchmark examples and a prior scored
artifact, but writes a strictly whitelisted, gold-free manifest.
``predict_replay`` reads only that manifest and calls only the semantic critic.
``score_replay`` joins the already persisted unscored predictions with gold.

This module is an experiment harness.  It does not replace the production E5
pipeline and its results must not be reported as the benchmark ``two_stage``
method.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Mapping, Sequence

from agentdebug.diagnostics import (
    DIAGNOSTIC_PIPELINE_VERSION,
    EVIDENCE_VALIDATION_VERSION,
    HANDOFF_PIPELINE_VERSION,
    HANDOFF_PROMPT_PROTOCOL_VERSION,
    JUDGE_VIEW_VERSION,
    AgentModule,
    CriticRequest,
    ErrorType,
    JudgeOutputError,
    JudgeTransportError,
    ModuleFinding,
    ModuleSpecialistResult,
    RootCauseJudgment,
)
from agentdebug.diagnostics.parsing import parse_root, parse_specialist
from agentdebug.diagnostics.prompts import (
    PROMPT_PROTOCOL_VERSION,
    critic_messages,
)
from agentdebug.diagnostics.validator import validate_evidence
from agentdebug.trace import CanonicalTrace, IntegrityStatus, validate_trace

from .cohort import CohortManifest
from .metrics import compute_metrics
from .models import BenchmarkDataset
from .runner import (
    TRANSPORT_POLICY_VERSION,
    BenchmarkRunConfig,
    _apply_root,
    _base_record,
)


REPLAY_INPUT_SCHEMA_VERSION = (
    "agentdebug.benchmark.e5a-critic-replay-input.v1"
)
REPLAY_PREDICTION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e5a-critic-replay-prediction.v1"
)
REPLAY_PIPELINE_VERSION = "e5a_frozen_intermediates_current_critic_v1"
REPLAY_METHOD = "e5a_replay_critic"
REPLAY_RUN_SCHEMA_VERSION = "agentdebug.benchmark.e5a-predict-run.v1"
AUDIT_REPLAY_METHOD = "e5b_explicit_audit_replay"
AUDIT_REPLAY_PREDICTION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e5b-explicit-audit-replay-prediction.v1"
)
AUDIT_REPLAY_PIPELINE_VERSION = (
    "e5b_frozen_intermediates_explicit_adversarial_audit_v1"
)
AUDIT_PROMPT_PROTOCOL_VERSION = (
    f"agentdebug-e5b-v1-{JUDGE_VIEW_VERSION}-explicit-adversarial-audit"
)
AUDIT_REPLAY_RUN_SCHEMA_VERSION = "agentdebug.benchmark.e5b-predict-run.v1"
HANDOFF_REPLAY_METHOD = "e5c_handoff_selector_replay"
HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e5c-handoff-selector-replay-prediction.v2"
)
HANDOFF_REPLAY_PIPELINE_VERSION = HANDOFF_PIPELINE_VERSION
HANDOFF_REPLAY_RUN_SCHEMA_VERSION = (
    "agentdebug.benchmark.e5c-predict-run.v2"
)
REPLAY_METHOD_CONTRACTS: dict[str, dict[str, Any]] = {
    REPLAY_METHOD: {
        "prediction_schema_version": REPLAY_PREDICTION_SCHEMA_VERSION,
        "replay_pipeline_version": REPLAY_PIPELINE_VERSION,
        "prompt_protocol_version": PROMPT_PROTOCOL_VERSION,
        "predict_run_schema_version": REPLAY_RUN_SCHEMA_VERSION,
        "raw_stage": "critic",
        "selection_name": "e5a_frozen_e4_tuning_dry3",
        "logical_completions_per_prediction": 1,
    },
    AUDIT_REPLAY_METHOD: {
        "prediction_schema_version": (
            AUDIT_REPLAY_PREDICTION_SCHEMA_VERSION
        ),
        "replay_pipeline_version": AUDIT_REPLAY_PIPELINE_VERSION,
        "prompt_protocol_version": AUDIT_PROMPT_PROTOCOL_VERSION,
        "predict_run_schema_version": AUDIT_REPLAY_RUN_SCHEMA_VERSION,
        "raw_stage": "explicit_audit",
        "selection_name": "e5b_frozen_e4_tuning_dry3",
        "logical_completions_per_prediction": 1,
    },
    HANDOFF_REPLAY_METHOD: {
        "prediction_schema_version": (
            HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION
        ),
        "replay_pipeline_version": HANDOFF_REPLAY_PIPELINE_VERSION,
        "prompt_protocol_version": HANDOFF_PROMPT_PROTOCOL_VERSION,
        "predict_run_schema_version": HANDOFF_REPLAY_RUN_SCHEMA_VERSION,
        "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
        "raw_stage": "handoff_selector",
        "selection_name": "e5c_frozen_e4_tuning_dry3",
        "logical_completions_per_prediction": 2,
    },
}
REPLAY_SCORABLE_METHODS = set(REPLAY_METHOD_CONTRACTS)
EXPECTED_RAW_STAGES = tuple(
    f"specialist.{module.value}" for module in AgentModule
) + ("arbiter",)


class CriticReplayError(ValueError):
    """A replay artifact is unsafe, inconsistent, or corrupt."""


_FORBIDDEN_KEYS = {
    "all_correct",
    "confidence",
    "critical_failure_module",
    "critical_failure_step",
    "critical_failure_type",
    "gold_error_type",
    "gold_event_id",
    "gold_module",
    "gold_normalization_notes",
    "gold_raw_error_type",
    "gold_raw_module",
    "gold_reasoning",
    "gold_step",
    "predicted_error_type",
    "predicted_event_id",
    "predicted_module",
    "predicted_step",
    "score",
    "step_annotations",
    "step_exact",
    "step_module_exact",
}


def replay_method_contract(method: str) -> dict[str, Any]:
    """Return the immutable artifact contract for one replay method."""

    try:
        return dict(REPLAY_METHOD_CONTRACTS[method])
    except KeyError:
        raise CriticReplayError(
            f"unsupported replay method: {method!r}"
        ) from None


def _canonical_json(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    ).encode("utf-8")


def _sha256_value(value: Any) -> str:
    return hashlib.sha256(_canonical_json(value)).hexdigest()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def replay_artifact_sha256(path: str | Path) -> str:
    """Return the byte-exact SHA-256 used to bind replay artifacts."""

    return _sha256_file(Path(path).expanduser().resolve())


def _atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(text, encoding="utf-8")
    temporary.replace(path)


def _atomic_write_json(path: Path, value: Any) -> None:
    _atomic_write(
        path,
        json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n",
    )


def _atomic_write_jsonl(path: Path, values: Sequence[Mapping[str, Any]]) -> None:
    _atomic_write(
        path,
        "".join(
            json.dumps(value, ensure_ascii=False, default=str) + "\n"
            for value in values
        ),
    )


def _json_safe(value: Any) -> Any:
    if isinstance(value, str):
        return value
    try:
        return json.loads(json.dumps(value, ensure_ascii=False, default=str))
    except (TypeError, ValueError):
        return repr(value)


def _assert_gold_free(value: Any, *, location: str) -> None:
    if isinstance(value, Mapping):
        forbidden = sorted(
            str(key)
            for key in value
            if str(key).casefold() in _FORBIDDEN_KEYS
            or str(key).casefold().startswith("gold_")
        )
        if forbidden:
            raise CriticReplayError(
                f"{location} contains forbidden scored/gold keys: "
                + ", ".join(forbidden)
            )
        for key, item in value.items():
            _assert_gold_free(item, location=f"{location}.{key}")
    elif isinstance(value, list):
        for index, item in enumerate(value):
            _assert_gold_free(item, location=f"{location}[{index}]")


def _document_with_hash(
    document: Mapping[str, Any],
    *,
    hash_field: str,
) -> dict[str, Any]:
    result = dict(document)
    result.pop(hash_field, None)
    result[hash_field] = _sha256_value(result)
    return result


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    values: list[dict[str, Any]] = []
    for line_number, line in enumerate(
        path.read_text(encoding="utf-8").splitlines(),
        1,
    ):
        if not line.strip():
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError as error:
            raise CriticReplayError(
                f"{path}:{line_number} is invalid JSON: {error}"
            ) from error
        if not isinstance(value, dict):
            raise CriticReplayError(
                f"{path}:{line_number} must contain a JSON object"
            )
        values.append(value)
    return values


def _module_analysis_from_dict(
    value: Mapping[str, Any],
) -> ModuleSpecialistResult:
    module = AgentModule(value["module"])
    findings = []
    for item in value.get("findings", []):
        findings.append(
            ModuleFinding(
                step=int(item["step"]),
                event_id=str(item["event_id"]),
                module=AgentModule(item["module"]),
                error_type=ErrorType(item["error_type"]),
                evidence_event_ids=[
                    str(event_id)
                    for event_id in item.get("evidence_event_ids", [])
                ],
                evidence_quote=str(item["evidence_quote"]),
                reasoning=str(item["reasoning"]),
            )
        )
    return ModuleSpecialistResult(module=module, findings=findings)


def _root_from_dict(value: Mapping[str, Any]) -> RootCauseJudgment:
    return RootCauseJudgment(
        critical_event_id=str(value["critical_event_id"]),
        critical_step=int(value["critical_step"]),
        module=AgentModule(value["module"]),
        error_type=ErrorType(value["error_type"]),
        root_cause=str(value["root_cause"]),
        evidence_quote=str(value["evidence_quote"]),
        evidence_event_ids=[
            str(event_id) for event_id in value.get("evidence_event_ids", [])
        ],
    )


def prepare_replay_inputs(
    *,
    dataset: BenchmarkDataset,
    cohort: CohortManifest,
    source_predictions_path: str | Path,
    expected_source_sha256: str,
    expected_source_prompt_version: str,
    output_path: str | Path,
    expected_count: int = 3,
) -> dict[str, Any]:
    """Create one hash-locked, gold-free replay manifest.

    The prior scored rows are never copied.  Only their trajectory identity,
    source hash, source prompt version, and exact six raw semantic stages are
    read, validated, and converted to public diagnostic contracts.
    """

    source_path = Path(source_predictions_path).expanduser().resolve()
    output = Path(output_path).expanduser().resolve()
    actual_source_sha256 = _sha256_file(source_path)
    if actual_source_sha256 != expected_source_sha256:
        raise CriticReplayError(
            "source predictions SHA-256 does not match the frozen value"
        )
    rows = _read_jsonl(source_path)
    if len(rows) != expected_count:
        raise CriticReplayError(
            f"source predictions must contain exactly {expected_count} rows"
        )

    by_id = {
        example.label.trajectory_id: example for example in dataset.examples
    }
    cohort_ids = set(cohort.trajectory_ids)
    seen: set[str] = set()
    entries: list[dict[str, Any]] = []
    for row in rows:
        trajectory_id = row.get("trajectory_id")
        if not isinstance(trajectory_id, str) or not trajectory_id:
            raise CriticReplayError(
                "source prediction trajectory_id must be non-empty text"
            )
        if trajectory_id in seen:
            raise CriticReplayError(
                f"duplicate replay trajectory_id: {trajectory_id}"
            )
        seen.add(trajectory_id)
        if trajectory_id not in cohort_ids:
            raise CriticReplayError(
                "source replay trajectory is outside the frozen tuning cohort"
            )
        example = by_id.get(trajectory_id)
        if example is None:
            raise CriticReplayError(
                "source replay trajectory has no canonical benchmark example"
            )
        trajectory_sha256 = row.get("trajectory_sha256")
        if trajectory_sha256 != example.mapping.trajectory_sha256:
            raise CriticReplayError(
                "source replay trajectory SHA-256 does not match adaptation"
            )
        source_prompt_version = row.get("prompt_version")
        if source_prompt_version != expected_source_prompt_version:
            raise CriticReplayError(
                "source replay prompt version does not match the frozen E4 "
                "protocol"
            )
        raw_outputs = row.get("raw_judge_outputs")
        if not isinstance(raw_outputs, Mapping):
            raise CriticReplayError(
                "source replay raw_judge_outputs must be an object"
            )
        if set(raw_outputs) != set(EXPECTED_RAW_STAGES):
            raise CriticReplayError(
                "source replay must contain exactly five specialist stages "
                "and one arbiter stage"
            )

        trace = example.trace
        integrity = validate_trace(trace, strict=False)
        if integrity.status == IntegrityStatus.FAIL:
            raise CriticReplayError(
                "source replay Canonical Trace fails the integrity gate"
            )
        analyses = [
            parse_specialist(
                raw_outputs[f"specialist.{module.value}"],
                trace,
                module,
            )
            for module in AgentModule
        ]
        initial_root = parse_root(
            raw_outputs["arbiter"],
            trace,
            stage="arbiter",
        )
        intermediate_public = {
            "module_analyses": [
                analysis.to_dict() for analysis in analyses
            ],
            "initial_root": initial_root.to_dict(),
        }
        entry: dict[str, Any] = {
            "trajectory_id": trajectory_id,
            "trajectory_sha256": trajectory_sha256,
            "source_prompt_version": source_prompt_version,
            "source_intermediates_sha256": _sha256_value(raw_outputs),
            "trace": trace.to_dict(),
            **intermediate_public,
        }
        entry["case_input_sha256"] = _sha256_value(entry)
        _assert_gold_free(entry, location="replay entry")
        entries.append(entry)

    document: dict[str, Any] = {
        "schema_version": REPLAY_INPUT_SCHEMA_VERSION,
        "replay_pipeline_version": REPLAY_PIPELINE_VERSION,
        "source_predictions_sha256": actual_source_sha256,
        "dataset_manifest_sha256": dataset.dataset_sha256,
        "parent_cohort_name": cohort.cohort_name,
        "parent_cohort_sha256": cohort.cohort_sha256,
        "entry_count": len(entries),
        "entries": entries,
    }
    document = _document_with_hash(
        document,
        hash_field="replay_manifest_sha256",
    )
    _assert_gold_free(document, location="replay manifest")
    _atomic_write_json(output, document)
    return document


def load_replay_manifest(path: str | Path) -> dict[str, Any]:
    """Load and fully verify one prepared gold-free replay manifest."""

    manifest_path = Path(path).expanduser().resolve()
    try:
        document = json.loads(manifest_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        raise CriticReplayError(
            f"invalid replay manifest JSON: {error}"
        ) from error
    if not isinstance(document, dict):
        raise CriticReplayError("replay manifest must contain a JSON object")
    if document.get("schema_version") != REPLAY_INPUT_SCHEMA_VERSION:
        raise CriticReplayError("unsupported replay manifest schema")
    if document.get("replay_pipeline_version") != REPLAY_PIPELINE_VERSION:
        raise CriticReplayError("unsupported replay input pipeline version")
    for field in (
        "source_predictions_sha256",
        "dataset_manifest_sha256",
        "parent_cohort_name",
        "parent_cohort_sha256",
    ):
        if not isinstance(document.get(field), str) or not document[field]:
            raise CriticReplayError(
                f"replay manifest {field} must be non-empty text"
            )
    claimed_hash = document.get("replay_manifest_sha256")
    expected = dict(document)
    expected.pop("replay_manifest_sha256", None)
    if claimed_hash != _sha256_value(expected):
        raise CriticReplayError("replay manifest SHA-256 is invalid")
    entries = document.get("entries")
    if (
        not isinstance(entries, list)
        or len(entries) != document.get("entry_count")
        or not entries
    ):
        raise CriticReplayError("replay manifest entries/count are invalid")
    seen: set[str] = set()
    for entry in entries:
        if not isinstance(entry, dict):
            raise CriticReplayError("replay manifest entry must be an object")
        trajectory_id = entry.get("trajectory_id")
        if (
            not isinstance(trajectory_id, str)
            or not trajectory_id
            or trajectory_id in seen
        ):
            raise CriticReplayError(
                "replay manifest trajectory IDs must be unique text"
            )
        seen.add(trajectory_id)
        case_hash = entry.get("case_input_sha256")
        body = dict(entry)
        body.pop("case_input_sha256", None)
        if case_hash != _sha256_value(body):
            raise CriticReplayError("replay case input SHA-256 is invalid")
        trace = CanonicalTrace.from_dict(entry["trace"])
        if validate_trace(trace, strict=False).status == IntegrityStatus.FAIL:
            raise CriticReplayError(
                "prepared replay Canonical Trace fails integrity"
            )
        analyses = [
            _module_analysis_from_dict(item)
            for item in entry.get("module_analyses", [])
        ]
        if [item.module for item in analyses] != list(AgentModule):
            raise CriticReplayError(
                "prepared replay module analyses are incomplete or unordered"
            )
        _root_from_dict(entry["initial_root"])
    _assert_gold_free(document, location="replay manifest")
    return document


def _request_identity(
    *,
    entry: Mapping[str, Any],
    request: CriticRequest,
    config: BenchmarkRunConfig,
    prepared_manifest_sha256: str,
) -> tuple[str, str]:
    messages = critic_messages(request)
    prompt_sha256 = _sha256_value(messages)
    identity = {
        "method": REPLAY_METHOD,
        "prediction_schema_version": REPLAY_PREDICTION_SCHEMA_VERSION,
        "replay_pipeline_version": REPLAY_PIPELINE_VERSION,
        "prepared_manifest_sha256": prepared_manifest_sha256,
        "case_input_sha256": entry["case_input_sha256"],
        "trajectory_sha256": entry["trajectory_sha256"],
        "source_intermediates_sha256": entry[
            "source_intermediates_sha256"
        ],
        "prompt_protocol_version": PROMPT_PROTOCOL_VERSION,
        "judge_view_version": JUDGE_VIEW_VERSION,
        "diagnostic_pipeline_version": DIAGNOSTIC_PIPELINE_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "prompt_sha256": prompt_sha256,
        "provider_config": config.public_dict(),
    }
    return _sha256_value(identity), prompt_sha256


def _read_raw_artifact(
    path: Path,
    *,
    request_sha256: str,
    expected_schema_version: str | None = None,
    expected_evidence_validation_version: str | None = None,
) -> Any:
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise CriticReplayError("critic raw response artifact is corrupt") from error
    if not isinstance(document, dict):
        raise CriticReplayError(
            "critic raw response artifact must contain an object"
        )
    if (
        expected_schema_version is not None
        and document.get("schema_version") != expected_schema_version
    ):
        raise CriticReplayError(
            "critic raw response artifact schema mismatch"
        )
    if (
        expected_evidence_validation_version is not None
        and document.get("evidence_validation_version")
        != expected_evidence_validation_version
    ):
        raise CriticReplayError(
            "critic raw response artifact evidence_validation_version "
            "mismatch"
        )
    if document.get("request_sha256") != request_sha256:
        raise CriticReplayError("critic raw response request hash mismatch")
    raw = document.get("raw_response")
    if document.get("response_sha256") != _sha256_value(raw):
        raise CriticReplayError("critic raw response SHA-256 mismatch")
    return raw


def _cache_record(
    path: Path,
    *,
    request_sha256: str,
    raw_path: Path,
    expected_fields: Mapping[str, Any],
) -> dict[str, Any] | None:
    if not path.is_file():
        return None
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise CriticReplayError("critic replay cache is corrupt") from error
    if not isinstance(document, dict):
        raise CriticReplayError("critic replay cache must contain an object")
    if document.get("request_sha256") != request_sha256:
        raise CriticReplayError("critic replay cache request hash mismatch")
    for field, expected in expected_fields.items():
        if document.get(field) != expected:
            raise CriticReplayError(
                f"critic replay cache {field} does not match this request"
            )
    _assert_gold_free(document, location="cached replay prediction")
    persisted_raw = _read_raw_artifact(
        raw_path,
        request_sha256=request_sha256,
        expected_schema_version=str(expected_fields["schema_version"]),
    )
    if document.get("raw_critic_output") != persisted_raw:
        raise CriticReplayError(
            "critic replay cache raw output does not match raw artifact"
        )
    if document.get("raw_response_sha256") != _sha256_value(persisted_raw):
        raise CriticReplayError(
            "critic replay cache raw response SHA-256 mismatch"
        )
    document["cache_hit"] = True
    return document


def _validate_prediction_identity(
    row: Mapping[str, Any],
    *,
    entry: Mapping[str, Any],
    manifest: Mapping[str, Any],
    method: str,
    config: BenchmarkRunConfig,
    request_sha256: str,
    prompt_sha256: str,
) -> None:
    """Validate the immutable, gold-free envelope of an unscored row."""

    contract = replay_method_contract(method)
    expected_fields = {
        "schema_version",
        "method",
        "replay_pipeline_version",
        "prepared_manifest_sha256",
        "trajectory_id",
        "trajectory_sha256",
        "case_input_sha256",
        "request_sha256",
        "prompt_sha256",
        "prompt_protocol_version",
        "judge_view_version",
        "diagnostic_pipeline_version",
        "transport_policy_version",
        "provider_config",
        "initial_root",
        "raw_critic_output",
        "raw_response_sha256",
        "root_cause",
        "evidence_validation_issues",
        "status",
        "failure_stage",
        "failure_code",
        "failure_message",
        "latency_seconds",
        "cache_hit",
    }
    if method == AUDIT_REPLAY_METHOD:
        expected_fields.update(
            {"initial_audit", "challenger", "comparison"}
        )
    if set(row) != expected_fields:
        raise CriticReplayError(
            "unscored replay prediction fields do not match its schema"
        )
    expected = {
        "schema_version": contract["prediction_schema_version"],
        "method": method,
        "replay_pipeline_version": contract["replay_pipeline_version"],
        "prepared_manifest_sha256": manifest["replay_manifest_sha256"],
        "trajectory_id": entry["trajectory_id"],
        "trajectory_sha256": entry["trajectory_sha256"],
        "case_input_sha256": entry["case_input_sha256"],
        "request_sha256": request_sha256,
        "prompt_sha256": prompt_sha256,
        "prompt_protocol_version": contract["prompt_protocol_version"],
        "judge_view_version": JUDGE_VIEW_VERSION,
        "diagnostic_pipeline_version": DIAGNOSTIC_PIPELINE_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "provider_config": config.public_dict(),
        "initial_root": entry["initial_root"],
    }
    for field, expected_value in expected.items():
        if row.get(field) != expected_value:
            raise CriticReplayError(
                f"unscored replay prediction {field} does not match "
                "its frozen request"
            )
    if not isinstance(row.get("cache_hit"), bool):
        raise CriticReplayError(
            "unscored replay prediction cache_hit must be boolean"
        )
    raw = row.get("raw_critic_output")
    if row.get("raw_response_sha256") != _sha256_value(raw):
        raise CriticReplayError(
            "unscored replay prediction raw response SHA-256 mismatch"
        )
    _assert_gold_free(row, location="unscored replay prediction")


def _e5a_parse_status(error: JudgeOutputError) -> str:
    if error.code in {"invalid_taxonomy", "invalid_taxonomy_pair"}:
        return "invalid_taxonomy"
    if error.code in {
        "malformed_json",
        "empty_response",
        "invalid_top_level",
    }:
        return "invalid_json"
    return error.code


def _validate_e5a_prediction_record(
    row: Mapping[str, Any],
    *,
    entry: Mapping[str, Any],
    manifest: Mapping[str, Any],
    request: CriticRequest,
    config: BenchmarkRunConfig,
    request_sha256: str,
    prompt_sha256: str,
) -> None:
    """Re-derive every E5a semantic field from the persisted raw output."""

    _validate_prediction_identity(
        row,
        entry=entry,
        manifest=manifest,
        method=REPLAY_METHOD,
        config=config,
        request_sha256=request_sha256,
        prompt_sha256=prompt_sha256,
    )
    raw = row.get("raw_critic_output")
    status = row.get("status")
    root_data = row.get("root_cause")

    # Transport and unexpected-provider failures have no assistant content to
    # parse. Their shape is still constrained so they cannot become scorable.
    if (
        raw is None
        and row.get("failure_stage") == "critic"
        and isinstance(row.get("failure_code"), str)
        and row.get("failure_code")
        and status not in {"success", "success_needs_review"}
    ):
        if root_data is not None or row.get("evidence_validation_issues") != []:
            raise CriticReplayError(
                "failed replay prediction contains derived semantic output"
            )
        return

    try:
        root = parse_root(raw, request.trace, stage="critic")
    except JudgeOutputError as error:
        if (
            root_data is not None
            or row.get("evidence_validation_issues") != []
            or status != _e5a_parse_status(error)
            or row.get("failure_stage") != error.stage
            or row.get("failure_code") != error.code
        ):
            raise CriticReplayError(
                "cached/scored replay parse failure does not match raw output"
            )
        return

    validation = validate_evidence(request.trace, root, stage="critic")
    expected_status = (
        "evidence_invalid"
        if not validation.valid
        else "success_needs_review"
        if validation.needs_review
        else "success"
    )
    expected_failure_stage = (
        "evidence_validation" if not validation.valid else None
    )
    expected_failure_code = "invalid_evidence" if not validation.valid else None
    if (
        root_data != root.to_dict()
        or row.get("evidence_validation_issues")
        != [issue.to_dict() for issue in validation.issues]
        or status != expected_status
        or row.get("failure_stage") != expected_failure_stage
        or row.get("failure_code") != expected_failure_code
    ):
        raise CriticReplayError(
            "cached/scored replay semantics do not match raw critic output"
        )


def predict_replay(
    *,
    manifest_path: str | Path,
    judge: Any,
    config: BenchmarkRunConfig,
    cache_dir: str | Path,
    unscored_output_path: str | Path,
    retry_failures: bool = False,
) -> list[dict[str, Any]]:
    """Call only the critic over prepared inputs and persist unscored outputs."""

    manifest = load_replay_manifest(manifest_path)
    critic = getattr(judge, "critique_root_cause", None)
    if not callable(critic):
        raise TypeError("replay judge must implement critique_root_cause(request)")
    cache_root = Path(cache_dir).expanduser().resolve()
    raw_root = cache_root / "raw_responses"
    cache_root.mkdir(parents=True, exist_ok=True)
    raw_root.mkdir(parents=True, exist_ok=True)
    unscored_path = Path(unscored_output_path).expanduser().resolve()
    results: list[dict[str, Any]] = []

    for entry in manifest["entries"]:
        trace = CanonicalTrace.from_dict(entry["trace"])
        analyses = [
            _module_analysis_from_dict(item)
            for item in entry["module_analyses"]
        ]
        initial_root = _root_from_dict(entry["initial_root"])
        request = CriticRequest(
            trace=trace,
            module_analyses=analyses,
            initial_root=initial_root,
        )
        request_sha256, prompt_sha256 = _request_identity(
            entry=entry,
            request=request,
            config=config,
            prepared_manifest_sha256=manifest["replay_manifest_sha256"],
        )
        cache_path = cache_root / f"{request_sha256}.json"
        raw_path = raw_root / f"{request_sha256}.json"
        cached = _cache_record(
            cache_path,
            request_sha256=request_sha256,
            raw_path=raw_path,
            expected_fields={
                "schema_version": REPLAY_PREDICTION_SCHEMA_VERSION,
                "method": REPLAY_METHOD,
                "replay_pipeline_version": REPLAY_PIPELINE_VERSION,
                "prepared_manifest_sha256": manifest[
                    "replay_manifest_sha256"
                ],
                "prompt_sha256": prompt_sha256,
                "prompt_protocol_version": PROMPT_PROTOCOL_VERSION,
                "provider_config": config.public_dict(),
            },
        )
        if cached is not None and (
            not retry_failures
            or str(cached.get("status", "")).startswith("success")
        ):
            _validate_e5a_prediction_record(
                cached,
                entry=entry,
                manifest=manifest,
                request=request,
                config=config,
                request_sha256=request_sha256,
                prompt_sha256=prompt_sha256,
            )
            results.append(cached)
            _atomic_write_jsonl(unscored_path, results)
            continue

        started = time.monotonic()
        failure: dict[str, Any] | None = None
        try:
            raw_response = critic(request)
        except JudgeTransportError as error:
            raw_response = None
            failure = {
                "status": error.code,
                "failure_stage": "critic",
                "failure_code": error.code,
                "failure_message": error.safe_message,
            }
        except Exception:
            raw_response = None
            failure = {
                "status": "judge_exception",
                "failure_stage": "critic",
                "failure_code": "judge_exception",
                "failure_message": (
                    "Critic judge raised an unexpected exception; its message "
                    "was omitted because it may contain sensitive data."
                ),
            }

        raw_response = _json_safe(raw_response)
        raw_document = {
            "schema_version": REPLAY_PREDICTION_SCHEMA_VERSION,
            "request_sha256": request_sha256,
            "response_sha256": _sha256_value(raw_response),
            "raw_response": raw_response,
        }
        # Raw provider output is durably written before any parsing attempt.
        _atomic_write_json(raw_path, raw_document)
        persisted_raw = _read_raw_artifact(
            raw_path,
            request_sha256=request_sha256,
            expected_schema_version=REPLAY_PREDICTION_SCHEMA_VERSION,
        )

        record: dict[str, Any] = {
            "schema_version": REPLAY_PREDICTION_SCHEMA_VERSION,
            "method": REPLAY_METHOD,
            "replay_pipeline_version": REPLAY_PIPELINE_VERSION,
            "prepared_manifest_sha256": manifest[
                "replay_manifest_sha256"
            ],
            "trajectory_id": entry["trajectory_id"],
            "trajectory_sha256": entry["trajectory_sha256"],
            "case_input_sha256": entry["case_input_sha256"],
            "request_sha256": request_sha256,
            "prompt_sha256": prompt_sha256,
            "prompt_protocol_version": PROMPT_PROTOCOL_VERSION,
            "judge_view_version": JUDGE_VIEW_VERSION,
            "diagnostic_pipeline_version": (
                DIAGNOSTIC_PIPELINE_VERSION
            ),
            "transport_policy_version": TRANSPORT_POLICY_VERSION,
            "provider_config": config.public_dict(),
            "initial_root": initial_root.to_dict(),
            "raw_critic_output": persisted_raw,
            "raw_response_sha256": _sha256_value(persisted_raw),
            "root_cause": None,
            "evidence_validation_issues": [],
            "status": None,
            "failure_stage": None,
            "failure_code": None,
            "failure_message": None,
            "latency_seconds": time.monotonic() - started,
            "cache_hit": False,
        }
        if failure is not None:
            record.update(failure)
        else:
            try:
                root = parse_root(
                    persisted_raw,
                    trace,
                    stage="critic",
                )
                validation = validate_evidence(
                    trace,
                    root,
                    stage="critic",
                )
                record["root_cause"] = root.to_dict()
                record["evidence_validation_issues"] = [
                    issue.to_dict() for issue in validation.issues
                ]
                if not validation.valid:
                    record.update(
                        {
                            "status": "evidence_invalid",
                            "failure_stage": "evidence_validation",
                            "failure_code": "invalid_evidence",
                        }
                    )
                else:
                    record["status"] = (
                        "success_needs_review"
                        if validation.needs_review
                        else "success"
                    )
            except JudgeOutputError as error:
                record.update(
                    {
                        "status": (
                            "invalid_taxonomy"
                            if error.code
                            in {"invalid_taxonomy", "invalid_taxonomy_pair"}
                            else "invalid_json"
                            if error.code
                            in {
                                "malformed_json",
                                "empty_response",
                                "invalid_top_level",
                            }
                            else error.code
                        ),
                        "failure_stage": error.stage,
                        "failure_code": error.code,
                        "failure_message": error.safe_message,
                    }
                )

        _assert_gold_free(record, location="unscored replay prediction")
        _validate_e5a_prediction_record(
            record,
            entry=entry,
            manifest=manifest,
            request=request,
            config=config,
            request_sha256=request_sha256,
            prompt_sha256=prompt_sha256,
        )
        _atomic_write_json(cache_path, record)
        results.append(record)
        _atomic_write_jsonl(unscored_path, results)

    return results


def validate_predict_run_metadata(
    metadata: Mapping[str, Any],
    *,
    manifest: Mapping[str, Any],
    manifest_path: str | Path,
    unscored_predictions_path: str | Path,
    rows: Sequence[Mapping[str, Any]],
    expected_transport_policy_version: str = TRANSPORT_POLICY_VERSION,
) -> str:
    """Bind predict-run telemetry and identity to the exact unscored file."""

    if not isinstance(metadata, Mapping):
        raise CriticReplayError("predict run metadata must be a JSON object")
    _assert_gold_free(metadata, location="predict run metadata")
    method = metadata.get("method")
    if not isinstance(method, str):
        raise CriticReplayError("predict run metadata method is missing")
    contract = replay_method_contract(method)
    expected_evidence_version = contract.get(
        "evidence_validation_version"
    )
    if (
        expected_evidence_version is not None
        and metadata.get("evidence_validation_version")
        != expected_evidence_version
    ):
        raise CriticReplayError(
            "predict run metadata evidence_validation_version mismatch: "
            f"expected {expected_evidence_version!r}"
        )
    prediction_path = Path(unscored_predictions_path).expanduser().resolve()
    prepared_path = Path(manifest_path).expanduser().resolve()
    expected = {
        "schema_version": contract["predict_run_schema_version"],
        "method": method,
        "prediction_schema_version": contract[
            "prediction_schema_version"
        ],
        "replay_pipeline_version": contract["replay_pipeline_version"],
        "prompt_protocol_version": contract["prompt_protocol_version"],
        "transport_policy_version": expected_transport_policy_version,
        "prepared_manifest_path": str(prepared_path),
        "prepared_manifest_sha256": manifest["replay_manifest_sha256"],
        "source_predictions_sha256": manifest[
            "source_predictions_sha256"
        ],
        "unscored_predictions_path": str(prediction_path),
        "unscored_predictions_sha256": _sha256_file(prediction_path),
        "prediction_count": len(rows),
        "cache_hit_count": sum(
            bool(row.get("cache_hit")) for row in rows
        ),
        "status_counts": {
            status: sum(row.get("status") == status for row in rows)
            for status in sorted({str(row.get("status")) for row in rows})
        },
    }
    if expected_evidence_version is not None:
        expected["evidence_validation_version"] = (
            expected_evidence_version
        )
    for field, expected_value in expected.items():
        if metadata.get(field) != expected_value:
            raise CriticReplayError(
                f"predict run metadata {field} does not match "
                "the frozen prediction artifact"
            )
    if any(row.get("method") != method for row in rows):
        raise CriticReplayError(
            "predict run metadata method does not match every prediction"
        )
    offline_revalidation = metadata.get("offline_revalidation")
    if offline_revalidation is not None:
        required_offline_fields = {
            "no_external_calls",
            "source_provenance_path",
            "source_provenance_sha256",
            "source_predict_run_sha256",
            "source_raw_artifact_count",
        }
        if (
            not isinstance(offline_revalidation, Mapping)
            or set(offline_revalidation) != required_offline_fields
            or offline_revalidation.get("no_external_calls") is not True
            or offline_revalidation.get("source_raw_artifact_count")
            != 2 * len(rows)
        ):
            raise CriticReplayError(
                "predict run offline revalidation metadata is invalid"
            )
        provenance_path = Path(
            str(offline_revalidation["source_provenance_path"])
        ).expanduser().resolve()
        if (
            not provenance_path.is_file()
            or _sha256_file(provenance_path)
            != offline_revalidation["source_provenance_sha256"]
        ):
            raise CriticReplayError(
                "predict run offline revalidation provenance hash mismatch"
            )
        try:
            provenance = json.loads(
                provenance_path.read_text(encoding="utf-8")
            )
        except (OSError, json.JSONDecodeError) as error:
            raise CriticReplayError(
                "predict run offline revalidation provenance is corrupt"
            ) from error
        if not isinstance(provenance, Mapping):
            raise CriticReplayError(
                "predict run offline revalidation provenance must be an "
                "object"
            )
        _assert_gold_free(
            provenance,
            location="offline revalidation provenance",
        )
        provenance_without_hash = dict(provenance)
        declared_provenance_hash = provenance_without_hash.pop(
            "revalidation_source_sha256",
            None,
        )
        if (
            provenance.get("evidence_validation_version")
            != expected_evidence_version
            or provenance.get("prepared_manifest_sha256")
            != manifest["replay_manifest_sha256"]
            or provenance.get("source_raw_artifact_count")
            != 2 * len(rows)
            or declared_provenance_hash
            != _sha256_value(provenance_without_hash)
            or provenance.get("source_predict_run_sha256")
            != offline_revalidation["source_predict_run_sha256"]
        ):
            raise CriticReplayError(
                "predict run offline revalidation provenance identity "
                "mismatch"
            )
    telemetry = metadata.get("provider_telemetry")
    if not isinstance(telemetry, Mapping):
        raise CriticReplayError(
            "predict run provider telemetry must be an object"
        )

    counters: dict[str, int] = {}
    for field in (
        "logical_completion_count",
        "http_attempt_count",
        "retry_count",
    ):
        value = telemetry.get(field)
        if (
            isinstance(value, bool)
            or not isinstance(value, int)
            or value < 0
        ):
            raise CriticReplayError(
                f"predict run provider telemetry {field} must be a "
                "non-negative integer"
            )
        counters[field] = value

    logical = counters["logical_completion_count"]
    if method == HANDOFF_REPLAY_METHOD:
        expected_logical = 0
        for row in rows:
            attempted = row.get("stage_attempted")
            hits = row.get("stage_cache_hits")
            if not isinstance(attempted, Mapping) or not isinstance(
                hits,
                Mapping,
            ):
                raise CriticReplayError(
                    "E5c prediction stage telemetry fields are missing"
                )
            expected_logical += sum(
                bool(attempted.get(stage))
                and not bool(hits.get(stage))
                for stage in ("handoff_ledger", "handoff_selector")
            )
    else:
        expected_logical = len(rows) - expected["cache_hit_count"]
    if logical != expected_logical:
        raise CriticReplayError(
            "predict run logical completion count does not match "
            "non-cached predictions"
        )

    http_attempts = counters["http_attempt_count"]
    retries = counters["retry_count"]
    if http_attempts != logical + retries:
        raise CriticReplayError(
            "predict run HTTP attempt/retry telemetry is inconsistent"
        )
    max_retries = metadata.get("max_retries")
    if (
        isinstance(max_retries, bool)
        or not isinstance(max_retries, int)
        or max_retries < 0
    ):
        raise CriticReplayError(
            "predict run max_retries must be a non-negative integer"
        )
    if retries > logical * max_retries:
        raise CriticReplayError(
            "predict run retry telemetry exceeds the configured maximum"
        )
    return method


def score_replay(
    *,
    dataset: BenchmarkDataset,
    cohort: CohortManifest,
    manifest_path: str | Path,
    unscored_predictions_path: str | Path,
    predict_run_metadata: Mapping[str, Any],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Join persisted replay predictions with gold and compute dry metrics."""

    manifest = load_replay_manifest(manifest_path)
    if dataset.dataset_sha256 != manifest["dataset_manifest_sha256"]:
        raise CriticReplayError(
            "scoring dataset does not match the frozen replay manifest"
        )
    if (
        cohort.dataset_manifest_sha256
        != manifest["dataset_manifest_sha256"]
        or cohort.cohort_sha256 != manifest["parent_cohort_sha256"]
        or cohort.cohort_name != manifest["parent_cohort_name"]
    ):
        raise CriticReplayError(
            "scoring cohort does not match the frozen replay manifest"
        )
    unscored = _read_jsonl(
        Path(unscored_predictions_path).expanduser().resolve()
    )
    for index, row in enumerate(unscored):
        _assert_gold_free(
            row,
            location=f"unscored replay prediction[{index}]",
        )
        if (
            row.get("method") == HANDOFF_REPLAY_METHOD
            and row.get("evidence_validation_version")
            != EVIDENCE_VALIDATION_VERSION
        ):
            raise CriticReplayError(
                "unscored E5c prediction evidence_validation_version "
                "mismatch"
            )
    metadata_method = validate_predict_run_metadata(
        predict_run_metadata,
        manifest=manifest,
        manifest_path=manifest_path,
        unscored_predictions_path=unscored_predictions_path,
        rows=unscored,
    )
    entries = {
        entry["trajectory_id"]: entry for entry in manifest["entries"]
    }
    if len(unscored) != len(entries):
        raise CriticReplayError(
            "unscored prediction count does not match replay manifest"
        )
    row_ids = [row.get("trajectory_id") for row in unscored]
    if len(set(row_ids)) != len(row_ids) or set(row_ids) != set(entries):
        raise CriticReplayError(
            "unscored prediction IDs do not exactly match replay manifest"
        )
    if not set(entries).issubset(set(cohort.trajectory_ids)):
        raise CriticReplayError(
            "replay predictions are outside the frozen tuning cohort"
        )
    by_id = {
        example.label.trajectory_id: example for example in dataset.examples
    }
    scored: list[dict[str, Any]] = []
    for row in unscored:
        trajectory_id = str(row["trajectory_id"])
        entry = entries[trajectory_id]
        if row.get("prepared_manifest_sha256") != manifest.get(
            "replay_manifest_sha256"
        ):
            raise CriticReplayError(
                "unscored prediction references the wrong replay manifest"
            )
        if (
            row.get("trajectory_sha256") != entry["trajectory_sha256"]
            or row.get("case_input_sha256") != entry["case_input_sha256"]
        ):
            raise CriticReplayError(
                "unscored prediction identity does not match replay input"
            )
        example = by_id.get(trajectory_id)
        if example is None:
            raise CriticReplayError(
                "unscored prediction has no benchmark example"
            )
        config_data = row.get("provider_config")
        if not isinstance(config_data, Mapping):
            raise CriticReplayError(
                "unscored prediction provider config is missing"
            )
        config = BenchmarkRunConfig(**dict(config_data))
        if config.cohort_sha256 != manifest["parent_cohort_sha256"]:
            raise CriticReplayError(
                "unscored prediction provider config uses the wrong cohort"
            )
        method = row.get("method")
        if method not in REPLAY_SCORABLE_METHODS:
            raise CriticReplayError(
                "unscored prediction uses an unsupported replay method"
            )
        if method != metadata_method:
            raise CriticReplayError(
                "unscored prediction method does not match predict metadata"
            )
        metadata_config_fields = {
            "model": config.model,
            "temperature": config.temperature,
            "provider": config.provider,
            "endpoint": config.endpoint,
            "timeout": config.timeout,
            "max_output_tokens": config.max_output_tokens,
            "max_retries": config.max_retries,
            "retry_backoff": config.retry_backoff,
        }
        for field, expected_value in metadata_config_fields.items():
            if predict_run_metadata.get(field) != expected_value:
                raise CriticReplayError(
                    f"predict run metadata {field} does not match "
                    "prediction provider config"
                )

        trace = CanonicalTrace.from_dict(entry["trace"])
        analyses = [
            _module_analysis_from_dict(item)
            for item in entry["module_analyses"]
        ]
        initial_root = _root_from_dict(entry["initial_root"])
        if method == REPLAY_METHOD:
            request = CriticRequest(
                trace=trace,
                module_analyses=analyses,
                initial_root=initial_root,
            )
            request_sha256, prompt_sha256 = _request_identity(
                entry=entry,
                request=request,
                config=config,
                prepared_manifest_sha256=manifest[
                    "replay_manifest_sha256"
                ],
            )
            _validate_e5a_prediction_record(
                row,
                entry=entry,
                manifest=manifest,
                request=request,
                config=config,
                request_sha256=request_sha256,
                prompt_sha256=prompt_sha256,
            )
        elif method == AUDIT_REPLAY_METHOD:
            from .replay_audit_critic import (
                ExplicitAuditRequest,
                _request_identity as _audit_request_identity,
                _validate_explicit_audit_prediction_record,
            )

            audit_request = ExplicitAuditRequest(
                trace=trace,
                module_analyses=analyses,
                initial_root=initial_root,
            )
            request_sha256, prompt_sha256 = _audit_request_identity(
                entry=entry,
                request=audit_request,
                config=config,
                prepared_manifest_sha256=manifest[
                    "replay_manifest_sha256"
                ],
            )
            _validate_explicit_audit_prediction_record(
                row,
                entry=entry,
                manifest=manifest,
                request=audit_request,
                config=config,
                request_sha256=request_sha256,
                prompt_sha256=prompt_sha256,
            )
        else:
            from .replay_handoff import (
                _validate_handoff_prediction_record,
            )

            _validate_handoff_prediction_record(
                row,
                entry=entry,
                manifest=manifest,
                config=config,
            )
        record = _base_record(
            example,
            method=method,
            config=config,
        )
        if method == HANDOFF_REPLAY_METHOD:
            raw_outputs = {
                "handoff_ledger": row.get(
                    "raw_handoff_ledger_output"
                ),
                "handoff_selector": row.get(
                    "raw_handoff_selector_output"
                ),
            }
        else:
            raw_outputs = {
                replay_method_contract(method)["raw_stage"]: row.get(
                    "raw_critic_output"
                )
            }
        record.update(
            {
                "status": row.get("status"),
                "failure_stage": row.get("failure_stage"),
                "failure_code": row.get("failure_code"),
                "failure_message": row.get("failure_message"),
                "evidence_validation_issues": row.get(
                    "evidence_validation_issues",
                    [],
                ),
                "raw_judge_outputs": raw_outputs,
                "latency_seconds": row.get("latency_seconds"),
                "cache_hit": row.get("cache_hit", False),
                "prompt_version": row["prompt_protocol_version"],
            }
        )
        if method == HANDOFF_REPLAY_METHOD:
            ledger_data = row.get("handoff_ledger")
            record["handoff_ledger"] = ledger_data
            candidates = (
                ledger_data.get("candidates", [])
                if isinstance(ledger_data, Mapping)
                else []
            )
            record["handoff_candidate_count"] = len(candidates)
            record["handoff_candidate_tuples"] = [
                {
                    "step": candidate.get("critical_step"),
                    "module": candidate.get("module"),
                    "error_type": candidate.get("error_type"),
                }
                for candidate in candidates
                if isinstance(candidate, Mapping)
            ]
            record["handoff_candidate_step_recall"] = any(
                candidate.get("critical_step") == example.label.original_step
                for candidate in candidates
                if isinstance(candidate, Mapping)
            )
            record["handoff_candidate_step_module_recall"] = any(
                candidate.get("critical_step") == example.label.original_step
                and candidate.get("module") == example.label.module
                for candidate in candidates
                if isinstance(candidate, Mapping)
            )
            record["candidate_evidence_validation_issues"] = row.get(
                "candidate_evidence_validation_issues",
                [],
            )
            record["stage_cache_hits"] = row.get("stage_cache_hits")
            record["stage_attempted"] = row.get("stage_attempted")
        else:
            record.update(
                {
                    "initial_predicted_step": entry["initial_root"][
                        "critical_step"
                    ],
                    "initial_predicted_module": entry["initial_root"][
                        "module"
                    ],
                    "initial_predicted_error_type": entry["initial_root"][
                        "error_type"
                    ],
                    "specialist_finding_count": sum(
                        len(item.get("findings", []))
                        for item in entry["module_analyses"]
                    ),
                    "specialist_counts_by_module": {
                        item["module"]: len(item.get("findings", []))
                        for item in entry["module_analyses"]
                    },
                }
            )
        if row.get("initial_audit") is not None:
            record["initial_audit"] = row["initial_audit"]
        if row.get("challenger") is not None:
            record["challenger"] = row["challenger"]
        if row.get("comparison") is not None:
            record["comparison"] = row["comparison"]
        root_data = row.get("root_cause")
        if isinstance(root_data, Mapping):
            _apply_root(
                record,
                example=example,
                root=_root_from_dict(root_data),
            )
            if method != HANDOFF_REPLAY_METHOD:
                record["initial_final_agree"] = (
                    entry["initial_root"]["critical_step"],
                    entry["initial_root"]["module"],
                    entry["initial_root"]["error_type"],
                ) == (
                    root_data["critical_step"],
                    root_data["module"],
                    root_data["error_type"],
                )
        scored.append(record)
    scored.sort(key=lambda item: str(item["trajectory_id"]))
    return scored, compute_metrics(scored)


def replay_provider_telemetry(judge: Any) -> dict[str, Any] | None:
    """Expose the same aggregate-only telemetry used by benchmark reports."""

    from .runner import provider_telemetry_snapshot

    return provider_telemetry_snapshot(judge)


__all__ = [
    "AUDIT_PROMPT_PROTOCOL_VERSION",
    "AUDIT_REPLAY_METHOD",
    "AUDIT_REPLAY_PIPELINE_VERSION",
    "AUDIT_REPLAY_PREDICTION_SCHEMA_VERSION",
    "AUDIT_REPLAY_RUN_SCHEMA_VERSION",
    "CriticReplayError",
    "EXPECTED_RAW_STAGES",
    "HANDOFF_PROMPT_PROTOCOL_VERSION",
    "HANDOFF_REPLAY_METHOD",
    "HANDOFF_REPLAY_PIPELINE_VERSION",
    "HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION",
    "HANDOFF_REPLAY_RUN_SCHEMA_VERSION",
    "REPLAY_INPUT_SCHEMA_VERSION",
    "REPLAY_METHOD",
    "REPLAY_METHOD_CONTRACTS",
    "REPLAY_PIPELINE_VERSION",
    "REPLAY_PREDICTION_SCHEMA_VERSION",
    "REPLAY_RUN_SCHEMA_VERSION",
    "REPLAY_SCORABLE_METHODS",
    "load_replay_manifest",
    "predict_replay",
    "prepare_replay_inputs",
    "replay_artifact_sha256",
    "replay_method_contract",
    "replay_provider_telemetry",
    "score_replay",
    "validate_predict_run_metadata",
]

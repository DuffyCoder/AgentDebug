"""Small, hash-locked preregistration and promotion gate for E9 v55."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any, Mapping, Sequence

from agentdebug.diagnostics.batched_global_judge import (
    BATCHED_GLOBAL_PIPELINE_VERSION,
    BATCHED_GLOBAL_PROMPT_PROTOCOL_VERSION,
)

from .prediction_manifest import load_prediction_manifest
from .runner import BenchmarkRunConfig
from .simple_global_workflow import (
    SIMPLE_GLOBAL_EXPERIMENT,
    SIMPLE_GLOBAL_TOPOLOGY,
    load_simple_global_batch_plan,
)
from .stage_cache import stable_sha256


SIMPLE_GLOBAL_PREREGISTRATION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-v55-preregistration.v1"
)
SIMPLE_GLOBAL_PROMOTION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e9-v55-promotion.v1"
)
_CODE_FILES = (
    "agentdebug/diagnostics/batched_global_judge.py",
    "agentdebug/benchmark/simple_global_workflow.py",
    "agentdebug/benchmark/simple_global_preregistration.py",
    "agentdebug/benchmark/simple_global_cli.py",
)


class SimpleGlobalPreregistrationError(ValueError):
    """A preregistration, frozen implementation, or gate is invalid."""


def _file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _code_snapshot() -> dict[str, str]:
    root = _repo_root()
    values: dict[str, str] = {}
    for relative in _CODE_FILES:
        path = root / relative
        if not path.is_file():
            raise SimpleGlobalPreregistrationError(
                f"frozen implementation file is missing: {relative}"
            )
        values[relative] = _file_sha256(path)
    return values


def _gate(profile: str, count: int) -> dict[str, Any]:
    if profile == "dry3":
        if count != 3:
            raise SimpleGlobalPreregistrationError("dry3 must contain three cases")
        required = 3
    elif profile in {"full30", "smoke30"}:
        if count != 30:
            raise SimpleGlobalPreregistrationError(
                f"{profile} must contain thirty cases"
            )
        required = 12
    else:
        raise SimpleGlobalPreregistrationError("unknown gate profile")
    return {
        "profile": profile,
        "metric": "Step Exact",
        "method": "two_stage",
        "semantic_topology": SIMPLE_GLOBAL_TOPOLOGY,
        "required_correct": required,
        "denominator": count,
        "invalid_outputs_count_as_incorrect": True,
    }


def write_simple_global_preregistration(
    *,
    prediction_manifest_path: str | Path,
    batch_plan_path: str | Path,
    run_output_dir: str | Path,
    cache_dir: str | Path,
    output_path: str | Path,
    config: BenchmarkRunConfig,
    gate_profile: str,
    hypothesis: str,
    selection_rule: str,
    cumulative_logical_completions_before: int,
    historical_rejection_path: str | Path | None = None,
) -> dict[str, Any]:
    """Freeze code, inputs, provider, paths, exact calls, and promotion gate."""

    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    plan_path = Path(batch_plan_path).expanduser().resolve()
    manifest, _cases = load_prediction_manifest(manifest_path)
    plan = load_simple_global_batch_plan(
        plan_path, prediction_manifest_path=manifest_path
    )
    if config.cohort_sha256 != manifest["cohort_sha256"]:
        raise SimpleGlobalPreregistrationError("provider cohort identity mismatch")
    if (
        isinstance(cumulative_logical_completions_before, bool)
        or not isinstance(cumulative_logical_completions_before, int)
        or cumulative_logical_completions_before < 0
    ):
        raise SimpleGlobalPreregistrationError("cumulative count is invalid")
    if not isinstance(hypothesis, str) or not hypothesis.strip():
        raise SimpleGlobalPreregistrationError("hypothesis is required")
    if not isinstance(selection_rule, str) or not selection_rule.strip():
        raise SimpleGlobalPreregistrationError("selection rule is required")
    maximum_new = len(plan.batches)
    run_dir = Path(run_output_dir).expanduser().resolve()
    cache = Path(cache_dir).expanduser().resolve()
    history: dict[str, Any] | None = None
    if historical_rejection_path is not None:
        history_path = Path(historical_rejection_path).expanduser().resolve()
        history = {
            "path": str(history_path),
            "file_sha256": _file_sha256(history_path),
            "role": "rejected_predecessor_result_not_semantic_input",
        }
    body: dict[str, Any] = {
        "schema_version": SIMPLE_GLOBAL_PREREGISTRATION_SCHEMA_VERSION,
        "experiment": SIMPLE_GLOBAL_EXPERIMENT,
        "pipeline_version": BATCHED_GLOBAL_PIPELINE_VERSION,
        "prompt_protocol_version": BATCHED_GLOBAL_PROMPT_PROTOCOL_VERSION,
        "semantic_topology": SIMPLE_GLOBAL_TOPOLOGY,
        "hypothesis": hypothesis.strip(),
        "selection_rule": selection_rule.strip(),
        "inputs": {
            "prediction_manifest_path": str(manifest_path),
            "prediction_manifest_file_sha256": _file_sha256(manifest_path),
            "prediction_manifest_sha256": manifest[
                "prediction_manifest_sha256"
            ],
            "batch_plan_path": str(plan_path),
            "batch_plan_file_sha256": _file_sha256(plan_path),
            "batch_plan_sha256": plan.batch_plan_sha256,
            "selected_trajectory_ids": list(plan.selected_trajectory_ids),
        },
        "implementation_sha256s": _code_snapshot(),
        "provider_config": config.public_dict(),
        "execution": {
            "run_output_dir": str(run_dir),
            "cache_dir": str(cache),
            "unscored_output_path": str(run_dir / "unscored-predictions.jsonl"),
            "predict_run_metadata_path": str(run_dir / "predict-run.json"),
            "logical_completion_ledger_path": str(
                run_dir / "logical-completion-ledger.json"
            ),
        },
        "logical_completion_budget": {
            "topology_rule": "one logical completion per uncached batch",
            "cumulative_before": cumulative_logical_completions_before,
            "maximum_new": maximum_new,
            "phase_ceiling": (
                cumulative_logical_completions_before + maximum_new
            ),
            "global_cumulative_cap": None,
        },
        "promotion_gate": _gate(
            gate_profile, len(plan.selected_trajectory_ids)
        ),
        "historical_rejection_anchor": history,
        "gold_isolation": {
            "prediction_accepts_dataset_argument": False,
            "prediction_accepts_cohort_argument": False,
            "raw_artifacts_validated_before_gold_load": True,
            "raw_llm_output_is_sole_semantic_source": True,
            "semantic_mutation_count_required": 0,
        },
    }
    body["preregistration_sha256"] = stable_sha256(body)
    _atomic_json(Path(output_path).expanduser().resolve(), body)
    return body


def verify_simple_global_preregistration(
    *,
    preregistration_path: str | Path,
    config: BenchmarkRunConfig,
    prediction_manifest_path: str | Path,
    batch_plan_path: str | Path,
    run_output_dir: str | Path,
    cache_dir: str | Path,
) -> dict[str, Any]:
    path = Path(preregistration_path).expanduser().resolve()
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise SimpleGlobalPreregistrationError("preregistration is unreadable") from error
    if not isinstance(value, Mapping):
        raise SimpleGlobalPreregistrationError("preregistration must be an object")
    result = dict(value)
    claimed = result.pop("preregistration_sha256", None)
    if claimed != stable_sha256(result):
        raise SimpleGlobalPreregistrationError("preregistration hash is invalid")
    result["preregistration_sha256"] = claimed
    if result.get("schema_version") != SIMPLE_GLOBAL_PREREGISTRATION_SCHEMA_VERSION:
        raise SimpleGlobalPreregistrationError("preregistration schema is invalid")
    inputs = result.get("inputs")
    execution = result.get("execution")
    if not isinstance(inputs, Mapping) or not isinstance(execution, Mapping):
        raise SimpleGlobalPreregistrationError("preregistration shape is invalid")
    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    plan_path = Path(batch_plan_path).expanduser().resolve()
    run_dir = Path(run_output_dir).expanduser().resolve()
    cache = Path(cache_dir).expanduser().resolve()
    checks = {
        "prediction_manifest_path": str(manifest_path),
        "prediction_manifest_file_sha256": _file_sha256(manifest_path),
        "batch_plan_path": str(plan_path),
        "batch_plan_file_sha256": _file_sha256(plan_path),
    }
    if any(inputs.get(key) != item for key, item in checks.items()):
        raise SimpleGlobalPreregistrationError("frozen input changed")
    if (
        execution.get("run_output_dir") != str(run_dir)
        or execution.get("cache_dir") != str(cache)
        or result.get("provider_config") != config.public_dict()
        or result.get("implementation_sha256s") != _code_snapshot()
    ):
        raise SimpleGlobalPreregistrationError("frozen execution changed")
    history = result.get("historical_rejection_anchor")
    if history is not None:
        if not isinstance(history, Mapping) or history.get("file_sha256") != _file_sha256(
            Path(str(history.get("path"))).resolve()
        ):
            raise SimpleGlobalPreregistrationError("historical anchor changed")
    return result


def verify_simple_global_promotion(
    *,
    preregistration_path: str | Path,
    metrics_path: str | Path,
    predictions_path: str | Path,
    output_path: str | Path,
) -> dict[str, Any]:
    """Write an immutable pass/fail decision from strict Step Exact counts."""

    prereg_path = Path(preregistration_path).expanduser().resolve()
    metrics_file = Path(metrics_path).expanduser().resolve()
    predictions_file = Path(predictions_path).expanduser().resolve()
    destination = Path(output_path).expanduser().resolve()
    if destination.exists():
        raise SimpleGlobalPreregistrationError("promotion output is write-once")
    prereg = json.loads(prereg_path.read_text(encoding="utf-8"))
    metrics_document = json.loads(metrics_file.read_text(encoding="utf-8"))
    metrics = metrics_document.get("metrics", metrics_document)
    prediction_count = len(predictions_file.read_text(encoding="utf-8").splitlines())
    gate = prereg["promotion_gate"]
    exact = metrics["by_method"]["two_stage"]["overall"]["step_exact"]
    passed = (
        exact["correct"] >= gate["required_correct"]
        and exact["denominator"] == gate["denominator"]
        and prediction_count == gate["denominator"]
    )
    body = {
        "schema_version": SIMPLE_GLOBAL_PROMOTION_SCHEMA_VERSION,
        "preregistration_sha256": prereg["preregistration_sha256"],
        "metrics_file_sha256": _file_sha256(metrics_file),
        "predictions_file_sha256": _file_sha256(predictions_file),
        "observed": {
            "correct": exact["correct"],
            "denominator": exact["denominator"],
            "prediction_count": prediction_count,
        },
        "required": gate,
        "passed": passed,
    }
    body["promotion_sha256"] = stable_sha256(body)
    _atomic_json(destination, body)
    return body


__all__ = [
    "SimpleGlobalPreregistrationError",
    "verify_simple_global_preregistration",
    "verify_simple_global_promotion",
    "write_simple_global_preregistration",
]

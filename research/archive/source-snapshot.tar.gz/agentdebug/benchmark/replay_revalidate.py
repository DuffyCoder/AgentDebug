"""Gold-free E5c revalidation from immutable historical raw responses.

This command never constructs a judge client and never loads benchmark labels.
It imports only the six hash-checked E5c raw response envelopes, rekeys them
under the current evidence-validator identity, and rebuilds every derived
unscored field by parsing and validating the raw text again.
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from agentdebug.diagnostics import (
    DIAGNOSTIC_PIPELINE_VERSION,
    EVIDENCE_VALIDATION_VERSION,
    HANDOFF_PROMPT_PROTOCOL_VERSION,
    JUDGE_VIEW_VERSION,
    JudgeOutputError,
    handoff_ledger_messages,
    handoff_selector_messages,
    parse_handoff_ledger,
    parse_handoff_selector,
)
from agentdebug.trace import CanonicalTrace

from .replay_critic import (
    CriticReplayError,
    _assert_gold_free,
    _atomic_write_json,
    _document_with_hash,
    _read_raw_artifact,
    _sha256_file,
    _sha256_value,
    load_replay_manifest,
    replay_artifact_sha256,
)
from .replay_handoff import (
    HANDOFF_REPLAY_METHOD,
    HANDOFF_REPLAY_PIPELINE_VERSION,
    HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION,
    HANDOFF_REPLAY_RUN_SCHEMA_VERSION,
    _failure_status,
    _stage_expected,
    _stage_identity,
    _validate_stage_record,
    predict_handoff_replay,
)
from .runner import BenchmarkRunConfig, TRANSPORT_POLICY_VERSION


LEGACY_HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e5c-handoff-selector-replay-prediction.v1"
)
LEGACY_HANDOFF_REPLAY_RUN_SCHEMA_VERSION = (
    "agentdebug.benchmark.e5c-predict-run.v1"
)
LEGACY_TRANSPORT_POLICY_VERSION = (
    "judge-http-json-object-v4-telemetry"
)
REVALIDATION_PROVENANCE_SCHEMA_VERSION = (
    "agentdebug.benchmark.e5c-immutable-raw-revalidation-source.v1"
)


def _read_json_object(path: Path, *, location: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise CriticReplayError(f"{location} is corrupt") from error
    if not isinstance(value, dict):
        raise CriticReplayError(f"{location} must be a JSON object")
    return value


def _legacy_config(
    metadata: Mapping[str, Any],
    *,
    manifest: Mapping[str, Any],
) -> BenchmarkRunConfig:
    """Validate the old gold-free run envelope without trusting its scores."""

    _assert_gold_free(metadata, location="legacy E5c predict run metadata")
    expected = {
        "schema_version": LEGACY_HANDOFF_REPLAY_RUN_SCHEMA_VERSION,
        "method": HANDOFF_REPLAY_METHOD,
        "prediction_schema_version": (
            LEGACY_HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION
        ),
        "replay_pipeline_version": HANDOFF_REPLAY_PIPELINE_VERSION,
        "prepared_manifest_sha256": manifest["replay_manifest_sha256"],
        "source_predictions_sha256": manifest["source_predictions_sha256"],
        "prompt_protocol_version": HANDOFF_PROMPT_PROTOCOL_VERSION,
        "transport_policy_version": LEGACY_TRANSPORT_POLICY_VERSION,
        "prediction_count": len(manifest["entries"]),
    }
    for field, value in expected.items():
        if metadata.get(field) != value:
            raise CriticReplayError(
                f"legacy E5c predict run {field} mismatch"
            )
    if "evidence_validation_version" in metadata:
        raise CriticReplayError(
            "legacy E5c source unexpectedly declares an evidence validator"
        )
    if (
        not isinstance(metadata.get("prepared_manifest_path"), str)
        or not metadata["prepared_manifest_path"]
        or not isinstance(metadata.get("cache_dir"), str)
        or not metadata["cache_dir"]
    ):
        raise CriticReplayError(
            "legacy E5c predict run source paths are missing"
        )
    try:
        return BenchmarkRunConfig(
            model=str(metadata["model"]),
            temperature=float(metadata["temperature"]),
            provider=str(metadata["provider"]),
            endpoint=str(metadata["endpoint"]),
            timeout=float(metadata["timeout"]),
            max_output_tokens=int(metadata["max_output_tokens"]),
            max_retries=int(metadata["max_retries"]),
            retry_backoff=float(metadata["retry_backoff"]),
            cohort_sha256=str(manifest["parent_cohort_sha256"]),
        )
    except (KeyError, TypeError, ValueError) as error:
        raise CriticReplayError(
            "legacy E5c provider configuration is invalid"
        ) from error


def _legacy_stage_identity(
    *,
    stage: str,
    entry: Mapping[str, Any],
    prepared_manifest_sha256: str,
    messages: list[dict[str, str]],
    config: BenchmarkRunConfig,
    dependency_sha256: str | None = None,
) -> tuple[str, str]:
    """Reproduce the byte identity used by the unversioned E5c raw run."""

    prompt_sha256 = _sha256_value(messages)
    identity = {
        "method": HANDOFF_REPLAY_METHOD,
        "prediction_schema_version": (
            LEGACY_HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION
        ),
        "replay_pipeline_version": HANDOFF_REPLAY_PIPELINE_VERSION,
        "prompt_protocol_version": HANDOFF_PROMPT_PROTOCOL_VERSION,
        "stage": stage,
        "prepared_manifest_sha256": prepared_manifest_sha256,
        "case_input_sha256": entry["case_input_sha256"],
        "trajectory_sha256": entry["trajectory_sha256"],
        "judge_view_version": JUDGE_VIEW_VERSION,
        "diagnostic_pipeline_version": DIAGNOSTIC_PIPELINE_VERSION,
        "transport_policy_version": LEGACY_TRANSPORT_POLICY_VERSION,
        "prompt_sha256": prompt_sha256,
        "dependency_sha256": dependency_sha256,
        "provider_config": config.public_dict(),
    }
    return _sha256_value(identity), prompt_sha256


def _source_raw(
    *,
    source_cache_dir: Path,
    stage: str,
    request_sha256: str,
) -> tuple[Any, dict[str, Any]]:
    path = source_cache_dir / f"raw_{stage}" / f"{request_sha256}.json"
    document = _read_json_object(path, location=f"legacy E5c {stage} raw")
    if (
        document.get("schema_version")
        != LEGACY_HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION
        or document.get("stage") != stage
        or "evidence_validation_version" in document
    ):
        raise CriticReplayError(
            f"legacy E5c {stage} raw envelope identity mismatch"
        )
    raw = _read_raw_artifact(
        path,
        request_sha256=request_sha256,
        expected_schema_version=(
            LEGACY_HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION
        ),
    )
    provenance = {
        "stage": stage,
        "legacy_request_sha256": request_sha256,
        "source_relative_path": str(path.relative_to(source_cache_dir)),
        "source_file_sha256": _sha256_file(path),
        "raw_response_sha256": _sha256_value(raw),
    }
    return raw, provenance


def _write_once(path: Path, value: Mapping[str, Any]) -> None:
    if path.is_file():
        if _read_json_object(path, location="revalidation cache") != value:
            raise CriticReplayError(
                "existing revalidation cache conflicts with immutable raw"
            )
        return
    _atomic_write_json(path, value)


def _import_stage(
    *,
    raw: Any,
    source_provenance: Mapping[str, Any],
    stage: str,
    expected: Mapping[str, Any],
    parser: Any,
    cache_dir: Path,
) -> None:
    request_sha256 = str(expected["request_sha256"])
    raw_path = (
        cache_dir / f"raw_{stage}" / f"{request_sha256}.json"
    )
    cache_path = cache_dir / stage / f"{request_sha256}.json"
    raw_document = {
        "schema_version": HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION,
        "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
        "stage": stage,
        "request_sha256": request_sha256,
        "response_sha256": _sha256_value(raw),
        "raw_response": raw,
        "immutable_source_file_sha256": source_provenance[
            "source_file_sha256"
        ],
        "legacy_request_sha256": source_provenance[
            "legacy_request_sha256"
        ],
    }
    _write_once(raw_path, raw_document)
    record: dict[str, Any] = {
        **dict(expected),
        "raw_output": raw,
        "raw_response_sha256": _sha256_value(raw),
        "parsed_output": None,
        "status": None,
        "failure_stage": None,
        "failure_code": None,
        "failure_message": None,
        "latency_seconds": 0.0,
        "immutable_source_file_sha256": source_provenance[
            "source_file_sha256"
        ],
        "legacy_request_sha256": source_provenance[
            "legacy_request_sha256"
        ],
    }
    try:
        record["parsed_output"] = parser(raw)
        record["status"] = "success"
    except JudgeOutputError as error:
        record.update(
            {
                "status": _failure_status(error),
                "failure_stage": error.stage,
                "failure_code": error.code,
                "failure_message": error.safe_message,
            }
        )
    _assert_gold_free(record, location=f"revalidated E5c {stage} cache")
    _validate_stage_record(record, stage=stage, parser=parser)
    _write_once(cache_path, record)


def _assert_outside_source(
    path: Path,
    *,
    source_root: Path,
) -> None:
    if path == source_root or source_root in path.parents:
        raise CriticReplayError(
            "revalidation outputs must not modify the legacy E5c directory"
        )


def revalidate_handoff_immutable_raw(
    *,
    manifest_path: str | Path,
    source_predict_run_path: str | Path,
    source_cache_dir: str | Path,
    cache_dir: str | Path,
    unscored_output_path: str | Path,
    run_metadata_path: str | Path,
    provenance_path: str | Path,
) -> tuple[list[dict[str, Any]], dict[str, Any], dict[str, Any]]:
    """Rebuild E5c unscored rows from six immutable raw envelopes only."""

    started = datetime.now(timezone.utc)
    prepared_path = Path(manifest_path).expanduser().resolve()
    source_run_path = Path(source_predict_run_path).expanduser().resolve()
    source_root = Path(source_cache_dir).expanduser().resolve()
    cache_root = Path(cache_dir).expanduser().resolve()
    unscored_path = Path(unscored_output_path).expanduser().resolve()
    metadata_path = Path(run_metadata_path).expanduser().resolve()
    provenance_output = Path(provenance_path).expanduser().resolve()
    legacy_dir = source_root.parent
    for target in (
        cache_root,
        unscored_path,
        metadata_path,
        provenance_output,
    ):
        _assert_outside_source(target, source_root=legacy_dir)

    manifest = load_replay_manifest(prepared_path)
    source_metadata = _read_json_object(
        source_run_path,
        location="legacy E5c predict run",
    )
    config = _legacy_config(
        source_metadata,
        manifest=manifest,
    )
    manifest_sha256 = str(manifest["replay_manifest_sha256"])
    source_records: list[dict[str, Any]] = []

    for entry in manifest["entries"]:
        trace = CanonicalTrace.from_dict(entry["trace"])
        ledger_messages = handoff_ledger_messages(trace)
        legacy_ledger_request, legacy_ledger_prompt = (
            _legacy_stage_identity(
                stage="handoff_ledger",
                entry=entry,
                prepared_manifest_sha256=manifest_sha256,
                messages=ledger_messages,
                config=config,
            )
        )
        raw_ledger, ledger_source = _source_raw(
            source_cache_dir=source_root,
            stage="handoff_ledger",
            request_sha256=legacy_ledger_request,
        )
        ledger_source.update(
            {
                "trajectory_id": entry["trajectory_id"],
                "legacy_prompt_sha256": legacy_ledger_prompt,
            }
        )
        source_records.append(ledger_source)

        ledger_request, ledger_prompt = _stage_identity(
            stage="handoff_ledger",
            entry=entry,
            prepared_manifest_sha256=manifest_sha256,
            messages=ledger_messages,
            config=config,
        )
        ledger_expected = _stage_expected(
            stage="handoff_ledger",
            manifest_sha256=manifest_sha256,
            entry=entry,
            request_sha256=ledger_request,
            prompt_sha256=ledger_prompt,
            config=config,
        )
        _import_stage(
            raw=raw_ledger,
            source_provenance=ledger_source,
            stage="handoff_ledger",
            expected=ledger_expected,
            parser=lambda raw, trace=trace: parse_handoff_ledger(
                raw,
                trace=trace,
            ).to_dict(),
            cache_dir=cache_root,
        )
        ledger = parse_handoff_ledger(raw_ledger, trace=trace)

        selector_messages = handoff_selector_messages(trace, ledger)
        legacy_selector_request, legacy_selector_prompt = (
            _legacy_stage_identity(
                stage="handoff_selector",
                entry=entry,
                prepared_manifest_sha256=manifest_sha256,
                messages=selector_messages,
                config=config,
                dependency_sha256=_sha256_value(raw_ledger),
            )
        )
        raw_selector, selector_source = _source_raw(
            source_cache_dir=source_root,
            stage="handoff_selector",
            request_sha256=legacy_selector_request,
        )
        selector_source.update(
            {
                "trajectory_id": entry["trajectory_id"],
                "legacy_prompt_sha256": legacy_selector_prompt,
            }
        )
        source_records.append(selector_source)

        selector_request, selector_prompt = _stage_identity(
            stage="handoff_selector",
            entry=entry,
            prepared_manifest_sha256=manifest_sha256,
            messages=selector_messages,
            config=config,
            dependency_sha256=_sha256_value(raw_ledger),
        )
        selector_expected = _stage_expected(
            stage="handoff_selector",
            manifest_sha256=manifest_sha256,
            entry=entry,
            request_sha256=selector_request,
            prompt_sha256=selector_prompt,
            config=config,
        )
        _import_stage(
            raw=raw_selector,
            source_provenance=selector_source,
            stage="handoff_selector",
            expected=selector_expected,
            parser=lambda raw, trace=trace: parse_handoff_selector(
                raw,
                trace=trace,
            ).to_dict(),
            cache_dir=cache_root,
        )

    provenance = _document_with_hash(
        {
            "schema_version": REVALIDATION_PROVENANCE_SCHEMA_VERSION,
            "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
            "prepared_manifest_sha256": manifest_sha256,
            "source_predict_run_path": str(source_run_path),
            "source_predict_run_sha256": _sha256_file(source_run_path),
            "source_prediction_schema_version": (
                LEGACY_HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION
            ),
            "source_raw_artifact_count": len(source_records),
            "source_raw_artifacts": source_records,
        },
        hash_field="revalidation_source_sha256",
    )
    _assert_gold_free(provenance, location="E5c revalidation provenance")
    _atomic_write_json(provenance_output, provenance)

    def no_completion(messages: list[dict[str, str]]) -> Any:
        raise AssertionError(
            "immutable-raw revalidation must never call a semantic provider"
        )

    rows = predict_handoff_replay(
        manifest_path=prepared_path,
        complete=no_completion,
        config=config,
        cache_dir=cache_root,
        unscored_output_path=unscored_path,
    )
    if not all(row.get("cache_hit") is True for row in rows):
        raise CriticReplayError(
            "immutable-raw revalidation did not use every imported cache"
        )
    finished = datetime.now(timezone.utc)
    metadata: dict[str, Any] = {
        "schema_version": HANDOFF_REPLAY_RUN_SCHEMA_VERSION,
        "method": HANDOFF_REPLAY_METHOD,
        "prediction_schema_version": (
            HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION
        ),
        "replay_pipeline_version": HANDOFF_REPLAY_PIPELINE_VERSION,
        "prepared_manifest_path": str(prepared_path),
        "prepared_manifest_sha256": manifest_sha256,
        "source_predictions_sha256": manifest[
            "source_predictions_sha256"
        ],
        "started_at": started.isoformat(),
        "finished_at": finished.isoformat(),
        "duration_seconds": (finished - started).total_seconds(),
        "provider": config.provider,
        "endpoint": config.endpoint,
        "model": config.model,
        "temperature": config.temperature,
        "timeout": config.timeout,
        "max_output_tokens": config.max_output_tokens,
        "max_retries": config.max_retries,
        "retry_backoff": config.retry_backoff,
        "prompt_protocol_version": HANDOFF_PROMPT_PROTOCOL_VERSION,
        "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "provider_telemetry": {
            "logical_completion_count": 0,
            "http_attempt_count": 0,
            "retry_count": 0,
        },
        "prediction_count": len(rows),
        "cache_hit_count": len(rows),
        "status_counts": {
            status: sum(row.get("status") == status for row in rows)
            for status in sorted({str(row.get("status")) for row in rows})
        },
        "unscored_predictions_path": str(unscored_path),
        "unscored_predictions_sha256": replay_artifact_sha256(
            unscored_path
        ),
        "cache_dir": str(cache_root),
        "offline_revalidation": {
            "no_external_calls": True,
            "source_provenance_path": str(provenance_output),
            "source_provenance_sha256": _sha256_file(provenance_output),
            "source_predict_run_sha256": _sha256_file(source_run_path),
            "source_raw_artifact_count": len(source_records),
        },
    }
    _assert_gold_free(metadata, location="E5c revalidation run metadata")
    _atomic_write_json(metadata_path, metadata)
    return rows, metadata, provenance


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m agentdebug.benchmark.replay_revalidate",
        description=(
            "Rebuild gold-free E5c predictions from immutable raw responses "
            "under the current evidence-validator identity."
        ),
    )
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--source-predict-run", required=True)
    parser.add_argument("--source-cache-dir", required=True)
    parser.add_argument("--cache-dir", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--run-metadata", required=True)
    parser.add_argument("--provenance", required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    rows, metadata, provenance = revalidate_handoff_immutable_raw(
        manifest_path=args.manifest,
        source_predict_run_path=args.source_predict_run,
        source_cache_dir=args.source_cache_dir,
        cache_dir=args.cache_dir,
        unscored_output_path=args.output,
        run_metadata_path=args.run_metadata,
        provenance_path=args.provenance,
    )
    print(
        json.dumps(
            {
                "unscored_predictions": metadata[
                    "unscored_predictions_path"
                ],
                "run_metadata": str(
                    Path(args.run_metadata).expanduser().resolve()
                ),
                "provenance": str(
                    Path(args.provenance).expanduser().resolve()
                ),
                "prediction_count": len(rows),
                "status_counts": metadata["status_counts"],
                "evidence_validation_version": (
                    EVIDENCE_VALIDATION_VERSION
                ),
                "source_raw_artifact_count": provenance[
                    "source_raw_artifact_count"
                ],
                "external_calls": 0,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "LEGACY_HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION",
    "LEGACY_HANDOFF_REPLAY_RUN_SCHEMA_VERSION",
    "REVALIDATION_PROVENANCE_SCHEMA_VERSION",
    "revalidate_handoff_immutable_raw",
]

"""Gold-isolated E7 global-causal-critic replay and scoring.

E7 deliberately reuses an already-persisted two-stage root as a *fallible*
claim.  It does not reuse the action-heavy ledger or any benchmark label.  A
fresh LLM reads the complete JudgeView and is the sole semantic classifier.
Deterministic code only enforces identities, schema, evidence, and scoring.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from agentdebug.diagnostics import (
    EVIDENCE_REPAIR_MAX_ATTEMPTS,
    EVIDENCE_REPAIR_PIPELINE_VERSION,
    EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION,
    EVIDENCE_VALIDATION_VERSION,
    GLOBAL_CRITIC_PIPELINE_VERSION,
    GLOBAL_CRITIC_PROMPT_PROTOCOL_VERSION,
    JUDGE_VIEW_VERSION,
    JudgeOutputError,
    RootCauseJudgment,
    build_evidence_repair_request,
    evidence_repair_messages,
    global_critic_messages,
    parse_evidence_repair,
    parse_global_critic,
    parse_handoff_selector,
    validate_evidence,
)

from .cohort import CohortManifest
from .metrics import compute_metrics
from .models import BenchmarkDataset
from .prediction_manifest import (
    PredictionCase,
    load_prediction_manifest,
    stable_sha256,
)
from .production_workflow import (
    ProductionWorkflowError,
    _load_predict_metadata,
    _read_jsonl,
    _validate_unscored_prediction,
)
from .runner import (
    TRANSPORT_POLICY_VERSION,
    BenchmarkRunConfig,
    _apply_root,
    _base_record,
)
from .stage_cache import (
    build_stage_request,
    run_cached_stage,
    stable_sha256 as stage_sha256,
    sum_stage_telemetry,
)


E7_INPUT_SCHEMA_VERSION = "agentdebug.benchmark.e7-critic-inputs.v1"
E7_PREDICTION_SCHEMA_VERSION = (
    "agentdebug.benchmark.e7-unscored-prediction.v1"
)
E7_PREDICT_RUN_SCHEMA_VERSION = "agentdebug.benchmark.e7-predict-run.v1"
E7_METHOD = "two_stage"
E7_EXPERIMENT = "e7_global_causal_critic"
E7_STAGE = "global_causal_critic"
E7_REPAIR_STAGE = "global_critic_evidence_repair"
_STAGES = (E7_STAGE, E7_REPAIR_STAGE)
_OUTCOME_FIELDS = {
    "status",
    "failure_stage",
    "failure_code",
    "failure_message",
}
_SEMANTIC_FIELDS = {
    "status",
    "failure_stage",
    "failure_code",
    "failure_message",
    "root_cause_judgment",
    "judge_reported_step",
    "predicted_step",
    "predicted_event_id",
    "predicted_module",
    "predicted_error_type",
    "root_cause",
    "judge_step_matches_event_mapping",
    "evidence_validation_issues",
    "evidence_repair",
}
_ROW_FIELDS = {
    "schema_version",
    "method",
    "experiment",
    "pipeline_version",
    "prompt_protocol_version",
    "evidence_repair_pipeline_version",
    "evidence_repair_prompt_protocol_version",
    "evidence_repair_max_attempts",
    "evidence_validation_version",
    "transport_policy_version",
    "prediction_manifest_sha256",
    "critic_input_manifest_sha256",
    "trajectory_id",
    "trajectory_sha256",
    "case_input_sha256",
    "entry_sha256",
    "initial_root",
    "provider_config",
    "stage_attempted",
    "stage_cache_hits",
    "stage_identities",
    "stage_outcomes",
    "stage_provider_telemetry",
    "raw_judge_outputs",
    "provider_telemetry",
    "latency_seconds",
    "cache_hit",
    *_SEMANTIC_FIELDS,
    "unscored_prediction_sha256",
}
_RUN_FIELDS = {
    "schema_version",
    "method",
    "experiment",
    "pipeline_version",
    "prompt_protocol_version",
    "evidence_repair_pipeline_version",
    "evidence_repair_prompt_protocol_version",
    "evidence_repair_max_attempts",
    "evidence_validation_version",
    "transport_policy_version",
    "prediction_manifest_path",
    "prediction_manifest_sha256",
    "critic_input_manifest_path",
    "critic_input_manifest_sha256",
    "unscored_predictions_path",
    "unscored_predictions_sha256",
    "selected_trajectory_ids",
    "prediction_count",
    "provider_config",
    "provider_telemetry",
    "provider_telemetry_coverage",
    "provider_capabilities",
    "repair_eligible_count",
    "repair_attempt_count",
    "repair_applied_count",
    "semantic_mutation_count",
    "max_logical_completions",
    "logical_completion_budget_used",
    "retry_failures",
    "predict_run_sha256",
}


class GlobalCriticWorkflowError(ValueError):
    """An E7 artifact is unsafe, inconsistent, or not reproducible."""


class _LogicalBudget:
    def __init__(self, maximum: int | None) -> None:
        if maximum is not None and (
            isinstance(maximum, bool)
            or not isinstance(maximum, int)
            or maximum < 1
        ):
            raise ValueError(
                "max_logical_completions must be a positive integer"
            )
        self.maximum = maximum
        self.issued = 0

    def before_complete(self) -> None:
        if self.maximum is not None and self.issued >= self.maximum:
            raise GlobalCriticWorkflowError(
                "E7 logical-completion budget is exhausted"
            )
        self.issued += 1


_FORBIDDEN_KEYS = {
    "all_correct",
    "confidence",
    "critical_failure_module",
    "critical_failure_step",
    "critical_failure_type",
    "gold_error_type",
    "gold_event_id",
    "gold_module",
    "gold_normalization_notes",
    "gold_raw_error_type",
    "gold_raw_module",
    "gold_reasoning",
    "gold_step",
    "score",
    "scores",
    "step_annotations",
    "step_exact",
    "step_module_exact",
    "weight",
    "weights",
}


def _assert_gold_free(value: Any, *, location: str) -> None:
    if isinstance(value, Mapping):
        forbidden = sorted(
            str(key)
            for key in value
            if str(key).casefold() in _FORBIDDEN_KEYS
            or str(key).casefold().startswith("gold_")
        )
        if forbidden:
            raise GlobalCriticWorkflowError(
                f"{location} contains forbidden evaluator fields: "
                + ", ".join(forbidden)
            )
        for key, item in value.items():
            # Provider output is immutable, untrusted data.  Its JSON field
            # names are not application-created evaluator fields.
            if key == "raw_judge_outputs":
                continue
            _assert_gold_free(item, location=f"{location}.{key}")
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _assert_gold_free(item, location=f"{location}[{index}]")


def _file_sha256(path: str | Path) -> str:
    resolved = Path(path).expanduser().resolve()
    digest = hashlib.sha256()
    with resolved.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _atomic_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(value, encoding="utf-8")
    temporary.replace(path)


def _atomic_json(path: Path, value: Any) -> None:
    _atomic_text(
        path,
        json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n",
    )


def _atomic_jsonl(path: Path, values: Sequence[Mapping[str, Any]]) -> None:
    _atomic_text(
        path,
        "".join(
            json.dumps(value, ensure_ascii=False, default=str) + "\n"
            for value in values
        ),
    )


def _read_object(path: str | Path, *, location: str) -> dict[str, Any]:
    resolved = Path(path).expanduser().resolve()
    try:
        value = json.loads(resolved.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise GlobalCriticWorkflowError(f"{location} is corrupt") from error
    if not isinstance(value, dict):
        raise GlobalCriticWorkflowError(f"{location} must be an object")
    return value


def _public_root(root: RootCauseJudgment) -> dict[str, Any]:
    return {
        "critical_step": root.critical_step,
        "module": root.module.value,
        "error_type": root.error_type.value,
        "evidence": root.evidence_quote,
        "root_cause": root.root_cause,
    }


def _validate_public_root(
    value: Any,
    *,
    case: PredictionCase,
) -> dict[str, Any] | None:
    if value is None:
        return None
    if not isinstance(value, Mapping) or set(value) != {
        "critical_step",
        "module",
        "error_type",
        "evidence",
        "root_cause",
    }:
        raise GlobalCriticWorkflowError("E7 prior root fields are invalid")
    try:
        root = parse_global_critic(
            json.dumps(dict(value), ensure_ascii=False),
            view=case.judge_view,
        )
    except JudgeOutputError as error:
        raise GlobalCriticWorkflowError("E7 prior root is invalid") from error
    return _public_root(root)


def _document_with_hash(
    body: Mapping[str, Any],
    *,
    hash_field: str,
) -> dict[str, Any]:
    value = dict(body)
    value[hash_field] = stable_sha256(value)
    return value


def prepare_global_critic_inputs(
    *,
    prediction_manifest_path: str | Path,
    source_unscored_path: str | Path,
    source_predict_run_path: str | Path,
    output_path: str | Path,
    expected_prediction_manifest_file_sha256: str | None = None,
    expected_source_unscored_sha256: str | None = None,
    expected_source_predict_run_sha256: str | None = None,
) -> dict[str, Any]:
    """Sanitize frozen E6 raw roots into a gold-free E7 input manifest."""

    manifest_path = Path(prediction_manifest_path).expanduser().resolve()
    source_path = Path(source_unscored_path).expanduser().resolve()
    source_run_path = Path(source_predict_run_path).expanduser().resolve()
    if (
        expected_prediction_manifest_file_sha256 is not None
        and _file_sha256(manifest_path)
        != expected_prediction_manifest_file_sha256
    ):
        raise GlobalCriticWorkflowError(
            "prediction manifest file SHA-256 mismatch"
        )
    if (
        expected_source_unscored_sha256 is not None
        and _file_sha256(source_path) != expected_source_unscored_sha256
    ):
        raise GlobalCriticWorkflowError(
            "source unscored file SHA-256 mismatch"
        )
    if (
        expected_source_predict_run_sha256 is not None
        and _file_sha256(source_run_path)
        != expected_source_predict_run_sha256
    ):
        raise GlobalCriticWorkflowError(
            "source predict-run file SHA-256 mismatch"
        )

    manifest, cases = load_prediction_manifest(manifest_path)
    rows = _read_jsonl(source_path)
    if len(rows) != len(cases):
        raise GlobalCriticWorkflowError(
            "source predictions do not match the prediction manifest"
        )
    source_run = _read_object(
        source_run_path,
        location="E7 source predict run",
    )
    raw_config = source_run.get("provider_config")
    if not isinstance(raw_config, Mapping):
        raise GlobalCriticWorkflowError(
            "source predict-run provider config is missing"
        )
    try:
        source_config = BenchmarkRunConfig(**dict(raw_config))
    except (TypeError, ValueError) as error:
        raise GlobalCriticWorkflowError(
            "source provider config is invalid"
        ) from error
    _load_predict_metadata(
        source_run_path,
        unscored_path=source_path,
        manifest_sha256=manifest["prediction_manifest_sha256"],
        prediction_count=len(rows),
        config=source_config,
        rows=rows,
    )
    by_row = {str(row.get("trajectory_id")): row for row in rows}
    if len(by_row) != len(rows) or set(by_row) != {
        case.trajectory_id for case in cases
    }:
        raise GlobalCriticWorkflowError(
            "source prediction identities are incomplete or duplicated"
        )

    entries: list[dict[str, Any]] = []
    for case in cases:
        row = _validate_unscored_prediction(
            by_row[case.trajectory_id],
            case=case,
            manifest_sha256=manifest["prediction_manifest_sha256"],
            config=source_config,
        )
        raw_outputs = row.get("raw_judge_outputs")
        raw_selector = (
            raw_outputs.get("handoff_selector")
            if isinstance(raw_outputs, Mapping)
            else None
        )
        initial_root: dict[str, Any] | None = None
        if raw_selector is not None:
            try:
                parsed = parse_handoff_selector(
                    raw_selector,
                    trace=case.judge_view,
                )
            except JudgeOutputError:
                parsed = None
            if parsed is not None:
                initial_root = _public_root(parsed)
        entry = {
            "trajectory_id": case.trajectory_id,
            "trajectory_sha256": case.trajectory_sha256,
            "case_input_sha256": case.case_input_sha256,
            "source_row_sha256": stable_sha256(row),
            "source_selector_raw_sha256": (
                None
                if raw_selector is None
                else stage_sha256(raw_selector)
            ),
            "initial_root": initial_root,
        }
        entry["entry_sha256"] = stable_sha256(entry)
        entries.append(entry)

    document = _document_with_hash(
        {
            "schema_version": E7_INPUT_SCHEMA_VERSION,
            "experiment": E7_EXPERIMENT,
            "pipeline_version": GLOBAL_CRITIC_PIPELINE_VERSION,
            "prompt_protocol_version": (
                GLOBAL_CRITIC_PROMPT_PROTOCOL_VERSION
            ),
            "judge_view_version": JUDGE_VIEW_VERSION,
            "prediction_manifest_path": str(manifest_path),
            "prediction_manifest_file_sha256": _file_sha256(manifest_path),
            "prediction_manifest_sha256": manifest[
                "prediction_manifest_sha256"
            ],
            "dataset_manifest_sha256": manifest[
                "dataset_manifest_sha256"
            ],
            "cohort_name": manifest["cohort_name"],
            "cohort_sha256": manifest["cohort_sha256"],
            "source_kind": "production_e6_raw_selector",
            "source_unscored_path": str(source_path),
            "source_unscored_sha256": _file_sha256(source_path),
            "source_predict_run_path": str(source_run_path),
            "source_predict_run_sha256": _file_sha256(source_run_path),
            "entry_count": len(entries),
            "entries": entries,
        },
        hash_field="critic_input_manifest_sha256",
    )
    _assert_gold_free(document, location="E7 input manifest")
    _atomic_json(Path(output_path).expanduser().resolve(), document)
    return document


def load_global_critic_inputs(
    path: str | Path,
) -> tuple[dict[str, Any], dict[str, dict[str, Any]]]:
    document = _read_object(path, location="E7 input manifest")
    expected_top = {
        "schema_version",
        "experiment",
        "pipeline_version",
        "prompt_protocol_version",
        "judge_view_version",
        "prediction_manifest_path",
        "prediction_manifest_file_sha256",
        "prediction_manifest_sha256",
        "dataset_manifest_sha256",
        "cohort_name",
        "cohort_sha256",
        "source_kind",
        "source_unscored_path",
        "source_unscored_sha256",
        "source_predict_run_path",
        "source_predict_run_sha256",
        "entry_count",
        "entries",
        "critic_input_manifest_sha256",
    }
    if set(document) != expected_top:
        raise GlobalCriticWorkflowError(
            "E7 input manifest fields are invalid"
        )
    if (
        document.get("schema_version") != E7_INPUT_SCHEMA_VERSION
        or document.get("experiment") != E7_EXPERIMENT
        or document.get("pipeline_version")
        != GLOBAL_CRITIC_PIPELINE_VERSION
        or document.get("prompt_protocol_version")
        != GLOBAL_CRITIC_PROMPT_PROTOCOL_VERSION
        or document.get("judge_view_version") != JUDGE_VIEW_VERSION
        or document.get("source_kind") != "production_e6_raw_selector"
    ):
        raise GlobalCriticWorkflowError(
            "E7 input manifest version identity is invalid"
        )
    body = dict(document)
    claimed = body.pop("critic_input_manifest_sha256")
    if claimed != stable_sha256(body):
        raise GlobalCriticWorkflowError(
            "E7 input manifest content hash is invalid"
        )
    entries = document.get("entries")
    if (
        not isinstance(entries, list)
        or len(entries) != document.get("entry_count")
        or not entries
    ):
        raise GlobalCriticWorkflowError(
            "E7 input manifest entries/count are invalid"
        )
    loaded_prediction, cases = load_prediction_manifest(
        document["prediction_manifest_path"]
    )
    by_case = {case.trajectory_id: case for case in cases}
    if (
        _file_sha256(document["prediction_manifest_path"])
        != document["prediction_manifest_file_sha256"]
        or loaded_prediction["prediction_manifest_sha256"]
        != document["prediction_manifest_sha256"]
        or loaded_prediction["dataset_manifest_sha256"]
        != document["dataset_manifest_sha256"]
        or loaded_prediction["cohort_name"] != document["cohort_name"]
        or loaded_prediction["cohort_sha256"]
        != document["cohort_sha256"]
        or _file_sha256(document["source_unscored_path"])
        != document["source_unscored_sha256"]
        or _file_sha256(document["source_predict_run_path"])
        != document["source_predict_run_sha256"]
        or len(by_case) != len(entries)
    ):
        raise GlobalCriticWorkflowError(
            "E7 input manifest prediction lineage is invalid"
        )
    by_entry: dict[str, dict[str, Any]] = {}
    expected_entry_fields = {
        "trajectory_id",
        "trajectory_sha256",
        "case_input_sha256",
        "source_row_sha256",
        "source_selector_raw_sha256",
        "initial_root",
        "entry_sha256",
    }
    for raw_entry in entries:
        if not isinstance(raw_entry, Mapping) or set(raw_entry) != (
            expected_entry_fields
        ):
            raise GlobalCriticWorkflowError(
                "E7 input entry fields are invalid"
            )
        entry = dict(raw_entry)
        claimed_entry = entry.pop("entry_sha256")
        if claimed_entry != stable_sha256(entry):
            raise GlobalCriticWorkflowError(
                "E7 input entry hash is invalid"
            )
        entry["entry_sha256"] = claimed_entry
        trajectory_id = entry.get("trajectory_id")
        case = by_case.get(str(trajectory_id))
        if (
            case is None
            or entry.get("trajectory_sha256") != case.trajectory_sha256
            or entry.get("case_input_sha256") != case.case_input_sha256
            or trajectory_id in by_entry
        ):
            raise GlobalCriticWorkflowError(
                "E7 input entry identity is invalid"
            )
        normalized = _validate_public_root(
            entry.get("initial_root"),
            case=case,
        )
        if normalized != entry.get("initial_root"):
            raise GlobalCriticWorkflowError(
                "E7 input prior root is not canonical"
            )
        by_entry[str(trajectory_id)] = entry
    if set(by_entry) != set(by_case):
        raise GlobalCriticWorkflowError(
            "E7 input entries do not exactly cover the prediction manifest"
        )
    _assert_gold_free(document, location="E7 input manifest")
    return document, by_entry


def _shared_identity(
    *,
    case: PredictionCase,
    input_manifest: Mapping[str, Any],
    config: BenchmarkRunConfig,
) -> dict[str, Any]:
    return {
        "method": E7_METHOD,
        "experiment": E7_EXPERIMENT,
        "prediction_schema_version": E7_PREDICTION_SCHEMA_VERSION,
        "pipeline_version": GLOBAL_CRITIC_PIPELINE_VERSION,
        "prompt_protocol_version": (
            GLOBAL_CRITIC_PROMPT_PROTOCOL_VERSION
        ),
        "judge_view_version": JUDGE_VIEW_VERSION,
        "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "prediction_manifest_sha256": input_manifest[
            "prediction_manifest_sha256"
        ],
        "critic_input_manifest_sha256": input_manifest[
            "critic_input_manifest_sha256"
        ],
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "case_input_sha256": case.case_input_sha256,
        "judge_view_sha256": stable_sha256(case.judge_view.to_dict()),
        "provider_config": config.public_dict(),
    }


def _critic_stage_request(
    *,
    case: PredictionCase,
    entry: Mapping[str, Any],
    input_manifest: Mapping[str, Any],
    config: BenchmarkRunConfig,
):
    messages = global_critic_messages(
        case.judge_view,
        initial_root=entry["initial_root"],
    )
    request = build_stage_request(
        stage=E7_STAGE,
        messages=messages,
        identity=_shared_identity(
            case=case,
            input_manifest=input_manifest,
            config=config,
        ),
        dependency_sha256=stable_sha256(
            {
                "entry_sha256": entry["entry_sha256"],
                "initial_root": entry["initial_root"],
            }
        ),
    )
    return request, messages


def _repair_eligible(root: RootCauseJudgment, case: PredictionCase) -> bool:
    validation = validate_evidence(
        case.judge_view,
        root,
        stage=E7_STAGE,
    )
    return (
        len(validation.issues) == 1
        and validation.issues[0].code == "evidence_quote_not_found"
        and validation.issues[0].level.value == "error"
    )


def _repair_stage_request(
    *,
    case: PredictionCase,
    entry: Mapping[str, Any],
    input_manifest: Mapping[str, Any],
    config: BenchmarkRunConfig,
    critic_root: RootCauseJudgment,
    critic_raw_sha256: str,
):
    repair = build_evidence_repair_request(case.judge_view, critic_root)
    messages = evidence_repair_messages(repair)
    identity = {
        **_shared_identity(
            case=case,
            input_manifest=input_manifest,
            config=config,
        ),
        "evidence_repair_pipeline_version": (
            EVIDENCE_REPAIR_PIPELINE_VERSION
        ),
        "evidence_repair_prompt_protocol_version": (
            EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
        ),
        "evidence_repair_max_attempts": EVIDENCE_REPAIR_MAX_ATTEMPTS,
        "critic_raw_sha256": critic_raw_sha256,
        "frozen_root_sha256": stable_sha256(critic_root.to_dict()),
        "entry_sha256": entry["entry_sha256"],
    }
    request = build_stage_request(
        stage=E7_REPAIR_STAGE,
        messages=messages,
        identity=identity,
        dependency_sha256=stable_sha256(
            {
                "critic_raw_sha256": critic_raw_sha256,
                "frozen_root": critic_root.to_dict(),
            }
        ),
    )
    return request, messages, repair


def _outcome(stage: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "status": stage["status"],
        "failure_stage": stage["failure_stage"],
        "failure_code": stage["failure_code"],
        "failure_message": stage["failure_message"],
    }


def _stage_identity(stage: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "request_sha256": stage["request_sha256"],
        "prompt_sha256": stage["prompt_sha256"],
        "raw_response_sha256": stage["raw_response_sha256"],
        "dependency_sha256": stage["identity"]["dependency_sha256"],
    }


def _empty_repair_state() -> dict[str, Any]:
    return {
        "eligible": False,
        "attempted": False,
        "applied": False,
        "status": "not_applicable",
        "failure_stage": None,
        "failure_code": None,
        "failure_message": None,
    }


def _semantic_fields(
    *,
    case: PredictionCase,
    raw_outputs: Mapping[str, Any],
    outcomes: Mapping[str, Any],
    attempted: Mapping[str, bool],
) -> dict[str, Any]:
    """Rebuild all final semantic fields from immutable raw responses."""

    result: dict[str, Any] = {
        "status": None,
        "failure_stage": None,
        "failure_code": None,
        "failure_message": None,
        "root_cause_judgment": None,
        "judge_reported_step": None,
        "predicted_step": None,
        "predicted_event_id": None,
        "predicted_module": None,
        "predicted_error_type": None,
        "root_cause": None,
        "judge_step_matches_event_mapping": False,
        "evidence_validation_issues": [],
        "evidence_repair": _empty_repair_state(),
    }
    critic_outcome = outcomes.get(E7_STAGE)
    if not isinstance(critic_outcome, Mapping):
        raise GlobalCriticWorkflowError("E7 critic outcome is missing")
    if critic_outcome.get("status") != "success":
        if attempted.get(E7_REPAIR_STAGE):
            raise GlobalCriticWorkflowError(
                "E7 repair was attempted after critic failure"
            )
        result.update(dict(critic_outcome))
        return result
    try:
        critic_root = parse_global_critic(
            raw_outputs.get(E7_STAGE),
            view=case.judge_view,
        )
    except JudgeOutputError as error:
        raise GlobalCriticWorkflowError(
            "successful E7 critic raw cannot be parsed"
        ) from error
    validation = validate_evidence(
        case.judge_view,
        critic_root,
        stage=E7_STAGE,
    )
    eligible = _repair_eligible(critic_root, case)
    if bool(attempted.get(E7_REPAIR_STAGE)) is not eligible:
        raise GlobalCriticWorkflowError(
            "E7 evidence repair eligibility/attempt mismatch"
        )
    final_root = critic_root
    repair_state = _empty_repair_state()
    if eligible:
        repair_outcome = outcomes.get(E7_REPAIR_STAGE)
        if not isinstance(repair_outcome, Mapping):
            raise GlobalCriticWorkflowError(
                "E7 attempted repair outcome is missing"
            )
        applied = repair_outcome.get("status") == "success"
        repair_state = {
            "eligible": True,
            "attempted": True,
            "applied": applied,
            **dict(repair_outcome),
        }
        if applied:
            request = build_evidence_repair_request(
                case.judge_view,
                critic_root,
            )
            try:
                repaired = parse_evidence_repair(
                    raw_outputs.get(E7_REPAIR_STAGE),
                    request=request,
                )
            except JudgeOutputError as error:
                raise GlobalCriticWorkflowError(
                    "successful E7 repair raw cannot be parsed"
                ) from error
            repaired_validation = validate_evidence(
                case.judge_view,
                repaired,
                stage=E7_REPAIR_STAGE,
            )
            if not repaired_validation.valid:
                raise GlobalCriticWorkflowError(
                    "successful E7 repair evidence is invalid"
                )
            final_root = repaired
            validation = repaired_validation
    else:
        repair_state["status"] = (
            "not_needed" if validation.valid else "not_eligible"
        )

    mapped_step = case.step_for_event(final_root.critical_event_id)
    if mapped_step != final_root.critical_step:
        raise GlobalCriticWorkflowError(
            "E7 parsed root does not map to its selected decision step"
        )
    result.update(
        {
            "root_cause_judgment": final_root.to_dict(),
            "judge_reported_step": final_root.critical_step,
            "predicted_step": mapped_step,
            "predicted_event_id": final_root.critical_event_id,
            "predicted_module": final_root.module.value,
            "predicted_error_type": final_root.error_type.value,
            "root_cause": final_root.root_cause,
            "judge_step_matches_event_mapping": True,
            "evidence_validation_issues": [
                issue.to_dict() for issue in validation.issues
            ],
            "evidence_repair": repair_state,
        }
    )
    if validation.valid:
        result["status"] = (
            "success_needs_review"
            if validation.needs_review
            else "success"
        )
    else:
        result.update(
            {
                "status": "evidence_invalid",
                "failure_stage": "evidence_validation",
                "failure_code": "invalid_evidence",
                "failure_message": (
                    "The E7 final evidence is not one strict observable "
                    "single-source substring at the selected step."
                ),
            }
        )
    return result


def _provider_capability_snapshot(judge: Any) -> dict[str, Any] | None:
    snapshotter = getattr(judge, "capability_snapshot", None)
    if not callable(snapshotter):
        return None
    value = snapshotter()
    if not isinstance(value, Mapping):
        raise GlobalCriticWorkflowError(
            "E7 provider capability snapshot must be an object"
        )
    result = dict(value)
    _assert_gold_free(result, location="E7 provider capabilities")
    return result


def _row_telemetry(
    attempted: Mapping[str, bool],
    values: Mapping[str, Any],
) -> dict[str, Any] | None:
    selected = [
        values.get(stage)
        for stage in _STAGES
        if attempted.get(stage)
    ]
    return sum_stage_telemetry(selected)


def _aggregate_telemetry(
    rows: Sequence[Mapping[str, Any]],
) -> tuple[dict[str, Any] | None, dict[str, Any]]:
    values = [
        row.get("provider_telemetry")
        for row in rows
        if row.get("provider_telemetry") is not None
    ]
    coverage = {
        "trajectory_count": len(rows),
        "covered_trajectory_count": len(values),
        "complete": len(values) == len(rows),
    }
    return (
        sum_stage_telemetry(values) if values else None,
        coverage,
    )


def _validate_provider_telemetry(
    value: Mapping[str, Any] | None,
    *,
    max_retries: int,
) -> None:
    if value is None:
        return
    for field in (
        "logical_completion_count",
        "http_attempt_count",
        "retry_count",
    ):
        counter = value.get(field)
        if (
            isinstance(counter, bool)
            or not isinstance(counter, int)
            or counter < 0
        ):
            raise GlobalCriticWorkflowError(
                f"E7 provider telemetry {field} is invalid"
            )
    logical = value["logical_completion_count"]
    http = value["http_attempt_count"]
    retries = value["retry_count"]
    if http != logical + retries or retries > logical * max_retries:
        raise GlobalCriticWorkflowError(
            "E7 telemetry violates HTTP = logical + retry or retry bound"
        )


def predict_global_critic_cases(
    *,
    prediction_manifest_path: str | Path,
    critic_input_manifest_path: str | Path,
    judge: Any,
    config: BenchmarkRunConfig,
    cache_dir: str | Path,
    unscored_output_path: str | Path,
    predict_run_metadata_path: str | Path,
    selected_trajectory_ids: Sequence[str] | None = None,
    max_logical_completions: int | None = None,
    on_result: Callable[[Mapping[str, Any]], None] | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Run E7 from gold-free manifests; this function cannot load labels."""

    prediction_manifest, cases = load_prediction_manifest(
        prediction_manifest_path
    )
    input_manifest, entries = load_global_critic_inputs(
        critic_input_manifest_path
    )
    if (
        input_manifest["prediction_manifest_sha256"]
        != prediction_manifest["prediction_manifest_sha256"]
        or config.cohort_sha256 != prediction_manifest["cohort_sha256"]
        or not config.api_key_env
    ):
        raise GlobalCriticWorkflowError(
            "E7 prediction/input/provider identities do not match"
        )
    selected: set[str] | None = None
    if selected_trajectory_ids is not None:
        values = [str(value) for value in selected_trajectory_ids]
        if not values or len(set(values)) != len(values):
            raise GlobalCriticWorkflowError(
                "E7 selected trajectory IDs must be unique and non-empty"
            )
        selected = set(values)
        known = {case.trajectory_id for case in cases}
        if not selected <= known:
            raise GlobalCriticWorkflowError(
                "E7 selected trajectory ID is outside the manifest"
            )
    chosen = [
        case
        for case in cases
        if selected is None or case.trajectory_id in selected
    ]
    budget = _LogicalBudget(max_logical_completions)
    complete = getattr(judge, "complete", None)
    if not callable(complete):
        raise TypeError("E7 prediction requires judge.complete(messages)")
    raw_snapshotter = getattr(judge, "telemetry_snapshot", None)
    telemetry_snapshotter = (
        raw_snapshotter if callable(raw_snapshotter) else None
    )
    cache_root = Path(cache_dir).expanduser().resolve() / "semantic_stages"
    output_path = Path(unscored_output_path).expanduser().resolve()
    rows: list[dict[str, Any]] = []
    for case in chosen:
        entry = entries[case.trajectory_id]
        critic_request, critic_messages = _critic_stage_request(
            case=case,
            entry=entry,
            input_manifest=input_manifest,
            config=config,
        )
        critic_stage, critic_cache_hit = run_cached_stage(
            request=critic_request,
            messages=critic_messages,
            complete=complete,
            parser=lambda raw, view=case.judge_view: parse_global_critic(
                raw,
                view=view,
            ).to_dict(),
            cache_root=cache_root,
            retry_failures=False,
            telemetry_snapshotter=telemetry_snapshotter,
            completion_guard=budget.before_complete,
        )
        attempted = {E7_STAGE: True, E7_REPAIR_STAGE: False}
        cache_hits = {
            E7_STAGE: critic_cache_hit,
            E7_REPAIR_STAGE: False,
        }
        identities: dict[str, Any] = {
            E7_STAGE: _stage_identity(critic_stage),
            E7_REPAIR_STAGE: None,
        }
        outcomes: dict[str, Any] = {
            E7_STAGE: _outcome(critic_stage),
            E7_REPAIR_STAGE: None,
        }
        raw_outputs: dict[str, Any] = {
            E7_STAGE: critic_stage["raw_response"],
        }
        stage_telemetry: dict[str, Any] = {
            E7_STAGE: critic_stage["stage_telemetry"],
            E7_REPAIR_STAGE: None,
        }
        latency = float(critic_stage["latency_seconds"])
        if critic_stage["status"] == "success":
            critic_root = parse_global_critic(
                critic_stage["raw_response"],
                view=case.judge_view,
            )
            if _repair_eligible(critic_root, case):
                repair_request, repair_messages, repair = (
                    _repair_stage_request(
                        case=case,
                        entry=entry,
                        input_manifest=input_manifest,
                        config=config,
                        critic_root=critic_root,
                        critic_raw_sha256=critic_stage[
                            "raw_response_sha256"
                        ],
                    )
                )

                def parse_repair(raw: Any) -> dict[str, Any]:
                    root = parse_evidence_repair(raw, request=repair)
                    validation = validate_evidence(
                        case.judge_view,
                        root,
                        stage=E7_REPAIR_STAGE,
                    )
                    if not validation.valid:
                        raise JudgeOutputError(
                            E7_REPAIR_STAGE,
                            "evidence_quote_not_found",
                            "E7 repaired evidence failed strict validation.",
                            raw_output=raw,
                        )
                    return root.to_dict()

                repair_stage, repair_cache_hit = run_cached_stage(
                    request=repair_request,
                    messages=repair_messages,
                    complete=complete,
                    parser=parse_repair,
                    cache_root=cache_root,
                    retry_failures=False,
                    telemetry_snapshotter=telemetry_snapshotter,
                    completion_guard=budget.before_complete,
                )
                attempted[E7_REPAIR_STAGE] = True
                cache_hits[E7_REPAIR_STAGE] = repair_cache_hit
                identities[E7_REPAIR_STAGE] = _stage_identity(repair_stage)
                outcomes[E7_REPAIR_STAGE] = _outcome(repair_stage)
                raw_outputs[E7_REPAIR_STAGE] = repair_stage["raw_response"]
                stage_telemetry[E7_REPAIR_STAGE] = repair_stage[
                    "stage_telemetry"
                ]
                latency += float(repair_stage["latency_seconds"])

        semantics = _semantic_fields(
            case=case,
            raw_outputs=raw_outputs,
            outcomes=outcomes,
            attempted=attempted,
        )
        row: dict[str, Any] = {
            "schema_version": E7_PREDICTION_SCHEMA_VERSION,
            "method": E7_METHOD,
            "experiment": E7_EXPERIMENT,
            "pipeline_version": GLOBAL_CRITIC_PIPELINE_VERSION,
            "prompt_protocol_version": (
                GLOBAL_CRITIC_PROMPT_PROTOCOL_VERSION
            ),
            "evidence_repair_pipeline_version": (
                EVIDENCE_REPAIR_PIPELINE_VERSION
            ),
            "evidence_repair_prompt_protocol_version": (
                EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
            ),
            "evidence_repair_max_attempts": EVIDENCE_REPAIR_MAX_ATTEMPTS,
            "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
            "transport_policy_version": TRANSPORT_POLICY_VERSION,
            "prediction_manifest_sha256": prediction_manifest[
                "prediction_manifest_sha256"
            ],
            "critic_input_manifest_sha256": input_manifest[
                "critic_input_manifest_sha256"
            ],
            "trajectory_id": case.trajectory_id,
            "trajectory_sha256": case.trajectory_sha256,
            "case_input_sha256": case.case_input_sha256,
            "entry_sha256": entry["entry_sha256"],
            "initial_root": entry["initial_root"],
            "provider_config": config.public_dict(),
            "stage_attempted": attempted,
            "stage_cache_hits": cache_hits,
            "stage_identities": identities,
            "stage_outcomes": outcomes,
            "stage_provider_telemetry": stage_telemetry,
            "raw_judge_outputs": raw_outputs,
            "provider_telemetry": _row_telemetry(
                attempted,
                stage_telemetry,
            ),
            "latency_seconds": latency,
            "cache_hit": all(
                cache_hits[stage] for stage in _STAGES if attempted[stage]
            ),
            **semantics,
        }
        _assert_gold_free(row, location="E7 unscored prediction")
        row["unscored_prediction_sha256"] = stable_sha256(row)
        rows.append(row)
        _atomic_jsonl(output_path, rows)
        if on_result is not None:
            on_result(row)

    telemetry, coverage = _aggregate_telemetry(rows)
    if coverage["complete"]:
        _validate_provider_telemetry(
            telemetry,
            max_retries=config.max_retries,
        )
    metadata = _document_with_hash(
        {
            "schema_version": E7_PREDICT_RUN_SCHEMA_VERSION,
            "method": E7_METHOD,
            "experiment": E7_EXPERIMENT,
            "pipeline_version": GLOBAL_CRITIC_PIPELINE_VERSION,
            "prompt_protocol_version": (
                GLOBAL_CRITIC_PROMPT_PROTOCOL_VERSION
            ),
            "evidence_repair_pipeline_version": (
                EVIDENCE_REPAIR_PIPELINE_VERSION
            ),
            "evidence_repair_prompt_protocol_version": (
                EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
            ),
            "evidence_repair_max_attempts": EVIDENCE_REPAIR_MAX_ATTEMPTS,
            "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
            "transport_policy_version": TRANSPORT_POLICY_VERSION,
            "prediction_manifest_path": str(
                Path(prediction_manifest_path).expanduser().resolve()
            ),
            "prediction_manifest_sha256": prediction_manifest[
                "prediction_manifest_sha256"
            ],
            "critic_input_manifest_path": str(
                Path(critic_input_manifest_path).expanduser().resolve()
            ),
            "critic_input_manifest_sha256": input_manifest[
                "critic_input_manifest_sha256"
            ],
            "unscored_predictions_path": str(output_path),
            "unscored_predictions_sha256": _file_sha256(output_path),
            "selected_trajectory_ids": [
                case.trajectory_id for case in chosen
            ],
            "prediction_count": len(rows),
            "provider_config": config.public_dict(),
            "provider_telemetry": telemetry,
            "provider_telemetry_coverage": coverage,
            "provider_capabilities": _provider_capability_snapshot(judge),
            "repair_eligible_count": sum(
                bool(row["evidence_repair"]["eligible"]) for row in rows
            ),
            "repair_attempt_count": sum(
                bool(row["evidence_repair"]["attempted"]) for row in rows
            ),
            "repair_applied_count": sum(
                bool(row["evidence_repair"]["applied"]) for row in rows
            ),
            "semantic_mutation_count": 0,
            "max_logical_completions": max_logical_completions,
            "logical_completion_budget_used": budget.issued,
            "retry_failures": False,
        },
        hash_field="predict_run_sha256",
    )
    _assert_gold_free(metadata, location="E7 predict run")
    _atomic_json(
        Path(predict_run_metadata_path).expanduser().resolve(),
        metadata,
    )
    return rows, metadata


def _validate_stage_identity(
    *,
    persisted: Any,
    request: Any,
    raw: Any,
) -> None:
    expected = {
        "request_sha256": request.request_sha256,
        "prompt_sha256": request.prompt_sha256,
        "raw_response_sha256": stage_sha256(raw),
        "dependency_sha256": request.identity["dependency_sha256"],
    }
    if persisted != expected:
        raise GlobalCriticWorkflowError(
            "E7 persisted stage identity diverges from raw request"
        )


def _validate_unscored_row(
    row: Mapping[str, Any],
    *,
    case: PredictionCase,
    entry: Mapping[str, Any],
    input_manifest: Mapping[str, Any],
    prediction_manifest: Mapping[str, Any],
    config: BenchmarkRunConfig,
) -> dict[str, Any]:
    value = dict(row)
    if set(value) != _ROW_FIELDS:
        raise GlobalCriticWorkflowError(
            "E7 unscored prediction fields are invalid"
        )
    claimed = value.pop("unscored_prediction_sha256", None)
    if claimed != stable_sha256(value):
        raise GlobalCriticWorkflowError(
            "E7 unscored prediction hash is invalid"
        )
    value["unscored_prediction_sha256"] = claimed
    identity_checks = {
        "schema_version": E7_PREDICTION_SCHEMA_VERSION,
        "method": E7_METHOD,
        "experiment": E7_EXPERIMENT,
        "pipeline_version": GLOBAL_CRITIC_PIPELINE_VERSION,
        "prompt_protocol_version": GLOBAL_CRITIC_PROMPT_PROTOCOL_VERSION,
        "evidence_repair_pipeline_version": (
            EVIDENCE_REPAIR_PIPELINE_VERSION
        ),
        "evidence_repair_prompt_protocol_version": (
            EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
        ),
        "evidence_repair_max_attempts": EVIDENCE_REPAIR_MAX_ATTEMPTS,
        "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "prediction_manifest_sha256": prediction_manifest[
            "prediction_manifest_sha256"
        ],
        "critic_input_manifest_sha256": input_manifest[
            "critic_input_manifest_sha256"
        ],
        "trajectory_id": case.trajectory_id,
        "trajectory_sha256": case.trajectory_sha256,
        "case_input_sha256": case.case_input_sha256,
        "entry_sha256": entry["entry_sha256"],
        "initial_root": entry["initial_root"],
        "provider_config": config.public_dict(),
    }
    if any(value.get(field) != expected for field, expected in (
        identity_checks.items()
    )):
        raise GlobalCriticWorkflowError(
            "E7 unscored prediction identity is invalid"
        )
    attempted = value.get("stage_attempted")
    cache_hits = value.get("stage_cache_hits")
    identities = value.get("stage_identities")
    outcomes = value.get("stage_outcomes")
    telemetry = value.get("stage_provider_telemetry")
    raw_outputs = value.get("raw_judge_outputs")
    if any(
        not isinstance(item, Mapping) or set(item) != set(_STAGES)
        for item in (
            attempted,
            cache_hits,
            identities,
            outcomes,
            telemetry,
        )
    ) or not isinstance(raw_outputs, Mapping):
        raise GlobalCriticWorkflowError("E7 stage envelopes are invalid")
    if attempted[E7_STAGE] is not True or any(
        not isinstance(attempted[stage], bool)
        or not isinstance(cache_hits[stage], bool)
        for stage in _STAGES
    ):
        raise GlobalCriticWorkflowError("E7 stage flags are invalid")
    expected_raw = {stage for stage in _STAGES if attempted[stage]}
    if set(raw_outputs) != expected_raw:
        raise GlobalCriticWorkflowError(
            "E7 raw outputs do not match attempted stages"
        )
    critic_request, _ = _critic_stage_request(
        case=case,
        entry=entry,
        input_manifest=input_manifest,
        config=config,
    )
    _validate_stage_identity(
        persisted=identities[E7_STAGE],
        request=critic_request,
        raw=raw_outputs[E7_STAGE],
    )
    if attempted[E7_REPAIR_STAGE]:
        if outcomes[E7_STAGE].get("status") != "success":
            raise GlobalCriticWorkflowError(
                "E7 repair follows unsuccessful critic"
            )
        critic_root = parse_global_critic(
            raw_outputs[E7_STAGE],
            view=case.judge_view,
        )
        repair_request, _, _ = _repair_stage_request(
            case=case,
            entry=entry,
            input_manifest=input_manifest,
            config=config,
            critic_root=critic_root,
            critic_raw_sha256=stage_sha256(raw_outputs[E7_STAGE]),
        )
        _validate_stage_identity(
            persisted=identities[E7_REPAIR_STAGE],
            request=repair_request,
            raw=raw_outputs[E7_REPAIR_STAGE],
        )
    elif any(
        item is not None
        for item in (
            identities[E7_REPAIR_STAGE],
            outcomes[E7_REPAIR_STAGE],
            telemetry[E7_REPAIR_STAGE],
        )
    ) or cache_hits[E7_REPAIR_STAGE]:
        raise GlobalCriticWorkflowError(
            "unattempted E7 repair contains persisted state"
        )
    semantics = _semantic_fields(
        case=case,
        raw_outputs=raw_outputs,
        outcomes=outcomes,
        attempted=attempted,
    )
    for field, expected in semantics.items():
        if value.get(field) != expected:
            raise GlobalCriticWorkflowError(
                f"E7 {field} diverges from raw semantic chain"
            )
    expected_telemetry = _row_telemetry(attempted, telemetry)
    if value.get("provider_telemetry") != expected_telemetry:
        raise GlobalCriticWorkflowError(
            "E7 row telemetry diverges from stage telemetry"
        )
    _validate_provider_telemetry(
        expected_telemetry,
        max_retries=config.max_retries,
    )
    expected_cache_hit = all(
        cache_hits[stage] for stage in _STAGES if attempted[stage]
    )
    if value.get("cache_hit") is not expected_cache_hit:
        raise GlobalCriticWorkflowError("E7 cache-hit summary is invalid")
    if (
        isinstance(value.get("latency_seconds"), bool)
        or not isinstance(value.get("latency_seconds"), (int, float))
        or value["latency_seconds"] < 0
    ):
        raise GlobalCriticWorkflowError("E7 latency is invalid")
    for stage in _STAGES:
        outcome = outcomes[stage]
        if attempted[stage]:
            if (
                not isinstance(outcome, Mapping)
                or set(outcome) != _OUTCOME_FIELDS
                or not isinstance(outcome.get("status"), str)
                or not outcome["status"]
            ):
                raise GlobalCriticWorkflowError(
                    f"E7 {stage} outcome is invalid"
                )
        elif outcome is not None:
            raise GlobalCriticWorkflowError(
                f"unattempted E7 {stage} has an outcome"
            )
    try:
        parsed_critic = parse_global_critic(
            raw_outputs[E7_STAGE],
            view=case.judge_view,
        )
    except JudgeOutputError:
        parsed_critic = None
    if (
        outcomes[E7_STAGE]["status"] == "success"
    ) is not (parsed_critic is not None):
        raise GlobalCriticWorkflowError(
            "E7 critic outcome does not match its raw response"
        )
    if attempted[E7_REPAIR_STAGE]:
        valid_repair = False
        if parsed_critic is not None:
            repair = build_evidence_repair_request(
                case.judge_view,
                parsed_critic,
            )
            try:
                repaired = parse_evidence_repair(
                    raw_outputs[E7_REPAIR_STAGE],
                    request=repair,
                )
            except JudgeOutputError:
                repaired = None
            if repaired is not None:
                valid_repair = validate_evidence(
                    case.judge_view,
                    repaired,
                    stage=E7_REPAIR_STAGE,
                ).valid
        if (
            outcomes[E7_REPAIR_STAGE]["status"] == "success"
        ) is not valid_repair:
            raise GlobalCriticWorkflowError(
                "E7 repair outcome does not match its raw response"
            )
    _assert_gold_free(value, location="E7 unscored prediction")
    return value


def _load_predict_run(
    *,
    path: str | Path,
    unscored_path: Path,
    rows: Sequence[Mapping[str, Any]],
    input_manifest: Mapping[str, Any],
    prediction_manifest: Mapping[str, Any],
    config: BenchmarkRunConfig,
) -> dict[str, Any]:
    run = _read_object(path, location="E7 predict run")
    if set(run) != _RUN_FIELDS:
        raise GlobalCriticWorkflowError("E7 predict-run fields are invalid")
    body = dict(run)
    claimed = body.pop("predict_run_sha256", None)
    if claimed != stable_sha256(body):
        raise GlobalCriticWorkflowError("E7 predict-run hash is invalid")
    checks = {
        "schema_version": E7_PREDICT_RUN_SCHEMA_VERSION,
        "method": E7_METHOD,
        "experiment": E7_EXPERIMENT,
        "pipeline_version": GLOBAL_CRITIC_PIPELINE_VERSION,
        "prompt_protocol_version": GLOBAL_CRITIC_PROMPT_PROTOCOL_VERSION,
        "evidence_repair_pipeline_version": (
            EVIDENCE_REPAIR_PIPELINE_VERSION
        ),
        "evidence_repair_prompt_protocol_version": (
            EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
        ),
        "evidence_repair_max_attempts": EVIDENCE_REPAIR_MAX_ATTEMPTS,
        "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "prediction_manifest_sha256": prediction_manifest[
            "prediction_manifest_sha256"
        ],
        "critic_input_manifest_sha256": input_manifest[
            "critic_input_manifest_sha256"
        ],
        "unscored_predictions_path": str(unscored_path),
        "unscored_predictions_sha256": _file_sha256(unscored_path),
        "prediction_count": len(rows),
        "provider_config": config.public_dict(),
        "retry_failures": False,
        "semantic_mutation_count": 0,
    }
    if any(run.get(field) != expected for field, expected in checks.items()):
        raise GlobalCriticWorkflowError(
            "E7 predict-run identity is invalid"
        )
    selected = run.get("selected_trajectory_ids")
    if (
        not isinstance(selected, list)
        or selected != [row.get("trajectory_id") for row in rows]
        or len(set(selected)) != len(selected)
    ):
        raise GlobalCriticWorkflowError(
            "E7 predict-run selection is invalid"
        )
    telemetry, coverage = _aggregate_telemetry(rows)
    if (
        run.get("provider_telemetry") != telemetry
        or run.get("provider_telemetry_coverage") != coverage
        or run.get("repair_eligible_count")
        != sum(bool(row["evidence_repair"]["eligible"]) for row in rows)
        or run.get("repair_attempt_count")
        != sum(bool(row["evidence_repair"]["attempted"]) for row in rows)
        or run.get("repair_applied_count")
        != sum(bool(row["evidence_repair"]["applied"]) for row in rows)
    ):
        raise GlobalCriticWorkflowError(
            "E7 predict-run aggregates are invalid"
        )
    if coverage["complete"]:
        _validate_provider_telemetry(
            telemetry,
            max_retries=config.max_retries,
        )
    maximum = run.get("max_logical_completions")
    used = run.get("logical_completion_budget_used")
    if (
        (
            maximum is not None
            and (
                isinstance(maximum, bool)
                or not isinstance(maximum, int)
                or maximum < 1
            )
        )
        or isinstance(used, bool)
        or not isinstance(used, int)
        or used < 0
        or (maximum is not None and used > maximum)
    ):
        raise GlobalCriticWorkflowError(
            "E7 logical-completion budget metadata is invalid"
        )
    _assert_gold_free(run, location="E7 predict run")
    return run


def score_global_critic_predictions(
    *,
    dataset: BenchmarkDataset,
    cohort: CohortManifest,
    prediction_manifest_path: str | Path,
    critic_input_manifest_path: str | Path,
    unscored_predictions_path: str | Path,
    predict_run_metadata_path: str | Path,
) -> tuple[list[dict[str, Any]], dict[str, Any], dict[str, Any]]:
    """Validate the raw chain first; only then join benchmark gold."""

    prediction_manifest, cases = load_prediction_manifest(
        prediction_manifest_path
    )
    input_manifest, entries = load_global_critic_inputs(
        critic_input_manifest_path
    )
    if (
        input_manifest["prediction_manifest_sha256"]
        != prediction_manifest["prediction_manifest_sha256"]
        or dataset.dataset_sha256
        != prediction_manifest["dataset_manifest_sha256"]
        or cohort.dataset_manifest_sha256
        != prediction_manifest["dataset_manifest_sha256"]
        or cohort.cohort_name != prediction_manifest["cohort_name"]
        or cohort.cohort_sha256 != prediction_manifest["cohort_sha256"]
    ):
        raise GlobalCriticWorkflowError(
            "E7 scoring dataset/cohort lineage is invalid"
        )
    unscored_path = Path(unscored_predictions_path).expanduser().resolve()
    rows = _read_jsonl(unscored_path)
    if not rows:
        raise GlobalCriticWorkflowError("E7 has no unscored predictions")
    first_config = rows[0].get("provider_config")
    if not isinstance(first_config, Mapping):
        raise GlobalCriticWorkflowError(
            "E7 prediction provider config is missing"
        )
    try:
        config = BenchmarkRunConfig(**dict(first_config))
    except (TypeError, ValueError) as error:
        raise GlobalCriticWorkflowError(
            "E7 prediction provider config is invalid"
        ) from error
    by_case = {case.trajectory_id: case for case in cases}
    row_ids = [str(row.get("trajectory_id")) for row in rows]
    if (
        len(set(row_ids)) != len(row_ids)
        or not set(row_ids) <= set(by_case)
        or not set(row_ids) <= set(cohort.trajectory_ids)
    ):
        raise GlobalCriticWorkflowError(
            "E7 unscored identities are duplicated or outside the cohort"
        )
    validated = [
        _validate_unscored_row(
            row,
            case=by_case[str(row["trajectory_id"])],
            entry=entries[str(row["trajectory_id"])],
            input_manifest=input_manifest,
            prediction_manifest=prediction_manifest,
            config=config,
        )
        for row in rows
    ]
    run = _load_predict_run(
        path=predict_run_metadata_path,
        unscored_path=unscored_path,
        rows=validated,
        input_manifest=input_manifest,
        prediction_manifest=prediction_manifest,
        config=config,
    )

    # Gold is touched only after every raw response, prompt identity, evidence
    # repair, artifact hash, and run aggregate above has been reconstructed.
    examples = {
        example.label.trajectory_id: example for example in dataset.examples
    }
    scored: list[dict[str, Any]] = []
    for row in validated:
        trajectory_id = str(row["trajectory_id"])
        example = examples.get(trajectory_id)
        if example is None:
            raise GlobalCriticWorkflowError(
                "E7 trajectory has no benchmark scoring example"
            )
        case = by_case[trajectory_id]
        if (
            example.mapping.trajectory_sha256 != case.trajectory_sha256
            or tuple(
                (item.original_step, item.critical_event_id)
                for item in example.mapping.steps
            )
            != case.step_event_mapping
        ):
            raise GlobalCriticWorkflowError(
                "E7 scoring adaptation diverges from prediction manifest"
            )
        record = _base_record(
            example,
            method=E7_METHOD,
            config=config,
        )
        record.update(
            {
                "status": row["status"],
                "failure_stage": row["failure_stage"],
                "failure_code": row["failure_code"],
                "failure_message": row["failure_message"],
                "root_cause_judgment": row["root_cause_judgment"],
                "evidence_validation_issues": row[
                    "evidence_validation_issues"
                ],
                "evidence_repair": row["evidence_repair"],
                "raw_judge_outputs": row["raw_judge_outputs"],
                "stage_attempted": row["stage_attempted"],
                "stage_cache_hits": row["stage_cache_hits"],
                "stage_identities": row["stage_identities"],
                "stage_provider_telemetry": row[
                    "stage_provider_telemetry"
                ],
                "provider_telemetry": row["provider_telemetry"],
                "latency_seconds": row["latency_seconds"],
                "cache_hit": row["cache_hit"],
                "prompt_version": GLOBAL_CRITIC_PROMPT_PROTOCOL_VERSION,
                "pipeline_version": GLOBAL_CRITIC_PIPELINE_VERSION,
                "experiment": E7_EXPERIMENT,
                "initial_root": row["initial_root"],
            }
        )
        if row["root_cause_judgment"] is not None:
            root = parse_global_critic(
                json.dumps(
                    {
                        "critical_step": row["root_cause_judgment"][
                            "critical_step"
                        ],
                        "module": row["root_cause_judgment"]["module"],
                        "error_type": row["root_cause_judgment"][
                            "error_type"
                        ],
                        "evidence": row["root_cause_judgment"][
                            "evidence_quote"
                        ],
                        "root_cause": row["root_cause_judgment"][
                            "root_cause"
                        ],
                    },
                    ensure_ascii=False,
                ),
                view=case.judge_view,
            )
            _apply_root(record, example=example, root=root)
        scored.append(record)
    metrics = compute_metrics(scored)
    return scored, metrics, run


__all__ = [
    "E7_EXPERIMENT",
    "E7_INPUT_SCHEMA_VERSION",
    "E7_METHOD",
    "E7_PREDICTION_SCHEMA_VERSION",
    "E7_PREDICT_RUN_SCHEMA_VERSION",
    "GlobalCriticWorkflowError",
    "load_global_critic_inputs",
    "predict_global_critic_cases",
    "prepare_global_critic_inputs",
    "score_global_critic_predictions",
]

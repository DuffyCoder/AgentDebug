"""Gold-free, raw-first cache for production semantic judge stages."""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping

from agentdebug.diagnostics import JudgeOutputError, JudgeTransportError


STAGE_CACHE_SCHEMA_VERSION = "agentdebug.benchmark.semantic-stage-cache.v2"
RAW_STAGE_SCHEMA_VERSION = "agentdebug.benchmark.semantic-stage-raw.v2"
RAW_RESPONSE_SIDECAR_SCHEMA_VERSION = (
    "agentdebug.benchmark.semantic-stage-response-sidecar.v1"
)
STAGE_CACHE_IMPORT_PROVENANCE_SCHEMA_VERSION = (
    "agentdebug.benchmark.semantic-stage-import-provenance.v1"
)


class StageCacheError(RuntimeError):
    """A persisted semantic stage cannot be trusted or reconstructed."""


@dataclass(frozen=True)
class StageRequest:
    """Content-addressed identity for one provider completion."""

    stage: str
    request_sha256: str
    prompt_sha256: str
    identity: dict[str, Any]

    def expected(self) -> dict[str, Any]:
        return {
            "schema_version": STAGE_CACHE_SCHEMA_VERSION,
            "stage": self.stage,
            "request_sha256": self.request_sha256,
            "prompt_sha256": self.prompt_sha256,
            "identity": self.identity,
        }


def _json_safe(value: Any) -> Any:
    if isinstance(value, str) or value is None:
        return value
    try:
        return json.loads(json.dumps(value, ensure_ascii=False, default=str))
    except (TypeError, ValueError):
        return repr(value)


def stable_sha256(value: Any) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _forbidden_identity_key(key: str) -> bool:
    normalized = key.casefold()
    return (
        normalized.startswith("gold_")
        or normalized
        in {
            "critical_failure_step",
            "critical_failure_module",
            "critical_failure_type",
            "step_annotations",
            "score",
            "confidence",
            "step_exact",
            "step_module_exact",
            "all_correct",
        }
    )


def _assert_identity_gold_free(value: Any, *, location: str) -> None:
    if isinstance(value, Mapping):
        for key, item in value.items():
            if _forbidden_identity_key(str(key)):
                raise StageCacheError(
                    f"{location} contains forbidden scored/gold field {key!r}"
                )
            _assert_identity_gold_free(
                item,
                location=f"{location}.{key}",
            )
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _assert_identity_gold_free(
                item,
                location=f"{location}[{index}]",
            )


def build_stage_request(
    *,
    stage: str,
    messages: list[dict[str, str]],
    identity: Mapping[str, Any],
    dependency_sha256: str | None = None,
) -> StageRequest:
    """Bind one stage to its prompt, trace, pipeline, and provider config."""

    if not isinstance(stage, str) or not stage.strip():
        raise ValueError("semantic stage must be non-empty text")
    public_identity = _json_safe(dict(identity))
    if not isinstance(public_identity, dict):
        raise TypeError("semantic stage identity must be a JSON object")
    _assert_identity_gold_free(
        public_identity,
        location="semantic stage identity",
    )
    prompt_sha256 = stable_sha256(messages)
    request_identity = {
        **public_identity,
        "stage": stage,
        "prompt_sha256": prompt_sha256,
        "dependency_sha256": dependency_sha256,
    }
    return StageRequest(
        stage=stage,
        request_sha256=stable_sha256(request_identity),
        prompt_sha256=prompt_sha256,
        identity=request_identity,
    )


def _validate_request(
    request: StageRequest,
    *,
    messages: list[dict[str, str]],
) -> None:
    """Reject mutable or caller-mismatched request identities."""

    if not isinstance(request.identity, dict):
        raise StageCacheError("semantic stage request identity must be an object")
    _assert_identity_gold_free(
        request.identity,
        location="semantic stage request identity",
    )
    if request.identity.get("stage") != request.stage:
        raise StageCacheError("semantic stage request stage is invalid")
    actual_prompt_sha256 = stable_sha256(messages)
    if (
        request.prompt_sha256 != actual_prompt_sha256
        or request.identity.get("prompt_sha256") != actual_prompt_sha256
    ):
        raise StageCacheError(
            "semantic stage request does not match the actual prompt messages"
        )
    if request.request_sha256 != stable_sha256(request.identity):
        raise StageCacheError("semantic stage request identity hash is invalid")


def _atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def _atomic_bytes(path: Path, value: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_bytes(value)
    temporary.replace(path)


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _validated_sha256(value: Any, *, field: str) -> str:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or value != value.lower()
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise StageCacheError(f"{field} must be a lowercase SHA-256 digest")
    return value


def _read_json_object(path: Path, *, description: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise StageCacheError(f"{description} is corrupt") from error
    if not isinstance(value, dict):
        raise StageCacheError(f"{description} must be a JSON object")
    return value


def _archive_raw(raw_path: Path, *, history_root: Path) -> None:
    if not raw_path.is_file():
        return
    old = _read_json_object(
        raw_path,
        description="semantic stage raw artifact",
    )
    archive = (
        history_root
        / str(old.get("stage", "unknown"))
        / str(old.get("request_sha256", "unknown"))
        / f"{stable_sha256(old)}.json"
    )
    if not archive.is_file():
        _atomic_json(archive, old)


def _counter(value: Any, *, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise StageCacheError(
            f"provider telemetry {field} must be a non-negative integer"
        )
    return value


def _telemetry_snapshot(
    snapshotter: Callable[[], Mapping[str, Any] | None] | None,
) -> dict[str, Any] | None:
    if snapshotter is None:
        return None
    value = snapshotter()
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise StageCacheError("provider telemetry snapshot must be an object")
    result: dict[str, Any] = {}
    for field in (
        "logical_completion_count",
        "http_attempt_count",
        "retry_count",
        "request_input_chars",
        "provider_usage_response_count",
    ):
        result[field] = _counter(value.get(field), field=field)
    raw_tokens = value.get("provider_usage_token_totals")
    if not isinstance(raw_tokens, Mapping):
        raise StageCacheError("provider token telemetry must be an object")
    result["provider_usage_token_totals"] = {
        field: _counter(raw_tokens.get(field), field=field)
        for field in ("input_tokens", "output_tokens", "total_tokens")
    }
    raw_reasons = value.get("finish_reason_counts")
    if not isinstance(raw_reasons, Mapping):
        raise StageCacheError(
            "provider finish-reason telemetry must be an object"
        )
    result["finish_reason_counts"] = {
        str(reason): _counter(count, field=f"finish_reason.{reason}")
        for reason, count in raw_reasons.items()
    }
    return result


def _telemetry_delta(
    before: Mapping[str, Any] | None,
    after: Mapping[str, Any] | None,
) -> dict[str, Any] | None:
    if before is None and after is None:
        return None
    if before is None or after is None:
        raise StageCacheError(
            "provider telemetry disappeared during a semantic stage"
        )

    def difference(field: str) -> int:
        value = _counter(after.get(field), field=field) - _counter(
            before.get(field),
            field=field,
        )
        if value < 0:
            raise StageCacheError(
                f"provider telemetry counter {field} moved backwards"
            )
        return value

    result = {
        field: difference(field)
        for field in (
            "logical_completion_count",
            "http_attempt_count",
            "retry_count",
            "request_input_chars",
            "provider_usage_response_count",
        )
    }
    result["provider_usage_token_totals"] = {}
    before_tokens = before["provider_usage_token_totals"]
    after_tokens = after["provider_usage_token_totals"]
    for field in ("input_tokens", "output_tokens", "total_tokens"):
        value = _counter(after_tokens.get(field), field=field) - _counter(
            before_tokens.get(field),
            field=field,
        )
        if value < 0:
            raise StageCacheError(
                f"provider token telemetry counter {field} moved backwards"
            )
        result["provider_usage_token_totals"][field] = value

    before_reasons = before["finish_reason_counts"]
    after_reasons = after["finish_reason_counts"]
    reasons = set(before_reasons) | set(after_reasons)
    finish_delta: dict[str, int] = {}
    for reason in reasons:
        value = _counter(
            after_reasons.get(reason, 0),
            field=f"finish_reason.{reason}",
        ) - _counter(
            before_reasons.get(reason, 0),
            field=f"finish_reason.{reason}",
        )
        if value < 0:
            raise StageCacheError(
                f"provider finish-reason counter {reason} moved backwards"
            )
        if value:
            finish_delta[str(reason)] = value
    result["finish_reason_counts"] = finish_delta
    return result


def sum_stage_telemetry(
    values: list[Mapping[str, Any] | None],
) -> dict[str, Any] | None:
    """Sum persisted per-stage deltas, including cache-recovered calls."""

    present = [value for value in values if value is not None]
    if not present:
        return None
    if len(present) != len(values):
        raise StageCacheError(
            "cannot combine partial provider telemetry coverage"
        )
    result: dict[str, Any] = {
        field: 0
        for field in (
            "logical_completion_count",
            "http_attempt_count",
            "retry_count",
            "request_input_chars",
            "provider_usage_response_count",
        )
    }
    result["provider_usage_token_totals"] = {
        field: 0 for field in ("input_tokens", "output_tokens", "total_tokens")
    }
    result["finish_reason_counts"] = {}
    for value in present:
        for field in (
            "logical_completion_count",
            "http_attempt_count",
            "retry_count",
            "request_input_chars",
            "provider_usage_response_count",
        ):
            result[field] += _counter(value.get(field), field=field)
        tokens = value.get("provider_usage_token_totals")
        if not isinstance(tokens, Mapping):
            raise StageCacheError("stage token telemetry must be an object")
        for field in ("input_tokens", "output_tokens", "total_tokens"):
            result["provider_usage_token_totals"][field] += _counter(
                tokens.get(field),
                field=field,
            )
        reasons = value.get("finish_reason_counts")
        if not isinstance(reasons, Mapping):
            raise StageCacheError(
                "stage finish-reason telemetry must be an object"
            )
        for reason, count in reasons.items():
            normalized = str(reason)
            result["finish_reason_counts"][normalized] = (
                result["finish_reason_counts"].get(normalized, 0)
                + _counter(count, field=f"finish_reason.{normalized}")
            )
    return result


def _failure_status(error: JudgeOutputError) -> str:
    if error.code in {"invalid_taxonomy", "invalid_taxonomy_pair"}:
        return "invalid_taxonomy"
    if error.code in {
        "malformed_json",
        "empty_response",
        "invalid_top_level",
    }:
        return "invalid_json"
    return "invalid_output"


def _raw_path(cache_root: Path, request: StageRequest) -> Path:
    return (
        cache_root
        / "raw"
        / request.stage
        / f"{request.request_sha256}.json"
    )


def _parsed_path(cache_root: Path, request: StageRequest) -> Path:
    return (
        cache_root
        / "parsed"
        / request.stage
        / f"{request.request_sha256}.json"
    )


def _response_sidecar_path(
    cache_root: Path,
    request: StageRequest,
) -> Path:
    return (
        cache_root
        / "response_sidecar"
        / request.stage
        / f"{request.request_sha256}.json"
    )


def _response_sidecar(
    *,
    request: StageRequest,
    raw_response: Any,
    failure: Mapping[str, Any] | None,
) -> dict[str, Any]:
    value = {
        "schema_version": RAW_RESPONSE_SIDECAR_SCHEMA_VERSION,
        "stage": request.stage,
        "request_sha256": request.request_sha256,
        "response_sha256": stable_sha256(raw_response),
        "raw_response": raw_response,
        "failure": None if failure is None else dict(failure),
    }
    value["artifact_sha256"] = stable_sha256(value)
    return value


def _read_response_sidecar(
    path: Path,
    *,
    request: StageRequest,
) -> dict[str, Any]:
    value = _read_json_object(
        path,
        description="semantic stage response sidecar",
    )
    if set(value) != {
        "schema_version",
        "stage",
        "request_sha256",
        "response_sha256",
        "raw_response",
        "failure",
        "artifact_sha256",
    }:
        raise StageCacheError(
            "semantic stage response sidecar fields are invalid"
        )
    if (
        value["schema_version"] != RAW_RESPONSE_SIDECAR_SCHEMA_VERSION
        or value["stage"] != request.stage
        or value["request_sha256"] != request.request_sha256
    ):
        raise StageCacheError(
            "semantic stage response sidecar identity is invalid"
        )
    if value["response_sha256"] != stable_sha256(value["raw_response"]):
        raise StageCacheError(
            "semantic stage response sidecar response hash is invalid"
        )
    body = dict(value)
    claimed = body.pop("artifact_sha256")
    if claimed != stable_sha256(body):
        raise StageCacheError(
            "semantic stage response sidecar content hash is invalid"
        )
    failure = value["failure"]
    if failure is not None and (
        not isinstance(failure, Mapping)
        or set(failure)
        != {"status", "failure_stage", "failure_code", "failure_message"}
    ):
        raise StageCacheError(
            "semantic stage response sidecar failure envelope is invalid"
        )
    return value


def _raw_wrapper(
    *,
    request: StageRequest,
    raw_response: Any,
    failure: Mapping[str, Any] | None,
    telemetry_delta: Mapping[str, Any] | None,
    prior_telemetry: Mapping[str, Any] | None,
) -> dict[str, Any]:
    cumulative_telemetry = _combine_stage_telemetry(
        prior_telemetry,
        telemetry_delta,
    )
    value = {
        "schema_version": RAW_STAGE_SCHEMA_VERSION,
        "stage": request.stage,
        "request_sha256": request.request_sha256,
        "response_sha256": stable_sha256(raw_response),
        "raw_response": raw_response,
        "failure": None if failure is None else dict(failure),
        "telemetry_delta": (
            None if telemetry_delta is None else dict(telemetry_delta)
        ),
        "prior_telemetry": (
            None if prior_telemetry is None else dict(prior_telemetry)
        ),
        "cumulative_telemetry": cumulative_telemetry,
    }
    value["artifact_sha256"] = stable_sha256(value)
    return value


def _read_raw(path: Path, *, request: StageRequest) -> dict[str, Any]:
    wrapper = _read_json_object(
        path,
        description="semantic stage raw artifact",
    )
    expected_fields = {
        "schema_version",
        "stage",
        "request_sha256",
        "response_sha256",
        "raw_response",
        "failure",
        "telemetry_delta",
        "prior_telemetry",
        "cumulative_telemetry",
        "artifact_sha256",
    }
    if set(wrapper) != expected_fields:
        raise StageCacheError(
            "semantic stage raw artifact fields are invalid"
        )
    if (
        wrapper["schema_version"] != RAW_STAGE_SCHEMA_VERSION
        or wrapper["stage"] != request.stage
        or wrapper["request_sha256"] != request.request_sha256
    ):
        raise StageCacheError(
            "semantic stage raw artifact identity is invalid"
        )
    if wrapper["response_sha256"] != stable_sha256(
        wrapper["raw_response"]
    ):
        raise StageCacheError(
            "semantic stage raw response hash is invalid"
        )
    artifact_body = dict(wrapper)
    claimed_artifact_sha256 = artifact_body.pop("artifact_sha256")
    if claimed_artifact_sha256 != stable_sha256(artifact_body):
        raise StageCacheError(
            "semantic stage raw artifact content hash is invalid"
        )
    failure = wrapper["failure"]
    if failure is not None and (
        not isinstance(failure, Mapping)
        or set(failure)
        != {"status", "failure_stage", "failure_code", "failure_message"}
    ):
        raise StageCacheError(
            "semantic stage raw failure envelope is invalid"
        )
    telemetry = wrapper["telemetry_delta"]
    prior_telemetry = wrapper["prior_telemetry"]
    cumulative_telemetry = wrapper["cumulative_telemetry"]
    for value in (telemetry, prior_telemetry, cumulative_telemetry):
        if value is not None:
            sum_stage_telemetry([value])
    expected_cumulative = _combine_stage_telemetry(
        prior_telemetry,
        telemetry,
    )
    if cumulative_telemetry != expected_cumulative:
        raise StageCacheError(
            "semantic stage cumulative telemetry is invalid"
        )
    return wrapper


def _combine_stage_telemetry(
    prior: Mapping[str, Any] | None,
    current: Mapping[str, Any] | None,
) -> dict[str, Any] | None:
    if prior is None:
        return (
            None
            if current is None
            else sum_stage_telemetry([current])
        )
    if current is None:
        raise StageCacheError(
            "provider telemetry coverage disappeared across a stage retry"
        )
    return sum_stage_telemetry([prior, current])


def _record_from_raw(
    *,
    request: StageRequest,
    wrapper: Mapping[str, Any],
    parser: Callable[[Any], Any],
    latency_seconds: float,
) -> dict[str, Any]:
    record = {
        **request.expected(),
        "raw_response_sha256": wrapper["response_sha256"],
        "raw_response": wrapper["raw_response"],
        "parsed_output": None,
        "status": None,
        "failure_stage": None,
        "failure_code": None,
        "failure_message": None,
        "stage_telemetry": wrapper["cumulative_telemetry"],
        "latency_seconds": latency_seconds,
    }
    failure = wrapper["failure"]
    if failure is not None:
        record.update(dict(failure))
        return record
    try:
        record["parsed_output"] = _json_safe(parser(wrapper["raw_response"]))
        record["status"] = "success"
    except JudgeOutputError as error:
        record.update(
            {
                "status": _failure_status(error),
                "failure_stage": error.stage,
                "failure_code": error.code,
                "failure_message": error.safe_message,
            }
        )
    return record


def _validate_record(
    record: Mapping[str, Any],
    *,
    request: StageRequest,
    raw_path: Path,
    parser: Callable[[Any], Any],
) -> None:
    expected_fields = set(request.expected()) | {
        "raw_response_sha256",
        "raw_response",
        "parsed_output",
        "status",
        "failure_stage",
        "failure_code",
        "failure_message",
        "stage_telemetry",
        "latency_seconds",
    }
    if set(record) != expected_fields:
        raise StageCacheError(
            "semantic parsed stage cache fields are invalid"
        )
    for field, value in request.expected().items():
        if record.get(field) != value:
            raise StageCacheError(
                f"semantic parsed stage cache {field} is invalid"
            )
    wrapper = _read_raw(raw_path, request=request)
    if (
        record.get("raw_response") != wrapper["raw_response"]
        or record.get("raw_response_sha256")
        != wrapper["response_sha256"]
        or record.get("stage_telemetry")
        != wrapper["cumulative_telemetry"]
    ):
        raise StageCacheError(
            "semantic parsed stage cache diverges from raw artifact"
        )
    rebuilt = _record_from_raw(
        request=request,
        wrapper=wrapper,
        parser=parser,
        latency_seconds=float(record["latency_seconds"]),
    )
    if record != rebuilt:
        raise StageCacheError(
            "semantic parsed stage cache does not match raw semantics"
        )


def run_cached_stage(
    *,
    request: StageRequest,
    messages: list[dict[str, str]],
    complete: Callable[[list[dict[str, str]]], Any],
    parser: Callable[[Any], Any],
    cache_root: str | Path,
    retry_failures: bool,
    telemetry_snapshotter: (
        Callable[[], Mapping[str, Any] | None] | None
    ) = None,
    completion_guard: Callable[[], None] | None = None,
) -> tuple[dict[str, Any], bool]:
    """Persist provider output before parsing and recover interrupted stages."""

    _validate_request(request, messages=messages)
    root = Path(cache_root).expanduser().resolve()
    raw_path = _raw_path(root, request)
    parsed_path = _parsed_path(root, request)
    sidecar_path = _response_sidecar_path(root, request)
    cached: dict[str, Any] | None = None
    if parsed_path.is_file():
        cached = _read_json_object(
            parsed_path,
            description="semantic parsed stage cache",
        )
        _validate_record(
            cached,
            request=request,
            raw_path=raw_path,
            parser=parser,
        )
        if (
            not retry_failures
            or str(cached.get("status", "")).startswith("success")
        ):
            return cached, True

    if cached is None and raw_path.is_file():
        wrapper = _read_raw(raw_path, request=request)
        recovered = _record_from_raw(
            request=request,
            wrapper=wrapper,
            parser=parser,
            latency_seconds=0.0,
        )
        _validate_record(
            recovered,
            request=request,
            raw_path=raw_path,
            parser=parser,
        )
        _atomic_json(parsed_path, recovered)
        if (
            not retry_failures
            or str(recovered.get("status", "")).startswith("success")
        ):
            return recovered, True

    # A paid completion may have returned immediately before telemetry or
    # process finalization failed.  Its response sidecar is authoritative:
    # recover the raw response without another provider call.  Telemetry is
    # intentionally left unavailable rather than guessed.
    if not raw_path.is_file() and sidecar_path.is_file():
        sidecar = _read_response_sidecar(
            sidecar_path,
            request=request,
        )
        wrapper = _raw_wrapper(
            request=request,
            raw_response=sidecar["raw_response"],
            failure=sidecar["failure"],
            telemetry_delta=None,
            prior_telemetry=None,
        )
        _atomic_json(raw_path, wrapper)
        persisted = _read_raw(raw_path, request=request)
        recovered = _record_from_raw(
            request=request,
            wrapper=persisted,
            parser=parser,
            latency_seconds=0.0,
        )
        _validate_record(
            recovered,
            request=request,
            raw_path=raw_path,
            parser=parser,
        )
        _atomic_json(parsed_path, recovered)
        return recovered, True

    prior_telemetry: Mapping[str, Any] | None = None
    if raw_path.is_file():
        prior_wrapper = _read_raw(raw_path, request=request)
        prior_telemetry = prior_wrapper["cumulative_telemetry"]
    if sidecar_path.is_file():
        # Validate before making another paid attempt.  A corrupt sidecar must
        # fail closed and can never be silently replaced by a new response.
        _read_response_sidecar(sidecar_path, request=request)

    if completion_guard is not None:
        completion_guard()
    started = time.monotonic()
    before = _telemetry_snapshot(telemetry_snapshotter)
    raw: Any = None
    failure: dict[str, Any] | None = None
    try:
        raw = complete(messages)
    except JudgeTransportError as error:
        failure = {
            "status": error.code,
            "failure_stage": request.stage,
            "failure_code": error.code,
            "failure_message": error.safe_message,
        }
    except Exception:
        failure = {
            "status": "judge_exception",
            "failure_stage": request.stage,
            "failure_code": "judge_exception",
            "failure_message": (
                f"{request.stage} judge raised an unexpected exception; its "
                "message was omitted because it may contain sensitive data."
            ),
        }
    raw = _json_safe(raw)
    # This is deliberately the first write after ``complete`` returns.  It
    # contains only the immutable response/failure and request identity, so a
    # later telemetry exception or process interruption cannot trigger a
    # duplicate logical completion on recovery.
    sidecar = _response_sidecar(
        request=request,
        raw_response=raw,
        failure=failure,
    )
    _archive_raw(
        sidecar_path,
        history_root=root / "response_sidecar_history",
    )
    _atomic_json(sidecar_path, sidecar)
    after = _telemetry_snapshot(telemetry_snapshotter)
    telemetry_delta = _telemetry_delta(before, after)
    wrapper = _raw_wrapper(
        request=request,
        raw_response=raw,
        failure=failure,
        telemetry_delta=telemetry_delta,
        prior_telemetry=prior_telemetry,
    )
    _archive_raw(
        raw_path,
        history_root=root / "raw_history",
    )
    _atomic_json(raw_path, wrapper)
    persisted = _read_raw(raw_path, request=request)
    record = _record_from_raw(
        request=request,
        wrapper=persisted,
        parser=parser,
        latency_seconds=time.monotonic() - started,
    )
    _validate_record(
        record,
        request=request,
        raw_path=raw_path,
        parser=parser,
    )
    _atomic_json(parsed_path, record)
    return record, False


def import_cached_stage_response(
    *,
    request: StageRequest,
    messages: list[dict[str, str]],
    parser: Callable[[Any], Any],
    source_cache_root: str | Path,
    target_cache_root: str | Path,
    expected_raw_response_sha256: str,
    expected_source_file_sha256s: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    """Import one exact paid response without permitting a provider call.

    Only the immutable raw wrapper and response sidecar are copied.  The
    parsed artifact is rebuilt from that raw response with the caller's
    current parser, so a deliberate parser revision never trusts stale parsed
    output from the source cache.  The target must be a fresh, empty cache
    root and is installed only after all three target artifacts validate.
    """

    _validate_request(request, messages=messages)
    expected_response = _validated_sha256(
        expected_raw_response_sha256,
        field="expected raw-response hash",
    )
    expected_files: dict[str, str] | None = None
    if expected_source_file_sha256s is not None:
        expected_files = dict(expected_source_file_sha256s)
        if set(expected_files) != {"raw", "response_sidecar"}:
            raise StageCacheError(
                "expected source file hashes must contain raw and "
                "response_sidecar"
            )
        expected_files = {
            key: _validated_sha256(
                value,
                field=f"expected source {key} file hash",
            )
            for key, value in expected_files.items()
        }

    source_root = Path(source_cache_root).expanduser().resolve()
    target_root = Path(target_cache_root).expanduser().resolve()
    if (
        source_root == target_root
        or target_root.is_relative_to(source_root)
        or source_root.is_relative_to(target_root)
    ):
        raise StageCacheError(
            "source and target stage-cache roots must be disjoint"
        )
    if not source_root.is_dir():
        raise StageCacheError("source stage-cache root is missing")
    if target_root.exists() and (
        not target_root.is_dir() or any(target_root.iterdir())
    ):
        raise StageCacheError("target stage-cache root must be empty")

    source_raw_path = _raw_path(source_root, request)
    source_sidecar_path = _response_sidecar_path(source_root, request)
    if not source_raw_path.is_file() or not source_sidecar_path.is_file():
        raise StageCacheError(
            "source cache omits the exact raw response or sidecar"
        )
    wrapper = _read_raw(source_raw_path, request=request)
    sidecar = _read_response_sidecar(
        source_sidecar_path,
        request=request,
    )
    if (
        wrapper["response_sha256"] != expected_response
        or sidecar["response_sha256"] != expected_response
        or wrapper["raw_response"] != sidecar["raw_response"]
        or wrapper["failure"] != sidecar["failure"]
    ):
        raise StageCacheError(
            "source raw response and response sidecar do not match"
        )
    if wrapper["failure"] is not None:
        raise StageCacheError(
            "only a successfully returned stage response can be imported"
        )

    try:
        raw_bytes = source_raw_path.read_bytes()
        sidecar_bytes = source_sidecar_path.read_bytes()
        raw_from_bytes = json.loads(raw_bytes.decode("utf-8"))
        sidecar_from_bytes = json.loads(sidecar_bytes.decode("utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise StageCacheError(
            "source stage-cache bytes changed or are corrupt"
        ) from error
    if raw_from_bytes != wrapper or sidecar_from_bytes != sidecar:
        raise StageCacheError(
            "source stage-cache bytes changed during validation"
        )
    source_file_hashes = {
        "raw": hashlib.sha256(raw_bytes).hexdigest(),
        "response_sidecar": hashlib.sha256(sidecar_bytes).hexdigest(),
    }
    if expected_files is not None and source_file_hashes != expected_files:
        raise StageCacheError(
            "source stage-cache file hash differs from the expected artifact"
        )

    target_root.parent.mkdir(parents=True, exist_ok=True)
    staging_root = Path(
        tempfile.mkdtemp(
            prefix=f".{target_root.name}.stage-import-",
            dir=target_root.parent,
        )
    ).resolve()
    installed = False
    try:
        target_raw_path = _raw_path(staging_root, request)
        target_sidecar_path = _response_sidecar_path(
            staging_root,
            request,
        )
        _atomic_bytes(target_raw_path, raw_bytes)
        _atomic_bytes(target_sidecar_path, sidecar_bytes)

        completion_called = False

        def forbidden_complete(
            _messages: list[dict[str, str]],
        ) -> Any:
            nonlocal completion_called
            completion_called = True
            raise StageCacheError(
                "stage-cache import attempted a provider completion"
            )

        def forbid_cache_miss() -> None:
            raise StageCacheError(
                "stage-cache import unexpectedly missed the copied response"
            )

        record, cache_hit = run_cached_stage(
            request=request,
            messages=messages,
            complete=forbidden_complete,
            parser=parser,
            cache_root=staging_root,
            retry_failures=False,
            completion_guard=forbid_cache_miss,
        )
        if completion_called or cache_hit is not True:
            raise StageCacheError(
                "stage-cache import did not remain cache-only"
            )
        if record["status"] != "success":
            raise StageCacheError(
                "current parser rejects the imported raw stage response"
            )

        relative_raw = str(target_raw_path.relative_to(staging_root))
        relative_sidecar = str(
            target_sidecar_path.relative_to(staging_root)
        )
        target_parsed_path = _parsed_path(staging_root, request)
        relative_parsed = str(
            target_parsed_path.relative_to(staging_root)
        )
        target_files = {
            relative_raw: _file_sha256(target_raw_path),
            relative_sidecar: _file_sha256(target_sidecar_path),
            relative_parsed: _file_sha256(target_parsed_path),
        }
        actual_files = {
            str(path.relative_to(staging_root))
            for path in staging_root.rglob("*")
            if path.is_file()
        }
        if actual_files != set(target_files):
            raise StageCacheError(
                "stage-cache import materialized unexpected artifacts"
            )
        if (
            target_files[relative_raw] != source_file_hashes["raw"]
            or target_files[relative_sidecar]
            != source_file_hashes["response_sidecar"]
        ):
            raise StageCacheError(
                "imported immutable artifacts differ from their source"
            )

        provenance: dict[str, Any] = {
            "schema_version": (
                STAGE_CACHE_IMPORT_PROVENANCE_SCHEMA_VERSION
            ),
            "stage": request.stage,
            "request_sha256": request.request_sha256,
            "prompt_sha256": request.prompt_sha256,
            "dependency_sha256": request.identity.get(
                "dependency_sha256"
            ),
            "raw_response_sha256": expected_response,
            "source_cache_root": str(source_root),
            "target_cache_root": str(target_root),
            "source_files": {
                str(source_raw_path.relative_to(source_root)): (
                    source_file_hashes["raw"]
                ),
                str(source_sidecar_path.relative_to(source_root)): (
                    source_file_hashes["response_sidecar"]
                ),
            },
            "target_files": target_files,
            "target_file_count": len(target_files),
            "target_files_sha256": stable_sha256(target_files),
            "parsed_output_sha256": stable_sha256(
                record["parsed_output"]
            ),
            "stage_telemetry_sha256": stable_sha256(
                record["stage_telemetry"]
            ),
            "provider_completion_called": False,
            "materialized_status": record["status"],
        }
        provenance["provenance_sha256"] = stable_sha256(provenance)

        if target_root.exists():
            if not target_root.is_dir() or any(target_root.iterdir()):
                raise StageCacheError(
                    "target stage-cache root stopped being empty"
                )
            target_root.rmdir()
        staging_root.replace(target_root)
        installed = True
        return provenance
    finally:
        if not installed and staging_root.exists():
            shutil.rmtree(staging_root)


__all__ = [
    "RAW_RESPONSE_SIDECAR_SCHEMA_VERSION",
    "RAW_STAGE_SCHEMA_VERSION",
    "STAGE_CACHE_SCHEMA_VERSION",
    "STAGE_CACHE_IMPORT_PROVENANCE_SCHEMA_VERSION",
    "StageCacheError",
    "StageRequest",
    "build_stage_request",
    "import_cached_stage_response",
    "run_cached_stage",
    "stable_sha256",
    "sum_stage_telemetry",
]

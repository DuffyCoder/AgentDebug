"""Gold-isolated production prediction and independent benchmark scoring."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from agentdebug.diagnostics import (
    EVIDENCE_REPAIR_MAX_ATTEMPTS,
    EVIDENCE_REPAIR_PIPELINE_VERSION,
    EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION,
    EVIDENCE_VALIDATION_VERSION,
    EvidenceRepairRequest,
    JudgeOutputError,
    RootCauseJudgment,
    build_evidence_repair_request,
    evidence_repair_messages,
    handoff_ledger_messages,
    handoff_selector_messages,
    parse_evidence_repair,
    parse_handoff_ledger,
    parse_handoff_selector,
    validate_evidence,
)

from .cohort import CohortManifest
from .models import BenchmarkDataset
from .prediction_manifest import (
    PredictionCase,
    PredictionManifestError,
    load_prediction_manifest,
    stable_sha256,
)
from .runner import (
    BenchmarkRunConfig,
    _apply_root,
    _base_record,
    _two_stage_identity,
    predict_two_stage_case,
)
from .prompts import (
    TWO_STAGE_PIPELINE_VERSION,
    TWO_STAGE_PROMPT_VERSION,
)
from .stage_cache import (
    build_stage_request,
    run_cached_stage,
    stable_sha256 as stage_stable_sha256,
    sum_stage_telemetry,
)


UNSCORED_PREDICTION_SCHEMA_VERSION = (
    "agentdebug.benchmark.production-unscored-prediction.v2"
)
PREDICT_RUN_SCHEMA_VERSION = (
    "agentdebug.benchmark.production-predict-run.v2"
)
PRODUCTION_TWO_STAGE_PIPELINE_VERSION = (
    "agentdebug.production-two-stage-handoff-selector-"
    "conditional-evidence-repair.v1"
)
_SEMANTIC_STAGES = ("handoff_ledger", "handoff_selector")
_ALL_STAGES = (*_SEMANTIC_STAGES, "evidence_repair")
_REPAIR_STATE_FIELDS = {
    "eligible",
    "attempted",
    "applied",
    "status",
    "failure_stage",
    "failure_code",
    "failure_message",
    "repair_input_sha256",
}


class ProductionWorkflowError(ValueError):
    """A production predict/score artifact is unsafe or inconsistent."""


class _LogicalCompletionBudget:
    def __init__(self, maximum: int | None) -> None:
        if maximum is not None and (
            isinstance(maximum, bool)
            or not isinstance(maximum, int)
            or maximum < 1
        ):
            raise ValueError(
                "max_logical_completions must be a positive integer"
            )
        self.maximum = maximum
        self.issued = 0

    def before_complete(self) -> None:
        if self.maximum is not None and self.issued >= self.maximum:
            raise ProductionWorkflowError(
                "production logical-completion budget is exhausted"
            )
        self.issued += 1


_FORBIDDEN_UNSCORED_KEYS = {
    "all_correct",
    "confidence",
    "gold_error_type",
    "gold_event_id",
    "gold_module",
    "gold_normalization_notes",
    "gold_raw_error_type",
    "gold_raw_module",
    "gold_reasoning",
    "gold_step",
    "step_exact",
    "step_module_exact",
    "score",
    "weight",
    "weights",
}


def _canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    ).encode("utf-8")


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(text, encoding="utf-8")
    temporary.replace(path)


def _atomic_json(path: Path, value: Any) -> None:
    _atomic_text(
        path,
        json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n",
    )


def _atomic_jsonl(
    path: Path,
    values: Sequence[Mapping[str, Any]],
) -> None:
    _atomic_text(
        path,
        "".join(
            json.dumps(value, ensure_ascii=False, default=str) + "\n"
            for value in values
        ),
    )


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    values: list[dict[str, Any]] = []
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as error:
        raise ProductionWorkflowError(
            "unscored predictions cannot be read"
        ) from error
    for line_number, line in enumerate(lines, 1):
        if not line.strip():
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError as error:
            raise ProductionWorkflowError(
                f"unscored prediction line {line_number} is invalid JSON"
            ) from error
        if not isinstance(value, dict):
            raise ProductionWorkflowError(
                f"unscored prediction line {line_number} is not an object"
            )
        values.append(value)
    return values


def _assert_unscored_gold_free(value: Any, *, location: str) -> None:
    """Reject evaluator fields while retaining immutable raw model output."""

    if isinstance(value, Mapping):
        forbidden = sorted(
            str(key)
            for key in value
            if str(key).casefold() in _FORBIDDEN_UNSCORED_KEYS
            or str(key).casefold().startswith("gold_")
        )
        if forbidden:
            raise ProductionWorkflowError(
                f"{location} contains evaluator fields: "
                + ", ".join(forbidden)
            )
        for key, item in value.items():
            # Invalid model output must still be preserved byte-for-byte.  It
            # is untrusted evidence, not an evaluator-created field.
            if key == "raw_judge_outputs":
                continue
            _assert_unscored_gold_free(
                item,
                location=f"{location}.{key}",
            )
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _assert_unscored_gold_free(
                item,
                location=f"{location}[{index}]",
            )


def _repair_request_snapshot(
    request: EvidenceRepairRequest,
) -> dict[str, Any]:
    return {
        "trace_id": request.trace_id,
        "judge_view_version": request.judge_view_version,
        "step_count": request.step_count,
        "critical_event_id": request.critical_event_id,
        "evidence_event_ids": list(request.evidence_event_ids),
        "semantic_root": request.semantic_root.to_dict(),
        "invalid_evidence": request.invalid_evidence,
        "source_strings": list(request.source_strings),
    }


def _empty_repair_state() -> dict[str, Any]:
    return {
        "eligible": False,
        "attempted": False,
        "applied": False,
        "status": "not_applicable",
        "failure_stage": None,
        "failure_code": None,
        "failure_message": None,
        "repair_input_sha256": None,
    }


def _initialize_repair_envelope(prediction: dict[str, Any]) -> None:
    """Extend the E5c prediction with a fixed, initially empty E5d stage."""

    for field in (
        "stage_attempted",
        "stage_cache_hits",
        "stage_identities",
        "stage_provider_telemetry",
    ):
        value = prediction.get(field)
        if not isinstance(value, dict) or set(value) != set(
            _SEMANTIC_STAGES
        ):
            raise ProductionWorkflowError(
                f"base two-stage prediction {field} is invalid"
            )
    prediction["stage_attempted"]["evidence_repair"] = False
    prediction["stage_cache_hits"]["evidence_repair"] = False
    prediction["stage_identities"]["evidence_repair"] = None
    prediction["stage_provider_telemetry"]["evidence_repair"] = None
    prediction["selector_root_cause_judgment"] = prediction.get(
        "root_cause_judgment"
    )
    prediction["selector_evidence_validation_issues"] = []
    prediction["evidence_repair"] = _empty_repair_state()
    prediction["production_pipeline_version"] = (
        PRODUCTION_TWO_STAGE_PIPELINE_VERSION
    )


def _selector_root(
    case: PredictionCase,
    prediction: Mapping[str, Any],
) -> RootCauseJudgment | None:
    raw_outputs = prediction.get("raw_judge_outputs")
    if not isinstance(raw_outputs, Mapping):
        raise ProductionWorkflowError(
            "semantic prediction raw outputs must be an object"
        )
    raw_selector = raw_outputs.get("handoff_selector")
    if raw_selector is None:
        if prediction.get("selector_root_cause_judgment") is not None:
            raise ProductionWorkflowError(
                "selector root exists without a raw selector output"
            )
        return None
    try:
        root = parse_handoff_selector(
            raw_selector,
            trace=case.judge_view,
        )
    except JudgeOutputError:
        if prediction.get("selector_root_cause_judgment") is not None:
            raise ProductionWorkflowError(
                "stored selector root cannot be reconstructed from raw"
            )
        return None
    if root.to_dict() != prediction.get(
        "selector_root_cause_judgment"
    ):
        raise ProductionWorkflowError(
            "stored selector semantics diverge from raw output"
        )
    return root


def _repair_eligible(validation: Any) -> bool:
    issues = tuple(validation.issues)
    return (
        not validation.valid
        and len(issues) == 1
        and issues[0].level == "error"
        and issues[0].code == "evidence_quote_not_found"
    )


def _repair_stage_request(
    *,
    case: PredictionCase,
    config: BenchmarkRunConfig,
    selector_root: RootCauseJudgment,
    selector_raw_sha256: str,
) -> tuple[Any, list[dict[str, str]], EvidenceRepairRequest, str]:
    request = build_evidence_repair_request(
        case.judge_view,
        selector_root,
    )
    request_snapshot = _repair_request_snapshot(request)
    repair_input_sha256 = stage_stable_sha256(request_snapshot)
    messages = evidence_repair_messages(request)
    identity = {
        **_two_stage_identity(case, config=config),
        "production_pipeline_version": (
            PRODUCTION_TWO_STAGE_PIPELINE_VERSION
        ),
        "evidence_repair_pipeline_version": (
            EVIDENCE_REPAIR_PIPELINE_VERSION
        ),
        "evidence_repair_prompt_protocol_version": (
            EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
        ),
        "evidence_repair_max_attempts": EVIDENCE_REPAIR_MAX_ATTEMPTS,
        "repair_input_sha256": repair_input_sha256,
        "frozen_semantic_root_sha256": stage_stable_sha256(
            request.semantic_root.to_dict()
        ),
    }
    dependency_sha256 = stage_stable_sha256(
        {
            "selector_raw_response_sha256": selector_raw_sha256,
            "selector_root": selector_root.to_dict(),
        }
    )
    stage_request = build_stage_request(
        stage="evidence_repair",
        messages=messages,
        identity=identity,
        dependency_sha256=dependency_sha256,
    )
    return stage_request, messages, request, repair_input_sha256


def _apply_final_root(
    case: PredictionCase,
    prediction: dict[str, Any],
    root: RootCauseJudgment,
) -> None:
    mapped_step = case.step_for_event(root.critical_event_id)
    prediction.update(
        {
            "root_cause_judgment": root.to_dict(),
            "judge_reported_step": root.critical_step,
            "predicted_step": mapped_step,
            "predicted_event_id": root.critical_event_id,
            "predicted_module": root.module.value,
            "predicted_error_type": root.error_type.value,
            "root_cause": root.root_cause,
            "judge_step_matches_event_mapping": (
                mapped_step is not None
                and root.critical_step == mapped_step
            ),
        }
    )


def _recompute_prediction_telemetry(
    prediction: dict[str, Any],
) -> None:
    attempted = prediction["stage_attempted"]
    telemetry = prediction["stage_provider_telemetry"]
    attempted_stages = [
        stage for stage in _ALL_STAGES if attempted[stage]
    ]
    present = [
        telemetry[stage]
        for stage in attempted_stages
        if telemetry[stage] is not None
    ]
    missing = [
        stage for stage in attempted_stages if telemetry[stage] is None
    ]
    subtotal = sum_stage_telemetry(present) if present else None
    prediction["provider_telemetry"] = (
        subtotal if not missing else None
    )
    prediction["provider_telemetry_known_subtotal"] = subtotal
    prediction["provider_telemetry_coverage"] = {
        "attempted_stage_count": len(attempted_stages),
        "recorded_stage_count": len(present),
        "missing_stages": missing,
        "complete": not missing,
    }


def _aggregate_run_telemetry(
    rows: Sequence[Mapping[str, Any]],
) -> tuple[dict[str, Any] | None, dict[str, Any] | None, dict[str, Any]]:
    present: list[Mapping[str, Any]] = []
    missing: list[str] = []
    attempted_count = 0
    for row in rows:
        trajectory_id = str(row.get("trajectory_id"))
        attempted = row.get("stage_attempted")
        telemetry = row.get("stage_provider_telemetry")
        if not isinstance(attempted, Mapping) or not isinstance(
            telemetry,
            Mapping,
        ):
            raise ProductionWorkflowError(
                "prediction stage telemetry envelope is invalid"
            )
        for stage in _ALL_STAGES:
            if not attempted.get(stage):
                continue
            attempted_count += 1
            value = telemetry.get(stage)
            if value is None:
                missing.append(f"{trajectory_id}:{stage}")
            elif isinstance(value, Mapping):
                present.append(value)
            else:
                raise ProductionWorkflowError(
                    "prediction stage telemetry must be an object or null"
                )
    subtotal = sum_stage_telemetry(present) if present else None
    coverage = {
        "attempted_stage_count": attempted_count,
        "recorded_stage_count": len(present),
        "missing_stage_count": len(missing),
        "missing_stage_refs": missing,
        "complete": not missing,
    }
    return subtotal if not missing else None, subtotal, coverage


def _evidence_audit(
    case: PredictionCase,
    prediction: dict[str, Any],
    *,
    config: BenchmarkRunConfig,
) -> RootCauseJudgment | None:
    """Rebuild selector/repair semantics from raw stages without gold."""

    prediction["candidate_evidence_validation_issues"] = []
    prediction["selector_evidence_validation_issues"] = []
    prediction["evidence_validation_issues"] = []
    raw_outputs = prediction.get("raw_judge_outputs")
    if not isinstance(raw_outputs, Mapping):
        raise ProductionWorkflowError(
            "semantic prediction raw outputs must be an object"
        )
    raw_ledger = raw_outputs.get("handoff_ledger")
    if raw_ledger is not None:
        try:
            ledger = parse_handoff_ledger(
                raw_ledger,
                trace=case.judge_view,
            )
        except JudgeOutputError:
            ledger = None
        if ledger is not None:
            candidate_issues: list[dict[str, Any]] = []
            for index, candidate in enumerate(ledger.candidates):
                validation = validate_evidence(
                    case.judge_view,
                    candidate,
                    stage=f"handoff_ledger.candidates[{index}]",
                )
                candidate_issues.extend(
                    issue.to_dict() for issue in validation.issues
                )
            prediction[
                "candidate_evidence_validation_issues"
            ] = candidate_issues

    state = prediction.get("evidence_repair")
    if not isinstance(state, Mapping) or set(state) != _REPAIR_STATE_FIELDS:
        raise ProductionWorkflowError(
            "evidence repair state does not match its schema"
        )
    selector_root = _selector_root(case, prediction)
    if selector_root is None:
        if dict(state) != _empty_repair_state():
            raise ProductionWorkflowError(
                "repair state exists without a parsed selector root"
            )
        return None

    selector_validation = validate_evidence(
        case.judge_view,
        selector_root,
        stage="handoff_selector",
    )
    selector_issues = [
        issue.to_dict() for issue in selector_validation.issues
    ]
    prediction["selector_evidence_validation_issues"] = selector_issues
    mapped_step = case.step_for_event(selector_root.critical_event_id)
    mapping_valid = (
        mapped_step is not None
        and mapped_step == selector_root.critical_step
    )
    eligible = mapping_valid and _repair_eligible(selector_validation)
    if state.get("eligible") is not eligible:
        raise ProductionWorkflowError(
            "persisted evidence repair eligibility diverges from selector raw"
        )

    attempted = state.get("attempted")
    applied = state.get("applied")
    if not isinstance(attempted, bool) or not isinstance(applied, bool):
        raise ProductionWorkflowError(
            "evidence repair attempted/applied flags must be boolean"
        )
    if attempted is not eligible:
        raise ProductionWorkflowError(
            "eligible evidence repair was not attempted exactly once"
        )

    final_root = selector_root
    if attempted:
        selector_identity = prediction["stage_identities"][
            "handoff_selector"
        ]
        if not isinstance(selector_identity, Mapping):
            raise ProductionWorkflowError(
                "evidence repair is missing selector identity"
            )
        (
            _,
            _,
            request,
            repair_input_sha256,
        ) = _repair_stage_request(
            case=case,
            config=config,
            selector_root=selector_root,
            selector_raw_sha256=str(
                selector_identity["raw_response_sha256"]
            ),
        )
        if state.get("repair_input_sha256") != repair_input_sha256:
            raise ProductionWorkflowError(
                "evidence repair input identity diverges from selector raw"
            )
        raw_repair = raw_outputs.get("evidence_repair")
        if state.get("status") == "success":
            try:
                repaired = parse_evidence_repair(
                    raw_repair,
                    request=request,
                )
            except JudgeOutputError as error:
                raise ProductionWorkflowError(
                    "successful evidence repair cannot be rebuilt from raw"
                ) from error
            repaired_validation = validate_evidence(
                case.judge_view,
                repaired,
                stage="evidence_repair",
            )
            if not repaired_validation.valid or applied is not True:
                raise ProductionWorkflowError(
                    "successful evidence repair is not strictly valid"
                )
            final_root = repaired
        else:
            if applied:
                raise ProductionWorkflowError(
                    "failed evidence repair cannot be applied"
                )
            if raw_repair is not None:
                try:
                    parse_evidence_repair(raw_repair, request=request)
                except JudgeOutputError:
                    pass
                else:
                    raise ProductionWorkflowError(
                        "valid repair raw is persisted as a failed attempt"
                    )
    else:
        expected_status = (
            "not_needed"
            if selector_validation.valid and mapping_valid
            else "not_eligible"
        )
        expected_state = {
            "eligible": False,
            "attempted": False,
            "applied": False,
            "status": expected_status,
            "failure_stage": None,
            "failure_code": None,
            "failure_message": None,
            "repair_input_sha256": None,
        }
        if dict(state) != expected_state:
            raise ProductionWorkflowError(
                "unattempted evidence repair state is inconsistent"
            )

    if prediction.get("root_cause_judgment") != final_root.to_dict():
        raise ProductionWorkflowError(
            "stored final root diverges from selector/repair raw chain"
        )
    _apply_final_root(case, prediction, final_root)
    validation = validate_evidence(
        case.judge_view,
        final_root,
        stage=(
            "evidence_repair" if applied else "handoff_selector"
        ),
    )
    prediction["evidence_validation_issues"] = [
        issue.to_dict() for issue in validation.issues
    ]
    if not mapping_valid:
        prediction.update(
            {
                "status": "invalid_output",
                "failure_stage": "mapping",
                "failure_code": "critical_event_not_a_decision_step",
                "failure_message": (
                    "The selected event is not one uniquely mapped public "
                    "benchmark decision step."
                ),
            }
        )
    elif not validation.valid:
        prediction.update(
            {
                "status": "evidence_invalid",
                "failure_stage": "evidence_validation",
                "failure_code": "invalid_evidence",
                "failure_message": (
                    "The selected evidence is not one strict observable "
                    "single-source substring at the selected step."
                ),
            }
        )
    else:
        prediction["status"] = (
            "success_needs_review"
            if validation.needs_review
            else "success"
        )
        prediction["failure_stage"] = None
        prediction["failure_code"] = None
        prediction["failure_message"] = None
    return final_root


def _maybe_repair_prediction(
    *,
    case: PredictionCase,
    prediction: dict[str, Any],
    judge: Any,
    config: BenchmarkRunConfig,
    cache_dir: str | Path,
    completion_guard: Callable[[], None] | None,
) -> None:
    """Attempt the sole mechanical evidence-only repair, if eligible."""

    selector_root = _selector_root(case, prediction)
    if selector_root is None:
        return
    selector_validation = validate_evidence(
        case.judge_view,
        selector_root,
        stage="handoff_selector",
    )
    mapped_step = case.step_for_event(selector_root.critical_event_id)
    mapping_valid = (
        mapped_step is not None
        and mapped_step == selector_root.critical_step
    )
    if not (mapping_valid and _repair_eligible(selector_validation)):
        prediction["evidence_repair"]["status"] = (
            "not_needed"
            if selector_validation.valid and mapping_valid
            else "not_eligible"
        )
        return

    selector_identity = prediction["stage_identities"][
        "handoff_selector"
    ]
    if not isinstance(selector_identity, Mapping):
        raise ProductionWorkflowError(
            "eligible evidence repair lacks selector identity"
        )
    (
        stage_request,
        messages,
        request,
        repair_input_sha256,
    ) = _repair_stage_request(
        case=case,
        config=config,
        selector_root=selector_root,
        selector_raw_sha256=str(
            selector_identity["raw_response_sha256"]
        ),
    )

    def parse_and_validate(raw: Any) -> dict[str, Any]:
        root = parse_evidence_repair(raw, request=request)
        validation = validate_evidence(
            case.judge_view,
            root,
            stage="evidence_repair",
        )
        if not validation.valid:
            raise JudgeOutputError(
                "evidence_repair",
                "evidence_quote_not_found",
                "Repaired evidence failed strict trace validation.",
                raw_output=raw,
            )
        return root.to_dict()

    complete = getattr(judge, "complete", None)
    if not callable(complete):
        raise TypeError(
            "production evidence repair requires judge.complete(messages)"
        )
    raw_snapshotter = getattr(judge, "telemetry_snapshot", None)
    telemetry_snapshotter = (
        raw_snapshotter if callable(raw_snapshotter) else None
    )
    prediction["stage_attempted"]["evidence_repair"] = True
    stage, cache_hit = run_cached_stage(
        request=stage_request,
        messages=messages,
        complete=complete,
        parser=parse_and_validate,
        cache_root=Path(cache_dir) / "semantic_stages",
        # A persisted semantic/format failure is final. Transport retries
        # remain inside the provider's one logical completion.
        retry_failures=False,
        telemetry_snapshotter=telemetry_snapshotter,
        completion_guard=completion_guard,
    )
    prediction["stage_cache_hits"]["evidence_repair"] = cache_hit
    prediction["stage_identities"]["evidence_repair"] = {
        "request_sha256": stage["request_sha256"],
        "prompt_sha256": stage["prompt_sha256"],
        "raw_response_sha256": stage["raw_response_sha256"],
        "dependency_sha256": stage["identity"]["dependency_sha256"],
    }
    prediction["raw_judge_outputs"]["evidence_repair"] = stage[
        "raw_response"
    ]
    prediction["stage_provider_telemetry"]["evidence_repair"] = stage[
        "stage_telemetry"
    ]
    prediction["latency_seconds"] = float(
        prediction.get("latency_seconds") or 0.0
    ) + float(stage["latency_seconds"])
    applied = stage["status"] == "success"
    prediction["evidence_repair"] = {
        "eligible": True,
        "attempted": True,
        "applied": applied,
        "status": stage["status"],
        "failure_stage": stage["failure_stage"],
        "failure_code": stage["failure_code"],
        "failure_message": stage["failure_message"],
        "repair_input_sha256": repair_input_sha256,
    }
    if applied:
        repaired = parse_evidence_repair(
            stage["raw_response"],
            request=request,
        )
        _apply_final_root(case, prediction, repaired)
    _recompute_prediction_telemetry(prediction)


def _wrap_prediction(
    *,
    prediction: Mapping[str, Any],
    case: PredictionCase,
    manifest_sha256: str,
    config: BenchmarkRunConfig,
) -> dict[str, Any]:
    value = {
        "schema_version": UNSCORED_PREDICTION_SCHEMA_VERSION,
        "prediction_manifest_sha256": manifest_sha256,
        "production_pipeline_version": (
            PRODUCTION_TWO_STAGE_PIPELINE_VERSION
        ),
        "two_stage_pipeline_version": TWO_STAGE_PIPELINE_VERSION,
        "two_stage_prompt_version": TWO_STAGE_PROMPT_VERSION,
        "evidence_repair_pipeline_version": (
            EVIDENCE_REPAIR_PIPELINE_VERSION
        ),
        "evidence_repair_prompt_protocol_version": (
            EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
        ),
        "evidence_repair_max_attempts": EVIDENCE_REPAIR_MAX_ATTEMPTS,
        "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
        "provider_config": config.public_dict(),
        **dict(prediction),
    }
    if value.get("trajectory_id") != case.trajectory_id:
        raise ProductionWorkflowError(
            "semantic prediction trajectory identity changed"
        )
    _assert_unscored_gold_free(value, location="unscored prediction")
    value["unscored_prediction_sha256"] = stable_sha256(value)
    return value


def _validate_telemetry(
    telemetry: Any,
    *,
    max_retries: int,
) -> None:
    if not isinstance(telemetry, Mapping):
        raise ProductionWorkflowError(
            "production provider telemetry is missing"
        )

    def counter(field: str) -> int:
        value = telemetry.get(field)
        if (
            isinstance(value, bool)
            or not isinstance(value, int)
            or value < 0
        ):
            raise ProductionWorkflowError(
                f"provider telemetry {field} is invalid"
            )
        return value

    logical = counter("logical_completion_count")
    http = counter("http_attempt_count")
    retries = counter("retry_count")
    if http != logical + retries:
        raise ProductionWorkflowError(
            "provider telemetry violates HTTP = logical + retry"
        )
    if retries > logical * max_retries:
        raise ProductionWorkflowError(
            "provider retry telemetry exceeds the configured bound"
        )


def _provider_capability_snapshot(judge: Any) -> dict[str, Any] | None:
    snapshotter = getattr(judge, "capability_snapshot", None)
    if not callable(snapshotter):
        return None
    snapshot = snapshotter()
    if not isinstance(snapshot, Mapping):
        raise ProductionWorkflowError(
            "provider capability snapshot must be an object"
        )
    value = dict(snapshot)
    _assert_unscored_gold_free(
        value,
        location="provider capability snapshot",
    )
    return value


def predict_manifest_cases(
    *,
    manifest_path: str | Path,
    judge: Any,
    config: BenchmarkRunConfig,
    cache_dir: str | Path,
    unscored_output_path: str | Path,
    predict_run_metadata_path: str | Path,
    retry_failures: bool = False,
    max_logical_completions: int | None = None,
    on_result: Callable[[Mapping[str, Any]], None] | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Run the provider using only a prepared, gold-free manifest."""

    manifest, cases = load_prediction_manifest(manifest_path)
    manifest_sha256 = manifest["prediction_manifest_sha256"]
    if config.cohort_sha256 != manifest["cohort_sha256"]:
        raise ProductionWorkflowError(
            "provider config cohort does not match prepared manifest"
        )
    if not config.api_key_env:
        raise ProductionWorkflowError(
            "provider config must bind the API-key environment variable name"
        )
    output_path = Path(unscored_output_path).expanduser().resolve()
    metadata_path = Path(
        predict_run_metadata_path
    ).expanduser().resolve()
    budget = _LogicalCompletionBudget(max_logical_completions)
    results: list[dict[str, Any]] = []
    for case in cases:
        prediction = predict_two_stage_case(
            case,
            judge=judge,
            config=config,
            cache_root=cache_dir,
            retry_failures=retry_failures,
            completion_guard=budget.before_complete,
        )
        _initialize_repair_envelope(prediction)
        _maybe_repair_prediction(
            case=case,
            prediction=prediction,
            judge=judge,
            config=config,
            cache_dir=cache_dir,
            completion_guard=budget.before_complete,
        )
        _recompute_prediction_telemetry(prediction)
        _evidence_audit(case, prediction, config=config)
        wrapped = _wrap_prediction(
            prediction=prediction,
            case=case,
            manifest_sha256=manifest_sha256,
            config=config,
        )
        results.append(wrapped)
        # Stage raw is already durable.  This second atomic checkpoint makes
        # every completed trajectory visible before the next paid call.
        _atomic_jsonl(output_path, results)
        if on_result is not None:
            on_result(wrapped)

    (
        telemetry,
        telemetry_known_subtotal,
        telemetry_coverage,
    ) = _aggregate_run_telemetry(results)
    if telemetry_coverage["complete"]:
        _validate_telemetry(
            telemetry,
            max_retries=config.max_retries,
        )
    metadata: dict[str, Any] = {
        "schema_version": PREDICT_RUN_SCHEMA_VERSION,
        "prediction_manifest_path": str(
            Path(manifest_path).expanduser().resolve()
        ),
        "prediction_manifest_sha256": manifest_sha256,
        "unscored_predictions_path": str(output_path),
        "unscored_predictions_sha256": _file_sha256(output_path),
        "prediction_count": len(results),
        "production_pipeline_version": (
            PRODUCTION_TWO_STAGE_PIPELINE_VERSION
        ),
        "two_stage_pipeline_version": TWO_STAGE_PIPELINE_VERSION,
        "two_stage_prompt_version": TWO_STAGE_PROMPT_VERSION,
        "evidence_repair_pipeline_version": (
            EVIDENCE_REPAIR_PIPELINE_VERSION
        ),
        "evidence_repair_prompt_protocol_version": (
            EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
        ),
        "evidence_repair_max_attempts": EVIDENCE_REPAIR_MAX_ATTEMPTS,
        "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
        "provider_config": config.public_dict(),
        "provider_telemetry": telemetry,
        "provider_telemetry_known_subtotal": telemetry_known_subtotal,
        "provider_telemetry_coverage": telemetry_coverage,
        "provider_capabilities": _provider_capability_snapshot(judge),
        "repair_eligible_count": sum(
            bool(row["evidence_repair"]["eligible"])
            for row in results
        ),
        "repair_attempt_count": sum(
            bool(row["evidence_repair"]["attempted"])
            for row in results
        ),
        "repair_applied_count": sum(
            bool(row["evidence_repair"]["applied"])
            for row in results
        ),
        "max_logical_completions": max_logical_completions,
        "logical_completion_budget_used": budget.issued,
        "retry_failures": bool(retry_failures),
    }
    _assert_unscored_gold_free(metadata, location="predict run metadata")
    metadata["predict_run_sha256"] = stable_sha256(metadata)
    _atomic_json(metadata_path, metadata)
    return results, metadata


def _validate_unscored_prediction(
    row: Mapping[str, Any],
    *,
    case: PredictionCase,
    manifest_sha256: str,
    config: BenchmarkRunConfig,
) -> dict[str, Any]:
    value = dict(row)
    claimed_hash = value.pop("unscored_prediction_sha256", None)
    if claimed_hash != stable_sha256(value):
        raise ProductionWorkflowError(
            "unscored prediction content hash is invalid"
        )
    value["unscored_prediction_sha256"] = claimed_hash
    if (
        value.get("schema_version")
        != UNSCORED_PREDICTION_SCHEMA_VERSION
        or value.get("prediction_manifest_sha256") != manifest_sha256
        or value.get("production_pipeline_version")
        != PRODUCTION_TWO_STAGE_PIPELINE_VERSION
        or value.get("two_stage_pipeline_version")
        != TWO_STAGE_PIPELINE_VERSION
        or value.get("two_stage_prompt_version")
        != TWO_STAGE_PROMPT_VERSION
        or value.get("evidence_repair_pipeline_version")
        != EVIDENCE_REPAIR_PIPELINE_VERSION
        or value.get("evidence_repair_prompt_protocol_version")
        != EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
        or value.get("evidence_repair_max_attempts")
        != EVIDENCE_REPAIR_MAX_ATTEMPTS
        or value.get("evidence_validation_version")
        != EVIDENCE_VALIDATION_VERSION
        or value.get("provider_config") != config.public_dict()
        or value.get("trajectory_id") != case.trajectory_id
        or value.get("trajectory_sha256") != case.trajectory_sha256
        or value.get("case_input_sha256") != case.case_input_sha256
        or value.get("method") != "two_stage"
    ):
        raise ProductionWorkflowError(
            "unscored prediction identity is invalid"
        )
    _assert_unscored_gold_free(value, location="unscored prediction")
    _validate_stage_identities(value, case=case, config=config)
    rebuilt = {
        key: item
        for key, item in value.items()
        if key
        not in {
            "schema_version",
            "prediction_manifest_sha256",
            "two_stage_pipeline_version",
            "two_stage_prompt_version",
            "evidence_repair_pipeline_version",
            "evidence_repair_prompt_protocol_version",
            "evidence_repair_max_attempts",
            "evidence_validation_version",
            "provider_config",
            "unscored_prediction_sha256",
            "candidate_evidence_validation_issues",
            "selector_evidence_validation_issues",
            "evidence_validation_issues",
        }
    }
    _evidence_audit(case, rebuilt, config=config)
    for field in (
        "candidate_evidence_validation_issues",
        "selector_evidence_validation_issues",
        "evidence_validation_issues",
        "status",
        "failure_stage",
        "failure_code",
        "failure_message",
        "root_cause_judgment",
        "predicted_step",
        "predicted_event_id",
        "predicted_module",
        "predicted_error_type",
    ):
        expected = (
            rebuilt.get(field)
            if field in rebuilt
            else value.get(field)
        )
        if value.get(field) != expected:
            raise ProductionWorkflowError(
                f"unscored prediction {field} diverges from raw"
            )
    return value


def _validate_stage_identities(
    value: Mapping[str, Any],
    *,
    case: PredictionCase,
    config: BenchmarkRunConfig,
) -> None:
    attempted = value.get("stage_attempted")
    identities = value.get("stage_identities")
    raw_outputs = value.get("raw_judge_outputs")
    cache_hits = value.get("stage_cache_hits")
    stage_telemetry = value.get("stage_provider_telemetry")
    expected_stages = set(_ALL_STAGES)
    if any(
        not isinstance(item, Mapping) or set(item) != expected_stages
        for item in (
            attempted,
            identities,
            cache_hits,
            stage_telemetry,
        )
    ) or not isinstance(raw_outputs, Mapping):
        raise ProductionWorkflowError(
            "unscored stage envelopes are invalid"
        )
    if any(
        not isinstance(attempted[stage], bool)
        or not isinstance(cache_hits[stage], bool)
        for stage in expected_stages
    ):
        raise ProductionWorkflowError(
            "unscored stage attempted/cache fields must be boolean"
        )
    if not attempted["handoff_ledger"]:
        raise ProductionWorkflowError(
            "production prediction did not attempt the ledger stage"
        )
    expected_raw_stages = {
        stage for stage in _ALL_STAGES if attempted[stage]
    }
    if set(raw_outputs) != expected_raw_stages:
        raise ProductionWorkflowError(
            "unscored raw outputs do not match attempted stages"
        )
    telemetry_probe = {
        "stage_attempted": dict(attempted),
        "stage_provider_telemetry": dict(stage_telemetry),
    }
    _recompute_prediction_telemetry(telemetry_probe)
    for field in (
        "provider_telemetry",
        "provider_telemetry_known_subtotal",
        "provider_telemetry_coverage",
    ):
        if value.get(field) != telemetry_probe[field]:
            raise ProductionWorkflowError(
                f"unscored {field} diverges from persisted stages"
            )
    shared_identity = _two_stage_identity(case, config=config)
    ledger_messages = handoff_ledger_messages(case.judge_view)
    ledger_request = build_stage_request(
        stage="handoff_ledger",
        messages=ledger_messages,
        identity=shared_identity,
    )

    def validate_one(stage: str, request: Any) -> None:
        identity = identities[stage]
        if not isinstance(identity, Mapping) or set(identity) != {
            "request_sha256",
            "prompt_sha256",
            "raw_response_sha256",
            "dependency_sha256",
        }:
            raise ProductionWorkflowError(
                f"unscored {stage} identity is invalid"
            )
        if stage not in raw_outputs:
            raise ProductionWorkflowError(
                f"unscored {stage} raw output is missing"
            )
        expected = {
            "request_sha256": request.request_sha256,
            "prompt_sha256": request.prompt_sha256,
            "raw_response_sha256": stage_stable_sha256(
                raw_outputs[stage]
            ),
            "dependency_sha256": request.identity[
                "dependency_sha256"
            ],
        }
        if dict(identity) != expected:
            raise ProductionWorkflowError(
                f"unscored {stage} identity diverges from raw request"
            )

    def validate_unattempted(stage: str) -> None:
        if (
            identities[stage] is not None
            or stage in raw_outputs
            or cache_hits[stage]
            or stage_telemetry[stage] is not None
        ):
            raise ProductionWorkflowError(
                f"unattempted {stage} stage contains persisted state"
            )

    validate_one("handoff_ledger", ledger_request)
    if not attempted["handoff_selector"]:
        validate_unattempted("handoff_selector")
        validate_unattempted("evidence_repair")
        if value.get("evidence_repair") != _empty_repair_state():
            raise ProductionWorkflowError(
                "repair state exists after an unattempted selector"
            )
        return
    try:
        ledger = parse_handoff_ledger(
            raw_outputs["handoff_ledger"],
            trace=case.judge_view,
        )
    except JudgeOutputError as error:
        raise ProductionWorkflowError(
            "selector was attempted after an invalid ledger"
        ) from error
    ledger_data = ledger.to_dict()
    selector_messages = handoff_selector_messages(
        case.judge_view,
        ledger,
    )
    selector_request = build_stage_request(
        stage="handoff_selector",
        messages=selector_messages,
        identity=shared_identity,
        dependency_sha256=stage_stable_sha256(
            {
                "raw_response_sha256": identities["handoff_ledger"][
                    "raw_response_sha256"
                ],
                "normalized_ledger": ledger_data,
            }
        ),
    )
    validate_one("handoff_selector", selector_request)
    if not attempted["evidence_repair"]:
        validate_unattempted("evidence_repair")
        return
    try:
        selector_root = parse_handoff_selector(
            raw_outputs["handoff_selector"],
            trace=case.judge_view,
        )
    except JudgeOutputError as error:
        raise ProductionWorkflowError(
            "repair was attempted after an invalid selector"
        ) from error
    (
        repair_request,
        _,
        _,
        _,
    ) = _repair_stage_request(
        case=case,
        config=config,
        selector_root=selector_root,
        selector_raw_sha256=str(
            identities["handoff_selector"]["raw_response_sha256"]
        ),
    )
    validate_one("evidence_repair", repair_request)


def _load_predict_metadata(
    path: str | Path,
    *,
    unscored_path: Path,
    manifest_sha256: str,
    prediction_count: int,
    config: BenchmarkRunConfig,
    rows: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    metadata_path = Path(path).expanduser().resolve()
    try:
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise ProductionWorkflowError(
            "predict run metadata is missing or invalid"
        ) from error
    if not isinstance(metadata, dict):
        raise ProductionWorkflowError(
            "predict run metadata must be an object"
        )
    claimed_hash = metadata.get("predict_run_sha256")
    body = dict(metadata)
    body.pop("predict_run_sha256", None)
    if claimed_hash != stable_sha256(body):
        raise ProductionWorkflowError(
            "predict run metadata content hash is invalid"
        )
    if (
        metadata.get("schema_version") != PREDICT_RUN_SCHEMA_VERSION
        or metadata.get("prediction_manifest_sha256") != manifest_sha256
        or metadata.get("production_pipeline_version")
        != PRODUCTION_TWO_STAGE_PIPELINE_VERSION
        or metadata.get("two_stage_pipeline_version")
        != TWO_STAGE_PIPELINE_VERSION
        or metadata.get("two_stage_prompt_version")
        != TWO_STAGE_PROMPT_VERSION
        or metadata.get("evidence_repair_pipeline_version")
        != EVIDENCE_REPAIR_PIPELINE_VERSION
        or metadata.get("evidence_repair_prompt_protocol_version")
        != EVIDENCE_REPAIR_PROMPT_PROTOCOL_VERSION
        or metadata.get("evidence_repair_max_attempts")
        != EVIDENCE_REPAIR_MAX_ATTEMPTS
        or sum(
            isinstance(row.get("evidence_repair"), Mapping)
            for row in rows
        )
        != len(rows)
        or metadata.get("unscored_predictions_sha256")
        != _file_sha256(unscored_path)
        or metadata.get("prediction_count") != prediction_count
        or metadata.get("evidence_validation_version")
        != EVIDENCE_VALIDATION_VERSION
        or metadata.get("provider_config") != config.public_dict()
        or metadata.get("repair_eligible_count")
        != sum(
            bool(row.get("evidence_repair", {}).get("eligible"))
            for row in rows
            if isinstance(row.get("evidence_repair"), Mapping)
        )
        or metadata.get("repair_attempt_count")
        != sum(
            bool(row.get("evidence_repair", {}).get("attempted"))
            for row in rows
            if isinstance(row.get("evidence_repair"), Mapping)
        )
        or metadata.get("repair_applied_count")
        != sum(
            bool(row.get("evidence_repair", {}).get("applied"))
            for row in rows
            if isinstance(row.get("evidence_repair"), Mapping)
        )
        or (
            metadata.get("provider_capabilities") is not None
            and not isinstance(
                metadata.get("provider_capabilities"),
                Mapping,
            )
        )
    ):
        raise ProductionWorkflowError(
            "predict run metadata identity is invalid"
        )
    (
        expected_telemetry,
        expected_known_subtotal,
        expected_coverage,
    ) = _aggregate_run_telemetry(rows)
    if (
        metadata.get("provider_telemetry") != expected_telemetry
        or metadata.get("provider_telemetry_known_subtotal")
        != expected_known_subtotal
        or metadata.get("provider_telemetry_coverage")
        != expected_coverage
    ):
        raise ProductionWorkflowError(
            "predict run telemetry coverage diverges from stage artifacts"
        )
    maximum = metadata.get("max_logical_completions")
    used = metadata.get("logical_completion_budget_used")
    if (
        (
            maximum is not None
            and (
                isinstance(maximum, bool)
                or not isinstance(maximum, int)
                or maximum < 1
            )
        )
        or isinstance(used, bool)
        or not isinstance(used, int)
        or used < 0
        or (maximum is not None and used > maximum)
    ):
        raise ProductionWorkflowError(
            "predict run logical-completion budget is invalid"
        )
    _assert_unscored_gold_free(metadata, location="predict run metadata")
    if expected_coverage["complete"]:
        _validate_telemetry(
            metadata.get("provider_telemetry"),
            max_retries=config.max_retries,
        )
    return metadata


def score_persisted_predictions(
    *,
    dataset: BenchmarkDataset,
    cohort: CohortManifest,
    manifest_path: str | Path,
    unscored_predictions_path: str | Path,
    predict_run_metadata_path: str | Path,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Load gold only here, after immutable unscored predictions exist."""

    manifest, cases = load_prediction_manifest(manifest_path)
    if (
        dataset.dataset_sha256 != manifest["dataset_manifest_sha256"]
        or cohort.dataset_manifest_sha256
        != manifest["dataset_manifest_sha256"]
        or cohort.cohort_name != manifest["cohort_name"]
        or cohort.cohort_sha256 != manifest["cohort_sha256"]
    ):
        raise ProductionWorkflowError(
            "scoring dataset/cohort does not match prediction manifest"
        )
    unscored_path = Path(
        unscored_predictions_path
    ).expanduser().resolve()
    rows = _read_jsonl(unscored_path)
    if len(rows) != len(cases):
        raise ProductionWorkflowError(
            "unscored prediction count does not match manifest"
        )
    by_case = {case.trajectory_id: case for case in cases}
    row_ids = [row.get("trajectory_id") for row in rows]
    if (
        len(set(row_ids)) != len(row_ids)
        or set(row_ids) != set(by_case)
    ):
        raise ProductionWorkflowError(
            "unscored prediction IDs do not exactly match manifest"
        )
    first_config = rows[0].get("provider_config")
    if not isinstance(first_config, Mapping):
        raise ProductionWorkflowError(
            "unscored provider config is missing"
        )
    try:
        config = BenchmarkRunConfig(**dict(first_config))
    except TypeError as error:
        raise ProductionWorkflowError(
            "unscored provider config is invalid"
        ) from error
    if config.cohort_sha256 != cohort.cohort_sha256:
        raise ProductionWorkflowError(
            "unscored provider config uses the wrong cohort"
        )
    metadata = _load_predict_metadata(
        predict_run_metadata_path,
        unscored_path=unscored_path,
        manifest_sha256=manifest["prediction_manifest_sha256"],
        prediction_count=len(rows),
        config=config,
        rows=rows,
    )
    validated = [
        _validate_unscored_prediction(
            row,
            case=by_case[str(row["trajectory_id"])],
            manifest_sha256=manifest["prediction_manifest_sha256"],
            config=config,
        )
        for row in rows
    ]
    example_by_id = {
        example.label.trajectory_id: example
        for example in dataset.examples
    }
    scored: list[dict[str, Any]] = []
    envelope_fields = {
        "schema_version",
        "prediction_manifest_sha256",
        "two_stage_pipeline_version",
        "two_stage_prompt_version",
        "evidence_repair_pipeline_version",
        "evidence_repair_prompt_protocol_version",
        "evidence_repair_max_attempts",
        "evidence_validation_version",
        "provider_config",
        "unscored_prediction_sha256",
        "case_input_sha256",
    }
    for row in validated:
        trajectory_id = str(row["trajectory_id"])
        example = example_by_id.get(trajectory_id)
        if example is None:
            raise ProductionWorkflowError(
                "unscored trajectory has no scoring example"
            )
        case = by_case[trajectory_id]
        if (
            example.mapping.trajectory_sha256 != case.trajectory_sha256
            or tuple(
                (step.original_step, step.critical_event_id)
                for step in example.mapping.steps
            )
            != case.step_event_mapping
        ):
            raise ProductionWorkflowError(
                "scoring adaptation diverges from prepared prediction case"
            )
        record = _base_record(
            example,
            method="two_stage",
            config=config,
        )
        record.update(
            {
                key: item
                for key, item in row.items()
                if key not in envelope_fields
                and key
                not in {
                    "trajectory_id",
                    "trajectory_sha256",
                    "method",
                }
            }
        )
        audit_body = {
            key: item
            for key, item in row.items()
            if key not in envelope_fields
        }
        root = _evidence_audit(
            case,
            audit_body,
            config=config,
        )
        if root is not None:
            _apply_root(record, example=example, root=root)
        scored.append(record)
    return scored, metadata


__all__ = [
    "PREDICT_RUN_SCHEMA_VERSION",
    "PRODUCTION_TWO_STAGE_PIPELINE_VERSION",
    "UNSCORED_PREDICTION_SCHEMA_VERSION",
    "ProductionWorkflowError",
    "predict_manifest_cases",
    "score_persisted_predictions",
]

"""Fail-closed evaluation gates for the 3x3 Agent Judge tuning slice.

The gate has two deliberately separate stages.  The preflight stage invokes
the selected Agent Judge protocol's existing gold-free validator and then
performs only a prediction census.  Scored rows are accepted by the second
stage only after preflight succeeds; :func:`run_agent_judge_gate` enforces that
ordering for callers that want one orchestration helper.

No dataset, benchmark label, historical metric, or ``all_correct`` value is
loaded or consulted here.
"""

from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from .agent_judge_workflow import validate_agent_judge_run


AGENT_JUDGE_GATE_SCHEMA_VERSION = "agentdebug.agent-judge-gate-eval.v1"

GATE_EXPECTED_COUNT = 9
GATE_MIN_DISTINCT_PREDICTED_MODULES = 3
GATE_MAX_PREDICTIONS_PER_MODULE = 6

GATE_MIN_STEP_EXACT_CORRECT = 3
GATE_MIN_STEP_MODULE_EXACT_CORRECT = 2
GATE_MIN_STEP_MODULE_ENVIRONMENTS = 2
GATE_MAX_INVALID_PREDICTIONS = 0

_VALID_MODULES = frozenset(
    {"memory", "reflection", "planning", "action", "system"}
)


def _reason(code: str, message: str, **details: Any) -> dict[str, Any]:
    return {"code": code, "message": message, **details}


def _empty_census() -> dict[str, Any]:
    return {
        "prediction_count": None,
        "valid_prediction_count": 0,
        "invalid_prediction_count": None,
        "module_counts": {},
        "distinct_module_count": 0,
        "maximum_single_module_count": 0,
    }


def _preflight_result(
    *,
    passed: bool,
    protocol: str,
    census: Mapping[str, Any],
    reasons: Sequence[Mapping[str, Any]],
    validation_audit: Mapping[str, Any] | None,
) -> dict[str, Any]:
    return {
        "schema_version": AGENT_JUDGE_GATE_SCHEMA_VERSION,
        "stage": "gold_free_preflight",
        "gold_free": True,
        "protocol": protocol,
        "passed": passed,
        "thresholds": {
            "expected_prediction_count": GATE_EXPECTED_COUNT,
            "minimum_distinct_predicted_modules": (
                GATE_MIN_DISTINCT_PREDICTED_MODULES
            ),
            "maximum_predictions_per_module": (
                GATE_MAX_PREDICTIONS_PER_MODULE
            ),
            "maximum_invalid_predictions": GATE_MAX_INVALID_PREDICTIONS,
        },
        "census": dict(census),
        "failure_reasons": [dict(item) for item in reasons],
        "validation_audit": (
            dict(validation_audit) if validation_audit is not None else None
        ),
    }


def _file_bytes_and_sha256(path: Path) -> tuple[bytes, str]:
    value = path.read_bytes()
    return value, hashlib.sha256(value).hexdigest()


def evaluate_agent_judge_gate_preflight(
    *,
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    protocol: str = "v1",
) -> dict[str, Any]:
    """Validate and census one nine-case prediction file without loading gold.

    Any validator, audit, file, JSON, count, validity, diversity, or
    concentration problem returns ``passed=False``.  Prediction identity,
    order, trajectory hashes, taxonomy, and evidence ownership remain the
    responsibility of ``validate_agent_judge_run``.
    """

    try:
        audit = validate_agent_judge_run(
            prediction_manifest_path=prediction_manifest_path,
            cohort_manifest_path=cohort_manifest_path,
            predictions_path=predictions_path,
            protocol=protocol,
        )
    except Exception as error:  # The public gate reports instead of repairing.
        return _preflight_result(
            passed=False,
            protocol=protocol,
            census=_empty_census(),
            reasons=[
                _reason(
                    "strict_validation_failed",
                    "The protocol's gold-free validator rejected the run.",
                    error_type=type(error).__name__,
                    error_message=str(error),
                )
            ],
            validation_audit=None,
        )

    if not isinstance(audit, Mapping) or audit.get("gold_free_validation") is not True:
        return _preflight_result(
            passed=False,
            protocol=protocol,
            census=_empty_census(),
            reasons=[
                _reason(
                    "invalid_validation_audit",
                    "Strict validation did not return a positive gold-free audit.",
                )
            ],
            validation_audit=audit if isinstance(audit, Mapping) else None,
        )

    output_hashes = audit.get("output_sha256")
    validated_sha256 = (
        output_hashes.get("predictions.json")
        if isinstance(output_hashes, Mapping)
        else None
    )
    if not isinstance(validated_sha256, str) or len(validated_sha256) != 64:
        return _preflight_result(
            passed=False,
            protocol=protocol,
            census=_empty_census(),
            reasons=[
                _reason(
                    "missing_validated_prediction_hash",
                    "Strict validation did not bind the prediction bytes.",
                )
            ],
            validation_audit=audit,
        )

    prediction_path = Path(predictions_path).expanduser().resolve()
    try:
        raw_bytes, observed_sha256 = _file_bytes_and_sha256(prediction_path)
    except OSError as error:
        return _preflight_result(
            passed=False,
            protocol=protocol,
            census=_empty_census(),
            reasons=[
                _reason(
                    "prediction_read_failed",
                    "Validated predictions could not be read for the census.",
                    error_type=type(error).__name__,
                    error_message=str(error),
                )
            ],
            validation_audit=audit,
        )
    if observed_sha256 != validated_sha256:
        return _preflight_result(
            passed=False,
            protocol=protocol,
            census=_empty_census(),
            reasons=[
                _reason(
                    "prediction_changed_after_validation",
                    "Prediction bytes changed after strict validation.",
                    validated_sha256=validated_sha256,
                    observed_sha256=observed_sha256,
                )
            ],
            validation_audit=audit,
        )

    try:
        predictions = json.loads(raw_bytes)
    except (UnicodeError, json.JSONDecodeError) as error:
        return _preflight_result(
            passed=False,
            protocol=protocol,
            census=_empty_census(),
            reasons=[
                _reason(
                    "prediction_census_json_invalid",
                    "Validated prediction bytes are no longer valid JSON.",
                    error_type=type(error).__name__,
                    error_message=str(error),
                )
            ],
            validation_audit=audit,
        )

    if not isinstance(predictions, list):
        predictions = []
        envelope_invalid = True
    else:
        envelope_invalid = False

    module_counts: Counter[str] = Counter()
    invalid_prediction_count = 0
    for prediction in predictions:
        if not isinstance(prediction, Mapping):
            invalid_prediction_count += 1
            continue
        module = prediction.get("predicted_module")
        if prediction.get("status") != "success" or module not in _VALID_MODULES:
            invalid_prediction_count += 1
            continue
        module_counts[str(module)] += 1

    prediction_count = len(predictions)
    valid_prediction_count = prediction_count - invalid_prediction_count
    maximum_single_module_count = max(module_counts.values(), default=0)
    census = {
        "prediction_count": prediction_count,
        "valid_prediction_count": valid_prediction_count,
        "invalid_prediction_count": invalid_prediction_count,
        "module_counts": dict(sorted(module_counts.items())),
        "distinct_module_count": len(module_counts),
        "maximum_single_module_count": maximum_single_module_count,
    }
    reasons: list[dict[str, Any]] = []
    if envelope_invalid:
        reasons.append(
            _reason(
                "invalid_prediction_envelope",
                "Predictions must be one JSON array.",
            )
        )
    if audit.get("case_count") != GATE_EXPECTED_COUNT:
        reasons.append(
            _reason(
                "validated_case_count_mismatch",
                "The strict audit does not describe the fixed nine-case gate.",
                required=GATE_EXPECTED_COUNT,
                observed=audit.get("case_count"),
            )
        )
    if prediction_count != GATE_EXPECTED_COUNT:
        reasons.append(
            _reason(
                "prediction_count_mismatch",
                "The prediction census must contain exactly nine records.",
                required=GATE_EXPECTED_COUNT,
                observed=prediction_count,
            )
        )
    if invalid_prediction_count > GATE_MAX_INVALID_PREDICTIONS:
        reasons.append(
            _reason(
                "invalid_predictions_present",
                "Every gate prediction must be valid and successful.",
                maximum=GATE_MAX_INVALID_PREDICTIONS,
                observed=invalid_prediction_count,
            )
        )
    if len(module_counts) < GATE_MIN_DISTINCT_PREDICTED_MODULES:
        reasons.append(
            _reason(
                "predicted_module_diversity_below_minimum",
                "The gate must predict at least three distinct modules.",
                minimum=GATE_MIN_DISTINCT_PREDICTED_MODULES,
                observed=len(module_counts),
            )
        )
    if maximum_single_module_count > GATE_MAX_PREDICTIONS_PER_MODULE:
        reasons.append(
            _reason(
                "predicted_module_concentration_above_maximum",
                "No module may own more than six gate predictions.",
                maximum=GATE_MAX_PREDICTIONS_PER_MODULE,
                observed=maximum_single_module_count,
            )
        )
    return _preflight_result(
        passed=not reasons,
        protocol=protocol,
        census=census,
        reasons=reasons,
        validation_audit=audit,
    )


def evaluate_agent_judge_post_score_gate(
    scored_rows: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Apply the fixed semantic gate after a successful gold-free preflight."""

    try:
        rows = list(scored_rows)
    except Exception as error:
        return {
            "schema_version": AGENT_JUDGE_GATE_SCHEMA_VERSION,
            "stage": "post_score_gate",
            "passed": False,
            "thresholds": _post_score_thresholds(),
            "observed": _empty_post_score_observed(),
            "failure_reasons": [
                _reason(
                    "scored_rows_unreadable",
                    "Scored rows could not be enumerated.",
                    error_type=type(error).__name__,
                    error_message=str(error),
                )
            ],
        }

    step_exact_correct = 0
    step_module_exact_correct = 0
    step_module_environments: set[str] = set()
    invalid_prediction_count = 0
    for row in rows:
        if not isinstance(row, Mapping):
            invalid_prediction_count += 1
            continue
        step_exact = row.get("step_exact")
        step_module_exact = row.get("step_module_exact")
        environment = row.get("environment")
        valid = (
            row.get("status") == "success"
            and isinstance(step_exact, bool)
            and isinstance(step_module_exact, bool)
            and isinstance(environment, str)
            and bool(environment)
            and not (step_module_exact and not step_exact)
        )
        if not valid:
            invalid_prediction_count += 1
            continue
        if step_exact:
            step_exact_correct += 1
        if step_module_exact:
            step_module_exact_correct += 1
            step_module_environments.add(environment)

    observed = {
        "scored_row_count": len(rows),
        "step_exact_correct": step_exact_correct,
        "step_module_exact_correct": step_module_exact_correct,
        "step_module_exact_environments": sorted(step_module_environments),
        "step_module_exact_environment_count": len(step_module_environments),
        "invalid_prediction_count": invalid_prediction_count,
    }
    reasons: list[dict[str, Any]] = []
    if len(rows) != GATE_EXPECTED_COUNT:
        reasons.append(
            _reason(
                "scored_row_count_mismatch",
                "The semantic gate must score exactly nine rows.",
                required=GATE_EXPECTED_COUNT,
                observed=len(rows),
            )
        )
    if invalid_prediction_count > GATE_MAX_INVALID_PREDICTIONS:
        reasons.append(
            _reason(
                "invalid_scored_predictions_present",
                "The semantic gate permits no invalid scored prediction.",
                maximum=GATE_MAX_INVALID_PREDICTIONS,
                observed=invalid_prediction_count,
            )
        )
    if step_exact_correct < GATE_MIN_STEP_EXACT_CORRECT:
        reasons.append(
            _reason(
                "step_exact_below_minimum",
                "At least three of nine steps must be exact.",
                minimum=GATE_MIN_STEP_EXACT_CORRECT,
                observed=step_exact_correct,
            )
        )
    if step_module_exact_correct < GATE_MIN_STEP_MODULE_EXACT_CORRECT:
        reasons.append(
            _reason(
                "step_module_exact_below_minimum",
                "At least two of nine step/module pairs must be exact.",
                minimum=GATE_MIN_STEP_MODULE_EXACT_CORRECT,
                observed=step_module_exact_correct,
            )
        )
    if len(step_module_environments) < GATE_MIN_STEP_MODULE_ENVIRONMENTS:
        reasons.append(
            _reason(
                "step_module_environment_coverage_below_minimum",
                "Step/module hits must cover at least two environments.",
                minimum=GATE_MIN_STEP_MODULE_ENVIRONMENTS,
                observed=len(step_module_environments),
            )
        )
    return {
        "schema_version": AGENT_JUDGE_GATE_SCHEMA_VERSION,
        "stage": "post_score_gate",
        "passed": not reasons,
        "thresholds": _post_score_thresholds(),
        "observed": observed,
        "failure_reasons": reasons,
    }


def _post_score_thresholds() -> dict[str, int]:
    return {
        "expected_scored_row_count": GATE_EXPECTED_COUNT,
        "minimum_step_exact_correct": GATE_MIN_STEP_EXACT_CORRECT,
        "minimum_step_module_exact_correct": (
            GATE_MIN_STEP_MODULE_EXACT_CORRECT
        ),
        "minimum_step_module_exact_environments": (
            GATE_MIN_STEP_MODULE_ENVIRONMENTS
        ),
        "maximum_invalid_predictions": GATE_MAX_INVALID_PREDICTIONS,
    }


def _empty_post_score_observed() -> dict[str, Any]:
    return {
        "scored_row_count": None,
        "step_exact_correct": 0,
        "step_module_exact_correct": 0,
        "step_module_exact_environments": [],
        "step_module_exact_environment_count": 0,
        "invalid_prediction_count": None,
    }


def run_agent_judge_gate(
    *,
    prediction_manifest_path: str | Path,
    cohort_manifest_path: str | Path,
    predictions_path: str | Path,
    score_loader: Callable[[], Sequence[Mapping[str, Any]]],
    protocol: str = "v1",
) -> dict[str, Any]:
    """Run preflight first and invoke ``score_loader`` only when it passes."""

    preflight = evaluate_agent_judge_gate_preflight(
        prediction_manifest_path=prediction_manifest_path,
        cohort_manifest_path=cohort_manifest_path,
        predictions_path=predictions_path,
        protocol=protocol,
    )
    if preflight["passed"] is not True:
        return {
            "schema_version": AGENT_JUDGE_GATE_SCHEMA_VERSION,
            "passed": False,
            "preflight": preflight,
            "scoring_attempted": False,
            "post_score": None,
        }

    try:
        scored_rows = score_loader()
    except Exception as error:
        return {
            "schema_version": AGENT_JUDGE_GATE_SCHEMA_VERSION,
            "passed": False,
            "preflight": preflight,
            "scoring_attempted": True,
            "post_score": {
                "schema_version": AGENT_JUDGE_GATE_SCHEMA_VERSION,
                "stage": "post_score_gate",
                "passed": False,
                "thresholds": _post_score_thresholds(),
                "observed": _empty_post_score_observed(),
                "failure_reasons": [
                    _reason(
                        "score_loader_failed",
                        "The post-preflight score loader failed.",
                        error_type=type(error).__name__,
                        error_message=str(error),
                    )
                ],
            },
        }

    post_score = evaluate_agent_judge_post_score_gate(scored_rows)
    return {
        "schema_version": AGENT_JUDGE_GATE_SCHEMA_VERSION,
        "passed": post_score["passed"] is True,
        "preflight": preflight,
        "scoring_attempted": True,
        "post_score": post_score,
    }


__all__ = [
    "AGENT_JUDGE_GATE_SCHEMA_VERSION",
    "GATE_EXPECTED_COUNT",
    "GATE_MAX_INVALID_PREDICTIONS",
    "GATE_MAX_PREDICTIONS_PER_MODULE",
    "GATE_MIN_DISTINCT_PREDICTED_MODULES",
    "GATE_MIN_STEP_EXACT_CORRECT",
    "GATE_MIN_STEP_MODULE_ENVIRONMENTS",
    "GATE_MIN_STEP_MODULE_EXACT_CORRECT",
    "evaluate_agent_judge_gate_preflight",
    "evaluate_agent_judge_post_score_gate",
    "run_agent_judge_gate",
]

"""Gold-isolated prepare, semantic replay, and scoring experiment CLI."""

from __future__ import annotations

import argparse
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from agentdebug.diagnostics import (
    EVIDENCE_VALIDATION_VERSION,
    GeminiGenerateContentJudge,
    OpenAICompatibleJudge,
)
from agentdebug.diagnostics.prompts import PROMPT_PROTOCOL_VERSION

from .replay_critic import (
    AUDIT_REPLAY_PREDICTION_SCHEMA_VERSION,
    AUDIT_REPLAY_RUN_SCHEMA_VERSION,
    REPLAY_METHOD,
    REPLAY_PIPELINE_VERSION,
    REPLAY_PREDICTION_SCHEMA_VERSION,
    REPLAY_RUN_SCHEMA_VERSION,
    load_replay_manifest,
    predict_replay,
    prepare_replay_inputs,
    replay_artifact_sha256,
    replay_method_contract,
    replay_provider_telemetry,
    score_replay,
)
from .replay_audit_critic import (
    AUDIT_PROMPT_PROTOCOL_VERSION,
    AUDIT_REPLAY_METHOD,
    AUDIT_REPLAY_PIPELINE_VERSION,
    predict_explicit_audit_replay,
)
from .replay_handoff import (
    HANDOFF_PROMPT_PROTOCOL_VERSION,
    HANDOFF_REPLAY_METHOD,
    HANDOFF_REPLAY_PIPELINE_VERSION,
    HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION,
    HANDOFF_REPLAY_RUN_SCHEMA_VERSION,
    predict_handoff_replay,
)
from .replay_evidence_repair import (
    E5D_METHOD,
    finalize_evidence_repair,
    load_evidence_repair_manifest,
    predict_evidence_repair,
    prepare_evidence_repair,
    score_evidence_repair,
)
from .reporting import write_outputs
from .runner import (
    BenchmarkRunConfig,
    TRANSPORT_POLICY_VERSION,
    provider_telemetry_snapshot,
)


def _atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m agentdebug.benchmark.replay_cli",
        description=(
            "Prepare, predict, and score gold-isolated semantic replays."
        ),
    )
    commands = parser.add_subparsers(dest="command", required=True)

    prepare = commands.add_parser(
        "prepare",
        help="Create a frozen gold-free replay manifest without networking.",
    )
    prepare.add_argument("--dataset", required=True)
    prepare.add_argument("--cohort-manifest", required=True)
    prepare.add_argument("--source-predictions", required=True)
    prepare.add_argument("--expected-source-sha256", required=True)
    prepare.add_argument("--expected-source-prompt-version", required=True)
    prepare.add_argument("--expected-count", type=int, default=3)
    prepare.add_argument("--output", required=True)

    predict = commands.add_parser(
        "predict",
        help=(
            "Read only a prepared manifest, call only the critic, and persist "
            "unscored outputs."
        ),
    )
    predict.add_argument("--manifest", required=True)
    predict.add_argument("--output", required=True)
    predict.add_argument("--cache-dir", required=True)
    predict.add_argument("--run-metadata", required=True)
    predict.add_argument(
        "--judge-provider",
        choices=("openai-compatible", "gemini-generate-content"),
        default="openai-compatible",
    )
    predict.add_argument("--judge-base-url", required=True)
    predict.add_argument("--judge-api-key-env", default="API_KEY")
    predict.add_argument("--judge-model", required=True)
    predict.add_argument("--judge-temperature", type=float, default=0)
    predict.add_argument("--judge-timeout", type=float, default=600)
    predict.add_argument("--judge-max-output-tokens", type=int, default=8192)
    predict.add_argument("--judge-max-retries", type=int, default=5)
    predict.add_argument("--judge-retry-backoff", type=float, default=2)
    predict.add_argument("--retry-failures", action="store_true")

    audit = commands.add_parser(
        "predict-audit",
        help=(
            "Run one explicit challenger/audit completion per prepared input "
            "and persist unscored outputs."
        ),
    )
    audit.add_argument("--manifest", required=True)
    audit.add_argument("--output", required=True)
    audit.add_argument("--cache-dir", required=True)
    audit.add_argument("--run-metadata", required=True)
    audit.add_argument(
        "--judge-provider",
        choices=("openai-compatible", "gemini-generate-content"),
        default="openai-compatible",
    )
    audit.add_argument("--judge-base-url", required=True)
    audit.add_argument("--judge-api-key-env", default="API_KEY")
    audit.add_argument("--judge-model", required=True)
    audit.add_argument("--judge-temperature", type=float, default=0)
    audit.add_argument("--judge-timeout", type=float, default=600)
    audit.add_argument("--judge-max-output-tokens", type=int, default=8192)
    audit.add_argument("--judge-max-retries", type=int, default=5)
    audit.add_argument("--judge-retry-backoff", type=float, default=2)
    audit.add_argument("--retry-failures", action="store_true")

    handoff = commands.add_parser(
        "predict-handoff",
        help=(
            "Run one unanchored handoff ledger and one independent selector "
            "completion per prepared input."
        ),
    )
    handoff.add_argument("--manifest", required=True)
    handoff.add_argument("--output", required=True)
    handoff.add_argument("--cache-dir", required=True)
    handoff.add_argument("--run-metadata", required=True)
    handoff.add_argument(
        "--judge-provider",
        choices=("openai-compatible", "gemini-generate-content"),
        default="openai-compatible",
    )
    handoff.add_argument("--judge-base-url", required=True)
    handoff.add_argument("--judge-api-key-env", default="API_KEY")
    handoff.add_argument("--judge-model", required=True)
    handoff.add_argument("--judge-temperature", type=float, default=0)
    handoff.add_argument("--judge-timeout", type=float, default=600)
    handoff.add_argument(
        "--judge-max-output-tokens",
        type=int,
        default=8192,
    )
    handoff.add_argument("--judge-max-retries", type=int, default=5)
    handoff.add_argument("--judge-retry-backoff", type=float, default=2)
    handoff.add_argument("--retry-failures", action="store_true")

    repair_prepare = commands.add_parser(
        "prepare-evidence-repair",
        help="Prepare the one-row gold-free E5d evidence repair manifest.",
    )
    repair_prepare.add_argument("--replay-manifest", required=True)
    repair_prepare.add_argument("--source-unscored", required=True)
    repair_prepare.add_argument("--source-predict-run", required=True)
    repair_prepare.add_argument(
        "--expected-replay-manifest-sha256",
        required=True,
    )
    repair_prepare.add_argument(
        "--expected-source-unscored-sha256",
        required=True,
    )
    repair_prepare.add_argument(
        "--expected-source-predict-run-sha256",
        required=True,
    )
    repair_prepare.add_argument(
        "--expected-eligible-count",
        type=int,
        default=1,
    )
    repair_prepare.add_argument("--output", required=True)

    repair_predict = commands.add_parser(
        "predict-evidence-repair",
        help="Run the sole E5d repair completion over a gold-free manifest.",
    )
    repair_predict.add_argument("--manifest", required=True)
    repair_predict.add_argument("--output", required=True)
    repair_predict.add_argument("--cache-dir", required=True)
    repair_predict.add_argument("--run-metadata", required=True)
    repair_predict.add_argument(
        "--judge-provider",
        choices=("openai-compatible", "gemini-generate-content"),
        default="openai-compatible",
    )
    repair_predict.add_argument("--judge-base-url", required=True)
    repair_predict.add_argument("--judge-api-key-env", default="API_KEY")
    repair_predict.add_argument("--judge-model", required=True)
    repair_predict.add_argument(
        "--judge-temperature",
        type=float,
        default=0,
    )
    repair_predict.add_argument(
        "--judge-timeout",
        type=float,
        default=600,
    )
    repair_predict.add_argument(
        "--judge-max-output-tokens",
        type=int,
        default=8192,
    )
    repair_predict.add_argument(
        "--judge-max-retries",
        type=int,
        default=5,
    )
    repair_predict.add_argument(
        "--judge-retry-backoff",
        type=float,
        default=2,
    )

    repair_finalize = commands.add_parser(
        "finalize-evidence-repair",
        help="Offline-materialize all three E5d gold-free predictions.",
    )
    repair_finalize.add_argument("--repair-manifest", required=True)
    repair_finalize.add_argument("--replay-manifest", required=True)
    repair_finalize.add_argument("--source-unscored", required=True)
    repair_finalize.add_argument("--source-predict-run", required=True)
    repair_finalize.add_argument("--attempts", required=True)
    repair_finalize.add_argument("--predict-run", required=True)
    repair_finalize.add_argument("--output", required=True)
    repair_finalize.add_argument("--run-metadata", required=True)

    repair_score = commands.add_parser(
        "score-evidence-repair",
        help="Load gold only here and score finalized E5d predictions.",
    )
    repair_score.add_argument("--dataset", required=True)
    repair_score.add_argument("--cohort-manifest", required=True)
    repair_score.add_argument("--replay-manifest", required=True)
    repair_score.add_argument("--unscored-predictions", required=True)
    repair_score.add_argument("--finalize-run", required=True)
    repair_score.add_argument("--output-dir", required=True)

    score = commands.add_parser(
        "score",
        help="Load gold only after predict and write standard dry-run reports.",
    )
    score.add_argument("--dataset", required=True)
    score.add_argument("--cohort-manifest", required=True)
    score.add_argument("--manifest", required=True)
    score.add_argument("--unscored-predictions", required=True)
    score.add_argument("--predict-run-metadata", required=True)
    score.add_argument("--output-dir", required=True)
    return parser


def _prepare(args: argparse.Namespace) -> int:
    from .cohort import load_cohort_manifest
    from .dataset import load_agent_error_bench

    dataset = load_agent_error_bench(args.dataset)
    cohort = load_cohort_manifest(
        args.cohort_manifest,
        dataset=dataset,
    )
    document = prepare_replay_inputs(
        dataset=dataset,
        cohort=cohort,
        source_predictions_path=args.source_predictions,
        expected_source_sha256=args.expected_source_sha256,
        expected_source_prompt_version=(
            args.expected_source_prompt_version
        ),
        output_path=args.output,
        expected_count=args.expected_count,
    )
    print(
        json.dumps(
            {
                "output": str(Path(args.output).expanduser().resolve()),
                "entry_count": document["entry_count"],
                "replay_manifest_sha256": document[
                    "replay_manifest_sha256"
                ],
                "gold_free": True,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _predict(args: argparse.Namespace) -> int:
    started = datetime.now(timezone.utc)
    manifest = load_replay_manifest(args.manifest)
    judge_class = (
        GeminiGenerateContentJudge
        if args.judge_provider == "gemini-generate-content"
        else OpenAICompatibleJudge
    )
    judge = judge_class(
        base_url=args.judge_base_url,
        api_key_env=args.judge_api_key_env,
        model=args.judge_model,
        temperature=args.judge_temperature,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
    )
    config = BenchmarkRunConfig(
        model=args.judge_model,
        temperature=args.judge_temperature,
        provider=args.judge_provider,
        endpoint=judge.endpoint,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
        cohort_sha256=manifest["parent_cohort_sha256"],
    )
    rows = predict_replay(
        manifest_path=args.manifest,
        judge=judge,
        config=config,
        cache_dir=args.cache_dir,
        unscored_output_path=args.output,
        retry_failures=args.retry_failures,
    )
    finished = datetime.now(timezone.utc)
    telemetry = replay_provider_telemetry(judge)
    metadata = {
        "schema_version": REPLAY_RUN_SCHEMA_VERSION,
        "method": REPLAY_METHOD,
        "prediction_schema_version": REPLAY_PREDICTION_SCHEMA_VERSION,
        "replay_pipeline_version": REPLAY_PIPELINE_VERSION,
        "prepared_manifest_path": str(
            Path(args.manifest).expanduser().resolve()
        ),
        "prepared_manifest_sha256": manifest["replay_manifest_sha256"],
        "source_predictions_sha256": manifest[
            "source_predictions_sha256"
        ],
        "started_at": started.isoformat(),
        "finished_at": finished.isoformat(),
        "duration_seconds": (finished - started).total_seconds(),
        "provider": args.judge_provider,
        "endpoint": judge.endpoint,
        "model": args.judge_model,
        "temperature": args.judge_temperature,
        "timeout": args.judge_timeout,
        "max_output_tokens": args.judge_max_output_tokens,
        "max_retries": args.judge_max_retries,
        "retry_backoff": args.judge_retry_backoff,
        "prompt_protocol_version": PROMPT_PROTOCOL_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "provider_telemetry": telemetry,
        "prediction_count": len(rows),
        "cache_hit_count": sum(bool(row.get("cache_hit")) for row in rows),
        "status_counts": {
            status: sum(row.get("status") == status for row in rows)
            for status in sorted({str(row.get("status")) for row in rows})
        },
        "unscored_predictions_path": str(
            Path(args.output).expanduser().resolve()
        ),
        "unscored_predictions_sha256": replay_artifact_sha256(args.output),
        "cache_dir": str(Path(args.cache_dir).expanduser().resolve()),
    }
    _atomic_json(
        Path(args.run_metadata).expanduser().resolve(),
        metadata,
    )
    print(
        json.dumps(
            {
                "unscored_predictions": metadata[
                    "unscored_predictions_path"
                ],
                "run_metadata": str(
                    Path(args.run_metadata).expanduser().resolve()
                ),
                "prediction_count": len(rows),
                "provider_telemetry": telemetry,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _predict_audit(args: argparse.Namespace) -> int:
    started = datetime.now(timezone.utc)
    manifest = load_replay_manifest(args.manifest)
    judge_class = (
        GeminiGenerateContentJudge
        if args.judge_provider == "gemini-generate-content"
        else OpenAICompatibleJudge
    )
    judge = judge_class(
        base_url=args.judge_base_url,
        api_key_env=args.judge_api_key_env,
        model=args.judge_model,
        temperature=args.judge_temperature,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
    )
    config = BenchmarkRunConfig(
        model=args.judge_model,
        temperature=args.judge_temperature,
        provider=args.judge_provider,
        endpoint=judge.endpoint,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
        cohort_sha256=manifest["parent_cohort_sha256"],
    )
    rows = predict_explicit_audit_replay(
        manifest_path=args.manifest,
        complete=judge.complete,
        config=config,
        cache_dir=args.cache_dir,
        unscored_output_path=args.output,
        retry_failures=args.retry_failures,
    )
    finished = datetime.now(timezone.utc)
    telemetry = replay_provider_telemetry(judge)
    metadata = {
        "schema_version": AUDIT_REPLAY_RUN_SCHEMA_VERSION,
        "replay_pipeline_version": AUDIT_REPLAY_PIPELINE_VERSION,
        "method": AUDIT_REPLAY_METHOD,
        "prediction_schema_version": (
            AUDIT_REPLAY_PREDICTION_SCHEMA_VERSION
        ),
        "prepared_manifest_path": str(
            Path(args.manifest).expanduser().resolve()
        ),
        "prepared_manifest_sha256": manifest["replay_manifest_sha256"],
        "source_predictions_sha256": manifest[
            "source_predictions_sha256"
        ],
        "started_at": started.isoformat(),
        "finished_at": finished.isoformat(),
        "duration_seconds": (finished - started).total_seconds(),
        "provider": args.judge_provider,
        "endpoint": judge.endpoint,
        "model": args.judge_model,
        "temperature": args.judge_temperature,
        "timeout": args.judge_timeout,
        "max_output_tokens": args.judge_max_output_tokens,
        "max_retries": args.judge_max_retries,
        "retry_backoff": args.judge_retry_backoff,
        "prompt_protocol_version": AUDIT_PROMPT_PROTOCOL_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "provider_telemetry": telemetry,
        "prediction_count": len(rows),
        "cache_hit_count": sum(bool(row.get("cache_hit")) for row in rows),
        "status_counts": {
            status: sum(row.get("status") == status for row in rows)
            for status in sorted({str(row.get("status")) for row in rows})
        },
        "unscored_predictions_path": str(
            Path(args.output).expanduser().resolve()
        ),
        "unscored_predictions_sha256": replay_artifact_sha256(args.output),
        "cache_dir": str(Path(args.cache_dir).expanduser().resolve()),
    }
    _atomic_json(
        Path(args.run_metadata).expanduser().resolve(),
        metadata,
    )
    print(
        json.dumps(
            {
                "unscored_predictions": metadata[
                    "unscored_predictions_path"
                ],
                "run_metadata": str(
                    Path(args.run_metadata).expanduser().resolve()
                ),
                "prediction_count": len(rows),
                "provider_telemetry": telemetry,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _predict_handoff(args: argparse.Namespace) -> int:
    started = datetime.now(timezone.utc)
    manifest = load_replay_manifest(args.manifest)
    judge_class = (
        GeminiGenerateContentJudge
        if args.judge_provider == "gemini-generate-content"
        else OpenAICompatibleJudge
    )
    judge = judge_class(
        base_url=args.judge_base_url,
        api_key_env=args.judge_api_key_env,
        model=args.judge_model,
        temperature=args.judge_temperature,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
    )
    config = BenchmarkRunConfig(
        model=args.judge_model,
        temperature=args.judge_temperature,
        provider=args.judge_provider,
        endpoint=judge.endpoint,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
        cohort_sha256=manifest["parent_cohort_sha256"],
    )
    rows = predict_handoff_replay(
        manifest_path=args.manifest,
        complete=judge.complete,
        config=config,
        cache_dir=args.cache_dir,
        unscored_output_path=args.output,
        retry_failures=args.retry_failures,
    )
    finished = datetime.now(timezone.utc)
    telemetry = replay_provider_telemetry(judge)
    metadata = {
        "schema_version": HANDOFF_REPLAY_RUN_SCHEMA_VERSION,
        "method": HANDOFF_REPLAY_METHOD,
        "prediction_schema_version": (
            HANDOFF_REPLAY_PREDICTION_SCHEMA_VERSION
        ),
        "replay_pipeline_version": HANDOFF_REPLAY_PIPELINE_VERSION,
        "prepared_manifest_path": str(
            Path(args.manifest).expanduser().resolve()
        ),
        "prepared_manifest_sha256": manifest["replay_manifest_sha256"],
        "source_predictions_sha256": manifest[
            "source_predictions_sha256"
        ],
        "started_at": started.isoformat(),
        "finished_at": finished.isoformat(),
        "duration_seconds": (finished - started).total_seconds(),
        "provider": args.judge_provider,
        "endpoint": judge.endpoint,
        "model": args.judge_model,
        "temperature": args.judge_temperature,
        "timeout": args.judge_timeout,
        "max_output_tokens": args.judge_max_output_tokens,
        "max_retries": args.judge_max_retries,
        "retry_backoff": args.judge_retry_backoff,
        "prompt_protocol_version": HANDOFF_PROMPT_PROTOCOL_VERSION,
        "evidence_validation_version": EVIDENCE_VALIDATION_VERSION,
        "transport_policy_version": TRANSPORT_POLICY_VERSION,
        "provider_telemetry": telemetry,
        "prediction_count": len(rows),
        "cache_hit_count": sum(bool(row.get("cache_hit")) for row in rows),
        "status_counts": {
            status: sum(row.get("status") == status for row in rows)
            for status in sorted({str(row.get("status")) for row in rows})
        },
        "unscored_predictions_path": str(
            Path(args.output).expanduser().resolve()
        ),
        "unscored_predictions_sha256": replay_artifact_sha256(args.output),
        "cache_dir": str(Path(args.cache_dir).expanduser().resolve()),
    }
    _atomic_json(
        Path(args.run_metadata).expanduser().resolve(),
        metadata,
    )
    print(
        json.dumps(
            {
                "unscored_predictions": metadata[
                    "unscored_predictions_path"
                ],
                "run_metadata": str(
                    Path(args.run_metadata).expanduser().resolve()
                ),
                "prediction_count": len(rows),
                "provider_telemetry": telemetry,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _prepare_evidence_repair(args: argparse.Namespace) -> int:
    document = prepare_evidence_repair(
        replay_manifest_path=args.replay_manifest,
        source_unscored_path=args.source_unscored,
        source_predict_run_path=args.source_predict_run,
        expected_replay_manifest_sha256=(
            args.expected_replay_manifest_sha256
        ),
        expected_source_unscored_sha256=(
            args.expected_source_unscored_sha256
        ),
        expected_source_predict_run_sha256=(
            args.expected_source_predict_run_sha256
        ),
        expected_eligible_count=args.expected_eligible_count,
        output_path=args.output,
    )
    print(
        json.dumps(
            {
                "output": str(Path(args.output).expanduser().resolve()),
                "entry_count": document["entry_count"],
                "repair_manifest_sha256": document[
                    "repair_manifest_sha256"
                ],
                "prompt_sha256": document["entries"][0][
                    "prompt_sha256"
                ],
                "external_calls": 0,
                "gold_free": True,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _predict_evidence_repair(args: argparse.Namespace) -> int:
    manifest = load_evidence_repair_manifest(args.manifest)
    judge_class = (
        GeminiGenerateContentJudge
        if args.judge_provider == "gemini-generate-content"
        else OpenAICompatibleJudge
    )
    judge = judge_class(
        base_url=args.judge_base_url,
        api_key_env=args.judge_api_key_env,
        model=args.judge_model,
        temperature=args.judge_temperature,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
    )
    config = BenchmarkRunConfig(
        model=args.judge_model,
        temperature=args.judge_temperature,
        provider=args.judge_provider,
        endpoint=judge.endpoint,
        timeout=args.judge_timeout,
        max_output_tokens=args.judge_max_output_tokens,
        max_retries=args.judge_max_retries,
        retry_backoff=args.judge_retry_backoff,
        cohort_sha256=manifest["parent_cohort_sha256"],
        api_key_env=args.judge_api_key_env,
    )
    rows, metadata = predict_evidence_repair(
        repair_manifest_path=args.manifest,
        complete=judge.complete,
        config=config,
        cache_dir=args.cache_dir,
        attempts_output_path=args.output,
        run_metadata_path=args.run_metadata,
        telemetry_snapshotter=lambda: provider_telemetry_snapshot(judge),
        capability_snapshotter=lambda: judge.capability_snapshot(),
    )
    print(
        json.dumps(
            {
                "attempts": metadata["attempts_path"],
                "run_metadata": str(
                    Path(args.run_metadata).expanduser().resolve()
                ),
                "attempt_count": len(rows),
                "provider_telemetry": metadata["provider_telemetry"],
                "provider_capabilities": metadata[
                    "provider_capabilities"
                ],
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _finalize_evidence_repair(args: argparse.Namespace) -> int:
    rows, metadata = finalize_evidence_repair(
        repair_manifest_path=args.repair_manifest,
        replay_manifest_path=args.replay_manifest,
        source_unscored_path=args.source_unscored,
        source_predict_run_path=args.source_predict_run,
        attempts_path=args.attempts,
        predict_run_path=args.predict_run,
        output_path=args.output,
        run_metadata_path=args.run_metadata,
    )
    print(
        json.dumps(
            {
                "unscored_predictions": metadata[
                    "unscored_predictions_path"
                ],
                "run_metadata": str(
                    Path(args.run_metadata).expanduser().resolve()
                ),
                "prediction_count": len(rows),
                "external_calls": 0,
                "gold_free": True,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _score_evidence_repair(args: argparse.Namespace) -> int:
    from .cohort import load_cohort_manifest
    from .dataset import load_agent_error_bench

    dataset = load_agent_error_bench(args.dataset)
    cohort = load_cohort_manifest(
        args.cohort_manifest,
        dataset=dataset,
    )
    scored, metrics, finalize_run = score_evidence_repair(
        dataset=dataset,
        cohort=cohort,
        replay_manifest_path=args.replay_manifest,
        unscored_predictions_path=args.unscored_predictions,
        finalize_run_path=args.finalize_run,
    )
    run_metadata = {
        **finalize_run,
        "workers": 1,
        "execution_order": "frozen-e5d-dry3-order",
        "methods": [E5D_METHOD],
        "prompt_versions": {
            E5D_METHOD: finalize_run["repair_protocol_version"]
        },
        "released_label_count": len(dataset.labels),
        "available_trajectory_count": len(dataset.examples),
        "judge_input_count": len(scored),
        "metric_cohort_count": len(scored),
        "selection": {
            "cohort": "e5d_frozen_e5c_tuning_dry3",
            "cohort_manifest_path": str(cohort.path),
            "cohort_name": cohort.cohort_name,
            "cohort_sha256": cohort.cohort_sha256,
            "dataset_manifest_sha256": dataset.dataset_sha256,
            "replay_manifest_sha256": finalize_run[
                "prepared_manifest_sha256"
            ],
        },
    }
    paths = write_outputs(
        output_dir=args.output_dir,
        dataset=dataset,
        predictions=scored,
        metrics=metrics,
        run_metadata=run_metadata,
    )
    print(json.dumps(paths, ensure_ascii=False, indent=2))
    return 0


def _score(args: argparse.Namespace) -> int:
    from .cohort import load_cohort_manifest
    from .dataset import load_agent_error_bench

    dataset = load_agent_error_bench(args.dataset)
    cohort = load_cohort_manifest(
        args.cohort_manifest,
        dataset=dataset,
    )
    predict_metadata = json.loads(
        Path(args.predict_run_metadata)
        .expanduser()
        .resolve()
        .read_text(encoding="utf-8")
    )
    scored, metrics = score_replay(
        dataset=dataset,
        cohort=cohort,
        manifest_path=args.manifest,
        unscored_predictions_path=args.unscored_predictions,
        predict_run_metadata=predict_metadata,
    )
    manifest = load_replay_manifest(args.manifest)
    methods = sorted({str(row["method"]) for row in scored})
    if len(methods) != 1:
        raise ValueError("replay score requires exactly one prediction method")
    method_contract = replay_method_contract(methods[0])
    run_metadata = {
        **predict_metadata,
        "workers": 1,
        "execution_order": "frozen-e4-dry3-order",
        "methods": methods,
        "prompt_versions": {
            method: predict_metadata.get("prompt_protocol_version")
            for method in methods
        },
        "released_label_count": len(dataset.labels),
        "available_trajectory_count": len(dataset.examples),
        "judge_input_count": len(scored),
        "metric_cohort_count": len(scored),
        "selection": {
            "cohort": method_contract["selection_name"],
            "cohort_manifest_path": str(cohort.path),
            "cohort_name": cohort.cohort_name,
            "cohort_sha256": cohort.cohort_sha256,
            "dataset_manifest_sha256": dataset.dataset_sha256,
            "replay_manifest_sha256": manifest[
                "replay_manifest_sha256"
            ],
            "source_predictions_sha256": manifest[
                "source_predictions_sha256"
            ],
        },
    }
    paths = write_outputs(
        output_dir=args.output_dir,
        dataset=dataset,
        predictions=scored,
        metrics=metrics,
        run_metadata=run_metadata,
    )
    print(json.dumps(paths, ensure_ascii=False, indent=2))
    return 0


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if args.command == "prepare":
        return _prepare(args)
    if args.command == "predict":
        return _predict(args)
    if args.command == "predict-audit":
        return _predict_audit(args)
    if args.command == "predict-handoff":
        return _predict_handoff(args)
    if args.command == "prepare-evidence-repair":
        return _prepare_evidence_repair(args)
    if args.command == "predict-evidence-repair":
        return _predict_evidence_repair(args)
    if args.command == "finalize-evidence-repair":
        return _finalize_evidence_repair(args)
    if args.command == "score-evidence-repair":
        return _score_evidence_repair(args)
    if args.command == "score":
        return _score(args)
    raise AssertionError("unreachable replay command")


if __name__ == "__main__":
    raise SystemExit(main())

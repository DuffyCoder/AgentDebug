# Artifact policy

Frozen prediction/audit files retain their recorded provenance. Selected
observations and method-family terminology are explained in
[Evaluation](../docs/results/README.md).

`results/` contains derived, text-free score accounting and provenance for the
complete experiment history. Verify with
`python -m scripts.reproduction.research_release verify`.

`releases/` contains the existing frozen predictions and audit bundle. Internal
archive identifiers are preserved for hash verification, not method selection.
It is useful for full reproduction but includes evidence quotations derived
from AgentErrorBench. Path sanitization is **not** redistribution permission or
PII review. Its distribution must pass [the data-rights review](../docs/data-provenance.md).
Do not expose this directory to a blind-evaluation participant: it contains solutions.

No raw trajectory corpus, model transcript archive, account credentials or private
hidden data belongs here. Hidden-set audit summaries may record counts and
verification outcomes, but should not publish private instance identifiers.

Full historical accounting and authoring materials have one navigation entry:
[Research archive](../research/README.md).
